const cds = require('@sap/cds');

const { Annotation, MessagesAnnotation, StateGraph, MemorySaver } = require('@langchain/langgraph');
const { Readable } = require('stream');

const oStateAnnotation = Annotation.Root({
    ...MessagesAnnotation.spec,
    sWhichAction: Annotation(String),
    bInputValidationSuccess: Annotation(Boolean),
    bActionSuccess: Annotation(Boolean),
    sApiCall: Annotation(String)
});

let metadataSpec = null;

const oUserRequestedAction = async (state) => {
    const oSystemPromptTemplate = {
        messages: [{
            "role": "system",
            "content": `You are a Product Master data maintenance agent who can determine whether user is requesting for a new Product creation or updating an existing one.
                        Our product categories includes electrical appliances, foods and beverages.
                        If you determine that the input message from user is not requesting for any of these product categories then your response must be "Others" in the json format outlined below.
                        The response must be in JSON as below:

                        {
                            "outcome": "<one of ['Product Create Requested','Product Update Requested','Others']>"
                        }

                        Your job now is only to detect if in the input message user is requesting for a new Product creation or updating an existing one.
                        The input message from user should only request for product related actions and otherwise return "Others".
                        
                        Here is the input message:
                        <message>
                            ${state.messages[0].content}
                        </message>
                        
                        Some examples below:

                        example-1:
                        user message is: "create a new product with name Cereals, description Morning breakfast good for health cereals, category Food"
                        your output is: {"outcome": "Product Create Requested"}
                        reason: user asked about our product category and also asked for creation
                        
                        example-2:
                        user message is: "change a product with name Cereals. Change the description to Cereals are good for health"
                        your output is: {"outcome": "Product Update Requested"}
                        reason: user asked about our product category and also asked for update
                        
                        example-3:
                        user message is: "what is the weather in Hyderabad and which diet is good for this weather?"
                        your output is: {"outcome": "Others"}
                        reason: user did not ask about our product category at all. In this user message, it is about weather`
        }]
    };

    const oChatModelConfig = cds.env.requires["gen-ai-hub"]["gpt-4o"];

    const oLlmPlugin = await cds.connect.to("cap-llm-plugin");
    const oMessageResponse = await oLlmPlugin.getChatCompletionWithConfig(oChatModelConfig, oSystemPromptTemplate);
    const oOutcome = JSON.parse(oMessageResponse.choices[0].message.content.replace(/^```json\n|\n```$/g, ''));

    return {
        messages: [...state.messages],
        sWhichAction: oOutcome.outcome
    }
};

const oValidateInput = async (state) => {

    // fetch the service metadata which can form as base for input validation
    const oProductApi = await cds.connect.to("northwind");

    let bError = false;

    const response = await oProductApi.send({
        method: 'GET',
        path: "/$metadata",
    }).catch((error) => {
        cds.log("apiActionExecuteNodeError").error(error);
        bError = true;
    });

    metadataSpec = response;

    const oSystemPromptTemplate = {
        messages: [{
            "role": "system",
            "content": `You are a Product Master data maintenance agent who can validte if the inputs for creation or update of product master is complete.
                        The action user has requested to be performed is ${state.sWhichAction} and this was determined by you in the previous step.
                        Your response is a boolean true in JSON format outlined below, if input is valid for the action to be performed or false otherwise. The response must be in JSON as below:
                        
                        {
                            "outcome": <true or false>
                        }
                        
                        Your job is now to validate if the input message for creation or update of product master has all the necessary data to create or update the product respectively. 
                        The completion or incompletion of input should be determined based on the API metadata specification. The specification is provided in XML format below: 

                        <metadata-specification>
                            ${response}
                        </metadata-specification>

                        Here is the input message:
                        <message>
                            ${state.messages[0].content}
                        </message>

                        Some examples below:

                        example-1:
                        user message is: "create a new product with name Cereals, description Morning breakfast good for health cereals, category Food"
                        your output is: {"outcome": true}
                        
                        example-2:
                        user message is: "change a product with name Cereals."
                        your output is: {"outcome": false}
                        reason: field to change is not provided
                        
                        example-3:
                        user message is: "what is the weather in Hyderabad and which diet is good for this weather?"
                        your output is: {"outcome": false}`
        }]
    };

    const oChatModelConfig = cds.env.requires["gen-ai-hub"]["gpt-4o"];

    const oLlmPlugin = await cds.connect.to("cap-llm-plugin");
    const oMessageResponse = await oLlmPlugin.getChatCompletionWithConfig(oChatModelConfig, oSystemPromptTemplate);
    const oOutcome = JSON.parse(oMessageResponse.choices[0].message.content.replace(/^```json\n|\n```$/g, ''));

    return {
        messages: [...state.messages],
        bInputValidationSuccess: oOutcome.outcome
    }
};

const oPrepareApiCall = async (state) => {
    const oSystemPromptTemplate = {
        messages: [{
            "role": "system",
            "content": `You are a Product Master data technical API expert who can prepare an API call for the action to be performed.
                        The action user has requested to be performed is ${state.sWhichAction} and this was determined by you in one of the prior steps.
                        Your response is a string that is the complete API call to be executed in later steps. The complete API call typically includes all the information below:
                        1. HTTP method
                        2. API endpoint alone from metadata specification. Base URL is not needed
                        3. JSON payload to be passed in the request body
                        4. query parameters (if any)

                        The response must be packed in a valid JSON as below:

                        {
                            "outcome": {
                                "method": "<HTTP method>",
                                "endpoint": "<API endpoint>",
                                "body": "<JSON payload to be passed in the request body>",
                                "query": "<query parameters (if any)>"
                            }
                        }

                        Your job is now to determine the complete API call for the action to be performed and use the user message below to extract the necessary information for the payload to be passed in the request body and query parameters (if any).
                        When determining body payload remove the fields that are not part of the metadata specification below. Also ensure the body payload contains the field names mentioned in the specification, so whereeer necessary use the fieldnames from the metadata spec below:

                        <metadata-specification>
                            ${metadataSpec}
                        </metadata-specification>

                        <message>
                            ${state.messages[0].content}
                        </message>

                        Some examples below:

                        example-1:
                        user message is: "create a new product with name Cereals, description Morning breakfast good for health cereals, category Food"
                        your output is: {"outcome": {"method": "POST", "url": "/products", "body": {"name": "Cereals", "description": "Morning breakfast good for health cereals"} }
                        reason: category removed from the body as it is not part of the metadata API spec
                        
                        example-2:
                        user message is: "change a product with name Cereals. Change the description to Cereals are good for health"
                        your output is: {"outcome": {"method": "PATCH", "url": "/products", "body": {"description": "Cereals are good for health"} }`
        }]
    };

    const oChatModelConfig = cds.env.requires["gen-ai-hub"]["gpt-4o"];

    const oLlmPlugin = await cds.connect.to("cap-llm-plugin");
    const oMessageResponse = await oLlmPlugin.getChatCompletionWithConfig(oChatModelConfig, oSystemPromptTemplate);
    const oOutcome = JSON.parse(oMessageResponse.choices[0].message.content.replace(/^```json\n|\n```$/g, ''));

    return {
        messages: [...state.messages],
        sApiCall: JSON.stringify(oOutcome.outcome)
    }
};

const oExecuteApiCall = async (state) => {
    const oApiCallToTrigger = JSON.parse(state.sApiCall);
    const oProductApi = await cds.connect.to("northwind");

    let bError = false;

    const response = await oProductApi.send({
        method: oApiCallToTrigger.method,
        headers: {
            "Content-Type": "application/json"
        },
        path: "/products",
        data: oApiCallToTrigger.body
    }).catch((error) => {
        cds.log("apiActionExecuteNodeError").error(error);
        bError = true;
    });

    return {
        messages: [...state.messages],
        bActionSuccess: !bError
    };

};

const oUserToValidation = async (state) => {
    return state.sWhichAction === "Product Create Requested" || state.sWhichAction === "Product Update Requested" ?
        "validate_input" : "__end__";
};

const oValidationToPrepareCall = async (state) => {
    return state.bInputValidationSuccess ? "prepare_action_call" : "__end__";
};

let builder = new StateGraph(oStateAnnotation)
    .addNode("user_requested_action", oUserRequestedAction)
    .addNode("validate_input", oValidateInput)
    .addNode("prepare_action_call", oPrepareApiCall)
    .addNode("execute_action_call", oExecuteApiCall)
    .addEdge("__start__", "user_requested_action")
    .addConditionalEdges("user_requested_action", oUserToValidation)
    .addConditionalEdges("validate_input", oValidationToPrepareCall)
    .addEdge("prepare_action_call", "execute_action_call")
    .addEdge("execute_action_call", "__end__");

// use memory for summarization of all activities later
// const checkpointer = new MemorySaver();

// const graph = builder.compile({
//     checkpointer,
// });

const graph = builder.compile();

module.exports = class AgentService extends cds.ApplicationService {
    init() {
        this.on("startAgentStream", async (req) => {

            const sMessage = req.data.message;
            const sThreadId = req.data.threadId;

            const input = {
                messages: [{
                    "role": "user",
                    content: sMessage
                }]
            };

            const streamUpdates = await graph.stream(input, { configurable: { "thread_id": sThreadId }, streamMode: "updates" });
            const readable = Readable.from(streamUpdates);

            req.res.setHeader("Content-Type", "text/event-stream");
            req.res.setHeader("Connection", "keep-alive");
            req.res.setHeader("Cache-Control", "no-cache");
            req.res.setHeader("Transfer-Encoding", "chunked");

            await new Promise((resolve) => {
                readable.on("data", (chunk) => {
                    cds.log("interimNodeResponse").info(chunk);
                    req.res.write(`event: message\nid: ${Object.keys(chunk)[0]}\ndata: ${JSON.stringify(chunk)}\n\n`);
                });

                readable.on("end", () => {
                    cds.log("endInterimResponse").info("end response stream");
                    req.res.end();
                    resolve("Success");
                });

                readable.on("error", (error) => {
                    cds.log("interimErrorResponse").error(error);
                    req.res.end();
                    resolve(null);
                });
            });

        });

        super.init();
    }
}