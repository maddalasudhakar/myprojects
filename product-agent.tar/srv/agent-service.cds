
service ProductAgentService {
    function startAgentStream(message: LargeString, threadId: String(100)) returns LargeBinary;
}