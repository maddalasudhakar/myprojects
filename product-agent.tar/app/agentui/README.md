## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon Dec 30 2024 19:26:15 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.12.2|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>simple|
|**Service Type**<br>Local Cap|
|**Service URL**<br>http://localhost:4004/odata/v4/product-agent/
|**Module Name**<br>agentui|
|**Application Title**<br>Northwind Product Agent|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon_dark|
|**UI5 Version**<br>1.131.1|
|**Enable Code Assist Libraries**<br>True|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|

## agentui

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply start your CAP project and navigate to the following location in your browser:

http://localhost:4004/agentui/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


