sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/base/util/uid"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, Uuid) {
        "use strict";

        return Controller.extend("agentui.controller.AgentUi", {
            onInit: function () {
                this.getView().byId("idFeedList").setModel(new JSONModel({}), "feedList");
            },

            onSendQuestion: function (oEvent) {
                this.getView().byId("idFeedList").setModel(new JSONModel({}), "feedList");

                let sMessage = oEvent.getParameters().value;
                let oModel = this.getView().getModel();
                let oFeedListModel = this.getView().byId("idFeedList").getModel("feedList");
                let oNodeUra = this.getView().byId("idUra");
                let oNodeVi = this.getView().byId("idVi");
                let oNodePac = this.getView().byId("idPac");
                let oNodeEa = this.getView().byId("idEa");
                let that = this;

                this.getView().byId("idFeedList").setBusy(true);
                this.getView().byId("idIMsg").setVisible(true);

                const threadId = Uuid() + Uuid();

                let eventSource = new EventSource(`${oModel.getServiceUrl()}startAgentStream(message='${sMessage}',threadId='${threadId}')`);

                oNodeUra.setStatus("Warning"); 

                eventSource.onmessage = function (oEvent) {
                    let oCurrentData = oFeedListModel.getData();
                    let oEventData = JSON.parse(oEvent.data);
                    let sTitle = "", sInputMessage = oEventData[oEvent.lastEventId].messages[0].kwargs.content, sAgentAction = "", sData = "";

                    that.getView().byId("idIMsg").setVisible(false);
                    that.getView().byId("idFeedList").setVisible(true);
                    that.getView().byId("idFeedList").setBusy(false);

                    if (oEvent.lastEventId === "user_requested_action") {
                        sTitle = "What action (create or update) was requested by the user based on the input message?";
                        sAgentAction = `Action detected: ${oEventData[oEvent.lastEventId].sWhichAction}`;
                        sData = `\nStep-1: ${sTitle}\n\nYour Input Message: ${sInputMessage}\n\n${sAgentAction}\n\n`;
                        if(oEventData[oEvent.lastEventId].sWhichAction !== "Others"){
                            oNodeUra.setStatus("Success"); 
                            oNodeVi.setStatus("Warning");  
                        } else {
                            oNodeUra.setStatus("Error");
                        }
                        
                    } else if (oEvent.lastEventId === "validate_input") {
                        sTitle = "Do we have all necessary inputs to execute the requested action?";
                        sAgentAction = `Validation Status: ${oEventData[oEvent.lastEventId].bInputValidationSuccess ? "Success" : "Failed"}`;
                        sData = `\nStep-2: ${sTitle}\n\nYour Input Message: ${sInputMessage}\n\n${sAgentAction}\n\n`;

                        if(oEventData[oEvent.lastEventId].bInputValidationSuccess) {
                            oNodeVi.setStatus("Success");
                            oNodePac.setStatus("Warning");
                        } else {
                            oNodeVi.setStatus("Error");
                        }
                        
                    } else if (oEvent.lastEventId === "prepare_action_call") {
                        sTitle = "What are the inputs extracted from the input message?";
                        sAgentAction = `Action Call Details:\n\t\t ${JSON.stringify(JSON.parse(oEventData[oEvent.lastEventId].sApiCall),null,4)}`;
                        sData = `\nStep-3: ${sTitle}\n\nYour Input Message: ${sInputMessage}\n\n${sAgentAction}\n\n`;
                        oNodePac.setStatus("Success");
                        oNodeEa.setStatus("Warning");
                    } else {
                        sTitle = "Is the action executed successfully?";
                        sAgentAction = `Action Execution Status:\n\t\t ${oEventData[oEvent.lastEventId].bActionSuccess ? "Success" : "Failed"}`;
                        sData = `\nStep-4: ${sTitle}\n\nYour Input Message: ${sInputMessage}\n\n${sAgentAction}\n\n`;
                        if(oEventData[oEvent.lastEventId].bActionSuccess) {
                            oNodeEa.setStatus("Success");
                        } else {
                            oNodeEa.setStatus("Error");
                        }
                    }

                    if (Object.keys(oCurrentData)[0] === "response") {
                        oCurrentData.response.push({ "data": sData });
                        oFeedListModel.setProperty("/response", oCurrentData.response);
                    } else {
                        oFeedListModel.setData({ "response": [{ "data": sData }] });
                    }
                };

                eventSource.onerror = function (oEvent) {
                    eventSource.close();
                };

                eventSource.onclose = function () {
                    // closed event
                };

                // let oBindingContext = oModel.bindContext("/startAgentStream(...)");
                // oBindingContext.setParameter("message", sMessage);
                // oBindingContext.invoke().then(function (oResponse) {

                //     // let oData = JSON.parse(oResponse.data);
                //     // oData = oFeedListModel.getData().response.push(oData);
                //     // oFeedListModel.setProperty("/response", oData);
                // });
            }
        });
    });
