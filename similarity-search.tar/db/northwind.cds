namespace northwind.masterdata;

using {cuid, managed} from '@sap/cds/common';

// ideally types can be centralized and reused in multiple other places
// for simplicity sake the type is added here
type Address: {
    street: String(512);
    city: String(512);
    state: String(512);
    zipCode: String(128);
    country: String(512);
}

entity Products: cuid, managed {
    key ID: UUID @odata.Type: 'Edm.String';
    name: String(256);
    description: String(512);
    releaseDate: DateTime;
    discontinuedDate: DateTime;
    rating: Int16;
    price: Decimal(16, 3);
    toCategory: Association to one Categories;
    toProductDetail: Composition of one ProductsDetail;
    toSupplier: Association to one Supplier;
    vectorMetadata: String(4999);
    productVector: cds.Vector;
}

entity ProductsDetail: cuid {
    details: String(1024);
    toProduct: Association to one Products;
}

entity Categories: cuid {
    name: String(256);
    toProducts: Composition of many Products;
}

entity Supplier: cuid {
    name: String(256);
    address: Address;
    concurrency: Int16;
    toProducts: Association to many Products;
}

entity Advertisements: cuid {
    name: String(256);
    airDate: DateTime;
    toProduct: Association to one Products;
}