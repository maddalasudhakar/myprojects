using NorthwindService as service from '../../srv/northwind-service';

annotate service.products with @(UI.LineItem: {
    ![@UI.Criticality]: criticality,
    $value            : [
        {
            $Type: 'UI.DataField',
            Label: 'Product Name',
            Value: name
        },
        {
            $Type: 'UI.DataField',
            Label: 'Description',
            Value: description,
        },
        {
            $Type: 'UI.DataField',
            Label: 'Release Date',
            Value: releaseDate,
        },
        {
            $Type: 'UI.DataField',
            Label: 'Discontinued Date',
            Value: discontinuedDate,
        },
        {
            $Type: 'UI.DataField',
            Label: 'Rating',
            Value: rating,
        }
    ]
}) {
    criticality @UI.Hidden;
};

annotate service.products with {
    toProductDetail @Common.ValueList: {
        $Type         : 'Common.ValueListType',
        CollectionPath: 'ProductsDetail',
        Parameters    : [
            {
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: toProductDetail_ID,
                ValueListProperty: 'ID',
            },
            {
                $Type            : 'Common.ValueListParameterDisplayOnly',
                ValueListProperty: 'details',
            },
        ],
    }
};

annotate service.products with @(
    UI.FieldGroup #GeneratedGroup1: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Label: 'name',
                Value: name,
            },
            {
                $Type: 'UI.DataField',
                Label: 'description',
                Value: description,
            },
            {
                $Type: 'UI.DataField',
                Label: 'releaseDate',
                Value: releaseDate,
            },
            {
                $Type: 'UI.DataField',
                Label: 'discontinuedDate',
                Value: discontinuedDate,
            },
            {
                $Type: 'UI.DataField',
                Label: 'rating',
                Value: rating,
            },
            {
                $Type: 'UI.DataField',
                Label: 'price',
                Value: price,
            },
        ],
    },
    UI.Facets                     : [{
        $Type : 'UI.ReferenceFacet',
        ID    : 'GeneratedFacet1',
        Label : 'General Information',
        Target: '@UI.FieldGroup#GeneratedGroup1',
    }, ]
);
