sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'productsimilaritysearch/test/integration/FirstJourney',
		'productsimilaritysearch/test/integration/pages/productsList',
		'productsimilaritysearch/test/integration/pages/productsObjectPage'
    ],
    function(JourneyRunner, opaJourney, productsList, productsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('productsimilaritysearch') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheproductsList: productsList,
					onTheproductsObjectPage: productsObjectPage
                }
            },
            opaJourney.run
        );
    }
);