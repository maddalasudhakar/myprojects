sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("productsimilaritysearch.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);