const cds = require("@sap/cds");

module.exports = class EmbeddingsService extends cds.ApplicationService {
    init() {
        this.on("create", async (req) => {
            const { Products } = cds.entities("northwind.masterdata");
            let aNeededEmbeddings = await SELECT.from(Products);
            // .where({
            //     createdAt: {
            //         $gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
            //     },
            //     modifiedAt: {
            //         $gte: new Date(Date.now() - 24 * 60 * 60 * 1000)
            //     }
            // });

            if (aNeededEmbeddings.length > 0) {
                cds.spawn(null, async (tx) => {
                    let aDataToUpdate = [];
                    const traceloop = require("@traceloop/node-server-sdk");

                    const promises = aNeededEmbeddings.map(async (data) => {
                        try {
                            const llmPlugin = await cds.connect.to("cap-llm-plugin");
                            const embeddingModelConfig = cds.env.requires["gen-ai-hub"]["ada-002"];
                            let response = null;

                            response = await traceloop.withWorkflow({ name: "similarity-search-job-llmplugin", traceContent: true }, async () => {
                                return await traceloop.withLLMCall({ vendor: "OpenAI", type: "getEmbedding" }, async ({ span }) => {
                                    span.reportRequest({
                                        model: embeddingModelConfig.modelName, messages: [{
                                            role: "user", content: JSON.stringify({
                                                productName: data.name,
                                                productDescription: data.description
                                            })
                                        }]
                                    });

                                    const oEmbedding = await llmPlugin.getEmbeddingWithConfig(embeddingModelConfig, JSON.stringify({
                                        productName: data.name,
                                        productDescription: data.description
                                    }));

                                    span.reportResponse(oEmbedding);

                                    return oEmbedding;
                                });
                            });

                            data.vectorMetadata = JSON.stringify({
                                productName: data.name,
                                productDescription: data.description
                            });

                            data.productVector = `[${response?.data[0]?.embedding}]`;
                            return data;
                        } catch (error) {
                            cds.log("createEmbeddings").error(error);
                            return data;
                        }
                    });

                    try {
                        aDataToUpdate = await Promise.all(promises);
                    } catch (error) {
                        cds.log("createEmbeddings").error(error);
                    }

                    await UPSERT(aDataToUpdate).into(Products);
                    tx.commit();
                    cds.log("createEmbeddingsCompletion").info("Embeddings created");
                });
                req.res.status(202);
                return "Embeddings are being created";
            } else {
                req.res.status(200);
                return "No Embeddings to create or update";
            }
        });

        super.init();
    }
}