
@impl: 'srv/create-product-embeddings.js'
service EmbeddingsService {
    action create() returns String;
}