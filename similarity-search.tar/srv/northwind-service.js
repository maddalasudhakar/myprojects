const cds = require("@sap/cds");

module.exports = class NorthwindService extends cds.ApplicationService {
    init() {
        this.on("READ", "products", async (req, next) => {
            const traceloop = require("@traceloop/node-server-sdk");
            if (req.req?.url.includes('$search')) {
                const llmPlugin = await cds.connect.to("cap-llm-plugin");
                const embeddingModelConfig = cds.env.requires["gen-ai-hub"]["ada-002"];

                try {
                    let aSimilarResults = await traceloop.withWorkflow({ name: "similarity-search-llmplugin", traceContent: true }, async () => {

                        let oEmbedding = await traceloop.withLLMCall({ vendor: "OpenAI", type: "getEmbedding" }, async ({ span }) => {
                            span.reportRequest({ model: embeddingModelConfig.modelName, messages: [{role: "user", content: JSON.stringify({ productName: req.req.query.$search, productDescription: req.req.query.$search })}] });
                            
                            let oEmbedding = await llmPlugin.getEmbeddingWithConfig(embeddingModelConfig, JSON.stringify({
                                productName: req.req.query.$search,
                                productDescription: req.req.query.$search
                            }));

                            span.reportResponse(oEmbedding);
                            return oEmbedding;
                        });

                        return await traceloop.withVectorDBCall({ vendor: "SAP HANA cloud", type: "query" }, async ({ span }) => {
                            span.reportQuery({ queryVector: oEmbedding?.data[0]?.embedding });
                            const results = await llmPlugin.similaritySearch("northwind_masterdata_products", "productVector", "vectorMetadata", oEmbedding?.data[0]?.embedding, "L2DISTANCE", 5);
                            span.reportResults({ results });
                            return results;
                        });

                    });


                    traceloop.withAssociationProperties({
                        inputQuery: JSON.stringify({ productName: req.req.query.$search, productDescription: req.req.query.$search }),
                        response: JSON.stringify(aSimilarResults)
                    }, () => { });

                    let response = aSimilarResults.map(result => {

                        return {
                            ID: result.ID,
                            name: result.name,
                            description: result.description,
                            releaseDate: result.releaseDate,
                            discontinuedDate: result.discontinuedDate,
                            rating: result.rating,
                            score: parseFloat(result.SCORE).toFixed(3),
                            criticality: result.SCORE <= 0.3 ? 3 : result.SCORE <= 0.45 ? 2 : 1
                        };
                    });

                    // always first record show criticality as GREEN as that is the closest the search could find
                    response[0].criticality = 3;

                    // anything having criticality as RED can be removed
                    response = response.filter(item => item.criticality !== 1);

                    return response;
                } catch (error) {
                    cds.log("searchSimilarProducts").error(error);
                }
            }

            return next();
        });
        super.init();
    }
}