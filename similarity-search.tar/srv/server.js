const cds = require("@sap/cds");
const traceloop = require("@traceloop/node-server-sdk");

const vcap = JSON.parse(process.env.VCAP_SERVICES);
const vcapCL = vcap["user-provided"].filter(item => item.tags.includes("Cloud Logging"))[0];
const config = {};

config.url = `https://${vcapCL.credentials["ingest-otlp-endpoint"]}`;
const grpc = require('@grpc/grpc-js');
const secureContext = require('tls').createSecureContext({
cert: vcapCL.credentials['ingest-otlp-cert'],
key: vcapCL.credentials['ingest-otlp-key']
});
config.credentials = grpc.credentials.createFromSecureContext(secureContext);
config.temporalityPreference = 0;

const { OTLPTraceExporter } = require('@opentelemetry/exporter-trace-otlp-grpc');

traceloop.initialize({exporter: new OTLPTraceExporter(config)});

module.exports = cds.server;
