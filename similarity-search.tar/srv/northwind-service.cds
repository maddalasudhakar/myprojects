using {northwind.masterdata as md} from '../db/northwind';

// authenticated-user is a default annotation once service is bound to xsuaa when deployed to CF
// so need not mention this annotation explicitly
service NorthwindService {

    // use readonly, insertonly, updateonly, deleteonly annotations depending on what capabilities the service should offer
    // do not leave every service to offer all capabilities even if its purpose is to allow only read

    // use restrictions with security scopes, never leave endpoint to allow all Henkel users to access (unless exceptional)
    
    entity products as projection on md.Products {
        *,
        0 as score: Decimal(16,3),
        0 as criticality: Integer
    } excluding {
        productVector,
        vectorMetadata
    };
}