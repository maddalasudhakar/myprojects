namespace com.sustainability.feedback.types;

type requestName          : String(100);
type sbu                  : String(3);
type product              : String;
type productType          : String(3);
type assessor             : String(40);
type submitter            : String(40);
type date                 : Date;
type approver             : String(40);
type approvalDate         : Date;
type assesmentType        : String(3);
type status               : String(2);
type statusDescription    : String(15);
type comment              : String;
type rcPreFlag            : String(2);
type rcPreFlagDescription : String;
type projectId            : String;
type sustClass            : String(2);
type category             : String(2);
type contributor          : String(2);
type propagation          : String;
type communicationResponse: String(10) @assert.range enum {
    ERROR;
    SUCCESS;
};
type communicationResponseMessage: String;
type retrial: Boolean;
type rejected: Boolean;
type rejectedAssessment: Boolean;
type feedbackProcessingStatus:  String(10) @assert.range enum {
    INITIAL = '01';
    FAILED  = '02';
    SUCCESS = '03';
};
type feedbackErrorMessage: String;
type virtualAssessment: Boolean;

type assessmentsByStatus {
    started          : Integer;
    submited         : Integer;
    underReSubmitted : Integer;
    approved         : Integer;
}

type ProductData {
    product                     : String;
    type                        : String(3);
    productName                 : String;
    sbu                         : String;
    rcPreFlag                   : String(2);
    rcPreFlagDescription        : String;
    technologyL2Key             : String;
    technologyLevel2            : String;
    sustainabilityClassCode     : String;
    existingSustainabilityClass : String;
    realSubstanceCode           : String(18);
    realSubstanceName           : String(40);
    region                      : String(3);
    applicationLevel2Key        : String(3);
    applicationLevel2           : String;
    lastAssessment              : String;
    lastSubmitter               : String;
    lastApprover                : String;
}

type productsRelation {
    product              : types.product;
    productName          : String;
    realSubstanceCode    : String;
    sustClass            : String(2);
    sustClassDescription : String;
};

type materialsToProducts {
    material : types.product;
    product  : types.product;
}

type assessmentItemErrorMessage {
    code    : Integer;
    message : String;
}

type productsAssessments {
    product     : product;
    requestName : requestName;
}

type communicationStatus: String @assert.range enum {
    PENDING = '01';
    SENDED_CPI = '02';
    ERROR_HANA = '03';
    ERROR_DOCUMENTS = '04';
    ERROR_HANA_DOCUMENTS = '05';
    COMPLETED = '06';
}