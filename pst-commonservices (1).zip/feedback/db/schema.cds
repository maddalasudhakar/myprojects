namespace com.sustainability.feedback;

using {
    managed,
    cuid,
} from '@sap/cds/common';

using com.sustainability.feedback.types as types from './types';

/**
 * Feedback table with asynchronous processing and retrial data for assessments
 */
entity FeedbackToProcess : cuid, managed {
    assessmentID                 : UUID;
    product                      : types.product;
    communicationResponse        : types.communicationResponse;
    communicationResponseMessages: Composition of many CommunicationResponseMessages
                                    on communicationResponseMessages.feedback = $self;
    retrial                      : types.retrial;
    rejected                     : types.rejected;
    // rejectedAssessment           : types.rejectedAssessment;
    feedbackProcessingStatus     : types.feedbackProcessingStatus;
    feedbackErrorMessage         : types.feedbackErrorMessage;
    sourcePayload                : Map;
};

/**
 * Messages attached to onpremise feedback
 */
entity CommunicationResponseMessages: cuid {
    feedback: Association to FeedbackToProcess;
    seqno: Integer;
    msgtyp: String(1);
    msgid: String(100);
    msgno: Integer;
    message: String;
    errorSource: String(100);
    msgCateg: String(1);      
    retryCount: Integer;
}

/**
 * IB to IDH data replication
 */
entity IbToIdhReplication: cuid, managed {
    product:  types.product;
    material: types.product;
    idhSbu: types.sbu;
    idhRcPreFlag: types.rcPreFlag;    
    idhRcPreFlagDescription: types.rcPreFlagDescription;
    assessmentID: UUID;
    processingStatus: types.feedbackProcessingStatus;
    errorMessage: String;
}

view ProductAssessmentList as 
    select from SingleAssessment
    {
        requestName,
        ID,
        null as headerId,
        virtualAssessment,
        product,
        sbu,
        assessor,
        submitter,
        submitionDate,
        approver,
        approvalDate,
        assesmentType,
        comment,
        rcPreFlag,
        rcPreFlagDescription,
        sustClass,
        category1,
        contributor1,
        category2,
        contributor2,
        category3,
        contributor3,
        approberComment,
        externalCommunication,
    }
    union all
    select from MassAssessmentItems as item
    inner join MassAssessmentHeader as header
    on item.headerId = header.ID
    {
        header.requestName,
        item.ID,
        item.headerId,
        item.virtualAssessment,
        item.product,
        item.sbu,
        item.assessor,
        item.submitter,
        header.submitionDate,      
        item.approver,
        item.approvalDate,
        header.assesmentType,
        item.comment,
        item.rcPreFlag,
        item.rcPreFlagDescription,
        item.sustClass,
        item.category1,
        item.contributor1,
        item.category2,
        item.contributor2,
        item.category3,
        item.contributor3,
        item.approberComment,
        item.externalCommunication,        
    };

@cds.persistence.exists
entity SingleAssessment : cuid, managed {
    requestName                         : types.requestName;
    sbu                                 : types.sbu;
    product                             : types.product;
    productType                         : types.productType;
    assessor                            : types.assessor;
    submitter                           : types.submitter;
    submitionDate                       : types.date;
    approver                            : types.approver;
    approvalDate                        : types.approvalDate;
    assesmentType                       : types.assesmentType;
    status                              : types.status;
    statusDescription                   : types.statusDescription;
    communicationStatus                 : types.communicationStatus;
    virtualAssessment                   : types.virtualAssessment;
    projectId                           : types.projectId;
    comment                             : types.comment;
    rcPreFlag                           : types.rcPreFlag;
    rcPreFlagDescription                : types.rcPreFlagDescription;
    sustClass                           : types.sustClass;
    category1                           : types.category;
    contributor1                        : types.contributor;
    category2                           : types.category;
    contributor2                        : types.contributor;
    category3                           : types.category;
    contributor3                        : types.contributor;
    approberComment                     : String(255);
    propagation                         : Boolean;
    externalCommunication               : Boolean;

    @Core.Computed: false
    virtual productName                 : String;

    @Core.Computed: false
    virtual technologyL2Key             : String;

    @Core.Computed: false
    virtual technologyLevel2            : String;

    @Core.Computed: false
    virtual sustainabilityClassCode     : String;

    @Core.Computed: false
    virtual existingSustainabilityClass : String;

    @Core.Computed: false
    virtual realSubstanceCode           : String(18);

    @Core.Computed: false
    virtual realSubstanceName           : String(40);

    @Core.Computed: false
    virtual region                      : String(3);

    @Core.Computed: false
    virtual applicationLevel2Key        : String(3);

    @Core.Computed: false
    virtual applicationLevel2           : String;

    @Core.Computed: false
    virtual lastAssessment              : String;

    @Core.Computed: false
    virtual lastSubmitter               : String;

    @Core.Computed: false
    virtual lastApprover                : String;
// toStatus                            : Association to one Status
//                                           on toStatus.code = status;
// toAssessmentType                    : Association to one AssessmentType
//                                           on toAssessmentType.code = assesmentType;
// toProofDocuments                    : Composition of many AssessmentProofDocument
//                                           on toProofDocuments.requestId = ID;
}

@cds.persistence.exists
entity MassAssessmentItems : cuid, managed {
    headerId                            : UUID;
    status                              : types.status;

    @Core.Computed: false
    virtual approbalStatus              : types.status;
    communicationStatus                 : types.communicationStatus;
    virtualAssessment                   : types.virtualAssessment;
    product                             : types.product;
    productType                         : types.productType;
    submitter                           : types.submitter;
    assessor                            : types.assessor;
    approver                            : types.approver;
    approvalDate                        : types.approvalDate;
    sbu                                 : types.sbu;
    comment                             : types.comment;
    rcPreFlag                           : types.rcPreFlag;
    rcPreFlagDescription                : types.rcPreFlagDescription;
    sustClass                           : types.sustClass;
    category1                           : types.category;
    contributor1                        : types.contributor;
    category2                           : types.category;
    contributor2                        : types.contributor;
    category3                           : types.category;
    contributor3                        : types.contributor;
    propagation                         : Boolean;
    externalCommunication               : Boolean;
    approberComment                     : String(255);

    @Core.Computed: false
    virtual productName                 : String;

    @Core.Computed: false
    virtual technologyL2Key             : String;

    @Core.Computed: false
    virtual technologyLevel2            : String;

    @Core.Computed: false
    virtual sustainabilityClassCode     : String;

    @Core.Computed: false
    virtual existingSustainabilityClass : String;

    @Core.Computed: false
    virtual realSubstanceCode           : String(18);

    @Core.Computed: false
    virtual realSubstanceName           : String(40);

    @Core.Computed: false
    virtual region                      : String(3);

    @Core.Computed: false
    virtual applicationLevel2Key        : String(3);

    @Core.Computed: false
    virtual applicationLevel2           : String;

    @Core.Computed: false
    virtual lastAssessment              : String;

    @Core.Computed: false
    virtual lastSubmitter               : String;

    @Core.Computed: false
    virtual lastApprover                : String;
// toProofDocuments                    : Composition of many AssessmentProofDocument
//                                           on toProofDocuments.requestId = ID;

// toStatus                            : Association to one Status
//                                           on toStatus.code = status;
};

@cds.persistence.exists
entity MassAssessmentHeader : cuid, managed {
        requestName       : types.requestName;
        sbu               : types.sbu;
        assessor          : types.assessor;
        productType       : types.productType;
        submitter         : types.submitter;
        submitionDate     : types.date;
        approver          : types.approver;
        approvalDate      : types.approvalDate;
        assesmentType     : types.assesmentType;
        status            : types.status;
        statusDescription : types.statusDescription;
        communicationStatus: types.communicationStatus;
        virtualAssessment : types.virtualAssessment;        
        projectId         : types.projectId;
        approberComment   : String(255);
        toItems           : Composition of many MassAssessmentItems
                                on toItems.headerId = ID;
    }

@cds.persistence.exists
entity AssessmentProofDocument : cuid, managed {
    requestId        : UUID;
    objectStoreId    : UUID;
    type             : String(2);
    description      : String;
    internalPath     : String;
    fileName         : String;

    @Core.MediaType  : mediaType
    content          : LargeBinary;

    @Core.IsMediaType: true
    mediaType        : String;
    url              : String;
    active           : Boolean;
    imageMasterID    : String;
    externalUrl      : Boolean;
    productReference : types.product;
}

@cds.persistence.exists
entity ProductProofDocumentRelation : managed {
    key product           : types.product;
    key proofPointId      : UUID;
        productType       : types.productType;
        type              : String(2);
        description       : String;
        fileName          : String;
        active            : Boolean;

        @Core.MediaType  : mediaType
        @Core.Computed   : false
        virtual content   : LargeBinary;

        @Core.IsMediaType: true
        @Core.Computed   : false
        virtual mediaType : String;

        url               : String;
        externalUrl       : Boolean;
}

@cds.persistence.exists
entity CommunicationErrorLog : cuid, managed {
    assessmentID : UUID;
    product      : types.product;
    system       : String(20);
    payload      : String;
    error        : LargeString;
}

@cds.persistence.exists
entity IBsToIDHPropagated {
    ibProduct: types.product;
    material: types.product;
    idhSbu: types.sbu;
    idhRcPreFlag: types.rcPreFlag;
    idhRcPreFlagDescription: types.rcPreFlagDescription;
}
