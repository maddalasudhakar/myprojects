const cds = require('@sap/cds');

const handlers = require("./handlers");

module.exports = async function (srv) {

    this.on("assessmentOnpremiseFeedback", handlers.actions.assessmentOnpremiseFeedback);
    this.on("assessmentRejectionFeedback", handlers.actions.assessmentRejectionFeedback);
    this.on("feedbackProcessing", handlers.actions.feedbackProcessing);
    this.on("processIBtoIDHReplication", handlers.actions.processIBtoIDHReplication);

      /***********************************************************
    *
    * Events
    *
    ************************************************************/
  srv.on("p03ProcessingProductError", handlers.events.p03ProcessingProductError);

};