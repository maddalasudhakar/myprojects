module.exports = async function () {
    // CAP auto-handles READ with full OData pushdown to HANA
};