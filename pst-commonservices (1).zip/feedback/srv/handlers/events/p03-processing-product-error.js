const cds = require('@sap/cds');
const { postNotificationOnP03ProcessingProdcutError } = require('../../src/notification-utils'); 

/**
 * Handles implementation of p03ProcessingProductError event
 * 
 * @param {cds.Request} req - Request received
 */
async function p03ProcessingProductError(req) {
    const { ID } = req.data;
    const result = await postNotificationOnP03ProcessingProdcutError({
        ID
    });
    return 'Notification sent';
};

module.exports = {
p03ProcessingProductError
}