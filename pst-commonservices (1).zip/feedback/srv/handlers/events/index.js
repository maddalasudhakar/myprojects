const {p03ProcessingProductError} = require("./p03-processing-product-error");

module.exports = {
    p03ProcessingProductError
};