const actions = require('./actions');
const events = require('./events');

module.exports = {
    actions,
    events
};