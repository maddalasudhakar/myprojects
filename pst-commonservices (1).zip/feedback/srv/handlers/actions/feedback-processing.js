const cds = require("@sap/cds");
const { 
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    ASSESSMENT_STATUS,
    ASSESSMENT_COMMUNICATION_STATUS,
    updateAssessmentCommunicationStatus,
    upsertMassAssessmentItemsDB,
    upsertSingleAssessmentDB,
    getItemsAssessmentProofDocumentsDB,
    getExistingObjectStoreIDs,
    removeObjectStoreDocument,
    s3,
    bucketName,    
    moveItemDocuments,
    setMassAssessmentHeaderStatus,
} = require("../../src/assessment-utils");
const { divideArrayInBatches, applyAsyncFunctionsToBatches } = require('../../src/batching-utils');
const { data } = require("@sap/cds/lib/dbs/cds-deploy");
const { FEEDBACK_STATUS, PROCESSING_STATUS } = require("../../src/feedback-utils");

const ENTITIES = {
    DB: {
        FEEDBACK_TO_PROCESS: "FeedbackToProcess",
        IB_TO_IDH_PROPAGATED:  "IBsToIDHPropagated",
        IB_TO_IDH_REPLICATION: "IbToIdhReplication",
    }
}
const PROMISES_PER_BATCH = 100;
const COMMUNICATION_RESPONSE = {
    ERROR: "ERROR",
    SUCCESS: "SUCCESS"
};

/**
 * Maximum number of entries to process from feedback table in a single job execution
 */
const MAX_FEEDBACK_PER_EXECUTION = 1000;

const MAX_ITEMS_TO_MOVE_DOCUMENTS = 1;

/**
 * Process provided feedback
 * @param {*} req 
 * @returns
 */
async function feedbackProcessing(req) {
    const LOGGER = cds.log("job");
    const {retry, rejected, assessmentIDs} = req.data;

    const aItems = assessmentIDs || await getItemsToProcess(retry, rejected);
    if (!aItems || aItems.length === 0) return "No items found";
    const sCase = retry
        ? rejected 
            ? "Retrial of rejected feedback found"
            : "Retrial of onpremise feedback found"
        : rejected
            ? "Rejected feedback found"
            : "Onpremise feedback found";
    LOGGER.log(sCase);
    console.time(sCase);

    const processItemsFunction = getProcessFeedbackFunction(rejected);
    const aBatchResults = await applyAsyncFunctionsToBatches(aItems, PROMISES_PER_BATCH, processItemsFunction, true);
    
    LOGGER.log(`Header IDs to update ${aBatchResults?.headerIds}`);
    req.on("done", async () =>{

        // Update of headers after commit
        const {feedbackData, headerIds} = aBatchResults
            .reduce((acc, curr) => {
                if (curr.status === "fulfilled") {
                    acc.feedbackData.push(...curr.value?.feedback);
                    acc.headerIds.push(...curr.value?.assessment.headers); 
                }
                return acc;
            }, {feedbackData: [], headerIds: []});

        if (headerIds && headerIds.length > 0){
            await cds.spawn({after: 10000}, async tx => {
                // Update headers at end
                let lastHeader;
                try {
                    LOGGER.log("Updating assessment header")
                    for (const headerId of headerIds) {
                        lastHeader = headerId;
                        const response = await setMassAssessmentHeaderStatus(headerId);
                        LOGGER.log("PST", response);
                    } 
                } catch (error) {
                    LOGGER.error("Error updating assessment header: ", error);
                    for (const item of feedbackData) {
                        await updateFeedback({ID: item.ID}, FEEDBACK_STATUS.FAILED, `Error updating assessment header ${lastHeader}: ${JSON.stringify(error.message)}`); // FEEDBACK id
                    }
                    const aIDs = feedbackData.map(item => item.assessmentID);
                    try{
                        await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
                    } catch (error) {
                        LOGGER.error(error)
                    }        
                        
                    return;
                }
            });
        }

    });
    console.timeEnd(sCase);
    return "Feedback processed";
};

/**
 * Get items to process from feedback table
 * 
 * @param {*} retry 
 * @param {*} rejected 
 * @returns 
 */
async function getItemsToProcess(retry, rejected) {
    const db = await cds.connect.to("db");
    const feedbackToProcess = db.entities[ENTITIES.DB.FEEDBACK_TO_PROCESS];

    const aItems = await db.run(SELECT.from(feedbackToProcess)
        .where({
            retrial: retry, 
            rejected: rejected, 
            feedbackProcessingStatus: [FEEDBACK_STATUS.PENDING, FEEDBACK_STATUS.FAILED]
        })
        .orderBy('modifiedAt')
        .limit(MAX_FEEDBACK_PER_EXECUTION)
    );
    return aItems;
};

/**
 * Build feedback processing fuction depending on provided case
 * 
 * @param {*} reject 
 * @returns 
 */
function getProcessFeedbackFunction(rejected) {
    
    if (rejected)   return getRejectedProcessFeedbackFunction();
    else            return getApprovedProcessFeedbackFunction();

};

/**
 * Build feedback processing fuction for rejection case
 * 
 * @returns 
 */
function getRejectedProcessFeedbackFunction() {
    
    /**
     * Function to proccess rejected feedback items
     * 
     * @param {Array} data feedback data that is going to be processed
     * @returns 
     */
    const feedbackFunction = async (data) => {
        const bIsRetrial = data[0]?.retrial;
        const sLogTag = bIsRetrial ? "reject-retrial" : "reject";
        const LOGGER = cds.log(sLogTag);

        LOGGER.log("Start rejected feedback processing");
        LOGGER.log("Getting DB assessments...");
        const aMassAssessmentItemsDB = await getMassAssessmentItemsDB(data.map(item => item.assessmentID));
        const aSingleAssessmentsDB = await getSingleAssessmentDB(data.map(item => item.assessmentID));
        LOGGER.log("DB assessments retrieved");

        // Retrieve all different headers
        const aHeaderIds = aMassAssessmentItemsDB.reduce((acc, curr) => {
            const bNewHeader = !acc.some(header => header === curr.headerId);
            if (bNewHeader) {
                acc.push(curr.headerId);
            }
            return acc;
        }, []);

        // Mege all assessments
        const aItemsDB = [
            ...aMassAssessmentItemsDB.map(item => ({...item, single: false})), 
            ...aSingleAssessmentsDB.map(item => ({...item, single: true}))
        ];

        const aItemIDs = aItemsDB.map(item => item.ID);

        // Move files from objectstore to imagemaster
        LOGGER.log("Starting document moving....");
        const oResult =  {success: [], error: []};
        try {
            const aProofDocumentsDB = await getItemsAssessmentProofDocumentsDB(aItemIDs);    
            LOGGER.log("Documents retrieved");

            const aProofDocumentsCopy = aProofDocumentsDB.map(document => ({...document}));

            // Divide items in batches
            const aBatches = divideArrayInBatches(aItemsDB, MAX_ITEMS_TO_MOVE_DOCUMENTS);

            // Create promises for moving documents in each batch and await them
            LOGGER.log("Moving documents...");
            for (batch of aBatches) {
                const aPromises = batch.map(item => {
                    const aItemProofDocuments = aProofDocumentsDB.filter(document => document.requestId === item.ID);
                    return moveItemDocuments(item, aItemProofDocuments);                
                });
                // const result = await Promise.allSettled(aPromises);
                const aSettledResults = await Promise.allSettled(aPromises);
                for (const aSettledResult of aSettledResults) {
                    if (aSettledResult.status === "fulfilled")   oResult.success.push(aSettledResult.value);
                    else                                         oResult.error.push(aSettledResult.reason);
                    
                }

                // if (result.some(promise => promise.status === "rejected")) {
                //     const oRejectedPromise = result.find(promise => promise.status === "rejected");
                //     throw new Error(oRejectedPromise.reason);
                // };
            }

            // Only successful item documents are checked to be deleted
            const aProofDocumentsToDelete = aProofDocumentsCopy
                .filter(document => {
                    const bIsCorrespondingItemSuccessful = oResult.success.some(item => item.ID === document.requestId);
                    return bIsCorrespondingItemSuccessful && document.objectStoreId;
                });

            // Retreive still existing objectstore IDs, those can not be deleted yet
            const aObjectStoreIDs = aProofDocumentsToDelete.map(document => document.objectStoreId);
            const aObjectStoreIDsInDB = await getExistingObjectStoreIDs(aObjectStoreIDs);

            for (const oDocument of aProofDocumentsToDelete) {
                const bHasItemsPendingProcessing = aObjectStoreIDsInDB.some(item => item.objectStoreId === oDocument.objectStoreId);
                if (!oDocument.imageMasterID && !bHasItemsPendingProcessing) {
                    try {
                        OBJECT = cds.log("OBJECSTORE");
                        OBJECT.log(JSON.stringify(oDocument));
                        await removeObjectStoreDocument(bucketName, s3, oDocument);
                    } catch (e) {
                        LOGGER.error("Error deleting object store documents:", e);        
                    }
                }
            }                 

            LOGGER.log("Moving of documents ended");

        } catch (e) {

            // Error management, set status to retry and update communication status
            LOGGER.error("Error moving documents: ", e);
            for (const item of data) {
                await updateFeedback({ID: item.ID}, FEEDBACK_STATUS.FAILED, "Error moving documents"); // Feedback ID
            }

            const aIDs = aItemsDB.map(item => item.ID);
            try{
                await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
            } catch (error) {
                console.error(error)
            }        
                 
            throw new Error(`Error moving documents: ${e}`);
        }
 
        LOGGER.log("Updating feedback table...")

        // Success handling
        for (const item of oResult.success) {
            await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FINISHED); 
        }            
        const aIDs = aItemsDB.map(item => item.ID);
        try{
            await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.COMPLETED);
        } catch (error) {
            LOGGER.error(error)
        }        

        // Error handling
        const aErrors = data.filter(item => (!oResult.success.some(successItem => successItem.ID === item.assessmentID)));
        for (const item of aErrors) {
            await updateFeedback({ID: item.ID}, FEEDBACK_STATUS.FAILED, "Error moving documents"); // assessment ID
        }

        try{
            const aItemIDs = aErrors.map(item => item.ID);
            await updateAssessmentCommunicationStatus(aItemIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        } catch (error) {
            LOGGER.error(error);
        }  

        LOGGER.log("Updating ended");

        // // Update headers at end
        // try {
        //     LOGGER.log("Updating assessment header")
        //     for (const headerId of aHeaderIds) {
        //         const response = await setMassAssessmentHeaderStatus(headerId);
        //         // console.log(response);
        //     } 
        // } catch (error) {
        //     LOGGER.error("Error updating assessment header: ", error);
        //     for (const item of data) {
        //         await updateFeedback({ID: item.ID}, FEEDBACK_STATUS.FAILED, "Error updating assessment header"); // FEEDBACK id
        //     }
        //     const aIDs = aItemsDB.map(item => item.ID);
        //     try{
        //         await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        //     } catch (error) {
        //         LOGGER.error(error)
        //     }        
                 
        //     return;
        // }  

        return {feedback: data, assessment: {headers: aHeaderIds}};
    };
    return feedbackFunction;

}

/**
 * Build feedback processing fuction for approval case
 * 
 * @returns 
 */
function getApprovedProcessFeedbackFunction() {

    /**
     * Function to handle approved product assessments feedback
     * 
     * @param {*} data feedback table data to processs
     * @returns 
     */
    const feedbackFunction = async (data) => {
        const bIsRetrial = data[0]?.retrial;
        const sLogTag = bIsRetrial ? "approve-retrial" : "approve";
        const LOGGER = cds.log(sLogTag);

        LOGGER.log("Start approved feedback processing");
        LOGGER.log("Getting DB assessments...");
        const aMassAssessmentItemsDB = await getMassAssessmentItemsDB(data.map(item => item.assessmentID));
        const aSingleAssessmentsDB = await getSingleAssessmentDB(data.map(item => item.assessmentID));
        LOGGER.log("DB assessments retrieved");

        // Retrieve all different headers
        const aHeaderIds = aMassAssessmentItemsDB.reduce((acc, curr) => {
            const bNewHeader = !acc.some(header => header === curr.headerId);
            if (bNewHeader) {
                acc.push(curr.headerId);
            }
            return acc;
        }, []);

        // Mege all assessments
        const aItemsDB = [
            ...aMassAssessmentItemsDB.map(item => ({...item, single: false})), 
            ...aSingleAssessmentsDB.map(item => ({...item, single: true}))
        ];

        // Separate depeding on received feedback
        const oItemsToUpdate = data.reduce((acc, curr) => {
            const oItemDB = aItemsDB.find(itemDB => itemDB.ID === curr.assessmentID);
            if (!oItemDB) {
                acc.omit.push({ID: curr.ID, status: FEEDBACK_STATUS.FINISHED, reason: `Product ${curr.product} is not pending response in database`});
                return acc;
            }
    
            if (curr.communicationResponse === COMMUNICATION_RESPONSE.ERROR) {
                acc.error.push(oItemDB);  
            } else {
                acc.success.push(oItemDB);  
            }         
            return acc;
        }, {success: [], error: [], omit: []});

        // Main processsing
        const aPromises = [
            successItemsProcessing(oItemsToUpdate.success, bIsRetrial),
            errorItemsProcessing(oItemsToUpdate.error, bIsRetrial),
        ]
        const results = await Promise.allSettled(aPromises);
        
        LOGGER.log("Updating feedback table...")

        if (results[0].status === 'fulfilled' && results[0].value.success?.length > 0) {
            for (const item of results[0].value.success) {
                await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FINISHED); // AssessmentID
            }      
        }      
        LOGGER.log("Updating ended");

        // // Update headers at end
        // try {
        //     LOGGER.log("Updating assessment header")
        //     for (const headerId of aHeaderIds) {
        //         await setMassAssessmentHeaderStatus(headerId);
        //     } 
        // } catch (error) {
        //     LOGGER.error("Error updating assessment header: ", error);
        //     for (const item of data) {
        //         await updateFeedback({ID: item.ID}, FEEDBACK_STATUS.FAILED, "Error updating assessment header"); // feedback ID
        //     }
        //     const aIDs = aItemsDB.map(item => item.ID);
        //     try{
        //         await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        //     } catch (error) {
        //         LOGGER.error(error)
        //     }        
                 
        //     return;
        // }           

        // If any item was omitted, indicate error at end
        try {
            for (const ommited of oItemsToUpdate.omit)      await updateFeedback({ID: ommited.ID}, FEEDBACK_STATUS.FINISHED, ommited.reason);
        } catch (error) {
            LOGGER.error(error);
        }

        return {feedback: data, assessment: {headers: aHeaderIds}};        
    };
    return feedbackFunction;

};


/**
 * Handling of items with error feedback
 * 
 * @param {*} req 
 * @param {*} items 
 */
async function errorItemsProcessing(items, retrial) {
    if (!items || items.length === 0) return;

    // Update database status for mass assessment items and single assessments
    const aMassAssessmentItemsToUpdate = items.filter(
        item => !item.single
    ).map(item => {
        const oReturn = {...item, status: ASSESSMENT_STATUS.APPROVED, communicationStatus: ASSESSMENT_COMMUNICATION_STATUS.PENDING_CPI_RETRY};
        delete oReturn.single, oReturn.modifiedAt, oReturn.modifiedBy;
        return oReturn; 
    });

    const aSingleAssessmentsToUpdate = items.filter(
        item => item.single
    ).map(item => {
        const oReturn = {...item, status: ASSESSMENT_STATUS.APPROVED, communicationStatus: ASSESSMENT_COMMUNICATION_STATUS.PENDING_CPI_RETRY};
        delete oReturn.single, oReturn.modifiedAt, oReturn.modifiedBy;
        return oReturn; 
    });

    try {
        if (aMassAssessmentItemsToUpdate && aMassAssessmentItemsToUpdate.length > 0) {
            await upsertMassAssessmentItemsDB(aMassAssessmentItemsToUpdate);
        }
        if (aSingleAssessmentsToUpdate && aSingleAssessmentsToUpdate.length > 0) {
            await upsertSingleAssessmentDB(aSingleAssessmentsToUpdate);
        }           

        for (const item of items) {
            await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FINISHED);
        }
    } catch (e){
        console.error(e);
        for (const item of items) {
            await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FAILED, "Error updating assessment status"); // assessment ID
        }

        const aIDs = items.map(item => item.ID);
        try{
            await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        } catch (error) {
            console.error(error);
        }         
        return;
    };

};

/**
 * Handling of items with successful feedback
 * 
 * @param {*} req 
 * @param {*} items assessment in DB
 * @returns 
 */
async function successItemsProcessing(items, retrial) {

    const sLogTag = retrial ? "approve-retrial-success" : "approve-success";
    const LOGGER = cds.log(sLogTag);

    if (!items || items.length === 0) return [];
    
    const oResult =  {success: [], error: []};
    try {
        LOGGER.log("Starting document moving....");
        const aItemIDs = items.map(item => item.ID);

        // Move files from objectstore to imagemaster
        const aProofDocumentsDB = await getItemsAssessmentProofDocumentsDB(aItemIDs);    
        LOGGER.log("Documents retrieved");

        const aProofDocumentsCopy = aProofDocumentsDB.map(document => ({...document}));

        // Divide items in batches
        const aBatches = divideArrayInBatches(items, MAX_ITEMS_TO_MOVE_DOCUMENTS);//PROMISES_PER_BATCH);

        // Create promises for moving documents in each batch and await them
        LOGGER.log("Moving documents...");
        for (batch of aBatches) {
            const aPromises = batch.map(item => {
                const aItemProofDocuments = aProofDocumentsDB.filter(document => document.requestId === item.ID);
                return moveItemDocuments(item, aItemProofDocuments);                
            })
            
            const aSettledResults = await Promise.allSettled(aPromises);
            for (const aSettledResult of aSettledResults) {
                if (aSettledResult.status === "fulfilled")   oResult.success.push(aSettledResult.value);
                else                                         oResult.error.push(aSettledResult.reason);
                
            }

        }

        // Only successful item documents are checked to be deleted
        const aProofDocumentsToDelete = aProofDocumentsCopy
            .filter(document => {
                const bIsCorrespondingItemSuccessful = oResult.success.some(item => item.ID === document.requestId);
                return bIsCorrespondingItemSuccessful && document.objectStoreId;
            });

        // Retreive still existing objectstore IDs, those can not be deleted yet
        const aObjectStoreIDs = aProofDocumentsToDelete.map(document => document.objectStoreId);
        const aObjectStoreIDsInDB = await getExistingObjectStoreIDs(aObjectStoreIDs);

        for (const oDocument of aProofDocumentsToDelete) {
            const bHasItemsPendingProcessing = aObjectStoreIDsInDB.some(item => item.objectStoreId === oDocument.objectStoreId);
            if (!oDocument.imageMasterID && !bHasItemsPendingProcessing) {
                try {
                    OBJECT = cds.log("OBJECSTORE");
                    OBJECT.log(JSON.stringify(oDocument));
                    await removeObjectStoreDocument(bucketName, s3, oDocument);
                } catch (e) {
                    LOGGER.error("Error deleting object store documents:", e);        
                }
            }
        }           
        LOGGER.log("Moving of documents ended");
    } catch (e) {
        LOGGER.error("Error moving documents: ", e);
        for (const item of items) {
            await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FAILED, "Error moving documents"); // assessment ID
        }

        try{
            const aItemIDs = items.map(item => item.ID);
            await updateAssessmentCommunicationStatus(aItemIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        } catch (error) {
            LOGGER.error(error);
        }   

        throw new Error(`Error moving documents: ${e}`);
    }
    await IDHOverwriteFlow(oResult.success);


    // When finished, update item status
    try{
        const aIDs = oResult.success.map(item => item.ID);
        await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.COMPLETED);

        const aErrors = items.filter(item => (!oResult.success.some(successItem => successItem.ID === item.ID)));
        for (const item of aErrors) {
            await updateFeedback({assessmentID: item.ID}, FEEDBACK_STATUS.FAILED, "Error moving documents"); // assessment ID
        }

        try{
            const aItemIDs = aErrors.map(item => item.ID);
            await updateAssessmentCommunicationStatus(aItemIDs, ASSESSMENT_COMMUNICATION_STATUS.RETRYING);
        } catch (error) {
            LOGGER.error(error);
        }   


    } catch (error) {
        LOGGER.error(error);
    }
    return oResult;
};

/**
 * Update of feedback table for success and error
 * 
 * @param {*} condition of update 
 * @param {*} reason 
 */
async function updateFeedback(condition, status, reason) {
    const db = await cds.connect.to("db");
    const FeedbackToProcess = db.entities[ENTITIES.DB.FEEDBACK_TO_PROCESS];
    await db.tx(async tx => {
        const oSet = {
            feedbackProcessingStatus: status, 
            // feedbackErrorMessage: reason,
        };
        if (reason) {
            oSet.feedbackErrorMessage = reason;
        }        
        if (status === FEEDBACK_STATUS.FAILED) {
            oSet.retrial = true;
        }

        await tx.run(UPDATE(FeedbackToProcess)
            .set(oSet)
            .where(condition));
    });
};

function removeHyphensFromUUID(sUUID) {
    return sUUID.replace(/-/g, '');
};

/**
 * IDH replication flow when manual maintenace flag unchecked
 * 
 * @param {*} items 
 */
async function IDHOverwriteFlow(items) {

    const aIbs = items.filter(item => item.productType === "IB").map(item => item.product);
    if (!aIbs || aIbs?.length === 0) return;

    const db = await cds.connect.to("db");
    const IBsToIDHPropagated = db.entities[ENTITIES.DB.IB_TO_IDH_PROPAGATED];
    
    const aIdhs = await db.run(
        SELECT.from(IBsToIDHPropagated).where({ibProduct: aIbs})
    );

    if (!aIdhs || aIdhs?.length === 0) return;
    const aData = aIdhs.map(ibToIdh => {
        const oAssessment = items.find(item => item.product === ibToIdh.ibProduct);
        const oReturn = {
            material: ibToIdh.material,
            idhSbu: ibToIdh.idhSbu,
            idhRcPreFlag: ibToIdh.idhRcPreFlag,  
            idhRcPreFlagDescription: ibToIdh.idhRcPreFlagDescription,
            product: ibToIdh.ibProduct,
            assessmentID: oAssessment.ID,
            processingStatus: PROCESSING_STATUS.PENDING,
        };
        return oReturn;
    });

    const IbToIdhReplication = db.entities[ENTITIES.DB.IB_TO_IDH_REPLICATION];
    await INSERT.into(IbToIdhReplication).entries(aData);
};

module.exports = {
    feedbackProcessing,
}

