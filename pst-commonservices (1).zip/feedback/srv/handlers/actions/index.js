const {assessmentOnpremiseFeedback} = require("./assessment-onpremise-feedback");
const {assessmentRejectionFeedback} = require("./assessment-rejection-feedback");
const {feedbackProcessing} = require("./feedback-processing")
const {processIBtoIDHReplication} = require("./process-ib-to-idh-replication"); 

module.exports = {
    assessmentOnpremiseFeedback,
    assessmentRejectionFeedback,
    feedbackProcessing,
    processIBtoIDHReplication,
};