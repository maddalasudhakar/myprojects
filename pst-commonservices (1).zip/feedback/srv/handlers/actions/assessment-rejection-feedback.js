const cds = require("@sap/cds");
const { 
    ASSESSMENT_COMMUNICATION_STATUS,
    updateAssessmentCommunicationStatus,
} = require("../../src/assessment-utils");
const { divideArrayInBatches } = require('../../src/batching-utils');
const { FEEDBACK_STATUS } = require("../../src/feedback-utils");

/**
 * Maximum number of concurrrent promises to be done when resolving in batches
 */
const PROMISES_PER_BATCH = 50;

const MAX_DB_BATCH = 1000;

/**
 * Handler for rejection of assessments
 * 
 * @param {*} req 
 */
async function assessmentRejectionFeedback(req) {
    const LOGGER = cds.log("incoming-rejection");
    LOGGER.log("New feedback. Req time:", cds.context.timestamp);
    console.time("Processing time");
    const aFeedback = req.data.items.map(item => {
        return {
            assessmentID: item.assessmentID,
            product: item.product,
            communicationResponse: item.error? "ERROR" : "SUCCESS",
            retrial: false,
            rejected: true,
            communicationResponseMessage: item.message,
            feedbackProcessingStatus: FEEDBACK_STATUS.PENDING
        };
    });
    
    const aBatches = divideArrayInBatches(aFeedback, MAX_DB_BATCH);
    const db = await cds.connect.to("db");
    const {FeedbackToProcess} = db.entities;
    for (const batch of aBatches) {
        const result = await INSERT.into(FeedbackToProcess).entries(batch);
        const aIDs = batch.map(item => item.assessmentID);
        try{
            await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.FEEDBACK_RECEIVED);
        } catch (error) {
            console.error(error)
        }        
    }    
    console.timeEnd("Processing time");
    return "Feedback saved";
    
};

module.exports = {
    assessmentRejectionFeedback,
}   