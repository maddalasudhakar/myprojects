const cds = require("@sap/cds");
const {
    getMassAssessmentItemsToOnpremiseByProduct,
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    getSingleAssessmentToOnpremiseByProduct,
    ASSESSMENT_STATUS,
    ASSESSMENT_COMMUNICATION_STATUS,
    upsertMassAssessmentItemsDB,
    upsertSingleAssessmentDB,
    getItemsAssessmentProofDocumentsDB,
    setMassAssessmentHeaderStatus,
    moveItemDocuments,
} = require("../../src/assessment-utils");
const { divideArrayInBatches, applyAsyncFunctionsToBatches } = require('../../src/batching-utils');
const { SELECT } = require("@sap/cds/lib/ql/cds-ql");
const ENTITIES = {
    DB: {
        FEEDBACK_TO_PROCESS: "FeedbackToProcess",
        IB_TO_IDH_PROPAGATED: "IBsToIDHPropagated",
        IB_TO_IDH_REPLICATION: "IbToIdhReplication",
        PRODUCT_ASSESSMENT_LIST: "ProductAssessmentList"
    }
};
const PROCESSING_STATUS = {
    PENDING: "01",
    ERROR: "02",
    COMPLETED: "03",
}
const MAX_ITEMS_PER_BATCH = 100;

/**
 * Logic to replicate IB to IDH
 * 
 * @param {*} req 
 */
async function processIBtoIDHReplication(req) {

    // Recover IBs to be sent
    const db = await cds.connect.to("db");
    const IbToIdhReplication = db.entities[ENTITIES.DB.IB_TO_IDH_REPLICATION];
    const productAssessmentList = db.entities[ENTITIES.DB.PRODUCT_ASSESSMENT_LIST];
    const aIbsToReplicate = await SELECT
        .from(IbToIdhReplication)
        .where({
            processingStatus: [PROCESSING_STATUS.PENDING, PROCESSING_STATUS.ERROR]
        });

    // Sending will be done in batches
    const aBatches = divideArrayInBatches(aIbsToReplicate, MAX_ITEMS_PER_BATCH);
    for (batch of aBatches) {

        try {
            // Prepare assessment data from DB
            const aAssessmentsDB = await db.run(
                SELECT.from(productAssessmentList)
                    .where({
                        ID: batch.map(item => item.assessmentID)
                    })
            );

            const aBody = batch.flatMap(item => {
                const { material, idhSbu, idhRcPreFlag, idhRcPreFlagDescription } = item;
                const oAssessment = aAssessmentsDB.find(assessment => assessment.ID === item.assessmentID)
                if (!oAssessment) {
                    return [];
                }
                return {
                    material,
                    idhSbu,
                    idhRcPreFlag,
                    idhRcPreFlagDescription,
                    assessment: {
                        requestName: oAssessment.requestName,
                        ID: oAssessment.ID,
                        headerId: oAssessment.headerId,
                        virtualAssessment : oAssessment.virtualAssessment,
                        product: oAssessment.product,
                        sbu: oAssessment.sbu,
                        assessor: oAssessment.assessor,
                        submitter: oAssessment.submitter,
                        submitionDate: oAssessment.submitionDate,
                        approver: oAssessment.approver,
                        approvalDate: oAssessment.approvalDate,
                        assesmentType: oAssessment.assessmentType,
                        comment: oAssessment.comment,
                        rcPreFlag: oAssessment.rcPreFlag,
                        rcPreFlagDescription: oAssessment.rcPreFlagDescription,
                        sustClass: oAssessment.sustClass,
                        category1: oAssessment.category1,
                        contributor1: oAssessment.contributor1,
                        category2: oAssessment.category2,
                        contributor2: oAssessment.contributor2,
                        category3: oAssessment.category3,
                        contributor3: oAssessment.contributor3,
                        approberComment: oAssessment.approberComment,
                        externalCommunication: oAssessment.externalCommunication,
                    }
                };

            });

            // Execute propagation
            const SustainabilityService = await cds.connect.to("SustainabilityService");
            const results = await SustainabilityService.send({
                method: "POST",
                path: "/odata/v4/sustainability/management/IdhOverwrite",
                data: {
                    products: aBody
                }
            });

            // Separate successful propagation from errors
            const oUpdateItems = batch.map(item => {

                const result = results?.find(result => {
                    const bIsEqual = (
                        result.assessmentID === item.assessmentID &&
                        result.product === item.product &&
                        result.material === item.material
                    );
                    return bIsEqual;
                });

                if (result) {
                    return {
                        error: true,
                        entry: {
                            ID: item.ID,
                            errorMessage: result?.message,
                            material: result?.material,
                            product: result?.product,
                            assessmentID: result?.assessmentID
                        }
                    };
                }

                return { error: false, ID: item.ID };

            }).reduce((acc, curr) => {
                curr?.error
                    ? acc.error.push(curr.entry)
                    : acc.success.push(curr.ID);
                return acc;
            }, { success: [], error: [] });

            // Updating of processing table depending on results
            await cds.tx(async tx => {

                const db = await cds.connect.to("db");
                const IbToIdhReplication = db.entities[ENTITIES.DB.IB_TO_IDH_REPLICATION];
                await cds.run(async tx => {

                    // Update of successful items as completed
                    if (oUpdateItems.success.length > 0) {
                        await UPDATE(IbToIdhReplication)
                            .set({ processingStatus: PROCESSING_STATUS.COMPLETED })
                            .where({ ID: oUpdateItems.success });
                    }

                    // Update error ones
                    if (oUpdateItems.error.length > 0) {

                        const aUpsertErrors = oUpdateItems.error.map(item => {
                            return {
                                ID: item.ID,
                                errorMessage: item.errorMessage,
                                processingStatus: PROCESSING_STATUS.ERROR,
                            }
                        });

                        await UPSERT(aUpsertErrors).into(IbToIdhReplication);

                    }

                });

            });

        } catch (error) {
            const sErrorMessage = (typeof error === "object") ? JSON.stringify(error) : error;
            await cds.tx(async tx => {
                const db = await cds.connect.to("db");
                const IbToIdhReplication = db.entities[ENTITIES.DB.IB_TO_IDH_REPLICATION];
                await cds.run(
                    UPDATE(IbToIdhReplication)
                        .set({ processingStatus: PROCESSING_STATUS.ERROR, errorMessage: sErrorMessage })
                        .where({ ID: batch.map(item => item.ID) })
                );
            });
        }

    }

};

module.exports = {
    processIBtoIDHReplication,
}