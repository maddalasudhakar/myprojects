const cds = require("@sap/cds");
const {
    ASSESSMENT_COMMUNICATION_STATUS,
    updateAssessmentCommunicationStatus,
} = require("../../src/assessment-utils");
const { divideArrayInBatches } = require('../../src/batching-utils');

const { FEEDBACK_STATUS } = require("../../src/feedback-utils");
/**
 * Maximum number of concurrrent promises to be done when resolving in batches
 */
const PROMISES_PER_BATCH = 50;

/**
 * Maximum number of elements to be used in an array
 */
const MAX_DB_BATCH = 1000;

/**
 * Communication response types
 */
const COMMUNICATION_RESPONSE = {
    ERROR: "ERROR",
    SUCCESS: "SUCCESS",
};

/**
 * Possible message categories to arrive in feedback
 */
const MESSAGE_CATEGORY = {
    DATA: "V",
    PROCESSING: "U"
}

/**
 * CPI user feedback identifier 
 */
const CPI_USER = 'CPISYSTEM';

/**
 * Handler for feedback response from mass assessment sendiong to on premise system
 * 
 * @param {*} req 
 */
async function assessmentOnpremiseFeedback (req) {

    const aFeedback = mapInputData(req);

    const aBatches = divideArrayInBatches(aFeedback, MAX_DB_BATCH);
    const db = await cds.connect.to("db");
    const {FeedbackToProcess} = db.entities;
    for (const batch of aBatches) {
        const result = await INSERT.into(FeedbackToProcess).entries(batch);
        const aIDs = batch.map(item => item.assessmentID);
        try{
            await updateAssessmentCommunicationStatus(aIDs, ASSESSMENT_COMMUNICATION_STATUS.FEEDBACK_RECEIVED);
        } catch (error) {
            console.error(error)
        }
        console.log(result)
    }
    return "Feedback saved";
};

/**
 * Map input data to datbase table fields
 * 
 * @param {object} req request object
 * @returns Array of mapped data
 */
function mapInputData(req) {

    const { data } = req;
    const { items } = data;
    const aFeedbackToProcess = items.map(item => {
        const material = item.speedStatus?.material;
        const product = item.speedStatus?.ibProd;

        const communicationResponse = item.speedStatus?.status === "E"
            ? COMMUNICATION_RESPONSE.ERROR
            : COMMUNICATION_RESPONSE.SUCCESS;

        const aCommunicationResponseMessages = item?.speedMsgs?.map( item => {
            return {
                createdBy: item.creBy,
                seqno: item.seqno,
                msgtyp: item.msgtyp,
                msgid: item.msgid,
                msgno: item.msgno,
                message: item.message,
                errorSource: item.errorSource,
                msgCateg: item.msgCateg,
                retryCount: item.retryCount,
            }
        });

        const feedbackProcessingStatus = getFeedbackStatus(item);

        const oReturn = {
            createdBy                    : item.speedStatus.creBy,
            assessmentID                 : item.speedStatus.speedReqId,
            product                      : material || product,
            communicationResponse        : communicationResponse,
            communicationResponseMessages: aCommunicationResponseMessages,
            retrial                      : false,
            rejected                     : false,
            // rejectedAssessment           : false,
            feedbackProcessingStatus     : feedbackProcessingStatus,
            feedbackErrorMessage         : "",    
            sourcePayload                : ""//data,
        };
        return oReturn;
    });

    return aFeedbackToProcess;

};

/**
 * Determines in which status in going to be stored the feedback message
 * 
 * @param {object} item Element of message array arriving
 * @returns {string} Feedback processing status to set
 */
function getFeedbackStatus(item) {

    // Onpremise data errors are stored as finished in wait of fixing in onpremise system and manual retry
    const isOnPremiseError = item.speedStatus?.creBy !== CPI_USER;
    const isDataError = item.speedStatus?.status === "E" && item.speedMsgs?.some(message => message?.msgCateg === MESSAGE_CATEGORY.PROCESSING);
    if (isOnPremiseError && isDataError) {
        cds.tx(async () => {
            try {
                //await sleep (3000);
                const feedbackService = await cds.connect.to('FeedbackService');
                const ID = item.speedStatus.speedReqId;

                // links each status to an event name and its specific payload
                const eventMap = {
                    'U': { event: 'p03ProcessingProductError', payload: { ID } }
                };

                const config = eventMap[MESSAGE_CATEGORY.PROCESSING];

                if (config) {
                    const result = feedbackService.emit(config.event, { ...config.payload });
                    console.log(result);
                }

            } catch (error) {
                console.error(error);
            }
        });
        return FEEDBACK_STATUS.FINISHED;
    }

    // In any other case, defauilt status is pending
    return FEEDBACK_STATUS.PENDING;
}

module.exports = {
    assessmentOnpremiseFeedback,
}   