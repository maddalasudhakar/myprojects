const cds = require("@sap/cds");
const { divideArrayInBatches } = require('./batching-utils');
const { createImageMasterDocument } = require("./imagemaster-utils");
const { initializeS3Client, getBucketName} = require('./s3-client');
const { PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');

// Initialize the S3 client
const s3 = initializeS3Client();
const bucketName = getBucketName();

/**
 * Maximum items used at same time to query database
 */
const MAX_PACKAGE_SIZE_DB = 1000;

/**
 * Entities to be referred
 */
const ENTITIES = {
    DB: {
        MASS_ASSESSMENT_ITEMS: "MassAssessmentItems",
        SINGLE_ASSESSMENT: "SingleAssessment",
        ASSESSMENT_PROOF_DOCUMENT: "AssessmentProofDocument",
        COMMUNICATION_ERROR_LOG: "CommunicationErrorLog",
        PRODUCT_PROOF_DOCUMENT_RELATION: "ProductProofDocumentRelation",
    }
};

/**
 * Possible status of an assessment
 */
const ASSESSMENT_STATUS = {
    SAVED: "01",
    SUBMITTED: "02",
    UNDER_RESUBMISSION: "03",
    RESUBMITTED: "04",
    APPROVED: "05",
    REJECTED: "06",
    DRAFT: "91",
    // PENDING_ONPREMISE: "96",
    FINALIZED: "08",
};

/**
 * Possible communication status of an assessment
 */
const ASSESSMENT_COMMUNICATION_STATUS = {
    PENDING: "01",
    PENDING_CPI_RETRY: "11",
    SENDED_CPI: "02",
    FEEDBACK_RECEIVED: "03",
    RETRYING: "04",
    COMPLETED: "05",
};

/**
 * Retrieves database MassAssessmentItems data from a list of MassAssessmentItems IDs
 * 
 * @param {*} aItems 
 * @returns 
 */
async function getMassAssessmentItemsToOnpremiseByProduct(aProducts) {

    if (!aProducts || aProducts.length === 0) return [];

    const aBatches = divideArrayInBatches(aProducts, MAX_PACKAGE_SIZE_DB);

    const db = await cds.connect.to("db");
    const aResults = [];        
    for (const batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT.from(ENTITIES.DB.MASS_ASSESSMENT_ITEMS)
                .where({
                    product: batch, 
                    status: ASSESSMENT_STATUS.PENDING_ONPREMISE
                })
        );
        aResults.push(...aBatchResults);
    }
    return aResultsaResults;

};

/**
 * Use an array of MassAssessmentItems to UPSERT databse entities
 * @param {*} aItems 
 */
async function upsertMassAssessmentItemsDB(aItems) {
    if (!aItems || aItems.length === 0) return [];
    const db = await cds.connect.to("db");
    const aBatches = divideArrayInBatches(aItems, MAX_PACKAGE_SIZE_DB);
    for (const batch of aBatches) {
        const results = await db.run(UPSERT(batch).into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS));
    }
};

/**
 * Use an array of SingleAssessment to UPSERT databse entities
 * @param {*} aItems 
 */
async function upsertSingleAssessmentDB(aItems) {
    if (!aItems || aItems.length === 0) return [];
    const db = await cds.connect.to("db");
    const aBatches = divideArrayInBatches(aItems, MAX_PACKAGE_SIZE_DB);
    for (const batch of aBatches) {
        const results = await db.run(UPSERT(batch).into(ENTITIES.DB.SINGLE_ASSESSMENT));
    }
};

/**
 * Retrieves database assessment proof documents by item ID
 * 
 * @param {*} aItems 
 * @returns 
 */
async function getItemsAssessmentProofDocumentsDB(aItems) {

    if (!aItems || aItems.length === 0) return [];

    const aBatches = divideArrayInBatches(aItems, MAX_PACKAGE_SIZE_DB);

    const db = await cds.connect.to("db");
    const aResults = [];        
    for (const batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT.from(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).where({requestId: batch}));
        aResults.push(...aBatchResults);
    }
    return aResults;

};

/**
 * Generic error logging table
 * 
 * @param {*} assessmentID 
 * @param {*} product 
 * @param {*} system 
 * @param {*} payload 
 * @param {*} error 
 */
async function setCommunicationErrorLog(assessmentID, product, system, payload, error) {

    await cds.tx(async (tx) => {
        const oDb = await cds.connect.to("db");
        const oNewEntry = {
            assessmentID: assessmentID,
            product : product,
            system: system,
            payload: JSON.stringify(payload),
            error : JSON.stringify(error),            
        };
        await oDb.run(INSERT.into(ENTITIES.DB.COMMUNICATION_ERROR_LOG).entries(oNewEntry));
    });

};

/**
 * Update image master reference in assessment
 * 
 * @param {*} oDocument 
 * @returns 
 */
async function updateAssessmentImageMasterReference(oDocument) {

    await cds.tx(async (tx) => {
        const oDb = await cds.connect.to('db');

        let oSet = {};
        oSet.url = "ProductProofDocument(product='',proofPointId=" + oDocument.ID + ")/content";
        oSet.imageMasterID = removeHyphensFromUUID(oDocument.ID);
        oSet.objectStoreId = "";
        await oDb.run(
            UPDATE(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT)
                .set(oSet)
                .where({ ID: oDocument.ID })
        );

        oDocument.imageMasterID = oSet.imageMasterID;

    });
    return oDocument;
    
};

/**
 * Update product and document relationship
 * 
 * @param {*} oDocument 
 * @param {*} oItem 
 * @returns 
 */
async function refreshProductDocumentMapping(oDocument, oItem) {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const sNormalizedProduct = oItem.product;
    if (oDocument.productReference) return;

    const aProductDocument = await oDb.run(SELECT.from(ENTITIES.DB.PRODUCT_PROOF_DOCUMENT_RELATION).where({ product: sNormalizedProduct, proofPointId: oDocument.imageMasterID }));

    if (aProductDocument.length === 1) {
        const oSet = {
            "type": oDocument.type,
            "description": oDocument.description,
            "active": oDocument.active
        }

        await oDb.run(
            UPDATE(ENTITIES.DB.PRODUCT_PROOF_DOCUMENT_RELATION)
                .set(oSet)
                .where({ product: sNormalizedProduct, proofPointId: oDocument.imageMasterID })
        );

    } else {

        const oInsert = {
            "product": sNormalizedProduct,
            "productType": oItem.productType ?? "",
            "proofPointId": oDocument.imageMasterID,
            "fileName": oDocument.fileName,
            "type": oDocument.type,
            "description": oDocument.description,
            "active": oDocument.active,
            "externalUrl": false
        }

        await oDb.run(INSERT.into(ENTITIES.DB.PRODUCT_PROOF_DOCUMENT_RELATION).entries(oInsert));

    }

};

/**
 * Setting of header status
 * 
 * @param {*} sHeaderId 
 * @returns 
 */
async function setMassAssessmentHeaderStatus(sHeaderId) {
    const SustainabilityService = await cds.connect.to("SustainabilityService");
    const response = await SustainabilityService.send({
        method: "POST",
        path: `/odata/v4/sustainability/management/MassAssessmentHeader(ID=${sHeaderId})/setStatus`,
        headers: {"Content-Type": "application/json"}
    });  
    return response
};

/**
 * Function to move documents from objectstore to imagemaster
 * 
 * @param {*} oItem 
 * @param {*} aProofDocuments 
 */
async function moveItemDocuments(oItem, aProofDocuments) {

    const oImageMasterService = await cds.connect.to('pst-imagemaster');

    aProofDocumentsObjectStore = aProofDocuments.map(item => ({ ...item }));

    // Move item documents to imagemaster
    for (const oDocument of aProofDocuments) {
        // If the document has content (Base64), upload it to S3
        if (!oDocument.imageMasterID && !oDocument.externalUrl) {

            const objParams = {
                Bucket: bucketName,
                Key: oDocument.objectStoreId ? oDocument.objectStoreId : oDocument.ID
            };

            // Fetch the document content from S3
            let s3Response;
            try {
                s3Response = await s3.send(new GetObjectCommand(objParams));
            } catch(e) {
                await setCommunicationErrorLog(oItem.ID, oItem.product, "objectStoreRead", {}, e);
                console.error("Error getting objectstore documents:", e);
                throw new Error(JSON.stringify(e));                   
            }

            try {
                await createImageMasterDocument(oDocument, s3Response, oImageMasterService, oItem);
                let oUpdatedDocument = await updateAssessmentImageMasterReference(oDocument);
                if (oItem.status === ASSESSMENT_STATUS.APPROVED) await refreshProductDocumentMapping(oUpdatedDocument, oItem);
            } catch (e) {
                await setCommunicationErrorLog(oItem.ID, oItem.product, "imageMaster", {}, e);                          
                console.error("Error creating imagemaster document:", e);
                throw new Error("Error updating the ProofPoints of the assessment");
            }
        } else {
            if (oItem.status === ASSESSMENT_STATUS.APPROVED) await refreshProductDocumentMapping(oDocument, oItem);
        }
    }

    // // Retrieve current DB state for object store ID
    // const aObjectStoreIDs = aProofDocumentsObjectStore.map(item => item.objectStoreId);
    // const db = await cds.connect.to("db");
    // const aIDsAwaitingMovement = await db.run(
    //     SELECT.from(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT)
    //         .columns(["ID"])
    //         .where({objectStoreId: aObjectStoreIDs})
    // );

    // // If finished, delete from object store
    // for (const oDocument of aProofDocumentsObjectStore) {
    //     const bHasItemsPendingProcessing = aIDsAwaitingMovement.some(item => item.ID === oDocument.ID);
    //     if (!oDocument.imageMasterID && !bHasItemsPendingProcessing) {
    //         try {
    //             await removeObjectStoreDocument(bucketName, s3, oDocument);
    //         } catch (e) {
    //             console.error("Error updating the ProofPoints of the assessment:", e);
    //             await setCommunicationErrorLog(oItem.ID, oItem.product, "objectStoreDelete", {}, e);
    //         }
    //     }
    // }    
    return oItem;
};

/**
 * Return given mass assessment items ids data from database
 * 
 * @param {*} aItems 
 * @returns 
 */
async function getMassAssessmentItemsDB( aItems ) {

    if (!aItems || aItems.length === 0) return [];

    const aBatches = divideArrayInBatches(aItems, MAX_PACKAGE_SIZE_DB);

    const db = await cds.connect.to("db");
    const {MassAssessmentItems} = db.entities;
    const aResults = [];        
    for (const batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT.from(MassAssessmentItems)
                .where({
                    ID: batch, 
                })
        );
        aResults.push(...aBatchResults);
    }
    return aResults;

};

/**
 * Return given single assessment items ids data from database 
 * 
 * @param {*} aItems 
 * @returns 
 */
async function getSingleAssessmentDB ( aItems ) {

    if (!aItems || aItems.length === 0) return [];

    const aBatches = divideArrayInBatches(aItems, MAX_PACKAGE_SIZE_DB);

    const db = await cds.connect.to("db");
    const aResults = [];        
    for (const batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT.from(ENTITIES.DB.SINGLE_ASSESSMENT)
                .where({
                    ID: batch, 
                })
        );
        aResults.push(...aBatchResults);
    }
    return aResults;

};

/**
 * Retrieves database SingleAssessment data from a list of MassAssessmentItems IDs
 * 
 * @param {*} aItems 
 * @returns 
 */
async function getSingleAssessmentToOnpremiseByProduct( aProducts ){

    if (!aProducts || aProducts.length === 0) return [];

    const aBatches = divideArrayInBatches(aProducts, MAX_PACKAGE_SIZE_DB);

    const db = await cds.connect.to("db");
    const aResults = [];        
    for (const batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT.from(ENTITIES.DB.SINGLE_ASSESSMENT)
                .where({
                    product: batch, 
                    status: ASSESSMENT_STATUS.PENDING_ONPREMISE
                })
        );
        aResults.push(...aBatchResults);
    }
    return aResults;
};

function removeHyphensFromUUID(sUUID) {
    return sUUID.replace(/-/g, '');
};

async function removeObjectStoreDocument(bucketName, s3, oDocument) {

    try {

        const objParamsDelete = {
            Bucket: bucketName,
            Key: oDocument.objectStoreId ? oDocument.objectStoreId : oDocument.ID
        };

        // Delete the document from S3
        await s3.send(new DeleteObjectCommand(objParamsDelete));

    } catch (oError) {
        console.error(oError);
    }
};

/**
 * Method to update  communication status of assessments
 * @param {*} IDs 
 * @param {*} communicationStatus 
 */
async function updateAssessmentCommunicationStatus(IDs, communicationStatus) {
    const db = await cds.connect.to("db");
    await db.run( async tx => {
            await UPDATE(ENTITIES.DB.MASS_ASSESSMENT_ITEMS)
                .set({communicationStatus: communicationStatus})
                .where({ ID: IDs });
            await UPDATE(ENTITIES.DB.SINGLE_ASSESSMENT)
                .set({communicationStatus: communicationStatus})
                .where({ ID: IDs });    
        }
    );
};

/**
 * Function to retrieve existingg objectstore IDs in assessmentProofDocuments table
 * 
 * @param {string[]} IDs Object store IDs to check
 * @returns {string[]} List of existing object stroe IDs
 */
async function getExistingObjectStoreIDs(IDs) {
    
    const aBatches = divideArrayInBatches(IDs, MAX_PACKAGE_SIZE_DB);
    const aResults = []
    const db = await cds.connect.to("db");
    for (batch of aBatches) {
        const aBatchResults = await db.run(
            SELECT
                .from(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT)
                .columns(["objectStoreId"])
                .where({objectStoreId: batch})
        )
        aResults.push(...aBatchResults);
    }
    return aResults;

};

module.exports = {
    ASSESSMENT_STATUS,
    ASSESSMENT_COMMUNICATION_STATUS,
    getMassAssessmentItemsToOnpremiseByProduct,
    getSingleAssessmentToOnpremiseByProduct,
    upsertMassAssessmentItemsDB,
    upsertSingleAssessmentDB,
    getSingleAssessmentDB,
    getItemsAssessmentProofDocumentsDB,
    setCommunicationErrorLog,
    updateAssessmentImageMasterReference,
    refreshProductDocumentMapping,
    setMassAssessmentHeaderStatus,
    moveItemDocuments,
    getMassAssessmentItemsDB,
    updateAssessmentCommunicationStatus,
    getExistingObjectStoreIDs,
    removeObjectStoreDocument,
    s3,
    bucketName,
}