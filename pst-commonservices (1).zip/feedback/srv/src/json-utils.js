const fs = require('fs');
const bfj = require('bfj');

/**
 * Reads JSON object from file
 * 
 * @param {String} filePath to read
 * @returns Object read from file
 */
async function readJSONFromFile(filePath) {
    const oJSONData = await parse(fs.createReadStream(filePath));
    return oJSONData;
}

/**
 * Parses an object variable asynchronously
 * 
 * @param {*} sObjectString String to parse
 * @returns Object from parsing
 */
async function parse(sObjectString) {
    const oJSONParsed = await bfj.parse(sObjectString);
    return oJSONParsed;
}

/**
 * Stringifies object asynchronously
 * 
 * @param {*} oObject Object to stringify
 * @returns Stringified object
 */
async function stringify(oObject) {
    const sObjectString = await bfj.stringify(oObject);
    return sObjectString;
}

module.exports = {
    readJSONFromFile,
    parse,
    stringify,
}