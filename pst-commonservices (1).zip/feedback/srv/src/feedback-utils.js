/**
 * Posible status of feedback in corresponding table
 */
const FEEDBACK_STATUS = {
    PENDING: "01",
    FAILED: "02",
    FINISHED: "03",
};

/**
 * Possible processing status for IB/IDH replication
 */
const PROCESSING_STATUS = {
    PENDING: "01"
};


module.exports = {
    FEEDBACK_STATUS,
    PROCESSING_STATUS,
}