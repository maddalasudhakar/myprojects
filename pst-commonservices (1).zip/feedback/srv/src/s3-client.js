const { S3Client } = require('@aws-sdk/client-s3');

/**
 * Initializes the S3 client using credentials from VCAP_SERVICES.
 * @returns {S3Client} An instance of S3Client configured with credentials.
 */
function initializeS3Client() {
    // Parse VCAP_SERVICES from environment variables
    const oVcapServices = JSON.parse(process.env.VCAP_SERVICES);

    // Access Object Store credentials
    const oObjectStoreCredentials = oVcapServices['objectstore'][0].credentials;

    // Create an S3 client with the necessary credentials and region
    const oS3 = new S3Client({
        region: oObjectStoreCredentials.region,
        credentials: {
            accessKeyId: oObjectStoreCredentials.access_key_id,
            secretAccessKey: oObjectStoreCredentials.secret_access_key
        }
    });

    return oS3; // Return the configured S3 client
}

/**
 * Retrieves the bucket name from the credentials.
 * @returns {string} The name of the S3 bucket.
 */
function getBucketName() {
    const oVcapServices = JSON.parse(process.env.VCAP_SERVICES);
    const oObjectStoreCredentials = oVcapServices['objectstore'][0].credentials;
    return oObjectStoreCredentials.bucket; // Return the bucket name
}

/**
 * Utility function to convert a stream (S3 Body) to a Base64 encoded string.
 * @param {Stream} stream - The readable stream from S3.
 * @returns {Promise<string>} The Base64 encoded string.
 */
function streamToBase64(stream) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        stream.on('data', chunk => chunks.push(chunk));
        stream.on('error', reject);
        stream.on('end', () => resolve(Buffer.concat(chunks).toString('base64')));
    });
}

// Export the S3 client and bucket name functions
module.exports = {
    initializeS3Client,
    getBucketName,
    streamToBase64
};