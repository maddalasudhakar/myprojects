const jsonUtils = require("./json-utils");

/**
 * Function to create Imagemaster document 
 * 
 * @param {*} oDocument 
 * @param {*} s3Response 
 * @param {*} oImageMasterService 
 * @param {*} oReqData 
 */
async function createImageMasterDocument(oDocument, s3Response, oImageMasterService, oReqData) {

    const streamToBase64 = async (stream) => {
        const chunks = [];
        for await (const chunk of stream) {
            chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);
        return buffer.toString('base64');
    };

    const base64Content = await streamToBase64(s3Response.Body);
    const sUUID = removeHyphensFromUUID(oDocument.ID);
    let oImageMasterDocument = {};

    const oBody = {
        "documentType": { "name": 'Sustainability_Tracking' },
        "revisions": [
            {
                "attributes": [
                    {
                        "definition": {
                            "name": 'Sustainability_Tracking.ID'
                        },
                        "values": [sUUID]
                    }
                ],
                "contents": [
                    {
                        "key": sUUID,
                        "fileName": oDocument.fileName,
                        "data": { "base64": base64Content },
                        "mimeType": s3Response.ContentType
                    }
                ]
            }
        ]
    };

    const sBody = await jsonUtils.stringify(oBody);
    oImageMasterDocument = await oImageMasterService.send({
        method: "POST",
        headers: {
            'Ima-Request-Id': `Sustainability_Tracking-{${sUUID}}`,
            "Content-Type": "application/json",
            "Accept": "application/json"
        },
        path: `/rest/core/documents`,
        data: sBody
    });

};

function removeHyphensFromUUID(sUUID) {
    return sUUID.replace(/-/g, '');
}

module.exports = {
    createImageMasterDocument,
}