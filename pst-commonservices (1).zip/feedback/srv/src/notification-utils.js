const cds = require("@sap/cds");

/**
 * Base URL path for assessment notification service
 */
const BASE_PATH = 'odata/v4/assessment-notification';

/**
 * Resource endpoints for notification
 */
const NOTIFICATION_PATH = {
    P03_PROCESSING_PRODCUT_ERROR: 'p03ProcessingProductError',
};

/**
 * Required services to connect
 */
const SERVICE = {
    CUSTOM_NOTIFICATION: 'pst-custom-notification'
};

/**
 * HTTP connection methods
 */
const HTTP_METHOD = {
    POST: 'POST',
}

/**
 * Custom notificaiton service call
 * 
 * @param {Object} param0 - Parameters to make the call 
 * @returns {Promise} Result of http call
 */
async function callCustomNotification({path, method, data = {}}) {
    const notificationService = await cds.connect.to(SERVICE.CUSTOM_NOTIFICATION);
    return await notificationService.send({
        path,
        method,
        data,
    })
};

/**
 * Post notification when prodcut has a processing error in P03
 * 
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.ID - ID of the prodcut
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnP03ProcessingProdcutError({ID}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.P03_PROCESSING_PRODCUT_ERROR}`;
    const oData = {
        assessmentId: ID,
        assessmentType: 'BY_ID'
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};
module.exports = {
postNotificationOnP03ProcessingProdcutError
}