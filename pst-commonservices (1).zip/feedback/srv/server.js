const cds = require('@sap/cds');

cds.once('served', async (tx) => {
    const LOGGER = cds.log("job");
    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"]; 
    const jobParams = userProvided?.find(item => item.name === 'feedback-job-params')?.credentials || userProvided?.find(item => item.name === 'custom-service:feedback-job-params')?.credentials;
    if (jobParams) {
        if (jobParams?.onpremiseFeedback?.active) {
            cds.spawn({ after: 1000, every: jobParams.onpremiseFeedback.interval }, async (tx) => {
                const FeedbackService = await cds.connect.to("FeedbackService");
                LOGGER.log("Trigger onpremise feedback job");
                await FeedbackService.send("feedbackProcessing", {retry: false, rejected: false});     
            });
        }
        if (jobParams?.rejectionFeedback?.active) {
            cds.spawn({ after: 1000, every: jobParams.rejectionFeedback.interval }, async (tx) => {
                const FeedbackService = await cds.connect.to("FeedbackService");
                LOGGER.log("Trigger rejection feedback job");
                await FeedbackService.send("feedbackProcessing", {retry: false, rejected: true});      
            });
        }
        if (jobParams?.retry?.active) {
            cds.spawn({ after: 1000, every: jobParams.retry.interval }, async (tx) => {
                const FeedbackService = await cds.connect.to("FeedbackService");
                LOGGER.log("Trigger retry onpremise feedback job");
                await FeedbackService.send("feedbackProcessing", {retry: true, rejected: false});    
            });         
            cds.spawn({ after: 1000, every: jobParams.retry.interval }, async (tx) => {
                const FeedbackService = await cds.connect.to("FeedbackService");
                LOGGER.log("Trigger retry rejection feedback job");
                await FeedbackService.send("feedbackProcessing", {retry: true, rejected: true});    
            });      
        }     
        if (jobParams?.ibToIdhReplication?.active) {
            cds.spawn({ after: 1000, every: jobParams.ibToIdhReplication.interval }, async (tx) => {
                const FeedbackService = await cds.connect.to("FeedbackService");
                LOGGER.log("Trigger IB to IDH replication job");
                await FeedbackService.send("processIBtoIDHReplication");      
            });
        }           
    }    
});
