using { com.sustainability.feedback as db } from '../db/schema';

@requires: 'authenticated-user'
service PowerBIService @(path: '/powerbi') {

    /**
     * Read-only projection for Power BI reporting
     * Source: COM_SUSTAINABILITY_FEEDBACK_COMMUNICATIONRESPONSEMESSAGES
     */
    @readonly
    entity FeedbackResponseMessages as projection on db.CommunicationResponseMessages {
        key ID,
            msgtyp    as MessageType    : String(1),
            message   as Message        : String(5000),
            msgCateg  as MessageCategory: String(1),
            errorSource as ErrorSource  : String(100),
            msgno as MessageNumber      : Integer
    };
}