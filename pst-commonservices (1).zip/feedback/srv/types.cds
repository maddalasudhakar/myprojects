type Product: String;

type OnPremiseFeedbackMessages {
    speedReqId: UUID;
    material: String(18);
    ibProd: String(18);
    seqno: Integer;
    msgtyp: String(1);
    msgid: String(100);
    msgno: Integer;
    message: String;
    errorSource: String(100);
    msgCateg: String(1);  
    retryCount: Integer;
};

type SpeedStatus: {
    speedReqId: UUID;
    material: String(18);
    ibProd: String(18);
    status: String(1);
    creBy: String(40);
    creOn: String(10);
    creAt: String(8);
    chgBy: String(40);
    chgOn: String(10);
    chgAt: String(8);            
}; 