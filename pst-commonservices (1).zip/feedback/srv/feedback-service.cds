using {Product, OnPremiseFeedbackMessages, SpeedStatus}from './types.cds';

@requires: 'authenticated-user'
// @requires: 'RunFeedback'
service FeedbackService { 

    /**
     * Onpremise ERP system response handler
     */
    action assessmentOnpremiseFeedback (
        items: array of {
            speedStatus: SpeedStatus;
            speedMsgs: array of OnPremiseFeedbackMessages;
        }
    ) returns String;

    /**
     * PST tool rejection handler
     */
    action assessmentRejectionFeedback (
        items: array of {
            assessmentID: UUID;
            product: Product;
        }
    ) returns String;

    action feedbackProcessing (
        retry: Boolean,
        rejected: Boolean,
        assessmentIDs: array of UUID @Core.OptionalParameter : { $Type : 'Core.OptionalParameterType' },
    ) returns String;

    action processIBtoIDHReplication(

    ) returns String;

    event p03ProcessingProductError {
        ID: UUID;
    };

    // function test() returns String;
};