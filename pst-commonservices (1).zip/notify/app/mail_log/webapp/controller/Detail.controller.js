sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",    
    "../model/formatter"
], (BaseController, JSONModel, formatter) => {
    "use strict";

    return BaseController.extend("com.nbx.maillog.controller.Detail", {
        formatter: formatter,
        
        onInit() {

            var oViewModel = new JSONModel({
                busy: false,
                delay: 0
            });

            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

            this.setModel(oViewModel, "detailView");
        },
        
        /**
         * Binds the view to the object path and expands the aggregated line items.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
        _onObjectMatched: function (oEvent) {
            var sID = oEvent.getParameter("arguments").ID;
            this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");

            this.aVariablesSelected = [];

            var sObjectPath = "/MailLog(ID='" + oEvent.getParameter("arguments").ID + "')";
            this._bindView(sObjectPath);

        },
        /**
         * Binds the view to the object path. Makes sure that detail view displays
         * a busy indicator while data for the corresponding element binding is loaded.
         * @function
         * @param {string} sObjectPath path to the object to be bound to the view.
         * @private
         */
        _bindView: function (sObjectPath) {
            // Set busy indicator during view binding
            let oViewModel = this.getModel("detailView"),
                oContext;

            // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
            oViewModel.setProperty("/busy", false);

            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oViewModel.setProperty("/busy", true);
                    },
                    dataReceived: function () {
                        oContext = this.getView().getBindingContext();
                        oViewModel.setProperty("/busy", false);
                        if (this.getView().byId("richEditor") && this.getView().byId("richEditor").getNativeApi()) {

                            this.getView().byId("richEditor").getNativeApi().setContent(oContext.getProperty("Body"));
                        }

                    }.bind(this)
                }
            });
        },
        
        _onBindingChange: function () {
            var oView = this.getView(),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("detailObjectNotFound");
                // if object could not be found, the selection in the list
                // does not make sense anymore.
                this.getOwnerComponent().oListSelector.clearMasterListSelection();
                return;
            }

            var sPath = oElementBinding.getPath();
            this.getOwnerComponent().oListSelector.selectAListItem(sPath);
        },
        onChangeEditor: function (oEvent) {
            var sContent = oEvent.getSource().getNativeApi().getContent();
            this.getView().byId("detailCodeEditor").setValue(sContent);
        },
        onReadyEditor: function (oEvent) {            
            oEvent.getSource().getNativeApi().setContent(this.getView().getBindingContext().getProperty("Body"));
        }        
    });
});