sap.ui.define([
    "./BaseController",
    "sap/ui/Device",
    "sap/ui/model/json/JSONModel",
    "../model/formatter"
], (BaseController, Device, JSONModel, formatter) => {
    "use strict";

    return BaseController.extend("com.nbx.maillog.controller.Main", {
        formatter: formatter,
        onInit() {
            var oList = this.byId("list"),
                oViewModel = this._createViewModel(),
                // Put down list's original value for busy indicator delay,
                // so it can be restored later on. Busy handling on the list is
                // taken care of by the list itself.
                iOriginalBusyDelay = oList.getBusyIndicatorDelay();


            this._oList = oList;
            // keeps the filter and search state
            this._oListFilterState = {
                aFilter: [],
                aSearch: []
            };

            this.setModel(oViewModel, "listView");
        },

        /**
         * Used to create GroupHeaders with non-capitalized caption.
         * These headers are inserted into the list to
         * group the list's items.
         * @param {Object} oGroup group whose text is to be displayed
         * @public
         * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
         */
        createGroupHeader: function (oGroup) {
            return new GroupHeaderListItem({
                title: oGroup.text,
                upperCase: false
            });
        },

        onSearch: function () {
            var oView = this.getView();
            var sTemplateName = oView.byId("TemplateName").getValue().trim();
            var sReceiver = oView.byId("Receiver").getValue().trim();
            var aSelectedChannels = oView.byId("filterTemplateChannel").getSelectedKeys();

            var oDateRangeControl = oView.byId("filterCreatedAt");
            var oDateFrom = oDateRangeControl.getDateValue();
            var oDateTo = oDateRangeControl.getSecondDateValue();

            var aFilters = [];

            if (sTemplateName) {
                aFilters.push(new sap.ui.model.Filter("TemplateName", sap.ui.model.FilterOperator.Contains, sTemplateName));
            }

            if (sReceiver) {
                aFilters.push(new sap.ui.model.Filter("Receiver", sap.ui.model.FilterOperator.Contains, sReceiver));
            }

            if (aSelectedChannels && aSelectedChannels.length > 0 && !aSelectedChannels.includes("")) {
                var aChannelFilters = aSelectedChannels.map(function (key) {
                    return new sap.ui.model.Filter("TemplateChannel", sap.ui.model.FilterOperator.EQ, key);
                });
                aFilters.push(new sap.ui.model.Filter(aChannelFilters, false)); 
            }

            
            if (oDateFrom && oDateTo) {
                var oStartDate = new Date(oDateFrom);
                oStartDate.setHours(0, 0, 1, 0); 

                var oEndDate = new Date(oDateTo);
                oEndDate.setHours(23, 59, 59, 999);

                var sStartISO = this._toISOStringWithoutMilliseconds(oStartDate);
                var sEndISO = this._toISOStringWithoutMilliseconds(oEndDate);
                aFilters.push(new sap.ui.model.Filter("createdAt", sap.ui.model.FilterOperator.BT, sStartISO, sEndISO));
            }

            // Aplicar filtros
            var oTable = oView.byId("list");
            var oBinding = oTable.getBinding("items");
            oBinding.filter(aFilters);
        },

        onSelectionChange: function (oEvent) {
            var oList = oEvent.getSource(),
                bSelected = oEvent.getParameter("selected");

            // skip navigation when deselecting an item in multi selection mode
            if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
                // get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
                this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
            }
        },
        /**
         * Shows the selected item on the detail page
         * On phones a additional history entry is created
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showDetail: function (oItem) {
            let oObject = oItem.getBindingContext().getObject();
            var bReplace = !Device.system.phone;
            // set the layout property of FCL control to show two columns
            this.getModel("appView").setProperty("/layout", "TwoColumnsBeginExpanded");
            /*this.getRouter().navTo("object", {
                ID : oItem.getBindingContext().getProperty("ID"),
                Version: oItem.getBindingContext().getProperty("Version"),
                Language: oItem.getBindingContext().getProperty("Language"),
                TimeStamp: oItem.getBindingContext().getProperty("TimeStamp"),
            }, bReplace);*/
            this.getRouter().navTo("object", {
                ID: oObject.ID
            }, bReplace);
        },
        /* =========================================================== */
        /* begin: internal methods                                     */
        /* =========================================================== */

        _toISOStringWithoutMilliseconds: function (date) {
            return date.toISOString().split(".")[0] + "Z";
        },


        _createViewModel: function () {
            return new JSONModel({
                isFilterBarVisible: false,
                filterBarLabel: "",
                delay: 0,
                title: this.getResourceBundle().getText("listTitleCount", [0]),
                noDataText: this.getResourceBundle().getText("listListNoDataText"),
                sortBy: "TemplateName",
                groupBy: "None"
            });
        },
    });
});