sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "./controller/ListSelector",
    "./model/models",
    "./controller/ErrorHandler"
], (UIComponent, Device, ListSelector, models, ErrorHandler) => {
    "use strict";

    return UIComponent.extend("com.nbx.maillog.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            
            this.oListSelector = new ListSelector();
            this._oErrorHandler = new ErrorHandler(this);

            this.setModel(models.createTemplateModel(), "templateModel");

            this.setModel(models.createAppModel(), "app");

            this.setModel(models.createVariablesModel(), "variables");

            this.setModel(models.createTestModel(), "testModel");

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // call the base component's init function and create the App view
            UIComponent.prototype.init.apply(this, arguments);

            // create the views based on the url/hash
            this.getRouter().initialize();
        },
        
        /**
        * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
        * design mode class should be set, which influences the size appearance of some controls.
        * @public
        * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
        */
        getContentDensityClass: function () {
            if (this._sContentDensityClass === undefined) {
                // check whether FLP has already set the content density class; do nothing in this case
                // eslint-disable-next-line sap-no-proprietary-browser-api
                if (document.body.classList.contains("sapUiSizeCozy") || document.body.classList.contains("sapUiSizeCompact")) {
                    this._sContentDensityClass = "";
                } else if (!Device.support.touch) { // apply "compact" mode if touch is not supported
                    this._sContentDensityClass = "sapUiSizeCompact";
                } else {
                    // "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
                    this._sContentDensityClass = "sapUiSizeCozy";
                }
            }
            return this._sContentDensityClass;
        }
    });
});