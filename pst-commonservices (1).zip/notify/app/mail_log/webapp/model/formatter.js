sap.ui.define([], function () {
    "use strict";

    return {
        /**
         * Rounds the currency value to 2 digits
         *
         * @public
         * @param {string} sValue value to be formatted
         * @returns {string} formatted currency value with 2 digits
         */
        channelText : function (sValue) {
            if (sValue) {
                var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (sValue) {
                    case "M":
                        return resourceBundle.getText("channelMailText");
                    case "N":
                        return resourceBundle.getText("channelNotificationCenterText");
                    case "S":
                        return resourceBundle.getText("channelSMSText");
                     case "W":
                        return resourceBundle.getText("channelWhatsappText");
                    default:
                        return sValue;
                }
            }
        },

        channelVisibilty : function (sValue) {
            var bVisible = false;
            if (sValue) {
                var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (sValue) {
                    case "M":
                        return resourceBundle.getText("channelMailText");
                    case "N":
                        return resourceBundle.getText("channelNotificationCenterText");
                    case "S":
                        return resourceBundle.getText("channelSMSText");
                     case "W":
                        return resourceBundle.getText("channelWhatsappText");
                    default:
                        return sValue;
                }
            }
        },
    };
});