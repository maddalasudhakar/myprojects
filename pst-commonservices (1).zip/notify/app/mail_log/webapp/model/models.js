sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "sap/ui/Device"
],
    /**
     * provide app-view type models (as in the first "V" in MVVC)
     * 
     * @param {typeof sap.ui.model.json.JSONModel} JSONModel
     * @param {typeof sap.ui.Device} Device
     * 
     * @returns {Function} createDeviceModel() for providing runtime info for the device the UI5 app is running on
     */
    function (JSONModel, Device) {
        "use strict";

        return {

            createTemplateModel: function () {
                var oModel = new JSONModel({
                    "id": "99999999999999999999999999999999",
                    "name": "",
                    "language": "EN",
                    "channel": "M",
                    "version": "1"
                }
                );
                oModel.setDefaultBindingMode("TwoWay");
                return oModel;
            },

            createTestModel: function () {
                var oModel = new JSONModel({
                    "receiverPernr": "",
                    "receiverName": "",
                    "receiverEmail": "",
                    "body": "",
                    "subject": "",
                    "Tokens": []
                }
                );
                oModel.setDefaultBindingMode("TwoWay");
                return oModel;
            },        

            createAppModel: function () {
                var oModel = new JSONModel({
                    "mode": "display",
                    "sender": "test"
                }
                );
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            },

            createVariablesModel: function () {
                var oModel = new JSONModel({

                    "categories": [
                        {
                            "name": "Personnel Administration", "technicalField": "", variable: "", type: "category", "categories": [
                                {
                                    "name": "Personal Data", "technicalField": "", variable: "", type: "alias", alias:"@pd", "categories": [
                                        { "name": "First name", "technicalField": "VORNA", variable: "FirstName", type: "property", alias:"@pd", selected: false},
                                        { "name": "Last name", "technicalField": "NACHN", variable: "LastName", type: "property", alias:"@pd", selected: false },
                                        { "name": "Form of address", "technicalField": "ANREX" , variable: "formOfAddress", type: "property", alias:"@pd", selected: false },
                                        { 'name': 'Short Descript.',  'technicalField': 'ID_TYPE_TEXT', variable: 'DocumentTypeText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Communication Language',  'technicalField': 'SPTXT', variable: 'CommunicationLanguageText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Screen control',  'technicalField': 'ITBLD', variable: 'VersionId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Form of Address',  'technicalField': 'ANRED', variable: 'FormOfAddressId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Form Addr.',  'technicalField': 'ANREX', variable: 'FormOfAddressText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Name Format',  'technicalField': 'KNZNM', variable: 'NameFormatIndicator', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Name at Birth',  'technicalField': 'NAME2', variable: 'NameAtBirth', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Initials',  'technicalField': 'INITS', variable: 'Initials', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Name prefix',  'technicalField': 'VORSW', variable: 'NamePrefix', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'N.prefix 2',  'technicalField': 'VORS2', variable: 'NamePrefix2', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Title',  'technicalField': 'TITEL', variable: 'AcademicTitle', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Document number',  'technicalField': 'PERID', variable: 'DocumentNumber', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Document type',  'technicalField': 'ID_TYPE', variable: 'DocumentType', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Birthplace',  'technicalField': 'GBORT', variable: 'CityOfBirth', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Province',  'technicalField': 'GBDEP', variable: 'StateOfBirth', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Description',  'technicalField': 'BEZEI', variable: 'StateOfBirthText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Country of birth',  'technicalField': 'LANDX', variable: 'CountryOfBirthText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Nationality',  'technicalField': 'NATIX', variable: 'NationalityText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Marital Status',  'technicalField': 'FAMST', variable: 'MaritalStatusId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Second name',  'technicalField': 'NACH2', variable: 'SecondName', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Gender',  'technicalField': 'FASEX', variable: 'GenderId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Gender',  'technicalField': 'GESC2', variable: 'Gender2Id', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Second Title',  'technicalField': 'TITL2', variable: 'SecondTitle', type: 'property', alias:"@pd", selected: false},
                                        { 'name': '2nd Nationality',  'technicalField': 'NATI2', variable: 'SecondNationalityId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Nationality',  'technicalField': 'NA2TX', variable: 'SecondNationalityText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': '3rd Nationality',  'technicalField': 'NATI3', variable: 'ThirdNationalityId', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Nationality',  'technicalField': 'NA3TX', variable: 'ThirdNationalityText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Religion',  'technicalField': 'KITXT', variable: 'ReligiousDenominationText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Other title',  'technicalField': 'NAMZU', variable: 'OtherTitle', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Marital status',  'technicalField': 'FATXT', variable: 'MarialStatusText', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Religion',  'technicalField': 'KTEXT', variable: 'Religion', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Number of Children',  'technicalField': 'ANZKD', variable: 'NumberOfChildren', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Birth date',  'technicalField': 'GBDAT', variable: 'DateOfBirth', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Since',  'technicalField': 'FAMDT', variable: 'MarialStatusBeginDate', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Personnel No.',  'technicalField': 'HCMFAB_PERNR', variable: 'EmployeeNumber', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'End Date',  'technicalField': 'HCMFAB_ENDDA', variable: 'EndDate', type: 'property', alias:"@pd", selected: false},
                                        { 'name': 'Start Date',  'technicalField': 'HCMFAB_BEGDA', variable: 'BeginDate', type: 'property', alias:"@pd", selected: false}
                                    ]
                                },
                                {
                                    "name": "Addresses", "technicalField": "", variable: "", type: "alias", alias:"@ad", "categories": [
                                        { 'name': 'Personnel No.',  'technicalField': 'HCMFAB_PERNR', variable: 'EmployeeNumber', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Hash Value',  'technicalField': 'PERS_INFO_ETAG', variable: 'PersInfoEtag', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Infotype',  'technicalField': 'HCMFAB_INFTY', variable: 'InfotypeId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Subtype',  'technicalField': 'HCMFAB_SUBTY', variable: 'SubtypeId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Object ID',  'technicalField': 'HCMFAB_OBJPS', variable: 'ObjectId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'IT record no.',  'technicalField': 'HCMFAB_SEQNR', variable: 'SequenceNumber', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Screen control',  'technicalField': 'ITBLD', variable: 'VersionId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Address type',  'technicalField': 'ANSSA', variable: 'AddressRecordType', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Name',  'technicalField': 'STEXT', variable: 'SubtypeText', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'c/o',  'technicalField': 'NAME2', variable: 'ContactName', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Street abbrev.',  'technicalField': 'STRDS', variable: 'StreetAbbreviationId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Meaning',  'technicalField': 'VIAPT', variable: 'StreetAbbreviationText', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Street',  'technicalField': 'STRAS', variable: 'Street', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'House Number',  'technicalField': 'HSNMR', variable: 'HouseNumber', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Apartment Number',  'technicalField': 'POSTA', variable: 'AppartmentId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Address Line 2',  'technicalField': 'LOCAT', variable: 'SupplementalAddressLine', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Postal Code',  'technicalField': 'PSTLZ', variable: 'PostalCode', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'City',  'technicalField': 'ORT01', variable: 'City', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'District',  'technicalField': 'ORT02', variable: 'District', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Province',  'technicalField': 'STATE', variable: 'StateId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'BEZEI', variable: 'StateText', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Country',  'technicalField': 'LAND1', variable: 'CountryId', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Name',  'technicalField': 'LANDX', variable: 'CountryText', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Telephone Number',  'technicalField': 'TELNR', variable: 'TelephoneNumber', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Type',  'technicalField': 'COM01', variable: 'CommunicationType1', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'TYPE1', variable: 'CommunicationTypeText1', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Number',  'technicalField': 'NUM01', variable: 'CommunicationNumber1', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Company housing',  'technicalField': 'WKWNG', variable: 'CompanyHousing', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Type',  'technicalField': 'COM02', variable: 'CommunicationType2', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'TYPE2', variable: 'CommunicationTypeText2', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Number',  'technicalField': 'NUM02', variable: 'CommunicationNumber2', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Bus route',  'technicalField': 'BUSRT', variable: 'BusRoute', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Type',  'technicalField': 'COM03', variable: 'CommunicationType3', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'TYPE3', variable: 'CommunicationTypeText3', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Number',  'technicalField': 'NUM03', variable: 'CommunicationNumber3', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'TYPE4', variable: 'CommunicationTypeText4', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Type',  'technicalField': 'COM04', variable: 'CommunicationType4', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Number',  'technicalField': 'NUM04', variable: 'CommunicationNumber4', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'DISPLAY_SCREEN', variable: 'DisplayScreen', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'EDIT_SCREEN', variable: 'EditScreen', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Distance in km.',  'technicalField': 'ENTKM', variable: 'WorkDistance', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Distance in km.',  'technicalField': 'ENTK2', variable: 'WorkDistance2', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'End Date',  'technicalField': 'HCMFAB_ENDDA', variable: 'EndDate', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Start Date',  'technicalField': 'HCMFAB_BEGDA', variable: 'BeginDate', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'Lock indicator',  'technicalField': 'HCMFAB_SPRPS', variable: 'LockIndicator', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_EDITABLE', variable: 'IsEditable', type: 'property', alias:'@ad',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_DELETABLE', variable: 'IsDeletable', type: 'property', alias:'@ad',  selected: false}                                        
                                    ]
                                },
                                {
                                    "name": "Bank details", "technicalField": "", variable: "", type: "alias", alias:"@bd", "categories": [
                                        { 'name': 'Bank Control Key',  'technicalField': 'BKONT_TEXT', variable: 'BankControlKeyText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Personnel No.',  'technicalField': 'HCMFAB_PERNR', variable: 'EmployeeNumber', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Ctry Grouping',  'technicalField': 'MOLGA', variable: 'Molga', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Infotype',  'technicalField': 'HCMFAB_INFTY', variable: 'InfotypeId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Hash Value',  'technicalField': 'PERS_INFO_ETAG', variable: 'PersInfoEtag', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Subtype',  'technicalField': 'HCMFAB_SUBTY', variable: 'SubtypeId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Start Date',  'technicalField': 'HCMFAB_BEGDA', variable: 'BeginDate', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'End Date',  'technicalField': 'HCMFAB_ENDDA', variable: 'EndDate', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Object ID',  'technicalField': 'HCMFAB_OBJPS', variable: 'ObjectId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'IT record no.',  'technicalField': 'HCMFAB_SEQNR', variable: 'SequenceNumber', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Lock indicator',  'technicalField': 'HCMFAB_SPRPS', variable: 'LockIndicator', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Account Number',  'technicalField': 'BANKN', variable: 'BankAccountNumber', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Control Key',  'technicalField': 'BKONT', variable: 'BankControlKey', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Country',  'technicalField': 'BANKS', variable: 'BankCountryId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Country Text',  'technicalField': 'LANDX', variable: 'BankCountryText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Detail Type',  'technicalField': 'BNKSA', variable: 'BankDetailsTypeId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Detail Type',  'technicalField': 'BNKSA_TEXT', variable: 'BankDetailsTypeText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Key',  'technicalField': 'BANKL', variable: 'BankId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Note to Payee',  'technicalField': 'BKREF', variable: 'BankReferenceDetails', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Bank Name',  'technicalField': 'BANKA', variable: 'BankText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Purpose',  'technicalField': 'ZWECK', variable: 'BankTransferPurpose', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Changed On',  'technicalField': 'AEDTM', variable: 'ChangedOn', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Currency',  'technicalField': 'WAERS01', variable: 'CurrencyId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'DISPLAY_SCREEN', variable: 'DisplayScreen', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'EDIT_SCREEN', variable: 'EditScreen', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'IBAN',  'technicalField': 'IBAN00', variable: 'Iban', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 1',  'technicalField': 'IBAN01', variable: 'IbanPart1', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 2',  'technicalField': 'IBAN02', variable: 'IbanPart2', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 3',  'technicalField': 'IBAN03', variable: 'IbanPart3', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 4',  'technicalField': 'IBAN04', variable: 'IbanPart4', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 5',  'technicalField': 'IBAN05', variable: 'IbanPart5', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 6',  'technicalField': 'IBAN06', variable: 'IbanPart6', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 7',  'technicalField': 'IBAN07', variable: 'IbanPart7', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 8',  'technicalField': 'IBAN08', variable: 'IbanPart8', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Section 9',  'technicalField': 'IBAN09', variable: 'IbanPart9', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'IBAN Valid From',  'technicalField': 'IBAN_VALFR', variable: 'IbanValidityBeginDate', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_DELETABLE', variable: 'IsDeletable', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_EDITABLE', variable: 'IsEditable', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payment Date',  'technicalField': 'BONDT', variable: 'OffCyclePayrollPaymentDate', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'City',  'technicalField': 'BKORT', variable: 'PayeeCity', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Country',  'technicalField': 'ADRS_BANKS', variable: 'PayeeCountryId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Country',  'technicalField': 'BANKS_LANDX', variable: 'PayeeCountryText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payee',  'technicalField': 'EMFTX', variable: 'PayeeName', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Postal Code',  'technicalField': 'BKPLZ', variable: 'PayeePostalCode', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Region',  'technicalField': 'STATE', variable: 'PayeeStateId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Description',  'technicalField': 'BEZEI', variable: 'PayeeStateText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Street and House No.',  'technicalField': 'STRAS', variable: 'PayeeStreet', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payment Currency',  'technicalField': 'WAERS', variable: 'PaymentCurrency', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payment Currency',  'technicalField': 'LTEXT', variable: 'PaymentCurrencyText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payment Method',  'technicalField': 'ZLSCH', variable: 'PaymentMethodId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payment Method',  'technicalField': 'TEXT1', variable: 'PaymentMethodText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payroll Identifier',  'technicalField': 'PAYID', variable: 'PayrollIdentifier', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Payroll type',  'technicalField': 'PAYTY', variable: 'PayrollType', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'PBS Transfer Type',  'technicalField': 'BTTYP', variable: 'PBSTransferTypeId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'PBS Transfer Type',  'technicalField': 'BTEXT', variable: 'PBSTransferTypeText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Standard Percentage',  'technicalField': 'ANZHL', variable: 'PercentageAmount', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Off-cycle reas.',  'technicalField': 'OCRSN', variable: 'ReasonForOffCyclePayrollId', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Offcycle reason',  'technicalField': 'OCRTX', variable: 'ReasonForOffCyclePayrollText', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'SWIFT/BIC',  'technicalField': 'SWIFT', variable: 'SwiftCode', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': '%',  'technicalField': 'PRCNT', variable: 'TransferPercentage', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Transfer Value',  'technicalField': 'BETRG', variable: 'TransferValue', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Changed by',  'technicalField': 'UNAME', variable: 'ChangedBy', type: 'property', alias:'@bd',  selected: false},
                                        { 'name': 'Screen control',  'technicalField': 'ITBLD', variable: 'VersionId', type: 'property', alias:'@bd',  selected: false},
                                                                            
                                    ]
                                },
                                {
                                    "name": "Family members", "technicalField": "", variable: "", type: "alias", alias:"@fm", "categories": [
                                        { 'name': 'Short Descript.',  'technicalField': 'MINSV_TEXT', variable: 'DegreeOfChallengeText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Personnel No.',  'technicalField': 'HCMFAB_PERNR', variable: 'EmployeeNumber', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Hash Value',  'technicalField': 'PERS_INFO_ETAG', variable: 'PersInfoEtag', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Infotype',  'technicalField': 'HCMFAB_INFTY', variable: 'InfotypeId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Subtype',  'technicalField': 'HCMFAB_SUBTY', variable: 'SubtypeId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Object ID',  'technicalField': 'HCMFAB_OBJPS', variable: 'ObjectId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Lock indicator',  'technicalField': 'HCMFAB_SPRPS', variable: 'LockIndicator', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'End Date',  'technicalField': 'HCMFAB_ENDDA', variable: 'EndDate', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Start Date',  'technicalField': 'HCMFAB_BEGDA', variable: 'BeginDate', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'IT record no.',  'technicalField': 'HCMFAB_SEQNR', variable: 'SequenceNumber', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Screen control',  'technicalField': 'ITBLD', variable: 'VersionId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Family Member',  'technicalField': 'FAMSA', variable: 'FamilyMemberTypeId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Name',  'technicalField': 'STEXT', variable: 'FamilyMemberTypeText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Object no. text',  'technicalField': 'OBJTX', variable: 'ObjectIdentificationText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': '',  'technicalField': 'OBJPS', variable: 'ObjectIdentificationId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Number',  'technicalField': 'OBJPS1', variable: 'ObjectIdentificationId1', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Child Number',  'technicalField': 'OBJPS2', variable: 'ObjectIdentificationId2', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'First Surname',  'technicalField': 'FANAM', variable: 'LastName', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Second Surname',  'technicalField': 'FNAC2', variable: 'SecondName', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'First Name',  'technicalField': 'FAVOR', variable: 'FirstName', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Initials',  'technicalField': 'FINIT', variable: 'Initials', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Other title',  'technicalField': 'FNMZU', variable: 'NameAffix', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Name Format',  'technicalField': 'KNZNM', variable: 'NameFormatIndicatorId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Date of Birth',  'technicalField': 'FGBDT', variable: 'DateOfBirth', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Place of Birth',  'technicalField': 'FGBOT', variable: 'PlaceOfBirth', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Country of Birth',  'technicalField': 'FGBLD', variable: 'CountryOfBirthId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Country of Birth',  'technicalField': 'LANDX', variable: 'CountryOfBirthText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Nationality',  'technicalField': 'FANAT', variable: 'NationalityId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Nationality',  'technicalField': 'NATIX', variable: 'NationalityText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Application of Family Min.',  'technicalField': 'IRPF', variable: 'FactorFamilyMinId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Application of Family Min.',  'technicalField': 'TTEXT', variable: 'FactorFamilyMinText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Degree of Challenge',  'technicalField': 'MINSV', variable: 'DegreeOfChallenge', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'NIF',  'technicalField': 'CODIM', variable: 'TaxPayRefNumber', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Adoption Date',  'technicalField': 'FECAD', variable: 'DateOfAdoption', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Gender',  'technicalField': 'GESC2', variable: 'GenderId2', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Other nat.',  'technicalField': 'FANA2', variable: 'NationalityId2', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': '2nd/3rd nat.',  'technicalField': 'FANA3', variable: 'NationalityId3', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Name prefix',  'technicalField': 'FVRSW', variable: 'NamePrefixFirstId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Name prefix',  'technicalField': 'FVRS2', variable: 'NamePrefixSecondId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Name at Birth',  'technicalField': 'FGBNA', variable: 'NameAtBirth', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Relev. for SEPE',  'technicalField': 'RE_INEM', variable: 'RelevanceForSEPE', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'Gender',  'technicalField': 'FASEX', variable: 'GenderId', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': '',  'technicalField': 'SEXTX', variable: 'GenderText', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_EDITABLE', variable: 'IsEditable', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'TRUE',  'technicalField': 'IS_DELETABLE', variable: 'IsDeletable', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'DISPLAY_SCREEN', variable: 'DisplayScreen', type: 'property', alias:'@fm',  selected: false},
                                        { 'name': 'UI Screen',  'technicalField': 'EDIT_SCREEN', variable: 'EditScreen', type: 'property', alias:'@fm',  selected: false}                                        
                                    ]
                                },
                                {
                                    "name": "Communication Data", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "First name", "technicalField": "VORNA", selected: false  },
                                        { "name": "Last name", "technicalField": "NACHNA", selected: false  },
                                        { "name": "Form of address", "technicalField": "ANREX", selected: false  }
                                    ]
                                }                                

                            ]
                        },
                        {
                            "name": "Organizational Management", "technicalField": "", variable: "", type: "alias", "categories": [
                                {
                                    "name": "Position", "technicalField": "", variable: "", type: "property", "categories": [
                                     
                                    ]
                                },
                                {
                                    "name": "Job", "technicalField": "", variable: "", type: "property", "categories": [
                                     
                                    ]
                                },
                                {
                                    "name": "Organizational Unit", "technicalField": "", variable: "", type: "property", "categories": [
                                     
                                    ]
                                },
                            ]
                        },
                        {
                            "name": "Time Management", "technicalField": "", variable: "", type: "alias", "categories": [
                                {
                                    "name": "Planned Working Time", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Work schedule rule", "technicalField": "SCHKZ", variable: "workScheduleRule", type: "property", selected: false },
                                        { "name": "Daily working hours", "technicalField": "ARBST", variable: "dailyWorkingHours", type: "property", selected: false },
                                        { "name": "Weekly working hours", "technicalField": "WOSTD", variable: "weeklyWorkingHours", type: "property", selected: false  },
                                        { "name": "Monthly working hours", "technicalField": "MOSTD", variable: "monthlyWorkingHours", type: "property", selected: false  },
                                        { "name": "Annual working hours", "technicalField": "JRSTD", variable: "annualWorkingHours", type: "property", selected: false  },
                                        { "name": "Weekly workdays", "technicalField": "WKWDY", variable: "weeklyWorkdays", type: "property", selected: false  }
                                    ]
                                },
                                {
                                    "name": "Absence", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "start", type: "property", selected: false },
                                        { "name": "End", "technicalField": "ENDDA", variable: "end", type: "property", selected: false },
                                        { "name": "Absence type", "technicalField": "AWART", variable: "absenceType", type: "property", selected: false },
                                        { "name": "StartTime", "technicalField": "BEGUZ", variable: "startTime", type: "property", selected: false },
                                        { "name": "EndTime", "technicalField": "ENDUZ", variable: "endTime", type: "property", selected: false },
                                        { "name": "Previous day", "technicalField": "VTKEN", variable: "previousDay", type: "property", selected: false },
                                        { "name": "Absence hours", "technicalField": "STDAZ", variable: "absenceHours", type: "property", selected: false  },
                                        { "name": "Full-day", "technicalField": "ALLDF", variable: "fullDay", type: "property", selected: false  },
                                        { "name": "Absence days", "technicalField": "ABWTG", variable: "absenceDays", type: "property", selected: false  },
                                        { "name": "Calender days", "technicalField": "KALTG", variable: "calendarDays", type: "property", selected: false  }
                                    ]
                                }, 
                                {
                                    "name": "Attendance", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "start", type: "property", selected: false }
                                    ]
                                }, 
                                {
                                    "name": "Overtime", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "start", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "Time Events", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "start", type: "property", selected: false }
                                    ]
                                }
                            ]
                        },
                        {
                            "name": "Payroll", "technicalField": "", variable: "", type: "alias", "categories": [
                                {
                                    "name": "Basic Pay", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "Recurring Payment and Deductions", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "Additional Payment", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "External Bank Transfer", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "Additional Off-Cycle payment", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                },
                                {
                                    "name": "Loan", "technicalField": "", variable: "", type: "alias", "categories": [
                                        { "name": "Start", "technicalField": "BEGDA", variable: "{start}", type: "property", selected: false }
                                    ]
                                }
                            ]
                        }
                    ]
                }
                );
                oModel.setDefaultBindingMode("TwoWay");
                return oModel;
            },


            createDeviceModel: function () {
                var oModel = new JSONModel(Device);
                oModel.setDefaultBindingMode("OneWay");
                return oModel;
            }
        };
    });