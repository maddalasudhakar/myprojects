sap.ui.define([
     "sap/ui/core/library"
], function (coreLibrary) {
    "use strict";
    let ValueState = coreLibrary.ValueState;

    return {
        /**
         * Rounds the currency value to 2 digits
         *
         * @public
         * @param {string} sValue value to be formatted
         * @returns {string} formatted currency value with 2 digits
         */
        channelText : function (sValue) {
            if (sValue) {
                var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (sValue) {
                    case "M":
                        return resourceBundle.getText("channelMailText");
                    case "N":
                        return resourceBundle.getText("channelNotificationCenterText");
                    case "S":
                        return resourceBundle.getText("channelSMSText");
                     case "W":
                        return resourceBundle.getText("channelWhatsappText");
                    default:
                        return sValue;
                }
            }
        },

        channelVisibilty : function (sValue) {
            var bVisible = false;
            if (sValue) {
                var resourceBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                switch (sValue) {
                    case "M":
                        return resourceBundle.getText("channelMailText");
                    case "N":
                        return resourceBundle.getText("channelNotificationCenterText");
                    case "S":
                        return resourceBundle.getText("channelSMSText");
                     case "W":
                        return resourceBundle.getText("channelWhatsappText");
                    default:
                        return sValue;
                }
            }
        },

        formatNameState: function (sValue, sErrorMessage) {
            if (sErrorMessage) {
                return ValueState.Error;
            } else if (!sValue) {
                return ValueState.Error;
            } else {
                return ValueState.None;
            }
        },

        formatNameStateText: function (sValue, sErrorMessage) {
            const oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            if (sErrorMessage) {
                return sErrorMessage;
            } else if (!sValue) {
                return oBundle.getText("nameInputStateMessage");
            } else {
                return "";
            }
        }

    };

});