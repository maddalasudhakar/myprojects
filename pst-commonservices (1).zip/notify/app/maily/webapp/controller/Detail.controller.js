sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Input",
    "sap/ui/model/SimpleType",
    "sap/ui/model/ValidateException",
    'sap/ui/core/Fragment',
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/Device",
], function (BaseController, JSONModel, formatter, Dialog, Button, Input, SimpleType, ValidateException, Fragment, MessageBox, MessageToast, Filter, FilterOperator, Device) {
    "use strict";
    // shortcut for sap.m.ButtonType
    var ButtonType = sap.m.ButtonType;

    // shortcut for sap.m.DialogType
    var DialogType = sap.m.DialogType;
    // shortcut for sap.m.URLHelper
    var URLHelper = sap.m.URLHelper;

    return BaseController.extend("com.nbx.maily.controller.Detail", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        onInit: function () {
            // Model used to manipulate control states. The chosen values make sure,
            // detail page is busy indication immediately so there is no break in
            // between the busy indication for loading the view's meta data
            var oViewModel = new JSONModel({
                busy: false,
                delay: 0
            });
            this.getView().setModel(new JSONModel({
                originalData: {}
            }), "oOriginalDataModel");

            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

            this.setModel(oViewModel, "detailView");


            this.aVariablesSelected = [];
            this._bNewSearchFromEmplDetailsTriggered = false;
            this._delayTimer = null;
            this._suggestValue = null;
            this._bSearchTriggered = false;

        },

        onChangeEditor: function (oEvent) {
            var sContent = oEvent.getSource().getNativeApi().getContent();
            this.getView().byId("detailCodeEditor").setValue(sContent);
            this.generateBodyTags(this.extractWords(sContent));
        },

        onReadyEditor: function (oEvent) {
            oEvent.getSource().getNativeApi().setContent(this.getView().getBindingContext().getProperty("Body"));
        },

        onSubjectLiveChange: function (oEvent) {
            let oObject = oEvent.getSource().getBindingContext().getObject();

            this.generateSubjectTags(this.extractWords(oEvent.getParameter("value")), oObject.Channel);
        },

        onNotificationTextLiveChange: function (oEvent) {
            this.generateNotificationTextTags(this.extractWords(oEvent.getParameter("value")));
        },

        onEdit: function (oEvent) {
            this.getModel("app").setProperty("/mode", "edit");
        },

        openCopyTemplateFragment: async function () {

            const oContextBinding = this.getView().getBindingContext();
            const sOriginalPath = oContextBinding.getPath();
            const oDataModel = this.getView().getModel();
            const oBindContext = oDataModel.bindContext(sOriginalPath);
            const oOriginalData = await oBindContext.requestObject();

            const oDialog = this.byId("copyTemplateDialog");

            const oOriginalDataModel = this.getView().getModel("oOriginalDataModel");
            oOriginalDataModel.setProperty("/originalData", {
                ...oOriginalData,
                TemplateName: "",
                ErrorMessage: ""
            });
            
            if(oDialog) {   
                oDialog.setModel(oOriginalDataModel);
                oDialog.open();
            } else {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.nbx.maily.view.fragment.CopyTemplate",
                    controller: this
                }).then(function (oDialog) {
                    this.getView().addDependent(oDialog);
                    oDialog.setModel(oOriginalDataModel);
                    oDialog.open();
                }.bind(this));
            }
  
        },

        onCopyTemplate: async function (oEvent) {

            const oView = this.getView(), 
            oDataModel = oView.getModel(),
            oOriginalDataModel = oView.getModel("oOriginalDataModel"),
            oMessageManager = sap.ui.getCore().getMessageManager(),
            oMessageModel = oMessageManager.getMessageModel();

            oOriginalDataModel.setProperty("/originalData/ErrorMessage", "");
  
            const  bReplace = !Device.system.phone,
            
            oOriginalData = this.byId("copyTemplateDialog").getModel().getData().originalData,
            sTemplateName = oOriginalData.TemplateName,
            sBody = oOriginalData.Body,
            sChannel = oOriginalData.Channel,
            sLanguage = oOriginalData.Language,
            bIsActiveVersion = oOriginalData.IsActiveVersion || null,
            sSubject = oOriginalData.Subject,
            bTextId = oOriginalData.TextId || null,
            
            oListBinding = oDataModel.bindList("/Template"),
            oContext = oListBinding.create({
                TemplateName : sTemplateName,
                Body : sBody,
                Channel : sChannel,
                Language : sLanguage,
                IsActiveVersion : bIsActiveVersion,
                Subject : sSubject,
                TextId : bTextId
            });

            oMessageManager.removeAllMessages();

            try {
                await oDataModel.submitBatch("UpdateGroup");
                if (!oDataModel.hasPendingChanges()) {
                    await oDataModel.refresh();
                    this.onCloseTemplateFragment();
                    
                    oContext.created().then(() => {
                        const oNewObject = oContext.getObject();
                        this.getRouter().navTo("object", {
                            ID: oNewObject.ID,
                            Language: oNewObject.Language,
                        }, bReplace);
                    });

                } else {

                    let aMessage = oMessageModel.getData();
                    let oLastMessage = aMessage[aMessage.length - 1],
                        sErrorMsg = oLastMessage.getMessage();
                    oOriginalDataModel.setProperty("/originalData/ErrorMessage", sErrorMsg);
                    oDataModel.resetChanges();
                }

            } catch (oError) {
                oDataModel.resetChanges();
                console.error("Create template error", oError);
            }

        },


        onTemplateNameChange: function (oEvent) {

            const oOriginalDataModel = this.getView().getModel("oOriginalDataModel");
            oOriginalDataModel.setProperty("/originalData/ErrorMessage", "");
            const oMessageManager = sap.ui.getCore().getMessageManager();
            const aMessages = oMessageManager.getMessageModel().getData();
            aMessages.filter(msg => msg.type === "Error").forEach(msg => oMessageManager.removeMessages(msg));

        },

        onCloseTemplateFragment: function () {
            const oDialog = this.byId("copyTemplateDialog");
            const oCopyFragmentModel = this.getView().getModel("oOriginalDataModel");

            if (oDialog) {
                const oContext = oDialog.getBindingContext();
                if (oContext && oContext.isTransient && oContext.isTransient()) {
                    oContext.delete();
                }
                oDialog.close();
                oCopyFragmentModel.setProperty("/originalData/TemplateName", "");
            }
        },

        onSave: function (oEvent) {
            let oModel = this.getModel(),
                oViewModel = this.getModel("appView");
            oViewModel.setProperty("/busy", true);
            oModel.submitBatch(oModel.sUpdateGroupId).then(
                (oResponse) => {
                    oViewModel.setProperty("/busy", false);

                    MessageToast.show(this.getResourceBundle().getText("msgSaveSuccess"));
                },
                (oError) => {
                    oViewModel.setProperty("/busy", false);

                    MessageToast.error(this.getResourceBundle().getText("msgSaveWrong"), {
                        details: oError.message
                    });
                    console.error("Batch Error:", oError);
                }
            );

            /*if (!this._oSaveDialog) {
                this._oSaveDialog = new Dialog({
                    type: DialogType.Message,
                    title: "{i18n>dialogTitleSaveChanges}",
                    content: new sap.m.Text({ text: "{i18n>dialogTextSaveChanges}" }),
                    buttons: [new Button({
                        text: "{i18n>dialogSaveButtonCreateVersion}",
                        press: function () {
                            this._createNewVersion(oSource);
                            this._oSaveDialog.close();
                            this.getModel("app").setProperty("/mode", "display");
                        }.bind(this)
                    }),
                    new Button({
                        text: "{i18n>dialogSaveButtonReplaceVersion}",
                        press: function () {

                            this.getView().getModel().submitBatch(this.getView().getModel().sUpdateGroupId).then(
                                function (oResponse) {
                                    MessageToast.show(this.getResourceBundle().getText("msgSaveSuccess"));
                                },
                                function (oError) {
                                    MessageToast.error(this.getResourceBundle().getText("msgSaveWrong"), {
                                        details: oError.message
                                    });
                                    console.error("Batch Error:", oError);
                                }
                            );

                            this._oSaveDialog.close();
                            this.getModel("app").setProperty("/mode", "display");
                        }.bind(this)
                    }),
                    new Button({
                        type: ButtonType.Reject,
                        text: "{i18n>dialogSaveButtonCancel}",
                        press: function () {
                            this._oSaveDialog.close();
                        }.bind(this)
                    })
                    ]
                });
            }

            this.getView().addDependent(this._oSaveDialog);
            this._oSaveDialog.open();*/
        },

        _createNewVersion: function (oSource) {
            let oModel = this.getView().getModel(),
                oBinding = oModel.bindList("/Template", undefined, undefined, undefined, { $$updateGroupId: "UpdateGroup" }),
                oObject = JSON.parse(JSON.stringify(oSource.getParent().getBindingContext().getObject())),
                oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel(),
                bReplace = !Device.system.phone,
                oNewVersionObject;

            if (oModel.hasPendingChanges()) {
                oModel.resetChanges();
            }

            var oContext = oBinding.create({
                "TemplateName": oObject.TemplateName,
                "Language": oObject.Language,
                "Version": parseInt(oObject.Version) + 1,
                "Channel": oObject.Channel,
                "Body": oObject.Body,
                "Subject": oObject.Subject
            }, false, false);

            oContext.created().then(function () {
                oModel.refresh();
            }.bind(this), function (oError) {

            });

            oModel.submitBatch(oContext.getUpdateGroupId()).then(function () {
                if (!oModel.hasPendingChanges(oContext.getUpdateGroupId())) {
                    oNewVersionObject = oContext.getObject();
                    MessageToast.show(this.getResourceBundle().getText("msgVersionCreateSuccess"));

                    this.getRouter().navTo("object", {
                        ID: oNewVersionObject.ID,
                        Version: oNewVersionObject.Version,
                        Language: oNewVersionObject.Language,
                        TimeStamp: oNewVersionObject.TimeStamp,
                        Channel: oNewVersionObject.Channel,
                        TemplateName: oNewVersionObject.TemplateName,
                    }, bReplace);

                } else {
                    let aMessage = oMessageModel.getData(),
                        oLastMessage = aMessage[aMessage.length - 1];
                    oModel.resetChanges();
                    sap.m.MessageBox.error(oLastMessage.getMessage());
                }
            }.bind(this)).catch(function (oError) {
                // Errores de timeout, conexión, etc    
            }.bind(this));



        },
        onCloseEdit: function (oEvent) {
             const oModel = this.getModel();
            if (this.getView().getModel().hasPendingChanges(oModel.sUpdateGroupId)) {

                const oBundle = this.getView().getModel("i18n").getResourceBundle();
                const sMessage = oBundle.getText("unsavedChangesMessage");
                const sTitle = oBundle.getText("unsavedChangesTitle");

                MessageBox.warning(sMessage, {
                    title: sTitle,
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === 'OK') {

                            this.getView().getModel().resetChanges(oModel.sUpdateGroupId);
                            this.getModel("app").setProperty("/mode", "display");
                        }

                    }.bind(this)
                });

            } else {
                this.getModel("app").setProperty("/mode", "display");
            }
        },

        onCancel: function (oEvent) {
            const oModel = this.getModel();
            if (this.getView().getModel().hasPendingChanges(oModel.sUpdateGroupId)) {

                const oBundle = this.getView().getModel("i18n").getResourceBundle();
                const sMessage = oBundle.getText("unsavedChangesMessage");
                const sTitle = oBundle.getText("unsavedChangesTitle");

                MessageBox.warning(sMessage, {
                    title: sTitle,
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === 'OK') {

                            this.getView().getModel().resetChanges(oModel.sUpdateGroupId);
                            this.getModel("app").setProperty("/mode", "display");
                        }

                    }.bind(this)
                });

            } else {
                this.getModel("app").setProperty("/mode", "display");
            }
        },

        onDelete: function (oEvent) {
            MessageBox.warning(this.getResourceBundle().getText("msgDeleteTemplateConfirm"), {
                title:this.getResourceBundle().getText("titleDeleteTemplate"),
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                emphasizedAction: MessageBox.Action.OK,
                onClose: function (sAction) {
                    if (sAction === 'OK') {
                        this.getView().getBindingContext().delete("$auto").then(function () {
                            MessageToast.show(this.getResourceBundle().getText("msgDelTemplate"));
                            this.onCloseDetailPress();
                            this.getView().getModel().refresh();
                        }.bind(this), function (oError) {
                            MessageBox.error(oError.message);
                        });

                    }
                }.bind(this)
            });
        },

        onShowVersions: function (oEvent) {
            var oButton = oEvent.getSource(),
                oView = this.getView(),
                oElement = this.getView().getBindingContext().getObject();

            // create popover
            if (!this._pPopover) {
                this._pPopover = Fragment.load({
                    id: oView.getId(),
                    name: "com.nbx.maily.view.fragment.Versions",
                    controller: this
                }).then(function (oPopover) {
                    oView.addDependent(oPopover);
                    return oPopover;
                }.bind(this));
            }
            this._pPopover.then(function (oPopover) {
                let oList = Fragment.byId(oView.getId(), "_IDGenList"),
                    oBinding = oList.getBinding("items"),
                    aFilters = [];

                aFilters.push(new Filter("TemplateName", FilterOperator.Contains, oElement.TemplateName));
                aFilters.push(new Filter("Channel", FilterOperator.Contains, oElement.Channel));
                aFilters.push(new Filter("Language", FilterOperator.Contains, oElement.Language));

                oBinding.filter(aFilters);

                oPopover.openBy(oButton);
            }.bind(this));
        },

        onSelectVersion: function (oEvent) {
            let oObject = oEvent.getSource().getSelectedContexts()[0].getObject(),
                bReplace = !Device.system.phone;

            this.getRouter().navTo("object", {
                ID: oObject.ID,
                Version: oObject.Version,
                Language: oObject.Language,
                TimeStamp: oObject.TimeStamp,
                Channel: oObject.Channel,
                TemplateName: oObject.TemplateName,
            }, bReplace);

        },

        customEMailType: SimpleType.extend("email", {
            formatValue: function (oValue) {
                return oValue;
            },

            parseValue: function (oValue) {
                //parsing step takes place before validating step, value could be altered here
                return oValue;
            },

            validateValue: function (oValue) {
                // The following Regex is only used for demonstration purposes and does not cover all variations of email addresses.
                // It's always better to validate an address by simply sending an e-mail to it.
                var rexMail = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
                if (!oValue.match(rexMail)) {
                   throw new ValidateException(this.getResourceBundle().getText("msgInvalidEmail") + ": '" + oValue + "'");

                }
            }
        }),

        checkIfEmailInString: function (sEmail) {
            return String(sEmail)
                .toLowerCase()
                .match(
                    /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                );
        },

        onVariableSelect: function (oEvent) {
            var sVariable = oEvent.getSource().getBindingContext("variables").getProperty("technicalField");
            var sAlias = oEvent.getSource().getBindingContext("variables").getProperty("alias");
            var sVariableComp = sVariable + sAlias;
            if (!this.aVariablesSelected.includes(sVariableComp)) {
                this.aVariablesSelected.push(sVariableComp);
            } else {
                this.aVariablesSelected.splice(this.aVariablesSelected.indexOf(sVariableComp), 1);
            }
        },

        onSuggest: function (oEvent) {
            var value = oEvent.getParameter("suggestValue");
            clearTimeout(this._delayTimer);
            if (value.length > 1) {
                this._delayTimer = setTimeout(function () {
                    this._onDelayedSuggest(value);
                }.bind(this), 300);
            } else {
                this.getView().byId("searchField").suggest(false);
            }
        },

        onSuggestionDataReceived: function () {
            if (!this._bSearchTriggered) {
                this.getView().byId("searchField").suggest(true);
            }
        },
        _onDelayedSuggest: function (sSuggestValue) {
            if (this._suggestValue !== sSuggestValue) {
                this._suggestValue = sSuggestValue;

                this._oTemplate = this._oTemplate ? this._oTemplate.clone() : this.getView().byId(
                    "suggItem");

                var aFilter = [new sap.ui.model.Filter('SearchString', 'EQ', sSuggestValue)];

                this.getView().byId("searchField").bindAggregation("suggestionItems", {
                    path: "/SearchResult",
                    parameters: {
                        searchParameter: sSuggestValue
                    },
                    filters: aFilter,
                    template: this._oTemplate,
                    events: {
                        dataReceived: this.onSuggestionDataReceived.bind(this)
                    }
                });
            }
        },

        onSearch: function (oEvent) {
            this._bNewSearchFromEmplDetailsTriggered = false;
            var item = oEvent.getParameter("suggestionItem");
            if (item) {
                var oPernr = item.getKey()


            } else if (oEvent.getParameters().clearButtonPressed) {
                // Search field's 'clear' button has been pressed.
                // navigate back to 'OwnData' view
                this._bSearchTriggered = false;
                var sCurrentAssignment = this.getModel("appView").getProperty("/sCurrentAssignmentId");
                this.getRouter().navTo("ownData", {
                    defaultAssignment: sCurrentAssignment
                }, true);

            } else {
                if (oEvent.getParameter("query")) {
                    this._bSearchTriggered = true;

                    clearTimeout(this._delayTimer);

                    var oSearchField = this.getView().byId("searchField");
                    oSearchField.suggest(false);

                    var aFilter = [new sap.ui.model.Filter('SearchString', 'EQ', oEvent.getParameter("query"))];
                    this._oTemplateItem = this._oTemplateItem ? this._oTemplateItem.clone() : this.getView().byId("searchResultTableItem");
                    this.getView().byId("searchResultTable").bindAggregation("items", {
                        path: "/SearchResult",
                        filters: aFilter,
                        template: this._oTemplateItem,
                        events: {
                            //  dataReceived: this.onSuggestionDataReceived.bind(this)
                        }
                    });
                }
            }
        },

        getTestContent: function (oResults) {
            var oContent = new sap.m.VBox();

            this.getView().getModel("testModel").setProperty("/body", oResults.Body);
            this.getView().getModel("testModel").setProperty("/subject", oResults.Subject);

            if (this.getView().getBindingContext().getProperty("Channel") === 'M') {

                oContent.addItem(sap.ui.xmlfragment("com.nbx.maily.view.fragment.Test")),
                    oContent.addItem(new sap.ui.core.HTML({
                        content: this._escapeString(oResults.Body)
                    }))
                oContent.setWidth("80rem");
            } else if (this.getView().getBindingContext().getProperty("Channel") === 'N') {
                oContent.addItem(sap.ui.xmlfragment("com.nbx.maily.view.fragment.NotificationTextTest"));
                oContent.setWidth("40rem");
            }

            return oContent;
        },

        onTest: async function (oEvent) {
            let oModel = this.getView().getModel(),
                oViewModel = this.getModel("appView"),
                oContext = this.getView().getBindingContext(),
                oObject = oContext ? oContext.getObject() : null;

            // Validation: Subject and Body fields are mandatory
            if (!oObject || !oObject.Subject || !oObject.Body || oObject.Subject.trim() === "" || oObject.Body.trim() === "") {
                MessageBox.warning(
                    this.getResourceBundle().getText("testWarningMessage"), {
                        title: this.getResourceBundle().getText("testWarningTitle"),
                        actions: [MessageBox.Action.OK],
                        emphasizedAction: MessageBox.Action.OK
                    }
                 );
                return;
            }

            if (oModel.hasPendingChanges()) {
                oViewModel.setProperty("/busy", true);
                await oModel.submitBatch(this.getView().getModel().sUpdateGroupId);
                oViewModel.setProperty("/busy", false);
                this.getModel("app").setProperty("/mode", "display");
            }

            if (!this.oSelectMail) {

                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.nbx.maily.view.fragment.MailSelect",
                    controller: this
                })
                    .then(function (oDialog) {
                        this.oSelectMail = oDialog;
                        this.getView().addDependent(this.oSelectMail);
                    }.bind(this))
                    .finally(function () {
                        this.oSelectMail.open()
                    }.bind(this));
            } else {
                this.oSelectMail.open();
            }
        },

        onEmailLiveChange: function (oEvent) {
           
            const oInput = oEvent.getSource();
            const oBundle = this.getView().getModel("i18n").getResourceBundle();

            // Trim whitespace from the entered value
            const sValue = oInput.getValue().trim();

            // Basic regular expression for validating email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!sValue) {
                // Set the input state to Error and provide a message
                oInput.setValueState("Error");
                oInput.setValueStateText(oBundle.getText("emailEmptyMessage"));
            }
            else if (!emailRegex.test(sValue)) {
                // Set the input state to Error and provide a message
                oInput.setValueState("Error");
                oInput.setValueStateText(oBundle.getText("emailInvalidMessage"));
            }
            else {
                // Reset the input state to None (no error)
                oInput.setValueState("None");
            }
        },
        

        onMailSelectSend: function (oEvent) {
            const oBundle = this.getView().getModel("i18n").getResourceBundle();
            let oTestModel = this.getView().getModel("testModel"),
                oContext = this.getView().getBindingContext(),
                oObject = oContext.getObject(),
                sBody = oObject.Body,
                sSubject = oObject.Subject,
                aVariables = this.extractWords(sSubject),
                aTokens = [];
            const sEmail = oTestModel.getProperty("/receiverEmail")?.trim();
            const oEmailInput = this.byId("_IDGenInput");

            // Validate empty email
            if (!sEmail) {
                oEmailInput.setValueState("Error");
                oEmailInput.setValueStateText(oBundle.getText("emailEmptyMessage"));
                return;
            }

            aVariables = [...new Set(aVariables.concat(this.extractWords(sBody)))];

            aVariables.forEach(function (sVariable) {
                aTokens.push({
                    Name: sVariable,
                    Value: ""
                });
            }.bind(this));

            oTestModel.setProperty("/Tokens", aTokens);

            this.oSelectMail.close();

            if (aTokens.length > 0) {
                if (!this.oFillTokens) {

                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.nbx.maily.view.fragment.FillTokensDialog",
                    controller: this
                })
                    .then(function (oDialog) {
                        this.oFillTokens = oDialog;
                        this.getView().addDependent(this.oFillTokens);
                        // this.getView().addDependent(this.getView().byId("searchResultTable"));
                    }.bind(this))
                    .finally(function () {
                        this.oFillTokens.open()
                    }.bind(this));
            } else {
                this.oFillTokens.open();
            }
            } else {
                this.onFillTokenConfirm();
            }
        },

        onTokenValueLiveChange: function (oEvent) {
            const oInput = oEvent.getSource();
            const sValue = oInput.getValue().trim();

            if (sValue) {
                // Remove warning when user types something
                oInput.setValueState("None");
            } else {
                // Keep it as warning (optional)
                const oBundle = this.getView().getModel("i18n").getResourceBundle();
                oInput.setValueState("Warning");
                oInput.setValueStateText(oBundle.getText("tokenEmptyWarning"));
            }
        },

        onFillTokenConfirm: function () {
            const oBundle = this.getView().getModel("i18n").getResourceBundle();
            const oTestModel = this.getView().getModel('testModel');
            const oViewModel = this.getModel("appView");
            const aTokens = oTestModel.getProperty("/Tokens");
            const oObject = this.getView().getBindingContext().getObject();
            const oModel = this.getView().getModel();
            const sReceiver = oTestModel.getProperty("/receiverEmail");
            const oTable = this.oFillTokens.getContent()[0];
            const aItems = oTable.getItems();
                

            let bHasEmpty = false;
            aItems.forEach(row => {
                const oInput = row.getCells()[1];
                const sValue = oInput.getValue().trim()
                const sTokenName = row.getCells()[0].getText();
                const token = oTestModel.getProperty("/Tokens").find(t => t.Name === sTokenName);
                
                if (token) {
                    token.Value = sValue;
                    if (!sValue) {
                        bHasEmpty = true;
                        token._warning = true;
                        oInput.setValueState("Warning");
                        oInput.setValueStateText(oBundle.getText("tokenEmptyWarning"));
                    } else {
                        token._warning = false;
                        oInput.setValueState("None");
                    }
                }
            });
            oTestModel.refresh(true);

            if (bHasEmpty) {
                MessageBox.warning(
                    oBundle.getText("tokenEmptyDialogMessage"),
                    {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        onClose: function (oAction) {
                            if (oAction === MessageBox.Action.OK) {
                                this.onSendTestMail(oModel, oObject, sReceiver, aTokens);
                            }
                        }.bind(this)
                    }
                );
            } else {
                this.onSendTestMail(oModel, oObject, sReceiver, aTokens);
            }

        },

        onSendTestMail: function (oModel, oObject, sReceiver, aTokens) {
            const oViewModel = this.getModel("appView");
            const oBundle = this.getView().getModel("i18n").getResourceBundle();
            let oFunction;

            switch (oObject.Channel) {
                case "M":
                    oFunction = oModel.bindContext("/MailHandlerSet(...)");
                    break;
                case "N":
                    oFunction = oModel.bindContext("/NotifHandlerSet(...)");
                    break;
                default:
                    return;
            }

            oFunction.setParameter("Receiver", sReceiver);
            oFunction.setParameter("TemplateId", oObject.ID);
            oFunction.setParameter("Language", oObject.Language);
            oFunction.setParameter("Tokens", aTokens.map(item => ({ id: item.Name, value: item.Value })));

            oViewModel.setProperty("/busy", true);
            oFunction.execute().then(() => {
                oViewModel.setProperty("/busy", false);
                if (oObject.Channel === "M") {
                    MessageToast.show(oBundle.getText("msgMailSentSuc"));
                } else {
                    MessageToast.show(oBundle.getText("msgNotifSentSuc"));
                }
                if (this.oFillTokens) {
                    this.resetMailSelectAndTokens();
                    this.oFillTokens.close();
                }
            }).catch(() => {
                oViewModel.setProperty("/busy", false);
                MessageToast.show(oBundle.getText("msgMailSentFail"));
                if (this.oFillTokens) {
                    this.resetMailSelectAndTokens();
                    this.oFillTokens.close();
                }
            });
        },

        onFillTokenCancel: function (oEvent) {
            this.resetMailSelectAndTokens();
            this.oFillTokens.close();
        },

        onMailSelectCancel: function (oEvent) {
            this.resetMailSelectAndTokens();
            this.oSelectMail.close();
        },
        resetMailSelectAndTokens: function () {
            const oTestModel = this.getView().getModel("testModel");
            const oView = this.getView();

            oTestModel.setProperty("/receiverEmail", "");
            const oEmailInput = this.byId("_IDGenInput");
            if (oEmailInput) {
                oEmailInput.setValue("");
                oEmailInput.setValueState("None");
            }

            const aTokens = oTestModel.getProperty("/Tokens");
            if (aTokens && aTokens.length > 0) {
                aTokens.forEach(token => {
                    token.Value = "";
                    token._warning = false;
                });
                oTestModel.refresh(true);
            }

            if (this.oFillTokens) {
                const oTable = this.oFillTokens.getContent()[0];
                oTable.getItems().forEach(row => {
                    const oInput = row.getCells()[1];
                    oInput.setValue("");
                    oInput.setValueState("None");
                });
            }
        },

        base64coonversionMethod: function (fileMime, fileName, fileDetails, DocNum, fnCallBack) {
            var that = this;
            if (!FileReader.prototype.readAsBinaryString) {
                FileReader.prototype.readAsBinaryString = function (fileData) {
                    var binary = "";
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        var bytes = new Uint8Array(reader.result);
                        var length = bytes.byteLength;
                        for (var i = 0; i < length; i++) {
                            binary += String.fromCharCode(bytes[i]);
                        }
                        that.base64ConversionRes = btoa(binary);
                        sap.ui.getCore().fileUploadArr.push({
                            "DocumentType": DocNum,
                            "MimeType": fileMime,
                            "FileName": fileName,
                            "Content": that.base64ConversionRes,
                        });
                    }.bind(this);
                    reader.readAsArrayBuffer(fileData);
                };
            }
            var reader = new FileReader();
            reader.onload = function (readerEvt) {
                var binaryString = readerEvt.target.result;
                that.base64ConversionRes = btoa(binaryString);

                fnCallBack({
                    "DocumentType": DocNum,
                    "MimeType": fileMime,
                    "FileName": fileName,
                    "Content": that.base64ConversionRes,

                });
            }.bind(this);
            reader.readAsBinaryString(fileDetails);
        },


        extractWords(sString) {
            sString = this._sanitizeString(sString);
            const regex = /{(.*?)}/g;
            let matches = [...sString.matchAll(regex)];

            var aWords = (matches.map(([, x]) => x))
            return aWords;
        },

        _sanitizeString(sString) {
            if (sString === null) {
                sString = "";
            }
            sString = sString.replaceAll('{<span style="background-color: #a8b3bd">', '{');
            sString = sString.replaceAll('{<span style="background-color: #a8b3bd;">', '{');
            return sString = sString.replaceAll('</span>}', '}');
        },

       _escapeString(sString) {
   
            if (!sString) {
                sString = "";
            }
            sString = sString.replaceAll('{', '&#123;');
            sString = sString.replaceAll('}', '&#125;');

            return sString;
        },


        generateBodyTags(aVariables) {

            let oTagsContainer = this.getView().byId("bodyTags");
            oTagsContainer.removeAllItems();
            for (let i = 0; i < aVariables.length; i++) {
                oTagsContainer.addItem(new sap.m.GenericTag({
                    "text": aVariables[i],
                    "press": function (oEvent) {
                    }.bind(this),

                }).addStyleClass("sapUiTinyMargin"));

                var sVariable = aVariables[i];
                if (this.getView().byId("richEditor").getNativeApi()) {
                    var body = this.getView().byId("richEditor").getNativeApi().getContent();
                    var re = new RegExp("(" + sVariable + ")(?![</span>])", "gumi");
                    body = body.replace(re, `<span style="background-color:#a8b3bd;">` + sVariable + `</span>`);
                    this.getView().byId("richEditor").getNativeApi().setContent(body);
                }
            }
        },

        generateSubjectTags(aVariables, sChannel) {
            let oTagsContainer;
            switch (sChannel) {
                case 'M':
                    oTagsContainer = this.getView().byId("emailSubjectTags");
                    break;
                case 'N':
                    oTagsContainer = this.getView().byId("notifSubjectTags");
                default:
                    break;
            }

            oTagsContainer.removeAllItems();
            for (let i = 0; i < aVariables.length; i++) {
                oTagsContainer.addItem(new sap.m.GenericTag({
                    "text": aVariables[i],
                    "press": function (oEvent) {
                    }.bind(this),

                }).addStyleClass("sapUiTinyMargin"));

            }
        },

        generateNotificationTextTags(aVariables) {

            let oTagsContainer = this.getView().byId("notificationTextTags");
            oTagsContainer.removeAllItems();
            for (let i = 0; i < aVariables.length; i++) {
                oTagsContainer.addItem(new sap.m.GenericTag({
                    "text": aVariables[i],
                    "press": function (oEvent) {
                    }.bind(this),

                }).addStyleClass("sapUiTinyMargin"));
            }
        },

        onAddVariableAdd: function (oEvent) {
        },

        onAddVariableClose: function (oEvent) {
            this.addVariableDialog.close();
        },
        onCreateBodyVariable: function (oEvent) {
            this._createVariableDialog(function (oEvent) {


                var sContent = this.getView().byId("richEditor").getNativeApi().getContent();
                var aVariablesText = this.extractWords(sContent);


                var aVariablesSelected = this.aVariablesSelected.filter(function (el) {
                    return !aVariablesText.includes(el);
                });


                aVariablesSelected.forEach(function myFunction(value) {
                    this.getView().byId("richEditor").getNativeApi().insertContent('{' + value + '}');
                }.bind(this));


            }.bind(this));
        },

        onCreateNotificationTextVariable: function (oEvent) {
            this._createVariableDialog(function (oEvent) {


                var sContent = this.getView().byId("notificationTextId").getValue();
                var aVariablesText = this.extractWords(sContent);


                var aVariablesSelected = this.aVariablesSelected.filter(function (el) {
                    return !aVariablesText.includes(el);
                });


                aVariablesSelected.forEach(function myFunction(value) {
                    sContent = sContent + ' ' + '{' + value + '}';
                }.bind(this));

                this.getView().byId("notificationTextId").setValue(sContent);

                this.generateNotificationTextTags(this.extractWords(sContent));


            }.bind(this));
        },

        _createVariableDialog(fnCallBack) {

            Fragment.load({
                name: "com.nbx.maily.view.fragment.VariableSelection",
                controller: this
            }).then(function (oTree) {

                this.oVariableDialog = new Dialog({
                    title: this.getResourceBundle().getText("addVariablesDialogTitle"),
                    content: oTree,
                    beginButton: new Button({
                        type: sap.m.ButtonType.Emphasized,
                        text: this.getResourceBundle().getText("addButtonAddVariable"),
                        press: function (oEvent) {
                            fnCallBack(oEvent);
                            this.oVariableDialog.close();
                        }.bind(this)
                    }),
                    endButton: new Button({
                        text: this.getResourceBundle().getText("cancelButtonAddVariable"),
                        press: function () {
                            this.oVariableDialog.close();
                        }.bind(this)
                    })
                });

                this.getView().addDependent(this.oVariableDialog);
                this.oVariableDialog.open();
            }.bind(this));
        },


        onCreateBodySimpleVariable(oEvent) {
            this._createSimpleVariableDialog(function (oEvent) {
                this.getView().byId("richEditor").getNativeApi().insertContent('{' + oEvent.getSource().getParent().getContent()[0].getValue() + '}');
            });
        },

        onCreateSubjectSimpleVariable(oEvent) {
            this._createSimpleVariableDialog(function (oEvent) {
                this.getView().byId("subjectId").setValue(this.getView().byId("subjectId").getValue() + ' ' + '{' + oEvent.getSource().getParent().getContent()[0].getValue() + '}')
            }.bind(this));
        },

        _createSimpleVariableDialog(fnCallBack) {
            if (this.oSimpleVariableDialog) {
                this.oSimpleVariableDialog.getContent()[0].setValue('');
            }

            this.oSimpleVariableDialog = new Dialog({
                title: this.getResourceBundle().getText("addVariablesDialogTitle"),
                content:
                    new Input({ width: "20rem" }).addStyleClass("sapUiSmallMargin"),
                beginButton: new Button({
                    type: sap.m.ButtonType.Emphasized,
                    text: this.getResourceBundle().getText("addButtonAddVariable"),
                    press: function (oEvent) {
                        fnCallBack(oEvent);
                        this.oSimpleVariableDialog.close();
                    }.bind(this)
                }),
                endButton: new Button({
                    text: this.getResourceBundle().getText("cancelButtonAddVariable"),
                    press: function () {
                        this.oSimpleVariableDialog.close();
                    }.bind(this)
                })
            });

            this.oSimpleVariableDialog.open();
        },

        onAddImage(oEvent) {
            this._createImageDialog();
        },

        _createImageDialog() {
            if (!this.oDefaultDialog) {
                this.oDefaultDialog = new Dialog({
                    title: this.getResourceBundle().getText("addImageDialogTitle"),
                    content:
                        new sap.ui.unified.FileUploader({
                            id: "fileUploader",
                            name: "myFileUpload",
                            uploadUrl: "upload/",
                            change: function (oEvent) {

                                var aFiles = oEvent.getParameters().files;
                                var currentFile = aFiles[0];

                                var fileDetails = currentFile;

                                var mimeDet = fileDetails.type,
                                    fileName = fileDetails.name;

                                this.base64coonversionMethod(mimeDet, fileName, fileDetails, "001", function (oFile) {
                                    sap.ui.getCore().fileUploadArr = [];
                                    sap.ui.getCore().fileUploadArr.push(oFile);
                                }.bind(this));

                            }.bind(this),
                            uploadComplete: "onUploadChange"
                        }).addStyleClass("sapUiSmallMargin"),
                    beginButton: new sap.m.Button({
                        type: sap.m.ButtonType.Emphasized,
                        text: this.getResourceBundle().getText("okButtonText"),
                        press: function () {
                            this.getView().byId("richEditor").getNativeApi().insertContent("<img src='data:image/png;base64," + sap.ui.getCore().fileUploadArr[0].Content + "' />")
                            this.oDefaultDialog.close();
                        }.bind(this)
                    }),
                    endButton: new sap.m.Button({
                        text: this.getResourceBundle().getText("closeButtonText"),
                        press: function () {
                            this.oDefaultDialog.close();
                        }.bind(this)
                    })
                });
            } else {
                this.oDefaultDialog.getContent()[0].clear();
            }
            this.oDefaultDialog.open();
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Event handler when the share by E-Mail button has been clicked
         * @public
         */
        onSendEmailPress: function () {
            var oViewModel = this.getModel("detailView");

            URLHelper.triggerEmail(
                null,
                oViewModel.getProperty("/shareSendEmailSubject"),
                oViewModel.getProperty("/shareSendEmailMessage")
            );
        },

        /* =========================================================== */
        /* begin: internal methods                                     */
        /* =========================================================== */

        /**
     * Handles route matching for the object route and manages unsaved changes.
     *
     *
     * @function
     * @param {sap.ui.base.Event} oEvent - Pattern match event triggered by the router for the object route.
     * @private
     */
        _onObjectMatched: function (oEvent) {
            let oParameters = oEvent.getParameter("arguments");
            this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
            this.aVariablesSelected = []; var sObjectPath = "/Template(ID='" + oParameters.ID + "',Language='" + oParameters.Language + "')";
            this._bindView(sObjectPath);

        },



        /**
         * Binds the view to the object path. Makes sure that detail view displays
         * a busy indicator while data for the corresponding element binding is loaded.
         * @function
         * @param {string} sObjectPath path to the object to be bound to the view.
         * @private
         */
        _bindView: function (sObjectPath) {
            // Set busy indicator during view binding
            let oViewModel = this.getModel("detailView"),
                oContext,
                oObject;

            // If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
            oViewModel.setProperty("/busy", false);

            this.getView().bindElement({
                path: sObjectPath,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oViewModel.setProperty("/busy", true);
                    },
                    dataReceived: function () {
                        oContext = this.getView().getBindingContext();
                        oViewModel.setProperty("/busy", false);
                        if (this.getView().byId("richEditor") && this.getView().byId("richEditor").getNativeApi()) {

                            this.getView().byId("richEditor").getNativeApi().setContent(oContext.getProperty("Body"));
                        }
                        // if (this.getView().byId("richDisplay")) {
                        //     this.getView().byId("richDisplay").setContent("");
                        //     this.getView().byId("richDisplay").setContent(oContext.getProperty("Body"));
                        // }
                      


                        switch (oContext.getProperty("Channel")) {
                            case 'M':
                                this.generateBodyTags(this.extractWords(oContext.getProperty("Body")));
                                this.generateSubjectTags(this.extractWords(oContext.getProperty("Subject")), "M");
                                break;
                            case 'N':
                                this.generateNotificationTextTags(this.extractWords(oContext.getProperty("Body")));
                                this.generateSubjectTags(this.extractWords(oContext.getProperty("Subject")), "N");
                                break;
                            default:
                            // code block
                        }


                    }.bind(this)
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.getView(),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.getRouter().getTargets().display("detailObjectNotFound");
                // if object could not be found, the selection in the list
                // does not make sense anymore.
                this.getOwnerComponent().oListSelector.clearMasterListSelection();
                return;
            }

            var sPath = oElementBinding.getPath(),
                oResourceBundle = this.getResourceBundle(),
                oViewModel = this.getModel("detailView");

            this.getOwnerComponent().oListSelector.selectAListItem(sPath);

        },


        /**
         * Set the full screen mode to false and navigate to list page
         */
        onCloseDetailPress: function () {
            const oModel = this.getModel();
            if (this.getView().getModel().hasPendingChanges(oModel.sUpdateGroupId)) {

                const oBundle = this.getView().getModel("i18n").getResourceBundle();
                const sMessage = oBundle.getText("unsavedChangesMessage");
                const sTitle = oBundle.getText("unsavedChangesTitle");

                MessageBox.warning(sMessage, {
                    title: sTitle,
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.OK,
                    onClose: function (sAction) {
                        if (sAction === 'OK') {
                            this.getView().getModel().resetChanges(oModel.sUpdateGroupId);
                            this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
                            // No item should be selected on list after detail page is closed
                            this.getOwnerComponent().oListSelector.clearMasterListSelection();
                            this.getRouter().navTo("RouteMain", {}, true);
                        }

                    }.bind(this)
                });

            } else {
                this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
                // No item should be selected on list after detail page is closed
                this.getOwnerComponent().oListSelector.clearMasterListSelection();
                this.getRouter().navTo("RouteMain", {}, true);
            }
        },


        /**
         * Toggle between full and non full screen mode.
         */
        toggleFullScreen: function () {
            var bFullScreen = this.getModel("appView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
            this.getModel("appView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
            if (!bFullScreen) {
                // store current layout and go full screen
                this.getModel("appView").setProperty("/previousLayout", this.getModel("appView").getProperty("/layout"));
                this.getModel("appView").setProperty("/layout", "MidColumnFullScreen");
            } else {
                // reset to previous layout
                this.getModel("appView").setProperty("/layout", this.getModel("appView").getProperty("/previousLayout"));
            }
        }
    });

});