sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/Sorter",
    "sap/ui/model/FilterOperator",
    "sap/m/GroupHeaderListItem",
    "sap/ui/Device",
    "sap/ui/core/Fragment",
    "../model/formatter",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
], function (BaseController, JSONModel, Filter, Sorter, FilterOperator, GroupHeaderListItem, Device, Fragment, formatter, MessageToast, MessageBox) {
    "use strict";

    return BaseController.extend("com.nbx.maily.controller.List", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

        /**
         * Called when the list controller is instantiated. It sets up the event handling for the list/detail communication and other lifecycle tasks.
         * @public
         */
        onInit: function () {
            // Control state model
            var oList = this.byId("list"),
                oViewModel = this._createViewModel(),
                // Put down list's original value for busy indicator delay,
                // so it can be restored later on. Busy handling on the list is
                // taken care of by the list itself.
                iOriginalBusyDelay = oList.getBusyIndicatorDelay();


            this._oList = oList;
            // keeps the filter and search state
            this._oListFilterState = {
                aFilter: [],
                aSearch: []
            };

            this.setModel(oViewModel, "listView");
            // Make sure, busy indication is showing immediately so there is no
            // break after the busy indication for loading the view's meta data is
            // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
            oList.attachEventOnce("updateFinished", function () {
                // Restore original busy indicator delay for the list
                oViewModel.setProperty("/delay", iOriginalBusyDelay);
            });

            this.getView().addEventDelegate({
                onBeforeFirstShow: function () {
                    this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
                }.bind(this)
            });

            this.getRouter().getRoute("RouteMain").attachPatternMatched(this._onMasterMatched, this);
            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
            this.getRouter().attachBypassed(this.onBypassed, this);
        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * After list data is available, this handler method updates the
         * list counter
         * @param {sap.ui.base.Event} oEvent the update finished event
         * @public
         */
        onUpdateFinished: function (oEvent) {
            // update the list object counter after new data is loaded
            this._updateListItemCount(oEvent.getParameter("total"));
        },

        /**
         * Event handler for the list search field. Applies current
         * filter value and triggers a new search. If the search field's
         * 'refresh' button has been pressed, no new search is triggered
         * and the list binding is refresh instead.
         * @param {sap.ui.base.Event} oEvent the search event
         * @public
         */
        onSearch: function (oEvent) {
            if (oEvent.getParameters().refreshButtonPressed) {
                // Search field's 'refresh' button has been pressed.
                // This is visible if you select any list item.
                // In this case no new search is triggered, we only
                // refresh the list binding.
                this.onRefresh();
                return;
            }

            var sQuery = oEvent.getParameter("query");

            if (sQuery) {
                this._oListFilterState.aSearch = [new Filter({ path: "TemplateName", operator: FilterOperator.Contains, value1: sQuery.toLowerCase().toString(), caseSensitive: false })];
            } else {
                this._oListFilterState.aSearch = [];
            }
            this._applyFilterSearch();

        },

        /**
         * Event handler for refresh event. Keeps filter, sort
         * and group settings and refreshes the list binding.
         * @public
         */
        onRefresh: function () {
            this._oList.getBinding("items").refresh();
        },

        /**
         * Event handler for the filter, sort and group buttons to open the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the button press event
         * @public
         */
        onOpenViewSettings: function (oEvent) {
            var sDialogTab = "filter";
            if (oEvent.getSource() instanceof sap.m.Button) {
                var sButtonId = oEvent.getSource().getId();
                if (sButtonId.match("sort")) {
                    sDialogTab = "sort";
                } else if (sButtonId.match("group")) {
                    sDialogTab = "group";
                }
            }
            // load asynchronous XML fragment
            if (!this.byId("viewSettingsDialog")) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.nbx.maily.view.fragment.ViewSettingsDialog",
                    controller: this
                }).then(function (oDialog) {
                    // connect dialog to the root view of this component (models, lifecycle)
                    this.getView().addDependent(oDialog);
                    oDialog.addStyleClass(this.getOwnerComponent().getContentDensityClass());
                    oDialog.open(sDialogTab);
                }.bind(this));
            } else {
                this.byId("viewSettingsDialog").open(sDialogTab);
            }
        },

        onAddTemplate: function (oEvent) {
            if (!this.addTemplateDialog) {

                Fragment.load({
                    name: "com.nbx.maily.view.fragment.AddTemplateDialog",
                    controller: this
                })
                    .then(function (oDialog) {
                        this.addTemplateDialog = oDialog;
                        this.getView().addDependent(this.addTemplateDialog);
                    }.bind(this))
                    .finally(function () {
                        this.addTemplateDialog.open()
                    }.bind(this));
            } else {
                this.addTemplateDialog.open();
            }
        },

        onAddTemplateAdd: function (oEvent) {
            const oView = this.getView(),
                oModel = oView.getModel(),
                oViewModel = this.getModel("appView"),
                oMessageManager = sap.ui.getCore().getMessageManager(),
                oMessageModel = oMessageManager.getMessageModel(),
                oList = this.byId("list"),
                oListBinding = oList.getBinding("items");

            // Validate inputs
            const aInputs = [sap.ui.getCore().byId("idTemplateNameInput")];
            let bValidationError = false;
            aInputs.forEach(oInput => bValidationError = this._validateInput(oInput) || bValidationError);
            if (bValidationError) return;

            // Create provisional context
            const oContext = oListBinding.create({
                TemplateName: this.getView().getModel("templateModel").getProperty("/name"),
                Language: this.getView().getModel("templateModel").getProperty("/language"),
                Channel: this.getView().getModel("templateModel").getProperty("/channel"),
                Body: "",
                Subject: ""
            });

            oMessageManager.removeAllMessages();
            oViewModel.setProperty("/busy", true);

            oModel.submitBatch(oContext.getUpdateGroupId())
                .then(function () {
                    oViewModel.setProperty("/busy", false);

                    if (!oModel.hasPendingChanges(oContext.getUpdateGroupId())) {
                        // Close dialog and reset model
                        this.addTemplateDialog.close();
                        MessageToast.show(this.getResourceBundle().getText("msgListSaveSuccess"));

                        const oNewObject = oContext.getObject();

                        // Delete provisional context to avoid duplicates
                        oContext.delete("$auto");

                        // Refresh list to apply sorting
                        oListBinding.refresh();

                        // Select item if visible, else navigate to detail
                        const selectOrNavigate = function () {
                            const oItem = oList.getItems().find(function (item) {
                                return item.getBindingContext() && item.getBindingContext().getProperty("ID") === oNewObject.ID;
                            });

                            if (oItem) {
                                oList.setSelectedItem(oItem, true);
                                this._showDetail(oItem);
                            } else {
                                this.getRouter().navTo("object", {
                                    ID: oNewObject.ID,
                                    Language: oNewObject.Language
                                }, !Device.system.phone);
                            }
                        }.bind(this);

                        if (oList.getItems().length > 0) {
                            selectOrNavigate();
                        } else {
                            oList.attachEventOnce("updateFinished", selectOrNavigate);
                        }
                        this._resetTemplateModel();

                    } else {
                        const aMessages = oMessageModel.getData();
                        const oLastMessage = aMessages[aMessages.length - 1];
                        oModel.resetChanges();
                        sap.m.MessageBox.error(oLastMessage.getMessage());
                    }
                }.bind(this))
                .catch(function (oError) {
                    oViewModel.setProperty("/busy", false);
                    oModel.resetChanges();
            
                }.bind(this));
        },

        onAddTemplateClose: function (oEvent) {
            this.addTemplateDialog.close();
            this._resetTemplateModel();
        },
        _resetTemplateModel: function () {
            const oTemplateModel = this.getView().getModel("templateModel");

            // Reset the template name field
            oTemplateModel.setProperty("/name", "");

            // Reset the language select to its default value
            const oLangSelect = sap.ui.getCore().byId("idTemplateLanguageInput");
            if (oLangSelect) oTemplateModel.setProperty("/language", oLangSelect.getItems()[0].getKey());

            // Reset the channel select to its default value
            const oChannelSelect = sap.ui.getCore().byId("idTemplateChannelInput");
            if (oChannelSelect) oTemplateModel.setProperty("/channel", oChannelSelect.getItems()[0].getKey());
        },

        _validateInput: function (oInput) {
            var sValueState = "None";
            var bValidationError = false;
            var oBinding = oInput.getBinding("value");

            try {
                oBinding.getType().validateValue(oInput.getValue());
            } catch (oException) {
                sValueState = "Error";
                bValidationError = true;
            }

            oInput.setValueState(sValueState);

            return bValidationError;
        },

        onNameChange: function (oEvent) {
            var oInput = oEvent.getSource();
            this._validateInput(oInput);
        },       /**
         * Event handler called when ViewSettingsDialog has been confirmed, i.e.
         * has been closed with 'OK'. In the case, the currently chosen filters, sorters or groupers
         * are applied to the list, which can also mean that they
         * are removed from the list, in case they are
         * removed in the ViewSettingsDialog.
         * @param {sap.ui.base.Event} oEvent the confirm event
         * @public
         */
        onConfirmViewSettingsDialog: function (oEvent) {

            this._applySortGroup(oEvent);
        },

        /**
         * Apply the chosen sorter and grouper to the list
         * @param {sap.ui.base.Event} oEvent the confirm event
         * @private
         */
        _applySortGroup: function (oEvent) {
            var mParams = oEvent.getParameters(),
                sPath,
                bDescending,
                aSorters = [];

            sPath = mParams.sortItem.getKey();
            bDescending = mParams.sortDescending;
            aSorters.push(new Sorter(sPath, bDescending));
            this._oList.getBinding("items").sort(aSorters);
        },

        /**
         * Event handler for the list selection event
         * @param {sap.ui.base.Event} oEvent the list selectionChange event
         * @public
         */
        onSelectionChange: function (oEvent) {
            const oModel = this.getModel();
            var oList = oEvent.getSource(),
                bSelected = oEvent.getParameter("selected");

            // skip navigation when deselecting an item in multi selection mode
            if (!(oList.getMode() === "MultiSelect" && !bSelected)) {

                if (this.getView().getModel().hasPendingChanges(oModel.sUpdateGroupId)) {
                    const oBundle = this.getView().getModel("i18n").getResourceBundle();
                    const sMessage = oBundle.getText("unsavedChangesMessage");
                    const sTitle = oBundle.getText("unsavedChangesTitle");

                    MessageBox.warning(sMessage, {
                        title: sTitle,
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                this.getView().getModel().resetChanges(oModel.sUpdateGroupId);
                                // get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
                                this._showDetail(oEvent.getParameter("listItem") || oList);
                            }
                        }.bind(this)
                    });

                } else {
                    // get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
                    this._showDetail(oEvent.getParameter("listItem") || oList);
                }
            }
        },

        /**
         * Event handler for the bypassed event, which is fired when no routing pattern matched.
         * If there was an object selected in the list, that selection is removed.
         * @public
         */
        onBypassed: function () {
            this._oList.removeSelections(true);
        },

        /**
         * Used to create GroupHeaders with non-capitalized caption.
         * These headers are inserted into the list to
         * group the list's items.
         * @param {Object} oGroup group whose text is to be displayed
         * @public
         * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
         */
        createGroupHeader: function (oGroup) {
            return new GroupHeaderListItem({
                title: oGroup.text,
                upperCase: false
            });
        },

        /**
         * Event handler for navigating back.
         * We navigate back in the browser history
         * @public
         */
        onNavBack: function () {
            // eslint-disable-next-line sap-no-history-manipulation
            history.go(-1);
        },

        /* =========================================================== */
        /* begin: internal methods                                     */
        /* =========================================================== */


        _createViewModel: function () {
            return new JSONModel({
                isFilterBarVisible: false,
                filterBarLabel: "",
                delay: 0,
                title: this.getResourceBundle().getText("listTitleCount", [0]),
                noDataText: this.getResourceBundle().getText("listListNoDataText"),
                sortBy: "TemplateName",
                groupBy: "None"
            });
        },

        _onMasterMatched: function (oEvent) {
            //Set the layout property of the FCL control to 'OneColumn'
            this.getModel("appView").setProperty("/layout", "OneColumn");
        },

        _onObjectMatched: function (oEvent) {
            const oParameters = oEvent.getParameter("arguments");
            const oList = this._oList;

            const selectItem = () => {
                // Search for the item by ID instead of by path
                const oItem = oList.getItems().find(item =>
                    item.getBindingContext() &&
                    item.getBindingContext().getProperty("ID") == oParameters.ID
                );

                if (oItem) {
                    oList.setSelectedItem(oItem, true);
                    oList.scrollToIndex(oList.indexOfItem(oItem));

                    // Navigate to details
                    const oObject = oItem.getBindingContext().getObject();
                    this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
                    this.getRouter().navTo("object", {
                        ID: oObject.ID,
                        Language: oObject.Language
                    }, !Device.system.phone);
                } else {
            // Item not found: deselect all items
            oList.removeSelections(true);
        }
            };

            if (oList.getItems().length > 0) {
                selectItem();
            } else {
                oList.attachEventOnce("updateFinished", selectItem);
            }
        },

        /**
         * Shows the selected item on the detail page
         * On phones a additional history entry is created
         * @param {sap.m.ObjectListItem} oItem selected Item
         * @private
         */
        _showDetail: function (oItem) {
            let oObject = oItem.getBindingContext().getObject();
            var bReplace = !Device.system.phone;
            // set the layout property of FCL control to show two columns
            this.getModel("appView").setProperty("/layout", "TwoColumnsMidExpanded");
            /*this.getRouter().navTo("object", {
                ID : oItem.getBindingContext().getProperty("ID"),
                Version: oItem.getBindingContext().getProperty("Version"),
                Language: oItem.getBindingContext().getProperty("Language"),
                TimeStamp: oItem.getBindingContext().getProperty("TimeStamp"),
            }, bReplace);*/
            this.getRouter().navTo("object", {
                ID: oObject.ID,
                //Version: oObject.Version,
                Language: oObject.Language,
                //TimeStamp: oObject.TimeStamp,
                //Channel: oObject.Channel,
                //TemplateName: oObject.TemplateName,
            }, bReplace);
        },

        /**
         * Sets the item count on the list header
         * @param {integer} iTotalItems the total number of items in the list
         * @private
         */
        _updateListItemCount: function (iTotalItems) {
            // only update the counter if the length is final
            const loadedItems = this._oList.getItems().length; // count of currently loaded items
            const sTitle = this.getResourceBundle().getText("listTitleCount", [loadedItems]);
            this.getModel("listView").setProperty("/title", sTitle);
        },

        /**
         * Internal helper method to apply both filter and search state together on the list binding
         * @private
         */
        _applyFilterSearch: function () {
            var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
                oViewModel = this.getModel("listView");
            this._oList.getBinding("items").filter(aFilters, "Application");
            // changes the noDataText of the list in case there are no filter results
            if (aFilters.length !== 0) {
                oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("listListNoDataWithFilterOrSearchText"));
            } else if (this._oListFilterState.aSearch.length > 0) {
                // only reset the no data text to default when no new search was triggered
                oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("listListNoDataText"));
            }
        },

        /**
         * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
         * @param {string} sFilterBarText the selected filter value
         * @private
         */
        _updateFilterBar: function (sFilterBarText) {
            var oViewModel = this.getModel("listView");
            oViewModel.setProperty("/isFilterBarVisible", (this._oListFilterState.aFilter.length > 0));
            oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("listFilterBarText", [sFilterBarText]));
        }

    });

});