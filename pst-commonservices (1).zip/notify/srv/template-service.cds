using { com.nbx.maily as my } from '../db/schema';
using {com.nbx.types as types} from './types'; 

// service Maily @(path:'/browse') {
@(requires: 'authenticated-user')
service TemplateService {
    @cds.redirection.target: true

    entity Template as projection on my.Templates;
    // entity SearchResult as projection on my.SearchResult;
    entity Send as projection on my.Send;
    entity MailLog as projection on my.NotifyLog;
    //entity CategoriesSet as projection on my.Categories;
    //entity SubCategoriesSet as projection on my.SubCategories;
    //entity TokensSet as projection on my.Tokens;

    //action SendMailSet( ID : my.Send:ID, Receiver: my.Send:Receiver, Body: my.Send:Body ) ;
   
    
    action MailHandlerSet(
        Receiver   : String,
        TemplateId : UUID,
        Language   : String(2),
        //Version    : Int16,
        //ObjectKey  : String(10), 
        //Connectors : String,
        Tokens: array of types.TemplateTokens,
    ) returns String;

    action NotifHandlerSet( 
        Receiver   : String,
        TemplateId : UUID,
        Language   : String(2),
        Tokens: array of types.TemplateTokens, ) returns String;

    //entity LatestTemplates as projection on my.LatestTemplates;
    // entity LatestTemplate as projection on my.LatestTemplates;
    // entity TemplateVersions as projection on my.TemplateVersions;

}