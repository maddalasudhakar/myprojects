@requires: 'authenticated-user'
service MailService {
  action SendMail(
    to: array of String,
    cc: array of String, 
    from: String,
    subject: String,
    @Core.OptionalParameter : { $Type : 'Core.OptionalParameterType' }
    text: String, 
    @Core.OptionalParameter : { $Type : 'Core.OptionalParameterType' }
    html: String, 
    @Core.OptionalParameter : { $Type : 'Core.OptionalParameterType' }
    attachments: array of Attachment 
  ) returns String;

  action SendMailFromTemplate(
    to: array of String,
    cc: array of String, 
    from: String,
    templateID: UUID,
    tokens: array of TemplateTokens
  ) returns String;

  type Attachment {
    filename: String;
    content: String;
    url: String;
    contentType: String;
  }

  type TemplateTokens {
    id: String(50);
    value: String;
  }
}