const cds = require("@sap/cds");
const handlers = require("./handlers");

module.exports = (srv) => {
    srv.on('SendNotificationFromTemplate', handlers.actions.SendNotificationFromTemplate);
    srv.on('CreateNotification', handlers.actions.CreateNotification);
    srv.on('UpdateNotification', handlers.actions.UpdateNotification);
    srv.on('DeleteNotification', handlers.actions.DeleteNotification);
//    srv.on('CreateNotificationType', handlers.actions.CreateNotificationType);
};