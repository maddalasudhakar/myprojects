namespace com.nbx.types;
type TemplateTokens {
      id: String(50);
      value: String;
}

type Language : String(2);
type TemplateName : String(100);
type Subject : String(240);
type Body : LargeString;




