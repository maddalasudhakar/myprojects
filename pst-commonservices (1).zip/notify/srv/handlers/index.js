const functions = require("./functions");
const actions = require("./actions");
const entities = require("./entities");

module.exports = {
    functions,
    actions,
    entities,
}