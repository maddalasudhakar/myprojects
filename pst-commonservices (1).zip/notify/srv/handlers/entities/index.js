const Template = require("./template-set");

module.exports = {
    Template,
}