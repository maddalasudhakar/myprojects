

const cds = require('@sap/cds');

async function afterCreate(req) {
    if (req.Channel === "N") {
        const oNotificationService = await cds.connect.to("NotificationService");
        await oNotificationService.send(
            "CreateNotification",
            {
                ID: req.ID,
                TemplateName: req.TemplateName,
                Language: req.Language,
                Subject: req.Subject,
                Body: req.Body
            }
        );

    }

};

async function afterUpdate(data, req) {
    const oDB = await cds.connect.to('db'),
        oTemplate = oDB.entities['Templates'];

    const aTemplate = await cds.run(SELECT.from(oTemplate).where({ ID: req.ID, Language: req.Language }));
    if (aTemplate[0].Channel === "N") {
        const oNotificationService = await cds.connect.to("NotificationService");
        await oNotificationService.send(
            "UpdateNotification",
            {
                ID: req.ID,
                TemplateName: aTemplate[0].TemplateName,
                Language: req.Language,
                Subject: aTemplate[0].Subject,
                Body: aTemplate[0].Body
            }
        );
 
    }

};

async function beforeDelete(req) {
  const oDB = await cds.connect.to('db'),
        oTemplate = oDB.entities['Templates'];

    const aTemplate = await cds.run(SELECT.from(oTemplate).where({ ID: req.data.ID, Language: req.data.Language }));
     if (aTemplate[0].Channel === "N") {
    req.before('commit', async () => {
 
        const oNotificationService = await cds.connect.to("NotificationService");
        await oNotificationService.send(
            "DeleteNotification",
            {
                ID: req.data.ID,
            }
        );
    })
 }
};

async function beforeCreate(req) {
    
    const { TemplateName, Language, Channel } = req.data;
    const oDB = await cds.connect.to('db'),
    oTemplate = oDB.entities['Templates'];
      
    const existingTemplate = await SELECT.from(oTemplate).where({
      TemplateName,
      Language,
      Channel
    });

    if (existingTemplate.length > 0) {
      return req.error(400, cds.i18n.labels.at('templateAlreadyExistsMessage', { TemplateName, Channel, Language }));
    }

}

module.exports = {
    afterCreate,
    afterUpdate,
    beforeDelete,
    beforeCreate
};