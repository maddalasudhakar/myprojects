const { updateNotification } = require("../../JS/notifications/notifications");

async function UpdateNotification(req) {
  await updateNotification(req.data);
};

module.exports = {
    UpdateNotification,
}