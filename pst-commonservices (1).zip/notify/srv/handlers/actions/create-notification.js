const { createNotification } = require("../../JS/notifications/notifications");

async function CreateNotification(req) {
  await createNotification(req);
};

module.exports = {
    CreateNotification,
}