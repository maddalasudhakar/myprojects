const { deleteNotification } = require("../../JS/notifications/notifications");

async function DeleteNotification(req) {
  await deleteNotification(req.data);
};

module.exports = {
    DeleteNotification,
}