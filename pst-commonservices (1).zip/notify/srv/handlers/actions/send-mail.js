const cds = require('@sap/cds');

/**
 * Kind of destinations allowed
 */
const CONNECTION_PROTOCOLS = {
    MAIL: "mail",
    REST: "rest"
};

/**
 * Destinations allowed
 */
const CONNECTION_KINDS = {
    SENDGRID_REST: "pst-sendgrid",
    MAIL_DESTINATION: "MailDestination",
};

/**
 * Destination configurations
 */
const CONNECTIONS = {
    // Sendgrid rest API
    "pst-sendgrid": {
        method: "POST",
        requires: CONNECTION_KINDS.SENDGRID_REST,
        protocol: CONNECTION_PROTOCOLS.REST,
        template: JSON.stringify({
            personalizations: [
                {
                    to: "RECEIVERS",
                    subject: "SUBJECT",
                    cc: "CC_RECIPIENTS",
                },
            ],
            content: [
                {
                    // type: "text/plain",
                    type: "text/html",
                    value: "MAIL_BODY"
                }
            ],
            from: {
                email: "SENDER_MAIL",
            }
        }),
        templateMapValues: {
            to: { token: "RECEIVERS", isArray: true, replacement: '{"email": <VALUE>}' },
            cc: { token: "CC_RECIPIENTS", isArray: true, replacement: '{"email": <VALUE>}' },
            subject: { token: "SUBJECT", isArray: false, replacement: '<VALUE>' },
            content: { token: "MAIL_BODY", isArray: false, replacement: '<VALUE>' },
            from: { token: "SENDER_MAIL", isArray: false, replacement: '<VALUE>' },
            // fromName: { token: "SENDER_NAME", isArray: false, replacement: '<VALUE>'},
        },
        templateReplacement: "<VALUE>",
        headers: null,
        path: "/mail/send"
    },
};


/**
 * Builds a SendGrid payload template for sending emails. 
 * 
 * @param {Object} parameters - The parameters to build the template.
 * @param {string[]} parameters.to - Array of recipient email addresses.
 * @param {string[]} [parameters.cc] - Optional array of CC email addresses.
 * @param {string} parameters.from - Sender email address.
 * @param {string} parameters.subject - Subject of the email.
 * @param {string} parameters.content - HTML content of the email body.
 * @returns 
 */
function buildSendgridTemplate(parameters) {

    let sengridTemplate = {
        personalizations: [
            {
                to: parameters.to.map(email => ({ email })),
                subject: parameters.subject || ''
            }
        ],
        content: [
            {
                type: "text/html",
                value: parameters.content || ''
            }
        ],
        from: {
            email: parameters.from
        }
    };

    if (parameters.cc && parameters.cc.length > 0) {

        sengridTemplate.personalizations[0].cc = parameters.cc.map(email => ({ email }));
    }


    return JSON.stringify(sengridTemplate);

}

/**
 * Builds a a function to send mails according to the kind of destinaiton provided
 * 
 * @param {*} kind 
 * @returns 
 */
function buildMailCall(kind) {
    const connection = CONNECTIONS[kind];

    if (connection.protocol === CONNECTION_PROTOCOLS.REST) {

        // API REST
        // Function to build
        return async (parameters) => {

            let data = buildSendgridTemplate(parameters);
            // let data = connection.template;
            // const { templateMapValues, templateReplacement } = connection;

            // Conpose according to template
            // for (const key in templateMapValues) {
            //     if (parameters[key]) {
            //         const { token, isArray, replacement } = templateMapValues[key];
            //         if (key === 'cc' && (!parameters[key] || parameters[key].length === 0)) {

            //             const obj = JSON.parse(data);
            //             delete obj.personalizations[0].cc;

            //             const cleanData = JSON.stringify(obj)
            //             console.log(cleanData);
            //         }
            //         if (isArray && Array.isArray(parameters[key])) {
            //             // When an array, get array following pattern before replacing
            //             const aReplace = parameters[key].reduce((acc, curr) => {
            //                 const newEntry = replacement.replaceAll(templateReplacement, `"${curr}"`);
            //                 acc.push(JSON.parse(newEntry));
            //                 return acc;
            //             }, []);


            //             data = data.replace(`"${token}"`, JSON.stringify(aReplace));
            //         } else {
            //             // Just replace token with replacement filled
            //             const newEntry = replacement.replaceAll(templateReplacement, parameters[key]);
            //             data = data.replaceAll(token, newEntry);
            //         }
            //     }
            // }

            console.log(data);
            const service = await cds.connect.to(kind);
            await service.send({
                method: connection.method,
                path: connection.path,
                headers: {
                    'Content-Type': 'application/json'
                },
                // data: JSON.parse('{"personalizations":[{"to":[{"email":"luis.garcia@nubexx.es","name":"Luis Manuel"}],"subject":"Test!"}], "content": [{"type": "text/plain", "value": "Heya!"}],"from":{"email":"test@henkel.com","name":"Henkel test"}}'),
                data,
            });
        }

    } else if (connection.protocol === CONNECTION_PROTOCOLS.MAIL) {

        // SMTP
        const { sendMail } = require('@sap-cloud-sdk/mail-client');
        return async (parameters) => {
            const mailConfig = {
                to: parameters.to,
                //   cc: parameters.cc || [],
                subject: parameters.subject,
                text: parameters.content,
                html: html || '',
                attachments: parameters.attachments || [],
            };
            await sendMail({ destinationName: CONNECTION_KINDS.MAIL_DESTINATION }, [mailConfig]);
        };

    }
};

/**
 * Builds a sending function for SendGrid rest apì and sends the mail
 * 
 * @param {*} parameters 
 */
async function sendMailSendGrid(parameters) {
    const sendEmail = buildMailCall(CONNECTION_KINDS.SENDGRID_REST);
    await sendEmail(parameters);
};

/**
 * Implements SendMail action import
 * 
 * @param {*} req 
 * @returns 
 */
async function SendMail(req) {

    // try {
        // Extract parameters from the request
        const { to, cc, from, subject, text, html, attachments } = req.data;

        if (!to) {
            req.error(400, 'The "to" field is required.');
            return;
        }

        //Validate CC recipients: remove anyone who is already in the main recipients list
        const filteredCc = cc?.filter(email => !to.includes(email));

        await sendMailSendGrid({ to, cc:filteredCc, from, subject, content: text });

        // const mailConfig = {
        //     to: to,
        //     sender: sender || 'default-sender@example.com',
        //     subject: subject || 'No Subject',
        //     text: text || '',
        //     html: html || '',
        //     attachments: [],
        // };

        // if (attachments && Array.isArray(attachments)) {
        //     for (const attachment of attachments) {
        //         if (attachment.url) {
        //             // Download the file from URL
        //             const response = await axios.get(attachment.url, { responseType: 'arraybuffer' });

        //             mailConfig.attachments.push({
        //                 filename: attachment.filename || 'attachment.pdf',
        //                 content: Buffer.from(response.data).toString('base64'),
        //                 contentType: attachment.contentType || 'application/pdf',
        //             });
        //         } else if (attachment.content) {
        //             // Decode and save the Base64 content locally
        //             const decodedContent = Buffer.from(attachment.content, 'base64');

        //             mailConfig.attachments.push({
        //                 filename: attachment.filename || 'attachment.pdf',
        //                 content: decodedContent,
        //                 contentType: attachment.contentType || 'application/pdf',
        //             });
        //         } else {
        //             console.error('Attachment missing required "url" or "content".');
        //         }
        //     }
        // }

        // // Debugging: Log final mailConfig
        // console.log('Final mail configuration:', JSON.stringify(mailConfig, null, 2));

        // // Send the email
        // await sendMail({ destinationName: 'mail_destination' }, [mailConfig]);

        return `Email sent successfully to ${to}`;
    // } catch (error) {
    //     console.error('Error sending email:', error.message);
    //     req.error(500, `Failed to send email: ${error.message}`);
    // }

}


async function addMailLogEntry(oData, oTemplate) {
    const oDB = await cds.connect.to('db'),
        oNotifyLog = oDB.entities['NotifyLog'];

    const entries = oData.to.map(receiver => ({
        TemplateId: oTemplate.ID,
        TemplateLanguage: oTemplate.Language,
        TemplateChannel: oTemplate.Channel,
        TemplateName: oTemplate.TemplateName,
        Sender: oData.from,
        Receiver: receiver,
        Body: oData.text,
        Subject: oData.subject,
    }));

    await INSERT.into(oNotifyLog).entries(entries);

    /*await INSERT.into(oNotifyLog).entries({
     TemplateId: oTemplate.ID,
     TemplateLanguage: oTemplate.Language,
     TemplateChannel: oTemplate.Channel,
     TemplateName: oTemplate.TemplateName,
     Sender: oData.from,
     Receiver: oData.to[0],
     Body: oData.text,
     Subject: oData.subject,
   });*/
}

module.exports = {
    SendMail,
    addMailLogEntry
}