const { sendNotification, addNotificationLogEntry } = require("../../JS/notifications/notifications");

async function SendNotificationFromTemplate(req) {
  const db = await cds.connect.to("db");

  const oTemplate = await db.run(SELECT.one.from("com.nbx.maily.Templates").where({ID: req.data.templateID}));
  await sendNotification(req.data, oTemplate.TemplateName);
  await addNotificationLogEntry(req.data, oTemplate);

};

module.exports = {
  SendNotificationFromTemplate,
}