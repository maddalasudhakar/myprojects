const cds = require("@sap/cds");
const {SendMail, addMailLogEntry} = require("./send-mail");

/**
 * Fills template form app with provided token values
 * 
 * @param {*} template 
 * @param {*} tokens 
 * @returns 
 */
function fillTemplate(template, tokens) {
    const templateFixed = template.replaceAll(`<span style=\"background-color: #a8b3bd;\">`, "")
        .replaceAll(`<span style="background-color: #a8b3bd;">`, "")
        .replaceAll(`</span>`, "")
        .replaceAll(`<span data-teams="true">`, "")
        .replaceAll("\n", "")
        .replaceAll(`&lt;span style="`, "");
    const filledTemplate = tokens.reduce((acc, curr) => {
        return acc.replaceAll(`{${curr.id}}`, curr.value);
    }, templateFixed);
    return filledTemplate;
};

function fillTemplateSubject(template, tokens) {
    const templateFixed = template.replaceAll("\n", "");  

    const filledTemplate = tokens.reduce((acc, curr) => {
        return acc.replaceAll(`{${curr.id}}`, curr.value); 
    }, templateFixed);

    return filledTemplate;
}

/**
 * Sends mail according a template
 * 
 * @param {*} req 
 * @returns 
 */
async function SendMailFromTemplate(req) {

    const { to, cc, from, attachments, templateID, tokens } = req.data;
    const db = await cds.connect.to("db");
    const templates = await db.run(SELECT.one.from("com.nbx.maily.Templates").where({ID: templateID}));
    
    const mail = {
        to: to, 
        cc: cc || [], 
        from: from,
        subject: fillTemplateSubject(templates.Subject, tokens),
        text: fillTemplate(templates.Body, tokens),
        html: templates.html || "",
        // html: templates.html || "",
        // attachments: attachments,
    };
    
    req.data = mail;
    await SendMail(req);
    await addMailLogEntry(mail, templates)
};

module.exports = {
    SendMailFromTemplate,
}