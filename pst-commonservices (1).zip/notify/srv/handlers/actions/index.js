const { CreateNotification } = require("./create-notification");
const { UpdateNotification } = require("./update-notification");
const { DeleteNotification } = require("./delete-notification");
const { SendNotificationFromTemplate } = require("./send-notification-from-template");
const { SendMail } = require("./send-mail");
const { SendMailFromTemplate } = require("./send-mail-from-template");

module.exports = {
    CreateNotification,
    UpdateNotification,
    DeleteNotification,
    SendNotificationFromTemplate,
    SendMail,
    SendMailFromTemplate,
};