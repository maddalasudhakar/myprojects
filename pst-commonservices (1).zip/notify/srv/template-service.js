const cds = require('@sap/cds')
const { createLogEntry,
  // sendMail,
  sendNotif
} = require('./JS/functions');

const handlers = require("./handlers");

class TemplateService extends cds.ApplicationService {
  init() {

    this.on('MailHandlerSet', this.MailHandler);
    this.on('NotifHandlerSet', this.NotifHandler);
    this.after("CREATE", "Template", handlers.entities.Template.afterCreate);
    this.after("UPDATE", "Template", handlers.entities.Template.afterUpdate);
    this.before("DELETE", "Template", handlers.entities.Template.beforeDelete);
    this.before("CREATE", "Template", handlers.entities.Template.beforeCreate);

    return super.init()
  }


  async MailHandler(req) {
    const sPreRegex = '\\{(?:<span style[^>]*?>)?',
      sPostRegex = '(?:</span>)?\\}';
    let sRegex,
      sRegexString,
      sSubject,
      sBody,
      oMailObject = {};

    const oDB = await cds.connect.to('db'),
      oTemplate = oDB.entities['Templates'],
      oInput = req.data,
      aTokens = oInput.Tokens;

    //  Insert call to Data Provider with Connectors required
    const aTemplate = await cds.run(SELECT.one.from(oTemplate).where({ ID: oInput.TemplateId, Language: oInput.Language, Channel: 'M' }));

    //  The variables are replaced with their corresponding values defined in the Tokens array.
    sBody = aTemplate.Body;
    sSubject = aTemplate.Subject;

    if (sBody === null) {
      sBody = ' ';
    }

    if (sSubject === null) {
      sBody = ' ';
    }

    aTokens.forEach(function (oToken) {
      sRegexString = sPreRegex + oToken.id + sPostRegex;
      sRegex = new RegExp(sRegexString);
      sBody = sBody.replace(sRegex, oToken.value);
      sSubject = sSubject.replace(sRegex, oToken.value);
    }.bind(this));

    const DEFAULT_MAIL = "notify_test@henkel.com";

    oMailObject = {
      ID: cds.utils.uuid(), // Genera un UUID automáticamente
      TemplateId: aTemplate.ID,
      TemplateTimeStamp: aTemplate.TimeStamp,
      TemplateLanguage: aTemplate.Language,
      TemplateVersion: aTemplate.Version,
      TemplateChannel: aTemplate.Channel,
      TemplateName: aTemplate.TemplateName,
      Sender: DEFAULT_MAIL,
      Receiver: req.data.Receiver,
      Body: sBody,
      Subject: sSubject,
      Template: aTemplate.ID,
      createdAt: new Date(),
      createdBy: req.user.id,
      modifiedAt: new Date(),
      modifiedBy: req.user.id
    };

    // sendMail(oMailObject, oDB);
    const MailService = await cds.connect.to("MailService");
    await MailService.send(
      "SendMailFromTemplate",
      {
        to: [req.data.Receiver],
        from: DEFAULT_MAIL,
        templateID: req.data.TemplateId,
        tokens: req.data.Tokens
      }
    );
    
    await createLogEntry(oMailObject, oDB);

    return { 'Body': sBody, "Subject": sSubject };

  }

  async NotifHandler(req) {
    const sPreRegex = '\\{(?:<span style[^>]*?>)?',
      sPostRegex = '(?:</span>)?\\}';

    const oInput = req.data,
      aTokens = oInput?.Tokens ?? [];

    let sRegex,
      sRegexString,
      sSubject,
      sBody,
      oMailObject = {};

    const oDB = await cds.connect.to('db'),
      oTemplate = oDB.entities['Templates'];

    /**
     * 
     * Insert call to Data Provider with Connectors required
     * 
     */


    const aTemplate = await cds.run(SELECT.one.from(oTemplate).where({ ID: oInput.TemplateId, Language: oInput.Language, Channel: 'N' }));


    /**
     * The variables are replaced with their corresponding values defined in the Tokens array.
     */


    sBody = aTemplate.Body;
    sSubject = aTemplate.Subject;

    if (sBody === null) {
      sBody = ' ';
    }

    if (sSubject === null) {
      sBody = ' ';
    }

    aTokens.forEach(function (oToken) {
      sRegexString = sPreRegex + oToken.Name + sPostRegex;
      sRegex = new RegExp(sRegexString);
      sBody = sBody.replace(sRegex, oToken.Value);
      sSubject = sSubject.replace(sRegex, oToken.Value);
    }.bind(this));

    const oNotificationService = await cds.connect.to("NotificationService");
    await oNotificationService.send(
      "SendNotificationFromTemplate",
      {
        to: [req.data.Receiver],
        from: req.data.Receiver,
        templateID: req.data.TemplateId,
        templateName: aTemplate.TemplateName,
        tokens: req.data.Tokens
      }
    );

    /*oMailObject = {
      ID: cds.utils.uuid(), // Genera un UUID automáticamente
      TemplateId: aTemplate.ID,
      TemplateTimeStamp: aTemplate.TimeStamp,
      TemplateLanguage: aTemplate.Language,
      TemplateVersion: aTemplate.Version,
      TemplateChannel: aTemplate.Channel,
      TemplateName: aTemplate.TemplateName,
      Sender: 'administration@nubexx.es',
      Receiver: req.data.input.Receiver,
      Body: sBody,
      Subject: sSubject,
      Template: aTemplate.ID,
      createdAt: new Date(),
      createdBy: req.user.id,
      modifiedAt: new Date(),
      modifiedBy: req.user.id
    };*/

    //sendNotif(aTokens);
    //createLogEntry(oMailObject, oDB);

    //return { 'Body': sBody, "Subject": sSubject };

  }

}



module.exports = TemplateService
