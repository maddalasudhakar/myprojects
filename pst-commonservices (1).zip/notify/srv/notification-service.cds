using {com.nbx.types as types} from './types'; 

@requires: 'authenticated-user'
service NotificationService {

  action SendNotificationFromTemplate(
    to: array of String,
    from: String,
    templateID: UUID,
    templateName: types.TemplateName,
    tokens: array of types.TemplateTokens
  ) returns String;

  action CreateNotification(
    ID: String(50),
    TemplateName: types.TemplateName,
    Language: types.Language,
    Subject: types.Subject,
    Body: types.Body
  ) returns String;
 
   action Updatetification(
    ID: String(50),
    TemplateName: types.TemplateName,
    Language: types.Language,
    Subject: types.Subject,
    Body: types.Body
  ) returns String;

    action DeleteNotification(
    ID: String(50)
  ) returns String;

}