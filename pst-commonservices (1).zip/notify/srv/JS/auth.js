const axios = require('axios');
const cds = require('@sap/cds')

const getMailAccessToken = async () => {

  const oDB = await cds.connect.to('db');
  const oSecret = oDB.entities['MailSecret'];

  const SecretData = await cds.run(SELECT.one.from(oSecret));

  const url = SecretData.TokenUrl;
  const clientId = SecretData.ClientID
  const clientSecret = SecretData.ClientSecret;


  try {
    const response = await axios.post(
      url,
      'grant_type=client_credentials',
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
        },
      }
    );
    return response.data.access_token;
  } catch (error) {
    console.error('Error fetching token:', error.response?.data || error.message);
    throw error;
  }
};

const getNotifAccessToken = async () => {

  //const oDB = await cds.connect.to('db');
  //const oSecret = oDB.entities['MailSecret'];

  //const SecretData = await cds.run(SELECT.one.from(oSecret));

  const url = 'https://4cdfd1ectrial.authentication.us10.hana.ondemand.com/oauth/token';
  const clientId = 'sb-your-cap-app!t364173'
  const clientSecret = 'fc79693f-943f-4a1e-9c62-c98680110155$H12yvyxvi4PB6yCVppIXgk27_wMphkeCKLAYbYwwZ9E=';


  try {
    const response = await axios.post(
      url,
      'grant_type=client_credentials',
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Authorization: `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`,
        },
      }
    );
    return response.data.access_token;
  } catch (error) {
    console.error('Error fetching token:', error.response?.data || error.message);
    throw error;
  }
};


module.exports = { getMailAccessToken, getNotifAccessToken };
