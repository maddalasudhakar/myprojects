const { executeHttpRequest } = require("@sap-cloud-sdk/http-client");
const { buildHeadersForDestination } = require("@sap-cloud-sdk/connectivity");
const { getNotificationDestination, formatNotificationVariables } = require("./utils");
const NOTIFICATION_TYPES_API_ENDPOINT = "v2/NotificationType.svc";
const cds = require("@sap/cds");
const LOG = cds.log('notifications');
const NotifyToRest = require('./notifyToRest');

async function createNotification(req) {
  try {
  const notificationDestination = await getNotificationDestination();
  const csrfHeaders = await buildHeadersForDestination(notificationDestination, {
    url: NOTIFICATION_TYPES_API_ENDPOINT
  });

  const sBody = formatNotificationVariables(req.data.Body),
    sSubject = formatNotificationVariables(req.data.Subject);

  const oTemplate = {
    NotificationTypeId: req.data.ID,
    NotificationTypeKey: req.data.TemplateName,
    NotificationTypeVersion: "1",
    Templates: [
      {
        Language: req.data.Language.toLowerCase(),
        TemplatePublic: sSubject,
        TemplateSensitive: sSubject,
        TemplateGrouped: "PST",
        TemplateLanguage: "mustache",
        Subtitle: sBody
      }
    ]
  };

    const oResponse = await executeHttpRequest(notificationDestination, {
      url: `${NOTIFICATION_TYPES_API_ENDPOINT}/NotificationTypes`,
      method: "post",
      data: oTemplate,
      headers: csrfHeaders
    });

    return oResponse.data?.d ?? response;
  } catch (error) {
    const errorMessage = error?.response?.data?.error?.message.value || "";

    if (errorMessage.includes("Active NotificationType with key") && errorMessage.includes("already exists")) {
      return req.error(400, cds.i18n.labels.at('NotificationTypeAlreadyExistsMessage', { errorMessage }));

    }
    else {
      return req.error(400, errorMessage);
    }
  }
}

async function updateNotification(data) {
  const notificationDestination = await getNotificationDestination();
  const csrfHeaders = await buildHeadersForDestination(notificationDestination, {
    url: NOTIFICATION_TYPES_API_ENDPOINT
  });

  const sBody = formatNotificationVariables(data.Body),
    sSubject = formatNotificationVariables(data.Subject);

  const oTemplate = {
    Templates: [
      {
        Language: data.Language.toLowerCase(),
        TemplatePublic: sSubject,
        TemplateSensitive: sSubject,
        TemplateGrouped: "PST",
        TemplateLanguage: "mustache",
        Subtitle: sBody
      }
    ]
  };

  const response = await executeHttpRequest(notificationDestination, {
    url: `${NOTIFICATION_TYPES_API_ENDPOINT}/NotificationTypes(guid'${data.ID}')`,
    method: "patch",
    data: oTemplate,
    headers: csrfHeaders
  });
  return response.status;

}

async function deleteNotification(data) {
  const notificationDestination = await getNotificationDestination();
  const csrfHeaders = await buildHeadersForDestination(notificationDestination, {
    url: NOTIFICATION_TYPES_API_ENDPOINT
  });

  const response = await executeHttpRequest(notificationDestination, {
    url: `${NOTIFICATION_TYPES_API_ENDPOINT}/NotificationTypes(guid'${data.ID}')`,
    method: "delete",
    headers: csrfHeaders
  });
  return response.status;

}

async function sendNotification(data, templateName) {
  const notifyService = new NotifyToRest();
  await notifyService.init();

  const oData = data.tokens.reduce((acc, item) => {
    acc[item.id] = item.value;
    return acc;
  }, {});

  await notifyService.notify(templateName, {
    recipients: data.to,
    data: oData
  });
}

async function addNotificationLogEntry(oData, oTemplate) {
  const oDB = await cds.connect.to('db'),
       oNotifyLog = oDB.entities['NotifyLog'];

       const oVariable = oData.tokens.reduce((acc, item) => {
        acc[item.id] = item.value;
        return acc;
      }, {});

      const replaceVariables = (text, data) => {
        return text.replace(/\{(.*?)\}/g, (_, key) => data[key] ?? `{${key}}`);
      };
      
      const sFinalSubject = replaceVariables(oTemplate.Subject, oVariable);
      const sFinalBody = replaceVariables(oTemplate.Body, oVariable);

      const entries = oData.to.map(receiver => ({
        TemplateId: oTemplate.ID,
        TemplateLanguage: oTemplate.Language,
        TemplateChannel: oTemplate.Channel,
        TemplateName: oTemplate.TemplateName,
        Receiver: receiver,
        Body: sFinalBody,
        Subject: sFinalSubject,
      }));
      
      await INSERT.into(oNotifyLog).entries(entries);
}

module.exports = {
  createNotification,
  updateNotification,
  deleteNotification,
  sendNotification,
  addNotificationLogEntry
};