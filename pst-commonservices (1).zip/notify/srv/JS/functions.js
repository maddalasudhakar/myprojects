const cds = require('@sap/cds')


async function createLogEntry(oEntry, oDB) {
  //const oDB = await cds.connect.to('db'),
  const oMailLog = oDB.entities['MailLog'];

  const result = await INSERT.into(oMailLog).entries({
    ID: cds.utils.uuid(), // Genera un UUID automáticamente
    TemplateId: oEntry.TemplateId,
    TemplateTimeStamp: oEntry.TemplateTimeStamp, // Timestamp actual
    TemplateLanguage: oEntry.TemplateLanguage,
    TemplateVersion: oEntry.TemplateVersion,
    TemplateChannel: oEntry.TemplateChannel,
    TemplateName: oEntry.TemplateName,
    Sender: oEntry.Sender,
    Receiver: oEntry.Receiver,
    Body: oEntry.Body,
    Subject: oEntry.Subject,
    Template_ID: oEntry.Template,
    createdAt: oEntry.createdAt,
    createdBy: oEntry.userId,
    modifiedAt: oEntry.modifiedAt,
    modifiedBy: oEntry.userId
  });

}

// async function sendMail(oMail, oDB) {
//   const axios = require('axios');
//   const oMailSecret = oDB.entities['MailSecret'];
//   const { getMailAccessToken } = require('./auth'); // Importa la función desde auth.js

//   const oUrl = await cds.run(SELECT.one.columns('ServiceURL').from(oMailSecret));

//   // Obtener el token dinámicamente desde auth.js
//   const token = await getMailAccessToken();

//   // Construir los datos del correo
//   const oEmailData = {
//     to: oMail.Receiver,
//     sender: oMail.Sender,
//     subject: oMail.Subject,
//     html: oMail.Body
//   };

//   // Enviar el correo
//   const response = await axios.post(
//     oUrl.ServiceURL,
//     oEmailData,
//     {
//       headers: {
//         Authorization: `Bearer ${token}`, // Usa el token obtenido dinámicamente
//         'Content-Type': 'application/json',
//       },
//     }
//   );

// }

async function sendNotif(oMail) {
  const axios = require('axios');
  const { getNotifAccessToken } = require('./auth'); // Importa la función desde auth.js

  const oUrl = 'https://4cdfd1ectrial-dev-notifications-srv.cfapps.us10-001.hana.ondemand.com/odata/v4/notification/testNotification';

  // Obtener el token dinámicamente desde auth.js
  const token = await getNotifAccessToken();

  // Construir los datos del correo
  const oEmailData = {
    typeKey: 'TestDemoApprovals',
    requestName: oMail[1].Value,
    sbu: oMail[0].Value
  };

  // Enviar el correo
  const response = await axios.post(
    oUrl,
    oEmailData,
    {
      headers: {
        Authorization: `Bearer ${token}`, // Usa el token obtenido dinámicamente
        'Content-Type': 'application/json',
      },
    }
  );

}



// Export the functions for use in other modules
module.exports = {
  createLogEntry,
  // sendMail,
  sendNotif
};