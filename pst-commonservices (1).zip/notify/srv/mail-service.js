const cds = require("@sap/cds");
const handlers = require("./handlers");

module.exports = (srv) => {
    srv.on('SendMail', handlers.actions.SendMail);  
    srv.on('SendMailFromTemplate', handlers.actions.SendMailFromTemplate);  
};