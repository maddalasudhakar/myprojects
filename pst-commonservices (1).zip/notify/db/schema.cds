using {
      managed,
      cuid
} from '@sap/cds/common';

namespace com.nbx.maily;

@assert.unique: {
      // TemplateName: [ID, createdAt, Language]
      TemplateName: [ID, Language]
}
entity Templates : managed, cuid {
      // key createdAt       : Timestamp  @cds.on.insert: $now;
      key Language        : String(2) @mandatory; 
// key Version         : Int16;
      Channel         : String(1) @mandatory;
      TemplateName    : String(100) @mandatory;
      // Version         : Int16;
      IsActiveVersion : String(1);
      TextId          : String(70);
      Subject         : String(240);
      Body            : LargeString;
      //     createdBy       : String     @cds.on.insert: $user;
      //     modifiedAt      : Timestamp  @cds.on.insert: $now   @cds.on.update: $now;
      //     modifiedBy      : String     @cds.on.insert: $user  @cds.on.update: $user;
}

entity Send : managed, cuid {
      Language   : String(2);
      Version    : Int16;
      Sender     : LargeString;
      Receiver   : LargeString;
      ReceiverCc : LargeString;
      Variables  : LargeString;
      Body       : LargeString;
      createdAt  : Timestamp  @cds.on.insert: $now;
      createdBy  : String     @cds.on.insert: $user;
      modifiedAt : Timestamp  @cds.on.insert: $now   @cds.on.update: $now;
      modifiedBy : String     @cds.on.insert: $user  @cds.on.update: $user;
}

// entity Employee : cuid {
//       EmployeeNumber  : String(40);
//       Name            : String(40);
//       LastName        : String(40);
//       City            : String(50);
//       Country         : String(241);
//       OfficeEmail     : String(40);
//       OfficeTelephone : String(8);
//       OfficeLocation  : String(30);

// }

// entity MailSecret : cuid {
//       ServiceURL   : String(100);
//       TokenUrl     : String(100);
//       ClientID     : String(100);
//       ClientSecret : String(100);
// }

// entity SearchResult : managed, cuid {
//       SearchString    : String(40);
//       EmployeeNumber  : String(40);
//       Name            : String(40);
//       PositionText    : String(40);
//       City            : String(50);
//       Country         : String(241);
//       OfficeEmail     : String(40);
//       OfficeTelephone : String(8);
//       OfficeLocation  : String(30);
// }

type Tokens : {
      Name  : String(20);
      Value : String(120);
}


// type MailHandler {
//       Receiver   : String;
//       TemplateId : UUID;
//       Language   : String(2);
//       Version    : Int16;
//       ObjectKey  : String(10);
//       Connectors : LargeString;
//       Tokens     : array of Tokens;
// };

type NofifHandler {
      Receiver   : String;
      TemplateId : UUID;
      Language   : String(2);
      //Version    : Int16;
      //ObjectKey  : String(10);
      //Connectors : LargeString;
      Tokens     : array of Tokens;
};

entity MailLog : managed, cuid {
      key ID                : UUID;
          TemplateId        : UUID;
          TemplateTimeStamp : Timestamp;
          TemplateLanguage  : String(2);
          TemplateVersion   : Int16;
          TemplateChannel   : String(1);
          TemplateName      : String(100);
          Sender            : String(40);
          Receiver          : String(40);
          Status            : String(2);
          Body              : LargeString;
          Subject           : LargeString;
          Template          : Association to Templates;
          createdAt         : Timestamp;
          createdBy         : String;
          modifiedAt        : Timestamp;
          modifiedBy        : String;
};

entity NotifyLog : managed, cuid {
          TemplateId        : UUID;
          TemplateLanguage  : String(2);
          TemplateChannel   : String(1);
          TemplateName      : String(100);
          Sender            : String(40);
          Receiver          : String(40);
          //Status            : String(2);
          Body              : LargeString;
          Subject           : LargeString;
          //Template          : Association to Templates;
};


/*view LatestTemplates as
          select distinct  Version, ID, TimeStamp, Language, Channel, IsActiveVersion, TemplateName, TextId, Subject, Body, createdAt, createdBy, modifiedAt, modifiedBy
              from Templates
    order by Version desc;*/

// view LatestTemplates as
//       select from Templates as Temp
//       inner join LastTemplateVersion as LastTemp
//             on  Temp.ID = LastTemp.ID
//             and Temp.Language     = LastTemp.Language
//             and Temp.createdAt    = LastTemp.createdAt
//       {
//             key Temp.ID,
//             key Temp.createdAt as createdAt,
//             key Temp.Language,
//             LastTemp.Version,
//             Temp.Channel,
//             Temp.TemplateName,
//             Temp.IsActiveVersion,
//             Temp.TextId,
//             Temp.Subject,
//             Temp.Body,
//             Temp.createdBy,
//             Temp.modifiedAt,
//             Temp.modifiedBy,
//       };

// view LastTemplateVersion as
//       select from TemplateVersions {
//             ID,
//             Language,
//             max(Version) as Version: Integer,
//             max(createdAt) as createdAt,
//       }
//       group by
//             ID,
//             Language;


// view TemplateVersions as
//       select from Templates
//       {
//             *,
//             rank() over (partition by ID, Language order by createdAt ASC) as Version: Integer,
//       }

// /**
//  * Extract only last approval dates
//  */
// view ProductsLastApprovalDate as
//     select from ProductsByApprovedAssessment
//     {
//         key product,
//         max(approvalDate) as approvalDate,
//         max(modifiedAt) as modifiedAt
//     }
//     group by product;

// /**
//  * Use last approval dates to extract only last Assessment per product
//  */
// view ProductsByLastApprovedAssessment as
//     select from ProductsLastApprovalDate as lastAssessment
//     inner join ProductsByApprovedAssessment as Assessments
//         on  lastAssessment.product = Assessments.product
//         and lastAssessment.approvalDate = Assessments.approvalDate
//         and lastAssessment.modifiedAt = Assessments.modifiedAt
//     {
//         key Assessments.product as product,
//             Assessments.approvalDate as approvalDate,
//             Assessments.category1 as category1,
//             Assessments.contributor1 as contributor1,
//             Assessments.category2 as category2,
//             Assessments.contributor2 as contributor2,
//             Assessments.category3 as category3,
//             Assessments.contributor3 as contributor3,
//             Assessments.sustClass as sustClass,
//             Assessments.assesor as assesor,
//             Assessments.approver as approver,
//             Assessments.submitter as submitter,
//     };


/*entity Categories : cuid {
      Name           : String(40);
      TechnicalField : String(40);
      Variable       : String(40);
      Type           : String(40);
      Alias          : String(40);
      SubCategories  : Association to many SubCategories on SubCategories.Category = $self;
}

entity SubCategories : cuid {
      Category       : Association to Categories;
      Name           : String(40);
      TechnicalField : String(40);
      Variable       : String(40);
      Type           : String(40);
      Alias          : String(40);
      Tokens         : Association to many Tokens on Tokens.SubCategories = $self;
}

entity Tokens : cuid {
      SubCategories  : Association to SubCategories;
      Name           : String(40);
      TechnicalField : String(40);
      Variable       : String(40);
      Type           : String(40);
      Alias          : String(40);
      Selected       : Boolean;
}
*/
