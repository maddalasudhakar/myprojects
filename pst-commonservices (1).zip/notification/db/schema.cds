using {
    managed,
    cuid
} from '@sap/cds/common';

namespace com.sustainability.notification;

entity AssessmentReminderLog : cuid, managed {
    assessmentId   : UUID;
    assessmentType : String;
    status         : String(2);
    product        : String;
    productType    : String;

}

entity CustomReminderRecipientsByRole : cuid {
    reminderType : String(20) enum {
        ASSESSMENT_OUTDATED
    };
    role         : String(40);
    mail         : String(100);
}

entity MyIdUsers {
    key role  : String;
    key email : String;
}
entity ProductReminderLog   : cuid, managed {
    product                 : String(255);
    productType             : String(20);
    lastAssessment          : Date;
}
 
