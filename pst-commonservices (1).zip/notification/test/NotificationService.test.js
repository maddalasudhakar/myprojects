const cds = require('@sap/cds')

const { GET, POST, expect, axios } = cds.test (__dirname+'/..')
axios.defaults.auth = { username: 'alice', password: '' }

describe('OData APIs', () => {


  it('executes test', async () => {
    const { data } = await POST `/odata/v4/notification/test ${
      {}
    }`
    // TODO finish this test
    // expect(data.value).to...
  })
})
