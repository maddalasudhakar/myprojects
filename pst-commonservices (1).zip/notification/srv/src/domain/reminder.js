const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../utils/batching-utils');
const { ASSESSMENT_TYPE } = require('./assessment');
const MS_PER_DAY = 24 * 60 * 60 * 1000;

const ENTITIES = {
    ASSESSMENT_REMINDER_LOG: 'com.sustainability.notification.AssessmentReminderLog',
    CUSTOM_REMINDER_RECIPIENTS: 'com.sustainability.notification.CustomReminderRecipientsByRole',
    PRODUCT_REMINDER_LOG: 'com.sustainability.notification.ProductReminderLog'
};

 
const MAX_DB_BATCH = 1000;
const MAX_REMINDER_LEVEL = 3;
const SERVICE = {
    ASSESSMENT_NOTIFICATION: 'AssessmentNotificationService'
};
const PATH = {
    NOTIFY_REMINDER_FOR_ASSESSMENT_STATE: '/notifyReminderForAssessmentState',
};

const LEVEL3_ROLES = {
    ASSESSMENT_REMINDER: 'AQR_MANAGER'
};

const REMINDER_TYPES = {
    ASSESSMENT_OUTDATED: 'ASSESSMENT_OUTDATED'
}

/**
 * Reads reminder logs for given assessments in batches.
 * 
 * @param {Object[]} assessments - Array of assessments to fetch logs for
 * @param {string} status - Assessment status to filter logs
 * @returns - Array of reminder logs
 */
async function getAssessmentReminderLogs(assessments, status) {

    // Split large assessment list into batches to avoid DB query limits
    const aBatches = divideArrayInBatches(assessments, MAX_DB_BATCH);
    const db = await cds.connect.to('db');
    let aLogs = [];

    for (const aBatch of aBatches) {
        // Build OR conditions for all assessments in this batch
        const aConditions = aBatch.map(oAssessment => {

            return `(
                assessmentId = '${oAssessment.ID}' 
                AND status = '${status}' 
                AND modifiedAt > '${oAssessment.modifiedAt}'
            )`;
        });


        const sWhere = aConditions.join(' OR ');
        const oWhere = cds.parse.expr(sWhere);

        // Fetch reminder logs newer than the last modification date
        const aBatchLogs = await db.run(
            SELECT.from(ENTITIES.ASSESSMENT_REMINDER_LOG)
                .where(oWhere)
                .columns('assessmentId', 'status', 'modifiedAt')
        );

        aLogs.push(...aBatchLogs);
    }
    return aLogs;

}


/**
 * Filters pending assessments to notify and sends reminders.
 *
 * @param {Object[]} pendingAssessments - Array of pending assessments
 * @param {Object[]} existingLogs - Array of existing reminder logs
 * @param {Object} daysSinceUpdate - Days thresholds per reminder level
 */
async function processAndNotifyAssessments(pendingAssessments, existingLogs, daysSinceUpdate, status) {

    // Connect to the assessment notification service
    const AssessmentNotificationService = await cds.connect.to(SERVICE.ASSESSMENT_NOTIFICATION);
    let aAssessmentsToNotify = [];

    // Determine which assessments need a new reminder
    for (let oAssessment of pendingAssessments) {

        // Get all existing logs for this assessment to know how many reminders were already sent
        const aLogsForAssessment = existingLogs.filter(oLog => oLog.assessmentId === oAssessment.ID);
        const iLevel = aLogsForAssessment.length + 1;
        if (iLevel <= MAX_REMINDER_LEVEL) {
            // Number of days to wait before sending this level of reminder
            const iReminderDays = daysSinceUpdate[`level${iLevel}`];

            // Calculate the date that marks the limit for sending a reminder
            const dExecutionDate = new Date();
            const dDeadlineDate = new Date(dExecutionDate.getTime() - iReminderDays * MS_PER_DAY);

            // Get the date when the assessment was last modified
            const dModifiedAt = new Date(oAssessment.modifiedAt);


            // If last modification is older than the deadline, the assessment should be reminded
            if (dModifiedAt < dDeadlineDate) {
                aAssessmentsToNotify.push({ ...oAssessment, iLevel });

            }
        }


    }

    // Separate single and mass assessments for different notification handling
    const singleAssessments = aAssessmentsToNotify.filter(a => a.assessmentType === ASSESSMENT_TYPE.SINGLE);
    const massAssessments = aAssessmentsToNotify.filter(a => a.assessmentType === ASSESSMENT_TYPE.MASS);

    const results = [];

    // Send notifications for single assessments concurrently
    const singleResults = await Promise.allSettled(singleAssessments.map(async oAssessment => {
        try {
            await AssessmentNotificationService.notifyReminderForAssessmentState({
                sbu: oAssessment.sbu,
                assessmentId: oAssessment.ID,
                assessmentType: ASSESSMENT_TYPE.SINGLE,
                level: oAssessment.iLevel,
                status
            });
            return { ...oAssessment, success: true };
        } catch (err) {
            console.error(`Error SINGLE ${oAssessment.ID}:`, err.message);
            return { ...oAssessment, success: false, error: err.message };
        }
    }));
    results.push(...singleResults.map(r => r.status === 'fulfilled' ? r.value : { success: false, error: r.reason }));

    // Group mass assessments by headerId and reminder level
    const oGroupedMassItems = {};
    for (const oAssessment of massAssessments) {
        oGroupedMassItems[oAssessment.headerId] ??= {};
        oGroupedMassItems[oAssessment.headerId][oAssessment.iLevel] ??= [];
        oGroupedMassItems[oAssessment.headerId][oAssessment.iLevel].push(oAssessment);
    }

    // Send notifications for mass assessments in batches
    const massPromises = [];
    for (const sHeaderId in oGroupedMassItems) {
        for (const sLevel in oGroupedMassItems[sHeaderId]) {
            const aItems = oGroupedMassItems[sHeaderId][sLevel];
            const iLevel = parseInt(sLevel, 10);

            massPromises.push((async () => {
                try {
                    await AssessmentNotificationService.notifyReminderForAssessmentState({
                        sbu: aItems[0].sbu,
                        assessmentId: sHeaderId,
                        assessmentType: ASSESSMENT_TYPE.MASS,
                        level: iLevel,
                        status
                    });
                    return aItems.map(a => ({ ...a, success: true }));
                } catch (err) {
                    console.error(` Error MASS header ${sHeaderId}:`, err.message);
                    return aItems.map(a => ({ ...a, success: false, error: err.message }));
                }
            })());
        }
    }

    const massResults = await Promise.all(massPromises);
    results.push(...massResults.flat());

    return results;

}

/**
 * Saves assessment reminder logs in batches.
 * 
 * @param {Object[]} assessmentsToNotify - Array of assessments to save logs for
 * @param {string} status - Assessment status to record in the logs
 */
async function saveAssessmentReminderLog(assessmentsToNotify, status) {

    // Split the list into smaller batches to avoid database limits
    const aBatchesToInsert = divideArrayInBatches(assessmentsToNotify, MAX_DB_BATCH);

    const db = await cds.connect.to('db');

    // Build log entries for each assessment in the batch
    for (const aBatch of aBatchesToInsert) {

        const aEntries = aBatch.map(oAssessment => ({
            assessmentId: oAssessment.ID,
            assessmentType: oAssessment.assessmentType,
            status,
            product: oAssessment.product,
            productType: oAssessment.productType
        }));

        // Save logs into the reminder log table
        await db.run(
            INSERT.into(ENTITIES.ASSESSMENT_REMINDER_LOG).entries(aEntries)
        );

    }

}


/**
 * Reads reminder logs for given products.
 * 
 * @param {Object[]} aFilterProducts - Array of products to search on reminder logs table
 * @returns - Array of reminder logs
 */
async function getProductReminderLogsForIbs({aFilterIbProducts}) {
    
    const aBatches = divideArrayInBatches(aFilterIbProducts, MAX_DB_BATCH);
    const db = await cds.connect.to('db');
    let aLogs = [];

    for (const aBatch of aBatches) {

        const aConditions = aBatch.map(oProducts => {

            return `(
                product = '${oProducts.materialtNumber}' 
                AND productType = 'IB' 
                AND lastAssessment = '${oProducts.approvalDate}'
            )`;
        });


        const sWhere = aConditions.join(' OR ');
        const oWhere = cds.parse.expr(sWhere);

        const aBatchLogs = await db.run(
            SELECT.from(ENTITIES.PRODUCT_REMINDER_LOG)
                .where(oWhere)
                .columns('product')
        );

        aLogs.push(...aBatchLogs);
    }
    return aLogs;

}

/**
 * Reads reminder logs for given products.
 * 
 * @param {Object[]} aFilterProducts - Array of products to search on reminder logs table
 * @returns - Array of reminder logs
 */
async function getProductReminderLogsForIdhs({aFilterProducts}) {

    const aBatches = divideArrayInBatches(aFilterProducts, MAX_DB_BATCH);
    const db = await cds.connect.to('db');
    let aLogs = [];

    for (const aBatch of aBatches) {

        const aConditions = aBatch.map(oProducts => {

            return `(
                product = '${oProducts.materialtNumber}' 
                AND productType = 'IDH' 
                AND lastAssessment = '${oProducts.approvalDate}'
            )`;
        });


        const sWhere = aConditions.join(' OR ');
        const oWhere = cds.parse.expr(sWhere);

        const aBatchLogs = await db.run(
            SELECT.from(ENTITIES.PRODUCT_REMINDER_LOG)
                .where(oWhere)
                .columns('product')
        );

        aLogs.push(...aBatchLogs);
    }
    return aLogs;

}

/**
 * Saves product reminder logs in batches for idh.
 * 
 * @param {Object[]} aUnnotifiedProducts - Array of products to save logs for
 * @param {string} status - Assessment status to record in the logs
 */
async function saveProductReminderLogForIdh(aUnnotifiedProducts) {

    const aBatchesToInsert = divideArrayInBatches(aUnnotifiedProducts, MAX_DB_BATCH);
    const db = await cds.connect.to('db');

    for (const aBatch of aBatchesToInsert) {

        const aEntries = aBatch.map(oProduct => ({
            product: oProduct.materialtNumber,
            productType: 'IDH',
            lastAssessment: oProduct.approvalDate,
        }));

        await db.run(
            INSERT.into(ENTITIES.PRODUCT_REMINDER_LOG).entries(aEntries)
        );

    }

}

/**
 * Saves product reminder logs in batches for ibs.
 * 
 * @param {Object[]} aUnnotifiedProducts - Array of products to save logs for
 * @param {string} status - Assessment status to record in the logs
 */
async function saveProductReminderLogForIbs(aUnnotifiedProducts) {

    const aBatchesToInsert = divideArrayInBatches(aUnnotifiedProducts, MAX_DB_BATCH);
    const db = await cds.connect.to('db');

    for (const aBatch of aBatchesToInsert) {

        const aEntries = aBatch.map(oProduct => ({
            product: oProduct.materialtNumber,
            productType: 'IB',
            lastAssessment: oProduct.approvalDate,
        }));

        await db.run(
            INSERT.into(ENTITIES.PRODUCT_REMINDER_LOG).entries(aEntries)
        );

    }

}

module.exports = {
    getAssessmentReminderLogs,
    processAndNotifyAssessments,
    saveAssessmentReminderLog,
    ENTITIES,
    LEVEL3_ROLES,
    REMINDER_TYPES,
    getProductReminderLogsForIbs,
    getProductReminderLogsForIdhs,
    saveProductReminderLogForIdh,
    saveProductReminderLogForIbs
};
