
const { sendEmailTemplate, sendNotificationTemplate, getTemplatesByName } = require('../io/notify');
const { getUsers, APPLICATION_NAME } = require('../io/my-id');
const { getAssessmentDataById, ASSESSMENT_STATUS } = require('../domain/assessment');
const { ENTITIES, LEVEL3_ROLES, REMINDER_TYPES } = require('../domain/reminder');
const { default: cds } = require('@sap/cds');

/**
 * Supported roles to get data from
 */
const ROLE = {
    SUBMITTER: 'Submitter',
    ASSESSOR: 'Assessor',
    APPROVER: 'Approver',
    NOTIFICATION: 'Notification',

};

/**
 * Possible actions for which templates will be created
 */
const TEMPLATE_ACTION = {
    SAVE: 'SAVE',
    SUBMIT: 'SUBMIT',
    UNDER_RESUBMISSION: 'UNDER_RESUBMISSION',
    RESUBMIT: 'RESUBMIT',
    APPROVE: 'APPROVE',
    REJECT: 'REJECT',
};

/**
 * Possible Name
 */
const TEMPLATE_NAME = {
    P03_PROCESSING_ERROR: 'ON_P03_PROCESSING_ERROR',
    ADP_NO_PRODUCT_PDP: 'ADP_NO_PRODUCT_PDP',
    ADP_NO_PRODUCT_MOC: 'ADP_NO_PRODUCT_MOC',
    MOC_NEW_SAVE_ASSESSMENT: 'ON_SAVE_NEW_MOC_ASSESSMENT',
    PDP_NEW_SAVE_ASSESSMENT: 'ON_SAVE_NEW_PDP_ASSESSMENT',
    PDP_NEW_SUBMIT_ASSESSMENT: 'ON_SUBMIT_NEW_PDP_ASSESSMENT',
    PRODUCTS_BLOCKING_ASSESSMENT: 'PRODUCTS_BLOCKING_ASSESSMENT',
    PDP_MOC_PRODUCTS_BLOCKED: 'PDP_MOC_PRODUCTS_BLOCKED',
    OUTDATED_REMINDER: 'OUTDATED_REMINDER',
    HEART_SAVED_ASSESSMENT:'ON_SAVE_HEART_ASSESSMENT',
    HEART_SUBMITTED_ASSESSMENT:'ON_SUBMITTED_HEART_ASSESSMENT',
    HEART_PRODUCTS_BLOCKED:'HEART_PRODUCTS_BLOCKED',
    RCPC_SAVED_ASSESSMENT:'ON_SAVE_RCPC_ASSESSMENT',
    RCPC_SUBMITTED_ASSESSMENT:'ON_SUBMITTED_RCPC_ASSESSMENT',
};

/**
 * RC Mismatch template base name
 */
const TEMPLATE_RC_MISMATCH_BASE = 'ON_${ACTION}_RC_MISMATCH_ASSESSMENT';

/**
 * Handler for ADP Project types
 */
const ADP_HANDLER = {
    PDP: ADPNotLinkedForPDP,
    MOC: ADPNotLinkedForMOC
};

/**
 * Supported notificaiton channels and the method to handle them
 */
const NOTIFICATION_CHANNEL_TO_HANDLER = {
    N: sendNotificationTemplate,
    M: sendEmailTemplate,
}

/**
 * Supported assessment types and their corresponding API paths
 */
const ASSESSMENT_TYPE_PATHS = {
    S: "/SingleAssessment",
    M: "/MassAssessment",
};

/**
 * Base names for process types used in role construction
 */
const MY_ID_PROCESS_TYPES = {
    PDP: "PDP_MOC_",
    MOC: "PDP_MOC_"
};

/** Available assessment process types */
const PROCESS_TYPES = {
    PDP: 'PDP',
    MOC: 'MOC',
    RCM: 'RCM',
    MANUAL: '',
    HEART: 'HRT',
    RCPC: 'RCPC',
};

/** Execution mode for development*/
const RUN_MODE_DEV = 'DEV';

/**
 * Function to get the assigned submitters for the given SBU
 * 
 * @param {string} sbu - SBU from which approvers are to be retrieved 
 * @returns {Promise<string[]>} Emails of the users assigned to submitter role by sbu
 */
async function getSubmitterEmailsBySbu(sbu) {
    // const aEmails = await getMailsByRoleAndSbu(sbu, ROLE.SUBMITTER);
    // return aEmails;
};

/**
 * Function to get the assigned approvers for the given SBU
 * 
 * @param {string} sbu - SBU from which approvers are to be retrieved 
 * @returns {Promise<string[]>} Emails of the users assigned to approver role by sbu
 */
async function getApproverEmailsBySbu(sbu) {
    // const aEmails = await getMailsByRoleAndSbu(sbu, ROLE.APPROVER);
    // return aEmails;
};

/**
 * Generic funciton to get data for a role in a SBU
 * 
 * @param {string} sbu - SBU from which submitters are to be retrieved 
 * @param {string} role - Role of the user mails to retrieve 
 * @returns {Promise<string[]>} - Emails of the users assigned to submmiter role by sbu
 */
async function getMailsByRoleAndSbu(sbu, role) {

    // // Entitlement must be determined from sbu and role
    // const sEntitlementName = getEntitlementName(sbu, role);

    // // Emails are retrieved from myID
    // const oMyIdParameters = {
    //     applicationName: APPLICATION_NAME.USER_GET_MAIL,
    //     entitlementName: sEntitlementName,
    //     attribute: 'email',
    // };
    // const aResults = await getUsers(oMyIdParameters);
    // return aResults;
};


/**
 * Composes entitlement name from sbu and role
 * 
 * @param {string} sbu - SBU of the entitlement
 * @param {string} role - Role of the entitlement
 * @returns {string} Name of the entitlement
*/
function getEntitlementName(sbu, role) {
    return "" // TODO calculate when known
};


/**
 * Send notifications
 * 
 * @param {Object} param0 - Parameters to use
 * @param {string} param0.templates - Templates to notify
 * @param {string} param0.recipients - Recipients of the notification
 * @param {Object[]} param0.tokens - List of tokens to fill template
 * @returns 
 */
async function sendNotification({ templates, recipients, ccRecipients, tokens = [] }) {

    // Check run mode to avoid sending to real users in cases determined as non
    // production execution mode
    const oNotificationConfiguration = cds.env['notification-defaults'];
    if (oNotificationConfiguration.mode === RUN_MODE_DEV) {
       const aAllowedRecipients = recipients.filter( item => oNotificationConfiguration.recipients.includes(item));
        recipients = aAllowedRecipients.length > 0 
            ? aAllowedRecipients
            : oNotificationConfiguration.recipients;
            
        if (ccRecipients && Array.isArray(ccRecipients) && ccRecipients.length > 0) {
            const aAllowedCcRecipients = ccRecipients.filter(item => oNotificationConfiguration.recipients.includes(item));
            ccRecipients = aAllowedCcRecipients.length > 0
                ? aAllowedCcRecipients
                : oNotificationConfiguration.recipients;
        }
    }

    // Send messages for every recovered template
    return await Promise.allSettled(
        templates.map(template => {

            if(!recipients || recipients.length === 0 || recipients.every(item => !item)) {
                throw new Error ("No recipients found");
            }

            const fnHandler = NOTIFICATION_CHANNEL_TO_HANDLER[template.Channel];
            return fnHandler({
                recipients,
                ccRecipients,
                tokens,
                template: template.ID,
            });

        })
    )

};

/**
 * Gets the templates corresponding concrete action
 * 
 * @param {string} action - Action of template
 */
async function getTemplatesForAction(action) {

    const sName = `ON_${action}_ASSESSMENT`;
    const aTemplates = await getTemplatesByName(sName);
    return aTemplates;

}

/**
 * Gets the templates corresponding to a reminder level for an assessment
 * 
 * @param {number} level - Reminder Level
 * @param {string} status - Status of the assessment
 * @param {string} templateRole - Template Rol
 * @returns 
 */
async function getTemplatesByReminderLevel(level, status, templateRole) {

    // Get the status name (e.g., DRAFT, SUBMITTED) from the ASSESSMENT_STATUS enum
    const statusName = Object.keys(ASSESSMENT_STATUS).find(key => ASSESSMENT_STATUS[key] === status);
    // Construct the template name using level, status, and role
    const sName = `LEVEL_${level}_REMINDER_${statusName}_${templateRole.toUpperCase()}`;

    // Retrieve all templates matching the constructed name
    const aTemplates = await getTemplatesByName(sName);
    return aTemplates;

}

async function getTemplatesByProductType(productType) {

    // Construct the template name using productType
    const sName = `${productType}_${TEMPLATE_NAME.OUTDATED_REMINDER}`;

    // Retrieve all templates matching the constructed name
    const aTemplates = await getTemplatesByName(sName);
    return aTemplates;

}

/** * Function to get recipients and template role for an assessment by status and reminder level *
* @param {Object} oAssessment - Assessment to process 
* @param {number} level - Reminder level 
* @returns Recipients and template role */

async function getRecipientsAndTemplateRoleByStatus(oAssessment, level, status) {
    const sStatus = status;
    let sRole;
    let aNotificationRecipients = [];
    let aCcRecipients = [];

    // Determine recipients and role based on the assessment status
    switch (sStatus) {
        case ASSESSMENT_STATUS.DRAFT:
            sRole = ROLE.ASSESSOR;
            if (oAssessment.assessor) {
                aNotificationRecipients.push(oAssessment.assessor);
            }
            break;
        case ASSESSMENT_STATUS.SAVED:

            // Assign role based on whether recipients were found
            aNotificationRecipients = oAssessment.toRecipients
                .filter(oRecipient => oRecipient.assessmentStatus === sStatus)
                .map(oRecipient => oRecipient.recipientEmail);


            if (aNotificationRecipients.length > 0) {
                sRole = ROLE.SUBMITTER;

            } else if (oAssessment.assessor) {
                // Default to assessor if no recipients exist
                sRole = ROLE.ASSESSOR;
                aNotificationRecipients.push(oAssessment.assessor);

            } else {
                
                // Determine if the process type is HEART
                const isHeart = oAssessment.processType === PROCESS_TYPES.HEART;

                // Determine if the process type is PDP or MOC
                const isPdpOrMoc = oAssessment.processType === PROCESS_TYPES.PDP || oAssessment.processType === PROCESS_TYPES.MOC;

                // Assign the main role based on process type
                sRole = isHeart ? ROLE.APPROVER : ROLE.ASSESSOR;

                // Assign the role used for notification; for PDP/MOC it's NOTIFICATION, otherwise same as sRole
                const sMyIdRole = isPdpOrMoc ? ROLE.NOTIFICATION : sRole;

                // Fetch users by role for the specific business unit and process type
                const users = await getMyIdUsersByRole({
                    sbu: oAssessment.sbu,
                    processType: oAssessment.processType,
                    role: sMyIdRole
                });

                // Extract email addresses from the user objects for notifications
                aNotificationRecipients = users.map(u => u.email);
            }

            break;

        case ASSESSMENT_STATUS.SUBMITTED:
            sRole = ROLE.APPROVER;

            const aRecipients = oAssessment.toRecipients
                .filter(oRecipient => oRecipient.assessmentStatus === sStatus)
                .map(oRecipient => oRecipient.recipientEmail);

            if (oAssessment.approver) {
                aNotificationRecipients.push(oAssessment.approver);
            }
            else if (aRecipients.length > 0) {
                aNotificationRecipients = aRecipients;

            } else {

                if (oAssessment.processType === PROCESS_TYPES.RCM) {
                    break;
                }

                // Default to myID users if no recipients exist and there is not approver
                const result = await getMyIdUsersByRole({
                    sbu: oAssessment.sbu,
                    processType: PROCESS_TYPES[oAssessment.processType],
                    role: ROLE.APPROVER
                });
                aNotificationRecipients = result.map(recipients => recipients.email);
            }

            break;

        case ASSESSMENT_STATUS.UNDER_RESUBMISSION:
            sRole = ROLE.SUBMITTER;
            if (oAssessment.submitter) {
                aNotificationRecipients.push(oAssessment.submitter);
            }

            break;

        case ASSESSMENT_STATUS.RESUBMITTED:
            sRole = ROLE.APPROVER;
            if (oAssessment.approver) {
                aNotificationRecipients.push(oAssessment.approver);
            }
            break;

    }
    // Special handling for level 3 reminders (escalation)
    if (level === 3) {

        // Move normal recipients to CC
        aCcRecipients.push(...aNotificationRecipients);

        // Fetch additional recipients for level 3 reminders from custom table
        aNotificationRecipients = [];
        const db = await cds.connect.to('db');
        const aExtraRecipients = await db.run(
            SELECT.from(ENTITIES.CUSTOM_REMINDER_RECIPIENTS)
                .where({
                    reminderType: REMINDER_TYPES.ASSESSMENT_OUTDATED,
                    role: LEVEL3_ROLES.ASSESSMENT_REMINDER
                }).columns('mail')
        );

        if (aExtraRecipients?.length > 0) {
            aNotificationRecipients.push(...aExtraRecipients.map(r => r.mail));
        }
    }
    return { aRecipients: aNotificationRecipients, aCcRecipients: aCcRecipients, sRole: sRole };


}

/**
 * Gets messages tokens to provide template
 * 
 * @param {*} param0 
 * @param {string} param0.assessmentId - Id of the assessment for notification
 * @param {string} param0.assessmentType - Type of the assessment (SINGLE/MASS)
 * @returns {Promise<Object[]>} Token array
 */
async function getMessageTokens({ assessmentId, assessmentType }) {

    const oAssessment = await getAssessmentDataById({ assessmentId, type: assessmentType });
    const aTokens = [];
    for (const key in oAssessment) {
        aTokens.push({
            id: key,
            value: ["propagation", "externalCommunication", "idhAssessmentOverwrite", "virtualAssessment"].includes(key)
                ? (oAssessment[key] === true ? "YES" : "NO")
                : (oAssessment[key] || ''),
        })
    }

    // Get the base system URL for constructing links
    const systemUrl = process.env.ASSESSMENT_URL || cds.env?.ASSESSMENT_URL;
    // Construct the direct URL to the assessment
    const basePath = ASSESSMENT_TYPE_PATHS[oAssessment.assesmentType];
    const assessmentUrl = `${systemUrl.replace(/\/$/, '')}/${basePath.replace(/^\/|\/$/g, '')}/${oAssessment.ID}`;

    // Create an HTML anchor tag for the assessment URL so it can be rendered as a clickable link in the notification
    const htmlTag = `<a title="Assessment" href="${assessmentUrl}">Click here</a>`;
    aTokens.push({ id: "pstAssessmentUrl", value: htmlTag });
    return aTokens;

};

/**
 * Gets message tokens from adpProjectNotLinked action
 *
 * @param {string} param0.adpProject - Project Id
 * @param {string} param0.sbu - SBU code
 * @param {string} param0.assessor - Assessor name/id
 * @param {string} param0.submitter - Submitter name/id
 * @returns {Promise<Object[]>} Token array
 */
function getMessageTokensFromActionNotLinked({ adpProject, sbu, assessor, submitter }) {

    const aTokens = [
        { id: "adpProject", value: adpProject || "" },
        { id: "assessor", value: assessor || "" },
        { id: "submitter", value: submitter || "" },
        { id: "sbu", value: sbu || "" }
    ];

    return aTokens;

};


/**
 * Send notification to ADP project PDP type
 * 
 */
async function ADPNotLinkedForPDP({ adpProject, sbu, assessor, submitter }) {

    //Get recipients TODO - CHANGE FOR MYID PDP GROUP
    // const aRecipients = await getApproverEmailsBySbu(sbu);
    const users = await getMyIdUsersByRole({
        sbu,
        processType: PROCESS_TYPES.PDP,
        role: ROLE.NOTIFICATION
    });

    const aRecipients = users.map(users => users.email);

    // Prepare message tokens
    const aTokens = getMessageTokensFromActionNotLinked({ adpProject, sbu, assessor, submitter });
    if (!aTokens || aTokens.length === 0) {
        const err = new Error('No data could be retrieved for assessment');
        err.code = 409;
        throw err;
    }

    // Get template for PDP or MOC
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.ADP_NO_PRODUCT_PDP);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    });

    return `notification sent (PDP)`;
};

/**
 * Send notification to ADP project MOC type
 * 
 */
async function ADPNotLinkedForMOC({ adpProject, sbu, assessor, submitter }) {

    //Get recipients TODO - CHANGE FOR MYID MOC GROUP

    //Get recipients
    // const aRecipients = await getApproverEmailsBySbu(sbu);
    const users = await getMyIdUsersByRole({
        sbu,
        processType: PROCESS_TYPES.MOC,
        role: ROLE.NOTIFICATION,
    });

    const aRecipients = users.map(users => users.email);
    // Prepare message tokens
    const aTokens = await getMessageTokensFromActionNotLinked({ adpProject, sbu, assessor, submitter });
    if (!aTokens || aTokens.length === 0) {
        const err = new Error('No data could be retrieved for assessment');
        err.code = 409;
        throw err;
    }

    // Get template for PDP or MOC
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.ADP_NO_PRODUCT_MOC);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    });

    return `notification sent (MOC)`;
};

/**
 * Gets messages tokens to provide template
 * 
 * @param {*} param0 
 * @param {string} param0.assessmentId - Id of the assessment for notification
 * @param {string} param0.assessmentType - Type of the assessment (SINGLE/MASS)
 * @returns {Promise<Object[]>} Token array
 */
async function mapMessageTokens({ oAssessment }) {

    const aTokens = [];
    for (const key in oAssessment) {
        if (key === "toRecipients") continue;
        aTokens.push({
            id: key,
            value: ["propagation", "externalCommunication", "idhAssessmentOverwrite", "virtualAssessment"].includes(key)
                ? (oAssessment[key] === true ? "YES" : "NO")
                : (oAssessment[key] || ''),
        })
    }

    // Get the base system URL for constructing links
    const systemUrl = process.env.ASSESSMENT_URL || cds.env?.ASSESSMENT_URL;
    // Construct the direct URL to the assessment
    const basePath = ASSESSMENT_TYPE_PATHS[oAssessment.assesmentType];
    const assessmentUrl = `${systemUrl.replace(/\/$/, '')}/${basePath.replace(/^\/|\/$/g, '')}/${oAssessment.ID}`;

    // Create an HTML anchor tag for the assessment URL so it can be rendered as a clickable link in the notification
    const htmlTag = `<a title="Assessment" href="${assessmentUrl}">Click here</a>`;
    aTokens.push({ id: "pstAssessmentUrl", value: htmlTag });
    return aTokens;

};

/**
 * Retrieve users from MyIdUsers table filtered by role.
 *
 * @param {Object} params
 * @param {string} params.sbu - The SBU code 
 * @param {string} params.processType - The process type
 * @param {string} params.role - The role name
 * @returns  List of users matching the constructed role
 */
async function getMyIdUsersByRole({ sbu, processType, role }) {

    let expectedFullRole;

    // Build the full role name based on process type
    const sEnv = process.env.MYID_PREFIX_BY_ENV || cds.env?.MYID_PREFIX_BY_ENV;
    if (!sEnv) {
        throw new Error(`Unknown environment: ${sEnv}`);
    }

    let sBaseName;

    switch (processType) {
        case PROCESS_TYPES.MANUAL:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
        case undefined:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
        case null:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
        case PROCESS_TYPES.MOC:
            sBaseName = MY_ID_PROCESS_TYPES[processType];
            expectedFullRole = `${sEnv}${sBaseName}${sbu}_${role}`;
            break;
        case PROCESS_TYPES.PDP:
            sBaseName = MY_ID_PROCESS_TYPES[processType];
            expectedFullRole = `${sEnv}${sBaseName}${sbu}_${role}`;
            break;
        case PROCESS_TYPES.RCM:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
        case PROCESS_TYPES.HEART:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
        case PROCESS_TYPES.RCPC:
            expectedFullRole = `${sEnv}${sbu}_${role}`;
            break;
    }


    // Connect to the database and retrieve users with the expected role
    const db = await cds.connect.to('db');
    const aUsers = await db.run(
        SELECT.from('MyIdUsers')
            .columns('email')
            .where({ role: expectedFullRole })
    );

    return aUsers;

};

/**
 * Function to get the assigned Submitters for ADP-MOC assessment
 * 
 * @param {string} sbu - SBU from which approvers are to be retrieved 
 * @returns {Promise<string[]>} Emails of the users assigned to submitter role by sbu
 */
async function getSubmitterEmailsForMocBySbu(sbu) {
    // const aEmails = await getMailsByRoleAndSbu(sbu, ROLE.MOC_SUBMITTER);
    // const aEmails = await getMyIdUsersByRole({
    //     sbu,
    //     processType: PROCESS_TYPES.MOC,
    //     role: ROLE.NOTIFICATION
    // });

    const result = await getMyIdUsersByRole({
        sbu,
        processType: PROCESS_TYPES.MOC,
        role: ROLE.NOTIFICATION
    });
    const aEmails = result.map(result => result.email);

    return aEmails;
};

/**
 * Function to get the assigned Submitters for ADP-PDP assessment
 * 
 * @param {string} sbu - SBU from which approvers are to be retrieved 
 * @returns {Promise<string[]>} Emails of the users assigned to submitter role by sbu
 */
async function getSubmitterEmailsForPdpBySbu(sbu) {
    // const aEmails = await getMailsByRoleAndSbu(sbu, ROLE.PDP_SUBMITTER);

    const result = await getMyIdUsersByRole({
        sbu,
        processType: PROCESS_TYPES.PDP,
        role: ROLE.NOTIFICATION
    });
    const aEmails = result.map(result => result.email);
    return aEmails;
};

/**
 * Function to get the assigned approvers for ADP-PDP assessment
 * 
 * @param {string} sbu - SBU from which approvers are to be retrieved 
 * @returns {Promise<string[]>} Emails of the users assigned to submitter role by sbu
 */
async function getApproverEmailsForPdpBySbu(sbu) {
    // const aEmails = await getMailsByRoleAndSbu(sbu, ROLE.PDP_APPROVER);

    const result = await getMyIdUsersByRole({
        sbu,
        processType: PROCESS_TYPES.PDP,
        role: ROLE.NOTIFICATION
    });
    const aEmails = result.map(result => result.email);
    return aEmails;
};

/**
 * Retrieve templates for RC Mismatch Assessment based on action
 *
 * @param {string} [action] - Optional action type 
 * @returns  Templates for the given RC mismatch action
 */
async function getTemplatesForRcMismatchAssessment(action) {
    const templateName = TEMPLATE_RC_MISMATCH_BASE.replace('${ACTION}', action);

    const templates = await getTemplatesByName(templateName);
    return templates;
}


module.exports = {
    TEMPLATE_ACTION,
    TEMPLATE_NAME,
    getMessageTokens,
    getTemplatesForAction,
    ADP_HANDLER,
    getSubmitterEmailsBySbu,
    getApproverEmailsBySbu,
    sendNotification,
    getRecipientsAndTemplateRoleByStatus,
    getTemplatesByReminderLevel,
    getSubmitterEmailsForMocBySbu,
    getSubmitterEmailsForPdpBySbu,
    getApproverEmailsForPdpBySbu,
    mapMessageTokens,
    getMyIdUsersByRole,
    getTemplatesByProductType,
    ROLE,
    getTemplatesForRcMismatchAssessment,
    PROCESS_TYPES,
    ASSESSMENT_TYPE_PATHS,
}