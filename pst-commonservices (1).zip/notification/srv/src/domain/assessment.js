const { getMassAssessmentHeaderById, getSingleAssessmentById, getItemById, getPendingAssessmentsByStatus, getNotificationRecipients } = require('../io/pst');

/**
 * Possible status of an assessment
 */
const ASSESSMENT_STATUS = {
    DRAFT: "91",
    SAVED: "01",
    SUBMITTED: "02",
    UNDER_RESUBMISSION: "03",
    RESUBMITTED: "04",
    APPROVED: "05",
    REJECTED: "06",
    UNDER_REVIEW: "07",
    FINALIZED: "08",
};

const ASSESSMENT_TYPE = {
    SINGLE: 'SINGLE',
    MASS: 'MASS'
};

/**
 * Maps type of assessment to handler to use
 */
const TYPE_TO_HANDLER = {
    GET_BY_ID: {
        MASS: getMassAssessmentHeaderById,
        SINGLE: getSingleAssessmentById,
        BY_ID: getItemById
    },
    GET_NOTIFICATION_RECIPIENTS: getNotificationRecipients
};


/**
 * Assessment status codes
 */
const ASSESSMENT_STATUS_CODES = {
    SAVED: '01',
    SUBMITTED: '02'
    }

/**
 * Generic handler to retrieve assessment data
 * 
 * @param {Object} param0 - Parameters to use
 * @param {string}: param0.assessmentId - ID of assessment
 * @param {string}: param0.type - Type of assessment
 * @param {string[]} [param0.expand=[]] Expand fields in the query
 * @returns {Promise<Object>} - Assessment data
 */
async function getAssessmentDataById({ assessmentId, type, expand = [] }) {

    const fnGetAssessmentById = TYPE_TO_HANDLER.GET_BY_ID[type];
    const oResult = await fnGetAssessmentById({ assessmentId, expand });

    return oResult;

};


/**
 * Generic handler to retrieve pending assessments filtered by status 
 * 
 * @param {Object} param0 - Parameters
 * @param {string} param0.status - Status to filter
 * @param {Object} param0.daysSinceUpdate - - { level1, level2, level3 }
 * @returns {Promise<Object>} - Pending assessments
 */

async function getPendingAssessments({ status, daysSinceUpdate }) {
    const oResult = await getPendingAssessmentsByStatus({ status, daysSinceUpdate });

    return oResult;
};

/**
 * Generic handler to retrieve assessment data
 * 
 * @param {Object} param0 - Parameters to use
 * @param {string}: param0.assessmentId - ID of assessment
 * @param {string}: param0.status - Status of assessment
 * @returns {Promise<Object>} - Assessment data
 */
async function getNotificationRecipientsFromPst({ assessmentId, status }) {

    const fnGetAssessmentById = TYPE_TO_HANDLER.GET_NOTIFICATION_RECIPIENTS;
    const oResult = await fnGetAssessmentById({assessmentId, status});

    return oResult;

};


module.exports = {
    ASSESSMENT_STATUS_CODES,
    getAssessmentDataById,
    getNotificationRecipientsFromPst,
    getPendingAssessments,
    ASSESSMENT_STATUS,
    ASSESSMENT_TYPE
};