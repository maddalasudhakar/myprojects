const cds = require('@sap/cds');

/**
 * paths to use when calling different endpoints
 */
const PATH = {
    USER: '/',
};

/**
 * HTTP methods
 */
const HTTP_METHOD = {
    GET: 'GET',
};

/**
 * Required services to connect
 */
const SERVICE = {
    USER: 'pst-myid-users',
};

/**
 * Valid application names
 */
const APPLICATION_NAME = {
    USER_GET_MAIL: "", // TODO - ADD WHEN PROVIDED
};

/**
 * Method for generic calls to myID user endpoint
 * 
 * @param {Object} params Filter parameters
 * @param {string} params.applicationName - The name of the application to query
 * @param {string} params.entitlementName - The name of the entitlement the users must have
 * @param {string} params.displayAttribute - The attributes to return
 * @returns {Promise<string[] | null>} Query results
 */
async function getUsers({applicationName, entitlementName, displayAttribute}) {
    
    const MyIdUserService = await cds.connect.to(SERVICE.USER);

    const result = await MyIdUserService.send({
        method: HTTP_METHOD.GET, 
        path: PATH.USER, 
        data: {
            // applicationName: 'APP-40257',
            applicationName, //, //: 'APP-40257 - Sustainability Portfolio Evaluation on Environmnetal Data (SPEED)',
            entitlementName, //: 'APP-PST_DEV/QUA_ACC_Assessor',
            displayAttribute, // 'email'
        }
    
    })

    return result;

};

module.exports = {
    getUsers,
    APPLICATION_NAME,
}