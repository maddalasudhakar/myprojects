const cds = require('@sap/cds');

/**
 * paths to use when calling different endpoints
 */
const PATH = {
    EMAIL_FROM_TEMPLATE: 'odata/v4/mail/SendMailFromTemplate',
    NOTIFICATION_FROM_TEMPLATE: 'odata/v4/notification/SendNotificationFromTemplate',
    TEMPLATE: 'odata/v4/template/Template',
};

/**
 * HTTP methods
 */
const HTTP_METHOD = {
    GET: 'GET',
    POST: 'POST',
};

/**
 * Required services to connect
 */
const SERVICE = {
    NOTIFY: 'notify'
};

/**
 * Generic mail to use as sender
 */
const GENERIC_SENDER = 'sustainability-notifications@henkel.com';

/**
 * Generic function call for notify
 * 
 * @param {Object} param0 - Call parameters
 * @param {string} param0.method - Http method to apply
 * @param {string} param0.path - Path to resource
 * @param {string} param0.data - Body data if applies  
 * @returns {Promise} Returning result of call
 */
async function notifyCall({ method, path, data = {} }) {

    const notifyService = await cds.connect.to(SERVICE.NOTIFY);
    return await notifyService.send({
        method,
        path,
        data,
    })

};

/**
 * Sends email using template to a list of recipients
 * 
 * @param {Object} params
 * @param {str[]} params.recipients - Email list of recipients
 * @param {Object[]} params.tokens - Tokens for filling template of email
 * @param {string} param.template - Notify template to use
 */
async function sendEmailTemplate({ recipients, ccRecipients, tokens = [], template }) {

    const oBody = {
        to: recipients,
        cc: ccRecipients,
        from: GENERIC_SENDER,
        templateID: template,
        tokens: tokens,
    };

    await notifyCall({
        method: HTTP_METHOD.POST,
        path: PATH.EMAIL_FROM_TEMPLATE,
        data: oBody,
    });

};

/**
 * Sends notification using template to a list of recipients
 * 
 * @param {Object} params
 * @param {str[]} params.recipients - Email list of recipients
 * @param {Object[]} params.tokens - Tokens for filling template of email
 * @param {string} param.template - Notify template to use
 */
async function sendNotificationTemplate({ recipients, ccRecipients, tokens = [], template }) {

    const oBody = {
        to: recipients,
        cc: ccRecipients,
        from: GENERIC_SENDER,
        templateID: template,
        tokens: tokens,
    };

    await notifyCall({
        method: HTTP_METHOD.POST,
        path: PATH.NOTIFICATION_FROM_TEMPLATE,
        data: oBody,
    });

};

/**
 * Call template service to query template
 * 
 * @param {string} name - Tenokate name to use as filter 
 */
async function getTemplatesByName(name) {

    const sPath = `${PATH.TEMPLATE}?$filter=TemplateName eq '${name}'`;
    return await notifyCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });

};

module.exports = {
    sendEmailTemplate,
    sendNotificationTemplate,
    getTemplatesByName
};