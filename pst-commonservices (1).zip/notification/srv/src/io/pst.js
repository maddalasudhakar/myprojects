const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../../src/utils/batching-utils');
/**
 * paths to use when calling different endpoints
 */
const PATH = {
    MASS_ASSESSMENT_HEADER: '/odata/v4/sustainability/management/MassAssessmentHeader',
    SINGLE_ASSESSMENT: '/odata/v4/sustainability/management/SingleAssessment',
    PRODUCT_BY_ITEM_ID: '/odata/v4/sustainability/management/ProductsByAssessment',
    NOTIFICATION_RECIPIENTS: '/odata/v4/sustainability/management/NotificationRecipients',
    ASSESSMENT_ITEM: '/odata/v4/sustainability/management/MassAssessmentItems', // TODO - CHANGE BY A NEW PATH TO READ ALL ITEMS
    PRODUCTS_BY_ASSESSMENT: '/odata/v4/sustainability/management/ProductsByAssessment',
    IB_PRODUCTS: '/odata/v4/sustainability/management/Ib',
    IDH_PRODUCTS: '/odata/v4/sustainability/management/Idh',
    IB_IDH_RELATIONSHIP: '/odata/v4/sustainability/management/IbIdhRelationship',
    CHECK_PRODUCT_IN_ASSESSMENT: '/odata/v4/sustainability/management/checkProductInAssessment',
};

/**
 * HTTP methods
 */
const HTTP_METHOD = {
    GET: 'GET',
    POST: 'POST',
};

/**
 * Required services to connect
 */
const SERVICE = {
    PST: 'pst-sustainability',
};

const MAX_DB_BATCH = 1000;

/**
 * Generic function call for PST
 * 
 * @param {Object} param0 - Call parameters
 * @param {string} param0.method - Http method to apply
 * @param {string} param0.path - Path to resource
 * @param {string} param0.data - Body data if applies  
 * @returns {Promise} Returning result of call
 */
async function pstCall({ method, path, data = {} }) {

    const pstService = await cds.connect.to(SERVICE.PST);
    return await pstService.send({
        method,
        path,
        data,
    })

};

/**
 * Get mass assessment header data for a mass assessment header searching by ID
 * 
 * @param {Object} param0 Parameters
 * @param {string} param0.assessmentId ID of mass assessment header to retrieve
 * @param {string[]} [param0.expand=[]] Expand fields in the query
 * @returns 
 */
async function getMassAssessmentHeaderById({ assessmentId, expand = [] }) {

    let sPath = `${PATH.MASS_ASSESSMENT_HEADER}(ID=${assessmentId})`;

    if (expand.length > 0) {
        sPath += `?$expand=${expand.join(',')}`;
    }

    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });

};

/**
 * Get mass assessment header data for a single assessment searching by ID
 * 
 * @param {Object} param0 Parameters
 * @param {string} param0.assessmentId ID of single assessment to retrieve 
 * @param {string[]} [param0.expand=[]] Expand fields in the query
 * @returns 
 */
async function getSingleAssessmentById({ assessmentId, expand = [] }) {

    let sPath = `${PATH.SINGLE_ASSESSMENT}(ID=${assessmentId})`;

    if (expand.length > 0) {
        sPath += `?$expand=${expand.join(',')}`;
    }

    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });

};

/**
 * Get item product date searching by ID
 * 
 * @param {Object} param0 Parameters
 * @param {string} param0 ID item of prdcut in assessment 
 * @returns 
 */
async function getItemById({ assessmentId }) {

    const sPath = `${PATH.PRODUCT_BY_ITEM_ID}(ID=${assessmentId})`;
    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });

};

/**
 * Get recipients by assessmentId and satatus
 * 
 * @param {Object} param0 Parameters
 * @param {string} param0 assessmentId item of prodcut in assessment 
 * @param {string} param0 status of the assessment 
 * @returns 
 */
async function getNotificationRecipients({assessmentId, status}) {
    
    const filter = `assessmentId eq ${assessmentId} and assessmentStatus eq '${status}'`;
    const sPath = `${PATH.NOTIFICATION_RECIPIENTS}?$filter=${encodeURIComponent(filter)}`;
    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });
    
}
/**
 * Get pending assessments filtered by status and last modification date
 * 
 * @param {Object} param0 - Parameters
 * @param {string} param0.status - Status to filter 
 * @param {Object} param0.daysSinceUpdate - { level1, level2, level3 }
 * @returns {Promise} Returning result of call
 */
async function getPendingAssessmentsByStatus({ status, daysSinceUpdate }) {

    // Calculate the date before which assessments are considered pending
    const dDateLimit = new Date();
    // Use level1 to fetch all assessments that may need any reminder
    dDateLimit.setDate(dDateLimit.getDate() - daysSinceUpdate.level1);
    const sIsoDate = dDateLimit.toISOString();

    // Build API path to fetch assessments with the given status and older than limit
    const sPath = `${PATH.PRODUCTS_BY_ASSESSMENT}?$filter=status eq '${status}' and modifiedAt lt ${sIsoDate}`;

    // Make the API call to fetch the pending assessments
    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath,
    });
}

/**
 * Get IB Products filtered by approvalDate
 *
 * @param {Object} param0 - Parameters
 * @param {Object} param0.approvalDate - Date
 * @returns {Promise} Returning result of call
 */
async function getApprovedIbProductsByApprovalDate(approvalDate) {

    const sPath = `${PATH.IB_PRODUCTS}?$filter=approvalDate lt ${approvalDate} and approver ne ''`;
 
    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath
    })
 
}
 
/**
 * Get IDH Products filtered by approvalDate
 *
 * @param {Object} param0 - Parameters
 * @param {Object} param0.approvalDate - Date
 * @returns {Promise} Returning result of call
 */
async function getManuallyMaintainedApprovedIdhProductsByApprovalDate(approvalDate) {
 
    const sPath = `${PATH.IDH_PRODUCTS}?$filter=approvalDate lt ${approvalDate} and approver ne '' and manualMaintenanceFlag eq true`;
 
    return await pstCall({
        method: HTTP_METHOD.GET,
        path: sPath
    })
 
}
 
/**
 * Get IB and IDH Products Relationship filtered by IB material number
 *
 * @param {Object} param0 - Parameters
 * @param {Object} param0.aIbMaterialNumbers - IB Material Number to filter
 * @returns {Promise} Returning result of call
 */
async function getIdhRelatedToIb({aIbMaterialNumbers}) {

    const aBatches = divideArrayInBatches(aIbMaterialNumbers, 10);
    const aAllProductRelationShips = [];
    
    for (const aBatch of aBatches) {

        const sFilter = aBatch.map(product => `AI_PRODUCT_KEY eq '${product}'`).join(' or ');
        const sPath = `${PATH.IB_IDH_RELATIONSHIP}?$filter=${sFilter}`;

        const aProductRelationShip = await pstCall({
            method: HTTP_METHOD.GET,
            path: sPath
        });

        aAllProductRelationShips.push(...aProductRelationShip);
    }

    return aAllProductRelationShips;
    
}


/**
 * Get IDH Products filtered by IDH material key and propagation
 *
 * @param {Object} param0 - Parameters
 * @param {Object} param0.aIdhMaterialKeys - IDH Material Key to filter
 * @returns {Promise} Returning result of call
 */
async function getIdhProductsByMaterialKeyAndPropagation({aIdhMaterialKeys, propagation}) {

    const aBatches = divideArrayInBatches(aIdhMaterialKeys, 10);
    const aAllIdhProducts = [];

    for (const aBatch of aBatches) {
        const sFilterMaterials = aBatch.map(key => `materialtNumber eq '${key}'`).join(' or ');
        const sFilter = `manualMaintenanceFlag eq ${propagation} and (${sFilterMaterials})`;
        const sPath = `${PATH.IDH_PRODUCTS}?$filter=${sFilter}`;

        const aIdhProducts = await pstCall({
            method: HTTP_METHOD.GET,
            path: sPath
        });

        aAllIdhProducts.push(...aIdhProducts);
    }

    return aAllIdhProducts;
 
}

/**
 * Get IDH Products filtered by IDH material key and propagation
 *
 * @param {Object} param0 - Parameters
 * @param {Object} param0.aIbMaterialKeys - IB Material Key to filter
 * @returns {Promise} Returning result of call
 */
async function getIbProductsByMaterialKey({aIbMaterialKeys}) {

    const aBatches = divideArrayInBatches(aIbMaterialKeys, 10);
    const aAllIbProducts = [];

    for (const aBatch of aBatches) {
        const sFilter = aBatch.map(key => `materialtNumber eq '${key}'`).join(' or ');
        const sPath = `${PATH.IB_PRODUCTS}?$filter=${sFilter}`;

        const aIbProducts = await pstCall({
            method: HTTP_METHOD.GET,
            path: sPath
        });

        aAllIbProducts.push(...aIbProducts);
    }

    return aAllIbProducts;
 
}

/**
 * Reads existing assesments for given products
 * 
 * @param {Object} param0 - Parameters
 * @param {Object[]} aProductReminderLogs - Array of unnotified products logs
 * @returns - Array of reminder logs
 */
async function checkExistingAssessmentForProduct({aExcludedNotifiedProducts}) {

    const aBatches = divideArrayInBatches(aExcludedNotifiedProducts, 10);
    const aAllProducts = [];

    for (const aBatch of aBatches) {
        const aProducts = aBatch.map(product => product.materialtNumber);

        const sPath = `${PATH.CHECK_PRODUCT_IN_ASSESSMENT}(products='${encodeURI(JSON.stringify(aProducts))}')`;

        const aProductsInExistingAssessment = await pstCall({
            method: HTTP_METHOD.GET,
            path: sPath,
        });
        
        aAllProducts.push(...aProductsInExistingAssessment);
    }
    
    return aAllProducts;
}


module.exports = {
    getMassAssessmentHeaderById,
    getSingleAssessmentById,
    getItemById,
    getNotificationRecipients,
    getPendingAssessmentsByStatus,
    getApprovedIbProductsByApprovalDate,
    getManuallyMaintainedApprovedIdhProductsByApprovalDate,
    getIdhRelatedToIb,
    getIdhProductsByMaterialKeyAndPropagation,
    getIbProductsByMaterialKey,
    checkExistingAssessmentForProduct
};
