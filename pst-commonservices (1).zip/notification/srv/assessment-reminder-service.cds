/**
 * Service to handle Assessment Reminders
 */

using com.notification.types as types from './types.cds';

@requires: 'authenticated-user'
service AssessmentReminderService {
 
    /**
     * Check Saved assessments pending reminder
     */
    action checkAssessmentOnSavedPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;

    /**
     * Check Submitted assessments pending reminder
     */
    action checkAssessmentOnSubmittedPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;

    /**
     * Check Under Re-Submission assessments pending reminder
     */
    action checkAssessmentOnUnderResubmissionPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;

    /**
     * Check Re-Submitted assessments pending reminder
     */
    action checkAssessmentOnResubmittedPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;

    /**
     * Check Under Review assessments pending reminder
     */
    action checkAssessmentOnUnderReviewPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;

    /**
     * Check Draft assessments pending reminder
     */
    action checkAssessmentOnDraftPending(
        daysSinceUpdate: types.DaysSinceUpdate
    ) returns String;


    /**
     * Check Ib Products on Outdated Asessment
     */
    action checkIbAssessmentOutdated(
        daysSinceUpdate: Integer
    ) returns String;

    /**
     * Check Idh Products on Outdated Asessment
     */
    action checkIdhAssessmentOutdated(
        daysSinceUpdate: Integer
    ) returns String;

}
