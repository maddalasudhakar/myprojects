const cds = require('@sap/cds');
const LOG = cds.log('reminder-jobs');

cds.once('served', async (tx) => {
    const user = new cds.User.Privileged
    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"];
    const jobParams = 
    userProvided?.find(item => item.name === 'notification-job-params')?.credentials || cds.env?.JOB_PARAMS;
    const envNotifications = process.env.ENVIRONMENT_NOTIFICATIONS
        ? JSON.parse(process.env.ENVIRONMENT_NOTIFICATIONS)
        : null;
    if (envNotifications) {
        cds.env['notification-defaults'] = {
            mode: envNotifications.MODE,
            recipients: envNotifications.DEFAULT_RECIPIENTS,
        };
    }

    const MINUTE_TO_MS_RATE = 1000 * 60;
    if (jobParams) {
        if (jobParams.checkAssessmentOnSavedPending?.active) {
            cds.spawn({ user, every: jobParams.checkAssessmentOnSubmittedPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnSavedPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnSavedPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnSavedPending.daysSinceUpdate,
                });
            });
        }

        if (jobParams.checkAssessmentOnSubmittedPending?.active) {
            cds.spawn({user, every: jobParams.checkAssessmentOnSubmittedPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnSubmittedPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnSubmittedPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnSubmittedPending.daysSinceUpdate
                });
            });
        }


          if (jobParams.checkAssessmentOnUnderResubmissionPending?.active) {
            cds.spawn({user, every: jobParams.checkAssessmentOnUnderResubmissionPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnUnderResubmissionPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnUnderResubmissionPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnUnderResubmissionPending.daysSinceUpdate
                });
            });
        }

        if (jobParams.checkAssessmentOnResubmittedPending?.active) {
            cds.spawn({user, every: jobParams.checkAssessmentOnResubmittedPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnResubmittedPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnResubmittedPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnResubmittedPending.daysSinceUpdate
                });
            });
        }

        if (jobParams.checkAssessmentOnUnderReviewPending?.active) {
            cds.spawn({user, every: jobParams.checkAssessmentOnUnderReviewPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnUnderReviewPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnUnderReviewPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnUnderReviewPending.daysSinceUpdate
                });
            });
        }

        if (jobParams.checkAssessmentOnDraftPending?.active) {
            cds.spawn({user, every: jobParams.checkAssessmentOnDraftPending.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkAssessmentOnDraftPending job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkAssessmentOnDraftPending", {
                    daysSinceUpdate: jobParams.checkAssessmentOnDraftPending.daysSinceUpdate
                });
            });
        }

        if (jobParams.checkIbAssessmentOutdated?.active) {
            cds.spawn({ user, every: jobParams.checkIbAssessmentOutdated.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkIbAssessmentOutdated job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkIbAssessmentOutdated", {
                    daysSinceUpdate: jobParams.checkIbAssessmentOutdated.daysSinceUpdate,
                });
            });
        }

        if (jobParams.checkIdhAssessmentOutdated?.active) {
            cds.spawn({ user, every: jobParams.checkIbAssessmentOutdated.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger checkIdhAssessmentOutdated job");
                const AssessmentReminderService = await cds.connect.to("AssessmentReminderService");
                await AssessmentReminderService.send("checkIdhAssessmentOutdated", {
                    daysSinceUpdate: jobParams.checkIdhAssessmentOutdated.daysSinceUpdate,
                });
            });
        }

    }
});
