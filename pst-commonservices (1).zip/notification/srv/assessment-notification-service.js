const cds = require('@sap/cds');
const handlers = require('./handlers');

module.exports = cds.service.impl(async function (srv) {

    srv.on('test', async (req) => {
        const MyIdUser = await cds.connect.to('myid-users');
        console.log("begin call");
        try {
            const result = await MyIdUser.send({
                method: 'GET',
                path: '/plugin/rest/RestAccessManagement/users',
                data: {
                    // applicationName: 'APP-40257',
                    // applicationName: 'APP-40257 - Sustainability Portfolio Evaluation on Environmnetal Data (SPEED)',
                    applicationName: 'Azure AD',
                    entitlementName: 'APP-PST_DEV/QUA_ACC_Assessor',
                    displayAttribute: 'email'
                }

            })

            console.log("end call", result);
        } catch (error) {
            console.log(JSON.stringify(error))
        }

    });

    srv.on("notifyOnSave", handlers.assessmentNotification.actions.notifyOnSave);
    srv.on("notifyOnSubmit", handlers.assessmentNotification.actions.notifyOnSubmit);
    srv.on("notifyOnUnderResubmission", handlers.assessmentNotification.actions.notifyOnUnderResubmission);
    srv.on("notifyOnResubmit", handlers.assessmentNotification.actions.notifyOnResubmit);
    srv.on("notifyOnNewRcPreFlagMismatchSubmited", handlers.assessmentNotification.actions.notifyOnNewRcPreFlagMismatchSubmited);
    srv.on("p03ProcessingProductError", handlers.assessmentNotification.actions.p03ProcessingProductError);
    srv.on("notifyReminderForAssessmentState", handlers.assessmentNotification.actions.notifyReminderForAssessmentState);
    srv.on("adpProjectNotLinked", handlers.assessmentNotification.actions.adpProjectNotLinked);
    srv.on("notifyOnNewPdpSaved", handlers.assessmentNotification.actions.notifyOnNewPdpSaved);
    srv.on("notifyOnNewPdpSubmitted", handlers.assessmentNotification.actions.notifyOnNewPdpSubmitted);
    srv.on("notifyOnNewMocSaved", handlers.assessmentNotification.actions.notifyOnNewMocSaved);
    srv.on("notifyAssessmentProductBlocked", handlers.assessmentNotification.actions.notifyAssessmentProductBlocked);
    srv.on("notifyProductBlockedPdpMoc", handlers.assessmentNotification.actions.notifyProductBlockedPdpMoc);
    srv.on("getMyIdUsers", handlers.assessmentNotification.functions.getMyIdUsers);
    srv.on("getMyIdUsersGroup", handlers.assessmentNotification.functions.getMyIdUsersGroup);
    srv.on("notifyReminderForProductAssessmentOutdated", handlers.assessmentNotification.actions.notifyReminderForProductAssessmentOutdated);
    srv.on("notifyOnHeartAssessmentSaved", handlers.assessmentNotification.actions.notifyOnHeartAssessmentSaved);
    srv.on("notifyOnHeartAssessmentSubmitted", handlers.assessmentNotification.actions.notifyOnHeartAssessmentSubmitted);
    srv.on("notifyProductBlockedHeart", handlers.assessmentNotification.actions.notifyProductBlockedHeart);
    srv.on("notifyOnRcPositiveContributionAssessmentSaved", handlers.assessmentNotification.actions.notifyOnRcPositiveContributionAssessmentSaved);
    srv.on("notifyOnRcPositiveContributionAssessmentSubmitted", handlers.assessmentNotification.actions.notifyOnRcPositiveContributionAssessmentSubmitted);

});