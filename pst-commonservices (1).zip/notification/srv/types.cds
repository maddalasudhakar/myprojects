namespace com.notification.types;

type email                      : String(40);
type DaysSinceUpdate : {
    level1 : Integer;
    level2 : Integer;
    level3 : Integer;
};

type assessmentProcessType : String(10) enum {
    PDP = 'PDP';
    MOC = 'MOC';
    RCM = 'RCM';
    MANUAL = '';
    HEART = 'HRT';
};

type notificationsRecipients {
    email : email
}