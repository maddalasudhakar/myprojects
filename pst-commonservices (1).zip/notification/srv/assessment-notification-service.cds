/**
 * Service to handle notifications
 */

using { com.sustainability.notification as db } from '../db/schema';
using com.notification.types as types from './types.cds';

@requires: 'authenticated-user'
service AssessmentNotificationService {
    function test () returns String;

    /**
     * Notify creation of assessment
     */
    action notifyOnSave(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        } 
    ) returns String;

    /**
     * Notify submission of assessment
     */
    action notifyOnSubmit(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        } 
    ) returns String;

    /**
     * Notify assessment returnal to submitter after being submitted
     */
    action notifyOnUnderResubmission(
        sbu: String(3), 
        submitter: String,
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        } 
    ) returns String;

    /**
     * Notify assessment has been resubmitted
     */
    action notifyOnResubmit(
        sbu: String(3), 
        approver: String,
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        }         
    ) returns String;
    
    /**
     * Notify creation of assessment
     */
    action notifyOnNewRcPreFlagMismatchSubmited(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        } 
    ) returns String;

    /**
     * Notify PO3 products error
     */
    action p03ProcessingProductError(
        assessmentId: UUID,
        assessmentType: String(6) enum {
            BY_ID;
        }  
    ) returns String;

    /**
     * Notify reminder for an assessment
     */
    action notifyReminderForAssessmentState(
        sbu: String(3),
        assessmentId: UUID,
        assessmentType: String(6) enum {
            SINGLE;
            MASS;
        },
        level: Integer,
        status: String
    ) returns String;

    action adpProjectNotLinked(
        adpProject: String(18),
        sbu: String(3),
        assessor: String(40),
        submitter: String(40),
        processType: String(3) enum {
            PDP;
            MOC;
        }
    ) returns String;

    /**
     * Notify creation of PDP assessment in saved status
     */
    action notifyOnNewPdpSaved(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            MASS;
        } 
    ) returns String;

    /**
     * Notify creation of PDP assessment in submitted status
     */
    action notifyOnNewPdpSubmitted(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            MASS;
        } 
    ) returns String;

    /**
     * Notify creation of MOC assessment in saved status
     */
    action notifyOnNewMocSaved(
        sbu: String(3), 
        assessmentId: UUID,
        assessmentType: String(6) enum {
            MASS;
        } 
    ) returns String;

    /**
     * Notify prodcuts which are blocking an assessment
     */
    action   notifyAssessmentProductBlocked(
    blockingAssessment: array of {
        ID                  : UUID;
        itemID              : UUID;
        requestName         : String;
        headerStatus        : String(2);
        product             : String;
        status              : String;
        assessor            : String;
        submitter           : String;
        approver            : String;
        communicationStatus : String(2);
    },
     type: String(6) enum {
        PDP;
        MOC;
    }) returns String;

    /**
     * Notify prodcuts which are block when create a PDP or MOC assessment
     */
    action  notifyProductBlockedPdpMoc(
    blockedProducts: array of {
        ID                  : UUID;
        itemID              : UUID;
        requestName         : String;
        headerStatus        : String(2);
        product             : String;
        status              : String;
        assessor            : String;
        submitter           : String;
        approver            : String;
        communicationStatus : String(2);
    },
    sbu: String(3), 
     type: String(6) enum {
        PDP;
        MOC;
    },
    adpProject: String
    ) returns String;

    /**
     * Retrieve users from MyIdUsers table
     */
    function getMyIdUsers(
        sbu: String(3),
        status: String(2),
        processType: types.assessmentProcessType
    ) returns Array of types.notificationsRecipients;

    /**
     * Retrieve users from MyIdUsers table by role
     */
    function getMyIdUsersGroup(
        sbu: String(3),
        role: String(150),
        processType: types.assessmentProcessType
    ) returns Array of types.notificationsRecipients;

    @readonly
    entity MyIdUsers as projection on db.MyIdUsers;

    /**
     * Notify reminder for an Outdated Product Asessment
     */
    action notifyReminderForProductAssessmentOutdated(
        responsible: String,
        secondResponsible: String, 
        productType: String(3) enum {
            IB;
            IDH;
        }, 
        products: String(255)
    ) returns String;

     /**
     * Notify creation of heart assessment in saved status
     */
    action notifyOnHeartAssessmentSaved(
        sbu: String(3), 
        assessmentId: UUID
    ) returns String;

     /**
     * Notify creation of heart assessment in submitted status
     */
    action notifyOnHeartAssessmentSubmitted(
        sbu: String(3), 
        assessmentId: UUID
    ) returns String;
    
    /**
     * Notify prodcuts which are block when create a Heart assessment
     */
    action  notifyProductBlockedHeart(
    blockedProducts: array of {
        requestName         : String;
        product             : String;
    },
    sbu: String(3), 
   ) returns String;

    /**
     * Notify creation of Rc Positive Contribution assessment in saved status
     */
    action notifyOnRcPositiveContributionAssessmentSaved(
        sbu: String(3), 
        assessmentId: UUID
    ) returns String;

     /**
     * Notify creation of Rc Positive Contribution assessment in submitted status
     */
    action notifyOnRcPositiveContributionAssessmentSubmitted(
        sbu: String(3), 
        assessmentId: UUID
    ) returns String;

}
