const cds = require('@sap/cds');
const { getPendingAssessments, ASSESSMENT_STATUS } = require('../../../src/domain/assessment');
const { getAssessmentReminderLogs, saveAssessmentReminderLog, processAndNotifyAssessments } = require('../../../src/domain/reminder');

/**
 * 
 * Reminder logic when an assessment is pending on status draft
 * 
 * @param {Object} req - Request triggering the logic
 * @param {Object} req.data - Request payload
 * @param {Object} req.data.daysSinceUpdate - Configuration of days thresholds for each reminder level
 * @returns 
 */
async function checkAssessmentOnDraftPending(req) {
    const { daysSinceUpdate } = req.data;
    const STATUS = ASSESSMENT_STATUS.DRAFT;

    // Get assessments in DRAFT status that may need a reminder
  const aPendingAssessments = await getPendingAssessments({ status: STATUS, daysSinceUpdate });

    if (!aPendingAssessments || aPendingAssessments.length === 0) {
        return;
    }

    // Get logs of reminders already sent
    const aExistingLogs = await getAssessmentReminderLogs(aPendingAssessments, STATUS);
    try {
        // Check which assessments need a reminder and send notifications
        const aResults = await processAndNotifyAssessments(aPendingAssessments, aExistingLogs, daysSinceUpdate, STATUS);

        // Separate successful and failed reminder attempts
        const successful = aResults?.filter(r => r.success);
        const failed = aResults?.filter(r => !r.success);

        // Save logs for successful reminders
        if (successful.length) {
    
            await saveAssessmentReminderLog(successful, STATUS);
        }

        // Log failed reminders for review
        if (failed.length) {
            failed.forEach(f => console.warn(` - ${f.assessmentId}: ${f.error}`));
        }

    } catch (oError) {
        return console.error(oError);
    }

}
module.exports = {
    checkAssessmentOnDraftPending
}

