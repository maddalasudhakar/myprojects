const { getApprovedIbProductsByApprovalDate, getIdhRelatedToIb, getIdhProductsByMaterialKeyAndPropagation, checkExistingAssessmentForProduct } = require('../../../src/io/pst');
const { getProductReminderLogsForIbs, saveProductReminderLogForIbs } = require('../../../src/domain/reminder');
const {notifyReminderForProductAssessmentOutdated} = require('../../assessment-notification/actions/notify-reminder-for-product-assessment-outdated')

async function checkIbAssessmentOutdated (req) {

    const {daysSinceUpdate} = req.data;

    const dDateLimit = new Date();
    dDateLimit.setDate(dDateLimit.getDate() - daysSinceUpdate);
    const sIsoDate = dDateLimit.toISOString().split('T')[0];
 
    //get Ib products
    const aIbProducts = await getApprovedIbProductsByApprovalDate(sIsoDate);

    //get array with only materialtNumber of Ib products
    const aIbMaterialNumbers = aIbProducts.map(product => product.materialtNumber);
    
    //get relationship between ib and idh products
    const aProductRelationships = await getIdhRelatedToIb({aIbMaterialNumbers});
 
    //get only idh products of the relationship with ibs
    const aIdhMaterialKeys = aProductRelationships.map(relation => relation.MATERIAL_KEY);
 
    //get all idh products that exists on the relationship and have propagation false
    const aIdhProducts = await getIdhProductsByMaterialKeyAndPropagation({aIdhMaterialKeys: aIdhMaterialKeys, propagation: false});
 
    //set with only idh product material number
    const stIdhKeysSet = new Set(aIdhProducts.map(product => product.materialtNumber));
 
    //filtered product relationships with only valid idh products
    const aFilteredProductRelationship = aProductRelationships.filter(relation => stIdhKeysSet.has(relation.MATERIAL_KEY));
    
    //set with only valid ib products keys
    const stFilteredIbKeys = new Set(aFilteredProductRelationship.map(relation => relation.AI_PRODUCT_KEY));

    //Filtered valid ib products
    const aFilterIbProducts = aIbProducts.filter(product => stFilteredIbKeys.has(product.materialtNumber));

    //get products that have been unnotified
    const aProductReminderLogs = await getProductReminderLogsForIbs({aFilterIbProducts});

    //set with product logs
    const stLoggedProducts = new Set(aProductReminderLogs.map(log => log.product));

    //filtered products that are valid for notification
    const aExcludedNotifiedProducts = aFilterIbProducts.filter(product => !stLoggedProducts.has(product.materialtNumber));

    //get unnotified products that are in a current assessment and are valid for sending notification
    const aProductsInExistingAssessment = await checkExistingAssessmentForProduct({aExcludedNotifiedProducts});

    //set con los productos que ya tienen assessment
    const stProductsWithAssessment = new Set(aProductsInExistingAssessment.map(product => product.product));

    //filtrar los logs para quedarte solo con los que no están en ese Set con assessment existente
    const aUnnotifiedProducts = aExcludedNotifiedProducts.filter(log => !stProductsWithAssessment.has(log.materialtNumber));

    const groupedProducts = Object.values(
        aUnnotifiedProducts.reduce((acc, item) => {
            const key = `${item.submitter}|${item.approver}`;
            if (!acc[key]) {
            acc[key] = {
                responsible: item.submitter,
                secondResponsible: item.approver,
                products: [],
            };
            }
            acc[key].products.push(item.materialtNumber);
            return acc;
        }, {})
    );

    for (const group of groupedProducts) {
        const productType = 'IB';
        const req = {
            data: {
                responsible: [group.responsible],
                secondResponsible: [group.secondResponsible],
                productType: productType,
                products: group.products,
            },
        };
        await notifyReminderForProductAssessmentOutdated(req);
    }

        await saveProductReminderLogForIbs(aUnnotifiedProducts);
}
 
 
module.exports = {
    checkIbAssessmentOutdated
}