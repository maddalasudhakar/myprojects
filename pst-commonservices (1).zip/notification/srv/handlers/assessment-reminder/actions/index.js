const { checkAssessmentOnSavedPending } = require('./check-assessment-on-saved-pending');
const { checkAssessmentOnDraftPending } = require('./check-assessment-on-draft-pending');
const { checkAssessmentOnSubmittedPending } = require('./check-assessment-on-submitted-pending');
const { checkAssessmentOnUnderResubmissionPending } = require('./check-assessment-on-under-resubmission-pending');
const { checkAssessmentOnResubmittedPending } = require('./check-assessment-on-re-submitted-pending');
const { checkAssessmentOnUnderReviewPending } = require('./check-assessment-on-under-review-pending');
const { checkIdhAssessmentOutdated } = require('./check-Idh-assessment-outdated');
const { checkIbAssessmentOutdated } = require('./check-Ib-assessment-outdated');


module.exports = {
    checkAssessmentOnSavedPending,
    checkAssessmentOnDraftPending,
    checkAssessmentOnSubmittedPending,
    checkAssessmentOnUnderResubmissionPending,
    checkAssessmentOnResubmittedPending,
    checkAssessmentOnUnderReviewPending,
    checkIdhAssessmentOutdated,
    checkIbAssessmentOutdated
};