const { getManuallyMaintainedApprovedIdhProductsByApprovalDate, checkExistingAssessmentForProduct } = require('../../../src/io/pst');
const { getProductReminderLogsForIdhs,saveProductReminderLogForIdh } = require('../../../src/domain/reminder');
const {notifyReminderForProductAssessmentOutdated} = require('../../assessment-notification/actions/notify-reminder-for-product-assessment-outdated')

async function checkIdhAssessmentOutdated (req) {

    const {daysSinceUpdate} = req.data;

    const dDateLimit = new Date();
    dDateLimit.setDate(dDateLimit.getDate() - daysSinceUpdate);
    const sIsoDate = dDateLimit.toISOString().split('T')[0];
 
    const aIdhProducts = await getManuallyMaintainedApprovedIdhProductsByApprovalDate(sIsoDate);
    
    const aProductReminderLogs = await getProductReminderLogsForIdhs({aFilterProducts: aIdhProducts});

    const stLoggedProducts = new Set(aProductReminderLogs.map(log => log.product));

    const aExcludedNotifiedProducts = aIdhProducts.filter(product => !stLoggedProducts.has(product.materialtNumber));
    
    const aProductsInExistingAssessment = await checkExistingAssessmentForProduct({aExcludedNotifiedProducts});
   
    const stProductsWithAssessment = new Set(aProductsInExistingAssessment.map(product => product.product));

    const aUnnotifiedProducts = aExcludedNotifiedProducts.filter(log => !stProductsWithAssessment.has(log.materialtNumber));

    const groupedProducts = Object.values(
        aUnnotifiedProducts.reduce((acc, item) => {
            const key = `${item.submitter}|${item.approver}`;
            if (!acc[key]) {
            acc[key] = {
                responsible: item.submitter,
                secondResponsible: item.approver,
                products: [],
            };
            }
            acc[key].products.push(item.materialtNumber);
            return acc;
        }, {})
    );

    for (const group of groupedProducts) {
        const productType = 'IDH';
        const req = {
            data: {
                responsible: [group.responsible],
                secondResponsible: [group.secondResponsible],
                productType: productType,
                products: group.products,
            },
        };
        await notifyReminderForProductAssessmentOutdated(req);
    }
        await saveProductReminderLogForIdh(aUnnotifiedProducts);
 
}
 
 
module.exports = {
    checkIdhAssessmentOutdated
}