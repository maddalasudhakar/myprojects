const actions = require('./actions');
const functions = require ('./functions');

module.exports = {
    actions,
    functions
}