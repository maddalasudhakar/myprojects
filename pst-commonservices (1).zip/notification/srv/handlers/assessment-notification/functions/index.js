const { getMyIdUsers } = require('./get-my-id-users');
const { getMyIdUsersGroup } = require('./get-my-id-users-group');


module.exports = {
    getMyIdUsers,
    getMyIdUsersGroup
};