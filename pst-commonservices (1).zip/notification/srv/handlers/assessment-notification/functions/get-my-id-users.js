
const { getMyIdUsersByRole, ROLE , PROCESS_TYPES } = require('../../../src/domain/notification');
const { ASSESSMENT_STATUS  } = require('../../../src/domain/assessment');

/**
 * Retrieve users from MyIdUsers based on SBU, process type, and status.
 *
 * @param {Request} req - Request object containing the input data
 * @param {string} req.data.sbu - The SBU code
 * @param {string} req.data.status - The status code (e.g., '01', '02')
 * @param {string} req.data.processType - The process type (e.g., PDP, MOC)
 * @returns  List of users matching the constructed role
 */
async function getMyIdUsers(req) {

    const { sbu, status, processType } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    // Determine expected role based on process type and status
    let expectedRole;
    switch (processType) {
        case PROCESS_TYPES.MANUAL:
            switch (status) {
                case ASSESSMENT_STATUS.SAVED:
                    expectedRole = ROLE.SUBMITTER;
                    break;
                case ASSESSMENT_STATUS.SUBMITTED:
                    expectedRole = ROLE.APPROVER;
                    break;
            }

            break;
        case PROCESS_TYPES.PDP:
            expectedRole = ROLE.NOTIFICATION;
            break;
        case PROCESS_TYPES.MOC:
            expectedRole = ROLE.NOTIFICATION;
            break;
        case PROCESS_TYPES.HEART:
            expectedRole = ROLE.APPROVER;
            break;
        case PROCESS_TYPES.RCM:
            expectedRole = ROLE.APPROVER;
            break;
        case PROCESS_TYPES.RCPC:
            switch (status) {
                case ASSESSMENT_STATUS.SAVED:
                    expectedRole = ROLE.SUBMITTER;
                    break;
                case ASSESSMENT_STATUS.SUBMITTED:
                    expectedRole = ROLE.APPROVER;
                    break;
            }
            break;
    }
    // Fetch users from remote service filtered by role
    const aUsers = await getMyIdUsersByRole({ sbu, processType, role: expectedRole });
    return aUsers;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = ['sbu'];

    if (data.processType === PROCESS_TYPES.MANUAL) {
        REQUIRED_FIELDS.push('status');
    }
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);

    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }

    return oResult;

};


module.exports = {
    getMyIdUsers,
}