
const { getMyIdUsersByRole } = require('../../../src/domain/notification');

/**
 * Retrieve users from MyIdUsers based on SBU, process type, and role.
 *
 * @param {Request} req - Request object containing the input data
 * @param {string} req.data.sbu - The SBU code
 * @param {string} req.data.status - The status code (e.g., '01', '02')
 * @param {string} req.data.processType - The process type (e.g., PDP, MOC)
 * @returns  List of users matching the constructed role
 */
async function getMyIdUsersGroup (req) {

    const { sbu, role, processType } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    // Fetch users from remote service filtered by role
    const aUsers = await getMyIdUsersByRole({ sbu, processType, role });
    return aUsers;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = ['sbu', 'role', 'processType'];
        
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);

    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }

    return oResult;

};


module.exports = {
    getMyIdUsersGroup
}