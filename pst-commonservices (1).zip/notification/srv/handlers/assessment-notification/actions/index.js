const { notifyOnSave } = require('./notify-on-save');
const { notifyOnSubmit } = require('./notify-on-submit');
const { notifyOnResubmit } = require('./notify-on-resubmit');
const { notifyOnUnderResubmission } = require('./notify-on-under-resubmission');
const { notifyOnNewRcPreFlagMismatchSubmited } = require('./notify-on-new-rcpreflag-mismatch-submitted');
const { p03ProcessingProductError } = require('./p03-processing-product-error');
const { notifyReminderForAssessmentState } = require('./notify-reminder-for-assessment-state');
const { adpProjectNotLinked } = require('./adp-project-not-linked');
const { notifyOnNewPdpSaved } = require('./notify-on-new-pdp-saved');
const { notifyOnNewPdpSubmitted } = require('./notify-on-new-pdp-submitted');
const { notifyOnNewMocSaved } = require('./notify-on-new-moc-saved');
const { notifyAssessmentProductBlocked } = require('./notify-assessment-product-blocked');
const { notifyProductBlockedPdpMoc } = require('./notify-product-blocked-pdp-moc');
const { notifyReminderForProductAssessmentOutdated } = require('./notify-reminder-for-product-assessment-outdated');
const { notifyOnHeartAssessmentSaved } = require('./notify-on-heart-assessment-saved');
const { notifyOnHeartAssessmentSubmitted } = require('./notify-on-heart-assessment-submitted');
const { notifyProductBlockedHeart } = require('./notify-product-blocked-heart');
const { notifyOnRcPositiveContributionAssessmentSaved } = require('./notify-on-rcpositivecontribution-assessment-saved');
const { notifyOnRcPositiveContributionAssessmentSubmitted } = require('./notify-on-rcpositivecontribution-assessment-submitted');

module.exports = {
    notifyOnSave,
    notifyOnSubmit,
    notifyOnResubmit,
    notifyOnUnderResubmission,
    p03ProcessingProductError,
    notifyReminderForAssessmentState,
    adpProjectNotLinked,
    notifyOnNewRcPreFlagMismatchSubmited,
    notifyOnNewPdpSaved,
    notifyOnNewPdpSubmitted,
    notifyOnNewMocSaved,
    notifyAssessmentProductBlocked,
    notifyProductBlockedPdpMoc,
    notifyReminderForProductAssessmentOutdated,
    notifyOnHeartAssessmentSaved,
    notifyOnHeartAssessmentSubmitted,
    notifyProductBlockedHeart,
    notifyOnRcPositiveContributionAssessmentSaved,
    notifyOnRcPositiveContributionAssessmentSubmitted
};