const { sendNotification, getMessageTokens, TEMPLATE_NAME } = require('../../../src/domain/notification');
const { getAssessmentDataById } = require('../../../src/domain/assessment');
const { getTemplatesByName } = require('../../../src/io/notify');

/**
 * Notification logic when a product has a processing error in P03
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function p03ProcessingProductError(req) {

    const { assessmentId, assessmentType } = req.data;

    // Prepare message tokens
    const aTokens = await getMessageTokens({ assessmentId, assessmentType });
    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    const aRecipients = aTokens
        .filter(token => token.id === 'approver' && token.value)
        .map(token => token.value);

    // Get template IDs and Channels
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.P03_PROCESSING_ERROR);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    });

    return `notification sent`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'assessmentId',
        'assessmentType',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

};


module.exports = {
    p03ProcessingProductError,
}