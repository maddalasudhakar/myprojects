const { sendNotification, getTemplatesForRcMismatchAssessment, getMessageTokens, TEMPLATE_ACTION, PROCESS_TYPES } = require('../../../src/domain/notification');
const {ASSESSMENT_TYPE } = require('../../../src/domain/assessment');
const { getMyIdUsers } = require('../functions/get-my-id-users');

/**
 * Handles the notification logic when an RCPreFLag Mismatch assessment is submited.
 *
 * @async
 * @function notifyOnNewRcPreFlagMismatchSubmited
 * @param {Object} req
 * @param {Object} req.data - The data payload containing necessary parameters.
 * @param {string} req.data.sbu 
 * @param {string|number} req.data.assessmentId 
 * @param {string} req.data.assessmentType 
 * @returns 
 */
async function notifyOnNewRcPreFlagMismatchSubmited(req) {

    const { sbu, assessmentId, assessmentType } = req.data;

    let aNotificationRecipients = [];

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }
    try {

        // Prepare message tokens
        const aTokens = await getMessageTokens({ assessmentId, assessmentType: ASSESSMENT_TYPE.MASS });
        if (!aTokens || aTokens.length === 0) {
            return req.error(409, 'No data could be retrieved for assessment');
        }

        aNotificationRecipients = await getMyIdUsers({
            data: {
                sbu: sbu,
                processType: PROCESS_TYPES.RCM
            }
        });

        const aRecipients = aNotificationRecipients.map(u => u.email);

        // Get template ID 
        const aTemplates = await getTemplatesForRcMismatchAssessment(TEMPLATE_ACTION.SUBMIT);

        // Send notifications
        const result = await sendNotification({
            templates: aTemplates,
            recipients: aRecipients,
            tokens: aTokens,
        })

        return `Save notifications sent to SBU ${sbu} for assessment ${assessmentId}`;


    } catch (error) {

        return req.error(500, `Error sending notifications: ${error.message}`);
    }

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'sbu',
        'assessmentId',
        'assessmentType',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}


module.exports = {
    notifyOnNewRcPreFlagMismatchSubmited,
}