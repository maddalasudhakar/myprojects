const { sendNotification, TEMPLATE_NAME, PROCESS_TYPES } = require('../../../src/domain/notification');
const { getTemplatesByName } = require('../../../src/io/notify');
const { getMyIdUsers } = require('../functions/get-my-id-users');
/**
 * Notification logic when a assessment Heart creation for some prodcuts is blocked by other assessments
 * Notify all the prodcuts blocked
 * @param {Request} req - Request triggering the logic 
 */
async function notifyProductBlockedHeart(req) {

    const { blockedProducts, sbu } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    // Get template ID
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.HEART_PRODUCTS_BLOCKED);

      aNotificationRecipients = await getMyIdUsers({
        data: {
            sbu: sbu,
            processType: PROCESS_TYPES.HEART
        }
    });
    const aRecipients = aNotificationRecipients.map(u => u.email);

    const aTokens = [];

    const sHtmlTable = buildHtmlTable(blockedProducts);

    aTokens.push({ id: "productList", value: sHtmlTable });

    // Send notifications
    await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    })


    return `Notificaions of Heart Products blocked sent`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'blockedProducts',
        'sbu'
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}

/**
 * Builds html table with token values.
 *
 * @param {Object} aTokens - tokens  array 
 * @returns String of html table 
 */
function buildHtmlTable(aProducts) {

    let html = `<table border="1" cellspacing="0" cellpadding="6" style="border-collapse:collapse; font-family:Arial, sans-serif; font-size:14px; width:100%; max-width:800px;">
  <thead style="background-color:#f5f5f5; text-align:left;">
    <tr>
      <th style="padding:8px;">Product</th>
      <th style="padding:8px;">Request Name</th>
    </tr>
  </thead>
  <tbody>`;

    for (const product of aProducts) {
        html += `
    <tr>
      <td style="padding:8px;">${product.product || "-"}</td>
      <td style="padding:8px;">${product.requestName || "-"}</td>
    </tr>`;
    }

    html += "</tbody></table>";

    return html;
}

module.exports = {
    notifyProductBlockedHeart
}