const { default: cds } = require('@sap/cds');
const { getAssessmentDataById } = require('../../../src/domain/assessment');
const { getRecipientsAndTemplateRoleByStatus, getTemplatesByReminderLevel, sendNotification, mapMessageTokens, PROCESS_TYPES } = require('../../../src/domain/notification');


/**
 * Notifies recipients with the proper reminder templates for a given assessment state.
 *
 * @param {cds.Request} req - Request triggering the notification
 * @param {Object} req.data - Payload with parameters
 * @param {string} req.data.sbu - SBU
 * @param {string} req.data.assessmentId - Unique identifier of the assessment
 * @param {string} req.data.assessmentType - Type of the assessment (SINGLE/MASS)
 * @param {number} req.data.level - Reminder level
 * @returns
 */
async function notifyReminderForAssessmentState(req) {

    const { assessmentId, assessmentType, level, status } = req.data;
    const aExpand = ['toRecipients'];

    // Fetch the assessment data including recipients
    const oAssessment = await getAssessmentDataById({ assessmentId, type: assessmentType, expand: aExpand });

    // RCM assessments do not trigger notifications
    const excludedTypes = [
        PROCESS_TYPES.RCM,
        PROCESS_TYPES.HEART,
        PROCESS_TYPES.PDP,
        PROCESS_TYPES.MOC,
    ];
    if (oAssessment.processType && excludedTypes.includes(oAssessment.processType)) {
        return;
    }
    // Generate tokens to personalize the notification template
    const aTokens = await mapMessageTokens({ oAssessment });

    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    // Determine recipients and the template role based on assessment status and reminder level
    const { aRecipients, aCcRecipients, sRole } = await getRecipientsAndTemplateRoleByStatus(oAssessment, level, status);

    // Get the correct templates for this reminder level, status, and role
    const aTemplates = await getTemplatesByReminderLevel(level, status, sRole);

    if (!aTemplates || aTemplates.length === 0) {
        return req.error(409, 'No template could be retrieved for assessment');
    }

    //Validate CC recipients: remove anyone who is already in the main recipients list
    const filteredCcRecipients = aCcRecipients.filter(cc => !aRecipients.includes(cc));

    // Send notifications to recipients
    const results = await sendNotification({ templates: aTemplates, recipients: aRecipients, ccRecipients: filteredCcRecipients, tokens: aTokens });

    // Handle failures in sending notifications
    if (results.some(item => item.status === "rejected")) {
        req.reject(500, "Failed to send notification");
    }

    /*---------------------------------------------------- MULTI-ROLE CASE-------------------------------------------------------------------------*/
    // Determine recipients and the template role based on assessment status and reminder level
    // const { aRecipients, aCcRecipients, sRole, aRecipientsByRole } = await getRecipientsAndTemplateRoleByStatus(oAssessment, level, status);
    // let results = [];
    // if (aRecipientsByRole) {

    //     for (const { role, recipients } of aRecipientsByRole) {

    //         if (!recipients || recipients.length === 0) {
    //             continue;
    //         }
    //         // Get the correct templates for this reminder level, status, and role
    //         const aTemplates = await getTemplatesByReminderLevel(level, status, role);

    //         if (!aTemplates?.length) {
    //             req.error(409, `No template found for role ${role}`);
    //             continue;
    //         }
    //         // Send notifications to recipients
    //         const result = await sendNotification({
    //             templates: aTemplates,
    //             recipients,
    //             ccRecipients: [],
    //             tokens: aTokens
    //         });

    //         results.push(...result);
    //     }

    // }
    // else {
    //     // Get the correct templates for this reminder level, status, and role
    //     const aTemplates = await getTemplatesByReminderLevel(level, status, sRole);

    //     if (!aTemplates?.length) {
    //         return req.error(409, "No template could be retrieved for assessment");
    //     }
    //     //Validate CC recipients: remove anyone who is already in the main recipients list
    //     const filteredCcRecipients = aCcRecipients.filter(cc => !aRecipients.includes(cc));
    //     // Send notifications to recipients
    //     results = await sendNotification({ templates: aTemplates, recipients: aRecipients, ccRecipients: filteredCcRecipients, tokens: aTokens });

    // }
    // if (results.some(item => item.status === "rejected")) {
    //     req.reject(500, "Failed to send notification");
    // }

    /*-----------------------------------------------------------------------------------------------------------------------------*/

}



module.exports = {
    notifyReminderForAssessmentState,
};
