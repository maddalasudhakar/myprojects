const { sendNotification, TEMPLATE_NAME, getSubmitterEmailsForMocBySbu, getSubmitterEmailsForPdpBySbu, ASSESSMENT_TYPE_PATHS } = require('../../../src/domain/notification');
const { getTemplatesByName } = require('../../../src/io/notify');

/**
 * Notification logic when a assessment PDP or MOC creation for some prodcuts is blocked by other assessments
 * Notify all the prodcuts blocked
 * @param {Request} req - Request triggering the logic 
 */
async function notifyProductBlockedPdpMoc(req) {

    let aRecipients = [];

    const { blockedProducts, sbu, type, adpProject } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    // Get template ID
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.PDP_MOC_PRODUCTS_BLOCKED);

    if (type === "PDP") {
         aRecipients = await getSubmitterEmailsForMocBySbu(sbu);
    } else if (type === "MOC") {
         aRecipients = await getSubmitterEmailsForPdpBySbu(sbu);
    }


    const aTokens = [];

    const sHtmlTable = buildHtmlTable(blockedProducts);

    aTokens.push({ id: "productList", value: sHtmlTable });
    aTokens.push({ id: "adpProject", value: adpProject });

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    })


    return `Notificaions of PDP or MOC Prodcuts blocked sent`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'blockedProducts',
        'sbu',
        'type',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}

/**
 * Builds html table with token values.
 *
 * @param {Object} aTokens - tokens  array 
 * @returns String of html table 
 */
function buildHtmlTable(aProducts) {
    
    let html = `<table border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse:collapse; font-family:Arial, sans-serif; font-size:14px; width:100%; max-width:800px;\"><thead style=\"background-color:#f5f5f5; text-align:left;\"><tr><th style=\"padding:8px;\">Product</th><th style=\"padding:8px;\">Request Name</th><th style=\"padding:8px;\">Link</th></tr></thead><tbody>`;
    
    // Get the base system URL for constructing links
    const systemUrl = process.env.ASSESSMENT_URL || cds.env?.ASSESSMENT_URL;

    for (const product of aProducts) {
        // Construct the direct URL to the assessment
        if (product.itemID == "") {
            basePath = ASSESSMENT_TYPE_PATHS.S;
        }
        else {
            basePath = ASSESSMENT_TYPE_PATHS.M;
        }
        const assessmentUrl = `${systemUrl.replace(/\/$/, '')}/${basePath.replace(/^\/|\/$/g, '')}/${product.ID}`;

        html += `<tr><td style=\"padding:8px;\">${product.product || "-"}<td style=\"padding:8px;\">${product.requestName || "-"}</td><td style="padding:8px;"><a href="${assessmentUrl}" target="_blank">Open</a></td></tr>`;
    }

    html += "</tbody></table>";

    return html;
}

module.exports = {
    notifyProductBlockedPdpMoc
}