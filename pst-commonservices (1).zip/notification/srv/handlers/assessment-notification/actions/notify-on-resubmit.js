
const { sendNotification, getTemplatesForAction,getMessageTokens, TEMPLATE_ACTION } = require('../../../src/domain/notification');

/**
 * Notification logic when an assessment is approved
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function notifyOnResubmit(req) {

    const { sbu, assessmentId, assessmentType, approver } = req.data;
    
    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {   
        return req.error(409, oCheck.reason);
    }

    // Each SBU has a separate list of recipients which has
    // to be recovered
    const aRecipients = [ approver ];

    // Prepare message tokens
    const aTokens = await getMessageTokens({assessmentId, assessmentType});
    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    // Get template IDs and Channels
    const aTemplates = await getTemplatesForAction(TEMPLATE_ACTION.RESUBMIT);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients, 
        tokens: aTokens, 
    });

    return `Resubmit notifications sent to sbu ${sbu} for assessment ${assessmentId}`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {
    
    const REQUIRED_FIELDS = [
        'sbu',
        'assessmentId',
        'assessmentType',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr])    acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }  
    return oResult;
    
};


module.exports = {
    notifyOnResubmit,
}