const { ADP_HANDLER } = require('../../../src/domain/notification');

/**
 * 
 * * Notification logic when ADP project is not linked to any product
 * @param {Request} req - Request triggering the logic 
 */

async function adpProjectNotLinked(req) {

    const { adpProject, sbu, assessor, submitter, processType } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {   
        return req.error(409, oCheck.reason);
    }
    
    // ADP Handler
    const handlerFn = ADP_HANDLER[processType];
    
    if (!handlerFn) {
        return req.error(400, `No handler defined for processType=${processType}`);
    }

    const response = await handlerFn({adpProject, sbu, assessor, submitter});
    return response;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'adpProject',
        'sbu',
        'processType'
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);

    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    
    return oResult;

};


module.exports = {
    adpProjectNotLinked,
}