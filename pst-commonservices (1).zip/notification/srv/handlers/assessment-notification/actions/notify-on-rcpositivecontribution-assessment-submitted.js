const { sendNotification, getMessageTokens, TEMPLATE_NAME, PROCESS_TYPES } = require('../../../src/domain/notification');
const { getTemplatesByName } = require('../../../src/io/notify');
const { ASSESSMENT_TYPE, ASSESSMENT_STATUS } = require('../../../src/domain/assessment');
const { getMyIdUsers } = require('../functions/get-my-id-users');

/**
 * Notification logic when a new RC Positive Contribution assessment is submitted
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function notifyOnRcPositiveContributionAssessmentSubmitted(req) {
    const { sbu, assessmentId } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    aNotificationRecipients = await getMyIdUsers({
        data: {
            sbu: sbu,
            status: ASSESSMENT_STATUS.SUBMITTED,
            processType: PROCESS_TYPES.RCPC
        }
    });

    const aRecipients = aNotificationRecipients.map(u => u.email);

    // Prepare message tokens
    const aTokens = await getMessageTokens({ assessmentId, assessmentType: ASSESSMENT_TYPE.MASS });
    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    // // Get template ID
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.RCPC_SUBMITTED_ASSESSMENT);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    })

    return `Submitted RCPC notifications sent to sbu ${sbu} for assessment ${assessmentId}`;



};

/**
 * Initial checks for input data before processing request
    * 
 * @param { Object } data - Input data provided in body
    */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'sbu',
        'assessmentId',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

};

module.exports = {
    notifyOnRcPositiveContributionAssessmentSubmitted
}