const { getTemplatesByProductType ,sendNotification } = require('../../../src/domain/notification');
const { getIdhProductsByMaterialKeyAndPropagation, getIbProductsByMaterialKey } = require('../../../src/io/pst');

async function notifyReminderForProductAssessmentOutdated (req) {

    let { responsible, secondResponsible, productType, products } = req.data;

    const oCheck = checkInputData(req.data);

    if (!oCheck.isValid) {
      throw new Error(oCheck.reason);
    }

    const aTemplates = await getTemplatesByProductType(productType);

    const aTokens = await getMessageTokens(products, productType);

    if (!aTokens || aTokens.length === 0) {
      throw new Error('No data could be retrieved for assessment');
    }

        
    if (responsible[0] === secondResponsible[0]) {
      secondResponsible = []
    }

    const results = await sendNotification({templates: aTemplates, recipients: responsible, ccRecipients: secondResponsible, tokens: aTokens});

    if (results.some(item => item.status === "rejected")) {
      throw new Error( "Failed to send notification");
    }
    
}


/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {
    
    const REQUIRED_FIELDS = [
        'responsible',
        'productType',
        'products',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr])    acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }  
    return oResult;
    
};

/**
 * Builds message tokens from a product type to be used in notification templates.
 *
 * @param {Object} products - productType string 
 * @param {Object} productType - productType string 
 * @returns Array of tokens 
 */

async function getMessageTokens(products, productType) {

    let aTokens = [];
    let aProducts = [];
    let htmlTable = '';

    if(productType === 'IDH') {
        aProducts = await getIdhProductsByMaterialKeyAndPropagation({aIdhMaterialKeys: products, propagation: true});
    }

    if(productType === 'IB') {
        aProducts = await getIbProductsByMaterialKey({aIbMaterialKeys: products});
    }

    htmlTable = buildHtmlTable(aProducts, productType);
    aTokens.push({ id: "productType", value: productType });
    aTokens.push({ id: "productList", value: htmlTable });

    return aTokens;
};

/**
 * Builds html table with token values.
 *
 * @param {Object} aTokens - tokens  array 
 * @param {Object} productType - product type string 
 * @returns String of html table 
 */
function buildHtmlTable(aProducts, productType) {

  const prefix = productType === "IB" ? "IB" : "IDH";

  let html = `<table border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse:collapse; font-family:Arial, sans-serif; font-size:14px; width:100%; max-width:800px;\"><thead style=\"background-color:#f5f5f5; text-align:left;\"><tr><th style=\"padding:8px;\">${prefix}</th><th style=\"padding:8px;\">${prefix} name</th><th style=\"padding:8px;\">Last approval date</th></tr></thead><tbody>`;

  for (const product of aProducts) {
    html += `<tr><td style=\"padding:8px;\">${product.materialtNumber || "-"}</td><td style=\"padding:8px;\">${product.materialDescription || "-"}</td><td style=\"padding:8px;\">${product.approvalDate || "-"}</td></tr>`;
  }

  html += "</tbody></table>";

  return html;
}


 
module.exports = {
    notifyReminderForProductAssessmentOutdated
}