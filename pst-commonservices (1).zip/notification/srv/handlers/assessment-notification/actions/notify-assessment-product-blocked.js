const { sendNotification, TEMPLATE_NAME, ASSESSMENT_TYPE_PATHS} = require('../../../src/domain/notification');
const { getTemplatesByName } = require('../../../src/io/notify');

/**
 * Notification logic when a assessment creation for some prodcuts is blocked by other assessments
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function notifyAssessmentProductBlocked(req) {

    const { blockingAssessment, sbu, type } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    const aNotificationsGroups = groupById(blockingAssessment);

    // Get template ID
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.PRODUCTS_BLOCKING_ASSESSMENT);

    for (const oGroup of aNotificationsGroups) {
        let aTokens = [],
            aRecipients = [];

        const sHtmlTable = buildHtmlTable(oGroup.items);

        for (const item of oGroup.items) {
            if (item.assessor) aRecipients.push(item.assessor);
            if (item.submitter) aRecipients.push(item.submitter);
            if (item.approver) aRecipients.push(item.approver);
        }

        aRecipients = [...new Set(aRecipients)];

        aTokens.push({ id: "productList", value: sHtmlTable });

        // Send notifications
        const result = await sendNotification({
            templates: aTemplates,
            recipients: aRecipients,
            tokens: aTokens,
        })

    }


    return `Notificaions of Prodcuts blocking sent`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'blockingAssessment',
        'type',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}

/**
 * Group assessment notifications by assessment ID
 * 
 * @param {Object} data - Input data provided in body 
 */
function groupById(blockingAssessment) {
  const groups = new Map();

  for (const item of blockingAssessment || []) {
    const { ID } = item;
    if (!ID) continue; // ignorar si no tiene ID

    if (!groups.has(ID)) {
      groups.set(ID, { ID, items: [] });
    }

    groups.get(ID).items.push(item);
  }

  return Array.from(groups.values());
}

/**
 * Builds html table with token values.
 *
 * @param {Object} aTokens - tokens  array 
 * @returns String of html table 
 */
function buildHtmlTable(aProducts) {

    let html = `<table border=\"1\" cellspacing=\"0\" cellpadding=\"6\" style=\"border-collapse:collapse; font-family:Arial, sans-serif; font-size:14px; width:100%; max-width:800px;\"><thead style=\"background-color:#f5f5f5; text-align:left;\"><tr><th style=\"padding:8px;\">Product</th><th style=\"padding:8px;\">Request Name</th><th style=\"padding:8px;\">Link</th></tr></thead><tbody>`;
    
    // Get the base system URL for constructing links
    const systemUrl = process.env.ASSESSMENT_URL || cds.env?.ASSESSMENT_URL;
    let basePath;
    for (const product of aProducts) {
        
        // Construct the direct URL to the assessment
        if (product.itemID == "") {
            basePath = ASSESSMENT_TYPE_PATHS.S;
        }
        else {
            basePath = ASSESSMENT_TYPE_PATHS.M;
        }
      
        const assessmentUrl = `${systemUrl.replace(/\/$/, '')}/${basePath.replace(/^\/|\/$/g, '')}/${product.ID}`;

        html += `<tr><td style=\"padding:8px;\">${product.product || "-"}<td style=\"padding:8px;\">${product.requestName || "-"}</td><td style="padding:8px;"><a href="${assessmentUrl}" target="_blank">Open</a></td></tr>`;
    }

    html += "</tbody></table>";

    return html;
}

module.exports = {
    notifyAssessmentProductBlocked
}