
const { sendNotification, getTemplatesForAction,getMessageTokens, TEMPLATE_ACTION} = require('../../../src/domain/notification');
const { getNotificationRecipientsFromPst, ASSESSMENT_STATUS_CODES } = require('../../../src/domain/assessment');
/**
 * Notification logic when an assessment is submitted
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function notifyOnSave(req) {

    const { sbu, assessmentId, assessmentType } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    // Ge recipients for the notification
    const aRecipients = await getNotificationRecipientsFromPst({ assessmentId, status: ASSESSMENT_STATUS_CODES.SAVED });
    const aEmails = (Array.isArray(aRecipients) ? aRecipients : [])
        .map(item => item?.recipientEmail)
        .filter(Boolean);

    // Prepare message tokens
    const aTokens = await getMessageTokens({ assessmentId, assessmentType });
    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    // Get template ID
    const aTemplates = await getTemplatesForAction(TEMPLATE_ACTION.SAVE);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aEmails,
        tokens: aTokens,
    })


    return `Save notifications sent to sbu ${sbu} for assessment ${assessmentId}`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'sbu',
        'assessmentId',
        'assessmentType',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}


module.exports = {
    notifyOnSave,
}