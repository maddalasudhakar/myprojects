const { sendNotification, getMessageTokens, TEMPLATE_NAME, getSubmitterEmailsForPdpBySbu} = require('../../../src/domain/notification');
const { getTemplatesByName } = require('../../../src/io/notify');
/**
 * Notification logic when a new PDP assessment is saved
 * 
 * @param {Request} req - Request triggering the logic 
 */
async function notifyOnNewPdpSaved(req) {

    const { sbu, assessmentId, assessmentType } = req.data;

    // Initial validations
    const oCheck = checkInputData(req.data);
    if (!oCheck.isValid) {
        return req.error(409, oCheck.reason);
    }

    const aRecipients = await getSubmitterEmailsForPdpBySbu(sbu);

    // Prepare message tokens
    const aTokens = await getMessageTokens({ assessmentId, assessmentType });
    if (!aTokens || aTokens.length === 0) {
        return req.error(409, 'No data could be retrieved for assessment');
    }

    // Get template ID
    const aTemplates = await getTemplatesByName(TEMPLATE_NAME.PDP_NEW_SAVE_ASSESSMENT);

    // Send notifications
    const result = await sendNotification({
        templates: aTemplates,
        recipients: aRecipients,
        tokens: aTokens,
    })


    return `Save PDP notifications sent to sbu ${sbu} for assessment ${assessmentId}`;

};

/**
 * Initial checks for input data before processing request
 * 
 * @param {Object} data - Input data provided in body 
 */
function checkInputData(data) {

    const REQUIRED_FIELDS = [
        'sbu',
        'assessmentId',
        'assessmentType',
    ];
    const oResult = {
        isValid: true
    }

    // Check mandatory parameters
    const aMissingParameters = REQUIRED_FIELDS.reduce((acc, curr) => {
        if (!data[curr]) acc.push(curr);
        return acc;
    }, []);
    if (aMissingParameters.length > 0) {

        const sParameters = aMissingParameters.join(', ');
        oResult.isValid = false;
        oResult.reason = `Missing required parameters: ${sParameters}`;

        return oResult;

    }
    return oResult;

}

module.exports = {
    notifyOnNewPdpSaved
}