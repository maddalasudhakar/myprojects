const cds = require('@sap/cds');
const handlers = require('./handlers');

module.exports = cds.service.impl(async function (srv) {
     srv.on("checkAssessmentOnSavedPending", handlers.assessmentReminder.actions.checkAssessmentOnSavedPending);
     srv.on("checkAssessmentOnDraftPending", handlers.assessmentReminder.actions.checkAssessmentOnDraftPending);
     srv.on("checkAssessmentOnSubmittedPending", handlers.assessmentReminder.actions.checkAssessmentOnSubmittedPending);
     srv.on("checkAssessmentOnUnderResubmissionPending", handlers.assessmentReminder.actions.checkAssessmentOnUnderResubmissionPending);
     srv.on("checkAssessmentOnResubmittedPending", handlers.assessmentReminder.actions.checkAssessmentOnResubmittedPending);
     srv.on("checkAssessmentOnUnderReviewPending", handlers.assessmentReminder.actions.checkAssessmentOnUnderReviewPending);
     srv.on("checkIbAssessmentOutdated", handlers.assessmentReminder.actions.checkIbAssessmentOutdated);
     srv.on("checkIdhAssessmentOutdated", handlers.assessmentReminder.actions.checkIdhAssessmentOutdated);
});