const cds = require('@sap/cds');

const handlers = require("./handlers");

module.exports = async function (srv) {

    this.on("processApprobedIdhProducts", handlers.actions.processApprobedIdhProducts);
    this.on("processApprobedIbProducts", handlers.actions.processApprobedIbProducts);
    this.on("processRejectedProducts", handlers.actions.processRejectedProducts);
    this.on("processCPIRetrial", handlers.actions.processCPIRetrial);
    this.on("screeningMismatchedSustClass", handlers.actions.screeningMismatchedSustClass);
    this.on("createAssessmentsForMismatchedProducts", handlers.actions.createAssessmentsForMismatchedProducts);
    this.on("adpAssessmentJobTrigger", handlers.actions.adpAssessmentJobTrigger);
    this.on("pdpAssessmentTrigger", handlers.actions.pdpAssessmentTrigger);
    this.on("pdpAssessmentDelta", handlers.actions.pdpAssessmentDelta);
    this.on("mocAssessmentDelta", handlers.actions.mocAssessmentDelta);
    this.on("mocAssessmentTrigger", handlers.actions.mocAssessmentTrigger);
    this.on("mismatchedAssessmentJobTrigger", handlers.actions.mismatchedAssessmentJobTrigger);
    this.on("heartAssessmentJobTrigger", handlers.actions.heartAssessmentJobTrigger);
    this.on("heartAssessmentTrigger", handlers.actions.heartAssessmentTrigger);
    this.on("heartAssessmentDelta", handlers.actions.heartAssessmentDelta);
    this.on("rcPositiveContributionAssessmentDelta", handlers.actions.rcPositiveContributionAssessmentDelta);
    this.on("rcPositiveContributionAssessmentTrigger", handlers.actions.rcPositiveContributionAssessmentTrigger);
    this.on("rcPositiveContributionAssessmentJobTrigger", handlers.actions.rcPositiveContributionAssessmentJobTrigger);
    this.on("jobOrchestrator", handlers.actions.jobOrchestrator);
    
};