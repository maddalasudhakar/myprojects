const cds = require("@sap/cds");

const {
    ENTITIES,
    TYPE_IB,
    TYPE_IDH,
    TYPE_OTHER,
} = require('./constants');

/**
 * Retrieves mass assessment items from the database based on given status and processing status.
 *
 * @param {string[]} aStatus - Array of statuses to filter the items.
 * @param {string[]} aProcessingStatus - Array of processing statuses to filter the items.
 * @returns {Promise<Object[]>} - A promise that resolves to an array of mass assessment item objects.
 */
async function getMassAssessmentItemsDB(aStatus, aProcessingStatus, sType) {

    if (!aStatus || aStatus.length === 0) return [];

    const db = await cds.connect.to("db");
    const aItems = await db.run(
        SELECT.from(ENTITIES.DB.MASS_ASSESSMENT_ITEMS)
            .where({
                status: aStatus,
                communicationStatus: aProcessingStatus,
                productType: sType
            })
    );
    return aItems;

};

/**
 * Retrieves single assessment items from the database based on given status and processing status.
 *
 * @param {string[]} aStatus - Array of statuses to filter the items.
 * @param {string[]} aProcessingStatus - Array of processing statuses to filter the items.
 * @returns {Promise<Object[]>} - A promise that resolves to an array of single assessment item objects.
 */
async function getSingleAssessmentDB(aStatus, aProcessingStatus, sType) {

    if (!aStatus || aStatus.length === 0) return [];

    const db = await cds.connect.to("db");

    const aItems = await db.run(
        SELECT.from(ENTITIES.DB.SINGLE_ASSESSMENT)
            .where({
                status: aStatus,
                communicationStatus: aProcessingStatus,
                productType: sType
            })
    );

    return aItems;

};

async function updateMassAssessmentItemsProcessingStatus(aAssessment, sProcessingStatus) {
    const aAssessmentIds = aAssessment.map(oAssessment => oAssessment.ID);

    if (!aAssessmentIds || aAssessmentIds.length === 0) return [];

    try {
        const db = await cds.connect.to("db");
        await db.run(
            UPDATE(ENTITIES.DB.MASS_ASSESSMENT_ITEMS)
                .set({ communicationStatus: sProcessingStatus })
                .where({ ID: { in: aAssessmentIds } })
        );

    } catch (oError) {
        console.error('Error updating processing status in MassAssessment:', sProcessingStatus);
        console.error(oError);
        throw oError;
    }

};

async function updateSingleAssessmentItemsProcessingStatus(aAssessment, sProcessingStatus) {
    const aAssessmentIds = aAssessment.map(oAssessment => oAssessment.ID);

    if (!aAssessmentIds || aAssessmentIds.length === 0) return [];

    try {
        const db = await cds.connect.to("db");
        await db.run(
            UPDATE(ENTITIES.DB.SINGLE_ASSESSMENT)
                .set({ communicationStatus: sProcessingStatus })
                .where({ ID: { in: aAssessmentIds } })
        );

    } catch (oError) {
        console.error('Error updating processing status in SingleAssessment:', sProcessingStatus);
        console.error(oError);
        throw oError;
    }

};

async function sendDataToCPI(aApprobedIDH, aApprobedIB, aIdhProofDocuments, aIbProofDocuments) {
    const oCPIConnection = await cds.connect.to('pst-integrationsuite-ib-idh-product');
    try {
        const aOnPremiseIdh = await _buildOnPremiseData(aApprobedIDH, aIdhProofDocuments, TYPE_IDH);
        const aOnPremiseIb = await _buildOnPremiseData(aApprobedIB, aIbProofDocuments, TYPE_IB);

        if (!aOnPremiseIdh || !Array.isArray(aOnPremiseIdh)) {
            console.error("IDH data not properly built.");
        }

        if (!aOnPremiseIb || !Array.isArray(aOnPremiseIb)) {
            console.error("IB data not properly built.");
        }

        if (aOnPremiseIb.length > 0) {
            try {
                oIbResponse = await oCPIConnection.send({
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    path: `/`,
                    data: aOnPremiseIb
                });
                console.log("IB sent to P03: " + JSON.stringify(aOnPremiseIb));
            } catch (oError) {
                console.error("Error sending IB data to CPI:", oError.message);
                console.error(oError)
                throw oError;
            }
        }

        if (aOnPremiseIdh.length > 0) {
            try {
                oIdhResponse = await oCPIConnection.send({
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    path: `/`,
                    data: aOnPremiseIdh
                });
                console.log("IDH sent to P03: " + JSON.stringify(aOnPremiseIdh));
            } catch (oError) {
                console.error("Error sending IDH data to CPI:", oError.message);
                console.error(oError);
                throw oError;
            }
        }

    } catch (oError) {
        console.error("Error processing OnPremise data or sending to CPI:", oError.message);
        console.error(oError);
        throw oError;
    }

}

async function sendDataToFeedback(aRejected) {
    const oFeedbackConnection = await cds.connect.to('pst-feedback');

    try {
        const aPayload = {
            items: aRejected.map(item => ({
                assessmentID: item.ID,
                product: item.PRODUCT
            }))
        };

        const oFeedbackResponse = await oFeedbackConnection.send({
            method: "POST",
            path: "/assessmentRejectionFeedback",
            data: aPayload
        });

    } catch (oError) {
        const aPayload = {
            items: aRejected.map(item => ({
                assessmentID: item.ID,
                product: item.PRODUCT
            }))
        };
        const sChunkString = JSON.stringify(aPayload);
        const jsonSize = Buffer.byteLength(sChunkString, 'utf8');

        console.log(JSON.stringify(`chunk size: ${jsonSize}, chunk length: ${sChunkString.length}, chunk n items: ${aRejected.length}, chunk object: ${sChunkString}`));     

        console.error("Error processing sending data to feedback application:", oError.message);
        console.error(oError);
        throw oError;
    }

}

async function getProofDocuments(aAssessments) {
    const aRequestIds = aAssessments.map(obj => obj.ID);

    if (aRequestIds.length > 0) {
        return await cds.run(
            SELECT.from(ENTITIES.DB.ASSESSMENT_PROOFDOCUMENTS).where({ requestId: aRequestIds, active: true })
        );
    }

    return [];
}

async function _buildOnPremiseData(aApprobedProducts, aProofDocuments, sType) {
    const oConfig = _getTypeClassUpdConfig(sType);
    if (!oConfig) {
        return;
    }
    const aProofTypes = await _getOnpremiseProofTypes();
    if (!aProofTypes || aProofTypes.length === 0) {
        return;
    }

    const oProofConfig = _getProofPointConfig();

    // Aux comparison function
    const compare = (a, b) => {
        if (a.createdAt < b.createdAt) {
            return 1;
        } else {
            return -1;
        }
    };

    const aOnPremiseData = [];
    for (const oProduct of aApprobedProducts) {
        // Get proofDocuments of the assessment product
        const aRelatedProofDocs = aProofDocuments.filter(doc => doc.REQUESTID === oProduct.ID);


        const aSortDocuments = aRelatedProofDocs?.sort(compare);
        //const aDocumentTypes = aSortDocuments.slice(0, 3).map(item => item.type);
        //Map documents types with onPremiseTypes
        aSortDocuments.forEach(doc => {
            const sType = aProofTypes?.find(proof => proof?.CODE === doc?.TYPE)?.ONPREMISECODE;
            doc.ONPREMISCODE = sType || TYPE_OTHER;
        });

        //Map assessment data with onPremise data
        const oSendData = {};
        for (const oMap of oConfig.mapping) {

            if (oMap.from === "PROPAGATION") {
                oSendData[oMap.to] = oProduct[oMap.from];
            } else if (oMap.from === "EXTERNALCOMMUNICATION") {
                oSendData[oMap.to] = oProduct[oMap.from] === true ? "Y" : "N";
            } else {
                oSendData[oMap.to] = oProduct[oMap.from] || "";
            }

            if (oMap.proofDocument && aOnpremiseTypes && aOnpremiseTypes?.length > 0) {
                const sType = aOnpremiseTypes.splice(0, 1)[0];
                if (sType) oSendData[oMap.to] = sType;
            }
        }

        oSendData._sppt = aSortDocuments.map((doc, index) => {
            const oProofItem = {};
            for (const map of oProofConfig.mapping) {
                const to = map.to;
                const from = map.from;

                if (to === "Material") {
                    oProofItem[to] = sType === "IDH" ? oProduct.PRODUCT : "";
                } else if (to === "IbProd") {
                    oProofItem[to] = sType === "IB" ? oProduct.PRODUCT : "";
                } else if (to === "Seqno") {
                    oProofItem[to] = index + 1;
                } else if (to === "SpeedReqId") {
                    oProofItem[to] = oProduct.ID;
                } else if (from) {
                    oProofItem[to] = doc[from] || "";
                } else {
                    oProofItem[to] = "";
                }
            }
            return oProofItem;
        });
        /* oSendData._sppt = aSortDocuments.map((doc, index) => {
             return {
                 SpeedReqId: doc.ID || "",
                 Material: sType === "IDH" ? oProduct.PRODUCT : "",
                 IbProd: sType === "IB" ? oProduct.PRODUCT : "",
                 Seqno: index + 1,
                 ProofPoint: doc.ONPREMISCODE || TYPE_OTHER,
                 OthPp: ""
             };
         });*/

        aOnPremiseData.push(oSendData);
    }

    return aOnPremiseData;

}

function chunkArray(aArray, iChunkSize) {
    const aChunks = [];
    for (let i = 0; i < aArray.length; i += iChunkSize) {
        aChunks.push(aArray.slice(i, i + iChunkSize));
    }
    return aChunks;
}

async function _getOnpremiseProofTypes() {

    const db = await cds.connect.to('db');

    return await cds.run(SELECT.from(ENTITIES.DB.PROOF_TYPES));

};

function _getTypeClassUpdConfig(sType) {
    aConfigs = [
        {
            type: TYPE_IDH,
            method: "PUT",
            mapping: [
                { from: "ID", to: "SpeedReqId" },
                { from: "PRODUCT", to: "Material" },
                { from: "SUSTCLASS", to: "SusClass" },
                { from: "COMMENT", to: "AssesmentExplanation" },
                { from: "CONTRIBUTOR1", to: "SusContrib1" },
                { from: "CONTRIBUTOR2", to: "SusContrib2" },
                { from: "CONTRIBUTOR3", to: "SusContrib3" },
                { from: "CATEGORY1", to: "SusCateg1" },
                { from: "CATEGORY2", to: "SusCateg2" },
                { from: "CATEGORY3", to: "SusCateg3" },
                { from: "PROPAGATION", to: "MaintManual" },
                { from: "EXTERNALCOMMUNICATION", to: "ExternSustainComunication" }
            ]
        },
        {
            type: TYPE_IB,
            method: "PATCH",
            mapping: [
                { from: "ID", to: "SpeedReqId" },
                { from: "PRODUCT", to: "IbProd" },
                { from: "SUSTCLASS", to: "SusClass" },
                { from: "COMMENT", to: "AssesmentExplanation" },
                { from: "CONTRIBUTOR1", to: "SusContrib1" },
                { from: "CONTRIBUTOR2", to: "SusContrib2" },
                { from: "CONTRIBUTOR3", to: "SusContrib3" },
                { from: "CATEGORY1", to: "SusCateg1" },
                { from: "CATEGORY2", to: "SusCateg2" },
                { from: "CATEGORY3", to: "SusCateg3" },
                { from: "EXTERNALCOMMUNICATION", to: "ExternSustainComunication" }
            ]
        }
    ];

    return aConfigs.find(item => item.type === sType);
};

function _getProofPointConfig() {
    return {
        mapping: [
            { from: "ID", to: "SpeedReqId" },
            { from: "", to: "Material" },
            { from: "", to: "IbProd" },
            { from: "", to: "Seqno" },
            { from: "ONPREMISCODE", to: "ProofPoint" },
            { from: "", to: "OthPp" }
        ]
    }
}



module.exports = {
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    getProofDocuments,
    sendDataToCPI,
    updateMassAssessmentItemsProcessingStatus,
    updateSingleAssessmentItemsProcessingStatus,
    sendDataToFeedback,
    chunkArray
}