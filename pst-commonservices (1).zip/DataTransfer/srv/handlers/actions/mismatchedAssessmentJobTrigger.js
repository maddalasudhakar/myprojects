
const cds = require('@sap/cds');

const { ENTITIES, PROCESS_TO_HANDLER, PROCESS_TYPE, SERVICES, } = require('../../src/constants.js');

const logger = cds.log('rc-mismatch-job-trigger');

/**
 * Handler for action in charge of managing mismatched Job triggering
 * 
 * @param {cds.Request} req - Request object 
 */
async function mismatchedAssessmentJobTrigger(req) {


    logger.info('Rc mismatch job trigger started');

    const orchecstratorLog = {
        ID: cds.utils.uuid(),
        createdAt: new Date(),
        createdBy: 'JOB_ORCHESTRATOR',
        modifiedAt: new Date(),
        modifiedBy: 'JOB_ORCHESTRATOR',
        type: 'RCM',
        status: '01',
    };
    await cds.tx(
        INSERT.into(ENTITIES.DB.JOB_LOGS_TABLE)
            .entries([orchecstratorLog])
    );
    
    req.on('done', async () => {
        await cds.tx(
            UPDATE( ENTITIES.DB.JOB_LOGS_TABLE )
                .set({ status: '03' })
                .where({ ID: orchecstratorLog.ID })
        );
        logger.info('Rc mismatch job trigger finished');
    });

    // Get last time each kind of jib was executed
    const db = await cds.connect.to(SERVICES.DB);
    const lastJobs = await db.run(
        SELECT
            .from(ENTITIES.DB.MISMATCHED_ASSESSMENT_EXECUTION_LOGS)
            .columns('type', 'MAX(createdAt)')
            .groupBy('type')
    );

    const jobParams = getMismatchedAssessmentJobConfiguration();

    // Check if first time already happened and if not trigger it
    try {
        await triggerJob(lastJobs, jobParams, PROCESS_TYPE.SUSTAINABILITY_CLASS_SCREENING);
        
        const wait = (s) => new Promise(res => setTimeout(res, s * 1000));
        await wait( 120 );

        await triggerJob(lastJobs, jobParams, PROCESS_TYPE.MISMATCHED_PRODUCT_ASSESSMENT_CREATION);
    } catch (error) {
        logger.log(error);
        return req.error({ code: 500, message: `Error in job triggering: ${error}` })
    }

    return 'Job finished';

};

/**
 * Method to trigger jobs
 * 
 * @param {*} lastJobs 
 * @param {*} jobParams 
 * @param {*} processType 
 * @param {*} status 
 */
async function triggerJob(lastJobs, jobParams, processType) {

    const DataTransferService = await cds.connect.to(SERVICES.DATA_TRANSFER);
    const now = new Date();

    const MINUTE_TO_MS_RATE = 1000 * 60;
    const hasLastJob = lastJobs.some(item => item.TYPE === processType);
    const jobParam = jobParams.subJobs?.find(item => item.processType === processType);
    // If already triggeredd once, check time. If not, trigger it
    if (hasLastJob && jobParam) {

        const job = lastJobs.find(item => {
            return item.TYPE === processType;
        });        

        const isInScheduledTime = isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);
        if (jobParam.active && isInScheduledTime) {
            await DataTransferService.send(PROCESS_TO_HANDLER[processType]);
        }

    } else if (jobParam?.active) {

        await DataTransferService.send(PROCESS_TO_HANDLER[processType]);

    }

};


/**
 * Retrieves job configuration
 * 
 * @returns  {Object} Retrieves job configuration
 */
function getMismatchedAssessmentJobConfiguration() {

    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"];
    const jobParams =
        userProvided?.find(item => item.name === 'DataTransfer-job-params')?.credentials || cds.env?.JOB_PARAMS;

    return jobParams.mismatchedAssessmentJobTrigger;

};

/**
 * Checks if a date is prior to a certain interval from provided one
 * 
 * @param {Date} dateToCheck - Date to compare
 * @param {Date} referenceDate - Reference date
 * @param {number} intervalMs - Miliseconds of interval 
 * @returns 
 */
function isDateLessThanInterval(dateToCheck, referenceDate, intervalMs) {

    // Convert to timestamps for comparison
    const checkTime = new Date(dateToCheck).getTime();
    const referenceTime = new Date(referenceDate).getTime();

    // Calculate the threshold (reference date minus interval)
    const thresholdTime = referenceTime - intervalMs;

    // Return true if dateToCheck is earlier than the threshold
    return checkTime < thresholdTime;

};

module.exports = {
    mismatchedAssessmentJobTrigger,
};