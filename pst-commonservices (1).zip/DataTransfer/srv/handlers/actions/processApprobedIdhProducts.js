const cds = require("@sap/cds");
const {
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    sendDataToCPI,
    getProofDocuments,
    updateMassAssessmentItemsProcessingStatus,
    updateSingleAssessmentItemsProcessingStatus,
    chunkArray
} = require("../../src/assessment-utils");

const {
    ASSESSMENT_STATUS,
    PROCESSING_STATUS,
    TYPE_IDH,
    CHUNK_NUMBER
} = require('../../src/constants');

async function processApprobedIdhProducts(req) {
    try {
        const aStatus = [ASSESSMENT_STATUS.APPROVED],
            sProcessingStatus = PROCESSING_STATUS.PENDING,
            sSendedStatus = PROCESSING_STATUS.SENDED_CPI;

        const aMassAssessmentItemsDB = await getMassAssessmentItemsDB(aStatus, sProcessingStatus, TYPE_IDH);
        const aSingleAssessmentsDB = await getSingleAssessmentDB(aStatus, sProcessingStatus, TYPE_IDH);

        const aMassItemsWithTag = aMassAssessmentItemsDB.map(item => ({ ...item, _source: 'MASS' }));
        const aSingleItemsWithTag = aSingleAssessmentsDB.map(item => ({ ...item, _source: 'SINGLE' }));


        const allAssessments = [...aMassItemsWithTag, ...aSingleItemsWithTag];

        const aApprobedIDH = allAssessments.filter(item => item.STATUS === ASSESSMENT_STATUS.APPROVED && item.PRODUCTTYPE === TYPE_IDH);

        const aChunks = chunkArray(aApprobedIDH, CHUNK_NUMBER);

        for (const chunk of aChunks) {
            try {
                await cds.tx(async (tx) => {

                    const oMassItems = chunk.filter(item => item._source === 'MASS');
                    const oSingleItems = chunk.filter(item => item._source === 'SINGLE');

                    await updateMassAssessmentItemsProcessingStatus(oMassItems, sSendedStatus);
                    await updateSingleAssessmentItemsProcessingStatus(oSingleItems, sSendedStatus);

                    const oProofDocuments = await getProofDocuments(chunk);

                    await sendDataToCPI(chunk, [], oProofDocuments, []);

                });
            } catch (error) {
                console.error("Error sending data to CPI:", error.message);
            }
        }

    } catch (oError) {
        console.error("Error in processApprobedIdhProducts:", oError.message);
        console.error(oError);
        throw oError;
    }

}

module.exports = {
    processApprobedIdhProducts,
}  