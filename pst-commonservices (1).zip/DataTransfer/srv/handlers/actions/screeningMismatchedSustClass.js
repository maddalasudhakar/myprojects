const cds = require("@sap/cds");
const { chunkArray } = require('../../src/assessment-utils.js');
const { ENTITIES, CHUNK_NUMBER, MAX_DB_BATCH, MISMATCH_STATUS, PROCESS_TYPE, } = require('../../src/constants.js');


/** Number of entries to be processed by delta every time */
const DELTA_SIZE = 1000;

const logger = cds.log('rc-mismatch-delta');

// SQL query to retrieve products whose sustainability class does not match the RC pre-flag mapping
const idhMismatchesQuery = `
    SELECT TOP ${DELTA_SIZE}
        PST.materialtNumber AS PRODUCT,
        PST.sbu AS SBU,
        DS.RC_SUSTAINABILITYCLASSKEY AS RCPREFLAG,
        PST.sustClass AS SUSTCLASS
    FROM COM_SUSTAINABILITY_IDHUPDATED AS PST
    LEFT JOIN COM_SUSTAINABILITY_VT_V_IDH AS DS
        ON PST.materialtNumber = DS.IDH_MATERIAL_NR
    LEFT JOIN COM_SUSTAINABILITY_BACKGROUND_RCPREFLAGTOSUSTCLASSMISMATCHMAPPING AS MAP
        ON DS.RC_SUSTAINABILITYCLASSKEY = MAP.rcPreFlag
       AND PST.sustClass = MAP.sustClass
       LEFT JOIN COM_SUSTAINABILITY_BACKGROUND_RCPREFLAGSUSTCLASSMISMATCHEDASSESSMENTLOG AS LOG
    ON PST.materialtNumber = LOG.product
    AND (LOG.status = '01' OR  LOG.status = '02')
    WHERE 
        MAP.rcPreFlag IS NULL
        AND LOG.product IS NULL;`

/**
 * Main handler that starts the delta process
 * @param {*} req 
 */
async function screeningMismatchedSustClass(req) {


    // Start the first delta iteration
    await executeDeltaIteration(0);

}


/**
 * Executes a single delta iteration to log products with mismatched sustainability class
 * @async
 * @param {number} executionNumber - Current iteration count to prevent infinite recursion
 * @returns 
 */

async function executeDeltaIteration(executionNumber) {
    logger.log("Screeaning Mismatched SustClass Execution Number: ", executionNumber);

    if (executionNumber >= CHUNK_NUMBER) {

        await insertMismatchedAssessmentExecutionLog();
        logger.log('Rc mismatch screening finished');
        return;
    }

    const db = await cds.connect.to("db");

    // Retrieve mismatched products
    const idhMismatches = await db.run(idhMismatchesQuery);

    if (!idhMismatches || idhMismatches.length === 0) {

        await insertMismatchedAssessmentExecutionLog();
        logger.log('Rc mismatch screening finished');
        return;
    }

    // Split results into manageable batches
    const aBatchesToInsert = chunkArray(idhMismatches, MAX_DB_BATCH);

    // Get privileged user and current timestamp to get managed fields
    const user = new cds.User.Privileged().id;
    const now = new Date().toISOString();

    // Process each batch and insert into database
    for (const aBatch of aBatchesToInsert) {

        const aEntries = aBatch.map(oMismatch => ({
            id: cds.utils.uuid(),
            createdAt: now,
            createdBy: user,
            modifiedAt: now,
            modifiedBy: user,
            product: oMismatch.PRODUCT,
            sbu: oMismatch.SBU,
            rcPreFlag: oMismatch.RCPREFLAG,
            sustClass: oMismatch.SUSTCLASS,
            status: MISMATCH_STATUS.PENDING
        }));

        // Map query results into log entries
        await cds.tx( async () => {
            await db.run(
                INSERT.into(ENTITIES.DB.RC_PREFLAG_MISMATCHED_LOG).entries(aEntries)
            );
        });

    }
    // Spawn next delta iteration asynchronously

    cds.spawn({after: 100}, async () => {
        await executeDeltaIteration(executionNumber + 1);
    });


}

async function insertMismatchedAssessmentExecutionLog() {
    const db = await cds.connect.to("db");
    // Get privileged user and current timestamp to get managed fields
    const user = new cds.User.Privileged().id;
    const now = new Date().toISOString();

    await db.run(
        INSERT.into(ENTITIES.DB.MISMATCHED_ASSESSMENT_EXECUTION_LOGS).entries([
            {
                id: cds.utils.uuid(),
                createdAt: now,
                createdBy: user,
                modifiedAt: now,
                modifiedBy: user,
                type: PROCESS_TYPE.SUSTAINABILITY_CLASS_SCREENING,
                status: MISMATCH_STATUS.FINALISED,
            },
        ])
    );

}


module.exports = {
    screeningMismatchedSustClass,
};
