const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../../src/batching-utils');

/** Default batch size for DB */
const DB_BATCH_SIZE = 1000;

/** Number of entries to be processed by delta every time */
DELTA_SIZE = 5000;

/** Services available to use */
const SERVICES = {
    DB: 'db'
};

/** Entitites available to use */
const ENTITIES = {
    DB: {
        HEART_SNAPSHOT: 'COM_SUSTAINABILITY_VT_V_HEART_PCF_CLUSTER_AVGS_SNAPSHOT',
        HEART_EXECUTION: 'COM_SUSTAINABILITY_BACKGROUND_HEARTEXECUTION',
        LATEST_HEART_EXECUTION: 'COM_SUSTAINABILITY_BACKGROUND_HEARTLATESTPRODUCTEXECUTION',
        HEART_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_HEARTJOBEXECUTIONLOGS',
        IDH: 'COM_SUSTAINABILITY_IDHUPDATED',
    }
};

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    FINALISED: '03',
};

/** Available process types */
const PROCESS_TYPE = {
    HEART_DELTA: 'HEART_DELTA',
};

/** Limit of consecutive delta calls */
const MAX_DELTA_ITERATIONS_PER_EXECUTION = 100;

/** Generic background user */
const GENERIC_USER = 'HEART_DELTA_JOB';

/** Generic logger to use */
const logger = cds.log('heart-delta');

/**
 * Handler for service action pdpAssessmentDelta that calculat
 * @param {*} req 
 */
async function heartAssessmentDelta ( req ) {

    logger.info('HEART delta triggered');

    // Save execution log
    req.on('succeeded', async () => {
        const dNow = new Date();
        cds.spawn( async () => {
            const db = await cds.connect.to('db');
            const result = await db.run(
                INSERT
                    .into(ENTITIES.DB.HEART_JOBS)
                    .entries([{
                        ID: cds.utils.uuid(),
                        createdAt: dNow,
                        createdBy: GENERIC_USER,
                        modifiedAt: dNow,
                        modifiedBy: GENERIC_USER,
                        type: PROCESS_TYPE.HEART_DELTA, 
                        status: PROCESSING_STATUS.FINALISED 
                    }])
            )
            logger.info('Log insertion result ', result);
        });
    })

    // Fill delta table
    await executeDeltaIteration(0);

};

/**
 * Function to execute a single extraction for delta process
 * 
 * @param {number} executionNumber - Number of recursive executions
 */
async function executeDeltaIteration(executionNumber) {

    // Query all unreplicated to delta queries from datasphere
    const aNewEntries = await getDeltaMaterials();

    logger.info('Delta execution found entries: ', aNewEntries.length);

    if (!aNewEntries || aNewEntries.length === 0) return;

    // Query related last run
    const mLastEntries = await getLastEntries( aNewEntries.map(item => item.FGMATERIALKEY) );

    // Query material data
    const mIdhData = await getIdhData( aNewEntries.map(item => item.FGMATERIALKEY) );

    // Format to target table fields
    const now = new Date();
    const aMappedEntries = aNewEntries.reduce((acc, item) => {
            
        const oLastEntry = mLastEntries.get( item.FGMATERIALKEY );
        const oIdh = mIdhData.get( item.FGMATERIALKEY );

        const bHasValidIdh = (oIdh && oIdh.SBU && oIdh.MATERIALTNUMBER) ? true : false;
        const bHasSustClass = item.PCFSUSTAINABILITYCLASSKEY ? true : false;

        if (!bHasValidIdh || !bHasSustClass) return acc;

        acc.push({
            ID: cds.utils.uuid(),
            createdAt: now,
            createdBy: GENERIC_USER,
            modifiedAt: now,
            modifiedBy: GENERIC_USER,
            sbu							 : oIdh.SBU,
            realSubstanceKey             : item.REALSUBSTANCEKEY,
            rcPreFlag                    : oIdh?.RCPREFLAG,
            sustClass                    : oIdh?.SUSTCLASS,
            contributor1                 : oIdh?.CONTRIBUTOR,
            category1                    : oIdh?.CATEGORY,
            contributor2                 : oIdh?.CONTRIBUTOR2,
            category2                    : oIdh?.CATEGORY2,
            contributor3                 : oIdh?.CONTRIBUTOR3,
            category3                    : oIdh?.CATEGORY3,
            material                     : oIdh?.MATERIALTNUMBER,
            oldRsnSbuCode                : oLastEntry?.RSNSBUCODE,
            oldProductLineL3             : oLastEntry?.NEWPRODUCTLINEL3,
            oldTechnologyL1              : oLastEntry?.NEWTECHNOLOGYL1,
            oldTechnologyL3              : oLastEntry?.NEWTECHNOLOGYL3,
            oldApplicationL1             : oLastEntry?.NEWAPPLICATIONL1,
            oldApplicationL2             : oLastEntry?.NEWAPPLICATIONL2,
            oldApplicationL3             : oLastEntry?.NEWAPPLICATIONL3,
            oldProductHierarchyL3        : oLastEntry?.NEWPCFPRODUCTHIERARCHYL3,
            oldPcfClusterAttributes      : oLastEntry?.NEWPCFCLUSTERATTRIBUTES,
            oldPcfClusterAttributesValues: oLastEntry?.NEWPCFCLUSTERATTRIBUTEVALUES,
            oldPcfClusterSize            : oLastEntry?.NEWPCFCLUSTERSIZE,
            oldPcfClusterBenchmark       : oLastEntry?.NEWPCFCLUSTERBENCHMARK,
            oldPcfExcl                   : oLastEntry?.NEWPCFEXCL,
            oldPcfDeltaRel               : oLastEntry?.NEWPCFEXCLDELTAREL,
            oldPcfSustClass              : oLastEntry?.PCFSUSTAINABILITYCLASSKEY,    
            newRsnSbuCode                : item.RSNSBUCODE,        
            newProductLineL3             : item.APRODUCTLINEL3,
            newTechnologyL1              : item.ATECHNOLOGYL1,
            newTechnologyL3              : item.ATECHNOLOGYL3,
            newApplicationL1             : item.APAPPLICATIONL1,
            newApplicationL2             : item.APAPPLICATIONL2,
            newApplicationL3             : item.APPAPPLICATIONL3,
            newProductHierarchyL3        : item.ACPRODUCTHIERARCHYL3,
            newPcfClusterAttributes      : item.PCFCLUSTERATTRIBUTES,
            newPcfClusterAttributesValues: item.PCFCLUSTERATTRIBUTEVALUES,
            newPcfClusterSize            : item.PCFCLUSTERSIZE,
            newPcfClusterBenchmark       : item.PCFCLUSTERBENCHMARK,
            newPcfExcl                   : item.PCFEXCL,
            newPcfDeltaRel               : item.PCFEXCLDELTAREL,
            productType                  : 'IDH',
            pcfHeartSustainabilityClass  : item.PCFSUSTAINABILITYCLASSKEY,
            pcfCategory                  : item.PCFSUSTAINABILITYCATEGORYCODE,
            pcfContributor               : item.PCFSUSTAINABILITYCONTRIBUTORCODE,
            status                       : PROCESSING_STATUS.PENDING,
            updateType                   : item.UPDATETYPE,
            heartRunId                   : item.RUNHID,
        });
        return acc;

    }, []);

    logger.info('Delta execution valid entries: ', aMappedEntries.length);

    // Insert into DB in batches
    await loadDataToDeltaTables( aMappedEntries);

};

/**
 * Gets the projects to process in query iteration
 * 
 * @returns {Promise<Object[]>} - List of project and product data to process in delta
 */
async function getDeltaMaterials() {

    const aLastExecution = await cds.db.run(
        SELECT
            .from(ENTITIES.DB.HEART_EXECUTION)
            .columns('max(heartRunId) as maxHeartRunId')
    );

    const bIsNotFirstRun = Array.isArray(aLastExecution) && aLastExecution.length > 0 && aLastExecution[0].MAXHEARTRUNID;
    const nMaxRunId = bIsNotFirstRun 
        ? aLastExecution[0].MAXHEARTRUNID
        : -1;

    const aWhere = bIsNotFirstRun 
        ? [{xpr:[{ref:['RUNHID']}, '>', {val: nMaxRunId}, 'and', {ref: ['UPDATETYPE']}, '!=', {val: 'No Change'}]}]
        : [];

    const aNewEntries = await cds.db.run(
        SELECT 
            .from(ENTITIES.DB.HEART_SNAPSHOT)
            .where(aWhere)
            .columns(
                'REALSUBSTANCEKEY',
                'FGMATERIALKEY',
                'RSNSBUCODE',
                'APRODUCTLINEL3',
                'ATECHNOLOGYL1',
                'ATECHNOLOGYL3',
                'APAPPLICATIONL1',
                'APAPPLICATIONL2',
                'APPAPPLICATIONL3',
                'PCFCLUSTERSIZE',
                'PCFCLUSTERBENCHMARK',
                'PCFEXCL',
                'PCFEXCLDELTAREL',
                'ACPRODUCTHIERARCHYL3',
                'PCFCLUSTERATTRIBUTES',
                'PCFCLUSTERATTRIBUTEVALUES',
                'PCFSUSTAINABILITYCLASSKEY',
                'PCFSUSTAINABILITYCATEGORYCODE',
                'PCFSUSTAINABILITYCONTRIBUTORCODE',
                'UPDATETYPE',
                'RUNHID',
            )
    );

    // At initial execution, all materials should be considered New
    if (!bIsNotFirstRun) {
        aNewEntries.forEach(material => material.UPDATETYPE = 'New');
    }

    return aNewEntries;           

};


/**
 * Loads the calculated data into database delta tables to be processed
 * by assessment creation job
 * 
 * @param {Object[]} projects - heart entries
 */
async function loadDataToDeltaTables( projects ) {
;
    const aProjectBatches = divideArrayInBatches( projects, DB_BATCH_SIZE );
    await cds.tx(async () => {

        const db = await cds.connect.to(SERVICES.DB);
        for (const batch of aProjectBatches) {
            const result = await db.run(
                INSERT
                    .into(ENTITIES.DB.HEART_EXECUTION)
                    .entries(batch)
            );
            logger.info('Delta insertion result ', result);
        }
        
    });

};

/**
 * Returns latest HEART execution data of a set of materials
 * @async 
 * @param {string[]} materials - List of materials to search by
 * @returns {Promise<Map()>} - Last HEART execution data
 */
async function getLastEntries( materials ) {

    const aBatches = divideArrayInBatches(materials, DB_BATCH_SIZE);

    const aResults = [];
    for (const batch of aBatches) {
        const aBatchResult = await SELECT
            .from(ENTITIES.DB.LATEST_HEART_EXECUTION)
            .where({material: batch})
            
        aResults.push(...aBatchResult);
    }

    // One-time Index Creation (O(n))
    const mIndexedData = new Map();
    for (const item of aResults) {
        mIndexedIdhs.set(item.MATERIAL, item);
    }
    return mIndexedData;

};

/**
 * Get IDH master data
 * @async
 * @param {string[]} materials - List of materials to filter by 
 * @returns {Promise<Map()>} material master data
 */
async function getIdhData( materials ) {

    const aBatches = divideArrayInBatches(materials, DB_BATCH_SIZE);

    const aResults = [];
    for (const batch of aBatches) {
        const aBatchResult = await SELECT
            .from(ENTITIES.DB.IDH)   
            .where({MATERIALTNUMBER: batch})
            
        aResults.push(...aBatchResult);
    }

    // One-time Index Creation (O(n))
    const mIndexedIdhs = new Map();
    for (const item of aResults) {
        mIndexedIdhs.set(item.MATERIALTNUMBER, item);
    }

    return mIndexedIdhs;        

};

module.exports = {
    heartAssessmentDelta,
}
