const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../../src/batching-utils');

/** Default batch size for DB */
const DB_BATCH_SIZE = 1000;

/** Number of entries to be processed by delta every time */
DELTA_SIZE = 5000;

/** Services available to use */
const SERVICES = {
    DB: 'db'
};

/** Entitites available to use */
const ENTITIES = {
    DB: {
        RCPC_SNAPSHOT: 'COM_SUSTAINABILITY_VT_V_POSITIVE_CONTRIBUTION_DATA',
        RCPC_EXECUTION: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONEXECUTION',
        LATEST_RCPC_EXECUTION: 'COM_SUSTAINABILITY_BACKGROUND_RCPCLATESTPRODUCTEXECUTION',
        RCPC_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONJOBEXECUTIONLOGS',
        IDH: 'COM_SUSTAINABILITY_IDHUPDATED',
    }
};

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    FINALISED: '03',
};

/** Available process types */
const PROCESS_TYPE = {
    RCPC_DELTA: 'RCPC_DELTA',
};

/** Limit of consecutive delta calls */
const MAX_DELTA_ITERATIONS_PER_EXECUTION = 100;

/** Generic background user */
const GENERIC_USER = 'RCPC_DELTA_JOB';

/** Generic logger to use */
const logger = cds.log('rcpc-delta');

/**
 * Handler for service action rcPositiveContributionAssessmentDelta 
 */
async function rcPositiveContributionAssessmentDelta ( req ) {

    logger.info('RCPC delta triggered');

    // Save execution log
    req.on('succeeded', async () => {
        const dNow = new Date();
        cds.spawn( async () => {
            const db = await cds.connect.to('db');
            const result = await db.run(
                INSERT
                    .into(ENTITIES.DB.RCPC_JOBS)
                    .entries([{
                        ID: cds.utils.uuid(),
                        createdAt: dNow,
                        createdBy: GENERIC_USER,
                        modifiedAt: dNow,
                        modifiedBy: GENERIC_USER,
                        type: PROCESS_TYPE.RCPC_DELTA, 
                        status: PROCESSING_STATUS.FINALISED 
                    }])
            )
            logger.info('Log insertion result ', result);
        });
    })

    // Fill delta table
    await executeDeltaIteration(0);

};

/**
 * Function to execute a single extraction for delta process
 * 
 * @param {number} executionNumber - Number of recursive executions
 */
async function executeDeltaIteration(executionNumber) {

    // Query all unreplicated to delta queries from datasphere
    const aNewEntries = await getDeltaMaterials();

    logger.info('Delta execution found entries: ', aNewEntries.length);

    if (!aNewEntries || aNewEntries.length === 0) return;

    // Format to target table fields
    const now = new Date();
    const aMappedEntries = aNewEntries.reduce((acc, item) => {
            
        acc.push({
            ID: cds.utils.uuid(),
            createdAt: now,
            createdBy: GENERIC_USER,
            modifiedAt: now,
            modifiedBy: GENERIC_USER,
            material: item.MATERIALKEY,
            sustClass: item.SUSTAINABILITYCLASSKEY,
            updateType: item.UPDATETYPE,
            runId: item.RUNID,
            status: PROCESSING_STATUS.PENDING
        });
        return acc;

    }, []);

    logger.info('Delta execution valid entries: ', aMappedEntries.length);

    // Insert into DB in batches
    await loadDataToDeltaTables( aMappedEntries);

};

/**
 * Gets the projects to process in query iteration
 * 
 * @returns {Promise<Object[]>} - List of project and product data to process in delta
 */
async function getDeltaMaterials() {

    const aLastExecution = await cds.db.run(
        SELECT
            .from(ENTITIES.DB.RCPC_EXECUTION)
            .columns('max(runId) as maxRunId')
    );

    const bIsNotFirstRun = Array.isArray(aLastExecution) && aLastExecution.length > 0 && aLastExecution[0].MAXRUNID;
    const nMaxRunId = bIsNotFirstRun 
        ? aLastExecution[0].MAXRUNID
        : -1;

    const aWhere = bIsNotFirstRun 
        ? [{
            xpr: [
                {ref:['RUNID']}, '>', {val: nMaxRunId}, 
                'and', 
                {ref: ['UPDATETYPE']}, '!=', {val: 'No Change'},
                'and', 
                {ref: ['UPDATETYPE']}, '!=', {val: 'Deleted'}
            ]
        }]
        : [{
            xpr: [
                {ref: ['UPDATETYPE']}, '!=', {val: 'No Change'},
                'and', 
                {ref: ['UPDATETYPE']}, '!=', {val: 'Deleted'}
            ]
        }];

    const aNewEntries = await cds.db.run(
        SELECT 
            .from(ENTITIES.DB.RCPC_SNAPSHOT)
            .where(aWhere)
    );

    // // At initial execution, all materials should be considered New
    // if (!bIsNotFirstRun) {
    //     aNewEntries.forEach(material => material.UPDATETYPE = 'New');
    // }

    // Get entries set as deleted that were not yet processed
    const aDeletedEntries = await cds.db.run(
        `
        SELECT DS.*
        FROM COM_SUSTAINABILITY_VT_V_POSITIVE_CONTRIBUTION_DATA AS DS
        LEFT JOIN COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONEXECUTION AS RCPC
        ON DS.materialkey = RCPC.material
        AND DS.runid = RCPC.runid
        AND DS.sustainabilityclasskey = RCPC.sustclass
        WHERE DS.updatetype = 'Deleted' 
        AND RCPC.updatetype IS null;
        `
    );

    const oNewEntries = aNewEntries.reduce((acc, curr) => {  
        if (!acc[curr.MATERIALKEY]) {
            acc[curr.MATERIALKEY] = [];
        }

        acc[curr.MATERIALKEY].push(curr);
        return acc;
    }, {});

    for (const entry of aDeletedEntries){ 
        
        // For every material deleted, it is checked if there is a detected deletion 
        // and new or change one is overwritten in that case
        const oNewMaterialEntry = oNewEntries[entry.MATERIALKEY];
        if (oNewMaterialEntry) {

            const oExistingEntry = oNewMaterialEntry.find(item => {
                item.MATERIALKEY === entry.MATERIALKEY &&
                item.RUNID === entry.RUNID
            });

            if (oExistingEntry) {
                oExistingEntry.UPDATETYPE = entry.UPDATETYPE;
                oExistingEntry.SUSTAINABILITYCLASSKEY = entry.SUSTAINABILITYCLASSKEY;
            }

        } else {
            aNewEntries.push(entry);
        }
        
    }

    return aNewEntries;           

};


/**
 * Loads the calculated data into database delta tables to be processed
 * by assessment creation job
 * 
 * @param {Object[]} projects - RCPC entries
 */
async function loadDataToDeltaTables( projects ) {
;
    const aProjectBatches = divideArrayInBatches( projects, DB_BATCH_SIZE );
    await cds.tx(async () => {

        const db = await cds.connect.to(SERVICES.DB);
        for (const batch of aProjectBatches) {
            const result = await db.run(
                INSERT
                    .into(ENTITIES.DB.RCPC_EXECUTION)
                    .entries(batch)
            );
            logger.info('Delta insertion result ', result);
        }
        
    });

};

module.exports = {
    rcPositiveContributionAssessmentDelta,
}
