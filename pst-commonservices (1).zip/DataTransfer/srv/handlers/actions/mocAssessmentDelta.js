const cds = require('@sap/cds');

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    FINALISED: '03',
};

/** Services available to use */
const SERVICES = {
    DB: 'db'
};

/** Entitites available to use */
const ENTITIES = {
    DB: {
        ADP_ASSESSMENT_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_ADPJOBEXECUTIONLOGS',
    }
};

/** Generic background user */
const GENERIC_USER = 'MOC_DELTA_JOB';

/** Available process types */
const PROCESS_TYPE = {
    MOC_DELTA: 'MOC_DELTA',
};


/**
 * Handler for service action mocAssessmentDelta
 * 
 * @param {*} req 
 */
async function mocAssessmentDelta(req) {

    const logger = cds.log('delta');
    const db = await cds.connect.to(SERVICES.DB);
    const now = new Date();

    

    logger.info('MOC delta data save start');

    await cds.db.run(`INSERT INTO COM_SUSTAINABILITY_BACKGROUND_MOCPROCESSEDPROJECTS (
                        ID, PROJECTID, SBU, PRODUCT, PRODUCTTYPE, ASSESSMENTEXPLANATION, RCPREFLAG, SUSTCLASS, CATEGORY1, CONTRIBUTOR1, ASSESSOR,
                        SUSTAINABILITY, PROJECTMANAGER, FINALDATE, STATUS, CREATEDAT, CREATEDBY, MODIFIEDAT, MODIFIEDBY) 
                    SELECT NEWUID() as ID, PROJECTID, SBU, PRODUCT, PRODUCTTYPE, ASSESSMENTEXPLANATION, RCPREFLAG, SUSTCLASS, CATEGORY1,
                        CONTRIBUTOR1, ASSESSOR, SUSTAINABILITY, PROJECTMANAGER, FINALDATE, 
                        STATUS,
                        CURRENT_TIMESTAMP     as CREATEDAT,
                        '${GENERIC_USER}'       as CREATEDBY,
                        CURRENT_TIMESTAMP     as MODIFIEDAT,
                        '${GENERIC_USER}'       as MODIFIEDBY
                     FROM COM_SUSTAINABILITY_BACKGROUND_MOCDELTAREAD`);


    const result = await db.run(
        INSERT
            .into(ENTITIES.DB.ADP_ASSESSMENT_JOBS)
            .entries([{
                ID: cds.utils.uuid(),
                type: PROCESS_TYPE.MOC_DELTA,
                status: PROCESSING_STATUS.FINALISED,
                createdAt: now,
                createdBy: GENERIC_USER,
                modifiedAt: now,
                modifiedBy: GENERIC_USER,
            }])
    )
};

module.exports = {
    mocAssessmentDelta,
}
