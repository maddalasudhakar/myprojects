const cds = require("@sap/cds");
const {
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    sendDataToCPI,
    getProofDocuments,
    updateMassAssessmentItemsProcessingStatus,
    updateSingleAssessmentItemsProcessingStatus,
    chunkArray
} = require("../../src/assessment-utils");

const {
    ASSESSMENT_STATUS,
    PROCESSING_STATUS,
    TYPE_IB,
    TYPE_IDH,
    CHUNK_NUMBER
} = require('../../src/constants');

/**
 * Function to implement CPI retrial action handler
 * 
 * @param {*} req 
 */
async function processCPIRetrial(req) {
    try {
        const aStatus = [ASSESSMENT_STATUS.APPROVED],
            sProcessingStatus = PROCESSING_STATUS.PENDING_CPI_RETRY,
            sSendedStatus = PROCESSING_STATUS.SENDED_CPI;

        const aMassAssessmentItemsDB = [
            ...await getMassAssessmentItemsDB(aStatus, sProcessingStatus, TYPE_IB),
            ...await getMassAssessmentItemsDB(aStatus, sProcessingStatus, TYPE_IDH),
        ];
        const aSingleAssessmentsDB = [
            ...await getSingleAssessmentDB(aStatus, sProcessingStatus, TYPE_IB),
            ...await getSingleAssessmentDB(aStatus, sProcessingStatus, TYPE_IDH),
        ]

        const aMassItemsWithTag = aMassAssessmentItemsDB.map(item => ({ ...item, _source: 'MASS' }));
        const aSingleItemsWithTag = aSingleAssessmentsDB.map(item => ({ ...item, _source: 'SINGLE' }));

        const allAssessments = [...aMassItemsWithTag, ...aSingleItemsWithTag];

        const aApprovedIB = allAssessments.filter(item => item.STATUS === ASSESSMENT_STATUS.APPROVED && item.PRODUCTTYPE === TYPE_IB);
        const aApprovedIdh = allAssessments.filter(item => item.STATUS === ASSESSMENT_STATUS.APPROVED && item.PRODUCTTYPE === TYPE_IDH);

        const aIbChunks = chunkArray(aApprovedIB, CHUNK_NUMBER);
        const aIdhChunks = chunkArray(aApprovedIdh, CHUNK_NUMBER);

        for (const chunk of aIbChunks) {
            try {
                await cds.tx(async (tx) => {

                    const oMassItems = chunk.filter(item => item._source === 'MASS');
                    const oSingleItems = chunk.filter(item => item._source === 'SINGLE');

                    await updateMassAssessmentItemsProcessingStatus(oMassItems, sSendedStatus);
                    await updateSingleAssessmentItemsProcessingStatus(oSingleItems, sSendedStatus);

                    const oProofDocuments = await getProofDocuments(chunk);
                    await sendDataToCPI([], chunk, [], oProofDocuments);

                });
            } catch (error) {
                console.error("Error sending data to CPI:", error.message);
            }
        }

        for (const chunk of aIdhChunks) {
            try {
                await cds.tx(async (tx) => {

                    const oMassItems = chunk.filter(item => item._source === 'MASS');
                    const oSingleItems = chunk.filter(item => item._source === 'SINGLE');

                    await updateMassAssessmentItemsProcessingStatus(oMassItems, sSendedStatus);
                    await updateSingleAssessmentItemsProcessingStatus(oSingleItems, sSendedStatus);

                    const oProofDocuments = await getProofDocuments(chunk);
                    await sendDataToCPI(chunk, [], oProofDocuments, []);

                });
            } catch (error) {
                console.error("Error sending data to CPI:", error.message);
            }
        }        

    } catch (error) {
        console.error("Error in processApprovedIbProducts:", error.message);
        throw error;
    }
};

module.exports = {
    processCPIRetrial,
}