
const cds = require('@sap/cds');

/** Used entities */
const ENTITIES = {
    DB: {
        HEART_EXECUTION_LOGS: 'COM_SUSTAINABILITY_BACKGROUND_HEARTJOBEXECUTIONLOGS',
        JOB_LOGS_TABLE: 'COM_SUSTAINABILITY_BACKGROUND_JOBORCHESTRATORLOGS',
    }
};

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
}

/** Handlers for each kind of service */
const PROCESS_TO_HANDLER = {
    HEART: 'heartAssessmentTrigger',
    HEART_DELTA: 'heartAssessmentDelta',
};

/** Types of processess used */
const PROCESS_TYPE = {
    HEART_DELTA: 'HEART_DELTA',
    HEART: 'HEART',
}

/** Used services */
const SERVICES = {
    DB: 'db',
    DATA_TRANSFER: 'DataTransferService'
};

/** Total number of triggerable jobs, 2 deltas and 4 assessment with retry */
const TOTAL_JOBS = 6;

const logger = cds.log('heart-job-trigger');

/**
 * Handler for action in charge of managing ADP Job triggering
 * 
 * @param {cds.Request} req - Request object 
 */
async function heartAssessmentJobTrigger( req ) {

    logger.info('Job trigger started');

    const orchecstratorLog = {
        ID: cds.utils.uuid(),
        createdAt: new Date(),
        createdBy: 'JOB_ORCHESTRATOR',
        modifiedAt: new Date(),
        modifiedBy: 'JOB_ORCHESTRATOR',
        type: 'HEART',
        status: '01',
    };
    await cds.tx(
        INSERT.into( ENTITIES.DB.JOB_LOGS_TABLE )
            .entries([ orchecstratorLog ])
    );
    
    req.on('done', async () => {
        logger.info('Job trigger finished');
        await cds.tx(
            UPDATE( ENTITIES.DB.JOB_LOGS_TABLE )
                .set({ status: '03' })
                .where({ ID: orchecstratorLog.ID })
        );
    });

    // Get last time each kind of jib was executed
    const lastJobs = await cds.db.run(
        SELECT
            .from(ENTITIES.DB.HEART_EXECUTION_LOGS)
            .columns('type', 'status', 'MAX(createdAt)')
            .groupBy('type', 'status')
    );

    const jobParams = getJobConfiguration();
    
    // Check if first time already happened and if not trigger it
    try {
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.HEART_DELTA );
    } catch (error) {
        console.error(error);
    }
    
    try {
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.HEART, PROCESSING_STATUS.RETRIAL );
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.HEART, PROCESSING_STATUS.PENDING );
    } catch (error) {
        console.error(error);
    }

    return 'Job finished';

};

/**
 * Method to trigger jobs
 * 
 * @param {*} lastJobs 
 * @param {*} jobParams 
 * @param {*} processType 
 * @param {*} status 
 */
async function triggerJob ( lastJobs, jobParams, processType, status ) {

    // jobParams.subJobs.filter(item => item.processType === 'PDP').forEach(item => {item.active = true})
    const MINUTE_TO_MS_RATE = 1000 * 60;
    const DataTransferService = await cds.connect.to(SERVICES.DATA_TRANSFER);
    const now = new Date();
    if (status) {

        const hasLastJob = lastJobs.some(item => {
            return item.STATUS === status && item.TYPE === processType;
        })
        const jobParam = jobParams.subJobs.find( item => {
            return item.status === status && item.processType === processType
        });        
        
        // If already triggeredd once, check time. If not, trigger it
        if (hasLastJob && jobParam) {

            const job = lastJobs.find(item => {
                return item.STATUS === status && item.TYPE === processType;
            });

            const isInScheduledTime = isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);
            if (jobParam.active && isInScheduledTime) {
                await DataTransferService.send( PROCESS_TO_HANDLER[processType], { status } );
            }

        } else if ( jobParam?.active ) {
        
            await DataTransferService.send( PROCESS_TO_HANDLER[processType], { status } );
        
        }

    } else {

        const hasLastJob = lastJobs.some(item => item.TYPE === processType);
        const jobParam = jobParams.subJobs?.find( item => item.processType === processType);        
        // If already triggeredd once, check time. If not, trigger it
        if (hasLastJob && jobParam) {

            const job = lastJobs.find( item => item.TYPE === processType );

            const isInScheduledTime = isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);
            if (jobParam.active && isInScheduledTime) {
                await DataTransferService.send( PROCESS_TO_HANDLER[processType]);
            }

        } else if ( jobParam?.active ) {
        
            await DataTransferService.send( PROCESS_TO_HANDLER[processType] );
        
        }

    }

};

/**
 * Retrieves job configuration
 * 
 * @returns  {Object} Retrieves job configuration
 */
function getJobConfiguration( ) {

    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"]; 
    const jobParams = userProvided?.find(item => item.name === 'DataTransfer-job-params')?.credentials 
        || userProvided?.find(item => item.name === 'custom-service:DataTransfer-job-params')?.credentials
        || cds.env?.JOB_PARAMS;
    return jobParams.heartAssessmentTrigger;

};

/**
 * Checks if a date is prior to a certain interval from provided one
 * 
 * @param {Date} dateToCheck - Date to compare
 * @param {Date} referenceDate - Reference date
 * @param {number} intervalMs - Miliseconds of interval 
 * @returns 
 */
function isDateLessThanInterval(dateToCheck, referenceDate, intervalMs) {

    // Convert to timestamps for comparison
    const checkTime = new Date(dateToCheck).getTime();
    const referenceTime = new Date(referenceDate).getTime();
    
    // Calculate the threshold (reference date minus interval)
    const thresholdTime = referenceTime - intervalMs;
    
    // Return true if dateToCheck is earlier than the threshold
    return checkTime < thresholdTime;

};

module.exports = {
    heartAssessmentJobTrigger,
};