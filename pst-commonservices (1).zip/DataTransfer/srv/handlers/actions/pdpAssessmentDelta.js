const cds = require('@sap/cds');

/** Entitites available to use */
const ENTITIES = {
    DB: {
        ADP_ASSESSMENT_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_ADPJOBEXECUTIONLOGS',
    }
};

/** Services available to use */
const SERVICES = {
    DB: 'db'
};

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    FINALISED: '03',
};

/** Available process types */
const PROCESS_TYPE = {
    PDP_DELTA: 'PDP_DELTA',
};


/** Generic background user */
const GENERIC_USER = 'PDP_DELTA_JOB';

/**
 * Handler for service action pdpAssessmentDelta
 * @param {*} req 
 */
async function pdpAssessmentDelta(req) {

    const logger = cds.log('delta');
    const db = await cds.connect.to(SERVICES.DB);
    const now = new Date();


    logger.info('PDP delta data save start');

    await cds.db.run(`INSERT INTO COM_SUSTAINABILITY_BACKGROUND_PDPPROCESSEDPROJECTS (
                        ID, PROJECTID, SBU, PRODUCT, PRODUCTTYPE, ASSESSMENTEXPLANATION, RCPREFLAG, SUSTCLASS, CATEGORY1, CONTRIBUTOR1, ASSESSOR, SUBMITTER,
                        SUSTAINABILITY, PROJECTMANAGER, FINALDATE, STATUS, CREATEDAT, CREATEDBY, MODIFIEDAT, MODIFIEDBY) 
                    SELECT NEWUID() as ID, PROJECTID, SBU, PRODUCT, PRODUCTTYPE, ASSESSMENTEXPLANATION, RCPREFLAG, SUSTCLASS, CATEGORY1,
                        CONTRIBUTOR1, ASSESSOR, SUBMITTER, SUSTAINABILITY, PROJECTMANAGER, FINALDATE, 
                        STATUS,
                        CURRENT_TIMESTAMP     as CREATEDAT,
                        '${GENERIC_USER}'       as CREATEDBY,
                        CURRENT_TIMESTAMP     as MODIFIEDAT,
                        '${GENERIC_USER}'       as MODIFIEDBY
                     FROM COM_SUSTAINABILITY_BACKGROUND_PDPDELTAREAD`);

    const result = await db.run(
        INSERT
            .into(ENTITIES.DB.ADP_ASSESSMENT_JOBS)
            .entries([{
                ID: cds.utils.uuid(),
                type: PROCESS_TYPE.PDP_DELTA,
                status: PROCESSING_STATUS.FINALISED,
                createdAt: now,
                createdBy: GENERIC_USER,
                modifiedAt: now,
                modifiedBy: GENERIC_USER,
            }])
    )
    logger.info('Log insertion result ', result);
};

module.exports = {
    pdpAssessmentDelta,
}
