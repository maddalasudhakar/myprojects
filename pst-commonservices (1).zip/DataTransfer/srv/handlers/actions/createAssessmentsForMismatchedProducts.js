const cds = require("@sap/cds");
const { ENTITIES, MISMATCH_STATUS, PATH, PROCESS_TYPE, } = require('../../src/constants.js');
const { chunkArray, } = require('../../src/assessment-utils.js');

const PRODUCTS_BY_ASSESSMENT = 2000;

const logger = cds.log('rc-mismatch-trigger');

/**
 * Creates assessments for all  pending products in the mismatch log grouped by SBU. 
 * @async
 * @returns 
 */
async function createAssessmentsForMismatchedProducts() {

    logger.log("Create  Assessments for Misstatched Products Trigger");
    const db = await cds.connect.to("db");
    const pst = await cds.connect.to('SustainabilityService');

    // Retrieve all pending products from the mismatch log 
    const aLogProducts = await db.run(
        SELECT.from(ENTITIES.DB.RC_PREFLAG_MISMATCHED_LOG)
            .columns(['product', 'sbu'])
            .where({ status: MISMATCH_STATUS.PENDING })
    );

    // Exit early if no pending records exist
    if (!aLogProducts || aLogProducts.length === 0) {
        return;
    }

    // Group products by their corresponding SBU
    const productsBySBU = aLogProducts.reduce((acc, { SBU, PRODUCT }) => {
        if (!acc[SBU]) acc[SBU] = [];
        acc[SBU].push({ product: PRODUCT });
        return acc;
    }, {});

    const wait = (seconds) => new Promise(res => setTimeout(res, seconds * 1000));

    // Iterate over each SBU group and trigger assessment creation
    for (const [sbu, products] of Object.entries(productsBySBU)) {

        if (!sbu) {
            continue;
        }

        const productIds = products.map(p => p.product);
        const batches = chunkArray(productIds, PRODUCTS_BY_ASSESSMENT);

        for (const batch of batches) {
            logger.info('Create assessment for sbu', {sbu});

            await wait(10);
            await pst.send({
                method: "POST",
                path: PATH.SUSTCLASS_MISMATCH_ASSESSMENT_CREATION,
                data: { sbu, products: batch }
            });
        }

    }

    // Get privileged user and current timestamp to get managed fields
    const user = new cds.User.Privileged().id;
    const now = new Date().toISOString();
    await db.run(
        INSERT.into(ENTITIES.DB.MISMATCHED_ASSESSMENT_EXECUTION_LOGS).entries([
            {
                id: cds.utils.uuid(),
                createdAt: now,
                createdBy: user,
                modifiedAt: now,
                modifiedBy: user,
                type: PROCESS_TYPE.MISMATCHED_PRODUCT_ASSESSMENT_CREATION,
                status: MISMATCH_STATUS.FINALISED,
            },
        ])
    );

}

module.exports = {
    createAssessmentsForMismatchedProducts,
};