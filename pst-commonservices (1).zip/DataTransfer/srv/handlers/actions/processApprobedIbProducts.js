const cds = require("@sap/cds");
const {
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    sendDataToCPI,
    getProofDocuments,
    updateMassAssessmentItemsProcessingStatus,
    updateSingleAssessmentItemsProcessingStatus,
    chunkArray
} = require("../../src/assessment-utils");

const {
    ASSESSMENT_STATUS,
    PROCESSING_STATUS,
    TYPE_IB,
    CHUNK_NUMBER
} = require('../../src/constants');

async function processApprobedIbProducts(req) {
    try {
        const aStatus = [ASSESSMENT_STATUS.APPROVED],
            sProcessingStatus = PROCESSING_STATUS.PENDING,
            sSendedStatus = PROCESSING_STATUS.SENDED_CPI;

        const aMassAssessmentItemsDB = await getMassAssessmentItemsDB(aStatus, sProcessingStatus, TYPE_IB);
        const aSingleAssessmentsDB = await getSingleAssessmentDB(aStatus, sProcessingStatus, TYPE_IB);

        const aMassItemsWithTag = aMassAssessmentItemsDB.map(item => ({ ...item, _source: 'MASS' }));
        const aSingleItemsWithTag = aSingleAssessmentsDB.map(item => ({ ...item, _source: 'SINGLE' }));

        const allAssessments = [...aMassItemsWithTag, ...aSingleItemsWithTag];

        const aApprovedIB = allAssessments.filter(item => item.STATUS === ASSESSMENT_STATUS.APPROVED && item.PRODUCTTYPE === TYPE_IB);

        const aChunks = chunkArray(aApprovedIB, CHUNK_NUMBER);

        for (const chunk of aChunks) {
            try {
                await cds.tx(async (tx) => {

                    const oMassItems = chunk.filter(item => item._source === 'MASS');
                    const oSingleItems = chunk.filter(item => item._source === 'SINGLE');

                    await updateMassAssessmentItemsProcessingStatus(oMassItems, sSendedStatus);
                    await updateSingleAssessmentItemsProcessingStatus(oSingleItems, sSendedStatus);

                    const oProofDocuments = await getProofDocuments(chunk);
                    await sendDataToCPI([], chunk, [], oProofDocuments);

                });
            } catch (error) {
                console.error("Error sending data to CPI:", error.message);
            }
        }

    } catch (error) {
        console.error("Error in processApprovedIbProducts:", error.message);
        throw error;
    }
}

module.exports = {
    processApprobedIbProducts,
}  