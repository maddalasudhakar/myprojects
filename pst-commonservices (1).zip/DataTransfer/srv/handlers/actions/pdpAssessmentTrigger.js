const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../../src/batching-utils');

/** Entities to use */
const ENTITIES = {
    DB: {
        PDP_GROUPINGS_TO_PROCESS: 'COM_SUSTAINABILITY_BACKGROUND_PDPPROJECTGROUPINGSTOPROCESS',
        PDP_PROCESSED_PROJECTS: 'COM_SUSTAINABILITY_BACKGROUND_PDPPROCESSEDPROJECTS',
        PDP_PRODUCTS_READY_TO_PROCESS: 'COM_SUSTAINABILITY_BACKGROUND_PDPPRODUCTSREADYTOPROCESS',
        ADP_ASSESSMENT_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_ADPJOBEXECUTIONLOGS',
        NOT_LINKED_ADP_PROJECTS: 'COM_SUSTAINABILITY_BACKGROUND_NOTLINKEDADPPROJECTSLOG',
    }
};

/** Default batch size for groupings */
const DEFAULT_GROUPING_BATCH = 50;

/** Services to connect */
const SERVICES = {
    DB: 'db',
    SUSTAINABILITY: 'SustainabilityService',
    NOTIFICATION: 'pst-custom-notification',

};

/** URLs to use when calling services */
const URL = {
    PDP_ASSESSMENT_CREATION: '/odata/v4/sustainability-background/pdpAssessmentCreation',
    ADP_ASSESSMENT_NOT_LINKED: '/odata/v4/assessment-notification/adpProjectNotLinked',
};


/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    FINALISED: '03',
};

/** Available process types */
const PROCESS_TYPE = {
    PDP: 'PDP',
};

/** HTTP methods */
const HTTP_METHODS = {
    GET: 'GET',
    POST: 'POST',
}

/** Process user ID */
const GENERIC_USER = 'PDP_TRIGGER_JOB';

/** Generic logger for process */
const logger = cds.log('pdp-assessment-trigger');

/**
 * Implementation for pdpAssessmentTrigger action import trigger 
 * @param {cds.Request} req - Incoming request made 
 */
async function pdpAssessmentTrigger(req) {

    const { status } = req.data;

    logger.info('Start PDP asssessment trigger...');

    // Groupings are retrieved, each grouping corresponds to an assessment to create
    const db = await cds.connect.to('db');

    const aGroupingsToProcess = await db.run(
        SELECT
            .from(ENTITIES.DB.PDP_GROUPINGS_TO_PROCESS)
            .where({ status: status })
            .orderBy({ createdAt: 'asc' })
    );

    logger.info('Number of assessments to create: ', aGroupingsToProcess.length);

    const aBatches = divideArrayInBatches(aGroupingsToProcess, DEFAULT_GROUPING_BATCH);
    for (const batch of aBatches) {

        const aProjects = batch.map(item => item.PROJECTID);
        const aSbus = batch.map(item => item.SBU);

        // Query products ready to assess from FIFO logic
        const aProductsReady = await db.run(
            SELECT
                .from(ENTITIES.DB.PDP_PRODUCTS_READY_TO_PROCESS)
                .where({
                    projectId: aProjects,
                    sbu: aSbus,
                    status: status,
                })
                .orderBy({ CREATEDAT: 'asc' })
        );

        // Save not linked projects
        const dNow = new Date();
        const aNotLinkedProjects = aProductsReady
            .filter(item => !item.PRODUCT)
            .reduce((acc, curr) => {
                if (!acc.some(item => item.PROJECTID === curr.PROJECTID)) {
                    acc.push({
                        CREATEDAT: dNow,
                        CREATEDBY: GENERIC_USER,
                        MODIFIEDAT: dNow,
                        MODIFIEDBY: GENERIC_USER,
                        PROJECTID: curr.PROJECTID,
                        TYPE: PROCESS_TYPE.PDP,
                    })
                }
                return acc;
            }, []);

        if (aNotLinkedProjects.length > 0){
            logger.info('Projects with ADP not linked: ', aNotLinkedProjects.length);
            try {
                const oResult = await cds.db.run(
                    UPSERT(aNotLinkedProjects).into(ENTITIES.DB.NOT_LINKED_ADP_PROJECTS)
                );   
            } catch(error) {
                logger.info( `${error}` );
            }

            const aProjectIds = aNotLinkedProjects.map(item => item.PROJECTID);
            await cds.db.run(
                UPDATE(ENTITIES.DB.PDP_PROCESSED_PROJECTS)
                    .set({status: PROCESSING_STATUS.FINALISED})
                    .where({PROJECTID: aProjectIds, product: ''})
            )
        }

        // For each grouping, their available products are obtained and used to
        // trigger process
        for (grouping of batch) {
            const aProductsForGrouping = aProductsReady
                .filter(item => {
                    const bIsFromGroup = (
                        item.PROJECTID === grouping.PROJECTID &&
                        item.SBU === grouping.SBU &&
                        item.PRODUCTTYPE === grouping.PRODUCTTYPE &&
                        item.STATUS === grouping.STATUS
                    );

                    return bIsFromGroup;
                })
                .map(item => item.PRODUCT);

            // If not linked products present, send notifications
            const aProductsNotLinked = aProductsForGrouping.filter(item => !item);

            //Only send notifications if there are data and is first run
            if (aProductsNotLinked && aProductsNotLinked.length > 0 && status === PROCESSING_STATUS.PENDING) {

                const oProduct = aProductsReady.find(item => {
                    return item.PROJECTID === grouping.PROJECTID &&
                        item.SBU === grouping.SBU &&
                        item.PRODUCTTYPE === grouping.PRODUCTTYPE &&
                        item.STATUS === grouping.STATUS &&
                        item.SUBMITTER &&
                        item.ASSESSOR &&
                        !item.PRODUCT;
                });

                const NotificationService = await cds.connect.to(SERVICES.NOTIFICATION);
                const result = await NotificationService.send({
                    method: HTTP_METHODS.POST,
                    path: URL.ADP_ASSESSMENT_NOT_LINKED,
                    data: {
                        adpProject: grouping.PROJECTID,
                        sbu: grouping.SBU,
                        processType: PROCESS_TYPE.PDP,
                    },
                })

            }

            const aProductsLinked = aProductsForGrouping.filter(item => item);
            if (aProductsLinked && aProductsLinked.length > 0) {
                logger.info('Creation of assessment for grouping:', grouping);

                const wait = (seconds) => new Promise(res => setTimeout(res, seconds * 1000));
                await wait(1);

                // Creation is triggered for linked products
                const SustainabilityService = await cds.connect.to(SERVICES.SUSTAINABILITY);
                const oResult = await SustainabilityService.send({
                    method: HTTP_METHODS.POST,
                    path: URL.PDP_ASSESSMENT_CREATION,
                    data: {
                        sbu: grouping.SBU,
                        productType: grouping.PRODUCTTYPE,
                        projectId: grouping.PROJECTID,
                        products: aProductsLinked,
                        status: grouping.STATUS
                    }
                });
            }
        }
    }

    req.on('done', async tx => {
        cds.spawn(async () => {
            const now = new Date();
            await db.run(
                INSERT
                    .into(ENTITIES.DB.ADP_ASSESSMENT_JOBS)
                    .entries([{
                        ID: cds.utils.uuid(),
                        type: PROCESS_TYPE.PDP,
                        status: status,
                        createdAt: now,
                        createdBy: GENERIC_USER,
                        modifiedAt: now,
                        modifiedBy: GENERIC_USER,
                    }])
            );
            logger.info('Assessment creation process finished');
        });
    });

};

module.exports = {
    pdpAssessmentTrigger,
}
