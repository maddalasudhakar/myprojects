const cds = require('@sap/cds');

const SECONDS_TO_MS_RATE = 1000;
const MINUTE_TO_MS_RATE = 60 * SECONDS_TO_MS_RATE;
const DATA_TRANSFER_SERVICE = 'DataTransferService';
const logger = cds.log('job-orchestrator');
const GROUP_HANDLERS = {
    ADP: 'adpAssessmentJobTrigger',
    RCPC: 'rcPositiveContributionAssessmentJobTrigger',
    HEART: 'heartAssessmentJobTrigger',
    RCM: 'mismatchedAssessmentJobTrigger',
};


/**
 * Orchestrator tick. Walks groups in order, gated by whether the previous
 * group is settled. "Settled" now means: every active subjob in the group
 * has its latest log row in a terminal state, and the most recent terminal
 * row is older than the cool-down.
 */
async function jobOrchestrator(req) {

    logger.info('Start job orchestrator');

    const config     = getOrchestratorConfig();
    const coolDownMs = (config.coolDownMinutes ?? 1) * MINUTE_TO_MS_RATE;

    for (const group of config.groups) {

        if (!group.active) continue;

        try {
            await cds.tx(async() => {
                const DataTransferService = await cds.connect.to(DATA_TRANSFER_SERVICE);

                const handler = GROUP_HANDLERS[group.process];
                if (!handler) {
                    logger.error(`No handler for processType: ${group.process}`);
                    return;
                }

                logger.info('Trigger job', handler);
                await DataTransferService.send(handler); 

                const wait = (ms) => new Promise(res => setTimeout(res, ms));
                await wait( coolDownMs );
            });

        } catch (error) {
            logger.error(`Error running group ${group.id}:`, error);
        }

    }

    logger.info('Orchestrator finished');

    return 'Orchestrator tick finished';
}


function getOrchestratorConfig() {
    const vcap = process.env.VCAP_SERVICES ? JSON.parse(process.env.VCAP_SERVICES) : {};
    const userProvided = vcap['user-provided'] ?? [];
    const jobParams =
        userProvided.find(i => i.name === 'DataTransfer-job-params')?.credentials ||
        userProvided.find(i => i.name === 'custom-service:DataTransfer-job-params')?.credentials ||
        cds.env?.JOB_PARAMS;

    if (!jobParams?.jobOrchestrator) {
        throw new Error('Orchestrator configuration not found in DataTransfer-job-params');
    }
    return jobParams.jobOrchestrator;
}


module.exports = { jobOrchestrator };