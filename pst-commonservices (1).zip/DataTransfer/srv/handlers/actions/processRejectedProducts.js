const cds = require("@sap/cds");
const {
    getMassAssessmentItemsDB,
    getSingleAssessmentDB,
    updateMassAssessmentItemsProcessingStatus,
    updateSingleAssessmentItemsProcessingStatus,
    sendDataToFeedback,
    chunkArray,
} = require("../../src/assessment-utils");

const {
    ASSESSMENT_STATUS,
    PROCESSING_STATUS,
    TYPE_IB,
    TYPE_IDH,
    CHUNK_NUMBER,
    CHUNK_SIZE_CAP,
} = require('../../src/constants');

async function processRejectedProducts(req) {
    try {
        const aStatus = [ASSESSMENT_STATUS.REJECTED],
            sProcessingStatus = PROCESSING_STATUS.PENDING,
            sSendedStatus = PROCESSING_STATUS.SENDED_CPI,
            aProductTypes = [TYPE_IB, TYPE_IDH];

        const aMassAssessmentItemsDB = await getMassAssessmentItemsDB(aStatus, sProcessingStatus, aProductTypes);
        const aSingleAssessmentsDB = await getSingleAssessmentDB(aStatus, sProcessingStatus, aProductTypes);

        const aMassItemsWithTag = aMassAssessmentItemsDB.map(item => ({ ...item, _source: 'MASS' }));
        const aSingleItemsWithTag = aSingleAssessmentsDB.map(item => ({ ...item, _source: 'SINGLE' }));

        const allAssessments = [...aMassItemsWithTag, ...aSingleItemsWithTag];

        const aRejected = allAssessments.filter(item => item.STATUS === ASSESSMENT_STATUS.REJECTED);

        const aChunks = chunkArray(aRejected, CHUNK_SIZE_CAP);
        for (const chunk of aChunks) {
            try {
                await cds.tx(async (tx) => {

                    const oMassItems = chunk.filter(item => item._source === 'MASS');
                    const oSingleItems = chunk.filter(item => item._source === 'SINGLE');

                    // await updateMassAssessmentItemsProcessingStatus(oMassItems, sSendedStatus);
                    // await updateSingleAssessmentItemsProcessingStatus(oSingleItems, sSendedStatus);

                    await sendDataToFeedback(chunk);

                });
            } catch (error) {
                if (typeof error.message === 'object') console.error("Error sending rejected products:", JSON.stringify(error.message));
                else console.error("Error sending rejected products:", error.message);
            }
        }


    } catch (oError) {
        console.error("Error in processRejectedProducts:", oError.message);
        console.error(oError);
        throw oError;
    }

}

module.exports = {
    processRejectedProducts,
}  