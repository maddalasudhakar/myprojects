const cds = require('@sap/cds');
const { divideArrayInBatches } = require('../../src/batching-utils');

/** Entities to use */
const ENTITIES = {
    DB: {
        RCPOSITIVECONTRIBUTION_GROUPINGS_TO_PROCESS: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONGROUPINGSTOPROCESS',
        RCPOSITIVECONTRIBUTION_EXECUTIONS_READY_TO_PROCESS: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONEXECUTIONSREADYTOPROCESS',
        RCPOSITIVECONTRIBUTION_ASSESSMENT_JOBS: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONJOBEXECUTIONLOGS'
    }
};

/** Default batch size for groupings */
const DEFAULT_GROUPING_BATCH = 50;

/** Max items (products) per assessment */
const MAX_ITEMS_PER_ASSESSMENT = 2000;

/** Services to connect */
const SERVICES = {
    DB: 'db',
    SUSTAINABILITY: 'SustainabilityService',    
};

/** URLs to use when calling services */
const URL = {
    RCPC_ASSESSMENT_CREATION: '/odata/v4/sustainability-background/rcPcAssessmentCreation',
};

/** Process user ID */
const GENERIC_USER = 'RCPC_TRIGGER_JOB';

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
}

/** Available process types */
const PROCESS_TYPE = {
    RCPC: 'RCPC',
};

/** HTTP methods */
const HTTP_METHODS = {
    GET: 'GET',
    POST: 'POST',
};

/** Default logger */
const logger = cds.log('rcpc-assessment-trigger');

/**
 * Implementation for pdpAssessmentTrigger action import trigger 
 * @param {cds.Request} req - Incoming request made 
 */
async function rcPositiveContributionAssessmentTrigger ( req ) {

    const { status } = req.data;

    req.on('done', onRequestDoneMaker(status));    

    logger.info('Assessment creation triggered');

    // Groupings are retrieved, each grouping corresponds to an assessment to create
    const aGroupingsToProcess = await cds.db.run(
        SELECT
            .from(ENTITIES.DB.RCPOSITIVECONTRIBUTION_GROUPINGS_TO_PROCESS)
            .where({ status })
    );

    logger.info('Groupings to create: ', aGroupingsToProcess.length);

    const aBatches = divideArrayInBatches( aGroupingsToProcess, DEFAULT_GROUPING_BATCH );
    for (const batch of aBatches) {

        const aRunIds = batch.map(item => item.RUNID);
        const aSbus = batch.map(item => item.SBU);

        // Query products ready to assess from FIFO logic
        const aProductsReady = await cds.db.run(
            SELECT
                .from(ENTITIES.DB.RCPOSITIVECONTRIBUTION_EXECUTIONS_READY_TO_PROCESS)
                .where({
                    sbu: aSbus,
                    runId: aRunIds,
                    status,
                })
                .orderBy({ RUNID: 'asc' })
        );        

        // For each grouping, their available products are obtained and used to
        // trigger process
        for (grouping of batch) {
            const aProductsForGrouping = aProductsReady
                .filter(item => {
                    const bIsFromGroup = (
                        item.SBU === grouping.SBU &&
                        item.RUNID === grouping.RUNID &&
                        item.STATUS === grouping.STATUS
                    );

                    return bIsFromGroup;
                })
                .map( item => item.MATERIAL );
            
            const aProductsLinked = aProductsForGrouping.filter(item => item);
            const aProductsBatched = divideArrayInBatches(aProductsLinked, MAX_ITEMS_PER_ASSESSMENT);
            if (aProductsLinked && aProductsLinked.length > 0){
                logger.info('Create assessment for grouping', grouping);

                const wait = (seconds) => new Promise(res => setTimeout(res, seconds * 1000));
                for( const batch of aProductsBatched ){
                    // Creation is triggered for linked products
                    const SustainabilityService = await cds.connect.to(SERVICES.SUSTAINABILITY);
                    
                    await wait(1);
                    try {
                        const oResult = await SustainabilityService.send({
                            method: HTTP_METHODS.POST,
                            path: URL.RCPC_ASSESSMENT_CREATION,
                            data: {
                                sbu: grouping.SBU, 
                                products: batch,
                                status: grouping.STATUS,
                                runId: grouping.RUNID,
                            }
                        });
                    } catch (error) {
                        logger.error('Failed to call Sustainability RCPC assessment creation:', error);
                        return req.error('Failed to call Sustainability RCPC assessment creation');
                    }
                }
            }
        }
    }

    return `RCPC assessment creation finished`;

};

/**
 * Factoy function for on Request done event handling
 * 
 * @param {string} status - status used for execution
 * @returns {function} Handler function created
 */
function onRequestDoneMaker(status) {
    return async(tx) => {
        cds.spawn( async () => {
            const now = new Date();
            const db = await cds.connect.to('db');
            await db.run(
                INSERT
                    .into(ENTITIES.DB.RCPOSITIVECONTRIBUTION_ASSESSMENT_JOBS)
                    .entries([{
                        ID: cds.utils.uuid(),
                        createdAt: now,
                        createdBy: GENERIC_USER,
                        modifiedAt: now,
                        modifiedBy: GENERIC_USER,                        
                        type: PROCESS_TYPE.RCPC, 
                        status, 
                    }])
            );
        })
    }
};

module.exports = {
    rcPositiveContributionAssessmentTrigger,
}