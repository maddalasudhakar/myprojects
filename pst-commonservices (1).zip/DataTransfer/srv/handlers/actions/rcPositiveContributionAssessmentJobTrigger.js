
const cds = require('@sap/cds');

/** Used entities */
const ENTITIES = {
    DB: {
        RCPOSITIVECONTRIBUTION_EXECUTION_LOGS: 'COM_SUSTAINABILITY_BACKGROUND_RCPOSITIVECONTRIBUTIONJOBEXECUTIONLOGS',
        JOB_LOGS_TABLE: 'COM_SUSTAINABILITY_BACKGROUND_JOBORCHESTRATORLOGS'
    }
};

/** Available processing status */
const PROCESSING_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
}

/** Handlers for each kind of service */
const PROCESS_TO_HANDLER = {
    RCPC: 'rcPositiveContributionAssessmentTrigger',
    RCPC_DELTA: 'rcPositiveContributionAssessmentDelta',
};

/** Types of processess used */
const PROCESS_TYPE = {
    RCPC_DELTA: 'RCPC_DELTA',
    RCPC: 'RCPC',
}

/** Used services */
const SERVICES = {
    DB: 'db',
    DATA_TRANSFER: 'DataTransferService'
};

/** Total number of triggerable jobs, 2 deltas and 4 assessment with retry */
const TOTAL_JOBS = 6;

/**
 * Handler for action in charge of managing ADP Job triggering
 * 
 * @param {cds.Request} req - Request object 
 */
async function rcPositiveContributionAssessmentJobTrigger( req ) {

    const orchecstratorLog = {
        ID: cds.utils.uuid(),
        createdAt: new Date(),
        createdBy: 'JOB_ORCHESTRATOR',
        modifiedAt: new Date(),
        modifiedBy: 'JOB_ORCHESTRATOR',
        type: 'RCPC',
        status: '01',
    };
    await cds.tx(
        INSERT.into( ENTITIES.DB.JOB_LOGS_TABLE )
            .entries([ orchecstratorLog ])
    );

    req.on('done', async () => {
        await cds.tx(
            UPDATE( ENTITIES.DB.JOB_LOGS_TABLE )
                .set({ status: '03' })
                .where({ ID: orchecstratorLog.ID })
        );
    });    

    // Get last time each kind of jib was executed
    const lastJobs = await cds.db.run(
        SELECT
            .from(ENTITIES.DB.RCPOSITIVECONTRIBUTION_EXECUTION_LOGS)
            .columns('type', 'status', 'MAX(createdAt)')
            .groupBy('type', 'status')
    );

    const jobParams = getJobConfiguration();
    
    // Check if first time already happened and if not trigger it
    try {
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.RCPC_DELTA );
    } catch (error) {
        console.error(error);
    }
    
    try {
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.RCPC, PROCESSING_STATUS.RETRIAL );
        await triggerJob( lastJobs, jobParams, PROCESS_TYPE.RCPC, PROCESSING_STATUS.PENDING );
    } catch (error) {
        console.error(error);
    }

    return 'Job finished';

};


/**
 * Resolves the effective trigger day for a given month, clamping dayOfMonth
 * to the last day of the month if the month is shorter (e.g. 31 → 28 in February).
 *
 * @param {number} year       - Full year (e.g. 2026)
 * @param {number} month      - 0-indexed month (0 = January, 11 = December)
 * @param {number} dayOfMonth - Configured trigger day (1-31)
 * @returns {number} - Effective day to trigger on
 */
function resolveEffectiveDay(year, month, dayOfMonth) {
    // Day 0 of next month === last day of current month
    const lastDayOfMonth = new Date(year, month + 1, 0).getDate();
    return Math.min(dayOfMonth, lastDayOfMonth);
}

/**
 * Determines whether a job should fire given its configuration and last-run history.
 *
 * Scheduling rules:
 *  1. If `jobParam.dayOfMonth` is set (1-31):
 *       a. Job must not have already run this calendar month.
 *       b. Clamp dayOfMonth to the last valid day of the current month
 *          (e.g. 31 → 28 in February, 31 → 30 in April).
 *       c. If today >= effectiveDay → trigger (day has arrived or passed, not yet run this month).
 *       d. If today < effectiveDay  → do not trigger yet.
 *  2. If `jobParam.dayOfMonth` is not set:
 *       - Fall back to interval logic: last run must be older than `jobParam.interval` minutes.
 *
 * @param {Date}        now      - Current timestamp.
 * @param {Object|null} job      - Last execution record ({ MAX: Date }), or null if never run.
 * @param {Object}      jobParam - Config entry ({ interval?, dayOfMonth?, active, ... }).
 * @returns {boolean}
 */
function shouldTrigger(now, job, jobParam) {

    if (jobParam?.dayOfMonth) {
        const targetDay      = Number(jobParam.dayOfMonth);
        const effectiveDay   = resolveEffectiveDay(now.getFullYear(), now.getMonth(), targetDay);

        // Check if already triggered this calendar month
        if (job) {
            const lastRun = new Date(job.MAX);
            const alreadyRanThisMonth =
                lastRun.getFullYear() === now.getFullYear() &&
                lastRun.getMonth()    === now.getMonth();
            if (alreadyRanThisMonth) return false;
        }

        // Trigger if the effective day has arrived or already passed this month
        return now.getDate() >= effectiveDay;
    }

    // Interval-based fallback
    if (!job) return true;

    const MINUTE_TO_MS_RATE = 1000 * 60;
    return isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);

} 

/**
 * Method to trigger jobs
 * 
 * @param {*} lastJobs 
 * @param {*} jobParams 
 * @param {*} processType 
 * @param {*} status 
 */
async function triggerJob ( lastJobs, jobParams, processType, status ) {

    // const MINUTE_TO_MS_RATE = 1000 * 60;
    const DataTransferService = await cds.connect.to(SERVICES.DATA_TRANSFER);
    const now = new Date();
    if (status) {

        const hasLastJob = lastJobs.some(item => {
            return item.STATUS === status && item.TYPE === processType;
        })
        const jobParam = jobParams.subJobs.find( item => {
            return item.status === status && item.processType === processType
        });        
        
        // If already triggeredd once, check time. If not, trigger it
        if (hasLastJob && jobParam) {

            const job = lastJobs.find(item => {
                return item.STATUS === status && item.TYPE === processType;
            });

            // const isInScheduledTime = isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);
            const isInScheduledTime = shouldTrigger(now, job, jobParam );
            if (jobParam.active && isInScheduledTime) {
                await DataTransferService.send( PROCESS_TO_HANDLER[processType], { status } );
            }

        } else if ( jobParam?.active ) {
        
            await DataTransferService.send( PROCESS_TO_HANDLER[processType], { status } );
        
        }

    } else {

        const hasLastJob = lastJobs.some(item => item.TYPE === processType);
        const jobParam = jobParams.subJobs?.find( item => item.processType === processType);        
        // If already triggeredd once, check time. If not, trigger it
        if (hasLastJob && jobParam) {

            const job = lastJobs.find( item => item.TYPE === processType );

            // const isInScheduledTime = isDateLessThanInterval(job.MAX, now, jobParam.interval * MINUTE_TO_MS_RATE);
            const isInScheduledTime = shouldTrigger(now, job, jobParam );
            if (jobParam.active && isInScheduledTime) {
                await DataTransferService.send( PROCESS_TO_HANDLER[processType]);
            }

        } else if ( jobParam?.active ) {
        
            await DataTransferService.send( PROCESS_TO_HANDLER[processType] );
        
        }

    }

};

/**
 * Retrieves job configuration
 * 
 * @returns  {Object} Retrieves job configuration
 */
function getJobConfiguration( ) {

    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"]; 
    const jobParams = userProvided?.find(item => item.name === 'DataTransfer-job-params')?.credentials 
        || userProvided?.find(item => item.name === 'custom-service:DataTransfer-job-params')?.credentials
        || cds.env?.JOB_PARAMS;
    return jobParams.rcPositiveContributionJobTrigger;

};

/**
 * Checks if a date is prior to a certain interval from provided one
 * 
 * @param {Date} dateToCheck - Date to compare
 * @param {Date} referenceDate - Reference date
 * @param {number} intervalMs - Miliseconds of interval 
 * @returns 
 */
function isDateLessThanInterval(dateToCheck, referenceDate, intervalMs) {

    // Convert to timestamps for comparison
    const checkTime = new Date(dateToCheck).getTime();
    const referenceTime = new Date(referenceDate).getTime();
    
    // Calculate the threshold (reference date minus interval)
    const thresholdTime = referenceTime - intervalMs;
    
    // Return true if dateToCheck is earlier than the threshold
    return checkTime < thresholdTime;

};

module.exports = {
    rcPositiveContributionAssessmentJobTrigger,
};