@requires: 'authenticated-user'
service DataTransferService {

    action processApprobedIdhProducts();
    action processApprobedIbProducts();
    action processRejectedProducts();
    action processCPIRetrial();
    action screeningMismatchedSustClass();
    action createAssessmentsForMismatchedProducts();

    /**
     *  Action to check pending PDP projects in delta table and generate assessment 
     * */
    action pdpAssessmentTrigger( 
        status: String(2) enum {
            PENDING = '01';
            RETRIAL = '02';
        }
    ) returns String;

    /**
     * Action to trigger PDP delta process
     */
    action pdpAssessmentDelta() returns String;

    /**
     *  Action to check pending MOC projects in delta table and generate assessment 
     */
    action mocAssessmentTrigger( 
        status: String(2) enum {
            PENDING = '01';
            RETRIAL = '02';
        }
    ) returns String;

    /**
     * Action to trigger MOC delta process
     */
    action mocAssessmentDelta() returns String;

    /**
     * Action to check and trigger jobs if required
     */
    action adpAssessmentJobTrigger() returns String;

    /**
     * Action to  trigger Mismatched Assessments jobs if required
     */
    action mismatchedAssessmentJobTrigger() returns String;
    
    /** Action to check and trigger HEART jobs if required */
    action heartAssessmentJobTrigger() returns String;

    /** Action to trigger HEART delta */
    action heartAssessmentDelta() returns String;

    /** Action to trigger HEART assessment */
    action heartAssessmentTrigger( 
        status: String(2) enum {
            PENDING = '01';
            RETRIAL = '02';
        }        
    ) returns String;

    /** Action to trigger RCPC jobs */
    action rcPositiveContributionJobTrigger() returns String;

    /** Action to trigger RCPC delta */
    action rcPositiveContributionAssessmentDelta() returns String;

    /** Action to trigger RCPC assessment */
    action rcPositiveContributionAssessmentTrigger( 
        status: String(2) enum {
            PENDING = '01';
            RETRIAL = '02';
        }        
    ) returns String;    

    action jobOrchestrator() returns String;
    
};
