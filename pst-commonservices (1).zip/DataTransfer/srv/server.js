const cds = require('@sap/cds');

cds.once('served', async (tx) => {
    // cds.env.requires.db.credentials.communicationTimeout  = 10 * 60 * 1000;
    const MINUTE_TO_MS_RATE = 1000 * 60;
    const userProvided = JSON.parse(process.env.VCAP_SERVICES)["user-provided"]; 
    const jobParams = userProvided?.find(item => item.name === 'DataTransfer-job-params')?.credentials 
        || userProvided?.find(item => item.name === 'custom-service:DataTransfer-job-params')?.credentials  
        || cds.env?.JOB_PARAMS;

    if (jobParams) {
        const jobOrchestrator = jobParams.jobOrchestrator;
        const orchestratorGroups = jobOrchestrator.groups ?? [];
        const adpFromOrchestrator = orchestratorGroups.find(group => group.process === 'ADP')?.active;
        const heartFromOrchestrator = orchestratorGroups.find(group => group.process === 'HEART')?.active;
        const rcmFromOrchestrator = orchestratorGroups.find(group => group.process === 'RCM')?.active;
        const rcpcFromOrchestrator = orchestratorGroups.find(group => group.process === 'RCPC')?.active;

        if (jobParams.processApprobedIdhProducts?.active) {
            cds.spawn({ after: 30000, every: jobParams.processApprobedIdhProducts.interval }, async (tx) => {
                console.log("Trigger processApprobedIdhProducts job");
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("processApprobedIdhProducts");     
            });
        }
        if (jobParams.processApprobedIbProducts?.active) {
            cds.spawn({ after: 30000, every: jobParams.processApprobedIbProducts.interval }, async (tx) => {
                console.log("Trigger processApprobedIbProducts job");
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("processApprobedIbProducts");      
            });
        }
        if (jobParams.processRejectedProducts?.active) {
            cds.spawn({ after: 30000, every: jobParams.processRejectedProducts.interval }, async (tx) => {
                console.log("Trigger processRejectedProducts job");                
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("processRejectedProducts");    
            });       
        }        

        if (jobParams.processCPIRetrial?.active) {
            cds.spawn({ after: 30000, every: jobParams.processCPIRetrial.interval }, async (tx) => {
                console.log("Trigger processCPIRetrial job");                
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("processCPIRetrial");    
            });       
        }
        
        if (jobParams.adpAssessmentTrigger?.active && !adpFromOrchestrator) {
            const user = new cds.User.Privileged;
            cds.spawn({ user, every: jobParams.adpAssessmentTrigger.interval * MINUTE_TO_MS_RATE }, async (tx) => {
            // cds.spawn({ }, async (tx) => {
                console.log("Trigger adpAssessmentJobTrigger job");                
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("adpAssessmentJobTrigger");    
            });                
        }
        if (jobParams.mismatchedAssessmentJobTrigger?.active && !rcmFromOrchestrator) {
            const user = new cds.User.Privileged;
            cds.spawn({ user, every: jobParams.mismatchedAssessmentJobTrigger.interval * MINUTE_TO_MS_RATE }, async (tx) => {
                console.log("Trigger mismatchedAssessmentJobTrigger job");                
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("mismatchedAssessmentJobTrigger");    
            });                
        }

        const user = new cds.User.Privileged;
        if (jobParams.heartAssessmentTrigger?.active && !heartFromOrchestrator) {
            cds.spawn({ user, every: jobParams.heartAssessmentTrigger.interval * MINUTE_TO_MS_RATE }, async tx => {
                console.log('Trigger heartAssessmentJobTrigger job');
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("heartAssessmentJobTrigger");   
            });
        }

        if (jobParams.rcPositiveContributionJobTrigger?.active && !rcpcFromOrchestrator) {
            cds.spawn({ user, every: jobParams.rcPositiveContributionJobTrigger.interval * MINUTE_TO_MS_RATE }, async tx => {
                console.log('Trigger rcPositiveContributionAssessmentJobTrigger job');
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("rcPositiveContributionAssessmentJobTrigger");   
            });
        }        
        
        if (jobParams.jobOrchestrator?.active) {
            cds.spawn({ user, every: jobParams.jobOrchestrator.interval * MINUTE_TO_MS_RATE }, async tx => {
            // cds.spawn({ user, after: 1 * MINUTE_TO_MS_RATE }, async tx => {
                console.log('Trigger job orchestrator');
                const DataTransferService = await cds.connect.to("DataTransferService");
                await DataTransferService.send("jobOrchestrator");   
            });            
        }
    }    

});
