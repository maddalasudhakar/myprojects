using {capire.rag as db} from '../db/capire';

service Capire {
    @readonly
    entity docs as projection on db.Sitemap order by topic, subTopic;

    entity Conversation as projection on db.Conversation;

    entity Message as projection on db.Message order by creation_time desc;

    type messageResponse {
        role               : String;
        content            : String;
        messageTime        : String;
        additionalContents : array of {
            score: String;
            pageContent: String;
        };
    }
    action fetchUserResponse(input: LargeString, conversationId: String, messageId: String, message_time: Timestamp) returns messageResponse;
}