const cds = require("@sap/cds");
const { uuid } = cds.utils;

module.exports = class Capire extends cds.ApplicationService {
    init() {
        this.on("fetchUserResponse", async (req) => {
            const traceloop = require("@traceloop/node-server-sdk");
            const { input, conversationId, messageId, message_time } = req.data;
            const { Conversation, Message } = this.entities;

            const oLlmPlugin = await cds.connect.to("cap-llm-plugin");

            const oChatModelConfig = cds.env.requires["gen-ai-hub"]["gpt-4o"];
            const oEmbeddingModelConfig = cds.env.requires["gen-ai-hub"]["ada-002"];

            const sPromptTemplate = `You are an helpful assistant who answers user question based only on the following context enclosed in triple quotes.\n`;

            //handle memory before the RAG LLM call
            const memoryContext = await storeRetrieveMessages(conversationId, messageId, message_time, req.user.id, input, Conversation, Message, oChatModelConfig.modelName);
            
            let oMessageResponse = await traceloop.withLLMCall({ vendor: "OpenAI", type: "getRAGResponse" }, async ({ span }) => {
                span.reportRequest({
                    model: `embedding: ${oEmbeddingModelConfig.modelName}, chat: ${oChatModelConfig.modelName}`,
                    messages: [{ role: "user", content: `originalInput: ${input}, memoryContext: ${memoryContext.length > 0 ? memoryContext : undefined}` }]
                });
                const response = await oLlmPlugin.getRagResponseWithConfig(
                    input,
                    "CAPIRE_RAG_EMBEDDINGS",
                    "CAPIREDOCVECTOR",
                    "VECTORMETADATA",
                    sPromptTemplate,
                    oEmbeddingModelConfig,
                    oChatModelConfig,
                    memoryContext.length > 0 ? memoryContext : undefined,
                    20
                );
                span.reportResponse(response.completion);

                return response;
            });

            await traceloop.withVectorDBCall({vendor: "SAP HANA cloud", type: "query"}, async ({span}) => {
                span.reportQuery({queryVector: oMessageResponse?.additionalContents[0]?.embedding});
                span.reportResults({ results: oMessageResponse.additionalContents });
            });

            let oFinalMessageResponse = {};
            if (oChatModelConfig.modelName === "gpt-4o") {
                oFinalMessageResponse =
                {
                    "role": oMessageResponse.completion.choices[0].message.role,
                    "content": oMessageResponse.completion.choices[0].message.content
                }
            }
            else {
                throw new Error("The model supported in this application is 'gpt-4'. Please customize this application to use any model supported by CAP LLM Plugin.")
            }
            //store latest response
            const responseTimestamp = new Date().toISOString();
            await storeModelResponse(conversationId, responseTimestamp, oFinalMessageResponse, Message, Conversation);

            return {
                "role": oFinalMessageResponse.role,
                "content": oFinalMessageResponse.content,
                "messageTime": responseTimestamp,
                "additionalContents": oMessageResponse.additionalContents,
            };

        });

        super.init();
    }
}

async function storeRetrieveMessages(conversationId, messageId, message_time, user_id, user_query, Conversation, Message, modelName) {
    try {

        let memoryContext = [];
        // Check if conversation exists in the db
        const isConversationPresent = await SELECT.from(Conversation).where({ "cID": conversationId });
        // If conversation is present, select messages from db and store it in memory context obj

        if (isConversationPresent.length > 0) {
            cds.log("insertConversationInfo").info(`Retrieving messages for conversation id: ${conversationId}`);
            const messageSelectStmt = await SELECT.from(Message).where({ "cID_cID": conversationId }).orderBy('creation_time');
            //parse the memory context for different models

            if (messageSelectStmt.length > 0) {
                //for gpt-4 or anthropic--claude-3-sonnet models
                if (modelName === "gpt-4o") {
                    messageSelectStmt.forEach(message => {
                        memoryContext.push({
                            "role": message.role,
                            "content": message.content
                        });
                    });
                }
                //Parse the responses of other chat models supported by the CAP LLM Plugin
                else {
                    throw new Error(`Model ${modelName} not supported.`);
                }
            }
            else {
                throw new Error(`Messages corresponding to conversation id: ${conversationId} not present!`);
            }
        }

        // If conversation is not present, insert the conversation into db
        else {
            //const conversationTitle = await getConversationSummarization(user_query);
            cds.log("insertConversationInfo").info(`Inserting new conversation for conversation id: ${conversationId}`);
            const currentTimestamp = new Date().toISOString();
            const conversationEntry = {
                "cID": conversationId,
                "userID": user_id,
                "creation_time": currentTimestamp,
                "last_update_time": currentTimestamp,
                "title": user_query,
            };
            const conversationInsertStatus = await INSERT.into(Conversation).entries([conversationEntry]);
            if (!conversationInsertStatus) {
                throw new Error("Insertion of conversation into db failed!");
            };
        }

        // In both cases, insert the message into db
        const messageRecord = {
            "cID_cID": conversationId,
            "mID": messageId,
            "role": "user",
            "content": user_query,
            "creation_time": message_time
        };

        await insertMessage(Message, messageRecord, conversationId, Conversation, message_time);
        return memoryContext;
    }

    catch (error) {
        // Handle any errors that occur during the execution
        cds.log("insertConversationError").error('Error handling memory prior to RAG response:', error);
        throw error;
    }
}

async function storeModelResponse(conversationId, message_time, chatRagResponse, Message, Conversation) {
    try {
        const aiMessageRecord = {
            "cID_cID": conversationId,
            "mID": uuid(),
            "role": chatRagResponse.role,
            "content": chatRagResponse.content,
            "creation_time": message_time
        };

        // Insert the assistant message to db
        await insertMessage(Message, aiMessageRecord, conversationId, Conversation, new Date().toISOString());
    }
    catch (error) {
        // Handle any errors that occur during the execution
        cds.log("insertConversationError").error('Error handling memory post RAG response:', error);
        throw error;
    }

}

async function insertMessage(messageEntity, messageRecord, conversationId, conversationEntity, messageTime) {

    cds.log("insertMessageInfo").info(`Inserting new message for conversation id: ${conversationId}`);
    const messageInsertionStatus = await INSERT.into(messageEntity).entries([messageRecord]);
    if (!messageInsertionStatus) {
        throw new Error("Insertion of message into db failed!");
    };

    cds.log("updateConversationInfo").info(`Updating the time for conversation id: ${conversationId}`);

    const oTimeToUpdate = {
        last_update_time: messageTime
    };
    const updateConversationStatus = await UPDATE(conversationEntity).set(oTimeToUpdate).where({
        cID: conversationId
    });
    if (updateConversationStatus !== 1) {
        throw new Error("Updating the conversation time failed!");
    }
}