namespace capire.rag;
using {cuid} from '@sap/cds/common';

entity Sitemap: cuid {
    topic: String(256);
    subTopic: String(1024);
    lastUpdatedOn: Timestamp;
    url: String(4096);
}

entity Embeddings: cuid {
    key ID: UUID; // uuid of the sitemap entry (each one might have multiple chunks)
    key chunkId: UUID;
    vectorMetadata: LargeString;
    capireDocVector: Vector;
}

entity Conversation {

    key cID : String(100) not null;
    userID: String;
    creation_time: Timestamp;
    last_update_time: Timestamp;
    title: String;
    to_messages: Composition of many Message on to_messages.cID = $self;
}

entity Message {

    key cID: Association to Conversation;
    key mID: String(100) not null;
    role: String;
    content: LargeString;
    creation_time: Timestamp;
}

