
@impl: 'srv/create-capire-embeddings.js'
service EmbeddingsService {
    action create() returns String;
}