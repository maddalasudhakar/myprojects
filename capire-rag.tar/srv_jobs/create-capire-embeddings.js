const cds = require('@sap/cds');

module.exports = class EmbeddingsService extends cds.ApplicationService {

    init() {
        this.on("create", async (req) => {

            const { SitemapLoader } = require("@langchain/community/document_loaders/web/sitemap");

            const { Sitemap, Embeddings } = cds.entities("capire.rag");
            let aCurrentSitemap = await SELECT.from(Sitemap);

            const loader = new SitemapLoader("https://cap.cloud.sap/docs");
            const aNewSitemap = await loader.parseSitemap();

            cds.log("XmlData").info(aNewSitemap);

            let aItemsToInsert = [], aItemsToUpdate = [];

            if (aCurrentSitemap.length > 0) {
                aNewSitemap.map(loc => {
                    const sTopic = loc.loc.split("/docs/")[1].split("/")[0];
                    const sSubTopic = loc.loc.split("/docs/")[1].split("/").splice(1).join("/");
                    const dLastModified = loc.lastmod.split("T")[0] + " " + loc.lastmod.split("T")[1].substring(1) + ".000000000";

                    const aExisting = aCurrentSitemap.filter(item => item.topic === sTopic && item.subTopic === sSubTopic && item.lastUpdatedOn !== dLastModified)

                    if (!sTopic || sTopic === "")
                        return;

                    if (aExisting.length > 0) {

                        aExisting.map(item => {
                            aItemsToUpdate.push({
                                ID: item.ID,
                                topic: sTopic,
                                subTopic: sSubTopic,
                                lastUpdatedOn: dLastModified,
                                url: loc.loc
                            });
                        });
                    } else {
                        aItemsToInsert.push({
                            topic: sTopic,
                            subTopic: sSubTopic,
                            lastUpdatedOn: loc.lastmod,
                            url: loc.loc
                        });
                    }
                });
            } else {
                aNewSitemap.map(loc => {
                    const sTopic = loc.loc.split("/docs/")[1].split("/")[0];
                    const sSubTopic = loc.loc.split("/docs/")[1].split("/").splice(1).join("/");

                    if (!sTopic || sTopic === "")
                        return;

                    aItemsToInsert.push({
                        topic: sTopic,
                        subTopic: sSubTopic,
                        lastUpdatedOn: loc.lastmod,
                        url: loc.loc
                    });
                });
            }

            if (aItemsToInsert.length > 0)
                await INSERT.into(Sitemap).entries(aItemsToInsert);

            if (aItemsToUpdate.length > 0)
                await UPSERT(aItemsToUpdate).into(Sitemap);

            cds.spawn(null, async (tx) => {

                const { RecursiveCharacterTextSplitter } = require("@langchain/textsplitters");
                const { HTMLWebBaseLoader } = require("@langchain/community/document_loaders/web/html");
                const { HtmlToTextTransformer } = require("@langchain/community/document_transformers/html_to_text");
                const traceloop = require("@traceloop/node-server-sdk");
                const { uuid } = cds.utils;
                const llmPlugin = await cds.connect.to("cap-llm-plugin");

                let aGenVectors = [];

                // get updated sitemap details
                const aCurrentSitemap = await SELECT.from(Sitemap);

                for await (const item of aItemsToInsert) {
                    try {
                        const oLoader = new HTMLWebBaseLoader(item.url);
                        const docs = await oLoader.load();

                        const oSplitter = RecursiveCharacterTextSplitter.fromLanguage("html", {
                            chunkSize: 1500,
                            chunkOverlap: 150,
                            addStartIndex: true
                        });

                        const oTransformer = new HtmlToTextTransformer();

                        const sequence = oSplitter.pipe(oTransformer);
                        let newDocuments = await sequence.invoke(docs);

                        newDocuments = newDocuments.map(doc => doc.pageContent);

                        await traceloop.withWorkflow({ name: "capire-rag-job-llmplugin", traceContent: true }, async () => {

                            for (const chunk of await oSplitter.splitText(newDocuments.join("\n\n"))) {
                                const response = await traceloop.withLLMCall({ vendor: "OpenAI", type: "getEmbedding" }, async ({ span }) => {
                                    span.reportRequest({
                                        model: cds.env.requires["gen-ai-hub"]["ada-002"].modelName, messages: [{
                                            role: "user", content: chunk
                                        }]
                                    });

                                    const response = await llmPlugin.getEmbeddingWithConfig(cds.env.requires["gen-ai-hub"]["ada-002"], chunk);

                                    span.reportResponse(response);

                                    return response
                                });

                                aGenVectors.push({
                                    ID: aCurrentSitemap.filter(s => s.topic === item.topic && s.subTopic === item.subTopic)[0].ID,
                                    chunkId: uuid(),
                                    vectorMetadata: chunk,
                                    capireDocVector: `[${response?.data[0]?.embedding}]`
                                });

                                // need to update database inside the loop
                                // because we might very soon go out of memory if we collect all vectors at once and try updating later
                                // for optimization reasons, updating db after every 20 records
                                if (aGenVectors.length === 20) {
                                    await UPSERT(aGenVectors).into(Embeddings);
                                    aGenVectors = [];
                                }
                            }
                        });
                    } catch (error) {
                        cds.log("EmbeddingGenerationError").error(`Error generating embedding for topic ${item.topic} and the reason is ${error}`);
                    }
                };

                for await (const item of aItemsToUpdate) {
                    if (item.topic !== "cds" && item.topic !== "about")
                        continue;
                    try {
                        const oLoader = new HTMLWebBaseLoader(item.url);
                        const docs = await oLoader.load();

                        const oSplitter = RecursiveCharacterTextSplitter.fromLanguage("html", {
                            chunkSize: 1500,
                            chunkOverlap: 150,
                            addStartIndex: true
                        });
                        const oTransformer = new HtmlToTextTransformer();

                        const sequence = oSplitter.pipe(oTransformer);
                        const newDocuments = await sequence.invoke(docs);

                        newDocuments = newDocuments.map(doc => doc.pageContent);

                        for (const chunk of await oSplitter.splitText(newDocuments.join(","))) {
                            const response = await llmPlugin.getEmbeddingWithConfig(cds.env.requires["gen-ai-hub"]["ada-002"], chunk);
                            aGenVectors.push({
                                ID: item.ID,
                                chunkId: uuid(),
                                vectorMetadata: chunk,
                                capireDocVector: `[${response?.data[0]?.embedding}]`
                            });

                            // need to update database inside the loop
                            // because we might very soon go out of memory if we collect all vectors at once and try updating later
                            // for optimization reasons, updating db after every 20 records
                            if (aGenVectors.length === 20) {
                                await UPSERT(aGenVectors).into(Embeddings);
                                aGenVectors = [];
                            }
                        }
                    } catch (error) {
                        cds.log("EmbeddingGenerationError").error(`Error generating embedding for topic ${item.topic} and the reason is ${error}`);
                    }
                };

                // if records still exist to be updated then
                // we do it there at the end
                if (aGenVectors.length > 0)
                    await UPSERT(aGenVectors).into(Embeddings);

                tx.commit();
                cds.log("createEmbeddingsCompletion").info("Embeddings generated");
            });

            req.res.status(202);
            return "Embeddings are being generated";
        });

        super.init();
    }
}