sap.ui.define([
    "sap/ui/core/Fragment",
    "sap/base/util/uid",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (Fragment, Uuid, Filter, FilterOperator) {
    'use strict';

    return {
        startDigitalAssistant: async function () {
            let that = this;
            if (!this._digitalAssistantPopover) {
                this._digitalAssistantPopover = await Fragment.load({
                    id: that._view.getId(),
                    name: "capiredocsrag.ext.fragments.DigitalAssistantPopover",
                    controller: that
                }).then(function (oPopover) {
                    that._view.addDependent(oPopover);
                    return oPopover;
                });
            }

            // start the conversation by generating a new ID
            this._conversationId = Uuid() + Uuid();

            let aFilter = new Filter({
                filters: [
                    new Filter({
                        path: "cID_cID",
                        operator: FilterOperator.EQ,
                        value1: `${this._conversationId}`
                    })
                ]
            });

            this._digitalAssistantPopover.getContent()[0].getItems()[0].getBinding("items").filter(aFilter);

            this._digitalAssistantPopover.openBy(this._view.byId("capiredocsrag::docsList--fe::table::docs::LineItem::CustomAction::ListReportController"));
        },
        onEndConversation: function(oEvent) {
            this._conversationId = null;
            this._messageId = null;
            oEvent.getSource().getParent().getParent().close();
        },

        onSendQuestion: function(oEvent) {

            oEvent.getSource().getParent().getContent()[0].getItems()[0].setBusy(true);
            let oModel = oEvent.getSource().getParent().getModel();

            this._messageId = this._conversationId + new Date().toISOString();
            
            let oBindingContext = oModel.bindContext("/fetchUserResponse(...)");
            oBindingContext.setParameter("input", oEvent.getParameters().value);
            oBindingContext.setParameter("conversationId", this._conversationId);
            oBindingContext.setParameter("messageId", this._messageId);
            oBindingContext.setParameter("message_time", new Date().toISOString());

            oBindingContext.execute().then(function(oResponse) {
                oEvent.getSource().getParent().getContent()[0].getItems()[0].getBinding("items").refresh();
                oEvent.getSource().getParent().getContent()[0].getItems()[0].setBusy(false);
            });
        }
    };
});
