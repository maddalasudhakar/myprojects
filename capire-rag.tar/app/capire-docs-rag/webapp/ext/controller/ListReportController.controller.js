sap.ui.define([
    'sap/ui/core/mvc/ControllerExtension'
],function(ControllerExtension) {
    'use strict';

    return ControllerExtension.extend('capiredocsrag.ext.controller.ListReportController', {
        override: {
            onBeforeRendering: function() {
                let sIdDaButton = this.base.getExtensionAPI().byId("capiredocsrag::docsList--fe::table::docs::LineItem::Table").getTableDefinition().actions[0].id;
                this.base.getView().byId(`capiredocsrag::docsList--fe::table::docs::LineItem::${sIdDaButton}`).setIcon("sap-icon://da-2");
                this.base.getView().byId(`capiredocsrag::docsList--fe::table::docs::LineItem::${sIdDaButton}`).setTooltip("Capire Digital Assistant");
                this.base.getView().byId(`capiredocsrag::docsList--fe::table::docs::LineItem::${sIdDaButton}`).setType("Accept");
            }
        }
    })
})