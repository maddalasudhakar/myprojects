sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'capiredocsrag/test/integration/FirstJourney',
		'capiredocsrag/test/integration/pages/docsList',
		'capiredocsrag/test/integration/pages/docsObjectPage'
    ],
    function(JourneyRunner, opaJourney, docsList, docsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('capiredocsrag') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onThedocsList: docsList,
					onThedocsObjectPage: docsObjectPage
                }
            },
            opaJourney.run
        );
    }
);