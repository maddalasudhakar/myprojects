sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("capiredocsrag.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);