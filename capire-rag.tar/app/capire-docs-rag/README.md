## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Sun Dec 22 2024 21:40:22 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori-elements|
|**App Generator Version**<br>1.12.2|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>List Report Page V4|
|**Service Type**<br>Local Cap|
|**Service URL**<br>http://localhost:4004/odata/v4/capire/
|**Module Name**<br>capire-docs-rag|
|**Application Title**<br>Retrieval Augmented generation of Capire docs|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon_dark|
|**UI5 Version**<br>1.131.1|
|**Enable Code Assist Libraries**<br>True|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>docs|

## capire-docs-rag

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply start your CAP project and navigate to the following location in your browser:

http://localhost:4004/capire-docs-rag/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


