using Capire as service from '../../srv/capire-service';

annotate service.docs with @(
    UI.LineItem: [
    {
        $Type: 'UI.DataField',
        Label: 'Topic',
        Value: topic,
    },
    {
        $Type: 'UI.DataField',
        Label: 'Sub-Topic',
        Value: subTopic,
    },
    {
        $Type: 'UI.DataField',
        Label: 'Last Updated on',
        Value: lastUpdatedOn,
    },
    {
        $Type: 'UI.DataFieldWithUrl',
        Label: 'Reference',
        Url: url,
        Value: url
    },

]);

annotate service.docs with @(
    UI.FieldGroup #GeneratedGroup1: {
        $Type: 'UI.FieldGroupType',
        Data : [
            {
                $Type: 'UI.DataField',
                Label: 'Topic',
                Value: topic,
            },
            {
                $Type: 'UI.DataField',
                Label: 'Sub-Topic',
                Value: subTopic,
            },
            {
                $Type: 'UI.DataField',
                Label: 'Last Updated on',
                Value: lastUpdatedOn,
            },
            {
                $Type: 'UI.DataField',
                Label: 'Reference',
                Value: url,
            },
        ],
    },
    UI.Facets                     : [{
        $Type : 'UI.ReferenceFacet',
        ID    : 'GeneratedFacet1',
        Label : 'General Information',
        Target: '@UI.FieldGroup#GeneratedGroup1',
    }, ]
);
