namespace com.sustainability;

using {
    managed,
    cuid,
    User,
} from '@sap/cds/common';

using com.sustainability.types as types from './types';

context management {

    type communicationStatus: types.communicationStatus;

    //@cds.persistence.skip
    entity SingleAssessment : cuid, managed {
        requestName                         : types.requestName;
        sbu                                 : types.sbu;
        product                             : types.product;
        productType                         : types.productType;
        assessor                            : types.assessor;
        submitter                           : types.submitter;
        submitionDate                       : types.date;
        approver                            : types.approver;
        approvalDate                        : types.approvalDate;
        assesmentType                       : types.assesmentType;
        status                              : types.status;
        statusDescription                   : types.statusDescription;
        communicationStatus                 : types.communicationStatus;
        virtualAssessment                   : types.virtualAssessment;
        projectId                           : types.projectId;
        comment                             : types.comment;
        rcPreFlag                           : types.rcPreFlag;
        rcPreFlagDescription                : types.rcPreFlagDescription;
        sustClass                           : types.sustClass;
        category1                           : types.category;
        contributor1                        : types.contributor;
        category2                           : types.category;
        contributor2                        : types.contributor;
        category3                           : types.category;
        contributor3                        : types.contributor;
        approberComment                     : String(255);
        propagation                         : Boolean;
        externalCommunication               : Boolean;
        idhAssessmentOverwrite              : Boolean;

        @Core.Computed: false
        virtual productName                 : String;

        @Core.Computed: false
        virtual technologyL2Key             : String;

        @Core.Computed: false
        virtual technologyLevel2            : String;

        @Core.Computed: false
        virtual sustainabilityClassCode     : String;

        @Core.Computed: false
        virtual existingSustainabilityClass : String;

        @Core.Computed: false
        virtual realSubstanceCode           : String(18);

        @Core.Computed: false
        virtual realSubstanceName           : String(40);

        @Core.Computed: false
        virtual region                      : String(3);

        @Core.Computed: false
        virtual applicationLevel2Key        : String(10);

        @Core.Computed: false
        virtual applicationLevel2           : String;

        @Core.Computed: false
        virtual lastAssessment              : String;

        @Core.Computed: false
        virtual lastSubmitter               : String;

        @Core.Computed: false
        virtual lastApprover                : String;
        toStatus                            : Association to one Status
                                                  on toStatus.code = status;
        toAssessmentType            : Association to one AssessmentType
                                                  on toAssessmentType.code = assesmentType;
        toProofDocuments            : Composition of many AssessmentProofDocument
                                                  on toProofDocuments.requestId = ID;
        toRecipients                : Composition of many NotificationRecipients
                                                  on toRecipients.assessmentId = ID;
    }

    entity MassAssessmentHeader : cuid, managed {
        requestName       : types.requestName;
        sbu               : types.sbu;
        assessor          : types.assessor;
        productType       : types.productType;
        submitter         : types.submitter;
        submitionDate     : types.date;
        approver          : types.approver;
        approvalDate      : types.approvalDate;
        assesmentType     : types.assesmentType;
        processType       : types.assessmentProcessType;
        status            : types.status;
        statusDescription : types.statusDescription;
        communicationStatus: types.communicationStatus;
        virtualAssessment : types.virtualAssessment;
        projectId         : types.projectId;
        approberComment   : String(255);
        idhAssessmentOverwrite : Boolean;
        toStatus          : Association to one Status
                                on toStatus.code = status;
        toAssessmentType  : Association to one AssessmentType
                                on toAssessmentType.code = assesmentType;
        toItems           : Composition of many MassAssessmentItems
                                on toItems.headerId = ID;
        toRecipients      : Composition of many NotificationRecipients
                                on toRecipients.assessmentId = ID;
    }

    entity MassAssessmentItems : cuid, managed {
        headerId                            : UUID;
        status                              : types.status;

        @Core.Computed: false
        virtual approbalStatus              : types.status;
        communicationStatus                 : types.communicationStatus;     
        virtualAssessment                   : types.virtualAssessment;           
        product                             : types.product;
        productType                         : types.productType;
        submitter                           : types.submitter;
        assessor                            : types.assessor;
        approver                            : types.approver;
        approvalDate                        : types.approvalDate;
        sbu                                 : types.sbu;
        comment                             : types.comment;
        rcPreFlag                           : types.rcPreFlag;
        rcPreFlagDescription                : types.rcPreFlagDescription;
        sustClass                           : types.sustClass;
        category1                           : types.category;
        contributor1                        : types.contributor;
        category2                           : types.category;
        contributor2                        : types.contributor;
        category3                           : types.category;
        contributor3                        : types.contributor;
        propagation                         : Boolean;
        externalCommunication               : Boolean;
        approberComment                     : String(255);
        idhAssessmentOverwrite              : Boolean;

        @Core.Computed: false
        virtual productName                 : String;

        @Core.Computed: false
        virtual technologyL2Key             : String;

        @Core.Computed: false
        virtual technologyLevel2            : String;

        @Core.Computed: false
        virtual sustainabilityClassCode     : String;

        @Core.Computed: false
        virtual existingSustainabilityClass : String;

        @Core.Computed: false
        virtual realSubstanceCode           : String(18);

        @Core.Computed: false
        virtual realSubstanceName           : String(40);

        @Core.Computed: false
        virtual region                      : String(3);

        @Core.Computed: false
        virtual applicationLevel2Key        : String(10);

        @Core.Computed: false
        virtual applicationLevel2           : String;

        @Core.Computed: false
        virtual lastAssessment              : String;

        @Core.Computed: false
        virtual lastSubmitter               : String;

        @Core.Computed: false
        virtual lastApprover                : String;
        toProofDocuments                    : Composition of many AssessmentProofDocument
                                                  on toProofDocuments.requestId = ID;

        toStatus                            : Association to one Status
                                                  on toStatus.code = status;

        toAdditionalData                    : Composition of AssessmentAdditionalData; 
    };

    /** Additional data specific to certain assessment types */
    entity AssessmentAdditionalData: cuid, managed {
        heart: Composition of HeartAdditionalData;
        pdp: Composition of PdpAdditionalData;
        moc: Composition of MocAdditionalData;
    };

    /** HEART assessment specific data */
    entity HeartAdditionalData: cuid, managed {
        last: types.HeartClassificationData;
        new: types.HeartClassificationData;
    };

    /** PDP assessment specific data */
    entity PdpAdditionalData : cuid, managed {
        assessor               : types.assessor;
        submitter             : types.submitter;
        sustainabiltiy        : String;
        projectManager        : String;
        launchGateMeetingDate : Timestamp;
        sustainabilityClass   : Association to one SustainabilityClass;
        category1             : Association to one SustainabilityCategory;
        contributor1          : Association to one Contributor;
        category2             : Association to one SustainabilityCategory;
        contributor2          : Association to one Contributor;
        category3             : Association to one SustainabilityCategory;
        contributor3          : Association to one Contributor;
    };

    /** MOC assessment specific data */
    entity MocAdditionalData : cuid, managed {
        assessor              : types.assessor;
        submitter             : types.submitter;
        sustainabiltiy        : String;
        projectManager        : String;
        launchGateMeetingDate : Date;
        sustainabilityClass   : Association to one SustainabilityClass;
        category1             : Association to one SustainabilityCategory;
        contributor1          : String(255);

    };
    
    view MassAssessmentProducts as 
        select from MassAssessmentHeader
        {
            key ID, 
            key toItems.ID as itemID,
                requestName,
                status as headerStatus,
                toItems.product as product,
                toItems.status as status,
                toItems.assessor as assessor,
                toItems.submitter as submitter,
                toItems.approver as approver,
                toItems.communicationStatus as communicationStatus
        }

    view AssessmentProducts as 
        select from MassAssessmentProducts
        {
            key ID, 
            key itemID,
                requestName,
                headerStatus,
                product,
                status,
                assessor,
                submitter,
                approver,
                communicationStatus
        }        
        union all
        select from SingleAssessment 
        {
            key ID, 
            key '' as itemID,
                requestName,
                '' as headerStatus: types.status,
                product,
                status,
                assessor,
                submitter,
                approver,
                communicationStatus           
        }    

    entity AssessmentProofDocument : cuid, managed {
        requestId        : UUID;
        objectStoreId    : UUID;
        type             : String(2);
        description      : String;
        internalPath     : String;
        fileName         : String;

        @Core.MediaType  : mediaType
        content          : LargeBinary;

        @Core.IsMediaType: true
        mediaType        : String;
        url              : String;
        active           : Boolean;
        imageMasterID    : String;
        externalUrl      : Boolean;
        productReference : types.product;
    }

    entity ProductProofDocument : managed {
        key product           : types.product;
        key proofPointId      : UUID;
            productType       : types.productType;
            type              : String(2);
            description       : String;
            fileName          : String;
            active            : Boolean;

            @Core.MediaType  : mediaType
            @Core.Computed   : false
            virtual content   : LargeBinary;

            @Core.IsMediaType: true
            @Core.Computed   : false
            virtual mediaType : String;

            @Core.Computed   : false
            virtual url       : String;
    }

    entity ProductProofDocumentRelation : managed {
        key product           : types.product;
        key proofPointId      : UUID;
            productType       : types.productType;
            type              : String(2);
            description       : String;
            fileName          : String;
            active            : Boolean;

            @Core.MediaType  : mediaType
            @Core.Computed   : false
            virtual content   : LargeBinary;

            @Core.IsMediaType: true
            @Core.Computed   : false
            virtual mediaType : String;

            url               : String;
            externalUrl       : Boolean;
    }

    entity Sbu {
        key sbu            : String(3);
            sbuDescription : String;
    }

    entity AssessmentChangeLog {
        key assessmentID : UUID;
        key entity       : String(50);
        key createdAt    : Timestamp;
        key createdBy    : User;
        key fieldName    : String(100);
            operation    : String(10);
            oldValue     : String;
            newValue     : String;
    }

    entity CommunicationErrorLog : cuid, managed {
        assessmentID : UUID;
        product : types.product;
        system: String(20);
        payload: String;
        error : LargeString;
    }

    entity Status {
        key code        : String(2);
            description : String;
    }

    entity SustainabilityClass {
        key code        : types.sustClass;
            description : String(50);
            level: Integer;
    }

    entity RcPreFlag {
        key code        : types.sustClass;
            description : String(50);
    }

    entity SustainabilityCategory {
        key code        : types.category;
            description : String(60);
    }

    entity Contributor {
        key code         : types.contributor;
            description  : String;
            categoryCode : types.category;
    }

    entity ProofType {
        key code        : String(2);
            description : String;
            onPremiseCode: String(2);
    }

    entity AssessmentType {
        key code        : String(1);
            description : String;
    }

    entity ProductType {
        key type : String(15)
    }

    entity NotificationRecipients : managed {
        key assessmentId    : UUID;
        key recipientEmail  : types.email;
        key assessmentStatus : types.status;
    }    

}

/** Context for background processes */
context background {


    entity PdpHeaderData {
            ADP_PROJ_NUM                                 : String(255); // ← ONLY key
            IB_PROD_NUM                                  : String(255); // ← NOT a key anymore
            IDH_NUMBER                                   : String(255);
            SBU                                          : String(255);
            ASSESSMENT_EXPLAINATION                      : String(255);
            SUSTAINABILITY_CLASS                         : String(255);
            SUSTAINABILITY_CLASS_KEY                     : String(2);
            SUSTAINABILITY_CATEGORY_1                    : String(255);
            SUSTAINABILITY_CATEGORY_KEY                  : String(10);
            SUSTAINABILITY_CONTRIBUTOR_1                 : String(255);
            SUSTAINABILITY_CONTRIBUTOR_KEY               : String(10);
            SUBMITTER                                    : String(255);
            ASSESSOR                                     : String(255);
            SUSTAINABILITY                               : String(255);
            PROJECT_MANAGER                              : String(255);
            FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE : Date;
            lastSyncedAt                                 : Timestamp;

            // Audit fields
            createdAt                                    : Timestamp;
            createdBy                                    : String(100);
            modifiedAt                                   : Timestamp;
            modifiedBy                                   : String(100);
    }

    entity MocHeaderData {
            ADP_PROJECT_NUMBER                                 : String(255); 
            IB_PROD_NUM                                        : String(255); 
            IDH_NUMBER                                         : String(255);
            SBU                                                : String(255);
            PROJECTED_SUSTAINABILITY_CLASS                     : String(255);
            PROJECTED_SUSTAINABILITY_CLASS_KEY                 : String(2);
            IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFIT    : String(255);
            IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY : String(2);
            HOW_IS_THE_BENEFIT_GENERATED                       : String(255);
            HOW_IS_THE_BENEFIT_GENERATED_KEY                   : String(2);
            WHICH_TIER_1_2_CHEMICALS_EXCEED_THE_THRESHOLDS     : String(255);
            ASSESSOR_SUBMITTER                                 : String(255);
            SUSTAINABILITY                                     : String(255);
            PROJECT_MANAGER                                    : String(255);
            FINAL_GATEKEEPER_MOC_EXECUTE_GATE_MEETING_DATE     : Date;
            lastSyncedAt                                       : Timestamp;

            // Audit fields
            createdAt                                          : Timestamp;
            createdBy                                          : String(100);
            modifiedAt                                         : Timestamp;
            modifiedBy                                         : String(100);
    }

    entity PdpProofPointsData {
            ADP_PROJECT_NUMBER          : String(255);
            TYPE_OF_PROOF_POINT_KEY     : String(100);
            TYPE_OF_PROOF_POINT         : String(255);
            TYPE_OF_PROOF_POINT_COMMENT : String(255);
            PROOF_POINT_DOC_NAME        : String(255);
            PROOF_POINT_URL_LINK        : String(1000);
            lastSyncedAt                : Timestamp;

            // Audit fields
            createdAt                   : Timestamp;
            createdBy                   : String(100);
            modifiedAt                  : Timestamp;
            modifiedBy                  : String(100);
    }

    entity DataSyncLog {
        key syncId       : UUID;
            tableName    : String(100);
            startTime    : Timestamp;
            endTime      : Timestamp;
            recordCount  : Integer;
            status       : String(20); // SUCCESS, FAILED, PARTIAL
            errorMessage : String(5000);
    }

   /** PDP projects assessment creation processing table */
    entity PdpProcessedProjects : cuid, managed {
        sbu                   : types.sbu;
        projectId             : String;
        product               : types.product;
        productType           : types.productType;
        status                : types.pdpProcessingStatus;
        assessmentExplanation : types.comment;
        rcPreFlag             : types.rcPreFlag;
        sustClass             : types.sustClass;
        category1             : types.category;
        contributor1          : types.contributor;
        category2             : types.category;
        contributor2          : types.contributor;
        category3             : types.category;
        contributor3          : types.contributor;
        submitter             : types.submitter;
        assessor              : types.assessor;
        sustainability        : types.sustainability;
        projectManager        : types.projectManager;
        finalDate             : Timestamp;
        proofPoints           : Association to many PdpProjectProofPoints
                                    on proofPoints.projectId = projectId;
    };

    /** PDP project proof points */
    entity PdpProjectProofPoints: cuid {
        projectId : String;
        type: String(2);
        description: String;
        fileName: String;
        url: String;

    };

    /** PDP project processing blocks */
    view PdpProjectGroupingsToProcess as 
        select from PdpProcessedProjects {
            sbu,
            projectId,
            productType,
            status,
            min( createdAt ) as createdAt,
        } 
        where status = '01'
           or status = '02'
        group by sbu, projectId, status, productType;

    /** PDP products first incoming product, to respect FIFO */
    view PdpProjectProductsPendingFirst as 
        select from PdpProcessedProjects {
            product,
            min( createdAt ) as createdAt,
        } 
        where status = '01'
           or status = '02'
        group by product;

    /** PDP products ready to process */
    view PdpProductsReadyToProcess as 
        select from PdpProcessedProjects as main
        inner join PdpProjectProductsPendingFirst as next
        on main.product = next.product
        and main.createdAt = next.createdAt
        {
            main.sbu,
            main.projectId,
            main.product,
            main.productType,
            main.assessor,
            main.submitter,
            main.status,
            main.createdAt,
        } 
        where status = '01'
           or status = '02';

    /** Job Execution log */
    entity AdpJobExecutionLogs: cuid, managed {
        type: String(10) enum {
            PDP;
            PDP_DELTA;
            MOC;
            MOC_DELTA;
        };
        status: types.pdpProcessingStatus;
    };

    /** Tracking of ADP not linked projects and their processing */
    entity NotLinkedAdpProjectsLog: managed {
        key projectId: String;
        key type: types.assessmentProcessType;
    };

    /** Missmatched Job Execution log */
    entity MismatchedAssessmentJobExecutionLogs : cuid, managed {
        type : String(25) enum {
            SUSTAINABILITY_SCREEN;
            MISMATCH_CREATE;
        };
        status:types.MismatchedAssessmentStatus;
    }

    /** MOC projects assessment creation processing table */
    entity MocProcessedProjects : cuid, managed {
        projectId             : String;
        sbu                   : types.sbu;
        product               : types.product;
        productType           : types.productType;
        status                : types.pdpProcessingStatus;
        assessmentExplanation : types.comment;
        rcPreFlag             : types.rcPreFlag;
        sustClass             : types.sustClass;
        category1             : types.category;
        contributor1          : String;
        assessor              : types.assessor;
        sustainability        : types.sustainability;
        projectManager        : types.projectManager;
        finalDate             : Date;
    };


    /** Log table for assessments where RC Pre-flag and Sustainability Class do not match */
    entity RcPreflagSustclassMismatchedAssessmentLog : cuid, managed {
        product             : types.product;
        sbu                 : types.sbu;
        rcPreFlag           : types.rcPreFlag;
        sustClass           : types.sustClass;
        status              : types.MismatchedAssessmentStatus;
        createdAssessmentId : UUID;
        message             : String;
    }
 
    /** Mapping table to define valid combinations of RC Pre-flag and Sustainability Class */
    entity RCPreFlagToSustClassMismatchMapping {
        key rcPreFlag : types.rcPreFlag;
        key sustClass : types.sustClass;
    }

    /** Translations table for contributors RC Pre-flag and Sustainability Class */
    entity MocContributorTranslations {
        key mocContributor : String;
        pstContributor: Association to management.Contributor;
        assessmentExplanation: String;
    }

    /** MOC project processing blocks */
    view MocProjectGroupingsToProcess as
        select from MocProcessedProjects {
            sbu,
            projectId,
            productType,
            status,
            min(createdAt) as createdAt,
        }
        where
               status = '01'
            or status = '02'
        group by
            sbu,
            projectId,
            status,
            productType;

    /** MOC products first incoming product, to respect FIFO */
    view MocProjectProductsPendingFirst as
        select from MocProcessedProjects {
            product,
            min(createdAt) as createdAt,
        }
        where
               status = '01'
            or status = '02'
        group by
            product;

    /** MOC products ready to process */
    view MocProductsReadyToProcess as
        select from MocProcessedProjects as main
        inner join MocProjectProductsPendingFirst as next
            on  main.product   = next.product
            and main.createdAt = next.createdAt
        {
            main.sbu,
            main.projectId,
            main.product,
            main.productType,
            main.assessor,
            main.status,
            main.createdAt,
        }
        where
               status = '01'
            or status = '02';

    /** RCPC Job Execution log */
    entity RcPositiveContributionJobExecutionLogs : cuid, managed {
        type: String(12) enum {
            RCPC;
            RCPC_DELTA;
        };
        status: types.pdpProcessingStatus;
    };

    /** RCPC assessment creation processing table */
    entity RcPositiveContributionExecution : cuid, managed {
        material         : types.product;
        sustClass        : types.sustClass;
        assessmentId     : UUID;
        assessmentStatus : types.status;
        status           : types.pdpProcessingStatus;
        runId            : String;
        updateType       : String(40);
    };

    /** Previous RC PC run for each RC PC material run */
    view RcPcPreviousRunIds as
        select from RcPositiveContributionExecution as source
        inner join RcPositiveContributionExecution as target
        on source.material = target.material
        {
            source.ID,
            source.material,
            source.runId,
            max(target.runId) as previousRun 
        }
        where target.runId < source.runId
        group by source.ID, source.material, source.runId;

    /** Previous RC PC run data for each RC PC material run */
    view RcPcPreviousRunData as 
        select from RcPositiveContributionExecution as actual
        inner join RcPcPreviousRunIds as previousId
        on actual.ID = previousId.ID
        inner join RcPositiveContributionExecution as previous
        on  previousId.material = previous.material
        and previousId.previousRun = previous.runId
        {
            actual.ID,
            actual.material,
            actual.runId,
            previousId.previousRun as previousRunId,
            previous.sustClass as previousClass,
            previous.updateType as previousUpdateType,
            previous.assessmentId as previousAssessment,
            previous.assessmentStatus as previousAssessmentStatus
        }

    /** RCPC data to read on execution  */
    view RcPcExecutionAndLastAssessment as 
        select from RcPositiveContributionExecution as rcpc
        inner join IdhUpdated as idh
        on idh.materialtNumber = rcpc.material
        left join RcPcPreviousRunData as previousRun
        on rcpc.ID = previousRun.ID
        {
            rcpc.*,
            previousRun.previousClass as previousRcPcClass,
            idh.sbu,
            idh.rcPreFlag,
            idh.sustClass as existingSustClass,
            idh.category as category1,
            idh.category2,
            idh.category3,
            idh.contributor as contributor1,
            idh.contributor2,
            idh.contributor3,
        }
        where rcpc.status != '03';    

    /** RCPC products first incoming product, to respect FIFO */
    view RcPositiveContributionExecutionPendingFirst as
        select from RcPositiveContributionExecution {
            material,
            runId,
            min(createdAt) as createdAt,
        }
        where 
            status = '01'   // PENDING
            or status = '02'   // RETRIAL
        group by 
            material,
            runId;
            
    /** RCPC products ready to process */
    view RcPositiveContributionExecutionsReadyToProcess as
        select from RcPcExecutionAndLastAssessment as executions
        inner join RcPositiveContributionExecutionPendingFirst as fifo
            on executions.material = fifo.material
            and executions.runId = fifo.runId
        {
            executions.sbu,
            executions.material,
            executions.runId,
            executions.sustClass,
            executions.rcPreFlag,
            executions.category1,
            executions.contributor1,
            executions.category2,
            executions.contributor2,
            executions.category3,
            executions.contributor3,
            executions.status,
            executions.updateType,
            executions.assessmentId,
            executions.assessmentStatus,
            executions.createdAt,
        }
        where 
            (  
                executions.status = '01'    // PENDING
                or executions.status = '02'   // RETRIAL
            )
            and executions.sbu is not null
            and executions.sbu != '';

    /** RCPC processing blocks */
    view RcPositiveContributionGroupingsToProcess as
        select from RcPcExecutionAndLastAssessment {
            sbu,
            runId,
            status,
            count(*) as itemCount,
            min(createdAt) as createdAt,
        }
        where 
            status = '01'  
            or status = '02'  
        group by 
            sbu,
            runId,
            status
        order by 
            runId;


    /** Job Execution log */
    entity HeartJobExecutionLogs: cuid, managed {
        type: String(12) enum {
            HEART;
            HEART_DELTA;
        };
        status: types.pdpProcessingStatus;
    };

   /** PDP projects assessment creation processing table */
    entity HeartExecution : cuid, managed {
        sbu                           : types.sbu;
        realSubstanceKey              : String;
        material                      : types.product;
        sustClass                     : types.sustClass;
        category1                     : types.category;
        contributor1                  : types.contributor;
        category2                     : types.category;
        contributor2                  : types.contributor;
        category3                     : types.category;
        contributor3                  : types.contributor;
        oldRsnSbuCode                 : String;
        oldProductLineL3              : String;
        oldTechnologyL1               : String;
        oldTechnologyL3               : String;
        oldApplicationL1              : String;
        oldApplicationL2              : String;
        oldApplicationL3              : String;
        oldProductHierarchyL3         : String;
        oldPcfClusterAttributes       : String;
        oldPcfClusterAttributesValues : String;
        oldPcfClusterSize             : String;
        oldPcfClusterBenchmark        : Double;
        oldPcfExcl                    : Double;
        oldPcfDeltaRel                : Double;
        oldPcfSustClass               : types.sustClass;    
        newProductLineL3              : String;
        newTechnologyL1               : String;
        newTechnologyL3               : String;
        newApplicationL1              : String;
        newApplicationL2              : String;
        newApplicationL3              : String;
        newProductHierarchyL3         : String;
        newPcfClusterAttributes       : String;
        newPcfClusterAttributesValues : String;
        newPcfClusterSize             : String;
        newPcfClusterBenchmark        : Double;
        newPcfExcl                    : Double;
        newPcfDeltaRel                : Double;
        newRsnSbuCode                 : String;        
        productType                   : types.productType;
        rcPreFlag                     : types.rcPreFlag;
        pcfHeartSustainabilityClass   : types.sustClass;
        pcfCategory                   : types.category;
        pcfContributor                : types.contributor;
        assessmentId                  : UUID;
        assessmentStatus              : types.status;
        status                        : types.pdpProcessingStatus;
        heartRunId                    : String;
        updateType                    : String(40);
    };

    view HeartLastProductRunDate as 
        select from HeartExecution
            {
                material,
                max(createdAt) as createdAt,
            }
            group by material;

    view HeartLatestProductExecution as 
        select from HeartExecution as execution 
        inner join HeartLastProductRunDate as lastRun
        on execution.material = lastRun.material
        and execution.createdAt = lastRun.createdAt
        {
            execution.*                
        };    


    /** Heart processing blocks */
    view HeartGroupingsToProcess as 
        select from HeartExecution distinct {
            sbu,
            status,
            heartRunId,
        } 
        where status = '01'
           or status = '02'
        order by heartRunId;

    /** HEART products first incoming product, to respect FIFO */
    view HeartExecutionPendingFirst as 
        select from HeartExecution {
            material,
            min( heartRunId ) as heartRunId,
        } 
        where status = '01'
           or status = '02'
        group by material;

    /** PDP products ready to process */
    view HeartExecutionsReadyToProcess as 
        select from HeartExecution as executions
        inner join HeartExecutionPendingFirst as fifo
            on executions.material = fifo.material
            and executions.heartRunId = fifo.heartRunId
        {
            executions.sbu,
            executions.realSubstanceKey,
            executions.material,
            executions.oldProductLineL3,
            executions.oldTechnologyL1,
            executions.oldTechnologyL3,
            executions.oldApplicationL1,
            executions.oldApplicationL2,
            executions.oldApplicationL3,
            executions.oldProductHierarchyL3,
            executions.oldPcfClusterAttributes,
            executions.oldPcfClusterAttributesValues,
            executions.oldPcfClusterSize,
            executions.oldPcfExcl,
            executions.oldPcfDeltaRel,
            executions.newProductLineL3,
            executions.newTechnologyL1,
            executions.newTechnologyL3,
            executions.newApplicationL1,
            executions.newApplicationL2,
            executions.newApplicationL3,
            executions.newProductHierarchyL3,
            executions.newPcfClusterAttributes,
            executions.newPcfClusterAttributesValues,
            executions.newPcfClusterSize,
            executions.newPcfExcl,
            executions.newPcfDeltaRel,  
            executions.newPcfClusterBenchmark,  
            executions.productType,
            executions.rcPreFlag,
            executions.pcfHeartSustainabilityClass,
            executions.pcfCategory,
            executions.pcfContributor,
            executions.assessmentId,
            executions.assessmentStatus,
            executions.status,
            executions.heartRunId,
            executions.updateType,
        } 
        where status = '01'
           or status = '02';

    view mocDeltaRead as
        select from MocHeaderData as source
        left join MocProcessedProjects as target
            on          source.ADP_PROJECT_NUMBER =  target.projectId
            and (
                        source.IDH_NUMBER         =  target.product
                or (
                        source.IDH_NUMBER         is null
                    and target.product            is null
                )
            )
        left join NotLinkedAdpProjectsLog as notLinked
            on source.ADP_PROJECT_NUMBER = notLinked.projectId
            and notLinked.type = 'MOC'           
        left join VT_V_IDH as idh
            on source.IDH_NUMBER = idh.IDH_MATERIAL_NR
        {
            source.SBU                                                as sbu,
            ADP_PROJECT_NUMBER                                        as projectId,
            case
                when IDH_NUMBER is not null
                     then IDH_NUMBER
                else ''
            end                                                       as product,
            case
                when IDH_NUMBER is not null
                     then 'IDH'
                else null
            end                                                       as productType,
            case
                when IDH_NUMBER is not null
                     then idh.RC_SUSTAINABILITYCLASSKEY
                else null
            end                                                       as rcPreFlag,
            source.PROJECTED_SUSTAINABILITY_CLASS_KEY                 as sustClass,
            source.IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY as category1,
            source.HOW_IS_THE_BENEFIT_GENERATED                       as contributor1,
            source.WHICH_TIER_1_2_CHEMICALS_EXCEED_THE_THRESHOLDS     as assessmentExplanation,
            source.ASSESSOR_SUBMITTER                                 as assessor,
            source.SUSTAINABILITY                                     as sustainability,
            source.PROJECT_MANAGER                                    as projectManager,
            source.FINAL_GATEKEEPER_MOC_EXECUTE_GATE_MEETING_DATE     as finalDate,
            case
                when notLinked.projectId is null then '01'
                else '02'
            end as status,
        }
        where
                   target.projectId                                                  is null
            and    LENGTH(source.SBU)                                                <  4
            and (                                                                   // Keep ADP not linked but filter non-existing IDHs
                    source.IDH_NUMBER is null                                       // ADP not linked
                or (                                                                // IDH is valid
                    source.IDH_NUMBER is not null and                               
                    idh.IDH_MATERIAL_NR is not null   
                )
            )            
            and (
                   LENGTH(source.IDH_NUMBER)                                         <= 18
                or source.IDH_NUMBER                                                 is null
                )
            and (
                   LENGTH(idh.RC_SUSTAINABILITYCLASSKEY)                             <= 2
                or idh.RC_SUSTAINABILITYCLASSKEY                                     is null
                )
            and (
                   LENGTH(source.PROJECTED_SUSTAINABILITY_CLASS_KEY)                 <= 2
                or source.PROJECTED_SUSTAINABILITY_CLASS_KEY                         is null
                )
            and (
                   LENGTH(source.IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY) <= 2
                or source.IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY         is null
                )
            and (
                   LENGTH(source.HOW_IS_THE_BENEFIT_GENERATED_KEY)                   <= 2
                or source.HOW_IS_THE_BENEFIT_GENERATED_KEY                           is null
            );

    view PdpDeltaRead as
        select from PdpHeaderData as source
        left join PdpProcessedProjects as target
            on          source.ADP_PROJ_NUM =  target.projectId
            and (
                        source.IDH_NUMBER   =  target.product
                or (
                        source.IDH_NUMBER   is null
                    and target.product      is null
                )
            )
        left join NotLinkedAdpProjectsLog as notLinked
            on source.ADP_PROJ_NUM = notLinked.projectId
            and notLinked.type = 'PDP' 
        left join VT_V_IDH as idh
            on source.IDH_NUMBER = idh.IDH_MATERIAL_NR
        {
            source.SBU                                          as sbu,
            ADP_PROJ_NUM                                        as projectId,
            case
                when IDH_NUMBER is not null
                     then IDH_NUMBER
                else ''
            end                                                 as product,
            case
                when IDH_NUMBER is not null
                     then 'IDH'
                else null
            end                                                 as productType,
            case
                when IDH_NUMBER is not null
                     then idh.RC_SUSTAINABILITYCLASSKEY
                else null
            end                                                 as rcPreFlag,
            source.SUSTAINABILITY_CLASS_KEY                     as sustClass,
            source.SUSTAINABILITY_CATEGORY_KEY                  as category1,
            source.SUSTAINABILITY_CONTRIBUTOR_KEY               as contributor1,
            source.ASSESSMENT_EXPLAINATION                      as assessmentExplanation,
            source.ASSESSOR                                     as assessor,
            source.SUBMITTER                                    as submitter,
            source.SUSTAINABILITY                               as sustainability,
            source.PROJECT_MANAGER                              as projectManager,
            source.FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE as finalDate,
            case
                when notLinked.projectId is null then '01'
                else '02'
            end as status,
        }
        where
                   target.projectId                              is null
            and    LENGTH(source.SBU)                            <  4
            and (                                                                   // Keep ADP not linked but filter non-existing IDHs
                    source.IDH_NUMBER is null                                       // ADP not linked
                or (                                                                // IDH is valid
                    source.IDH_NUMBER is not null and                               
                    idh.IDH_MATERIAL_NR is not null   
                )
            )
            and (
                   LENGTH(source.IDH_NUMBER)                     <= 18
                or source.IDH_NUMBER                             is null
            )
            and (
                   LENGTH(idh.RC_SUSTAINABILITYCLASSKEY)         <= 2
                or idh.RC_SUSTAINABILITYCLASSKEY                 is null
            )
            and (
                   LENGTH(source.SUSTAINABILITY_CLASS_KEY)       <= 2
                or source.SUSTAINABILITY_CLASS_KEY               is null
            )
            and (
                   LENGTH(source.SUSTAINABILITY_CATEGORY_KEY)    <= 2
                or source.SUSTAINABILITY_CATEGORY_KEY            is null
            )
            and (
                   LENGTH(source.SUSTAINABILITY_CONTRIBUTOR_KEY) <= 2
                or source.SUSTAINABILITY_CONTRIBUTOR_KEY         is null
            );

    entity jobOrchestratorLogs: cuid, managed {
        type: String(12) enum {
            ADP;
            HEART;
            RCM;
            RCPC;
        };
        status: types.pdpProcessingStatus;
    };

    view AllLastJobExecution as
        select from AdpJobExecutionLogs {
            'ADP' as process: String,
            type: String,
            status,
            max(createdAt) as createdAt,
        }
        group by type, status
        union all
        select from RcPositiveContributionJobExecutionLogs {
            'RCPC' as process: String,
            type: String,
            status,
            max(createdAt) as createdAt,
        }
        group by type, status
        union all
        select from HeartJobExecutionLogs {
            'HEART' as process: String,
            type: String,
            status,
            max(createdAt) as createdAt,
        }
        group by type, status
        union all 
        select from MismatchedAssessmentJobExecutionLogs {
            'RCM' as process: String,
            type: String,
            status,
            max(createdAt) as createdAt,
        }
        group by type, status
        union all
        select from jobOrchestratorLogs {
            'ORCHESTRATOR' as process: String,
            type: String,
            status,
            max(createdAt) as createdAt,
        }
        group by type, status;        
}

// Support application entities context
context support {
    entity SupportSectionForm {
        key id        : String(20);
            label1    : String;
            linkName1 : String;
            link1     : String;
            label2    : String;
            linkName2 : String;
            link2     : String;
            label3    : String;
            linkName3 : String;
            link3     : String;
    }
}

/*@cds.persistence.exists
entity COM_SUSTAINABILITY_VT_V_IBProduct_ATTR {

}

@cds.persistence.exists
entity COM_SUSTAINABILITY_VT_V_IDH_ATTR {

}*/

entity VT_V_IDH {
    key IDH_MATERIAL_NR                : String(255);
        PRODUCT_NAME_MAT_DSC           : String(255);
        ASSESOR                        : String(255);
        APPROVER                       : String(255);
        ASSESSED_ON                    : String(255);
        TECHNOLOGY_LEVEL2_KEY          : String(255);
        TECHNOLOGY_LEVEL2_DESC         : String(255);
        APPLICATION_LEVEL_KEY          : String(255);
        APPLICATION_LEVEL2_DESC        : String(255);
        SUSTAINABILITY_CLASS_KEY       : String(255);
        SUSTAINABILITY_CLASS_DESC      : String(255);
        PRIMARY_SUSTAINABILITY_CATEG   : String(255);
        PRIMARY_SUSTAINABIL_CATEG_DESC : String(255);
        SEC_SUSTAINABILITY_CATEG_A_KEY : String(255);
        SEC_SUSTAINABILITY_CATG_A_DESC : String(255);
        SEC_SUSTAINABILITY_CATEG_B_KEY : String(255);
        SEC_SUSTAINABILITY_CATG_B_DESC : String(255);
        PRIMARY_CONTRIBUTOR_KEY        : String(255);
        PRIMARY_CONTRIBUTOR_DESC       : String(255);
        SECONDARY_CONTRIBUTOR_A_KEY    : String(255);
        SECONDARY_CONTRIBUTOR_A_DESC   : String(255);
        SECONDARY_CONTRIBUTOR_B_KEY    : String(255);
        SECONDARY_CONTRIBUTOR_B_DESC   : String(255);
        SUSTAINBILITY_MAINTMANUAL_DESC : String(255);
        LEADINGSBUCODE                 : String(255);
        RSN_REAL_SUBSTANCE_NUMBER      : String(255);
        RC_SUSTAINABILITYFLAG          : String(255);
        RC_SUSTAINABILITYCLASSKEY      : String(255);
}

@cds.persistence.journal
entity VT_V_IB_IDH {
    key MATERIAL_KEY   : String(255);
        AI_PRODUCT_KEY : String(255);
}

entity VT_V_IBPRODUCT {
    key IB_PRODUCT_NUMBER              : String(255);
        PRODUCT_NAME                   : String(255);
        ASSESOR                        : String(255);
        APPROVER                       : String(255);
        LAST_ASSESTMENTAPPROVAL_DATE   : String(255);
        TECHNOLOGY_LEVEL_2             : String(255);
        TECHNOLOGY_LEVEL_2_DESC        : String(255);
        SUST_CLASS_KEY                 : String(255);
        SUST_CLASS_DESC                : String(255);
        PRIM_SUSTAINABILITY_CATEG_KEY  : String(255);
        PRIM_SUSTAINABILITY_CATEG_DESC : String(255);
        SEC_SUSTAINABILITY_CAT_A_KEY   : String(255);
        SEC_SUSTAINABILITY_CAT_A_DESC  : String(255);
        SEC_SUSTAINABILITY_CAT_B_KEY   : String(255);
        SEC_SUSTAINABILITY_CAT_B_DESC  : String(255);
        PRIMARY_CONTRIBUTOR_KEY        : String(255);
        PRIMARY_CONTRIBUTOR_DESC       : String(255);
        SECONDARY_CONTRIBUTOR_A_KEY    : String(255);
        SECONDARY_CONTRIBUTOR_A_DESC   : String(255);
        SECONDARY_CONTRIBUTOR_B_KEY    : String(255);
        SECONDARY_CONTRIBUTOR_B_DESC   : String(255);
        APPLICATION_LEVEL2_KEY         : String(255);
        LEADING_SBU_CODE_DESC          : String(255);
        APPLICATION_LEVEL2_DSC         : String(255);
        RC_SUSTAINABILITYFLAG          : String(255);
        RC_SUSTAINABILITYCLASSKEY      : String(255);
        REAL_SUBSTANCE_NUMBER          : String(255);
}

view ProductsByAssessment as 
    select from management.SingleAssessment 
    {
        key ID,
        key product,
        'SINGLE' AS assessmentType: String(10),
        null AS headerId: UUID,
        createdAt,
        createdBy,
        modifiedAt,
        modifiedBy,
        requestName,
        status,                           
        communicationStatus,               
        productType,
        approvalDate,
        category1,
        contributor1,
        category2,
        contributor2,
        category3,
        contributor3,
        sustClass,
        assessor as assesor,
        approver,
        submitter,
        sbu,
        comment,
        rcPreFlag,
        rcPreFlagDescription,
        propagation,
        externalCommunication,
        idhAssessmentOverwrite,
        approberComment,
        toProofDocuments,
    }
    union all
    select from management.MassAssessmentHeader as header
    inner join management.MassAssessmentItems as item
    on header.ID = item.headerId
    {
        key item.ID,
        key item.product,
        'MASS' AS assessmentType: String(10),
        headerId,
        item.createdAt,
        item.createdBy,
        item.modifiedAt,
        item.modifiedBy,
        header.requestName,
        item.status,                      
        item.communicationStatus,                     
        item.productType,
        item.approvalDate,
        item.category1,
        item.contributor1,
        item.category2,
        item.contributor2,
        item.category3,
        item.contributor3,
        item.sustClass,
        item.assessor  as assesor,
        item.approver,
        item.submitter,
        item.sbu,
        item.comment,
        item.rcPreFlag,
        item.rcPreFlagDescription,
        item.propagation,
        item.externalCommunication,
        item.idhAssessmentOverwrite,
        item.approberComment,
        item.toProofDocuments,
    };



/**
 *  Fist, create get all approved assessments by product
 */
view ProductsByApprovedAssessment as 
    select from management.SingleAssessment 
    {
        key ID,
        key product,
        'SINGLE' AS assessmentType: String(10),
        createdAt,
        createdBy,
        modifiedAt,
        modifiedBy,
        productType,
        approvalDate,
        category1,
        contributor1,
        category2,
        contributor2,
        category3,
        contributor3,
        sustClass,
        assessor as assesor,
        approver,
        submitter,
        sbu,
        comment,
        rcPreFlag,
        rcPreFlagDescription,
        propagation,
        externalCommunication,
        approberComment,
        toProofDocuments,
    }
    where status = '05'
        and ( communicationStatus = '05' or communicationStatus is null )
        and ( virtualAssessment = false or virtualAssessment is null)
    union all
    select from management.MassAssessmentItems
    {
        key ID,
        key product,
        'MASS' AS assessmentType: String(10),
        createdAt,
        createdBy,
        modifiedAt,
        modifiedBy,
        productType,
        approvalDate,
        category1,
        contributor1,
        category2,
        contributor2,
        category3,
        contributor3,
        sustClass,
        assessor  as assesor,
        approver,
        submitter,
        sbu,
        comment,
        rcPreFlag,
        rcPreFlagDescription,
        propagation,
        externalCommunication,
        approberComment,
        toProofDocuments,
    }
    where status = '05'
        and ( communicationStatus = '05' or communicationStatus is null )
        and ( virtualAssessment = false or virtualAssessment is null);

/**
 * Extract only last approval dates
 */
view ProductsLastApprovalDate as
    select from ProductsByApprovedAssessment 
    {
        key product,
        max(approvalDate) as approvalDate,
        max(modifiedAt) as modifiedAt
    }
    group by product;

/**
 * Use last approval dates to extract only last Assessment per product
 */
view ProductsByLastApprovedAssessment as 
    select from ProductsLastApprovalDate as lastAssessment
    inner join ProductsByApprovedAssessment as Assessments
        on  lastAssessment.product = Assessments.product 
        and lastAssessment.approvalDate = Assessments.approvalDate
        and lastAssessment.modifiedAt = Assessments.modifiedAt
    {
        key Assessments.product as product,
            Assessments.approvalDate as approvalDate,
            Assessments.category1 as category1,
            Assessments.contributor1 as contributor1,
            Assessments.category2 as category2,
            Assessments.contributor2 as contributor2,
            Assessments.category3 as category3,
            Assessments.contributor3 as contributor3,
            Assessments.sustClass as sustClass,
            Assessments.assesor as assesor,
            Assessments.approver as approver,
            Assessments.submitter as submitter,
            Assessments.propagation as propagation,
    };

/**
 * Map IB data to common structure with IDH
 */
view IbMapped as 
    select from VT_V_IBPRODUCT 
    {
        key IB_PRODUCT_NUMBER              as materialtNumber          : String(18),
            PRODUCT_NAME                   as materialDescription      : String(40),
            LEADING_SBU_CODE_DESC          as sbu                      : String(3),
            SUST_CLASS_KEY                 as sustClass                : String(2),
            SUST_CLASS_DESC                as sustClassDescription     : String,
            PRIM_SUSTAINABILITY_CATEG_KEY  as category                 : String(3),
            PRIM_SUSTAINABILITY_CATEG_DESC as categoryDescription      : String,
            SEC_SUSTAINABILITY_CAT_A_KEY   as category2                : String(3),
            SEC_SUSTAINABILITY_CAT_A_DESC  as category2Description     : String,
            SEC_SUSTAINABILITY_CAT_B_KEY   as category3                : String(3),
            SEC_SUSTAINABILITY_CAT_B_DESC  as category3Description     : String,
            PRIMARY_CONTRIBUTOR_KEY        as contributor              : String(3),
            PRIMARY_CONTRIBUTOR_DESC       as contributorDescription   : String,
            SECONDARY_CONTRIBUTOR_A_KEY    as contributor2             : String(3),
            SECONDARY_CONTRIBUTOR_A_DESC   as contributor2Description  : String,
            SECONDARY_CONTRIBUTOR_B_KEY    as contributor3             : String(3),
            SECONDARY_CONTRIBUTOR_B_DESC   as contributor3Description  : String,
            ASSESOR                        as assesor                  : String(50),
            APPROVER                       as approver                 : String(50),
            TECHNOLOGY_LEVEL_2             as technologyL2             : String(3),
            TECHNOLOGY_LEVEL_2_DESC        as technologyL2Description  : String,
            RC_SUSTAINABILITYCLASSKEY      as rcPreFlag                : String(2),
            RC_SUSTAINABILITYFLAG          as rcPreFlagDescription     : String,
            APPLICATION_LEVEL2_KEY         as applicationL2            : String(3),
            APPLICATION_LEVEL2_DSC         as applicationL2Description : String,
            REAL_SUBSTANCE_NUMBER          as realSubstanceCode        : String(18),
            REAL_SUBSTANCE_NUMBER          as realSubstanceName        : String(40),
            cast(LAST_ASSESTMENTAPPROVAL_DATE as Date)   as approvalDate
    };

/**
 * Map IDH data to common structure with IB
 */
view IdhMapped as 
    select from VT_V_IDH 
    {
        key IDH_MATERIAL_NR                as materialtNumber          : String(18),
            PRODUCT_NAME_MAT_DSC           as materialDescription      : String(40),
            LEADINGSBUCODE                 as sbu                      : String(3),
            SUSTAINABILITY_CLASS_KEY       as sustClass                : String(2),
            SUSTAINABILITY_CLASS_DESC      as sustClassDescription     : String,
            PRIMARY_SUSTAINABILITY_CATEG   as category                 : String(3),
            PRIMARY_SUSTAINABIL_CATEG_DESC as categoryDescription      : String,
            SEC_SUSTAINABILITY_CATEG_A_KEY as category2                : String(3),
            SEC_SUSTAINABILITY_CATG_A_DESC as category2Description     : String,
            SEC_SUSTAINABILITY_CATEG_B_KEY as category3                : String(3),
            SEC_SUSTAINABILITY_CATG_B_DESC as category3Description     : String,
            PRIMARY_CONTRIBUTOR_KEY        as contributor              : String(3),
            PRIMARY_CONTRIBUTOR_DESC       as contributorDescription   : String,
            SECONDARY_CONTRIBUTOR_A_KEY    as contributor2             : String(3),
            SECONDARY_CONTRIBUTOR_A_DESC   as contributor2Description  : String,
            SECONDARY_CONTRIBUTOR_B_KEY    as contributor3             : String(3),
            SECONDARY_CONTRIBUTOR_B_DESC   as contributor3Description  : String,
            ASSESOR                        as assesor                  : String(50),
            APPROVER                       as approver                 : String(50),
            TECHNOLOGY_LEVEL2_KEY          as technologyL2             : String(3),
            TECHNOLOGY_LEVEL2_DESC         as technologyL2Description  : String,
            RC_SUSTAINABILITYCLASSKEY      as rcPreFlag                : String(2),
            RC_SUSTAINABILITYFLAG          as rcPreFlagDescription     : String,
            APPLICATION_LEVEL_KEY          as applicationL2            : String(3),
            APPLICATION_LEVEL2_DESC        as applicationL2Description : String,
            RSN_REAL_SUBSTANCE_NUMBER      as realSubstanceCode        : String(18),
            RSN_REAL_SUBSTANCE_NUMBER      as realSubstanceName        : String(40),           
            case  
                when SUSTAINBILITY_MAINTMANUAL_DESC = 'YES' then true
                else false
            end as manualMaintenanceFlag    : Boolean, 
            cast(ASSESSED_ON as Date)      as approvalDate
    };

/**
 * IBs getting the latest data between datasphere and assessment data
 */
view IbUpdated as 
    select from IbMapped as Ib
    left join ProductsByLastApprovedAssessment as Assessment
    on Assessment.product = Ib.materialtNumber        
    {
        key Ib.materialtNumber          as materialtNumber,         
            Ib.materialDescription      as materialDescription,     
            Ib.sbu                      as sbu,
            case 
                when Assessment.approvalDate is not null then  Assessment.sustClass
                else Ib.sustClass
            end as sustClass : String(2),        
            case 
                when Assessment.approvalDate is not null then  Assessment.category1
                else Ib.category
            end as category : String(3),       
            case 
                when Assessment.approvalDate is not null then  Assessment.category2
                else Ib.category2
            end as category2 : String(3),         
            case 
                when Assessment.approvalDate is not null then  Assessment.category3
                else Ib.category3
            end as category3 : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor1
                else Ib.contributor
            end as contributor : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor2
                else Ib.contributor2
            end as contributor2 : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor3
                else Ib.contributor3
            end as contributor3 : String(3),                          
            case 
                when Assessment.approvalDate is not null then  Assessment.assesor
                else ''
            end as assesor : String(50), 
            case 
                when Assessment.approvalDate is not null then  Assessment.submitter
                else ''
            end as submitter : String(50),             
            case 
                when Assessment.approvalDate is not null then  Assessment.approver
                else ''
            end as approver : String(50),                                
            Ib.technologyL2             as technologyL2,            
            Ib.technologyL2Description  as technologyL2Description, 
            Ib.rcPreFlag                as rcPreFlag,               
            Ib.rcPreFlagDescription     as rcPreFlagDescription,   
            Ib.applicationL2            as applicationL2,           
            Ib.applicationL2Description as applicationL2Description,
            Ib.realSubstanceCode as realSubstanceCode,
            Ib.realSubstanceName as realSubstanceName,
            case 
                when Assessment.approvalDate is not null then  Assessment.approvalDate
                else '0000-00-00'
            end as approvalDate : Date,                              
    };

/**
 * IDHs getting the latest data between datasphere and assessment data
 */
view IdhUpdated as 
    select from IdhMapped as Idh
    left join ProductsByLastApprovedAssessment as Assessment
    on Assessment.product = Idh.materialtNumber        
    {
        key Idh.materialtNumber          as materialtNumber,       
            Idh.materialDescription      as materialDescription,     
            Idh.sbu                      as sbu,
            case 
                when Assessment.approvalDate is not null then  Assessment.sustClass
                else Idh.sustClass
            end as sustClass : String(2),        
            case 
                when Assessment.approvalDate is not null then  Assessment.category1
                else Idh.category
            end as category : String(3),       
            case 
                when Assessment.approvalDate is not null then  Assessment.category2
                else Idh.category2
            end as category2 : String(3),         
            case 
                when Assessment.approvalDate is not null then  Assessment.category3
                else Idh.category3
            end as category3 : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor1
                else Idh.contributor
            end as contributor : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor2
                else Idh.contributor2
            end as contributor2 : String(3),    
            case 
                when Assessment.approvalDate is not null then  Assessment.contributor3
                else Idh.contributor3
            end as contributor3 : String(3),                          
            case 
                when Assessment.approvalDate is not null then  Assessment.assesor
                else ''
            end as assesor : String(50), 
            case 
                when Assessment.approvalDate is not null then  Assessment.submitter
                else ''
            end as submitter : String(50),             
            case 
                when Assessment.approvalDate is not null then  Assessment.approver
                else ''
            end as approver : String(50),                        
            Idh.technologyL2             as technologyL2,            
            Idh.technologyL2Description  as technologyL2Description, 
            Idh.rcPreFlag                as rcPreFlag,               
            Idh.rcPreFlagDescription     as rcPreFlagDescription,   
            Idh.applicationL2            as applicationL2,           
            Idh.applicationL2Description as applicationL2Description,
            Idh.realSubstanceCode as realSubstanceCode,
            Idh.realSubstanceName as realSubstanceName,            
            case 
                when Assessment.approvalDate is not null then  Assessment.approvalDate
                else '0000-00-00'
            end as approvalDate : Date,    
            case 
                when Assessment.approvalDate is not null then Assessment.propagation
                else Idh.manualMaintenanceFlag
            end as manualMaintenanceFlag : Boolean,                                      
    };    

view ProductsByApprovedAssessmentPlain as 
    select from ProductsByApprovedAssessment as Assessment
    {
        Assessment.ID as assessmentID,
        Assessment.toProofDocuments.ID as proofPointID,
        Assessment.product as product,
        Assessment.assessmentType as assessmentType,
        Assessment.sbu as sbu,
        Assessment.assesor as assesor,
        Assessment.submitter as submitter,
        Assessment.approver as approver,
        Assessment.comment as comment,
        Assessment.rcPreFlag as rcPreFlag,
        Assessment.rcPreFlagDescription as rcPreFlagDescription,
        Assessment.propagation as propagation,
        Assessment.externalCommunication as externalCommunication,
        Assessment.approberComment as approberComment,
        Assessment.category1 as category1,
        Assessment.contributor1 as contributor1,
        Assessment.category2 as category2,
        Assessment.contributor2 as contributor2,
        Assessment.category3 as category3,
        Assessment.contributor3 as contributor3,        
        Assessment.sustClass as sustClass,
        Assessment.toProofDocuments.modifiedAt as modifiedAt,
        Assessment.approvalDate as approvalDate,
        Assessment.modifiedAt as assessmentModifiedAt,
        case 
            when Assessment.toProofDocuments.type is not null then Assessment.toProofDocuments.type 
            else '18' 
        end as type: String(2),
        Assessment.toProofDocuments.active as active,
    };

view ApprovedProofPoints as
    select from ProductsByApprovedAssessmentPlain as Assessment
    inner join ProductsLastApprovalDate as LastAsessment
    on  Assessment.product = LastAsessment.product
    and Assessment.approvalDate = LastAsessment.approvalDate
    and Assessment.assessmentModifiedAt = LastAsessment.modifiedAt 
    left join management.ProofType
    on Assessment.type = ProofType.code
    {
        Assessment.assessmentID as assessmentID,
        Assessment.proofPointID as proofPointID,
        Assessment.product as product,
        Assessment.category1 as category1,
        Assessment.contributor1 as contributor1,
        Assessment.category2 as category2,
        Assessment.contributor2 as contributor2,
        Assessment.category3 as category3,
        Assessment.contributor3 as contributor3,          
        Assessment.sustClass as sustClass ,
        Assessment.modifiedAt as modifiedAt,
        Assessment.type as type,
        ProofType.description as description,
        ProofType.onPremiseCode as onPremiseCode,
    }
    where Assessment.proofPointID is not null
    and   Assessment.active = true;

view ApprovedProofPointsRanked as 
    select from ApprovedProofPoints as Assessment
    {   
        Assessment.assessmentID as assessmentID,
        Assessment.proofPointID as proofPointID,
        Assessment.product as product,
        Assessment.category1 as category1,
        Assessment.contributor1 as contributor1,
        Assessment.category2 as category2,
        Assessment.contributor2 as contributor2,
        Assessment.category3 as category3,
        Assessment.contributor3 as contributor3,          
        Assessment.sustClass as sustClass ,
        Assessment.modifiedAt as modifiedAt,
        Assessment.type as type,
        Assessment.description as description,
        Assessment.onPremiseCode as onPremiseCode,
        RANK() OVER (PARTITION BY assessmentID ORDER BY modifiedAt DESC, proofPointID) AS rank,        
    }

view ApprovedProofPointsTypesToOnpremise as 
    select from ApprovedProofPointsRanked
    {
        assessmentID,
        MAX(CASE WHEN rank = 1 THEN type END) AS type1,
        MAX(CASE WHEN rank = 2 THEN type END) AS type2,
        MAX(CASE WHEN rank = 3 THEN type END) AS type3,
    }
    group by assessmentID;

view ApprovedProofPointsToOnpremise as 
    select from ApprovedProofPointsRanked
    {
        assessmentID,
        product,
        category1,
        contributor1,
        category2,
        contributor2,
        category3,
        contributor3,          
        sustClass,
        MAX(CASE WHEN rank = 1 THEN type END) AS type1,
        MAX(CASE WHEN rank = 1 THEN onPremiseCode END) AS onPremiseCode1,
        MAX(CASE WHEN rank = 1 THEN description END) AS description1,
        MAX(CASE WHEN rank = 2 THEN type END) AS type2,
        MAX(CASE WHEN rank = 2 THEN onPremiseCode END) AS onPremiseCode2,
        MAX(CASE WHEN rank = 2 THEN description END) AS description2,        
        MAX(CASE WHEN rank = 3 THEN type END) AS type3,
        MAX(CASE WHEN rank = 3 THEN onPremiseCode END) AS onPremiseCode3,       
        MAX(CASE WHEN rank = 3 THEN description END) AS description3, 
    }
    group by assessmentID, product, category1, contributor1, category2, contributor2, category3, contributor3, sustClass;    

view IBsToIDHPropagated as 
    select from VT_V_IB_IDH as IbToIdh
    inner join IdhUpdated as Idh
    on Idh.materialtNumber = IbToIdh.MATERIAL_KEY
    {
        IbToIdh.AI_PRODUCT_KEY as ibProduct: String(18),
        IbToIdh.MATERIAL_KEY as material: String(18),
        Idh.sbu as idhSbu: types.sbu,
        Idh.rcPreFlag as idhRcPreFlag: types.rcPreFlag,
        Idh.rcPreFlagDescription as idhRcPreFlagDescription: types.rcPreFlagDescription,
    }
    where Idh.manualMaintenanceFlag = false;

context administration {

    view ApprovedProducts as
        select from ProductsByApprovedAssessment as Assessment
        left outer join ApprovedProofPointsToOnpremise as Proofpoints
        on  Assessment.ID = Proofpoints.assessmentID
        and Assessment.product = Proofpoints.product
        {
            Assessment.ID as assessmentID,
            Assessment.product,
            Assessment.assessmentType,
            Assessment.createdAt,
            Assessment.createdBy,
            Assessment.modifiedAt,
            Assessment.modifiedBy,
            Assessment.productType,
            Assessment.approvalDate,
            Assessment.category1,
            Assessment.contributor1,
            Assessment.category2,
            Assessment.contributor2,
            Assessment.category3,
            Assessment.contributor3,
            Assessment.sustClass,
            Assessment.assesor,
            Assessment.approver,
            Assessment.submitter,
            Assessment.sbu,
            Assessment.comment,
            Assessment.rcPreFlag,
            Assessment.rcPreFlagDescription,
            Assessment.propagation as manualMaintenanceFlag,
            case Assessment.propagation 
                when true then 'YES'
                else 'NO' 
            end as manualMaintenanceFlagDescription: String(3),
            Assessment.externalCommunication,
            Assessment.approberComment,
            Assessment.toProofDocuments,       
            Proofpoints.type1,
            Proofpoints.onPremiseCode1,
            Proofpoints.description1,
            Proofpoints.type2,
            Proofpoints.onPremiseCode2,
            Proofpoints.description2,
            Proofpoints.type3,
            Proofpoints.onPremiseCode3,
            Proofpoints.description3,
        };

    view LatestApprovedProducts as
        select from ApprovedProducts as Assessment
        inner join ProductsLastApprovalDate as lastAssessment
        on  lastAssessment.product = Assessment.product 
        and lastAssessment.approvalDate = Assessment.approvalDate
        and lastAssessment.modifiedAt = Assessment.modifiedAt     
        {
            Assessment.*
        }        
        
}


