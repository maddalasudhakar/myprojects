namespace com.sustainability.types;

type requestName                : String(100);
type sbu                        : String(3);
type product                    : String;
type productType                : String(3);
type assessor                   : String(40);
type submitter                  : String(40);
type date                       : Date;
type approver                   : String(40);
type approvalDate               : Date;
type assesmentType              : String(3);
type status                     : String(2);
type statusDescription          : String(15);
type comment                    : String;
type rcPreFlag                  : String(2);
type rcPreFlagDescription       : String;
type projectId                  : String;
type sustClass                  : String(2);
type category                   : String(2);
type contributor                : String(2);
type propagation                : String;
type virtualAssessment          : Boolean;
type email                      : String(40);
type projectManager             : String(80);
type sustainability             : String(80);
type productLineL3: String;



type assessmentsByStatus {
    started          : Integer;
    submited         : Integer;
    underReSubmitted : Integer;
    approved         : Integer;
}

type ProductData {
    product                     : String;
    type                        : String(3);
    productName                 : String;
    sbu                         : String;
    rcPreFlag                   : String(2);
    rcPreFlagDescription        : String;
    technologyL2Key             : String;
    technologyLevel2            : String;
    sustainabilityClassCode     : String;
    existingSustainabilityClass : String;
    realSubstanceCode           : String(18);
    realSubstanceName           : String(40);
    region                      : String(3);
    applicationLevel2Key        : String(3);
    applicationLevel2           : String;
    lastAssessment              : String;
    lastSubmitter               : String;
    lastApprover                : String;
}

type productsRelation {
    product              : types.product;
    productName          : String;
    realSubstanceCode    : String;
    sustClass            : String(2);
    sustClassDescription : String;
};

type materialsToProducts {
    material : types.product;
    product  : types.product;
}

type assessmentItemErrorMessage {
    code    : Integer;
    message : String;
}

type productsAssessments {
    product     : product;
    requestName : requestName;
}

type communicationStatus        : String @assert.range enum {
    PENDING = '01';
    PENDING_CPI_RETRY = '11';
    SENDED_CPI = '02';
    FEEDBACK_RECEIVED = '03';
    RETRYING = '04';
    COMPLETED = '05';
}

type assessmentProcessType      : String(10) enum {
    PDP = 'PDP';
    MOC = 'MOC';
    RCM = 'RCM';
    MANUAL = '';
    HEART = 'HRT';
    RCPC = 'RCPC';
};

type pdpProcessingStatus        : String(2) enum {
    PENDING = '01';
    RETRYING = '02';
    COMPLETED = '03';
}

type mocProcessingStatus        : String(2) enum {
    PENDING = '01';
    RETRYING = '02';
    COMPLETED = '03';
}

type idhOverwrite {
    material                : product;
    idhSbu                  : sbu;
    idhRcPreFlag            : rcPreFlag;
    idhRcPreFlagDescription : types.rcPreFlagDescription;
    assessment              : {
        requestName           : requestName;
        ID                    : UUID;
        headerId              : UUID;
        product               : product;
        sbu                   : sbu;
        assessor              : assessor;
        submitter             : submitter;
        submitionDate         : date;
        approver              : approver;
        approvalDate          : approvalDate;
        assesmentType         : assesmentType;
        comment               : comment;
        rcPreFlag             : rcPreFlag;
        rcPreFlagDescription  : types.rcPreFlagDescription;
        sustClass             : types.sustClass;
        category1             : types.category;
        contributor1          : types.contributor;
        category2             : types.category;
        contributor2          : types.contributor;
        category3             : types.category;
        contributor3          : types.contributor;
        approberComment       : String(255);
        externalCommunication : Boolean;
        virtualAssessment     : Boolean;
    }
}

type notificationsRecipients {
    email : email
}

type assessmentBlocked {
    ID                  : UUID;
    itemID              : UUID;
    requestName         : requestName;
    headerStatus        : status;
    product             : product;
    status              : status;
    assessor            : assessor;
    submitter           : submitter;
    approver            : approver;
    communicationStatus : status;
}

type blockedProdcuts {
    requestName : String;
    product     : String;
}

type MismatchedAssessmentStatus : String @assert.range enum {
    PENDING = '01';
    RETRYING = '02';
    FINALISED = '03';
}

type HeartClassificationData {
    rsnSbuCode                 : String;
    productLineL3              : String;
    technologyL1               : String;
    technologyL3               : String;
    applicationL1              : String;
    applicationL2              : String;
    applicationL3              : String;
    productHierarchyL3         : String;
    pcfClusterAttributes       : String;
    pcfClusterAttributesValues : String;
    pcfClusterSize             : String;
    pcfClusterBenchmark        : Double;
    pcfExcl                    : Double;
    pcfDeltaRel                : Double;
    pcfHeartSustainabilityClass : types.sustClass;
    pcfCategory : types.category;
    pcfContributor : types.contributor;
    heartRunId: String; 
    updateType: String(40);
};

type HeartDeltaProductDisplay {
    lineType: String(10) enum {
        LAST;
        NEW;
        DIFF;
    };
    productLineL3               : HeartClassificationData:productLineL3;
    technologyL1                : HeartClassificationData:technologyL1;
    technologyL3                : HeartClassificationData:technologyL3;
    applicationL1               : HeartClassificationData:applicationL1;
    applicationL2               : HeartClassificationData:applicationL2;
    applicationL3               : HeartClassificationData:applicationL3;
    productHierarchyL3          : HeartClassificationData:productHierarchyL3;
    pcfClusterAttributes        : HeartClassificationData:pcfClusterAttributes;
    pcfClusterAttributesValues  : HeartClassificationData:pcfClusterAttributesValues;
    pcfClusterSize              : HeartClassificationData:pcfClusterSize;
    pcfClusterBenchmark         : HeartClassificationData:pcfClusterBenchmark;
    pcfExcl                     : HeartClassificationData:pcfExcl;
    pcfDeltaRel                 : HeartClassificationData:pcfDeltaRel;
    pcfHeartSustainabilityClass : HeartClassificationData:pcfHeartSustainabilityClass;
    pcfCategory                 : HeartClassificationData:pcfCategory;
    pcfContributor              : HeartClassificationData:pcfContributor;
    heartRunId                  : HeartClassificationData:heartRunId;
    updateType                  : HeartClassificationData:updateType;
};

type pdpData {
    SBU                   : String;
    PROJECTID             : String;
    PRODUCT               : String;
    PRODUCTTYPE           : String;
    RCPREFLAG             : String;
    CONTRIBUTOR1          : String;
    CATEGORY1             : String;
    SUSTCLASS             : String;
    ASSESSMENTEXPLANATION : String;
    ASSESSOR              : String;
    SUBMITTER             : String;
    SUSTAINABILITY        : String;
    PROJECTMANAGER        : String;
    FINALDATE             : Timestamp;

}
