const cds = require("@sap/cds");
const { assessmentsCountQuery,
  userParameters,
  validateSingleAssementUserPermissions,
  formatUUIDWithHyphens,
  removeHyphensFromUUID,
  createImageMasterDocument,
  updateImageMasterreference,
  removeObjectStoreDocument,
  refreshProductDocumentMapping,
  checkProductsInAssessment,
  getIdhMapping,
  getIbMapping,
  translateVtResultsToProductData,
  translateVtSelectQueryWhere,
  setAssessmentLog,
  updateOnPremiseAssessmentProduct,
  convertAbapToJSDate,
  getProductApproverAssessor,
  checkPermissionAndStatus,
  updateMassAssessmentItemsBatch,
  checkProductsInAssessmentInfo,
  COMMUNICATION_STATUS,
} = require('./JS/functions');

const handlers = require("./handlers");

const { initializeS3Client, getBucketName, streamToBase64, streamToBuffer } = require('./JS/s3Client');
const { PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = require('@aws-sdk/client-s3');

// Initialize the S3 client
const s3 = initializeS3Client();
const bucketName = getBucketName(); // Get the bucket name

module.exports = (srv) => {


  /***********************************************************
   *
   * SingleAssessment
   *
   ************************************************************/

  /**
   * Middleware for handling the CREATE event for SingleAssessment.
   * @param {Object} req - The request object.
   * @returns {Object} The modified request object.
   */
  srv.before("CREATE", "SingleAssessment", async (req) => {
    // Validate user permissions; stop execution if validation fails
    // if (!validateSingleAssementUserPermissions(req)) {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    const aProductsInAsessment = await checkProductsInAssessment([req.data.product]);
    if (aProductsInAsessment && aProductsInAsessment.length > 0) {
      req.error(403, "Product is already in an assessment");
      return;
    }

    if (req.data.status === '01') {
      req.data.assessor = req.user.id;
    } else if (req.data.status){
      if (req.data.assessor !== '') {
        req.data.createdAt = new Date();
      } else {
        req.data.assessor = req.user.id;
      }
      req.data.submitter = req.user.id;
      req.data.submitionDate = new Date().toISOString().slice(0, 10);
    }

    await setAssessmentLog(req);

    return req;

  });

  /**
   * Handles the CREATE operation for the SingleAssessment entity, along with its associated AssessmentProofDocument.
   * If documents contain content, the content is uploaded to S3 and only metadata is stored in the database.
   * 
   * @param {Object} req - The request object containing data for the SingleAssessment entity and its related documents.
   * @returns {Object} The created SingleAssessment entity with its metadata.
   * @throws {Error} If there is an error during document upload to S3 or database operations.
   */
  srv.on('CREATE', 'SingleAssessment', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oSingleAssessment = oDb.entities['management.SingleAssessment']; // Reference to SingleAssessment entity

    try {
      const oData = req.data; // Data from the request (Deep Insert)

      // If there are associated proof documents in `toProofDocuments`, process them
      if (oData.toProofDocuments && oData.toProofDocuments.length > 0) {
        for (const document of oData.toProofDocuments) {
          // If the document has content (Base64), upload it to S3
          if (document.content && !document.url) {
            //let content = await streamToBuffer(document.content);
            const objParams = {
              Bucket: bucketName,
              Key: document.ID, // Use document ID as S3 key
              Body: Buffer.from(document.content, 'base64'),
              ContentType: document.mediaType
            };

            // Upload the document to S3
            await s3.send(new PutObjectCommand(objParams));

            // Clear content and mediaType fields to avoid storing it in the database
            document.content = null;
            document.mediaType = null;
          }

        }
      }

      // First, insert the SingleAssessment data into the database
      await cds.run(INSERT.into(oSingleAssessment).entries(oData));

    } catch (error) {
      console.error('Error creating SingleAssessment:', error);
      req.error("An error occurred during the creation of the assessment");
    }

    req.on('succeeded', async () => {
      await cds.tx(async () => {
        try {
          const SustainabilityManagement = await cds.connect.to('SustainabilityManagement');
          const oDb = await cds.connect.to('db');
          const oNotificationRecipients = oDb.entities['management.NotificationRecipients'];
          const { status, sbu, ID: assessmentId } = req.data;

          // links each status to an event name and its specific payload
          const eventMap = {
            '01': { event: 'assessmentSaved', payload: { sbu, assessmentId } },
            '02': { event: 'assessmentSubmitted', payload: { sbu, assessmentId } }
          };
          const aNotificationRecipients = await SELECT.from(oNotificationRecipients).where({ assessmentId: req.data.ID, assessmentStatus: status});

          if(((status === '02' || status === "01") && !aNotificationRecipients)) {
            return;
          }

          const config = eventMap[status];

          if (config) {
            const result = await SustainabilityManagement.emit(config.event, { ...config.payload, type: 'SINGLE' });
            console.log(result);
          }

        } catch (error) {
          console.error(error);
        }
      });
    });

    return req.data;

  });


  /**
   * Middleware for handling the UPDATE event for SingleAssessment.
   * @param {Object} req - The request object.
   * @returns {Object} The modified request object.
   */
  srv.before("UPDATE", "SingleAssessment", async (req) => {

    // Validate user permissions; stop execution if validation fails
    // if (!validateSingleAssementUserPermissions(req)) {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }
    if (req.data.status === '01') {
      req.data.assessor = req.user.id;
    } else if (req.data.status === '02') {
      req.data.submitter = req.user.id;
      req.data.submitionDate = new Date().toISOString().slice(0, 10);
    } else if (req.data.status !== '01' && req.data.status !== '02' && req.data.status) {
      const oDb = await cds.connect.to('db'); // Connect to the database
      const oSingleAssessment = oDb.entities['management.SingleAssessment']; // Reference to the SingleAssessment entity

      // If status is under review, the first time approver is set
      const oAssessment = await SELECT.one.from(oSingleAssessment).where({ ID: req.data.ID });
      if (!oAssessment.approver || oAssessment.approver === "") {
        req.data.approver = req.user.id;
      }
    }

    if (req.data.status === '05') {
      req.data.approvalDate = new Date().toISOString().slice(0, 10);
    }

    await setAssessmentLog(req);

    return req;
  });

  srv.on("UPDATE", "SingleAssessment", async (req) => {

    const oDb = await cds.connect.to('db'); // Connect to the database
    const oSingleAssessment = oDb.entities['management.SingleAssessment']; // Reference to the SingleAssessment entity
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument'];

    let aUpdatedSingleAssessment = [];
    let aProofDocumentsObjectStore = [];

    try {
      if (req.data.status === '05' || req.data.status == '06') {
        req.data.communicationStatus = '01';
      }
      await cds.run(
        UPDATE(oSingleAssessment)
          .set(req.data)
          .where({ ID: req.data.ID })
      );

    } catch (error) {
      console.error("Error updating the assessment data:", error);
      req.reject(409, "Error updating the assessment data");
    }

    req.on('succeeded', async () => {
      await cds.tx(async () => {
        try {
          const SustainabilityManagement = await cds.connect.to('SustainabilityManagement');
          const oDb = await cds.connect.to('db');
          const oNotificationRecipients = oDb.entities['management.NotificationRecipients'];
          const oSingleAssessment = oDb.entities['management.SingleAssessment'];

          const oAssessment = await SELECT.one.from(oSingleAssessment).where({ ID: req.data.ID });
          const { sbu, ID: assessmentId, submitter, approver } = oAssessment;

          const { status } = req.data;

          const aNotificationRecipients = await SELECT.from(oNotificationRecipients).where({ assessmentId: req.data.ID, assessmentStatus: status});

          if(((status === '02' || status === "01") && !aNotificationRecipients)) {
            return;
          }

          // links each status to an event name and its specific payload
          const eventMap = {
            '01': { event: 'assessmentSaved', payload: { sbu, assessmentId } },
            '02': { event: 'assessmentSubmitted', payload: { sbu, assessmentId } },
            '03': { event: 'assessmentUnderResubmission', payload: { sbu, assessmentId, submitter } },
            '04': { event: 'assessmentResubmitted', payload: { sbu, assessmentId, approver } },
          };

          const config = eventMap[status];

          if (config) {
            const result = await SustainabilityManagement.emit(config.event, { ...config.payload, type: 'SINGLE' });
            console.log(result);
          }

        } catch (error) {
          console.error(error);
        }
      });
    });

    return req;
  });

  /**
  * Middleware for handling the READ event for SingleAssessment.
  * @param {Array} req - The request array.
  * @returns {Array} The modified request array.
  */
  srv.after("READ", "SingleAssessment", async (req) => {
    let aProductData = [];
    const aProofDocuments = req[0].toProofDocuments;

    if (aProofDocuments && Array.isArray(aProofDocuments)) {
      aProofDocuments.forEach((oProofDocument) => {
        if (oProofDocument.imageMasterID && !oProofDocument.externalUrl) {
          let sFormatUUID = oProofDocument.imageMasterID.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
          oProofDocument.url = "ProductProofDocument(product='',proofPointId=" + sFormatUUID + ")/content";
        } else if (oProofDocument.fileName && !oProofDocument.imageMasterID) {
          oProofDocument.url = `AssessmentProofDocument(${oProofDocument.ID})/content`;
        }
      });
    }
    // if (req[0].productType === "IB") {
    //   aProductData = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IBPRODUCT').where({ IB_PRODUCT_NUMBER: req[0].product }));
    // } else {
    //   aProductData = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IDH').where({ IDH_MATERIAL_NR: req[0].product }));
    // }
    // const aTranslatedProductData = translateVtResultsToProductData(aProductData);

    const sEntity = req[0].productType === "IB" ? "Ib" : "Idh";
    aProduct = await srv.read( sEntity ).where({ materialtNumber: req[0].product });
    const aTranslatedProductData = aProduct.map(item => {
      const oMap = {
        product                     : item.materialtNumber,
        productName                 : item.materialDescription,
        sbu                         : item.sbu,
        rcPreFlag                   : item.rcPreFlag,
        rcPreFlagDescription        : item.rcPreFlagDescription,
        technologyL2Key             : item.technologyL2,
        technologyLevel2            : item.technologyL2Description,
        sustainabilityClassCode     : item.sustClass,
        existingSustainabilityClass : item.sustClassDescription,
        realSubstanceCode           : item.realSubstanceCode,
        realSubstanceName           : item.realSubstanceName,
        applicationLevel2Key        : item.applicationL2,
        applicationLevel2           : item.applicationL2Description,
        lastAssessment              : item.approvalDate,
        lastSubmitter               : item.submitter,
        lastApprover                : item.approver,            
      };
      return oMap;
    });

    if (aTranslatedProductData && aTranslatedProductData.length > 0) {
      const oTranslatedData = aTranslatedProductData[0];
      for (const key in oTranslatedData) {
        if (req[0].hasOwnProperty(key)) {
          req[0][key] = oTranslatedData[key];
        }
      }
    }

    return req;
  });

  /**
   * Middleware for handling the UPDATE event for SingleAssessment.
   * @param {Object} req - The request object.
   * @returns {Object} The modified request object.
   */
  srv.before("DELETE", "SingleAssessment", async (req) => {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }
    await setAssessmentLog(req);
  });

  /**
   * Handles the DELETE operation for the SingleAssessment entity and its associated AssessmentProofDocument.
   * Removes any associated documents from S3 and then deletes the SingleAssessment entity from the database.
   * 
   * @param {Object} req - The request object containing the ID of the SingleAssessment to delete.
   * @returns {Object} The result of the delete operation.
   * @throws {Error} If there is an error during document deletion from S3 or database operations.
   */
  srv.on('DELETE', 'SingleAssessment', async (req) => {
    // Validate user permissions; stop execution if validation fails
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    const oDb = await cds.connect.to('db'); // Connect to the database
    const oSingleAssessment = oDb.entities['management.SingleAssessment']; // Reference to the SingleAssessment entity
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument']; // Reference to the ProofDocuments entity
    const { ID } = req.data; // ID of the SingleAssessment to delete


    try {
      // Check if there are associated documents
      const aProofDocuments = await cds.run(SELECT.from(oProofDocuments).where({ requestId: ID }));

      if (aProofDocuments.length > 0) {
        // If associated documents exist, delete the files from S3
        for (const oDocument of aProofDocuments) {
          const objParams = {
            Bucket: bucketName,
            Key: oDocument.ID // Document ID is the S3 key
          };

          // Delete the document from S3
          await s3.send(new DeleteObjectCommand(objParams));
        }

      }

      // Delete the SingleAssessment from the database
      await cds.run(DELETE.from(oSingleAssessment).where({ ID }));

      return { message: `SingleAssessment with ID ${ID} and its associated documents were deleted successfully.` };
    } catch (error) {
      console.error('Error during SingleAssessment delete operation:', error);
      req.error(409, 'Failed to delete SingleAssessment and its associated documents.');
    }
  });


  /***********************************************************
   *
   * MassAssessmentHeader
   *
   ************************************************************/

  /**
   * Middleware for handling the CREATE event for MassAssessmentHeader.
   * @param {Object} req - The request object.
   * @returns {Object} The modified request object.
   */
  srv.before("CREATE", "MassAssessmentHeader", async (req) => {


    if (req.data.status !== "91") {
      req.error(409, `Mass assessments can only be created in draft status`);
    }

    // Validate user permissions; stop execution if validation fails
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }
    // if (req.data.status === '01') {
    req.data.assessor = req.user.id;
    if (Array.isArray(req.data.toItems)) {
      req.data.toItems.forEach(oItem => {
        if (!oItem.assessor || oItem.assessor === '') {
          oItem.assessor = req.user.id;
        }
        oItem.status = "91";
      });
    }

    if (Array.isArray(req.data.toItems)) {
      const aProducts = req.data.toItems.map(item => item.product);
      const aProductsInAsessment = await checkProductsInAssessment(aProducts);

      if (aProductsInAsessment && aProductsInAsessment.length > 0) {
        const sProductEnumeration = aProductsInAsessment.reduce((acc, curr) => {
          if (acc === "") {
            return curr; 
          } else if (!curr.includes(" and ")) {
            return `${curr} and ${acc}`;
          }
          return `${curr}, ${acc}`;
        }, "");

        req.error(403, `Product already in an assessment: ${sProductEnumeration}`);
      }
    }

    await setAssessmentLog(req);

    return req;
  });

  /**
   * Handles the CREATE operation for the MassAssessmentHeader entity, along with its associated MassAssessmentItems and AssessmentProofDocument.
   * If documents contain content, the content is uploaded to S3 and only metadata is stored in the database.
   * 
   * @param {Object} req - The request object containing data for the MassAssessmentHeader entity and its related items and documents.
   * @returns {Object} The created MassAssessmentHeader entity with its metadata.
   * @throws {Error} If there is an error during document upload to S3 or database operations.
   */
  srv.on('CREATE', 'MassAssessmentHeader', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oMassAssessmentHeader = oDb.entities['management.MassAssessmentHeader']; // Reference to MassAssessmentHeader entity

    try {
      const data = req.data; // Data from the request (Deep Insert)

      // If there are associated items in `toItems`, process them
      if (data.toItems && data.toItems.length > 0) {
        for (const item of data.toItems) {

          // If the item contains associated proof documents, process them
          if (item.toProofDocuments && item.toProofDocuments.length > 0) {
            for (const document of item.toProofDocuments) {

              // If it's a new document, upload content to S3 if provided
              if (document.content && !document.url) {
                //let content = await streamToBuffer(document.content);
                const objParams = {
                  Bucket: bucketName,
                  Key: document.ID, // Use document ID as S3 key
                  Body: Buffer.from(document.content, 'base64'),
                  ContentType: document.mediaType
                };

                // Clear content and mediaType fields to avoid storing it in the database
                document.content = null;
                document.mediaType = null;

                // Upload the document to S3
                await s3.send(new PutObjectCommand(objParams));

              }
            }
          }
        }
      }

      // Insert the MassAssessmentHeader into the database
      await cds.run(INSERT.into(oMassAssessmentHeader).entries(data));

      return req.data;
    } catch (error) {
      console.error('Error creating MassAssessmentHeader:', error);
      req.error(409, 'Error creating the MassAssessment');
    }
  });


  /**
    * Middleware for handling the UPDATE event for MassAssessmentHeader.
    * @param {Object} req - The request object.
    * @returns {Object} The modified request object.
    */
  srv.before("UPDATE", "MassAssessmentHeader", async (req) => {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }
    if (req.data.status === '01') {
      req.data.assessor = req.user.id;
    } else if (req.data.status === '02') {
      req.data.submitter = req.user.id;
      req.data.submitionDate = new Date().toISOString().slice(0, 10);

      /*if (Array.isArray(req.data.toItems)) {
        req.data.toItems.forEach(oItem => {
          oItem.status = '02';
        });
      }*/
    }

    await setAssessmentLog(req);

    return req;
  });

  /**
    * Middleware for handling the DELETE event for MassAssessmentHeader.
    * @param {Object} req - The request object.
    * @returns {Object} The modified request object.
    */
  srv.before("DELETE", "MassAssessmentHeader", async (req) => {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    await setAssessmentLog(req);

    return req;
  });

  /**
   * Handles the DELETE operation for the MassAssessmentHeader entity and its associated items and documents.
   * Removes any associated documents from S3 and then deletes the MassAssessmentHeader entity and its related items and documents from the database.
   * 
   * @param {Object} req - The request object containing the ID of the MassAssessmentHeader to delete.
   * @returns {Object} The result of the delete operation.
   * @throws {Error} If there is an error during document deletion from S3 or database operations.
   */
  srv.on('DELETE', 'MassAssessmentHeader', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oMassAssessmentHeader = oDb.entities['management.MassAssessmentHeader']; // Reference to MassAssessmentHeader entity
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems']; // Reference to MassAssessmentItems entity
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument']; // Reference to AssessmentProofDocument entity
    const { ID } = req.data; // ID of the MassAssessmentHeader to delete

    try {
      // First, find all related items associated with the MassAssessmentHeader
      const aMassAssessmentItems = await cds.run(SELECT.from(oMassAssessmentItems).where({ headerId: ID }));

      // Delete the MassAssessmentHeader from the database
      await cds.run(DELETE.from(oMassAssessmentHeader).where({ ID }));

      if (aMassAssessmentItems.length > 0) {
        // For each item, check for associated proof documents
        for (const oItem of aMassAssessmentItems) {
          const aProofDocuments = await cds.run(SELECT.from(oProofDocuments).where({ requestId: oItem.ID }));

          if (aProofDocuments.length > 0) {
            // If associated documents exist, delete the files from S3
            for (const oDocument of aProofDocuments) {
              const objParams = {
                Bucket: bucketName,
                Key: oDocument.ID // Document ID is the S3 key
              };

              // Delete the document from S3
              await s3.send(new DeleteObjectCommand(objParams));
            }

          }
        }
      }

      return { message: `MassAssessmentHeader with ID ${ID} and its associated items and documents were deleted successfully.` };
    } catch (error) {
      console.error('Error during MassAssessmentHeader delete operation:', error);
      req.error(409, 'Failed to delete MassAssessment and its associated items and documents.');
    }
  });

  /**
   * Post-processing for the READ operation on the MassAssessmentHeader entity.
   * Checks the status of each associated item and updates the approval status accordingly.
   * 
   * @param {Object} req - The request object containing the MassAssessmentHeader data after read operation.
   * @returns {Object} The modified request object with updated approval statuses.
   */
  srv.after("READ", "MassAssessmentHeader", async (req) => {

    let aProducts = [];

    // Check if there are associated items
    if (Array.isArray(req[0].toItems)) {
      req[0].toItems.forEach(oItem => {
        // Add the product to the array if it is not null or undefined
        if (oItem.product) {
          aProducts.push(oItem.product);
        }

        // Update approbalStatus only if the status is not "01" or "02"
        if (oItem.status !== '01' && oItem.status !== '02') {
          oItem.approbalStatus = oItem.status;
        }
      });
    }

    // Exit early if there are no products
    if (aProducts.length === 0) {
      return req;
    }

   
    const sEntity = req[0].productType === "IB" ? "Ib" : "Idh";
    aProductData = await srv.read( sEntity ).where({ materialtNumber: aProducts });
    const aTranslatedProductData = aProductData.map(item => {
      const oMap = {
        product                     : item.materialtNumber,
        productName                 : item.materialDescription,
        sbu                         : item.sbu,
        rcPreFlag                   : item.rcPreFlag,
        rcPreFlagDescription        : item.rcPreFlagDescription,
        technologyL2Key             : item.technologyL2,
        technologyLevel2            : item.technologyL2Description,
        sustainabilityClassCode     : item.sustClass,
        existingSustainabilityClass : item.sustClassDescription,
        realSubstanceCode           : item.realSubstanceCode,
        realSubstanceName           : item.realSubstanceName,
        applicationLevel2Key        : item.applicationL2,
        applicationLevel2           : item.applicationL2Description,
        lastAssessment              : item.approvalDate,
        lastSubmitter               : item.submitter,
        lastApprover                : item.approver,            
      };
      return oMap;
    });

    if (aTranslatedProductData && aTranslatedProductData.length > 0) {
      req[0].toItems.forEach(oItem => {
        const oTranslatedData = aTranslatedProductData.find(product => product.product === oItem.product);
        if (oTranslatedData) {
          for (const key in oTranslatedData) {
            if (oItem.hasOwnProperty(key)) {
              oItem[key] = oTranslatedData[key];
            }
          }
        }
      });
    }

    return req;
  });

  /***********************************************************
  *
  * MassAssessmentItems
  *
  ************************************************************/

  /**
   * Post-processing for the READ operation on the MassAssessmentItems entity.
   * Iterates through the list of items, checks each item's status, and updates the approval status if applicable.
   * 
   * @param {Object[]} req - The request object containing the MassAssessmentItems data after read operation.
   * @returns {Object[]} The modified request object with updated approval statuses.
   */
  srv.after("READ", "MassAssessmentItems", (req) => {
    if (Array.isArray(req)) {
      req.forEach(oItem => {
        // Update the approval status only if the item status is not "01" or "02" (approbal steps)
        if (oItem.status !== '01' && oItem.status !== '02') {
          oItem.approbalStatus = oItem.status;
        }
      });
    }

    return req;
  });

  srv.before('CREATE', 'MassAssessmentItems', async (req) => {

    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    if (req.data.status === '01') {

      req.data.assessor = req.user.id;

    } else {

      if (req.data.assessor !== '') {
        req.data.createdAt = new Date();
      } else {
        req.data.assessor = req.user.id;
      }
      req.data.submitter = req.user.id;
      // req.data.submitionDate = new Date().toISOString().slice(0, 10);

    }

    const aProductsInAsessment = await checkProductsInAssessment([req.data.product]);

    if (aProductsInAsessment && aProductsInAsessment.length > 0) {
      const sProductEnumeration = aProductsInAsessment.reduce((acc, curr) => {
        if (acc === "") {
          return curr;
        } else if (!curr.includes(" and ")) {
          return `${curr} and ${acc}`;
        }
        return `${curr}, ${acc}`;
      }, "");

      req.error(403, `Product already in an assessment: ${sProductEnumeration}`);
    }

    await setAssessmentLog(req);

  });

  srv.on('CREATE', 'MassAssessmentItems', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems']; // Reference to MassAssessmentItems entity

    try {
      //const data = req.data; // Data from the request (Deep Insert)

      // If there are associated items in `toItems`, process them
      //if (data.toItems && data.toItems.length > 0) {
      //for (const item of data.toItems) {

      req.data.assessor = req.user.id;

      // If the item contains associated proof documents, process them
      if (req.data.toProofDocuments && req.data.toProofDocuments.length > 0) {
        for (const document of req.data.toProofDocuments) {

          // If it's a new document, upload content to S3 if provided
          if (document.content && !document.url) {
            // let content = await streamToBuffer(document.content);
            const objParams = {
              Bucket: bucketName,
              Key: document.ID, // Use document ID as S3 key
              Body: Buffer.from(document.content, 'base64'),
              ContentType: document.mediaType
            };

            // Clear content and mediaType fields to avoid storing it in the database
            document.content = null;
            document.mediaType = null;
            document.objectStoreId = document.ID;
            document.url = `AssessmentProofDocument(${document.objectStoreId})/content`;


            // Upload the document to S3
            await s3.send(new PutObjectCommand(objParams));

          }
        }
      }
      //}
      //}

      // Insert the MassAssessmentItems into the database
      await cds.run(INSERT.into(oMassAssessmentItems).entries(req.data));

      return req.data;
    } catch (error) {
      console.error('Error creating MassAssessmentItems:', error);
      req.error(409, 'Error creating the Item');
    }
  });


  /**
  * Pre-processing for the UPDATE operation on the MassAssessmentItems entity.
  * Sets the item's status based on the approbalStatus provided, if it meets certain conditions.
  * 
  * @param {Object} req - The request object containing the data to update in MassAssessmentItems.
  * @returns {Object} The modified request object with the status updated based on approval status if conditions are met.
  */
  srv.before("UPDATE", "MassAssessmentItems", async (req) => {

    if (req.data.status === "02" || req.data.approbalStatus === "02") {
      req.error(409, "Generic handler cannot submit assessment items");
      return;
    }

    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const oOldItems = await SELECT.from(oMassAssessmentItems).where({ ID: req.data.ID });

    // Check if the approval status meets specific criteria (approbal steps), then update the item's status accordingly
    if (req.data.approbalStatus === '03' || req.data.approbalStatus === '04' || req.data.approbalStatus === '05' || req.data.approbalStatus === '06') {
      req.data.status = req.data.approbalStatus;
      const sOldApprover = oOldItems[0]?.approver;
      if ((!req.data.approver || req.data.approver === "") && !sOldApprover) {
        req.data.approver = req.user.id;
      }
    }

    if (oOldItems[0]?.status === '91' && req.data.approbalStatus === "01") {
      req.data.status = req.data.approbalStatus;
    }
    if (req.data.status === '91') {
      req.data.assessor = req.user.id;
    } else if (req.data.status === '02') {
      req.data.submitter = req.user.id;
      if (!oOldItems || !oOldItems[0].assessor || oOldItems[0].assessor === "") {
        req.data.assessor = req.user.id;
      }
    }

    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    if (req.data.status === '05') {
      req.data.approvalDate = new Date().toISOString().slice(0, 10);
    }

    await setAssessmentLog(req);

    return req;
  });

  srv.on("UPDATE", "MassAssessmentItems", async (req) => {
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument'];

    let aUpdatedMassItem = [];
    let aProofDocumentsObjectStore = [];

    try {
      if (req.data.status === '05' || req.data.status == '06') {
        req.data.communicationStatus = '01';
      }
      await cds.run(
        UPDATE(oMassAssessmentItems)
          .set(req.data)
          .where({ ID: req.data.ID })
      );


    } catch (error) {
      console.log(JSON.stringify(error));
      req.reject(409, "Error updating the assessment data");
    }

    return req;

  });

  /**
  * Middleware for handling the DELETE event for MassAssessmentItems.
  * @param {Object} req - The request object.
  * @returns {Object} The modified request object.
  */
  srv.before("DELETE", "MassAssessmentItems", async (req) => {
    if (!(await checkPermissionAndStatus(req))) {
      return;
    }

    await setAssessmentLog(req);

    return req;
  });

  /***********************************************************
  *
  * AssessmentProofDocument
  *
  ************************************************************/


  /**
    * Middleware for handling the READ event for AssessmentProofDocument.
    * @param {Array} req - The request array.
    * @returns {Array} The modified request array.
    */
  srv.after("READ", "AssessmentProofDocument", (req) => {
    if (req && Array.isArray(req)) {
      req.forEach((oProofDocument) => {
        if (oProofDocument.fileName) {

          if (oProofDocument.imageMasterID && !oProofDocument.externalUrl) {
            let sFormatUUID = oProofDocument.imageMasterID.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
            oProofDocument.url = "ProductProofDocument(product='',proofPointId=" + sFormatUUID + ")/content";
          } else if (!oProofDocument.imageMasterID && !oProofDocument.externalUrl) {
            oProofDocument.url = `AssessmentProofDocument(${oProofDocument.ID})/content`;
          }

        }
      });
    }
    return req;
  });

  /**
 * Middleware for handling the AFTER UPDATE event for AssessmentProofDocument.
 * @param {Array} req - The request array.
 * @returns {Array} The modified request array.
 */
  /*srv.after("UPDATE", "AssessmentProofDocument", (req) => {

    if (req.fileName) {
      req.url = `AssessmentProofDocument(${req.ID})/content`;
    }

    return req;
  });*/

  /**
   * Handler for the READ event on AssessmentProofDocument.
   * Retrieves assessment proof documents, and fetches their content from S3 only when explicitly requested.
   * @param {Object} req - The request object containing query parameters.
   * @returns {Array|Object} The assessment proof documents retrieved from the database.
   */
  srv.on('READ', 'AssessmentProofDocument', async (req) => {

    const oDb = await cds.connect.to('db'); // Connect to the database
    const oAssessmentProofDocument = oDb.entities["management.AssessmentProofDocument"]; // Reference to AssessmentProofDocument entity

    let sItemID; // Variable to hold item ID

    // Check how many parameters exist to determine the correct item ID
    if (req.params.length > 1) {
      sItemID = req.params[1]; // MassAssessment
    } else {
      sItemID = req.params[0]; // SingleAssessment
    }

    // Define a flag to check if content is requested
    const isContentRequested = req.query.SELECT.columns && req.query.SELECT.columns.some(col => col.ref && col.ref[0] === 'content');

    // If a specific ID is provided in the request, retrieve that document
    if (req.data.ID) {
      const oDocument = await SELECT.one.from(oAssessmentProofDocument).where({ ID: req.data.ID });

      // If document exists and content is requested, fetch the content from S3
      if (oDocument && isContentRequested) {
        // Define parameters for S3 get
        const objParams = {
          Bucket: bucketName,
          Key: oDocument.objectStoreId ? oDocument.objectStoreId : oDocument.ID // Use the document ID as the S3 key
        };

        // Fetch the document content from S3
        const s3Response = await s3.send(new GetObjectCommand(objParams));

        const oReturn = {
          content: s3Response.Body,
          $mediaContentType: s3Response.ContentType,
          $mediaContentDispositionFilename: oDocument.fileName
        };

        return oReturn ? oReturn : req.error(404, 'Document not found');
      } else {
        // Retrieve the document with specified columns from the database
        const oDocument = await SELECT.one.from(oAssessmentProofDocument).where({ ID: req.data.ID });
        return oDocument;
      }


    }

    // Define pagination variables
    const iTop = req.query.SELECT.limit.rows || 110;  // Default top (limit) of 110
    const iSkip = req.query.SELECT.limit.offset || 0;  // Default skip (offset) of 0

    // If sItemID is provided, handle the navigation logic
    if (sItemID) {
      // Retrieve all the proof documents associated with the specific item
      const aDocuments = await SELECT.from(oAssessmentProofDocument)
        .where({ requestId: sItemID });

      return aDocuments; // Return the documents associated with the item
    }

    // If no specific ID or item ID is provided, apply filters if necessary
    const aFilters = req.query.SELECT.where || []; // Retrieve any filters from the request

    // Apply filters if they exist
    const aDocuments = await SELECT.from(oAssessmentProofDocument)
      .where(aFilters);

    return aDocuments; // Return the retrieved assessment proof documents
  });

  /**
    * Middleware for handling the DELETE event for MassAssessmentItems.
    * @param {Object} req - The request object.
    * @returns {Object} The modified request object.
    */
  srv.before("CREATE", "MassAssessmentItems", async (req) => {
    await setAssessmentLog(req);
  });



  /**
   * Handles the CREATE operation to upload a document to S3 and save its metadata to the database.
   * @param {Object} req - The request object containing the data for the document.
   * @returns {Object} A message indicating the success of the operation.
   * @throws {Error} If there is an error during the upload or database operation.
   */
  srv.on('CREATE', 'AssessmentProofDocument', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oAssessmentProofDocument = oDb.entities["management.AssessmentProofDocument"]; // Reference to AssessmentProofDocument entity
    try {

      if (req.data.content) {
        //let content = await streamToBuffer(req.data.content);
        // Define parameters for S3 upload
        const objParams = {
          Bucket: bucketName,
          Key: req.data.ID,
          Body: Buffer.from(req.data.content, 'base64'),
          ContentType: req.data.mediaType
        };

        // Upload the document to S3
        await s3.send(new PutObjectCommand(objParams));

        // Prepare the data for the AssessmentProofDocument entity
        //req.data.url = `${objectStoreCredentials.url}/${bucketName}/${req.data.ID}`;
        req.data.content = null; // Clear content after upload
        req.data.internalPath = ""; // Set internal path if necessary
        req.data.mediaType = null; // Clear media type
      }
      req.data.internalPath = ""; // Set internal path if necessary

      req.data.objectStoreId = req.data.ID;
      // Insert the new document metadata into the database
      await cds.run(INSERT.into(oAssessmentProofDocument).entries(req.data));

      return req.data;

    } catch (error) {
      console.error('Error uploading document:', error);
      req.reject(409, 'Error uploading document to S3 and saving metadata');
    }
  });

  /**
   * Handles the UPDATE operation to update a document in S3 and its metadata in the database.
   * @param {Object} req - The request object containing the updated data for the document.
   * @returns {Object} A message indicating the success of the operation.
   * @throws {Error} If there is an error during the update or database operation.
   */
  srv.on('UPDATE', 'AssessmentProofDocument', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oAssessmentProofDocument = oDb.entities["management.AssessmentProofDocument"]; // Reference to AssessmentProofDocument entity

    try {
      // Check if document exists in the database
      const existingDocument = await cds.run(
        SELECT.one.from(oAssessmentProofDocument).where({ ID: req.data.ID })
      );

      if (!existingDocument) {
        return req.error(404, 'Document not found');
      }


      if (req.data.content && req.data.internalPath && !existingDocument[0]?.url) {
        // let content = await streamToBuffer(req.data.content);
        // Define parameters for S3 upload (update)
        const objParams = {
          Bucket: bucketName,
          Key: req.data.ID,
          Body: Buffer.from(req.data.content, 'base64'),
          ContentType: req.data.mediaType
        };

        // Upload the updated document to S3 (replacing the existing one)
        await s3.send(new PutObjectCommand(objParams));

        // Prepare the data for the AssessmentProofDocument entity
        req.data.content = null; // Clear content after upload
        req.data.internalPath = ""; // Set internal path if necessary
        req.data.mediaType = null; // Clear media type
        req.data.objectStoreId = req.data.ID;
        req.data.url = `AssessmentProofDocument(${req.data.objectStoreId})/content`;

      }

      // Update the document metadata in the database
      await cds.run(
        UPDATE(oAssessmentProofDocument)
          .set(req.data)
          .where({ ID: req.data.ID })
      );

      return req.data;

    } catch (error) {
      console.error('Error updating document:', error);
      req.error(409, 'Error updating document in S3 and saving metadata');
    }
  });

  /**
   * Handles the DELETE operation to remove a document from S3 and its metadata from the database.
   * @param {Object} req - The request object containing the ID of the document to delete.
   * @returns {Object} A message indicating the success of the operation.
   * @throws {Error} If there is an error during the deletion from S3 or database operation.
   */
  srv.on('DELETE', 'AssessmentProofDocument', async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oAssessmentProofDocument = oDb.entities["management.AssessmentProofDocument"]; // Reference to AssessmentProofDocument entity

    try {
      // Fetch the document metadata to check if it exists
      const existingDocument = await cds.run(
        SELECT.one.from(oAssessmentProofDocument).where({ ID: req.data.ID })
      );

      if (!existingDocument) {
        return req.error(404, 'Document not found');
      }

      // Check if there is still an ongoing item with the same object store id
      if (existingDocument.objectStoreId && existingDocument.objectStoreId !== "") {

        // New case
        const sameObjectStoreDocuments = await cds.run(
          SELECT.from(oAssessmentProofDocument).where({ objectStoreId: existingDocument.objectStoreId })
        );
        if (sameObjectStoreDocuments.length <= 1) {
          const sObjectStoreId = req.data.objectStoreId;
          cds.spawn( async (tx) => {
            // Define parameters for S3 delete
            const objParams = {
              Bucket: bucketName,
              Key: sObjectStoreId // Same key as when uploaded
            };

            // Delete the document from S3
            await s3.send(new DeleteObjectCommand(objParams));
          });
        }

      } else {

        // Legacy case
        const sObjectStoreId = req.data.ID;
        cds.spawn( async (tx) => {
          // Define parameters for S3 delete
          const objParams = {
            Bucket: bucketName,
            Key: sObjectStoreId // Same key as when uploaded
          };

          // Delete the document from S3
          await s3.send(new DeleteObjectCommand(objParams));
        });

      }


      // Delete the document metadata from the database
      await cds.run(
        DELETE.from(oAssessmentProofDocument).where({ ID: req.data.ID })
      );

      return { message: `Document with ID ${req.data.ID} has been successfully deleted.` };

    } catch (error) {
      console.error('Error deleting document:', error);
      req.reject(409, 'Error deleting document from S3 and removing metadata');
    }
  });

  /***********************************************************
  *
  * ProductProofDocument
  *
  ************************************************************/

  srv.after("READ", "ProductProofDocument", (req) => {

    if (req && Array.isArray(req)) {
      req.forEach((oProofDocument) => {
        if (oProofDocument.fileName && !oProofDocument.externalUrl) {
          let sFormatUUID = oProofDocument.proofPointId.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
          oProofDocument.url = "ProductProofDocument(product='" + oProofDocument.product + "',proofPointId=" + sFormatUUID + ")/content";
        }
      });
    }
    return req;

  });


  srv.on("READ", "ProductProofDocument", async (req) => {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oProductProofDocument = oDb.entities["management.ProductProofDocumentRelation"];

    let isContentRequested = req.query.SELECT.columns && req.query.SELECT.columns.some(col => col.ref && col.ref[0] === 'content');

    if (isContentRequested && req.data.proofPointId) {
      try {
        const externalService = await cds.connect.to('pst-imagemaster');
        let UUID = req.data.proofPointId.replace(/-/g, '');
        let sQuery = `{\r\n\"query\":\"restrict(and(ima:revision:isLatest(ref('revisions')),ima:attribute:hasValue(ima:metadata:Sustainability_Tracking.ID(ref('revisions')),const('${UUID}'))),galaxy(revisions))\"\r\n}`;
        let sPath = `/rest/core/query?includeContentData=true&maxHits=1000&language=RAQL`;
        var oData = await externalService.send({
          method: "POST",
          headers: {
            'Ima-Request-Id': `Sustainability_Tracking-{${UUID}}`,
            "Content-Type": "application/json",
            "Accept": "application/json"
          },
          path: sPath,
          data: sQuery
        });

        // Decode Base64 content to binary (binary string)
        let binaryString = atob(oData.hits[0].items[0].revision.contents[0].data.base64);

        // Convert binary string to byte array (Uint8Array)
        let byteArray = new Uint8Array(binaryString.length);
        for (let i = 0; i < binaryString.length; i++) {
          byteArray[i] = binaryString.charCodeAt(i);
        }
        const oReturn = {
          content: byteArray,
          $mediaContentType: oData.hits[0].items[0].revision.contents[0].mimeType,
          $mediaContentDispositionFilename: oData.hits[0].items[0].revision.contents[0].fileName
        };

        return oReturn ? oReturn : req.error(404, 'Document not found');
      } catch (e) {
        req.error(409, "Error reading the document content");
        console.log(JSON.stringify(e));
      }
    }

    const aFilters = req.query.SELECT.where || []; // Retrieve any filters from the request

    const aProductsProofDocuments = await oDb.read(oProductProofDocument).where(aFilters);

    return aProductsProofDocuments;



  });

  /***********************************************************
  *
  * IDH
  *
  ************************************************************/
  srv.before('READ', 'Idh', async (req) => {

    if (req.query.SELECT.columns) {
      req.query.SELECT.columns = [];
    }

  });

  srv.after('READ', 'Idh', async (data, req) => {

    // Filling of calculated fields
    const oDb = await cds.connect.to('db');
    const Sbu = oDb.entities["management.Sbu"];
    const SustainabilityCategory = oDb.entities["management.SustainabilityCategory"];
    const SustainabilityClass = oDb.entities["management.SustainabilityClass"];
    const Contributor = oDb.entities["management.Contributor"];

    // Recover data from DB
    const [aSbu, aContributor, aSustainabilityCategory, aSustainabilityClass] = (await oDb.run(tx => {

      const sbu = oDb.run(SELECT.from(Sbu));
      const contributor = oDb.run(SELECT.from(Contributor));
      const sustainabilityCategory = oDb.run(SELECT.from(SustainabilityCategory));
      const sustainabilityClass = oDb.run(SELECT.from(SustainabilityClass));
      return Promise.allSettled([sbu, contributor, sustainabilityCategory, sustainabilityClass]);

    })).map(item => item.value);

    // Fill descriptions
    for(const oData of data){

      oData.sbuDescription = aSbu.find(item => item.sbu === oData?.sbu)?.sbuDescription ?? "";
      oData.sustClassDescription = aSustainabilityClass.find(item => item.code === oData?.sustClass)?.description ?? "";
      oData.categoryDescription = aSustainabilityCategory.find(item => item.code === oData?.category)?.description ?? "";
      oData.category2Description = aSustainabilityCategory.find(item => item.code === oData?.category2)?.description ?? "";
      oData.category3Description = aSustainabilityCategory.find(item => item.code === oData?.category3)?.description ?? "";
      oData.contributorDescription = aContributor.find(item => item.code === oData?.contributor)?.description ?? "";
      oData.contributor2Description = aContributor.find(item => item.code === oData?.contributor2)?.description ?? "";
      oData.contributor3Description = aContributor.find(item => item.code === oData?.contributor3)?.description ?? "";

    };

  });

  /***********************************************************
  *
  * IB
  *
  ************************************************************/

  

  srv.before('READ', 'Ib', async (req) => {

    if (req.query.SELECT.columns) {
      req.query.SELECT.columns = [];
    }

  });

  srv.after('READ', 'Ib', async (data, req) => {

    // Filling of calculated fields
    const oDb = await cds.connect.to('db');
    const Sbu = oDb.entities["management.Sbu"];
    const SustainabilityCategory = oDb.entities["management.SustainabilityCategory"];
    const SustainabilityClass = oDb.entities["management.SustainabilityClass"];
    const Contributor = oDb.entities["management.Contributor"];

    // Recover data from DB
    const [aSbu, aContributor, aSustainabilityCategory, aSustainabilityClass] = (await oDb.run(tx => {

      const sbu = oDb.run(SELECT.from(Sbu));
      const contributor = oDb.run(SELECT.from(Contributor));
      const sustainabilityCategory = oDb.run(SELECT.from(SustainabilityCategory));
      const sustainabilityClass = oDb.run(SELECT.from(SustainabilityClass));
      return Promise.allSettled([sbu, contributor, sustainabilityCategory, sustainabilityClass]);

    })).map(item => item.value);

    // Fill descriptions
    for(const oData of data){

      oData.sbuDescription = aSbu.find(item => item.sbu === oData?.sbu)?.sbuDescription ?? "";
      oData.sustClassDescription = aSustainabilityClass.find(item => item.code === oData?.sustClass)?.description ?? "";
      oData.categoryDescription = aSustainabilityCategory.find(item => item.code === oData?.category)?.description ?? "";
      oData.category2Description = aSustainabilityCategory.find(item => item.code === oData?.category2)?.description ?? "";
      oData.category3Description = aSustainabilityCategory.find(item => item.code === oData?.category3)?.description ?? "";
      oData.contributorDescription = aContributor.find(item => item.code === oData?.contributor)?.description ?? "";
      oData.contributor2Description = aContributor.find(item => item.code === oData?.contributor2)?.description ?? "";
      oData.contributor3Description = aContributor.find(item => item.code === oData?.contributor3)?.description ?? "";

    };

  });

  /***********************************************************
  *
  * ProductsRelation
  *
  ************************************************************/

  /***********************************************************
  *
  * ProductLog
  *
  ************************************************************/
  /**
  * Handler for the READ event on ProductLog.
  * Retrieves log data from SingleAssessment, MassAssessmentHeader, and MassAssessmentItems 
  * entities, and maps the results into the ProductLog structure.
  * @param {Object} req - The request object containing query parameters.
  * @returns {Array} The product log data retrieved and merged from multiple sources.
  */
  srv.on('READ', 'ProductLog', async (req) => {
    const oDb = await cds.connect.to('db');

    // Define references to entities in the 'management' namespace
    const oSingleAssessment = oDb.entities["management.SingleAssessment"],
      oMassAssessmentHeader = oDb.entities["management.MassAssessmentHeader"],
      oCategory = oDb.entities["management.SustainabilityCategory"],
      oContributor = oDb.entities["management.Contributor"],
      oSustClass = oDb.entities["management.SustainabilityClass"];

    try {

      /* const aFilters = req.query.SELECT.where || [];
       //If there are already conditions, add an ‘AND’ operator.'
       if (aFilters.length > 0) {
         aFilters.push("and");
       }
 
       // Add status filter = '05' Approved
       aFilters.push({ ref: ["status"] }, "=", { val: "05" });*/

      const aFilters = [
        ...(req.query.SELECT.where || []),
        ...(req.query.SELECT.where ? ["and"] : []),
        { ref: ["status"] }, "=", { val: "05" },
        "and",
        "(",
        { ref: ["communicationStatus"] }, "=", { val: "05" },
        "or",
        { ref: ["communicationStatus"] }, "=", { val: null },
        ")"
      ];

      // 1. Fetch data from SingleAssessment entity
      const aSingleAssessment = await cds.run(
        SELECT.from(oSingleAssessment)
          .where(aFilters)
          .orderBy({ approvalDate: 'asc' })
      );

      // 1. Fetch data from MassAssessment entity
      const aMassAssessment = await cds.run(SELECT.from(oMassAssessmentHeader, header => {
        header.ID,
          header.requestName,
          header.sbu,
          header.assessor,
          header.submitter,
          header.submitionDate,
          header.approver,
          header.approvalDate,
          header.toItems(items => {
            items.ID,
              items.modifiedAt,
              items.approver,
              items.product,
              items.approvalDate,
              items.comment,
              items.rcPreFlag,
              items.rcPreFlagDescription,
              items.sustClass,
              items.category1,
              items.contributor1,
              items.category2,
              items.contributor2,
              items.category3,
              items.contributor3,
              items.propagation
          }).where(aFilters);
      }));

      // Manually sort items by approvalDate after retrieving the data
      aMassAssessment.forEach(massAssessmentHeader => {
        massAssessmentHeader.toItems.sort((firstItem, secondItem) => {
          // Convert the approvalDate to Date objects and subtract to compare
          return new Date(firstItem.approvalDate) - new Date(secondItem.approvalDate);
        });
      });
      const aSustClass = await cds.run(SELECT.from(oSustClass));
      const aCategory = await cds.run(SELECT.from(oCategory));
      const aContributor = await cds.run(SELECT.from(oContributor));

      // 3. Combine the data from both entities into the ProductLog structure
      const aProductLogs = [];

      // Create maps for quick lookup
      const sustClassMap = new Map(aSustClass.map(item => [item.code, item.description]));
      const categoryMap = new Map(aCategory.map(item => [item.code, item.description]));
      const contributorMap = new Map(aContributor.map(item => [item.code, item.description]));

      // Process SingleAssessments and map to ProductLog structure
      aSingleAssessment.forEach(oSingleAssessment => {
        aProductLogs.push({
          ID: oSingleAssessment.ID,  // Map SingleAssessment ID
          modifiedAt: oSingleAssessment.modifiedAt,
          requestName: oSingleAssessment.requestName,
          sbu: oSingleAssessment.sbu,
          product: oSingleAssessment.product,
          productName: '',
          assessor: oSingleAssessment.assessor,
          submitter: oSingleAssessment.submitter,
          submitionDate: oSingleAssessment.submitionDate,
          approver: oSingleAssessment.approver,
          approvalDate: oSingleAssessment.approvalDate,
          comment: oSingleAssessment.comment,
          rcPreFlag: oSingleAssessment.rcPreFlag,
          rcPreFlagDescription: oSingleAssessment.rcPreFlagDescription,
          sustClass: oSingleAssessment.sustClass,
          sustClassDescription: sustClassMap.get(oSingleAssessment.sustClass) || '', // Map the description
          category1: oSingleAssessment.category1,
          category1Description: categoryMap.get(oSingleAssessment.category1) || '', // Map the description
          contributor1: oSingleAssessment.contributor1,
          contributor1Description: contributorMap.get(oSingleAssessment.contributor1) || '', // Map the description
          category2: oSingleAssessment.category2,
          category2Description: categoryMap.get(oSingleAssessment.category2) || '', // Map the description
          contributor2: oSingleAssessment.contributor2,
          contributor2Description: contributorMap.get(oSingleAssessment.contributor2) || '', // Map the description
          category3: oSingleAssessment.category3,
          category3Description: categoryMap.get(oSingleAssessment.category3) || '', // Map the description
          contributor3: oSingleAssessment.contributor3,
          contributor3Description: contributorMap.get(oSingleAssessment.contributor3) || '', // Map the description
          propagation: oSingleAssessment.propagation
        });
      });

      // Process MassAssessmentHeaders and MassAssessmentItems and map to ProductLog structure
      aMassAssessment.forEach(oMassAssessment => {
        oMassAssessment.toItems.forEach(item => {
          aProductLogs.push({
            ID: item.ID,
            modifiedAt: item.modifiedAt,
            requestName: oMassAssessment.requestName,
            sbu: oMassAssessment.sbu,
            product: item.product,
            productName: '',
            assessor: oMassAssessment.assessor,
            submitter: oMassAssessment.submitter,
            submitionDate: oMassAssessment.submitionDate,
            approver: item.approver,
            approvalDate: item.approvalDate,
            comment: item.comment,
            rcPreFlag: item.rcPreFlag,
            rcPreFlagDescription: item.rcPreFlagDescription,
            sustClass: item.sustClass,
            sustClassDescription: sustClassMap.get(item.sustClass) || '', // Map the description
            category1: item.category1,
            category1Description: categoryMap.get(item.category1) || '', // Map the description
            contributor1: item.contributor1,
            contributor1Description: contributorMap.get(item.contributor1) || '', // Map the description
            category2: item.category2,
            category2Description: categoryMap.get(item.category2) || '', // Map the description
            contributor2: item.contributor2,
            contributor2Description: contributorMap.get(item.contributor2) || '', // Map the description
            category3: item.category3,
            category3Description: categoryMap.get(item.category3) || '', // Map the description
            contributor3: item.contributor3,
            contributor3Description: contributorMap.get(item.contributor3) || '', // Map the description
            propagation: item.propagation
          });
        });
      });

      if (aProductLogs.length > 0) {
        aProductLogs.sort((a, b) =>{
          // If no approval date modification one is used (virtual assessment case)
          const sDateA = a.approvalDate || a.modifiedAt.split('T')[0];
          const sDateB = b.approvalDate || b.modifiedAt.split('T')[0];

          // If order ccan be determined by first compare, return it
          const sFirstCompare = sDateA.localeCompare(sDateB);
          if (sFirstCompare != 0) return sFirstCompare;

          // If comparing approval dates was equal, compare full modification dates
          return a.modifiedAt.localeCompare(b.modifiedAt);
        });
      }


      // Return the combined product log data
      return aProductLogs;

    } catch (error) {
      // Handle errors
      console.error('Error retrieving ProductLog data:', error);
      req.error(409, "Error reading product log data");
    }
  });

  /***********************************************************
  *
  * Functions
  *
  ************************************************************/

  srv.on('GetUserParameters', async (req) => {

    const oUserParameters = userParameters(req.user);

    return oUserParameters;

  });

  srv.on('GetUserRole', async (req) => {
    const oUserParameters = userParameters(req.user);

    return oUserParameters.role;

  });

  srv.on('GetAssessmentsUser', async (req) => {
    let assessmentsByStatus = {
      started: 0,
      submited: 0,
      underReSubmitted: 0,
      approved: 0
    };

    //const { sbu, role } = req.data;
    const db = await cds.connect.to('db');
    const MassAssessmentHeader = db.entities["management.MassAssessmentHeader"];
    const SingleAssessment = db.entities["management.SingleAssessment"];

    const dynamicQuery = assessmentsCountQuery(SingleAssessment, MassAssessmentHeader, req.user.id);//sbu, role, req.user.id);

    const resultsSingleAssessment = await db.run(dynamicQuery.singleAssessment);
    const resultsMassAssessment = await db.run(dynamicQuery.massAssessmentHeader);

    const results = [...resultsSingleAssessment, ...resultsMassAssessment];

    results.forEach(result => {
      switch (result.status) {
        case '01':
          assessmentsByStatus.started += result.assessments;
          break;
        case '02':
          assessmentsByStatus.submited += result.assessments;
          break;
        case '03':
          assessmentsByStatus.underReSubmitted += result.assessments;
          break;
        case '04':
          assessmentsByStatus.submited += result.assessments;
          break;
        case '05':
          assessmentsByStatus.approved += result.assessments;
          break;
        default:
          break;
      }
    });

    return assessmentsByStatus;
  });


  srv.on('GetProductMasterdata', async (req) => {
    const aProducts = req.data.product.split(','),
      sType = req.data.productType;

    if (sType === "IB") {
      // aProductData = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IBPRODUCT').where({ IB_PRODUCT_NUMBER: aProducts }));
      try {
        const aIb = await srv.read("Ib").where({ materialtNumber: aProducts });
        const aMappedProductData = aIb.map(item => {
          const oMap = {
            product                     : item.materialtNumber,
            type                        : "IB",
            productName                 : item.materialDescription,
            sbu                         : item.sbu,
            rcPreFlag                   : item.rcPreFlag,
            rcPreFlagDescription        : item.rcPreFlagDescription,
            technologyL2Key             : item.technologyL2,
            technologyLevel2            : item.technologyL2Description,
            sustainabilityClassCode     : item.sustClass,
            existingSustainabilityClass : item.sustClassDescription,
            realSubstanceCode           : item.realSubstanceCode,
            realSubstanceName           : item.realSubstanceName,
            applicationLevel2Key        : item.applicationL2,
            applicationLevel2           : item.applicationL2Description,
            lastAssessment              : item.approvalDate,
            lastSubmitter               : item.submitter,
            lastApprover                : item.approver,            
          };
          return oMap;
        });
        return aMappedProductData;
      } catch(e) {

      }
    } else {
      // aProductData = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IDH').where({ IDH_MATERIAL_NR: aProducts }));
      try {
        const aIb = await srv.read("Idh").where({ materialtNumber: aProducts });
        const aMappedProductData = aIb.map(item => {
          const oMap = {
            product                     : item.materialtNumber,
            type                        : "IDH",
            productName                 : item.materialDescription,
            sbu                         : item.sbu,
            rcPreFlag                   : item.rcPreFlag,
            rcPreFlagDescription        : item.rcPreFlagDescription,
            technologyL2Key             : item.technologyL2,
            technologyLevel2            : item.technologyL2Description,
            sustainabilityClassCode     : item.sustClass,
            existingSustainabilityClass : item.sustClassDescription,
            realSubstanceCode           : item.realSubstanceCode,
            realSubstanceName           : item.realSubstanceName,
            applicationLevel2Key        : item.applicationL2,
            applicationLevel2           : item.applicationL2Description,
            lastAssessment              : item.approvalDate,
            lastSubmitter               : item.submitter,
            lastApprover                : item.approver,            
          };
          return oMap;
        });
        return aMappedProductData;
      } catch(e) {

      }
    }
    // const aTranslatedProductData = translateVtResultsToProductData(aProductData);

    // return aTranslatedProductData;
  });

  srv.on('getRelatedProductsData', async (req) => {
    const sProductType = req.data.productType,
      sProduct = req.data.product;

    let aProducts = [];
    var aProductData = [];

    if (sProductType === 'IB') {
      aProducts = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IB_IDH')
        .columns('MATERIAL_KEY')
        .where({ AI_PRODUCT_KEY: sProduct }));
      const aTransformedArray = aProducts.map(product => product.MATERIAL_KEY);
      if (aTransformedArray.length > 0) {
        aProductData = (await srv.read(
          "Idh",
          [
            'materialtNumber',
            'materialDescription',
            'realSubstanceCode',
            'sustClass',
            'sustClassDescription'
          ]
        )
          .where({ materialtNumber: aProducts.map(item => item.MATERIAL_KEY) }))
          .map(item => {
            return {
              product: item.materialtNumber,
              productName: item.materialDescription,
              realSubstanceCode: item.realSubstanceCode,
              sustClass: item.sustClass,
              sustClassDescription: item.sustClassDescription,
            }
          });
      }
    } else {
      aProducts = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IB_IDH')
        .columns('AI_PRODUCT_KEY')
        .where({ MATERIAL_KEY: sProduct }));
      const aTransformedArray = aProducts.map(product => product.AI_PRODUCT_KEY);
      if (aTransformedArray.length > 0) {
        aProductData = (await srv.read(
          "Ib",
          [
            'materialtNumber',
            'materialDescription',
            'realSubstanceCode',
            'sustClass',
            'sustClassDescription'
          ]
        )
          .where({ materialtNumber: aProducts.map(item => item.AI_PRODUCT_KEY) }))
          .map(item => {
            return {
              product: item.materialtNumber,
              productName: item.materialDescription,
              realSubstanceCode: item.realSubstanceCode,
              sustClass: item.sustClass,
              sustClassDescription: item.sustClassDescription,
            }
          });
      }
    }
    return aProductData;
  })

  srv.on('getIbLinkedToIdh', async (req) => {
    const aMaterials = Array.isArray(req.data.materials) ? req.data.materials : req.data.materials?.split(',');

    let aProducts = [];

    aProducts = await cds.run(SELECT.from('COM_SUSTAINABILITY_VT_V_IB_IDH')
      .columns('MATERIAL_KEY as material', 'AI_PRODUCT_KEY as product')
      .where({ MATERIAL_KEY: aMaterials }));

    return aProducts;
  })

  srv.on('getProductDocuments', async (req) => {
    const aProducts =req.data.product.split(',');

    const oDb = await cds.connect.to('db');

    const oSingleAssessment = oDb.entities["management.ProductProofDocumentRelation"];

    const MAX_PACKAGE_SIZE = 1000;
    const aProofDocuments = [];
    let aPackage = [];
    for (const product of aProducts) {
      aPackage.push(product);

      if (aPackage.length === MAX_PACKAGE_SIZE) {
        const aProofDocumentsPackage = await SELECT.from(oSingleAssessment).where({product: aPackage});
        aProofDocuments.push(...aProofDocumentsPackage);
        aPackage = [];
      }
    }
    if (aPackage.length !== 0) {
      const aProofDocumentsPackage = await SELECT.from(oSingleAssessment).where({product: aPackage});
      aProofDocuments.push(...aProofDocumentsPackage);
      aPackage = [];
    }
    aProofDocuments.forEach((oProofDocument) => {
      if (oProofDocument.fileName && !oProofDocument.externalUrl) {
        let sFormatUUID = oProofDocument.proofPointId.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
        oProofDocument.url = "ProductProofDocument(product='" + oProofDocument.product + "',proofPointId=" + sFormatUUID + ")/content";
      }
    });

    return aProofDocuments;

  });

  srv.on("GetRulesModel", handlers.functions.GetRulesModel);
  srv.on('checkProductInAssessment', handlers.functions.checkProductInAssessment);
  srv.on('GetUserFromMyId', handlers.functions.GetUserFromMyId);
  srv.on('getHeartDeltaData', 'MassAssessmentItems', handlers.functions.getHeartDeltaData);

  /***********************************************************
  *
  * Actions
  *
  ************************************************************/

  /**
      * Processing of function getStatus on the MassAssessmentHeader entity.
      * Gets the status of the mass assessment evaluating all of its single assessments status
      * 
      * @param {Object} req - The request object containing the MassAssessmentHeader data after read operation.
      * @returns {Object} Status of the request
      */
  srv.on("setStatus", "MassAssessmentHeader", async (req) => {
    // Retrieve header ID
    const sHeaderId = req.params[0];

    // Retrieve related items
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities["management.MassAssessmentItems"];
    const oMassAssessmentHeader = oDb.entities["management.MassAssessmentHeader"];
    const aItems = await SELECT.from(oMassAssessmentItems).where({ headerId: sHeaderId });

    const STATUS_SAVED = "O1";
    const STATUS_SUBMITTED = "02";
    const STATUS_APPROVED = "05";
    const STATUS_REJECTED = "06";
    const STATUS_UNDER_REVIEW = "07";
    const STATUS_FINALIZED = "08";

    // If every status is submitted or saved, set the header status to the same as items
    const bStatusSubmitted = !aItems.some(item => item.status !== STATUS_SUBMITTED);
    const oSet = {};
    oSet.status = bStatusSubmitted ? STATUS_SUBMITTED : undefined;

    if (!oSet.status) {
      const bStatusSaved = !aItems.some(item => item.status !== STATUS_SAVED);
      oSet.status = bStatusSaved ? STATUS_SAVED : bStatusSaved;
    }

    if (!oSet.status) {

      // If any of the items is not approved or rejected, the it is under review. Else, it is finalized
      const bAllAssessmentFinished = !aItems.some(item => {
        return item.status !== STATUS_APPROVED && item.status !== STATUS_REJECTED;
      });
      oSet.status = bAllAssessmentFinished ? STATUS_FINALIZED : STATUS_UNDER_REVIEW;

      // Get communication status
      if (bAllAssessmentFinished) {
        const bAllProcessed = !aItems.some(item => item.communicationStatus !== COMMUNICATION_STATUS.COMPLETED);
        if (bAllProcessed) {
          oSet.communicationStatus = COMMUNICATION_STATUS.COMPLETED;
        } else {
          oSet.communicationStatus = COMMUNICATION_STATUS.PENDING;
        }
      }

      if (aItems.some(item => item.status === STATUS_APPROVED && !item.virtualAssessment)) {
        oSet.approvalDate = new Date().toISOString().slice(0, 10);
      }

      // If status is under review, the first time approver is set
      const oHeader = await SELECT.one.from(oMassAssessmentHeader).where({ ID: sHeaderId });
      if (!oHeader.virtualAssessment && (!oHeader.approver || oHeader.approver === "")) {
        oSet.approver = req.user.id;
      }

      // }

    }

    // Update header
    await UPDATE(oMassAssessmentHeader, sHeaderId).set(oSet);

    // Return new status
    return `New header status for mass assesstment header ${sHeaderId} set to ${oSet.status}`;
  });

  srv.on("updateMassAssessmentItemsBatch", async (req, data) => {
    return await updateMassAssessmentItemsBatch(req, bucketName, s3);
  });

  srv.on("SubmitMassAssessment", handlers.actions.SubmitMassAssessment)
  srv.on("MassUploadDocuments", async (req) => {
    return await handlers.actions.MassUploadDocuments(req, bucketName, s3);
  })
  srv.on("submitProofpointsVirtualAssessment", handlers.actions.submitProofpointsVirtualAssessment)
  srv.on("SaveMassAssessment", handlers.actions.SaveMassAssessment);
  srv.on("IdhOverwrite", handlers.actions.IdhOverwrite);
  srv.on("saveRecipients", handlers.actions.saveRecipients);


  /***********************************************************
    *
    * Events
    *
    ************************************************************/
  srv.on("assessmentSaved", handlers.events.assessmentSaved);
  srv.on("assessmentSubmitted", handlers.events.assessmentSubmitted);
  srv.on("assessmentResubmitted", handlers.events.assessmentResubmitted);
  srv.on("assessmentUnderResubmission", handlers.events.assessmentUnderResubmission);

};