using com.sustainability.types as types from '../db/types';
using com.sustainability.background as background from '../db/schema';
/**
 * Service dedicated to background processess
 */
@requires: 'authenticated-user'
service SustainabilityBackgroundService {

    /** 
     * Projection of the log table for assessments with RC Pre-flag and Sustainability Class mismatches 
     */
    entity RcPreflagSustClassMismatchedAssessmentLog as projection on background.RcPreflagSustclassMismatchedAssessmentLog;

      /** 
     * Projection of the log table for jobs of  RC Pre-flag and Sustainability Class mismatches 
     */
    entity MismatchedAssessmentJobExecutionLogs as projection on background.MismatchedAssessmentJobExecutionLogs;

    /**
     *  Projection of the mapping table defining valid combinations of RC Pre-flag and Sustainability Class 
     */
    entity RCPreFlagToSustClassMismatchMapping as projection on background.RCPreFlagToSustClassMismatchMapping;

    /** Triggering of heart Assessment Creation */
    action heartAssessmentCreation (
        sbu: types.sbu,
        products: array of types.product,
        status: String(2),
        heartRunId: String,
    ) returns String; 

    /** Triggering of heart Assessment Creation */
    action rcPcAssessmentCreation (
        sbu: types.sbu,
        products: array of types.product,
        status: String(2),
        runId: String,
    ) returns String; 

    /**
     * PDP automatic assessment creation
     */
    action pdpAssessmentCreation(sbu: types.sbu,
                                 productType: types.productType,
                                 projectId: types.projectId,
                                 products: array of types.product,
                                 status: types.pdpProcessingStatus) returns String;
    /**
     * MOC automatic assessment creation
     */
    action mocAssessmentCreation(sbu: types.sbu,
                                 productType: types.productType,
                                 projectId: types.projectId,
                                 products: array of types.product,
                                 status: types.mocProcessingStatus) returns String;

    
    /**
    * Automatic creation of assessments for products with RC Pre-flag / Sustainability Class mismatch
    */
    action sustClassMismatchAssessmentCreation (
                                         sbu: types.sbu,
                                         products: array of types.product
                                        ) returns String;

// Sync log to track job execution
    entity DataSyncLog {
        key syncId       : UUID;
            tableName    : String(100);
            startTime    : Timestamp;
            endTime      : Timestamp;
            recordCount  : Integer;
            status       : String(20); // SUCCESS, FAILED, PARTIAL
            errorMessage : String(5000);
    }

    /** Data Sync Actions */
    action syncPdpDataFromDataSphere() returns {
        status  : String;
        message : String;
        summary : array of {
            tableName   : String;
            status      : String;
            recordCount : Integer;
            message     : String;
        };
    };
    
    action syncMocDataFromDataSphere() returns {
        status  : String;
        message : String;
        summary : array of {
            tableName   : String;
            status      : String;
            recordCount : Integer;
            message     : String;
        };
    };
    /**
     * PDP assessment save notification
     */
    event pdpAssessmentSaved {
        sbu          : types.sbu;
        assessmentId : UUID;
        type         : String(6) enum {
            MASS;
        };
    };

    /**
     * PDP assessment submit notification
     */
    event pdpAssessmentSubmitted {
        sbu          : types.sbu;
        assessmentId : UUID;
        type         : String(6) enum {
            MASS;
        };
    };

    /**
     * MOC assessment save notification
     */
    event mocAssessmentSaved {
        sbu          : types.sbu;
        assessmentId : UUID;
        type         : String(6) enum {
            MASS;
        };
    };

    /**
     * RCPREFLAG_MISMATCH assessment save notification
     */
    event rcPreFlagMismatchAssessmentCreated {
        sbu          : types.sbu;
        assessmentId : UUID;
        type         : String(6) enum {
            MASS;
        };
    };

    /**
     * Notification of assessments which are blocking prodcuts for other assessment creation
     */
    event backgroundAssessmentCreationBlocking {
        blockingAssessment : array of types.assessmentBlocked;
        type               : String(6) enum {
            PDP;
            MOC;
        };
    };

    /**
     * Notification of products which are blocked
     */
    event productsBlockedPdpMoc {
        blockedProducts : array of types.assessmentBlocked;
        sbu             : types.sbu;
        type            : String(6) enum {
            PDP;
            MOC;
        };
        adpProject: types.projectId;
    };

    /**
     * Notification for HEART assessment saved
     */
    event heartAssessmentSaved {
        sbu          : types.sbu;
        assessmentId : UUID;
    }

    /**
     * Notification for HEART assessment submitted
     */
    event heartAssessmentSubmitted {
        sbu          : types.sbu;
        assessmentId : UUID;
    }

    /**
     * Notification of assessments which are blocking products for Heart assessment creation
     */
    event heartAssessmentProductsBlocked {
        sbu             : types.sbu;
        blockedProducts : array of types.blockedProdcuts;
        blockingAssessment : array of types.assessmentBlocked;
    };

   /**
     * Notification for RCPC assessment submitted
     */
    event rcPcAssessmentSubmitted {
        sbu          : types.sbu;
        assessmentId : UUID;
    }

      /**
     * Notification for RCPC assessment saved
     */
    event rcPcAssessmentSaved {
        sbu          : types.sbu;
        assessmentId : UUID;
    }
}
