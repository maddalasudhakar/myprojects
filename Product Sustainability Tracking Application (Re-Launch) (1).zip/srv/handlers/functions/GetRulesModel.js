const {getRules} = require("../../JS/rules-model/rules-model");
const {stringify} = require("../../JS/json-utils");

async function GetRulesModel(req) {
    const oRules = await getRules();
    const sRulesStringified = await stringify(oRules);
    return sRulesStringified;
};

module.exports = {
    GetRulesModel,
}