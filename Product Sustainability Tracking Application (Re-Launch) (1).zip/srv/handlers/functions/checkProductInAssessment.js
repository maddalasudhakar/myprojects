
async function checkProductInAssessment (req, next) {
    const aProducts = JSON.parse(req.data.products);

    const db = await cds.connect.to('db');
    const AssessmentProducts = db.entities["management.AssessmentProducts"];

    if (!aProducts || aProducts.length === 0) {
        return [];  // If no products are sent, there is nothing to check.
    }

    const aAssessmentProducts = await SELECT.from(AssessmentProducts)
    .where({
      product: { in: aProducts },
      and: { status: { 'not in': ['05', '06'] }, or: { communicationStatus : { 'not in': ['05', ''] } } } } )
    .columns('product', 'requestName');

    return aAssessmentProducts;    

};

module.exports = {
    checkProductInAssessment,
}