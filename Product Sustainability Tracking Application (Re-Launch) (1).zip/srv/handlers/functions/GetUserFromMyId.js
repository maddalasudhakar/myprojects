const { getMyIdUsers } = require("../../JS/notification-utils.js");


/**
 * Retrieves users from the Assessment Notification Service based on role.
 *
 * @param {Object} req - The incoming request object.
 * @param {string} req.data.sbu - SBU code.
 * @param {string} req.data.status - Status code .
 * @param {string} req.data.processType - Process type (optional).
 * @returns {Promise<Array>} Array of users matching the computed role.
 */
async function GetUserFromMyId(req) {

    const { sbu, status, processType } = req.data;

    if (!req.data.status || !req.data.sbu) {
        req.error(403, "Status and sbu must not be empty");
        return;
    }

    const aUsers = await getMyIdUsers({ sbu, status, processType });
    return aUsers;

};

module.exports = {
    GetUserFromMyId,
}