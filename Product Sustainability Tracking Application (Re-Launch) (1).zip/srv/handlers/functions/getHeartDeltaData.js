const cds = require('@sap/cds');
const { 
    getMassAssessmentItemById, 
    getMassAssessmentHeaderById, 
    getMassAssessmentItemAdditionalDataByProcess,
    ASSESSMENT_PROCESS,
 } = require('../../JS/assessment');

/** Possible delta line types */
const HEART_DELTA_LINE_TYPE = {
    LAST: 'LAST',
    NEW: 'NEW',
    DIFF: 'DIFF',
};

/**
 * Handler for getHeartDeltaData function import
 * 
 * @param {cds.Request} req - Request made 
 */
async function getHeartDeltaData(req) {

    const [ sItemId ] = req.params;

    // Get mass assessment item data
    const oAssessmentItem = await getMassAssessmentItemById( sItemId, ['headerId', 'toAdditionalData_ID'] );

    // Get assessment header 
    const oAssessmentHeader = await getMassAssessmentHeaderById(oAssessmentItem.headerId);
    
    // Function is only valid for HEART assessments
    const bIsAllowedForFunction = oAssessmentHeader.processType === ASSESSMENT_PROCESS.HEART;
    if (!bIsAllowedForFunction)     return req.error(409, 'Function not allowed');

    // Retrieve mass assessment additional Item
    const oAdditionalData = await getMassAssessmentItemAdditionalDataByProcess({
        ID: oAssessmentItem.toAdditionalData_ID, 
        processType: ASSESSMENT_PROCESS.HEART, 
    }); 

    // Compose result
    const oFirstLine = {
        lineType: HEART_DELTA_LINE_TYPE.LAST, 
    };
    const oSecondLine = {
        lineType: HEART_DELTA_LINE_TYPE.NEW, 
    };
    for (const key in oAdditionalData) {
        // Last line fields are filled
        if (key.startsWith("last_")) {
            const sNewKey = key.slice(5); 
            oFirstLine[sNewKey] = oAdditionalData[key];
        }        
        if (key.startsWith("new_")) {
            const sNewKey = key.slice(4);
            oSecondLine[sNewKey] = oAdditionalData[key];

            // Round numbers up to 2 decimal places
            if (typeof oSecondLine[sNewKey] === 'number') {
                oSecondLine[sNewKey] = oSecondLine[sNewKey].toFixed(2);
            }
        }
    }   
    
    // Fill third line with delta if applies
    const FIELDS_FOR_DELTA = ['pcfClusterBenchmark', 'pcfExcl'];
    const oThirdLine = {};
    for (const key in oFirstLine) {
        if (FIELDS_FOR_DELTA.includes(key)) {
            oThirdLine[key] = oSecondLine[key] - oFirstLine[key];
        } else {
            oThirdLine[key] = null;
        }
    }
    oThirdLine.lineType = HEART_DELTA_LINE_TYPE.DIFF;

    return [
        oFirstLine,
        oSecondLine,
        oThirdLine,
    ];
    

};

module.exports = {
    getHeartDeltaData,
};