const functions = require("./functions");
const actions = require("./actions");
const events = require("./events");

module.exports = {
    functions,
    actions,
    events,
}