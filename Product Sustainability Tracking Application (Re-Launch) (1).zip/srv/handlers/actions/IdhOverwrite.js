const cds = require("@sap/cds");
const functions = require("./../functions");

async function IdhOverwrite(req) {
    const DEBUG = cds.log('DEBUG-OVERWRITE');
    try {

        const aMaterialList = req.data.products;
        const oRulesModel = functions.GetRulesModel();

        const oDb = await cds.connect.to('db');
        const oProductProofDocumentRelation = oDb.entities["management.ProductProofDocumentRelation"],
            AssessmentProducts = oDb.entities["management.AssessmentProducts"],
            oMassAssessmentHeaderTable = oDb.entities["management.MassAssessmentHeader"];


        var aAssessments = [],
            aErrorFeedback = [];

        const aIbNumbers = aMaterialList.map(oMaterial => oMaterial.assessment.product);
        const aIdhNumbers = aMaterialList.map(oMaterial => oMaterial.material);

        const aAllproducts = [...aIbNumbers, ...aIdhNumbers];
        const cqn4 = cds.parse.expr;
        const sIdhs = aIdhNumbers.map(s => `'${s}'`).join(', ')
        const sIdhCondition = aIdhNumbers.length > 1 
            ? `product in (${sIdhs})`
            : `product = ('${aIdhNumbers[0]}')`;
        const oWhere = cqn4(`
            ${sIdhCondition}
            and (
                status not in ('05', '06') 
                or (
                    status in ('05', '06') 
                    and communicationStatus != '05' 
                    and communicationStatus is not null
                )
            )
        `);           
        const aAssessmentProducts = await SELECT.from(AssessmentProducts)
            .where([oWhere]);

        const aMatchedProducts = aAssessmentProducts.filter(oProduct => aIdhNumbers.includes(oProduct.product));

        //Get proofPoints related with the IBs
        const aProofDocuments = await SELECT.from(oProductProofDocumentRelation).where({ product: aAllproducts });


        // Build unique idhSbu and headerId combinations
        const aUniqueGroups = Array.from(
            new Map(
                aMaterialList.map(item => {
                    const key = `${item.idhSbu}_${item.assessment.headerId}`;
                    return [key, {
                        idhSbu: item.idhSbu,
                        headerId: item.assessment.headerId
                    }];
                })
            ).values()
        );

        // Group items
        const aIdhBySbuHeaderID = aUniqueGroups.map(({ idhSbu, headerId }) => ({
            idhSbu,
            headerId,
            items: aMaterialList
                .filter(item =>
                    item.idhSbu === idhSbu &&
                    item.assessment.headerId === headerId
                )
                .map(item => ({
                    material: item.material,
                    idhSbu: item.idhSbu,
                    idhRcPreFlag: item.idhRcPreFlag,
                    idhRcPreFlagDescription: item.idhRcPreFlagDescription,
                    ...item.assessment
                }))
        }));

        for (const oData of aIdhBySbuHeaderID) {

            let aItems = [];

            oData.items.forEach(oItem => {

                if (aMatchedProducts.some(oMatchedProdcuts => oMatchedProdcuts.product === oItem.material)) {
                    aErrorFeedback.push({
                        material: oItem.material,
                        product: oItem.product,
                        message: "Product in assessment",
                        assessmentID: oItem.ID
                    });
                    return;
                }

                // Build a list of relevant product IDs to match documents
                const relevantProducts = [
                    oItem.material,
                    oItem.product
                ].filter(Boolean);

                // Filter and map proof documents for the relevant products
                const aMappedDocuments = aProofDocuments
                    .filter(oDocument => relevantProducts.includes(oDocument.product))
                    .map(oDocument => {
                        const isFromIDH = oDocument.product === oItem.material;
                        return {
                            type: oDocument.type,
                            description: oDocument.description,
                            internalPath: "",
                            fileName: oDocument.fileName,
                            mediaType: oDocument.mediaType,
                            content: null,
                            active: isFromIDH
                                ? false
                                : oDocument.active !== null ? oDocument.active : true,
                            url: oDocument.url,
                            externalUrl: oDocument.externalUrl,
                            imageMasterID: oDocument.proofPointId,
                            productReference: !isFromIDH
                                ? oDocument.product
                                : oDocument.productReference
                        };
                    });

                let oItems = {
                    status: "05",
                    communicationStatus: "01",
                    product: oItem.material,
                    productType: "IDH",
                    comment: oItem.comment,
                    sustClass: oItem.sustClass,
                    category1: oItem.category1,
                    contributor1: oItem.contributor1,
                    category2: oItem.category2,
                    contributor2: oItem.contributor2,
                    category3: oItem.category3,
                    contributor3: oItem.contributor3,
                    rcPreFlag: oItem.idhRcPreFlag,
                    rcPreFlagDescription: oItem.idhRcPreFlagDescription,
                    sbu: oItem.idhSbu,
                    assessor: oItem.assessor,
                    submitter: oItem.submitter,
                    approver: oItem.approver,
                    //submitionDate: oItem.submitionDate,
                    approvalDate: oItem.approvalDate,
                    propagation: false,
                    externalCommunication: oItem.externalCommunication,
                    approberComment: oItem.approberComment,
                    idhAssessmentOverwrite: true,
                    virtualAssessment : oItem.virtualAssessment,
                    toProofDocuments: aMappedDocuments
                }

                aItems.push(oItems);
            });

            if (aItems.length > 0){
                let oMassAssessmentHeader = {
                    "requestName": oData.items[0].requestName,
                    "sbu": oData.sbu,
                    "virtualAssessment" : oData.items[0].virtualAssessment,
                    "assessor": oData.items[0].assessor,
                    "submitter": oData.items[0].submitter,
                    "submitionDate": oData.items[0].submitionDate,
                    "approvalDate": oData.items[0].approvalDate,
                    "approver": oData.items[0].approver,
                    "productType": "IDH",
                    "assesmentType": "M",
                    "status": "05",
                    "communicationStatus": "01",
                    "projectId": "",
                    "idhAssessmentOverwrite": true,
                    "toItems": aItems
                };
                aAssessments.push(oMassAssessmentHeader);
            }
        }

        if (aAssessments.length > 0) {

            await cds.run(INSERT.into(oMassAssessmentHeaderTable).entries(aAssessments));

        }
    } catch (error) {
        console.error('Error saving the data:', error);
        throw error;
    }
    return aErrorFeedback;

}

module.exports = {
    IdhOverwrite,
}