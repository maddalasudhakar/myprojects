const cds = require("@sap/cds");
const { 
    getHeartProductData, 
    buildHeartAssessment, 
    createHeartAssessment, 
    setHeartLogsAsFinished,
    setHeartLogsAsRetrial,
    checkValidProducts,
    VALIDATION_REASON,
} = require('../../JS/heart-assessment');

const { ASSESSMENT_STATUS } = require("../../JS/assessment");

/** Services available */
const SERVICES = {
    SUSTAINABILITY_BACKGROUND: 'SustainabilityBackgroundService',
};

/** Service resources consumed */
const RESOURCES = {
    EVENTS: {
        HEART_PRODUCTS_BLOCKED: 'heartAssessmentProductsBlocked',
        HEART_SAVED: 'heartAssessmentSaved',
        HEART_SUBMITTED: 'heartAssessmentSubmitted',
    }
};

/** Generic logger to use */
const logger = cds.log('heart-assessment-creation');

/**
 * Implementation for action heartAssessmentCreation
 * 
 * @param {cds.Request} req - Incoming request
 */
async function heartAssessmentCreation(req) {

    const { sbu, products, status, heartRunId } = req.data;
    
    // Filter only valid products
    const oCheckedProducts = await checkValidProducts(products);

    // Handle invalid products
    if (oCheckedProducts.invalidProducts && oCheckedProducts.invalidProducts.length > 0) {
        await setHeartLogsAsRetrial( oCheckedProducts.invalidProducts, sbu, status, heartRunId );

        // const aProductsBlocked = oCheckedProducts
        //     .invalidProducts
        //     .filter(item => item.reason === VALIDATION_REASON.PRODUCTS_BLOCKED);
        
        // // Emit event on blocking assessment
        // if (aProductsBlocked && aProductsBlocked.length > 0) {
        //     const BackgroundService = await cds.connect.to(SERVICES.SUSTAINABILITY_BACKGROUND);
        //     const aBlockedProducts = aProductsBlocked.map(item => ({
        //         requestName: item.blockingAssessment.requestName,
        //         product: item.product
        //     }));

        //     await BackgroundService.emit(
        //         RESOURCES.EVENTS.HEART_PRODUCTS_BLOCKED,
        //         {
        //             sbu: sbu,
        //             blockedProducts: aBlockedProducts,
        //             blockingAssessment: aProductsBlocked.map(item => item.blockingAssessment)
        //         },
        //     );

        // }
    }

    if (!oCheckedProducts.validProducts || oCheckedProducts.validProducts.length === 0) {
        return `No valid products to process`;
    }

    // Obtain product data from delta table
    const aProductsData = await getHeartProductData( 
        sbu, 
        oCheckedProducts.validProducts, 
        status, 
        heartRunId 
    );

    if (!aProductsData || aProductsData.length === 0) {
        return `No data found`;
    }    

    // Build assessment to create
    const { assessmentsToCreate, discardedProducts } = await buildHeartAssessment( aProductsData );

    // Create assessment
    if (assessmentsToCreate && assessmentsToCreate.length > 0){
        await createHeartAssessment( assessmentsToCreate );
    }
    // Set heart assessments to finished
    const aAssessmentsToFinish = [ ...assessmentsToCreate ];
    if (discardedProducts && discardedProducts.length > 0) {
        aAssessmentsToFinish.push({ items: discardedProducts });
    }

    await setHeartLogsAsFinished( aAssessmentsToFinish, sbu, status, heartRunId );

    const fnOnRequestSucceded = onRequestSucceededMaker(assessmentsToCreate);
    req.on('succeeded', fnOnRequestSucceded);

    return `Assessments created`;

};

/**
 * On request succeeded handler factory
 * 
 * @param {Object[]} aAssessmentsToCreate - Assessments to be created in service 
 * @returns {Function} Handler for onSucceeded request event
 */
 function onRequestSucceededMaker(aAssessmentsToCreate) {
    return async function () {
        cds.spawn(
            async tx => {
                const BackgroundService = await cds.connect.to(SERVICES.SUSTAINABILITY_BACKGROUND);
                for (const assessment of aAssessmentsToCreate) {
                    const sEvent = assessment.header.status === ASSESSMENT_STATUS.SAVED
                        ? RESOURCES.EVENTS.HEART_SAVED
                        : RESOURCES.EVENTS.HEART_SUBMITTED;
                    await BackgroundService.emit(sEvent, { sbu:assessment.header.sbu, assessmentId: assessment.header.ID })
                }
            }
        );
    };

};

module.exports = {
    heartAssessmentCreation,
};
