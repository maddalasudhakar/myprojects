const cds = require("@sap/cds");
const { PutObjectCommand} = require('@aws-sdk/client-s3');

const {
    uuid,
} = cds.utils;

/**
 * Action to post several documents to several mass assessment items at the same time
 * 
 * @param {*} req 
 * @param {*} bucketName 
 * @param {*} s3 
 */
async function MassUploadDocuments(req, bucketName, s3) {

    const aDocuments = req.data.documents;
    const aItems = req.data.items;

    
    for (const oDocument of aDocuments) {
        oDocument.objectStoreId = uuid();

        try {
            if (oDocument.content) {
                // Define parameters for S3 upload
                const objParams = {
                    Bucket: bucketName,
                    Key: oDocument.objectStoreId,
                    Body: Buffer.from(oDocument.content, 'base64'), // Convert content from base64
                    ContentType: oDocument.mediaType
                };

                // Upload the document to S3
                await s3.send(new PutObjectCommand(objParams));

                // Prepare the data for the AssessmentProofDocument entity
                oDocument.content = null; // Clear content after upload
                oDocument.internalPath = ""; // Set internal path if necessary
                oDocument.mediaType = null; // Clear media type
            }
            oDocument.internalPath = ""; // Set internal path if necessary

            const aNewDocuments = [];
            for (const oItem of aItems) {
                const oNewDocument = {
                    ...oDocument,
                };
                oNewDocument.requestId = oItem.ID;
                aNewDocuments.push(oNewDocument);
            }

            // Insert the new document metadata into the database
            const oDb = await cds.connect.to('db'); // Connect to the database
            const oAssessmentProofDocument = oDb.entities["management.AssessmentProofDocument"]; // Reference to AssessmentProofDocument entity
            await cds.run(INSERT.into(oAssessmentProofDocument).entries(aNewDocuments));
            return "Mass upload finished";
            // return req.data;
        } catch (error) {
            console.error('Error uploading document:', error);
            req.reject(409, 'Error uploading document to S3 and saving metadata');
        }

    }

}

module.exports = {
    MassUploadDocuments,
}