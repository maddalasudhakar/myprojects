const cds = require('@sap/cds');

/**
 * Sync MOC data from Data Sphere to local HANA tables
 * 
 * @param {cds.Request} req - Request made to service
 */
async function syncMocDataFromDataSphere(req) {
    // Use cds.spawn for long-running background operation
    cds.spawn(async () => {
        console.log('=== MOC Data Sync Started (Background) ===');
        
        const db = await cds.connect.to('db');
        const { 
            MocHeaderData
        } = db.entities('com.sustainability.background');
        
        const VT_MOC_DATA = 'COM_SUSTAINABILITY_VT_V_IDI_MOC_DATA';
        
        const syncResults = {
            overallStatus: 'SUCCESS',
            tables: []
        };
        
        const currentUser = 'SYSTEM';
        const currentTime = new Date();
        
        // ========== Sync MOC Header Data (2025+ only) ==========
        try {
            console.log('📊 Syncing MOC header data from Data Sphere (2025 onwards)...');
            
            // Filter at database level for simple date format
            const allVtData = await db.run(
                SELECT.from(VT_MOC_DATA)
                    .where({ FINAL_GATEKEEPER_MOC_EXECUTE_GATE_MEETING_DATE: { '>=': '2025-01-01' } })
            );
            
            console.log(`Found ${allVtData.length} MOC header records from 2025 onwards`);
            
            // Remove duplicates based on ADP_PROJECT_NUMBER + IDH_NUMBER composite key
            const uniqueMap = new Map();
            allVtData.forEach(record => {
                const key = `${record.ADP_PROJECT_NUMBER || ''}_${record.IDH_NUMBER || ''}`;
                if (!uniqueMap.has(key)) {
                    uniqueMap.set(key, record);
                }
            });
            
            const vtData = Array.from(uniqueMap.values());
            const duplicatesRemoved = allVtData.length - vtData.length;
            
            console.log(`After removing duplicates: ${vtData.length} unique records (removed ${duplicatesRemoved} duplicates)`);
            
            if (vtData.length > 0) {
                let totalUpserted = 0;
                let totalInserted = 0;
                let totalUpdated = 0;
                
                // Get existing records for comparison (using ADP_PROJECT_NUMBER + IDH_NUMBER as composite key)
                const existingRecords = await db.run(SELECT.from(MocHeaderData));
                const existingMap = new Map(
                    existingRecords.map(r => [
                        `${r.ADP_PROJECT_NUMBER || ''}_${r.IDH_NUMBER || ''}`,
                        r
                    ])
                );
                
                const batchSize = 1000;
                
                for (let i = 0; i < vtData.length; i += batchSize) {
                    const batch = vtData.slice(i, i + batchSize);
                    
                    for (const record of batch) {
                        const key = `${record.ADP_PROJECT_NUMBER || ''}_${record.IDH_NUMBER || ''}`;
                        const existingRecord = existingMap.get(key);
                        
                        const recordData = {
                            ADP_PROJECT_NUMBER: record.ADP_PROJECT_NUMBER || null,
                            IB_PROD_NUM: record.IB_PROD_NUM || null,
                            IDH_NUMBER: record.IDH_NUMBER || null,
                            SBU: record.SBU || null,
                            PROJECTED_SUSTAINABILITY_CLASS: record.PROJECTED_SUSTAINABILITY_CLASS || null,
                            PROJECTED_SUSTAINABILITY_CLASS_KEY: record.PROJECTED_SUSTAINABILITY_CLASS_KEY || null,
                            IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFIT: record.IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFIT || null,
                            IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY: record.IN_WHICH_AREA_DOES_THE_PROJECT_CREATE_A_BENEFITKEY || null,
                            HOW_IS_THE_BENEFIT_GENERATED: record.HOW_IS_THE_BENEFIT_GENERATED || null,
                            HOW_IS_THE_BENEFIT_GENERATED_KEY: record.HOW_IS_THE_BENEFIT_GENERATED_KEY || null,
                            WHICH_TIER_1_2_CHEMICALS_EXCEED_THE_THRESHOLDS: record.WHICH_TIER_1_2_CHEMICALS_EXCEED_THE_THRESHOLDS || null,
                            ASSESSOR_SUBMITTER: record.ASSESSOR_SUBMITTER || null,
                            SUSTAINABILITY: record.SUSTAINABILITY || null,
                            PROJECT_MANAGER: record.PROJECT_MANAGER || null,
                            FINAL_GATEKEEPER_MOC_EXECUTE_GATE_MEETING_DATE: record.FINAL_GATEKEEPER_MOC_EXECUTE_GATE_MEETING_DATE || null,
                            lastSyncedAt: currentTime,
                            modifiedAt: currentTime,
                            modifiedBy: currentUser
                        };
                        
                        if (existingRecord) {
                            // UPDATE existing record (preserve createdAt and createdBy)
                            await db.run(
                                UPDATE(MocHeaderData)
                                    .set(recordData)
                                    .where({ 
                                        ADP_PROJECT_NUMBER: record.ADP_PROJECT_NUMBER,
                                        IDH_NUMBER: record.IDH_NUMBER
                                    })
                            );
                            totalUpdated++;
                        } else {
                            // INSERT new record (set createdAt and createdBy)
                            recordData.createdAt = currentTime;
                            recordData.createdBy = currentUser;
                            await db.run(INSERT.into(MocHeaderData).entries(recordData));
                            totalInserted++;
                        }
                        totalUpserted++;
                    }
                    
                    console.log(`  Batch ${Math.floor(i / batchSize) + 1}: Processed ${batch.length} records`);
                }
                
                console.log(`✅ Successfully upserted ${totalUpserted} MOC header records (${totalInserted} inserted, ${totalUpdated} updated)`);
                syncResults.tables.push({
                    tableName: 'MocHeaderData',
                    status: 'SUCCESS',
                    recordCount: totalUpserted,
                    message: `Upserted ${totalUpserted} records (${totalInserted} new, ${totalUpdated} updated, ${duplicatesRemoved} duplicates removed)`
                });
            } else {
                console.log('⚠️  No MOC header data found in Data Sphere for 2025 onwards');
                syncResults.tables.push({
                    tableName: 'MocHeaderData',
                    status: 'SUCCESS',
                    recordCount: 0,
                    message: 'No records found from 2025 onwards'
                });
            }
        } catch (error) {
            console.error('❌ Error syncing MOC header data:', error);
            syncResults.overallStatus = 'PARTIAL';
            syncResults.tables.push({
                tableName: 'MocHeaderData',
                status: 'FAILED',
                recordCount: 0,
                message: error.message
            });
        }
        
        // Determine overall status
        const allFailed = syncResults.tables.every(t => t.status === 'FAILED');
        if (allFailed) {
            syncResults.overallStatus = 'FAILED';
        }
        
        console.log('=== MOC Data Sync Completed ===');
        console.log('Overall Status:', syncResults.overallStatus);
        console.log('Summary:', JSON.stringify(syncResults.tables, null, 2));
        
    });
    
    // Return immediately to avoid timeout
    return {
        status: 'STARTED',
        message: 'MOC data sync from Data Sphere has been initiated in the background. Check logs for progress.',
        summary: []
    };
}

module.exports = {
    syncMocDataFromDataSphere,
};