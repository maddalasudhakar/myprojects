const cds = require("@sap/cds");

/**
 * Action handler to save notification recipients.
 *
 * - Removes duplicates from the incoming payload.
 * - Checks if the recipient (by composite key: assessmentId + recipientEmail + assessmentStatus) already exists in the database.
 * - Inserts only new recipients using the original request transaction.
 *
 * @param {import('@sap/cds/apis/services').Request} req - The CAP service request containing recipients.
 * @returns {Promise<string[]>} Array of inserted recipient keys.
 */
async function saveRecipients(req) {
  // Connect to the database
  const oDb = await cds.connect.to("db");
  const oNotificationRecipients = oDb.entities["management.NotificationRecipients"];

  const { assessmentId, recipientEmail, status } = req.data;

  const aExistingRecipients = await cds.run(SELECT.from(oNotificationRecipients).where({ assessmentId: assessmentId, recipientEmail: recipientEmail, assessmentStatus: status }));

  const aExistingEmailsSet = new Set(
  (aExistingRecipients ?? []).map(row => row.recipientEmail)
);

  const aNewEmails = (recipientEmail ?? []).filter(
  emailAddress => !aExistingEmailsSet.has(emailAddress)
);

  const aEntriesToInsert = aNewEmails.map(email => ({
    assessmentId,
    recipientEmail: email,
    assessmentStatus: status
  }));

  try {
    // Insert only the new recipients
    if (aEntriesToInsert && aEntriesToInsert.length > 0) {
      await cds.run(INSERT.into(oNotificationRecipients).entries(aEntriesToInsert));
    }
  } catch (error) {
    console.error(error);
  }

  // Return inserted keys as strings
  return "Recipients saved"
}

module.exports = {
  saveRecipients,
}