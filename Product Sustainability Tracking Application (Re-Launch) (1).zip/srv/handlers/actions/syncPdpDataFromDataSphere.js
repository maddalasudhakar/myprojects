const cds = require('@sap/cds');

/**
 * Sync PDP data (Header + Proof Points) from Data Sphere to local HANA tables
 * 
 * @param {cds.Request} req - Request made to service
 */
async function syncPdpDataFromDataSphere(req) {
    // Use cds.spawn for long-running background operation
    cds.spawn(async () => {
        console.log('=== PDP Data Sync Started (Background) ===');
        
        const db = await cds.connect.to('db');
        const { 
            PdpHeaderData, 
            PdpProofPointsData
        } = db.entities('com.sustainability.background');
        
        const VT_HEADER = 'COM_SUSTAINABILITY_VT_V_IDI_HEADER_TABLE';
        const VT_PROOF_POINTS = 'COM_SUSTAINABILITY_VT_V_IDI_PROOF_POINT_DETAILS';
        
        const syncResults = {
            overallStatus: 'SUCCESS',
            tables: []
        };
        
        const currentUser = 'SYSTEM';
        const currentTime = new Date();
        
        let pdpProjectNumbers = []; // Store synced PDP project numbers for filtering proof points
        
        // ========== Sync PDP Header Data (2025+ only) ==========
        try {
            console.log('📊 Syncing PDP header data from Data Sphere (2025 onwards)...');
            
            // Fetch ALL data first, then filter in JavaScript
            const allVtData = await db.run(SELECT.from(VT_HEADER));
            console.log(`Total PDP header records in Data Sphere: ${allVtData.length}`);
            
            // Filter for 2025+ records in JavaScript
            const vtData2025Plus = allVtData.filter(record => {
                if (!record.FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE) return false;
                
                // Extract year from timestamp (format: 2016-01-11 00:00:00.000000000)
                const dateStr = record.FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE.toString();
                const year = parseInt(dateStr.substring(0, 4));
                
                return year >= 2025;
            });
            
            console.log(`Found ${vtData2025Plus.length} PDP header records from 2025 onwards`);
            
            // Remove duplicates based on ADP_PROJ_NUM + IDH_NUMBER composite key
            const uniqueMap = new Map();
            vtData2025Plus.forEach(record => {
                const key = `${record.ADP_PROJ_NUM || ''}_${record.IDH_NUMBER || ''}`;
                if (!uniqueMap.has(key)) {
                    uniqueMap.set(key, record);
                }
            });
            
            const vtData = Array.from(uniqueMap.values());
            const duplicatesRemoved = vtData2025Plus.length - vtData.length;
            
            console.log(`After removing duplicates: ${vtData.length} unique records (removed ${duplicatesRemoved} duplicates)`);
            
            if (vtData.length > 0) {
                let totalUpserted = 0;
                let totalInserted = 0;
                let totalUpdated = 0;
                
                // Get existing records for comparison (using ADP_PROJ_NUM + IDH_NUMBER as composite key)
                const existingRecords = await db.run(SELECT.from(PdpHeaderData));
                const existingMap = new Map(
                    existingRecords.map(r => [
                        `${r.ADP_PROJ_NUM || ''}_${r.IDH_NUMBER || ''}`,
                        r
                    ])
                );
                
                const batchSize = 1000;
                
                for (let i = 0; i < vtData.length; i += batchSize) {
                    const batch = vtData.slice(i, i + batchSize);
                    
                    for (const record of batch) {
                        const key = `${record.ADP_PROJ_NUM || ''}_${record.IDH_NUMBER || ''}`;
                        const existingRecord = existingMap.get(key);
                        
                        const recordData = {
                            ADP_PROJ_NUM: record.ADP_PROJ_NUM || null,
                            IB_PROD_NUM: record.IB_PROD_NUM || null,
                            IDH_NUMBER: record.IDH_NUMBER || null,
                            SBU: record.SBU || null,
                            ASSESSMENT_EXPLAINATION: record.ASSESSMENT_EXPLAINATION || null,
                            SUSTAINABILITY_CLASS: record.SUSTAINABILITY_CLASS || null,
                            SUSTAINABILITY_CLASS_KEY: record.SUSTAINABILITY_CLASS_KEY || null,
                            SUSTAINABILITY_CATEGORY_1: record.SUSTAINABILITY_CATEGORY_1 || null,
                            SUSTAINABILITY_CATEGORY_KEY: record.SUSTAINABILITY_CATEGORY_KEY || null,
                            SUSTAINABILITY_CONTRIBUTOR_1: record.SUSTAINABILITY_CONTRIBUTOR_1 || null,
                            SUSTAINABILITY_CONTRIBUTOR_KEY: record.SUSTAINABILITY_CONTRIBUTOR_KEY || null,
                            SUBMITTER: record.SUBMITTER || null,
                            ASSESSOR: record.ASSESSOR || null,
                            SUSTAINABILITY: record.SUSTAINABILITY || null,
                            PROJECT_MANAGER: record.PROJECT_MANAGER || null,
                            FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE: record.FINAL_GATEKEEPER_PD_LAUNCH_GATE_MEETING_DATE || null,
                            lastSyncedAt: currentTime,
                            modifiedAt: currentTime,
                            modifiedBy: currentUser
                        };
                        
                        if (existingRecord) {
                            // UPDATE existing record (preserve createdAt and createdBy)
                            await db.run(
                                UPDATE(PdpHeaderData)
                                    .set(recordData)
                                    .where({ 
                                        ADP_PROJ_NUM: record.ADP_PROJ_NUM,
                                        IDH_NUMBER: record.IDH_NUMBER
                                    })
                            );
                            totalUpdated++;
                        } else {
                            // INSERT new record (set createdAt and createdBy)
                            recordData.createdAt = currentTime;
                            recordData.createdBy = currentUser;
                            await db.run(INSERT.into(PdpHeaderData).entries(recordData));
                            totalInserted++;
                        }
                        totalUpserted++;
                    }
                    
                    console.log(`  Batch ${Math.floor(i / batchSize) + 1}: Processed ${batch.length} records`);
                }
                
                // Store project numbers for proof points filtering
                pdpProjectNumbers = vtData
                    .map(r => r.ADP_PROJ_NUM)
                    .filter(num => num != null && num !== '');
                
                console.log(`✅ Successfully upserted ${totalUpserted} PDP header records (${totalInserted} inserted, ${totalUpdated} updated)`);
                console.log(`   Collected ${pdpProjectNumbers.length} unique project numbers for proof points filtering`);
                
                syncResults.tables.push({
                    tableName: 'PdpHeaderData',
                    status: 'SUCCESS',
                    recordCount: totalUpserted,
                    message: `Upserted ${totalUpserted} records (${totalInserted} new, ${totalUpdated} updated, ${duplicatesRemoved} duplicates removed)`
                });
            } else {
                console.log('⚠️  No PDP header data found in Data Sphere for 2025 onwards');
                syncResults.tables.push({
                    tableName: 'PdpHeaderData',
                    status: 'SUCCESS',
                    recordCount: 0,
                    message: 'No records found from 2025 onwards'
                });
            }
        } catch (error) {
            console.error('❌ Error syncing PDP header data:', error);
            syncResults.overallStatus = 'PARTIAL';
            syncResults.tables.push({
                tableName: 'PdpHeaderData',
                status: 'FAILED',
                recordCount: 0,
                message: error.message
            });
        }
        
        // ========== Sync Proof Points Data (Only matching PDP projects) ==========
        try {
            console.log('📊 Syncing proof points data from Data Sphere...');
            
            // Fetch ALL proof points
            const allProofPoints = await db.run(SELECT.from(VT_PROOF_POINTS));
            console.log(`Total proof point records in Data Sphere: ${allProofPoints.length}`);
            
            // Filter: Only keep proof points where ADP_PROJECT_NUMBER matches a PDP header's ADP_PROJ_NUM
            const vtData = allProofPoints.filter(record => {
                if (!record.ADP_PROJECT_NUMBER) return false;
                return pdpProjectNumbers.includes(record.ADP_PROJECT_NUMBER);
            });
            
            console.log(`Found ${vtData.length} proof point records matching PDP headers`);
            console.log(`   Filtered out: ${allProofPoints.length - vtData.length} records (no matching PDP header)`);
            
            if (vtData.length > 0) {
                let totalUpserted = 0;
                let totalInserted = 0;
                let totalUpdated = 0;
                
                // Get existing records for comparison
                const existingRecords = await db.run(SELECT.from(PdpProofPointsData));
                const existingMap = new Map(
                    existingRecords.map(r => [
                        `${r.ADP_PROJECT_NUMBER || ''}_${r.TYPE_OF_PROOF_POINT_KEY || ''}_${r.PROOF_POINT_DOC_NAME || ''}_${r.PROOF_POINT_URL_LINK || ''}`,
                        r
                    ])
                );
                
                const batchSize = 1000;
                
                for (let i = 0; i < vtData.length; i += batchSize) {
                    const batch = vtData.slice(i, i + batchSize);
                    
                    for (const record of batch) {
                        const key = `${record.ADP_PROJECT_NUMBER || ''}_${record.TYPE_OF_PROOF_POINT_KEY || ''}_${record.PROOF_POINT_DOC_NAME || ''}_${record.PROOF_POINT_URL_LINK || ''}`;
                        const existingRecord = existingMap.get(key);
                        
                        const recordData = {
                            ADP_PROJECT_NUMBER: record.ADP_PROJECT_NUMBER || null,
                            TYPE_OF_PROOF_POINT_KEY: record.TYPE_OF_PROOF_POINT_KEY || null,
                            TYPE_OF_PROOF_POINT: record.TYPE_OF_PROOF_POINT || null,
                            TYPE_OF_PROOF_POINT_COMMENT: record.TYPE_OF_PROOF_POINT_COMMENT || null,
                            PROOF_POINT_DOC_NAME: record.PROOF_POINT_DOC_NAME || null,
                            PROOF_POINT_URL_LINK: record.PROOF_POINT_URL_LINK || null,
                            lastSyncedAt: currentTime,
                            modifiedAt: currentTime,
                            modifiedBy: currentUser
                        };
                        
                        if (existingRecord) {
                            // UPDATE existing record (preserve createdAt and createdBy)
                            await db.run(
                                UPDATE(PdpProofPointsData)
                                    .set(recordData)
                                    .where({ 
                                        ADP_PROJECT_NUMBER: record.ADP_PROJECT_NUMBER,
                                        TYPE_OF_PROOF_POINT_KEY: record.TYPE_OF_PROOF_POINT_KEY,
                                        TYPE_OF_PROOF_POINT_COMMENT: record.TYPE_OF_PROOF_POINT_COMMENT,
                                        PROOF_POINT_DOC_NAME: record.PROOF_POINT_DOC_NAME,
                                        PROOF_POINT_URL_LINK: record.PROOF_POINT_URL_LINK

                                    })
                            );
                            totalUpdated++;
                        } else {
                            // INSERT new record (set createdAt and createdBy)
                            recordData.createdAt = currentTime;
                            recordData.createdBy = currentUser;
                            await db.run(INSERT.into(PdpProofPointsData).entries(recordData));
                            totalInserted++;
                        }
                        totalUpserted++;
                    }
                    
                    console.log(`  Batch ${Math.floor(i / batchSize) + 1}: Processed ${batch.length} records`);
                }
                
                console.log(`✅ Successfully upserted ${totalUpserted} proof point records (${totalInserted} inserted, ${totalUpdated} updated)`);
                syncResults.tables.push({
                    tableName: 'PdpProofPointsData',
                    status: 'SUCCESS',
                    recordCount: totalUpserted,
                    message: `Upserted ${totalUpserted} records (${totalInserted} new, ${totalUpdated} updated)`
                });
            } else {
                console.log('⚠️  No matching proof points data found');
                syncResults.tables.push({
                    tableName: 'PdpProofPointsData',
                    status: 'SUCCESS',
                    recordCount: 0,
                    message: 'No matching proof points found'
                });
            }
        } catch (error) {
            console.error('❌ Error syncing proof points data:', error);
            syncResults.overallStatus = 'PARTIAL';
            syncResults.tables.push({
                tableName: 'PdpProofPointsData',
                status: 'FAILED',
                recordCount: 0,
                message: error.message
            });
        }
        
        // Determine overall status
        const allFailed = syncResults.tables.every(t => t.status === 'FAILED');
        if (allFailed) {
            syncResults.overallStatus = 'FAILED';
        }
        
        console.log('=== PDP Data Sync Completed ===');
        console.log('Overall Status:', syncResults.overallStatus);
        console.log('Summary:', JSON.stringify(syncResults.tables, null, 2));
        
    });
    
    // Return immediately to avoid timeout
    return {
        status: 'STARTED',
        message: 'PDP data sync from Data Sphere has been initiated in the background. Check logs for progress.',
        summary: []
    };
}

module.exports = {
    syncPdpDataFromDataSphere,
};