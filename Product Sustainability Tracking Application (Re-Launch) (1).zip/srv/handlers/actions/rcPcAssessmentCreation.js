const cds = require("@sap/cds");
const { ASSESSMENT_STATUS } = require("../../JS/assessment");

/** Services available */
const SERVICES = {
    SUSTAINABILITY_BACKGROUND: 'SustainabilityBackgroundService',
};

/** Service resources consumed */
const RESOURCES = {
    EVENTS: {
        RC_PC_SAVED: 'rcPcAssessmentSaved',
        RC_PC_SUBMITTED: 'rcPcAssessmentSubmitted',
    }
};

const { makeRcPcAssessment } = require('../../JS/rc-pc-assessment');
const { makeRcPcRepository } = require('../../JS/rc-pc-repository');
const { makeRcPcDecisionTree } = require('../../JS/rc-pc-decision-tree');
const { checkProductsInAssessmentforPdpMocHeart } = require('../../JS/functions');


const {
    getProductData, 
    buildAssessments, 
    createAssessments, 
    setLogsAsFinished,
    setLogsAsRetrial,
    checkValidProducts,
} = makeRcPcAssessment({
    rcPcRepository: makeRcPcRepository(),
    decisionTree: makeRcPcDecisionTree(),
    assessmentValidations: require('../../JS/assessment-validations'),
    assessment: require('../../JS/assessment'),
    checkProductsInAssessment: checkProductsInAssessmentforPdpMocHeart,
    rulesModel: require('../../JS/rules-model/rules-model'),
    getUuid: cds.utils.uuid,
});

/**
 * Implementation for action rcPcAssessmentCreation
 * 
 * @param {cds.Request} req - Incoming request
 */
async function rcPcAssessmentCreation(req) {

    const { sbu, products, status, runId } = req.data;
    
    // Filter only valid products
    const oCheckedProducts = await checkValidProducts(products);

    // Handle invalid products
    if (oCheckedProducts.invalidProducts && oCheckedProducts.invalidProducts.length > 0) {
        await setLogsAsRetrial( oCheckedProducts.invalidProducts, sbu, status, runId );
    }

    if (!oCheckedProducts.validProducts || oCheckedProducts.validProducts.length === 0) {
        return `No valid products to process`;
    }

    // Obtain product data from delta table
    const aProductsData = await getProductData( 
        sbu, 
        oCheckedProducts.validProducts, 
        status, 
        runId 
    );

    if (!aProductsData || aProductsData.length === 0) {
        return `No data found`;
    }    

    // Build assessment to create
    const assessmentsToCreate = await buildAssessments( aProductsData );

    // Create assessment
    if (assessmentsToCreate && assessmentsToCreate.length > 0){
        await createAssessments( assessmentsToCreate );
    }
    
    // Set heart assessments to finished
    await setLogsAsFinished( assessmentsToCreate, sbu, status, runId );

    const fnOnRequestSucceded = onRequestSucceededMaker(assessmentsToCreate);
    req.on('succeeded', fnOnRequestSucceded);

    return `Assessments created`;

};

/**
 * On request succeeded handler factory
 * 
 * @param {Object[]} aAssessmentsToCreate - Assessments to be created in service 
 * @returns {Function} Handler for onSucceeded request event
 */
 function onRequestSucceededMaker(aAssessmentsToCreate) {
    return async function () {
        cds.spawn(
            async tx => {
                const BackgroundService = await cds.connect.to(SERVICES.SUSTAINABILITY_BACKGROUND);
                for (const assessment of aAssessmentsToCreate) {
                    const sEvent = assessment.header.status === ASSESSMENT_STATUS.SAVED
                        ? RESOURCES.EVENTS.RC_PC_SAVED
                        : RESOURCES.EVENTS.RC_PC_SUBMITTED;
                    await BackgroundService.emit(sEvent, { sbu:assessment.header.sbu, assessmentId: assessment.header.ID })
                }
            }
        );
    };

};

module.exports = {
    rcPcAssessmentCreation,
};
