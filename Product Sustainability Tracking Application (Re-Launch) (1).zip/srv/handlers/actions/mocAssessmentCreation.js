const cds = require('@sap/cds');
const {
    MOC_PRODUCT_STATUS,
    getProductsForMocAssessment,
    checkMocAssessmentDataBeforeCreate,
    setMocProcessedProjectStatusToRetrial,
    buildMocAssessment,
    createMocAssessment,
    setMocProcessedProjectStatusToFinished,
    checkPendingPdpProducts,
    PROCESS_TYPE,
} = require('../../JS/adp-assessments');
const { PRODUCT_TYPE, getRelatedIbProofDocuments, getProductProofDocuments } = require('../../JS/assessment');
const { GetUserFromMyId } = require('../functions/GetUserFromMyId');
const { saveRecipients } = require('./saveRecipients');

/**
 * Implementation of mocAssessmentCreation action import
 * 
 * @param {cds.Request} req - Request made to service
 */
async function mocAssessmentCreation(req) {

    const { sbu, productType, projectId, products, status } = req.data;

    let oAssessment = {};

    // Only status pending and in retrial are processed
    const bIsStatusValid = status === MOC_PRODUCT_STATUS.PENDING || status === MOC_PRODUCT_STATUS.RETRIAL;
    if (!bIsStatusValid) return req.error(400, 'Invalid status');

    const aPdpProdcuts = await checkPendingPdpProducts({ productType, products });

    // Get products from MOC
    const aMocProducts = await getProductsForMocAssessment({ sbu, productType, projectId, products, status });

    const aProductData = aMocProducts.filter(item =>
        !aPdpProdcuts.some(ppp => ppp.product === item.product)
    );

    // Do not conitnue if no product found
    const bHasFoundProducts = aProductData && aProductData.length > 0;
    if (!bHasFoundProducts) return 'No data to process has been found';
    req.on('succeeded', async () => {

        try {

            const SustainabilityBackground = await cds.connect.to('SustainabilityBackgroundService');

            if (oAssessment && Object.keys(oAssessment).length > 0) {
                const eventMap = {
                    '01': { event: 'mocAssessmentSaved', payload: { sbu, assessmentId: oAssessment.header.ID, type: 'MASS' } },
                };

                const config = eventMap[oAssessment.header.status];

                //Get MyID Recipients
                const aRecipients = await GetUserFromMyId({ data: { sbu, status: oAssessment.header.status, processType: PROCESS_TYPE.MOC } });
                const recipientEmail = aRecipients.map(e => e.email);
                //Save recipients on notification recipients db
                await saveRecipients({ data: { assessmentId: oAssessment.header.ID, recipientEmail: recipientEmail, status: oAssessment.header.status } });

                // Send MOC assessment notification
                await SustainabilityBackground.emit(config.event, { ...config.payload });
            }

            if (oCheck.assessmentData.length > 0 && status === '01') {
                await SustainabilityBackground.emit("backgroundAssessmentCreationBlocking", {
                    blockingAssessment: oCheck.assessmentData.map(a => ({
                        ID: a.ID ?? null,
                        itemID: a.itemID ?? null,
                        requestName: a.requestName ?? null,
                        headerStatus: a.headerStatus ?? null,
                        product: a.product ?? null,
                        status: a.status ?? null,
                        assessor: a.assessor ?? null,
                        submitter: a.submitter ?? null,
                        approver: a.approver ?? null,
                        communicationStatus: a.communicationStatus ?? null
                    })),
                    type: 'MOC'
                });

                await SustainabilityBackground.emit("productsBlockedPdpMoc", {
                    blockedProducts:  oCheck.assessmentData.map(a => ({
                        ID: a.ID ?? null,
                        itemID: a.itemID ?? null,
                        requestName: a.requestName ?? null,
                        headerStatus: a.headerStatus ?? null,
                        product: a.product ?? null,
                        status: a.status ?? null,
                        assessor: a.assessor ?? null,
                        submitter: a.submitter ?? null,
                        approver: a.approver ?? null,
                        communicationStatus: a.communicationStatus ?? null
                    })),
                    sbu: sbu,
                    type: 'MOC',
                    adpProject: projectId
                });
            }

        } catch (error) {
            console.error('Error sending MOC notifications:', error)
        }

    });

    // For each product, make initial checks
    const oCheck = await checkMocAssessmentDataBeforeCreate(aProductData);
    if (!oCheck.isValid) {

        // If validation error detected, do not continue execution with the products with errors and set assessment products for retrial
        await setMocProcessedProjectStatusToRetrial({
            projectId,
            products: oCheck.productsWithError,
        });
    }

    // Only products without error are further processed
    const aValidProducts = aProductData.filter(item => {
        return !oCheck.productsWithError.includes(item.product)
    });

    const bHasValidProdcuts = aValidProducts && aValidProducts.length > 0;
    if (!bHasValidProdcuts) return 'No valid products to process has been found';

    // Get already existing proof documents
    const aExistingProofDocuments = await getProductProofDocuments(aValidProducts.map(item => item.product));

    // Get related IB documents in case it is an IDH
    const aIbProofDocuments = productType === PRODUCT_TYPE.IDH
        ? (await getRelatedIbProofDocuments(aValidProducts.map(item => item.product)))
        : [];

    oAssessment = await buildMocAssessment(aValidProducts, aIbProofDocuments, aExistingProofDocuments);

    await createMocAssessment(oAssessment);

    // If everything went well, set as status as finished
    await setMocProcessedProjectStatusToFinished({
        projectId,
        products: aValidProducts.map(item => item.product)
    });


    return `MOC Assessment ${oAssessment.header.ID} created`;
};

module.exports = {
    mocAssessmentCreation,
}