const cds = require('@sap/cds');
const {
    PDP_PRODUCT_STATUS,
    getProductsForPdpAssessment,
    setPdpProcessedProjectStatusToRetrial,
    setPdpProcessedProjectStatusToFinished,
    checkPdpAssessmentDataBeforeCreate,
    buildPdpAssessment,
    createPdpAssessment,
    getPdpAdpProofDocuments,
    PROCESS_TYPE,
} = require('../../JS/adp-assessments');
const { PRODUCT_TYPE, getRelatedIbProofDocuments, getProductProofDocuments } = require('../../JS/assessment');
const { GetUserFromMyId } = require('../functions/GetUserFromMyId');
const { saveRecipients } = require('./saveRecipients');

/**
 * Implementation of pdpAssessmentCreation action import
 * 
 * @param {cds.Request} req - Request made to service
 */
async function pdpAssessmentCreation(req) {

    const { sbu, productType, projectId, products, status } = req.data;

    let oAssessment = {};

    // Only status pending and in retrial are processed
    const bIsStatusValid = status === PDP_PRODUCT_STATUS.PENDING || status === PDP_PRODUCT_STATUS.RETRIAL;
    if (!bIsStatusValid) return req.error(400, 'Invalid status');

    // Get products to use
    const aProductData = await getProductsForPdpAssessment({ sbu, productType, projectId, products, status });

    // Do not conitnue if no product found
    const bHasFoundProducts = aProductData && aProductData.length > 0;
    if (!bHasFoundProducts) return 'No data to process has been found';

    // Get ADP proofDocuments
    const aAdpProofDocuments = await getPdpAdpProofDocuments({projectId})

    req.on('succeeded', async () => {

        try {

            const SustainabilityBackground = await cds.connect.to('SustainabilityBackgroundService');

            if (oAssessment && Object.keys(oAssessment).length > 0) {
                const eventMap = {
                    '01': { event: 'pdpAssessmentSaved', payload: { sbu, assessmentId: oAssessment.header.ID, type: 'MASS' } },
                    '02': { event: 'pdpAssessmentSubmitted', payload: { sbu, assessmentId: oAssessment.header.ID, type: 'MASS' } },

                };

                const config = eventMap[oAssessment.header.status];

                //Get MyID Recipients
                // const aRecipients = await GetUserFromMyId({ data: {sbu, status, processType: PROCESS_TYPE.PDP}});
                const processType = oAssessment.header.status === '01'
                    ? PROCESS_TYPE.PDP
                    : '';
                const aRecipients = await GetUserFromMyId({ data: { sbu, status: oAssessment.header.status, processType }});
                const recipientEmail = aRecipients.map(e => e.email);

                //Save recipients on notification recipients db
                await saveRecipients({ data: {assessmentId: oAssessment.header.ID, recipientEmail: recipientEmail, status: oAssessment.header.status}}); 
            
                // Send PDP assessment notification
                await SustainabilityBackground.emit(config.event, { ...config.payload });
            }
            
            if (oCheck.assessmentData.length > 0 && status === '01') {
                await SustainabilityBackground.emit("backgroundAssessmentCreationBlocking", {
                      blockingAssessment: oCheck.assessmentData.map(a => ({
                        ID: a.ID ?? null,
                        itemID: a.itemID ?? null,
                        requestName: a.requestName ?? null,
                        headerStatus: a.headerStatus ?? null,
                        product: a.product ?? null,
                        status: a.status ?? null,
                        assessor: a.assessor ?? null,
                        submitter: a.submitter ?? null,
                        approver: a.approver ?? null,
                        communicationStatus: a.communicationStatus ?? null
                    })),
                    type: 'PDP'
                });

                await SustainabilityBackground.emit("productsBlockedPdpMoc", {
                    blockedProducts: oCheck.assessmentData.map(a => ({
                        ID: a.ID ?? null,
                        itemID: a.itemID ?? null,
                        requestName: a.requestName ?? null,
                        headerStatus: a.headerStatus ?? null,
                        product: a.product ?? null,
                        status: a.status ?? null,
                        assessor: a.assessor ?? null,
                        submitter: a.submitter ?? null,
                        approver: a.approver ?? null,
                        communicationStatus: a.communicationStatus ?? null
                    })),
                    sbu: sbu,
                    type: 'PDP',
                    adpProject: projectId
                });
            }

        } catch (error) {
            console.log('Error sending PDP notification:', error)
        }

    });

    // For each product, make initial checks
    const oCheck = await checkPdpAssessmentDataBeforeCreate(aProductData);
    if (!oCheck.isValid) {

        // If validation error detected, do not continue execution and set assessment for retrial
        await setPdpProcessedProjectStatusToRetrial({
            projectId,
            products: oCheck.productsWithError,
        });

    }

    // Only products without error are further processed
    const aValidProducts = aProductData.filter(item => {
        const bIsValid = !oCheck.productsWithError.includes(item.product)
        return bIsValid;
    });

    const bHasFoundValidProducts = aValidProducts && aValidProducts.length > 0;
    if (!bHasFoundValidProducts) return 'No valid products to process has been found';

    // Get already existing proof documents
    const aExistingProofDocuments = await getProductProofDocuments(aValidProducts.map(item => item.product));

    // Get related IB documents in case it is an IDH
    const aIbProofDocuments = productType === PRODUCT_TYPE.IDH
        ? (await getRelatedIbProofDocuments(aValidProducts.map(item => item.product)))
        : [];

    // If initial validations are OK, then assessment is created
    oAssessment = await buildPdpAssessment(aValidProducts, aAdpProofDocuments, aIbProofDocuments, aExistingProofDocuments);

    // Insert data in DB
    const oCreation = await createPdpAssessment(oAssessment);

    // If everything went well, set as status as finished
    await setPdpProcessedProjectStatusToFinished({
        projectId,
        products: aValidProducts.map(item => item.product)
    });

    return `Assessment ${oAssessment.header.ID} created`;

};

module.exports = {
    pdpAssessmentCreation,
}