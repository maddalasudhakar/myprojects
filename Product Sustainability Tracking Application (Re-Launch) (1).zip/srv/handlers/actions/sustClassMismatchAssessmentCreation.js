const cds = require('@sap/cds');
const { checkProductsInAssessment } = require("../../JS/functions");
const { divideArrayInBatches } = require('../../JS/batching-utils');
const { getProductProofDocuments, getRelatedIbProofDocuments, ENTITIES, ASSESSMENT_TYPE } = require('../../JS/assessment');
const { setRcPreFlagMismatchProcessedProjectStatusToFinished, BATCH_SIZE, buildRcPreFlagMismatchAssessmentHeader, buildRcPreFlagMismatchAssessmentItems } = require('../../JS/rc-mismatch-assessments');


/**
 * Implementation of sustClassMismatchAssessmentCreation action import
 * 
 * @param {cds.Request} req - Request made to service
 */
async function sustClassMismatchAssessmentCreation(req) {
    // cds.spawn(async () => {

        let oHeader;
        const { sbu, products } = req.data;
        if (!sbu || !products) {
            req.error(400, "Required fields 'sbu' and 'products' must be provided");
            return;
        }

        await cds.tx(async () => {
            const db = await cds.connect.to('db');

            // Check which products are already in an active assessment
            const productsInAssessment = await checkProductsInAssessment(products);
            const productsAlreadyInAssessment = productsInAssessment.map(p => p.product);

            if (productsAlreadyInAssessment.length > 0) {
                await setRcPreFlagMismatchProcessedProjectStatusToFinished({
                    products: productsAlreadyInAssessment,
                    message: 'Product currently part of an active assessment',
                    createdassessmentid: null
                });

            }
            const productsToCreateIds = products.filter(p => !productsAlreadyInAssessment.includes(p));

            if (productsToCreateIds.length === 0) return;

            //Retrieve complete product information from IDH_UPDATED using batches.
            let bInsertHeader = true;
            const MISMATCH_BATCH_SIZE = 100;
            const batches = divideArrayInBatches(productsToCreateIds, MISMATCH_BATCH_SIZE);

            for (const batch of batches) {
                const aResults = await db.run(
                    SELECT.from(ENTITIES.DB.IDH_UPDATED)
                        .columns(
                            'MATERIALTNUMBER as product',
                            'SBU as sbu',
                            'APPROVER as approver',
                            'RCPREFLAG as rcPreFlag',
                            'RCPREFLAGDESCRIPTION as rcPreFlagDescription',
                            'SUSTCLASS as sustClass',
                            'CATEGORY as category1',
                            'CONTRIBUTOR as contributor1'
                        )
                        .where({ MATERIALTNUMBER: { in: batch } })
                );

                const aExistingProofDocuments = await getProductProofDocuments(aResults.map(item => item.product));
                const relatedIbProofDocuments = await getRelatedIbProofDocuments(aResults.map(item => item.product));

                if (bInsertHeader) {
                    oHeader = await buildRcPreFlagMismatchAssessmentHeader(aResults[0]);
                    await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_HEADER).entries([oHeader]);
                    bInsertHeader = false;
                }

                const aItems = await buildRcPreFlagMismatchAssessmentItems(
                    aResults,
                    relatedIbProofDocuments,
                    aExistingProofDocuments,
                    oHeader.ID
                );

                const aItemEntries = aItems.map(item => {
                    const itemWithoutDocuments = { ...item };
                    delete itemWithoutDocuments.toProofDocuments;
                    return itemWithoutDocuments;
                });

                if (aItemEntries.length > 0) {
                    const aItemBatches = divideArrayInBatches(aItemEntries, BATCH_SIZE);
                    for (const itemBatch of aItemBatches) {
                        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(itemBatch);
                    }
                }

                const aProofDocuments = aItems.flatMap(item => item.toProofDocuments || []);
                if (aProofDocuments.length > 0) {
                    const aProofBatches = divideArrayInBatches(aProofDocuments, BATCH_SIZE);
                    for (const proofBatch of aProofBatches) {
                        await INSERT.into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).entries(proofBatch);
                    }
                }

            }

            await setRcPreFlagMismatchProcessedProjectStatusToFinished({
                products: productsToCreateIds,
                message: 'Assessment created successfully',
                createdassessmentid: oHeader.ID
            });

        });

        const SustainabilityBackground = await cds.connect.to('SustainabilityBackgroundService');
        if (oHeader?.ID) {
            await SustainabilityBackground.emit('rcPreFlagMismatchAssessmentCreated', {
                sbu,
                assessmentId: oHeader.ID,
                assessmentType: ASSESSMENT_TYPE.MASS
            });
        }
    // });

}



module.exports = {
    sustClassMismatchAssessmentCreation,

}