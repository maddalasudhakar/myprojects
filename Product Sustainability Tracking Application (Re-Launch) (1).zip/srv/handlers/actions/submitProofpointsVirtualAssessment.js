const cds = require("@sap/cds/libx/_runtime/cds");
const { getRules, checkRules } = require("../../JS/rules-model/rules-model");
const { checkAssessmentFieldValues, getAssessmentFieldMasterData, getMassAssessmentDataBeforeSubmit } = require("../../JS/assessment-validations")

const ENTITIES = {
    DB: {
        MASS_ASSESSMENT_HEADER: "management.MassAssessmentHeader",
        MASS_ASSESSMENT_ITEMS: "management.MassAssessmentItems",
    }
};

const STATUS = {
    DRAFT: "91",
    APPROVED: "05"
};

const COMMUNICATION_STATUS = {
    PENDING_CPI: "01"
}

async function submitProofpointsVirtualAssessment(req) {
    const db = await cds.connect.to("db");
    const MassAssessmentHeader = db.entities[ENTITIES.DB.MASS_ASSESSMENT_HEADER];
    const MassAssessmentItems = db.entities[ENTITIES.DB.MASS_ASSESSMENT_ITEMS];    
    const aMassAssessmentHeader = await SELECT.from(MassAssessmentHeader).where({ID: req.data.header.ID});
    const aMassAssessmentItems = await SELECT.from(MassAssessmentItems).where({headerId: req.data.header.ID});

    // Validations
    await initialValidations( req, aMassAssessmentHeader, aMassAssessmentItems );
    if (req.errors && req.errors?.length > 0) return;
    
    await db.run(async tx => {

        await UPDATE(MassAssessmentHeader)
            .set({
                status: STATUS.APPROVED, 
                communicationStatus: COMMUNICATION_STATUS.PENDING_CPI
            })
            .where({
                ID: req.data.header.ID 
            });

        await UPDATE(MassAssessmentItems)
            .set({
                status: STATUS.APPROVED, 
                communicationStatus: COMMUNICATION_STATUS.PENDING_CPI,
            })
            .where({
                headerId: req.data.header.ID 
            });            

    });   
    return "Submit finished";
};

/**
 * Validaitons before processing
 * 
 * @param {*} req 
 * @returns 
 */
async function initialValidations(req, headerDB, itemsDB) {

    const { header, items } = req.data;
    const { sbu } = header;

    // Check user permissions
    const aAcceptedRoles = [`${sbu}.Assessor`, `${sbu}.Submitter`];
    const bUserHasPermission = aAcceptedRoles.some(roles => req.user.is(roles));
    if (!bUserHasPermission) {
        req.error(403, "Unauthorized for this SBU");
        return;
    }

    // Retrieve data from database to complete missing data
    const aAssessments = await getMassAssessmentDataBeforeSubmit(req);  

    // Check eash assessment item according to rules model
    const oRules = await getRules();
    const oMasterData = await getAssessmentFieldMasterData();
    for (const oAssessement of aAssessments) {
        const oCheckRule = await checkRules(oAssessement, oRules, oMasterData.contributor);
        if (!oCheckRule.continue) {
            req.error(409, `Product ${oAssessement.product}: ${oCheckRule.reason}`);
        } else {
            const oCheckValues = await checkAssessmentFieldValues(oAssessement, oMasterData);
            if (!oCheckValues.valid) {
                req.error(409, `Product ${oAssessement.product}: ${oCheckValues.reason}`);
            }                
        }         
    }
    if (req.errors && req.errors?.length > 0) return;
    
    // Check assessments are set as virtual
    const bHeaderVirtual = headerDB[0]?.virtualAssessment;
    const bItemsVirtual = itemsDB?.length > 0 && !itemsDB.some(item => !item.virtualAssessment);
    if (!bHeaderVirtual || !bItemsVirtual) {
        req.error(409, "Asssessment header or items are not virtual");
        return;        
    }

    // Check status are allowed
    const bHeaderStatusValid = headerDB[0]?.status === STATUS.DRAFT;
    const bItemStatusValid = itemsDB?.length > 0 && !itemsDB.some(item => item.status !== STATUS.DRAFT);
    if (!bHeaderStatusValid || !bItemStatusValid) {
        req.error(409, "Header and item status must be draft");
    }

};

module.exports = {
    submitProofpointsVirtualAssessment,
}