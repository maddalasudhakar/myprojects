const cds = require("@sap/cds/libx/_runtime/cds");

const {
    beforeSubmitMass,
} = require("../../JS/assessment-validations");

const ENTITIES = {
    DB: {
        MASS_ASSESSMENT_HEADER: "management.MassAssessmentHeader",
        MASS_ASSESSMENT_ITEMS: "management.MassAssessmentItems",
    }
}

async function SubmitMassAssessment(req) {
    const db = await cds.connect.to("db");
    await beforeSubmitMass(req);

    if (req.errors) {
        return;
    }

    const MassAssessmentHeader = db.entities[ENTITIES.DB.MASS_ASSESSMENT_HEADER];
    const MassAssessmentItems = db.entities[ENTITIES.DB.MASS_ASSESSMENT_ITEMS];
    await db.run(async tx => {

        const aPromises = [];
        let aUpdateBatch = [];
        for (const oItem of req.data.items) {                  
            if (oItem.itemDB) delete oItem.itemDB;
            if (oItem.productProofDocumentsDB) delete oItem.productProofDocumentsDB;
            
            aUpdateBatch.push(oItem);
            if (aUpdateBatch.length === 1000) {          
                const result = await UPSERT(aUpdateBatch).into(MassAssessmentItems);
                console.log(JSON.stringify(result));
                console.log(JSON.stringify(aUpdateBatch));
                aUpdateBatch = [];
            }
            // aPromises.push(UPDATE(MassAssessmentItems).set(oItem).where({ ID: oItem.ID }));
        }

        if (aUpdateBatch.length !== 0) {
            await UPSERT(aUpdateBatch).into(MassAssessmentItems) 
            aUpdateBatch = [];
        }        
        // const result = await Promise.allSettled(aPromises);
        // if (result.some(item => item.status === "rejected")) {
        //     req.reject(500, "Failed tu update database");
        // }

        await UPDATE(MassAssessmentHeader).set(req.data.header).where({ ID: req.data.header.ID });

    });   

    req.on('succeeded', async () => {
        await cds.tx(async () => {
            try {
                const oDb = await cds.connect.to('db');
                const oNotificationRecipients = oDb.entities['management.NotificationRecipients'];
                const { ID: assessmentID, sbu, status } = req.data.header;

                const aNotificationRecipients = await SELECT.from(oNotificationRecipients).where({ assessmentId: assessmentID, assessmentStatus: status });

             if (!aNotificationRecipients || aNotificationRecipients.length == 0) {
                    return;
                }

                const result = await this.emit(
                    'assessmentSubmitted',
                    {
                        sbu: sbu,
                        assessmentId: assessmentID,
                        type: 'MASS'
                    }
                );
                console.log(result);
            } catch (error) {
                console.error(error);
            }
        });
    });

    return "Submit finished";
};

module.exports = {
    SubmitMassAssessment,
}