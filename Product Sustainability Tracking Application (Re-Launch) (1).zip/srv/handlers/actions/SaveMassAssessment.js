const cds = require("@sap/cds/libx/_runtime/cds");
const {
    beforeSaveMass,
} = require("../../JS/assessment-validations");

const ENTITIES = {
    DB: {
        MASS_ASSESSMENT_HEADER: "management.MassAssessmentHeader",
        MASS_ASSESSMENT_ITEMS: "management.MassAssessmentItems",
    }
}

async function SaveMassAssessment(req) {
    const db = await cds.connect.to("db");

    await beforeSaveMass(req);

    if (req.errors) {
        return;
    }

    const MassAssessmentHeader = db.entities[ENTITIES.DB.MASS_ASSESSMENT_HEADER];
    const MassAssessmentItems = db.entities[ENTITIES.DB.MASS_ASSESSMENT_ITEMS];
    await db.run(async tx => {

        await UPDATE(MassAssessmentHeader).set(req.data.header).where({ ID: req.data.header.ID });
        const aPromises = [];
        let aUpdateBatch = [];
        for (const oItem of req.data.items) {
            if (oItem.itemDB) delete oItem.itemDB;
            if (oItem.productProofDocumentsDB) delete oItem.productProofDocumentsDB;

            aUpdateBatch.push(oItem);
            if (aUpdateBatch.length === 1000) {          
                const result = await UPSERT(aUpdateBatch).into(MassAssessmentItems);
                console.log(JSON.stringify(result));
                console.log(JSON.stringify(aUpdateBatch));
                aUpdateBatch = [];
            }
        }

        if (aUpdateBatch.length !== 0) {
            await UPSERT(aUpdateBatch).into(MassAssessmentItems) 
            aUpdateBatch = [];
        }    

        await UPDATE(MassAssessmentHeader).set(req.data.header).where({ ID: req.data.header.ID });
    });   

    req.on('succeeded', async () => {
        await cds.tx(async () => {
            try {
                const oDb = await cds.connect.to('db');
                const oNotificationRecipients = oDb.entities['management.NotificationRecipients'];
                const { ID: assessmentID, sbu, status } = req.data.header;

                const aNotificationRecipients = await SELECT.from(oNotificationRecipients).where({ assessmentId: assessmentID, assessmentStatus: status });
            
                if (!aNotificationRecipients || aNotificationRecipients.length == 0) {
                    return;
                }

                const result = await this.emit(
                    'assessmentSaved',
                    {
                        sbu: sbu,
                        assessmentId: assessmentID,
                        type: 'MASS',
                    }
                );
                console.log(result);
            } catch (error) {
                console.error(error);
            }
        });
    });

    return "Save finished";
};

module.exports = {
    SaveMassAssessment,
}