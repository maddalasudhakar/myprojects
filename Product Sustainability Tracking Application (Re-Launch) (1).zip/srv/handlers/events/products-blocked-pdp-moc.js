const cds = require('@sap/cds');
const { postProductBlockedNotificationPdpMoc } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of productsBlockedPdpMoc event
 * 
 * @param {cds.Request} req - Request received
 */
async function productsBlockedPdpMoc(req) {
    const { blockedProducts, sbu, type, adpProject } = req.data;
    const result = await postProductBlockedNotificationPdpMoc({
        blockedProducts,
        sbu,
        type,
        adpProject
    });
    return 'Notification sent';
};

module.exports = {
    productsBlockedPdpMoc,
};