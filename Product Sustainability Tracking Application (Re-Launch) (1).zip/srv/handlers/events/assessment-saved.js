const cds = require('@sap/cds');
const { postNotificationOnSave } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of assessmentSaved event
 * 
 * @param {cds.Request} req - Request received
 */
async function assessmentSaved(req) {
    const { assessmentId, sbu, type } = req.data;
    const result = await postNotificationOnSave({
        sbu,
        assessmentId,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    assessmentSaved,
};