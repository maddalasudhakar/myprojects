const cds = require('@sap/cds');
const { postNotificationOnSubmitted } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of assessmentSubmitted event
 * 
 * @param {cds.Request} req - Request received
 */
async function assessmentSubmitted(req) {
    const { assessmentId, sbu, type } = req.data;
    const result = await postNotificationOnSubmitted({
        sbu,
        assessmentId,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    assessmentSubmitted,
};