const cds = require('@sap/cds');
const { postNotificationOnSaveMoc } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of mocAssessmentSaved event
 * 
 * @param {cds.Request} req - Request received
 */
async function mocAssessmentSaved(req) {
    const { assessmentId, sbu, type } = req.data;
    const result = await postNotificationOnSaveMoc({
        sbu,
        assessmentId,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    mocAssessmentSaved,
};