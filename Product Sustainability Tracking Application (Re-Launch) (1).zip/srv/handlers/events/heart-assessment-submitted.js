const cds = require('@sap/cds');
const { postNotificationOnHeartAssessmentSubmitted } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of heartAssessmentSubmitted event
 * 
 * @param {cds.Request} req - Request received
 */
async function heartAssessmentSubmitted(req) {
    const { sbu, assessmentId } = req.data;
    const result = await postNotificationOnHeartAssessmentSubmitted({
        sbu,
        assessmentId
    });
    return 'Notification sent';
};

module.exports = {
    heartAssessmentSubmitted,
};