const cds = require('@sap/cds');
const { postNotificationOnUnderResubmission } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of assessmentUnderResubmission event
 * 
 * @param {cds.Request} req - Request received
 */
async function assessmentUnderResubmission(req) {
    const { assessmentId, sbu, type, submitter } = req.data;
    const result = await postNotificationOnUnderResubmission({
        sbu,
        assessmentId,
        assessmentType: type,
        submitter,
    });
    return 'Notification sent';
};

module.exports = {
    assessmentUnderResubmission,
};