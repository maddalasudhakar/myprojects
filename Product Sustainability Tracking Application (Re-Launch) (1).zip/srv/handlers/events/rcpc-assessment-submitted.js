const cds = require('@sap/cds');
const { postNotificationOnRCPCAssessmentSubmitted } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of rcPcAssessmentSubmitted event
 * 
 * @param {cds.Request} req - Request received
 */
async function rcPcAssessmentSubmitted(req) {
    const { sbu, assessmentId } = req.data;
    const result = await postNotificationOnRCPCAssessmentSubmitted({
        sbu,
        assessmentId
    });
    return 'Notification sent';
};

module.exports = {
    rcPcAssessmentSubmitted,
};