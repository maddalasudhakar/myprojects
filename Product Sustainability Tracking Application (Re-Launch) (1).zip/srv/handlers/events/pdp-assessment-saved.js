const cds = require('@sap/cds');
const { postNotificationOnSavePdp } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of pdpAssessmentSaved event
 * 
 * @param {cds.Request} req - Request received
 */
async function pdpAssessmentSaved(req) {
    const { assessmentId, sbu, type } = req.data;
    const result = await postNotificationOnSavePdp({
        sbu,
        assessmentId,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    pdpAssessmentSaved,
};