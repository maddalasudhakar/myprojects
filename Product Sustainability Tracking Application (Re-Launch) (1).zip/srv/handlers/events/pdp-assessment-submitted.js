const cds = require('@sap/cds');
const { postNotificationOnSubmitPdp } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of pdpAssessmentSubmitted event
 * 
 * @param {cds.Request} req - Request received
 */
async function pdpAssessmentSubmitted(req) {
    const { assessmentId, sbu, type } = req.data;
    const result = await postNotificationOnSubmitPdp({
        sbu,
        assessmentId,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    pdpAssessmentSubmitted,
};