const cds = require('@sap/cds');
const { postNotificationOnResubmitted } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of assessmentResubmitted event
 * 
 * @param {cds.Request} req - Request received
 */
async function assessmentResubmitted(req) {
    const { assessmentId, sbu, type, approver } = req.data;
    const result = await postNotificationOnResubmitted({
        sbu,
        assessmentId,
        assessmentType: type,
        approver,
    });
    return 'Notification sent';
};

module.exports = {
    assessmentResubmitted,
};