const cds = require('@sap/cds');
const { postBlockingAssessmentNotification } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of backgroundAssessmentCreationBlocking event
 * 
 * @param {cds.Request} req - Request received
 */
async function backgroundAssessmentCreationBlocking(req) {
    const { blockingAssessment, sbu, type } = req.data;
    const result = await postBlockingAssessmentNotification({
        blockingAssessment,
        sbu,
        assessmentType: type
    });
    return 'Notification sent';
};

module.exports = {
    backgroundAssessmentCreationBlocking,
};