const cds = require('@sap/cds');
const { postNotificationOnSubmitRcPreFlagMismatch } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of rcPreFlagMismatchAssessmentCreated event
 * 
 * @param {cds.Request} req - Request received
 */
async function rcPreFlagMismatchAssessmentCreated(req) {
    const { assessmentId, sbu, assessmentType } = req.data;
    const result = await postNotificationOnSubmitRcPreFlagMismatch({
        sbu,
        assessmentId,
        assessmentType: assessmentType
    });
    return 'Notification sent';
};

module.exports = {
    rcPreFlagMismatchAssessmentCreated,
};