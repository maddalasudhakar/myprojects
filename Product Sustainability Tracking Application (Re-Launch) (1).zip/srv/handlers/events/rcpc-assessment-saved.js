const cds = require('@sap/cds');
const { postNotificationOnRCPCAssessmentSave } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of rcPcAssessmentSaved event
 * 
 * @param {cds.Request} req - Request received
 */
async function rcPcAssessmentSaved(req) {
    const { sbu, assessmentId } = req.data;
    const result = await postNotificationOnRCPCAssessmentSave({
        sbu,
        assessmentId
    });
    return 'Notification sent';
};

module.exports = {
    rcPcAssessmentSaved,
};