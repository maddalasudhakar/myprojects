const cds = require('@sap/cds');
const { postNotificationOnHeartAssessmentSave } = require('../../JS/notification-utils'); 

/**
 * Handles implementation of heartAssessmentSaved event
 * 
 * @param {cds.Request} req - Request received
 */
async function heartAssessmentSaved(req) {
    const { sbu, assessmentId } = req.data;
    const result = await postNotificationOnHeartAssessmentSave({
        sbu,
        assessmentId
    });
    return 'Notification sent';
};

module.exports = {
    heartAssessmentSaved,
};