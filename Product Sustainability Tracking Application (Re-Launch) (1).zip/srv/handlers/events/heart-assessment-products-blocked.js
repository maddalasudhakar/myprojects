const cds = require('@sap/cds');
const { postProductBlockedNotificationHeart, postBlockingAssessmentNotification} = require('../../JS/notification-utils'); 
const { ASSESSMENT_PROCESS } = require('../../JS/assessment');

/**
 * Handles implementation of heartAssessmentProductsBlocked event
 * 
 * @param {cds.Request} req - Request received
 */
async function heartAssessmentProductsBlocked(req) {
    const {sbu, blockedProducts, blockingAssessment } = req.data;
    await postProductBlockedNotificationHeart({
        blockedProducts,
        sbu
    });

    await postBlockingAssessmentNotification({
        blockingAssessment,
        assessmentType: ASSESSMENT_PROCESS.HEART
    });
    return 'Notification sent';
};

module.exports = {
    heartAssessmentProductsBlocked,
};