using {
    com.sustainability.management as management,
    com.sustainability.support as support,
    com.sustainability.IbUpdated as IbUpdated,
    com.sustainability.IdhUpdated as IdhUpdated,
    com.sustainability as sustainability,
    com.sustainability.VT_V_IB_IDH as ibIdhRelationship
} from '../db/schema';

using com.sustainability.types as types from '../db/types';

@path    : 'sustainability/management'
@requires: 'authenticated-user'
service SustainabilityManagement {

    @readonly
    @cds.query.limit.default: 100000
    @cds.query.limit.max: 100000
    entity Idh as
        select from IdhUpdated 
        {
            *,
            false as HasDraftEntity          : Boolean,
            null  as sbuDescription          : String(60),
            null  as sustClassDescription    : String,
            null  as categoryDescription     : String,
            null  as category2Description    : String,
            null  as category3Description    : String,
            null  as contributorDescription  : String,
            null  as contributor2Description : String,
            null  as contributor3Description : String,
        };    

    @readonly
    @cds.query.limit.default: 100000
    @cds.query.limit.max: 100000
    entity Ib as
        select from IbUpdated 
        {
            *,
            false as HasDraftEntity          : Boolean,
            null  as sbuDescription          : String(60),
            null  as sustClassDescription    : String,
            null  as categoryDescription     : String,
            null  as category2Description    : String,
            null  as category3Description    : String,
            null  as contributorDescription  : String,
            null  as contributor2Description : String,
            null  as contributor3Description : String,
        };

    @readonly
    @cds.query.limit.default: 100000
    @cds.query.limit.max: 100000
    entity ProductsByAssessment as select from sustainability.ProductsByAssessment;

    @readonly
    entity Sbu                     as select from management.Sbu;

    //Project entities
    @readonly
    entity SustainabilityClass     as select from management.SustainabilityClass;

    @readonly
    entity RcPreFlag               as select from management.RcPreFlag;

    @readonly
    entity SustainabilityCategory  as select from management.SustainabilityCategory;

    @readonly
    entity Contributor             as select from management.Contributor;

    @readonly
    entity ProofType               as select from management.ProofType;

    @readonly
    entity StatusVH                as select from management.Status;

    @readonly
    entity AssessmentType          as select from management.AssessmentType;

    @readonly
    entity ProductType             as select from management.ProductType;

    @readonly
    entity ProductProofDocument    as select from management.ProductProofDocumentRelation;

    @readonly
    entity AssessmentList          as
            select from SingleAssessment {
                key ID,
                    requestName,
                    sbu,
                    productType,
                    assessor,
                    submitter,
                    submitionDate,
                    approver,
                    approvalDate,
                    assesmentType,
                    status,
                    statusDescription,
                    projectId,
                    virtualAssessment,
                    communicationStatus,
                    toStatus,
                    toAssessmentType
            }
        union all
            select from MassAssessmentHeader {
                key ID,
                    requestName,
                    sbu,
                    productType,
                    assessor,
                    submitter,
                    submitionDate,
                    approver,
                    approvalDate,
                    assesmentType,
                    status,
                    statusDescription,
                    projectId,
                    virtualAssessment,
                    communicationStatus,
                    toStatus,
                    toAssessmentType
            }
            
    entity NotificationRecipients  as select from management.NotificationRecipients;

    entity SingleAssessment        as projection on management.SingleAssessment;


    entity MassAssessmentHeader    as projection on management.MassAssessmentHeader
        actions {
            action setStatus() returns String;
        };

    entity MassAssessmentItems     as projection on management.MassAssessmentItems
        actions {
            function getHeartDeltaData() returns array of types.HeartDeltaProductDisplay;
        };
    entity AssessmentProofDocument as projection on management.AssessmentProofDocument;
    @readonly
    entity IbIdhRelationship as select from ibIdhRelationship;

    //Functions
    function GetUserParameters()                                                             returns String;
    function GetAssessmentsUser()                                                            returns types.assessmentsByStatus;
    function checkProductInAssessment(products : String)                                     returns array of types.productsAssessments;
    function GetProductMasterdata(productType : String(3), product : array of types.product) returns array of types.ProductData;
    function getRelatedProductsData(productType : String(3), product : String)               returns array of types.productsRelation;
    function getIbLinkedToIdh(materials : array of types.product)               returns array of types.materialsToProducts;
    function getProductDocuments(product : array of types.product) returns array of  ProductProofDocument;
    function GetRulesModel() returns String;
    function GetUserFromMyId(status: types.status, sbu: types.sbu , processType: types.assessmentProcessType) returns array of types.notificationsRecipients;
    action updateMassAssessmentItemsBatch( items : array of SustainabilityManagement.MassAssessmentItems ) returns array of types.assessmentItemErrorMessage;
    action SubmitMassAssessment(
        header: SustainabilityManagement.MassAssessmentHeader, 
        items: array of SustainabilityManagement.MassAssessmentItems
    ) returns array of String;
    action SaveMassAssessment(
        header: SustainabilityManagement.MassAssessmentHeader, 
        items: array of SustainabilityManagement.MassAssessmentItems
    ) returns array of String;    
    action MassUploadDocuments(
        items: array of SustainabilityManagement.MassAssessmentItems,
        documents: array of SustainabilityManagement.AssessmentProofDocument
    ) returns String;
    action submitProofpointsVirtualAssessment(
        header: SustainabilityManagement.MassAssessmentHeader, 
        items: array of SustainabilityManagement.MassAssessmentItems,
    ) returns array of String;

    action IdhOverwrite (products : array of types.idhOverwrite) returns array of String;

    action   saveRecipients(assessmentId: UUID,
                            recipientEmail: array of types.email,
                            status: types.status)  returns array of String;
    
    event assessmentSaved {
        sbu: types.sbu;
        assessmentId: UUID; 
        type: String(6) enum {
            SINGLE;
            MASS;
        };
    };
    event assessmentSubmitted {
        sbu: types.sbu;
        assessmentId: UUID; 
        type: String(6) enum {
            SINGLE; 
            MASS;
        };
    };
    event assessmentResubmitted {
        sbu: types.sbu;
        assessmentId: UUID; 
        type: String(6) enum {
            SINGLE; 
            MASS;
        };
        approver: types.approver;
    };
    event assessmentUnderResubmission {
        sbu: types.sbu;
        assessmentId: UUID; 
        type: String(6) enum {
            SINGLE; 
            MASS;
        };
        submitter: types.submitter;
    };

};

@path    : 'sustainability/support'
@requires: 'authenticated-user'
service Support {
    //Entitites
    entity SupportSection as projection on support.SupportSectionForm;
    //Functions
    function GetUserRole() returns String;

}

@requires: 'authenticated-user'
service ProductTrackingLog {

    @readonly
    entity ProductLog {
        key ID                      : UUID;
            requestName             : types.requestName;
            sbu                     : types.sbu;
            product                 : types.product;
            productName             : String;
            assessor                : types.assessor;
            submitter               : types.submitter;
            submitionDate           : types.date;
            approver                : types.approver;
            approvalDate            : types.date;
            comment                 : types.comment;
            rcPreFlag               : types.rcPreFlag;
            rcPreFlagDescription    : types.rcPreFlagDescription;
            sustClass               : types.sustClass;
            sustClassDescription    : String;
            category1               : types.category;
            category1Description    : String;
            contributor1            : types.contributor;
            contributor1Description : String;
            category2               : types.category;
            category2Description    : String;
            contributor2            : types.contributor;
            contributor2Description : String;
            category3               : types.category;
            category3Description    : String;
            contributor3            : types.contributor;
            contributor3Description : String;
            propagation             : Boolean;
            toProofDocuments        : Composition of many management.AssessmentProofDocument
                                          on toProofDocuments.requestId = ID;
    }

    @readonly
    entity AssessmentProofDocument as projection on management.AssessmentProofDocument;
    @readonly
    entity ProductProofDocument    as select from management.ProductProofDocumentRelation;

    @readonly
    entity ProofType               as select from management.ProofType;

}
