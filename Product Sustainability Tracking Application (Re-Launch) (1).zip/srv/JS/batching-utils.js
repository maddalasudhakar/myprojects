/**
 * Utility function to divide an array in subarrays of maximmum a given length
 * 
 * @param {*} array 
 * @param {*} batchSize 
 * @returns 
 */
function divideArrayInBatches(array, batchSize) {
    return array.reduce((acc, curr) => {
        if (acc.length === 0) return [[curr]];

        const lastIndex = acc.length - 1;
        if (acc[ lastIndex ].length < batchSize) {
            acc[ lastIndex ].push(curr);
            return acc;
        } else {
            acc.push( [curr] );
            return acc;
        }
    }, []);    
};

/**
 * Splits the items array in batches of given size and then applies provided async function to them
 * 
 * @param {*} array 
 * @param {*} batchSize 
 * @param {*} asyncFunctionForBatch 
 * @param {*} sequential 
 * @param {*} independentTransaction 
 * @returns 
 */
async function applyAsyncFunctionsToBatches(array, batchSize, asyncFunctionForBatch, sequential, independentTransaction) {

    const transactionIndependentFunction = async (data) => {
        let result;
        try {
            await cds.tx(async tx => {
                result = await asyncFunctionForBatch(data);
            });
        } catch (error) {
            console.error(error);
        }
        return result;
    };

    const asyncFunction = independentTransaction ? transactionIndependentFunction : asyncFunctionForBatch;

    const aBatches = divideArrayInBatches(array, batchSize);
    const aPromises = aBatches.reduce((acc, curr) => {
        acc.push(asyncFunction(curr));
        return acc;
    }, []);

    let aResults = [];
    if (sequential) {
        for (const promise of aPromises) {
            const oResult = await promise;
            aResults.push(oResult);
        }
    } else {
        aResults = await Promise.allSettled(aPromises); 
    }
    return aResults;

};

module.exports = {
    divideArrayInBatches,
    applyAsyncFunctionsToBatches,
}