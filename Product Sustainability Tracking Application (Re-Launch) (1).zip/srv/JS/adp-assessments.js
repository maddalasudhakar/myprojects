const cds = require('@sap/cds');
const { divideArrayInBatches } = require('./batching-utils');
const { checkProductsInAssessment, checkProductsInAssessmentforPdpMocHeart, updateOnPremiseAssessmentProduct } = require('./functions');
const { getRules, checkRules } = require("./rules-model/rules-model");
const { clearInvalidSustainabilityFieldsForItem, checkAssessmentFieldValues, getAssessmentFieldMasterData } = require('./assessment-validations');
const { ASSESSMENT_STATUS, ASSESSMENT_TYPE, ASSESSMENT_PROCESS, PRODUCT_TYPE } = require('./assessment');
const { getMyIdUsersByGroup } = require("./notification-utils.js");


/** Default batching size to use whrn updating DB */
const DB_DEFAULT_BATCH_SIZE = 1000;

/** Possible product status for PDP process*/
const PDP_PRODUCT_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    PROCESSED: '03',
};

/** Possible product status for MOC process  */
const MOC_PRODUCT_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    PROCESSED: '03',
};
/**Possible process type for saving users in notification recipients db**/
const PROCESS_TYPE = {
    PDP: "PDP",
    MOC: "MOC",
}

/** Possible services to connect */
const SERVICES = {
    DB: 'db',
    SUSTAINABILITY: 'SustainabilityService',
};

const ROLE = {
    SUBMITTER: 'Submitter',
    ASSESSOR: 'Assessor',
    APPROVER: 'Approver',
    NOTIFICATION: 'Notification',

};

/** Service and DB entities */
const ENTITIES = {
    DB: {
        PDP_PROCESSED_PROJECTS: 'background.PdpProcessedProjects',
        PDP_PROOF_POINTS: 'com.sustainability.background.PdpProofPointsData',
        MOC_PROCESSED_PROJECTS: 'background.MocProcessedProjects',
        MASS_ASSESSMENT_HEADER: 'com.sustainability.management.MassAssessmentHeader',
        MASS_ASSESSMENT_ITEMS: 'com.sustainability.management.MassAssessmentItems',
        ASSESSMENT_PROOF_DOCUMENT: 'com.sustainability.management.AssessmentProofDocument',
        IDH_UPDATED: "com.sustainability.idhupdated",
        IB_UPDATED: "com.sustainability.ibupdated",
        MOC_CONTRIBUTOR_TRANSLATIONS: "com.sustainability.background.MocContributorTranslations",
        PDP_ITEM_ADDITIONALDATA: "com.sustainability.background.MocContributorTranslations"

    }
};

/** Sustainability posible classes */
const SUSTAINABILITY_CLASSES = {
    PIONEER: '05',
    CONTRIBUTOR: '04',
    PERFORMER: '20',
    PERFORMER_T2B: '02',
    TRANSITIONER_T2A: '30',
    TRANSITIONER_T1: '03',
    UNKNOWN: '01'
};


/***************************************************
 * 
 * PDP methods
 * 
 ***************************************************/

/**
 * Method to get products for PDP assessment
 * 
 * @async
 * @param {Object} param0 - Filter parameters to get products to use
 * @param {String} param0.sbu - SBU of product
 * @param {String} param0.productType - Product type
 * @param {String} param0.projectId - ID of the project
 * @param {String} param0.status - Status 
 * @param {String[]} param0.products - List of products
 * @param {String} param0.status - Processing status of ADP project product
 * @returns {Promise<Array>} Products to include in assessment 
 */
async function getProductsForPdpAssessment({ sbu, productType, projectId, products, status }) {

    const db = await cds.connect.to(SERVICES.DB);
    const PdpProcessedProjects = db.entities[ENTITIES.DB.PDP_PROCESSED_PROJECTS];

    const aBatches = divideArrayInBatches(products, DB_DEFAULT_BATCH_SIZE);
    const aProducts = [];
    for (const batch of aBatches) {

        const aProductsBatch = await db.run(
            SELECT.from(PdpProcessedProjects).where({
                sbu,
                productType,
                projectId,
                product: batch,
                status: status,
            })
        );

        for (const products of aProductsBatch) {
            if (!aProducts.some(p => p.product === products.product)) {
                aProducts.push(products);
            }
        }
    //aProducts.push(...aProductsBatch);

    }

    return aProducts;

};

async function getPdpAdpProofDocuments({projectId}) {

    /*const aProjectsId = [...new Set(aProducts.map(i => i.projectId))];

    const aBatches = divideArrayInBatches(aProjectsId, DB_DEFAULT_BATCH_SIZE);
    const aPdpProofPoins = [];
    for (const batch of aBatches) {*/

       const aProofPoints = await cds.run(SELECT().from(ENTITIES.DB.PDP_PROOF_POINTS)
           .columns('ADP_PROJECT_NUMBER as projectId', 'TYPE_OF_PROOF_POINT_KEY as type',
             'TYPE_OF_PROOF_POINT_COMMENT as description', 'PROOF_POINT_DOC_NAME as fileName',
             'PROOF_POINT_URL_LINK as url')
           .where({ ADP_PROJECT_NUMBER: projectId }));


    //}

    return aProofPoints;
}

/**
 * Method to check pending PDP products
 * 
 * @async
 * @param {Object} param0 - Filter parameters to get products to use
 * @param {String} param0.productType - Product type
 * @param {String} param0.status - Status 
 * @param {String[]} param0.products - List of products
 * @param {String} param0.status - Processing status of ADP project product
 * @returns {Promise<Array>} Products to include in assessment 
 */
async function checkPendingPdpProducts({ productType, products, status }) {

    const db = await cds.connect.to(SERVICES.DB);
    const PdpProcessedProjects = db.entities[ENTITIES.DB.PDP_PROCESSED_PROJECTS];

    const aBatches = divideArrayInBatches(products, DB_DEFAULT_BATCH_SIZE);
    const aProducts = [];
    for (const batch of aBatches) {

        const aProductsBatch = await db.run(
            SELECT.from(PdpProcessedProjects)
                .where({
                    productType,
                    product: batch,
                    status: [PDP_PRODUCT_STATUS.PENDING, PDP_PRODUCT_STATUS.RETRIAL]
                })
        );
        aProducts.push(...aProductsBatch);

    }

    return aProducts;

};


/**
 * Set PDP proccesed projects status
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 * @param {string} param0.status - Status to set
 */
async function setPdpProcessedProjectStatus({ projectId, products, status }) {

    const aBatches = divideArrayInBatches(products, DB_DEFAULT_BATCH_SIZE);
    const db = await cds.connect.to(SERVICES.DB);
    const PdpProcessedProjects = db.entities[ENTITIES.DB.PDP_PROCESSED_PROJECTS];

    for (const batch of aBatches) {
        await db.run(
            UPDATE(PdpProcessedProjects)
                .set({ status })
                .where({
                    projectId,
                    product: batch,
                })
        );
    }

};

/**
 * Set PDP proccesed projects status as on retrial
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 * @param {string} param0.status - Status to set
 */
async function setPdpProcessedProjectStatusToRetrial({ projectId, products }) {

    await setPdpProcessedProjectStatus({
        projectId,
        products,
        status: PDP_PRODUCT_STATUS.RETRIAL
    });

};

/**
 * Set PDP proccesed projects status as finished
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 * @param {string} param0.status - Status to set
 */
async function setPdpProcessedProjectStatusToFinished({ projectId, products }) {

    await setPdpProcessedProjectStatus({
        projectId,
        products,
        status: PDP_PRODUCT_STATUS.PROCESSED
    });

};

/**
 * Validations before PDP assessment creation
 * 
 * @param {*} products - Data of the products to be assessed
 * @returns {Object} object inidcating if any error has been found
 */
async function checkPdpAssessmentDataBeforeCreate(products) {

    const oValidation = {
        isValid: true,
        reason: '',
        productsWithError: [],
        assessmentData: []
    };

    // Check if there are any products with an ongoing assessment
    const aProductsInAssessment = await checkProductsInAssessmentforPdpMocHeart(
        products.map(product => product.product)
    );
    if (aProductsInAssessment && aProductsInAssessment.length > 0) {
        const sProductIds = aProductsInAssessment.map(item => item.product).join(', ');

        oValidation.isValid = false;
        oValidation.reason = `Products already in Assessment: ${sProductIds}`;
        oValidation.productsWithError = aProductsInAssessment.map(item => item.product);
        oValidation.assessmentData = aProductsInAssessment;

        return oValidation
    }

    return oValidation;

};

/**
 * Builds PDP assessment fields from Datasphere data
 * 
 * @param {Object[]} productsData - Array of assessment prodcuts
 * @param {Object[]} aAdpProofDocuments - proof points related with ADPs projects 
 * @param {Object[]} relatedIbProofDocuments - proof points related with IBs 
 * @param {Object[]} existingProofDocuments - proof points related with IDHs 

 * @returns {}
 */
async function buildPdpAssessment(productsData, aAdpProofDocuments, relatedIbProofDocuments, existingProofDocuments) {

    if (!productsData || productsData.length === 0) return;

    // Build basic data
    const oHeader = await buildPdpAssessmentHeader(productsData[0]);
    const aItems = await buildPdpAssessmentItems(productsData, aAdpProofDocuments, relatedIbProofDocuments, existingProofDocuments, oHeader.ID);
    const oAssessment = {
        header: oHeader,
        items: aItems,
    };

    // Validate assessment data for inconsistencies
    const oCheck = await checkAndClearPdpMocAssessmentSustainabilityData(oAssessment);

    // If all checks are passed, assessment is kept as submitted. 
    // Else, change it to saved to review
    if (!oCheck.isValid) {

        oAssessment.header.status = ASSESSMENT_STATUS.SAVED;
        delete oAssessment.header.submitter;
        delete oAssessment.header.submitionDate;
        oAssessment.items.forEach(item => {
            item.status = ASSESSMENT_STATUS.SAVED;
            delete item.submitter;
            delete item.submitionDate;
        });

    }

    return oAssessment;
};

/**
 * Builds PDP initial mass assessment data to be filled
 * 
 * @param {Object} productData - Data of one of the products to include in assessment
 * @returns {Object} Built assessment header
 */
async function buildPdpAssessmentHeader(productData) {

  const bUseSustainability = await checkPdpAssessorAndSubmitterFields(productData);

    const oHeader = {
        ID: cds.utils.uuid(),
        requestName: `PDP - ${productData.projectId}`,
        sbu: productData.sbu,
        assessor: bUseSustainability ? productData.sustainability : productData.assessor,
        productType: productData.productType,
        submitter: bUseSustainability ? productData.sustainability :productData.submitter,
        submitionDate: new Date().toISOString().slice(0, 10),
        // approver: ,
        // approvalDate: ,
        assesmentType: ASSESSMENT_TYPE.MASS,
        status: ASSESSMENT_STATUS.SUBMITTED,
        processType: ASSESSMENT_PROCESS.PDP,
        virtualAssessment: false,
        projectId: productData.projectId,
    };

    return oHeader;
};

/**
 * Builds PDP initial mass assessment items data to be filled
 * 
 * @param {Object[]} products - Product data to use 
 * @param {Object[]} aAdpProofDocuments - Related ADPs proof documents to add
 * @param {Object[]} relatedIbProofDocuments - Related IB proof documents to add
 * @param {Object[]} existingProofDocuments - Related existing proof documents to add
 * @param {string} headerId - Generated header ID
 * @returns {Object[]} List of mass assessment items built
 */
async function buildPdpAssessmentItems(products, aAdpProofDocuments, relatedIbProofDocuments, existingProofDocuments, headerId) {

  const bUseSustainability = await checkPdpAssessorAndSubmitterFields(products[0]);

    const sAssessor = bUseSustainability ? products[0].sustainability : products[0].assessor,
        sSubmitter = bUseSustainability ? products[0].sustainability : products[0].submitter;

    const DEFAULT_PROOFPOINT = {
        TYPE: '18', // Other
        DESCRIPTION: 'Automated Load from Planview',
    };

    const aItems = products.map(item => {

        const sItemId = cds.utils.uuid();

        // Map proof document data to format, both incoming and existing in related IBs
        const aProofDocuments = [
            ...(
                aAdpProofDocuments
                    .filter(document => document.projectId === item.projectId)
                    .map(document => {
                        const { type, description, fileName, url } = document;
                        return {
                            requestId: sItemId,
                            type: type ? type : DEFAULT_PROOFPOINT.TYPE,
                            description: description ? description : DEFAULT_PROOFPOINT.DESCRIPTION,
                            fileName,
                            url,
                            active: true,
                            externalUrl: true,
                        };
                    })
            ),
            ...(
                relatedIbProofDocuments
                    .find(document => document.material === item.product)?.productProofDocuments || [])
                    .map(document => {
                        const { type, description, fileName, url, externalUrl, active, product, proofPointId } = document;
                        return {
                            requestId: sItemId,
                            type,
                            description,
                            fileName,
                            url,
                            externalUrl,
                            active: active === null ? true : active,
                            imageMasterID: proofPointId,
                            productReference: product,
                        };
                    }
            ),
            ...(
                existingProofDocuments
                    .filter(document => document.product === item.product)
                    .map(document => {
                        const { type, description, fileName, url, externalUrl, active, proofPointId } = document;
                        return {
                            requestId: sItemId,
                            type,
                            description,
                            fileName,
                            url,
                            externalUrl,
                            imageMasterID: proofPointId,
                            active: active === null ? true : active,
                        };
                    })
            ),

        ];

        // Final item to return
        const oItem = {
            ID: sItemId,
            headerId,
            virtualAssessment: false,
            status: ASSESSMENT_STATUS.SUBMITTED,
            product: item.product,
            productType: item.productType,
            assessor: sAssessor,
            submitter: sSubmitter,
            sbu: item.sbu,
            comment: item.assessmentExplanation,
            rcPreFlag: item.rcPreFlag,
            rcPreFlagDescription: item.rcPreFlagDescription,
            sustClass: item.sustClass,
            category1: item.category1,
            contributor1: item.contributor1,
            category2: item.category2,
            contributor2: item.contributor2,
            category3: item.category3,
            contributor3: item.contributor3,
            propagation: item.productType === PRODUCT_TYPE.IDH,
            externalCommunication: false,
            toProofDocuments: aProofDocuments,
            toAdditionalData: {
                pdp: {
                    assessor: item.assessor,
                    submitter: item.submitter,
                    sustainabiltiy: item.sustainability,
                    projectManager: item.projectManager,
                    launchGateMeetingDate: item.finalDate,
                    sustainabilityClass_code: item.sustClass,
                    category1_code: item.category1,
                    contributor1_code: item.contributor1,
                    category2_code: item.category2,
                    contributor2_code: item.contributor2,
                    category3_code: item.category3,
                    contributor3_code: item.contributor3,
                }
            }
        };

        return oItem;

    });

    return aItems;

};

/**
 * Checks for any data inconsistency in sustainability related fields and if
 * needed, clears it
 * 
 * @param {Object} param0 - Assessment data
 * @param {Object[]} param0.header - Mass assessment header
 * @param {Object[]} param0.items - Mass assessment items
 */
async function checkAndClearPdpMocAssessmentSustainabilityData({ header, items }) {

    let oResult = {
        isValid: true,
        reasons: [],
    };

    const oMasterData = await getAssessmentFieldMasterData();
    const oRules = await getRules();
    for (const oItem of items) {

        //const oItem = { ...item };
        oItem.requestName = header.requestName;
        oItem.approbalStatus = header.status;

        // First check if assessment is correct according to rules. 
        // If an error related to sustainability fields is risen, then individual fields are 
        // checked to clear wrong sustainbility fields 
        const oCheckRule = await checkRules(oItem, oRules, oMasterData.contributor);
        if (!oCheckRule.continue) {

            // Error found, delete sustainability fields that are wrong if needed
            if (oCheckRule.hasSustainabilityError) {
                clearInvalidSustainabilityFieldsForItem(oItem, oMasterData.contributor, oRules);
            }

            oResult.isValid = oCheckRule.continue;
            oResult.reasons.push(`Product ${oItem.product}: ${oCheckRule.reason}`);

        } else {

            // Check if fields correspond to masterdata
            const oCheckValues = await checkAssessmentFieldValues(oItem, oMasterData);
            if (!oCheckValues.valid) {
                oResult.isValid = oCheckValues.valid;
                oResult.reasons.push(`Product ${oItem.product}: ${oCheckValues.reason}`)
            }

        }
        delete oItem.requestName;
        delete oItem.approbalStatus;

    }

    return oResult;

};

/**
 * Create PDP assessment in DB
 * 
 * @param {Object} param0 - Assessment data
 * @param {Object} param0.header - Mass assessment header data
 * @param {Object[]} param0.items - List of assessment items 
 */
async function createPdpAssessment({ header, items }) {

    const aItems = items.map(item => {
        const oItem = { ...item };
        delete oItem.toProofDocuments;
        return oItem;
    });
    const aProofDocuments = items.flatMap(item => item.toProofDocuments);

    const db = await cds.connect.to('db');
    await db.run(async tx => {
        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_HEADER).entries([header]);
        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(aItems);
        if (aProofDocuments.length > 0) {
            await INSERT
                .into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT)
                .entries(aProofDocuments);
        }
    });

};

/**
 * Validate PDP assessor and submitter fields
 * 
 * @param {Object} productData - Product information to validate
 * @returns {Promise<boolean>} True if sustainability email is valid and belongs to a PDP approver
 */
async function checkPdpAssessorAndSubmitterFields(productData) {

    const sEmailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let bIsApprover = false;

    const bIsEmail = sEmailRegex.test(productData.sustainability);

    if (bIsEmail) {
        const aUsers = await getMyIdUsersByGroup({ sbu: productData.sbu, role: ROLE.APPROVER, processType: PROCESS_TYPE.PDP });

        bIsApprover = aUsers.some(oUser => oUser.email === productData.sustainability);
    }

    if (!bIsEmail || !bIsApprover) {
        return false;
    }

    return true;
}

/***************************************************
 * 
 * MOC methods
 * 
 ***************************************************/

/**
 * Method to get products for MOC assessment
 * 
 * @async
 * @param {Object} param0 - Filter parameters to get products to use
 * @param {String} param0.sbu - SBU of product
 * @param {String} param0.productType - Product type
 * @param {String} param0.projectId - ID of the project
 * @param {String} param0.status - Status 
 * @param {String[]} param0.products - List of products
 * @returns {Promise<Array>} Products to include in assessment 
 */
async function getProductsForMocAssessment({ sbu, productType, projectId, products, status }) {

    const db = await cds.connect.to(SERVICES.DB);
    const oMocProcessedProjects = db.entities[ENTITIES.DB.MOC_PROCESSED_PROJECTS];

    const aBatches = divideArrayInBatches(products, DB_DEFAULT_BATCH_SIZE);
    const aProducts = [];
    for (const batch of aBatches) {

        const aProductsBatch = await db.run(
            SELECT
                .from(oMocProcessedProjects)
                .where({
                    sbu,
                    productType,
                    projectId,
                    product: batch,
                    status: status
                })
        );
        //aProducts.push(...aProductsBatch);

        for (const products of aProductsBatch) {
            if (!aProducts.some(p => p.product === products.product)) {
                aProducts.push(products);
            }
        }

    }

    return aProducts;

};

/**
 * Validations before MOC assessment creation
 * 
 * @param {*} products - Data of the products to be assessed
 * @returns {Object} object inidcating if any error has been found
 */
async function checkMocAssessmentDataBeforeCreate(products) {

   const oValidation = {
        isValid: true,
        reason: '',
        productsWithError: [],
        assessmentData: []
    };

    // Check if there are any products with an ongoing assessment
    const aProductsInAssessment = await checkProductsInAssessmentforPdpMocHeart(
        products.map(product => product.product)
    );
    if (aProductsInAssessment && aProductsInAssessment.length > 0) {
        const sProductIds = aProductsInAssessment.map(item => item.product).join(', ');

        oValidation.isValid = false;
        oValidation.reason = `Products already in Assessment: ${sProductIds}`;
        oValidation.productsWithError = aProductsInAssessment.map(item => item.product);
        oValidation.assessmentData = aProductsInAssessment;

        return oValidation
    }

    return oValidation;

};

/**
 * Set MOC proccesed projects status as on retrial
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 */
async function setMocProcessedProjectStatusToRetrial({ projectId, products }) {

    await setMocProcessedProjectStatus({
        projectId,
        products,
        status: MOC_PRODUCT_STATUS.RETRIAL
    });

};

/**
 * Set MOC proccesed projects status
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 * @param {string} param0.status - Status to set
 */
async function setMocProcessedProjectStatus({ projectId, products, status }) {

    const aBatches = divideArrayInBatches(products, DB_DEFAULT_BATCH_SIZE);
    const db = await cds.connect.to(SERVICES.DB);
    const PdpProcessedProjects = db.entities[ENTITIES.DB.MOC_PROCESSED_PROJECTS];

    for (const batch of aBatches) {
        await db.run(
            UPDATE(PdpProcessedProjects)
                .set({ status })
                .where({
                    projectId,
                    product: batch,
                })
        );
    }

};

/**
 * Build MOC assessment from Datasphere data
 * 
 * @param {Object[]} productsData - Array with the products for which the assessment will be created
 * @param {Object[]} relatedIbProofDocuments - List of IB's documents associated with IDHs
 * @param {Object[]} aExistingProofDocuments - List of product's documents

 * @returns {}
 */
async function buildMocAssessment(productsData, relatedIbProofDocuments, aExistingProofDocuments) {

    if (!productsData || productsData.length === 0) return;

    // Build basic data
    const oHeader = await buildMocAssessmentHeader(productsData[0]);
    const aItems = await buildMocAssessmentItems(productsData, relatedIbProofDocuments, aExistingProofDocuments, oHeader.ID);
    const oAssessment = {
        header: oHeader,
        items: aItems,
    };

    // Validate assessment data for inconsistencies
    await checkAndClearPdpMocAssessmentSustainabilityData(oAssessment);

    return oAssessment;
};

/**
 * Build MOC initial mass assessment data to be filled
 * 
 * @param {Object} productData - Data of one of the products to include in assessment
 * @returns {Object} Built assessment header
 */
async function buildMocAssessmentHeader(productData) {

    const bUseSustainability = await checkMocAssessorAndSubmitterFields(productData);

    const oHeader = {
        ID: cds.utils.uuid(),
        requestName: `MOC - ${productData.projectId}`,
        sbu: productData.sbu,
        assessor: bUseSustainability ? productData.sustainability : productData.assessor,
        productType: productData.productType,
        assesmentType: ASSESSMENT_TYPE.MASS,
        status: ASSESSMENT_STATUS.SAVED,
        processType: ASSESSMENT_PROCESS.MOC,
        virtualAssessment: false,
        projectId: productData.projectId,
    };

    return oHeader;
};

/**
 * Build MOC initial mass assessment items data to be filled
 * 
 * @param {Object[]} products - Product data to use 
 * @param {Object[]} relatedIbProofDocuments - Related IB proof documents to add
 * @param {Object[]} existingProofDocuments - Related existing proof documents to add
 * @param {string} headerId - Generated header ID
 * @returns {Object[]} List of mass assessment items built
 */
async function buildMocAssessmentItems(products, relatedIbProofDocuments, existingProofDocuments, headerId) {

    const bUseSustainability = await checkMocAssessorAndSubmitterFields(products[0]);

    const sAssessor = bUseSustainability ? products[0].sustainability : products[0].assessor;

    const aItems = await Promise.all(
        products.map(async (item) => {

            const sItemId = cds.utils.uuid();

            // Map proof document data
            const aProofDocuments = [
                ...(
                    relatedIbProofDocuments.filter(document => document.material === item.product)
                        .map(document => document.productProofDocuments)
                        .map(document => {
                            const { type, description, fileName, url, externalUrl, active, proofPointId } = document;
                            return {
                                requestId: sItemId,
                                type,
                                description,
                                fileName,
                                url,
                                externalUrl,
                                imageMasterID: proofPointId,
                                active: active === null ? true : active,
                                productReference: document.product,
                            };
                        })
                ),
                ...(
                    existingProofDocuments
                        .find(document => document.material === item.product)?.productProofDocuments || [])
                        .map(document => {
                            const { type, description, fileName, url, externalUrl, active, proofPointId } = document;
                            return {
                                requestId: sItemId,
                                type,
                                description,
                                fileName,
                                url,
                                externalUrl,
                                imageMasterID: proofPointId,
                                active: active === null ? true : active,
                            };
                        }
                ),

            ];

            const {
                sSustClass,
                sCategory1,
                sCategory2,
                sCategory3,
                sContributor1,
                sContributor2,
                sContributor3,
                sAssessmentExplanation
            } = await determineSustainabilityClass(item);

            // Final item to return
            const oItem = {
                ID: sItemId,
                headerId: headerId,
                virtualAssessment: false,
                status: ASSESSMENT_STATUS.SAVED,
                product: item.product,
                productType: item.productType,
                assessor: sAssessor,
                sbu: item.sbu,
                comment: sAssessmentExplanation,
                rcPreFlag: item.rcPreFlag,
                rcPreFlagDescription: item.rcPreFlagDescription,
                sustClass: sSustClass,
                category1: sCategory1,
                category2: sCategory2,
                category3: sCategory3,
                contributor1: sContributor1,
                contributor2: sContributor2,
                contributor3: sContributor3,
                propagation: item.productType === PRODUCT_TYPE.IDH,
                externalCommunication: false,
                toProofDocuments: aProofDocuments,
                toAdditionalData: {
                    moc: {
                        assessor: item.assessor,
                        submitter: item.submitter,
                        sustainabiltiy: item.sustainability,
                        projectManager: item.projectManager,
                        launchGateMeetingDate: item.finalDate,
                        sustainabilityClass_code: item.sustClass,
                        category1_code: item.category1,
                        contributor1: item.contributor1
                    }
                }
                
            };

            return oItem;

        })
    );

    return aItems;

};

/**
 * Create MOC assessment in DB
 * 
 * @param {Object} param0 - Assessment data
 * @param {Object} param0.header - Mass assessment header data
 * @param {Object[]} param0.items - List of assessment items 
 */
async function createMocAssessment({ header, items }) {

    const aItems = items.map(item => {
        const oItem = { ...item };
        delete oItem.toProofDocuments;
        return oItem;
    });

    const aProofDocuments = items.flatMap(item => item.toProofDocuments);

    const db = await cds.connect.to('db');
    await db.run(async tx => {
        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_HEADER).entries([header]);
        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(aItems);
        if (aProofDocuments.length > 0) {
            await INSERT.into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).entries(aProofDocuments);
        }
    });

};

/**
 * Set MOC proccesed projects status as finished
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.projectId - ID of the project to update
 * @param {string[]} param0.products - List of the products to update
 */
async function setMocProcessedProjectStatusToFinished({ projectId, products }) {

    await setMocProcessedProjectStatus({
        projectId,
        products,
        status: MOC_PRODUCT_STATUS.PROCESSED
    });

};

/**
 * Determines the new sustainability class based on the RC-PreFlag value and the current class.
 * 
 * @param {Object} item 
 * @returns 
 */
async function determineSustainabilityClass(item) {

    const aExistingData = await fetchDataByType(item.productType, item.product);
    const sRCFlag = item.rcPreFlag;
    const sMocFlag = item.sustClass;
    const sExistSustClass = aExistingData[0]?.sustClass;
    let sSustClass = item.sustClass;
    let sCategory1 = item.category1;
    let sCategory2;
    let sCategory3;
    let sContributor1 = item.contributor1;
    let sContributor2;
    let sContributor3;
    let sAssessmentExplanation;
    let sTranslatedContributor;
    let oResult;

    const aDirectSustClasses = [
        SUSTAINABILITY_CLASSES.PERFORMER_T2B,
        SUSTAINABILITY_CLASSES.TRANSITIONER_T2A,
        SUSTAINABILITY_CLASSES.TRANSITIONER_T1,
        SUSTAINABILITY_CLASSES.UNKNOWN
    ];

    // If the RC flag is one of the direct classes, assign it directly
    if (aDirectSustClasses.includes(sRCFlag)) {
        sSustClass = sRCFlag;
    } else {
        // Check if any of the current classes (MOC or existing) is Contributor or Pioneer
        const bHasContributorOrPioneer = [sMocFlag, sExistSustClass].some(sEvaluatedClass =>
            [SUSTAINABILITY_CLASSES.CONTRIBUTOR, SUSTAINABILITY_CLASSES.PIONEER].includes(sEvaluatedClass)
        );

        // If RC is Contributor, assign Contributor if there's already a high class, otherwise Performer
        if (sRCFlag === SUSTAINABILITY_CLASSES.CONTRIBUTOR) {
            sSustClass = bHasContributorOrPioneer
                ? SUSTAINABILITY_CLASSES.CONTRIBUTOR
                : SUSTAINABILITY_CLASSES.PERFORMER;
            // If RC is Pioneer, check if a high class exists to determine final class
        } else if (sRCFlag === SUSTAINABILITY_CLASSES.PIONEER) {
            if (bHasContributorOrPioneer) {
                sSustClass =
                    [sMocFlag, sExistSustClass].includes(SUSTAINABILITY_CLASSES.PIONEER)
                        ? SUSTAINABILITY_CLASSES.PIONEER
                        : SUSTAINABILITY_CLASSES.CONTRIBUTOR;
            } else {
                // If no high class exists, assign Performer
                sSustClass = SUSTAINABILITY_CLASSES.PERFORMER;
            }
        }
    }

    // Fetch the translated contributor from the database 
    if (item.contributor1) {
        const db = await cds.connect.to('db');
        oResult = await db.run(
            SELECT.one.from(ENTITIES.DB.MOC_CONTRIBUTOR_TRANSLATIONS)
                .where({ mocContributor: item.contributor1 })
        );
    }

    // Extract translation code and assessment explanation
    if (oResult) {
        sTranslatedContributor = oResult.pstContributor_code;
        sAssessmentExplanation = oResult.assessmentExplanation;
    }
    // Assign the translated contributor to the first available slot
    const contributorSlots = [
        aExistingData[0].contributor1,
        aExistingData[0].contributor2,
        aExistingData[0].contributor3
    ];
    let firstEmptyContributor = contributorSlots.findIndex(contributor => !contributor);
    if (firstEmptyContributor === -1) {
        firstEmptyContributor = 2;
    }
    contributorSlots[firstEmptyContributor] = sTranslatedContributor;

    [sContributor1, sContributor2, sContributor3] = contributorSlots;

    // Assign the category to the first available slot

    const categorySlots = [
        aExistingData[0].category1,
        aExistingData[0].category2,
        aExistingData[0].category3
    ];

    let firstEmptyCategory = categorySlots.findIndex(category => !category);
    if (firstEmptyCategory === -1) {
        firstEmptyCategory = 2;
    }
    categorySlots[firstEmptyCategory] = item.category1;


    [sCategory1, sCategory2, sCategory3] = categorySlots;


    return {
        sSustClass,
        sCategory1,
        sCategory2,
        sCategory3,
        sContributor1,
        sContributor2,
        sContributor3,
        sAssessmentExplanation
    };

}

/**
 * Validate MOC assessor and submitter fields
 * 
 * @param {Object} productData - Product information to validate
 * @returns {Promise<boolean>} True if sustainability email is valid and belongs to a MOC approver
 */
async function checkMocAssessorAndSubmitterFields(productData) {

    const sEmailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let bIsApprover = false;

    const bIsEmail = sEmailRegex.test(productData.sustainability);

    if (bIsEmail) {
        const aUsers = await getMyIdUsersByGroup({ sbu: productData.sbu, role: ROLE.APPROVER, processType: PROCESS_TYPE.MOC });

        bIsApprover = aUsers.some(oUser => oUser.email === productData.sustainability);
    }

    if (!bIsEmail || !bIsApprover) {
        return false;
    }

    return true;
}

/**
 * Fetch product data from IDH or IB table by product ID.
 * 
 * @async
 * @param {string} type -
 * @param {string|number} productID - Product MATERIALTNUMBER to query.
 * @returns Product data.
 */
async function fetchDataByType(sType, sProductId) {
    const db = await cds.connect.to('db');

    const sTableName = sType === 'IDH' ? ENTITIES.DB.IDH_UPDATED : ENTITIES.DB.IB_UPDATED;

    const aResults = await db.run(
        SELECT.from(sTableName)
            .columns(
                'MATERIALTNUMBER as product',
                'SUSTCLASS as sustClass',
                'CATEGORY as category1',
                'CATEGORY2 as category2',
                'CATEGORY3 as category3',
                'CONTRIBUTOR as contributor1',
                'CONTRIBUTOR2 as contributor2',
                'CONTRIBUTOR3 as contributor3'
            )
            .where({ MATERIALTNUMBER: sProductId })
    );

    return aResults;
}




module.exports = {
    PDP_PRODUCT_STATUS,
    getProductsForPdpAssessment,
    setPdpProcessedProjectStatusToRetrial,
    setPdpProcessedProjectStatusToFinished,
    checkPdpAssessmentDataBeforeCreate,
    buildPdpAssessment,
    createPdpAssessment,
    MOC_PRODUCT_STATUS,
    getProductsForMocAssessment,
    checkMocAssessmentDataBeforeCreate,
    setMocProcessedProjectStatusToRetrial,
    buildMocAssessment,
    createMocAssessment,
    setMocProcessedProjectStatusToFinished,
    checkPdpAssessorAndSubmitterFields,
    checkMocAssessorAndSubmitterFields,
    checkPendingPdpProducts,
    getPdpAdpProofDocuments,
    PROCESS_TYPE,
}