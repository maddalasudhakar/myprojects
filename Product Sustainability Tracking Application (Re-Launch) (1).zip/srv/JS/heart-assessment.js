const cds = require('@sap/cds');

const { 
    ASSESSMENT_PROCESS, 
    getSustainabilityClassMasterData, 
    ASSESSMENT_STATUS, 
    PRODUCT_TYPE,
    ASSESSMENT_TYPE,
    getProductProofDocuments,
    getRelatedIbProofDocuments,
} = require('./assessment');

const { 
    checkProductsInAssessmentforPdpMocHeart,
} = require('./functions');

const { 
    clearInvalidSustainabilityFieldsForItem, 
    checkAssessmentFieldValues, 
    getAssessmentFieldMasterData 
} = require('./assessment-validations');

const { getRules, checkRules } = require("./rules-model/rules-model");

const { divideArrayInBatches } = require('./batching-utils');
const { rootNode } = require('./heart-assessment-status-decision-tree');

/** Entities used */
const ENTITIES = {
    DB: {
        HEART_EXECUTION: 'com.sustainability.background.HeartExecution',
        MASS_ASSESSMENT_HEADER: 'com.sustainability.management.MassAssessmentHeader',
        MASS_ASSESSMENT_ITEMS: 'com.sustainability.management.MassAssessmentItems',
        ASSESSMENT_PROOF_DOCUMENT: 'com.sustainability.management.AssessmentProofDocument',
    },
};

/** Default batch size */
const DEFAULT_DB_BATCH_SIZE = 1000;

/** Trigger name for assessment naming template */
const TRIGGER_NAME = 'HEART';

/** Proof point type for exemption L3 */
const EXEMPTION_L3_DOCUMENT = '20';

/** Possible product status for heart process  */
const HEART_PRODUCT_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    PROCESSED: '03',
};

/** Reason data */
const VALIDATION_REASON = {
    PRODUCTS_BLOCKED: 'Ongoing assessment',
};

/** Mapping between assessment status codes and their request name suffix. */
const STATUS_FOR_ASSESSMENTS = [
    { status: ASSESSMENT_STATUS.SAVED, nameSuffix: '_SAVED' },
    { status: ASSESSMENT_STATUS.SUBMITTED, nameSuffix: '_SUBMITTED' },
];

/**
 * Get HEART product data to create assessment
 * 
 * @async
 * @param {string} sbu - SBU 
 * @param {string[]} products - List of products
 * @param {string} status - Status of heart entry
 * @param {String} heartRunId - Date of HEART ID
 * @returns {Promise<Object[]>} List of products with relevant HEART data
 */
async function getHeartProductData(sbu, products, status, heartRunId) {

    const aProducts = [];
    const aBatches = divideArrayInBatches(products, DEFAULT_DB_BATCH_SIZE);
    for( const batch of aBatches) {  
        const aProductsBatch = await cds.db.run(
            SELECT
                .from(ENTITIES.DB.HEART_EXECUTION)
                .where({
                    material: batch,
                    heartRunId,
                    sbu,
                    // status,
                })
        );
        aProducts.push(
            ...aProductsBatch,
        )
    }
    
    return aProducts;

};

/**
 * Build Assessment data for HEART. It builds either a saved assessment,
 * a submitted one or both
 * 
 * @param {Object[]} productData - List of product data
 * @returns {Promise<Object[]>} Assesment header and items 
 */
async function buildHeartAssessment(productData) {

    // Retrieve sustainability class master data for calculations
    const aSustainabilityClassMasterData = await getSustainabilityClassMasterData();
    
    // Get already existing proof documents
    const aExistingProofDocuments = await getProductProofDocuments(productData.map(item => item.material));

    // Get related IB documents in case it is an IDH
    const aRelatedIbProofDocuments = await getRelatedIbProofDocuments(productData.map(item => item.material));
    
    // Create generic data for assessments
    const oGenericHeader = buildGenericHeartAssessmentHeader(productData[0]);
    const aGenericItems = buildGenericHeartAssessmentItems(
        productData, 
        aRelatedIbProofDocuments, 
        aExistingProofDocuments, 
        aSustainabilityClassMasterData,
    );

    /** Existing headers matching the current request name prefix. */
    const aHeadersByRequestName = await getMassAssessmentHeadersByRequestName(oGenericHeader.requestName);


    // Generate assessments to be created
    const aHeartAssessments = [];

    for (const statusOption of STATUS_FOR_ASSESSMENTS) {

        // Check if items to be created as saved are processed. If so, 
        // a saved assessment is generated
        if (aGenericItems.some(item => item.status === statusOption.status)) {
            const oSavedHeader = { ...oGenericHeader };
            oSavedHeader.ID = cds.utils.uuid();
            oSavedHeader.status = statusOption.status;
            oSavedHeader.requestName += statusOption.nameSuffix;
            
            const aSavedItems = aGenericItems
                .filter(item => item.status === statusOption.status)
                .map(item => {
                    return {
                        ...item,
                        headerId: oSavedHeader.ID,
                    };
                });

            aHeartAssessments.push({
                header: oSavedHeader,
                items: aSavedItems,
            });
        }

    }
    
    // Validate and clear data from created assessments. Merge assessments with same status
    const aClearedAssessments = [];
    for (const assessment of aHeartAssessments) {

        // Validate assessment data for inconsistencies
        const oCheck = await checkAndClearHeartAssessmentSustainabilityData(assessment);

        // If all checks are passed, assessment is kept as submitted. 
        // Else, change it to saved to review
        if (!oCheck.isValid && assessment.header.status === ASSESSMENT_STATUS.SUBMITTED) {

            const aSavedItems = assessment.items
                .filter(item => oCheck.productsToSave.includes(item.product))
                .map(item => {
                    return {
                        ...item,
                        status: ASSESSMENT_STATUS.SAVED,
                        submitter: null,
                    };
                });           
            
            // Remove save items from submitted assessment 
            assessment.items = assessment.items.filter(item => !oCheck.productsToSave.includes(item.product));
            
            // Add save items to save assessments or create it if does not exist
            const oSavedAssessment = aHeartAssessments.find(assessment => assessment.header.status === ASSESSMENT_STATUS.SAVED);
            const oClearedAssessment = aClearedAssessments.find(assessment => assessment.header.status === ASSESSMENT_STATUS.SAVED);
            if (oClearedAssessment) {
                aSavedItems.forEach(item => {item.headerId = oClearedAssessment.header.ID});
                oClearedAssessment.items.push(...aSavedItems);   
            } else if (oSavedAssessment) { 
                oSavedAssessment.items.push(...aSavedItems);  
            } else {
                const oNewSavedAssessment = {
                    header: {...aHeartAssessments[0].header},
                    items: aSavedItems,
                };

                // Name fixing
                const sStatusSubmittedSuffix = STATUS_FOR_ASSESSMENTS.find(
                    item => item.status === ASSESSMENT_STATUS.SUBMITTED
                ).nameSuffix;
                const sStatusSavedSuffix = STATUS_FOR_ASSESSMENTS.find(
                    item => item.status === ASSESSMENT_STATUS.SAVED
                ).nameSuffix;
                oNewSavedAssessment.requestName = oNewSavedAssessment
                    .requestName
                    .replace(sStatusSubmittedSuffix, sStatusSavedSuffix);

                oNewSavedAssessment.header.status = ASSESSMENT_STATUS.SAVED;
                aClearedAssessments.push(oNewSavedAssessment);
            }   

            // Lastly, if still has more submitted items, add also to final assessments 
            if (assessment.items.length > 0) {         
                aClearedAssessments.push(assessment)
            }

        } else {

            // Check if saved assessment already exist
            const oClearedAssessment = aClearedAssessments.find(
                clearedAssessment => clearedAssessment.header.status === assessment.header.status
            );
            if (oClearedAssessment) {
                assessment.items.forEach(item => {item.headerId = oClearedAssessment.header.ID});
                oClearedAssessment.items.push(...assessment.items);  
            } else {
                aClearedAssessments.push(assessment);
            }   

        }

    }

    /** Assign sequential request name per status and update existing headers list. */
    for (const assessment of aClearedAssessments) {

        const nextNumber = getNextNumberForStatus(
            assessment.header.status,
            aHeadersByRequestName
        );

        assessment.header.requestName =
            `${assessment.header.requestName}-${nextNumber}`;

        aHeadersByRequestName.push({
            requestName: assessment.header.requestName
        });
    }
  
        const aDiscardedProducts = aGenericItems.filter(item => !item.status);

    return { 
        assessmentsToCreate: aClearedAssessments, 
        discardedProducts: aDiscardedProducts 
    };

};

/**
 * Checks for any data inconsistency in sustainability related fields and if
 * needed, clears it
 * 
 * @param {Object} param0 - Assessment data
 * @param {Object[]} param0.header - Mass assessment header
 * @param {Object[]} param0.items - Mass assessment items
 */
async function checkAndClearHeartAssessmentSustainabilityData({ header, items }) {

    const oResult = {
        isValid: true,
        reasons: [],
        productsToSave: [],
    };

    const oMasterData = await getAssessmentFieldMasterData();
    const oRules = await getRules();
    for (const oItem of items) {

        //const oItem = { ...item };
        oItem.requestName = header.requestName;
        oItem.approbalStatus = header.status;

        // First check if assessment is correct according to rules. 
        // If an error related to sustainability fields is risen, then individual fields are 
        // checked to clear wrong sustainbility fields 
        const oCheckRule = await checkRules(oItem, oRules, oMasterData.contributor);
        if (!oCheckRule.continue) {

            // Error found, delete sustainability fields that are wrong if needed
            if (oCheckRule.hasSustainabilityError) {
                clearInvalidSustainabilityFieldsForItem(oItem, oMasterData.contributor, oRules);
            }

            oResult.isValid = oCheckRule.continue;
            oResult.reasons.push(`Product ${oItem.product}: ${oCheckRule.reason}`);
            oResult.productsToSave.push(oItem.product);

        } else {

            // Check if fields correspond to masterdata
            const oCheckValues = await checkAssessmentFieldValues(oItem, oMasterData);
            if (!oCheckValues.valid) {
                oResult.isValid = oCheckRule.continue;
                oResult.reasons.push(`Product ${oItem.product}: ${oCheckValues.reason}`);
                oResult.productsToSave.push(oItem.product);
            }

        }
        delete oItem.requestName;
        delete oItem.approbalStatus;

    }

    return oResult;

};

/**
 * Builds generic HEART assessment header
 * 
 * @param {Object[]} data - Data to use in assessment creation
 * @returns {Object} Assessment header
 */
function buildGenericHeartAssessmentHeader(data) {

    const today = new Date();
    const formattedDate = today.toISOString().slice(2, 10).replace(/-/g, '.');

    const oHeader = {
        requestName: `${TRIGGER_NAME}_${data.sbu}_${formattedDate}`,
        sbu: data.sbu,
        assessor: data.assessor,
        productType: data.productType,
        submitter: data.submitter,
        submitionDate: today,
        // approver: ,
        // approvalDate: ,
        assesmentType: ASSESSMENT_TYPE.MASS,
        status: ASSESSMENT_STATUS.SUBMITTED,
        processType: ASSESSMENT_PROCESS.HEART,
        virtualAssessment: false,
    };

    return oHeader;

};

/**
 * Builds HEART initial mass assessment items data to be filled
 * 
 * @param {Object[]} products - Product data to use 
 * @param {Object[]} relatedIbProofDocuments - Related IB proof documents to add
 * @param {Object[]} existingProofDocuments - Related existing proof documents to add
 * @param {Object[]} sustainabilityClassMasterData - Sustainability class masterdata
 * @returns {Object[]} List of mass assessment items built
 */
function buildGenericHeartAssessmentItems(
    products, 
    relatedIbProofDocuments, 
    existingProofDocuments, 
    sustainabilityClassMasterData,
) {
    const today = new Date();
    const formattedDate = today.toISOString().slice(2, 10).replace(/-/g, '.');

    /** Configuration of default proofpoint data */
    const defaultUrl = process.env.DEFAULT_HEART_PROOFPOINT_URL;
    const DEFAULT_PROOFPOINT = {
        URL: defaultUrl,
        TYPE: '14', // Carbon footprint Cradle-to-Gate
        FILENAME: 'HEART - Power BI',
        DESCRIPTION: 'AUTOMATED INPUT HEART',
    };


    const items = products.map(item => {
        const sItemId = cds.utils.uuid();

        // Map proof document data to format, both incoming and existing in related IBs
        const proofDocuments = [
            ...(
                relatedIbProofDocuments.find(document => document.material === item.material)?.productProofDocuments || []
            ).map(document => {
                    const {
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        active,
                        product,
                        proofPointId,
                    } = document;
                    return {
                        requestId: sItemId,
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        imageMasterID: proofPointId,
                        active: (active === null) ? true : active,
                        productReference: product,
                    };
                }),
            ...existingProofDocuments
                .filter(document => document.product === item.material)
                .map(document => {
                    const {
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        active,
                        proofPointId,
                    } = document;
                    return {
                        requestId: sItemId,
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        imageMasterID: proofPointId,
                        active: (active === null) ? true : active,
                    };                 
                }),
        ];

        // If no proofdocuments, add default one
        if (proofDocuments.length === 0) {
            
            proofDocuments.push({
                requestId: sItemId,
                type: DEFAULT_PROOFPOINT.TYPE,
                description: DEFAULT_PROOFPOINT.DESCRIPTION,
                fileName: DEFAULT_PROOFPOINT.FILENAME,
                url: DEFAULT_PROOFPOINT.URL,
                externalUrl: true,
                // imageMasterID: proofPointId,
                active: true,                
            })
            
        }
        
        const oNewStatusSustClass = getHeartAssessmentStatusAndClass(
            {
                heartSustClass: item.pcfHeartSustainabilityClass,
                rcPreFlag: item.rcPreFlag,
                existingSustClass: item.sustClass,
                contributor1: item.contributor1,
                contributor2: item.contributor2,
                contributor3: item.contributor3,
                proofDocuments: proofDocuments,
                updateType: item.updateType,
            },
            sustainabilityClassMasterData
        );

        const { 
            category1, 
            contributor1, 
            category2, 
            contributor2, 
            category3, 
            contributor3 
        } = buildCategoryContributorForAssessmentItem(item);

        // Final item to return
        const oItem = {
            ID: sItemId,
            virtualAssessment: false,
            status: oNewStatusSustClass?.status,
            product: item.material,
            productType: PRODUCT_TYPE.IDH,
            sbu: item.sbu,
            comment: `${TRIGGER_NAME}_${item.sbu}_${formattedDate} ${item.updateType}`,
            rcPreFlag: item.rcPreFlag,
            sustClass: oNewStatusSustClass?.sustClass,
            category1, 
            contributor1, 
            category2, 
            contributor2, 
            category3, 
            contributor3,
            propagation: true,
            externalCommunication: false,
            toProofDocuments: proofDocuments,
            toAdditionalData: {
                heart: {
                    new: {
                        rsnSbuCode: item.newRsnSbuCode,
                        productLineL3: item.newRsnSbuCode,
                        technologyL1: item.newTechnologyL1,
                        technologyL3: item.newTechnologyL3,
                        applicationL1: item.newApplicationL1,
                        applicationL2: item.newApplicationL2,
                        applicationL3: item.newApplicationL3,
                        productHierarchyL3: item.newProductHierarchyL3,
                        pcfClusterAttributes: item.newPcfClusterAttributes,
                        pcfClusterAttributesValues:
                            item.newPcfClusterAttributesValues,
                        pcfClusterSize: item.newPcfClusterSize,
                        pcfClusterBenchmark: item.newPcfClusterBenchmark,
                        pcfExcl: item.newPcfExcl,
                        pcfDeltaRel: item.newPcfDeltaRel,
                        pcfHeartSustainabilityClass:
                            item.pcfHeartSustainabilityClass,
                        pcfCategory: item.pcfCategory,
                        pcfContributor: item.pcfContributor,
                        // heartRunDate: item.heartRunDate,
                        heartRunId: item.heartRunId,
                    },
                    last: {
                        rsnSbuCode: item.oldRsnSbuCode,
                        productLineL3: item.oldProductLineL3,
                        technologyL1: item.oldTechnologyL1,
                        technologyL3: item.oldTechnologyL3,
                        applicationL1: item.oldApplicationL1,
                        applicationL2: item.oldApplicationL2,
                        applicationL3: item.oldApplicationL3,
                        productHierarchyL3: item.oldProductHierarchyL3,
                        pcfClusterAttributes: item.oldPcfClusterAttributes,
                        pcfClusterAttributesValues: item.oldPcfClusterAttributesValues,
                        pcfClusterSize: item.oldPcfClusterSize,
                        pcfClusterBenchmark: item.oldPcfClusterBenchmark,
                        pcfExcl: item.oldPcfExcl,
                        pcfDeltaRel: item.oldPcfDeltaRel,
                        pcfHeartSustainabilityClass: item.oldPcfSustClass,
                        // pcfCategory: item.pcfCategory,
                        // pcfContributor: item.pcfContributor,
                        // heartRunDate: item.heartRunDate,
                        heartRunId: item.heartRunId,
                        // pcfCategory                 : item.pcfCategory                  ,
                        // pcfContributor              : item.pcfContributor               ,
                        // heartRunDate                : item.heartRunDate					,
                        // heartRunId                  : item.heartRunId                   ,
                    },
                },
            },
        };

        return oItem;
    });

    return items;

};

/**
 * Calculates heart assessment status
 * 
 * @param {Object} param0 - HEART data
 * @returns {Object | boolean} Status of the assessed product, false when no valid data
 */
function getHeartAssessmentStatusAndClass (
    { 
        heartSustClass, 
        rcPreFlag, 
        existingSustClass, 
        contributor1, 
        contributor2, 
        contributor3, 
        proofDocuments, 
        updateType 
    }, 
    sustClassMasterdata
) {

    // // When update type is Delet, the assessment is created as saved
    // const UPDATE_TYPE_DELETED = 'Deleted';
    // if (updateType === UPDATE_TYPE_DELETED) return ASSESSMENT_STATUS.SAVED;

    // // If in downgrade case, assessment is created as SAVED per default
    // const heartLevel = sustClassMasterdata.find(item => item.code === heartSustClass)?.level;
    // const rcLevel = sustClassMasterdata.find(item => item.code === rcPreFlag)?.level;
    // const isDowngraded = heartLevel < rcLevel;
    // if (isDowngraded)   return ASSESSMENT_STATUS.SAVED;

    // // If RC preflag is matched with HEART class, create as submitted
    // const arePcfAndRcPreFlagMatched = heartSustClass === rcPreFlag;
    // if (arePcfAndRcPreFlagMatched) return ASSESSMENT_STATUS.SUBMITTED;

    // // If mismatched, check if there is a L3 exemption. If yes, it can be submitted
    // const hasL3Exemption = proofDocuments.some( document => {
    //     return document.type === EXEMPTION_L3_DOCUMENT && document.active;
    // });
    // if (hasL3Exemption) return ASSESSMENT_STATUS.SUBMITTED;

    // // Else, assessment is created as SAVED
    // return ASSESSMENT_STATUS.SAVED;
    const oNewStatusSustClass = rootNode(    { 
        heartSustClass, 
        rcPreFlag, 
        existingSustClass, 
        contributor1, 
        contributor2, 
        contributor3, 
        proofDocuments, 
        updateType,
        sustClassMasterdata 
    })
    return oNewStatusSustClass;

};

/**
 * Builds sustainability category and contributors for assessment item
 * @param {Object} param0 
 * @param {string} param0.category1 
 * @param {string} param0.contributor1
 * @param {string} param0.category2
 * @param {string} param0.contributor2
 * @param {string} param0.pcfCategory
 * @param {string} param0.pcfContributor 
 * @returns {Object} Category and contributors for new assessment item
 */
function buildCategoryContributorForAssessmentItem({
    category1,
    contributor1,
    category2,
    contributor2,     
    pcfCategory,
    pcfContributor,
}) {

    if (!contributor1) {

        return { 
            category1: pcfCategory, 
            contributor1: pcfContributor 
        };

    } else if ( !contributor2 ) {

        return { 
            category1, 
            contributor1, 
            category2: pcfCategory, 
            contributor2: pcfContributor,
        };

    }

    return { 
        category1, 
        contributor1,
        category2, 
        contributor2,              
        category3: pcfCategory, 
        contributor3: pcfContributor,
    };        

};

/**
 * Creates HEART assessment in database
 * 
 * @param {Object[]} assessmentsToCreate - Assessment data to INSERT
 */
async function createHeartAssessment(assessmentsToCreate) {

    const aFlattenedItems = assessmentsToCreate.flatMap(assessment => assessment.items);
    const aItems = aFlattenedItems.map(item => {
        const oItem = { ...item };
        delete oItem.toProofDocuments;
        return oItem;
    });
    const aProofDocuments = aFlattenedItems.flatMap(item => item.toProofDocuments);
    
    await cds.db.run( async tx => {
        await INSERT
            .into(ENTITIES.DB.MASS_ASSESSMENT_HEADER)
            .entries( assessmentsToCreate.map( assessment => assessment.header ) );

        const aItemsBatched = divideArrayInBatches(aItems, DEFAULT_DB_BATCH_SIZE);
        for (const batch of aItemsBatched){
            await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(batch);
        }
        
        if (aProofDocuments.length > 0) {
            const aDocumentsBatch = divideArrayInBatches(aProofDocuments, DEFAULT_DB_BATCH_SIZE);
            for (const batch of aDocumentsBatch){
                await INSERT.into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).entries(batch);
            }            
        }
    });

};

/**
 * Sets HEART assessment process as finished in logs
 * 
 * @param {Object[]} assessmentsCreated - Assessments created
 * @param {string} sbu - SBU of run
 * @param {string} status - Status of HEAR run
 * @param {string} heaertRunId - HEART run ID  
 */
async function setHeartLogsAsFinished(assessmentsCreated, sbu, status, heartRunId) {

    // Saving of assessment generated as SAVED
    const oAssessmentSaved = assessmentsCreated.find(
        assessment => assessment?.header?.status === ASSESSMENT_STATUS.SAVED
    );
    if (oAssessmentSaved && oAssessmentSaved.header) {
        await setHeartLogMaterialsStatus( 
            oAssessmentSaved.items,
            sbu,
            heartRunId,
            status,
            HEART_PRODUCT_STATUS.PROCESSED,
            oAssessmentSaved.header.ID,
            oAssessmentSaved.header.status,
        );
    }

    // Saving of assessment generated as SUBMITTED
    const oAssessmentSubmitted = assessmentsCreated.find(
        assessment => assessment?.header?.status === ASSESSMENT_STATUS.SUBMITTED
    );
    if (oAssessmentSubmitted && oAssessmentSubmitted.header) {
        await setHeartLogMaterialsStatus( 
            oAssessmentSubmitted.items,
            sbu,
            heartRunId,
            status,
            HEART_PRODUCT_STATUS.PROCESSED,
            oAssessmentSubmitted.header.ID,
            oAssessmentSubmitted.header.status,
        );
    }

    const oDiscardedAssessment = assessmentsCreated.find(
        assessment => !assessment?.header    
    );
    if (
        oDiscardedAssessment && 
        oDiscardedAssessment.items &&
        oDiscardedAssessment.items.length > 0
    ) {
        await setHeartLogMaterialsStatus( 
            oDiscardedAssessment.items,
            sbu,
            heartRunId,
            status,
            HEART_PRODUCT_STATUS.PROCESSED,
            null,
            null,
        );        
    }

};

/**
 * Set HEART material run as retrial
 * 
 */
async function setHeartLogsAsRetrial(materials, sbu, status, heartRunId) {
    await setHeartLogMaterialsStatus( 
        materials,
        sbu,
        heartRunId,
        status,
        HEART_PRODUCT_STATUS.RETRIAL,
        null,
        null,
    );
};

/**
 * Sets HEART run status fitlering by execution material
 * 
 * @param {string[]} materials - Materials to apply status
 * @param {string} sbu - SBU to apply status
 * @param {string} heartRunId - HEART run ID to apply status 
 * @param {string} oldStatus - Old status to apply status
 * @param {string} newStatus - New status to apply
 * @param {string} headerId - Header ID of assessment generated, only when successful
 */
async function setHeartLogMaterialsStatus(materials, sbu, heartRunId, oldStatus, newStatus, headerId, assessmentStatus) {
    
    const aBatchedItems = divideArrayInBatches(materials, DEFAULT_DB_BATCH_SIZE);
    for (const batch of aBatchedItems) {
        await cds.db.run(
            UPDATE(ENTITIES.DB.HEART_EXECUTION)
                .set({ 
                    status: newStatus,
                    assessmentId: headerId,
                    assessmentStatus,
                })
                .where({
                    sbu,
                    status: oldStatus,
                    heartRunId,
                    material: batch.map(item => item.product),
                })
        )
    }

};

/**
 * Checks for valid products for creating asssessment
 * 
 * @param {} products 
 * @returns 
 */
async function checkValidProducts(products) {

    const oValidation = {
        validProducts: [],
        invalidProducts: [],
    };
    
    const aProductsInAssessment = await checkProductsInAssessmentforPdpMocHeart(products);
    if (aProductsInAssessment && aProductsInAssessment.length > 0) {
        oValidation.invalidProducts.push(
            ...aProductsInAssessment
                .map( item => {
                    return {
                        product: item.product,
                        blockingAssessment: item,
                        reason: VALIDATION_REASON.PRODUCTS_BLOCKED,
                    }
                })
        );
    }

    oValidation.validProducts = products
        .filter( product => !oValidation.invalidProducts.some(item => item.product === product) );
    
    return oValidation;

};

/**
 * Returns mass assessment headers whose requestName starts with the given prefix.
 *
 * @param {string} requestName Request name prefix.
 * @returns  Matching headers or empty array.
 */
async function getMassAssessmentHeadersByRequestName(requestName) {
    const aMassHeaders = await SELECT
        .from(ENTITIES.DB.MASS_ASSESSMENT_HEADER)
        .columns('requestName')
        .where('requestName like', `${requestName}%`);

        return aMassHeaders || [];
    }

/**
 * Determines the next sequential number for the given status
 * based on existing request headers.
 *
 * @param {string} status Assessment status code (e.g. "01", "02").
 * @param {Array<{ requestName: string }>} aExistingHeaders Existing headers.
 * @returns {number} Next available number.
 */

function getNextNumberForStatus(status, aExistingHeaders) {

  
    const statusConfig = STATUS_FOR_ASSESSMENTS.find(
        s => s.status === status
    );

    const sameStatusHeaders = statusConfig
        ? aExistingHeaders.filter(h =>
            h.requestName.includes(statusConfig.nameSuffix)
        ) : [];

    let maxNumber = 0;
    for (const h of sameStatusHeaders) {

        const match = h.requestName.match(/-(\d+)$/);

        if (match) {

            const num = parseInt(match[1], 10);


            if (num > maxNumber) {
                maxNumber = num;
            }
        }
    }

    return maxNumber + 1;
}




module.exports = {
    getHeartProductData,
    buildHeartAssessment,
    createHeartAssessment,
    setHeartLogsAsFinished,
    setHeartLogsAsRetrial,
    checkValidProducts,
    VALIDATION_REASON,
};