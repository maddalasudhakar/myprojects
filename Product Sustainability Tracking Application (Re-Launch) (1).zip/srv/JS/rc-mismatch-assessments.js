const cds = require('@sap/cds');
const { ASSESSMENT_STATUS, ASSESSMENT_TYPE, ASSESSMENT_PROCESS, ENTITIES } = require('./assessment');
const { divideArrayInBatches } = require('../JS/batching-utils');


/** Possible product status for RC PrefLag Mismatch process */
const RC_PREFLAG_MISMATCH_PRODUCT_STATUS = {
    PENDING: '01',
    RETRIAL: '02',
    PROCESSED: '03',
};

/** Possible product status for RC PrefLag Mismatch process */
const RC_PREFLAG_MISMATCH_PRODUCT_TYPE = {
    IDH: 'IDH',
    IB: 'IB',
};

/** Possible sustainability classes for RC PreFlag Mismatch process */
const SUSTAINABILITY_CLASSES = {
    UNKNOWN: '01',
    CONTRIBUTOR: '04',
    PIONEER: '05',
    PERFORMER: '20',
};


const BATCH_SIZE = 1000;

/** Trigger name for RC PreFlag Mismatch process */
const TRIGGER_NAME = "RC Mismatch"


/** Item Explanation (Comment )RC PreFlag Mismatch process */
const EXPLANATION = "RC PreFlag Mismatch assessment generated automatically"

/**
 * Build assessment from Datasphere data
 * 
 * @param {Object[]} productsData - Array with the products for which the assessment will be created
 * @param {Object[]} relatedIbProofDocuments - List of IB's documents associated with IDHs
 * @param {Object[]} aExistingProofDocuments - List of product's documents

 * @returns {}
 */
async function buildRcPreFlagMismatchAssessment(oHeader, aItems) {

    // if (!productsData || productsData.length === 0) return;

    // Build basic data
    // const oHeader = buildRcPreFlagMismatchAssessmentHeader(productsData[0]);
    // const aItems = buildRcPreFlagMismatchAssessmentItems(productsData, relatedIbProofDocuments, aExistingProofDocuments, oHeader.ID);
    const oAssessment = {
        header: oHeader,
        items: aItems,
    };


    return oAssessment;
};

/**
 * Build RcPreFragMismatch initial mass assessment data to be filled
 * 
 * @param {Object} productData - Data of one of the products to include in assessment
 * @returns {Object} Built assessment header
 */
async function buildRcPreFlagMismatchAssessmentHeader(productData) {
    const today = new Date();

    const formattedDate = today
        .toLocaleDateString('es-ES', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
        })
        .replace(/\//g, '.');

    const requestName = await buildRcPreFlagMismatchAssessmentRequestName(`${TRIGGER_NAME}_${productData.sbu}_${formattedDate}`);

    const oHeader = {
        ID: cds.utils.uuid(),
        requestName: requestName,
        sbu: productData.sbu,
        productType: RC_PREFLAG_MISMATCH_PRODUCT_TYPE.IDH,
        assesmentType: ASSESSMENT_TYPE.MASS,
        status: ASSESSMENT_STATUS.SUBMITTED,
        processType: ASSESSMENT_PROCESS.RC_PREFLAG_MISMATCH,
        submitionDate: new Date().toISOString(),
        virtualAssessment: false
    };

    return oHeader;
};

/**
 * Build RcPreFlagMismatch initial mass assessment items data to be filled
 * 
 * @param {Object[]} products - Product data to use 
 * @param {Object[]} relatedIbProofDocuments - Related IB proof documents to add
 * @param {Object[]} existingProofDocuments - Related existing proof documents to add
 * @param {string} headerId - Generated header ID
 * @returns {Object[]} List of mass assessment items built
 */
function buildRcPreFlagMismatchAssessmentItems(products, relatedIbProofDocuments, existingProofDocuments, headerId) {

    const aItems = products.map(item => {

        const sItemId = cds.utils.uuid();

        // Map proof document data
        const aProofDocuments = [
            ...(
                relatedIbProofDocuments.find(
                    document => document.material === item.product,
                )?.productProofDocuments || []
            ).map(document => {
                const {
                    type,
                    description,
                    fileName,
                    url,
                    externalUrl,
                    active,
                } = document;
                return {
                    requestId: sItemId,
                    type,
                    description,
                    fileName,
                    url,
                    externalUrl,
                    active,
                    productReference: document.product,
                };
            }),
            ...existingProofDocuments
                .filter(document => document.product === item.product)
                .map(document => {
                    const {
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        active,
                    } = document;
                    return {
                        requestId: sItemId,
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        active,
                    };
                }),
        ];


        const { sSustClass, sCategory1, sContributor1 } = determineSustainabilityClass(item);

        // Final item to return
        const oItem = {
            ID: sItemId,
            headerId: headerId,
            virtualAssessment: false,
            status: ASSESSMENT_STATUS.SUBMITTED,
            product: item.product,
            productType: RC_PREFLAG_MISMATCH_PRODUCT_TYPE.IDH,
            sbu: item.sbu,
            comment: EXPLANATION,
            rcPreFlag: item.rcPreFlag,
            rcPreFlagDescription: item.rcPreFlagDescription,
            sustClass: sSustClass,
            category1: sCategory1,
            contributor1: sContributor1,
            propagation: true,
            externalCommunication: false,
            toProofDocuments: aProofDocuments,
        };

        return oItem;

    });

    return aItems;

};


/**
 * Create RC PreFlag Mismatch assessment in DB
 * 
 * @param {Object} param0 - Assessment data
 * @param {Object} param0.header - Assessment header data
 * @param {Object[]} param0.items - List of assessment items 
 */
async function createRcPreFlagMismatchAssessment({ header, items }) {
    const aProofDocuments = items.flatMap(item => item.toProofDocuments || []).filter(doc => doc !== undefined);
    const aItems = items.map(item => {
        const oItem = { ...item };
        delete oItem.toProofDocuments;
        return oItem;
    });

    const db = await cds.connect.to('db');
    await db.run(async tx => {

        await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_HEADER).entries([header]);

        const aBatchedItems = divideArrayInBatches(aItems, BATCH_SIZE);
        for (const batch of aBatchedItems) {
            await INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(batch);
        }


        if (aProofDocuments.length > 0) {
            const aBatchedDocuments = divideArrayInBatches(aProofDocuments, BATCH_SIZE);
            for (const batch of aBatchedDocuments) {

                await INSERT.into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).entries(batch);
            }

        }
    });

};

/**
 * Set RC Preflag Mismatch processed projects status as finished
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.message - message to set
 * @param {string[]} param0.products - List of the products to update
 */
async function setRcPreFlagMismatchProcessedProjectStatusToFinished({ message, products, createdassessmentid }) {

    await setRcPreFlagMismatchProcessedProjectStatus({
        products,
        status: RC_PREFLAG_MISMATCH_PRODUCT_STATUS.PROCESSED,
        message,
        createdassessmentid
    });

};

/**
 * Set RC Preflag Mismatch processed projects status
 * 
 * @param {Object} param0 - Updating parameters
 * @param {string} param0.message - message to set
 * @param {string[]} param0.products - List of the products to update
 * @param {string} param0.status - Status to set
 */
async function setRcPreFlagMismatchProcessedProjectStatus({ message, products, status, createdassessmentid }) {

    const aBatches = divideArrayInBatches(products, BATCH_SIZE);
    const db = await cds.connect.to('db');

    for (const batch of aBatches) {

        const existing = await db.run(
            SELECT.from(ENTITIES.DB.RC_PREFLAG_MISMATCHED_LOG)
                .columns('PRODUCT', 'STATUS', 'MESSAGE')
                .where({ PRODUCT: { in: batch } })
        );


        await db.run(
            UPDATE(ENTITIES.DB.RC_PREFLAG_MISMATCHED_LOG)
                .set({ STATUS: status, MESSAGE: message, CREATEDASSESSMENTID: createdassessmentid })
                .where({ PRODUCT: { in: batch } })
        );

    }

};

/**
 * Determines the new sustainability class based on the RC-PreFlag value and the current class.
 * 
 * @param {Object} item 
 * @returns 
 */
function determineSustainabilityClass(item) {

    let sSustClass = item.sustClass;
    let sCategory1 = item.category1;
    let sContributor1 = item.contributor1;

    const rcFlag = item.rcPreFlag;

    switch (rcFlag) {
        case SUSTAINABILITY_CLASSES.PIONEER:
            if ([SUSTAINABILITY_CLASSES.PIONEER, SUSTAINABILITY_CLASSES.CONTRIBUTOR].includes(item.sustClass)) {

                sSustClass = item.sustClass;
                sCategory1 = item.category1;
                sContributor1 = item.contributor1;

            } else {

                sSustClass = SUSTAINABILITY_CLASSES.PERFORMER;
                sCategory1 = null;
                sContributor1 = null;
            }
            break;

        case SUSTAINABILITY_CLASSES.CONTRIBUTOR:
            if (item.sustClass === SUSTAINABILITY_CLASSES.CONTRIBUTOR) {
                sSustClass = item.sustClass;
                sCategory1 = item.category1;
                sContributor1 = item.contributor1;
            } else {
                sSustClass = SUSTAINABILITY_CLASSES.PERFORMER;
                sCategory1 = null;
                sContributor1 = null;
            }
            break;

        default:
            sSustClass =  item.rcPreFlag;
            break;
    }

    return { sSustClass, sCategory1, sContributor1 };
}

/**
 * Builds a sequential request name for RC Pre-Flag mismatch assessments
 * based on existing records with the same prefix.
 *
 * @param {string} requestName Request name prefix.
 * @returns  Generated request name with incremental suffix.
 */
async function buildRcPreFlagMismatchAssessmentRequestName(requestName){
    const { total } = await SELECT.one.from(ENTITIES.DB.MASS_ASSESSMENT_HEADER).columns('count(*) as total').where('requestName like', `${requestName}%`);

  return `${requestName}-${total + 1}`;
}

module.exports = {
    buildRcPreFlagMismatchAssessment,
    createRcPreFlagMismatchAssessment,
    setRcPreFlagMismatchProcessedProjectStatusToFinished,
    BATCH_SIZE,
    buildRcPreFlagMismatchAssessmentHeader,
    buildRcPreFlagMismatchAssessmentItems,
}