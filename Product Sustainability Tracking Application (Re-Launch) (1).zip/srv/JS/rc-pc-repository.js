const batchingUtils = require('./batching-utils');



function makeRcPcRepository({
    db = cds.db, 
    divideArrayInBatches = batchingUtils.divideArrayInBatches,
} = {}) {

    /** Entities used */
    const ENTITIES = {
        DB: {
            RC_PC_EXECUTION: 'com.sustainability.background.RcPositiveContributionExecution',
            RC_PC_EXECUTION_AND_ASSESSMENT:
                'com.sustainability.background.RcPcExecutionAndLastAssessment',
            MASS_ASSESSMENT_HEADER: 'com.sustainability.management.MassAssessmentHeader',
            MASS_ASSESSMENT_ITEMS: 'com.sustainability.management.MassAssessmentItems',
            ASSESSMENT_PROOF_DOCUMENT: 'com.sustainability.management.AssessmentProofDocument',
        },
    };

    const DEFAULT_DB_BATCH_SIZE = 1000;

    async function getProductData(sbu, products, status, runId) {
        if (!sbu || !Array.isArray(products) || products.length === 0) {
            throw new Error('Invalid parameters');
        }

        const aProducts = [];
        const aBatches = divideArrayInBatches(products, DEFAULT_DB_BATCH_SIZE);

        for (const batch of aBatches) {
            const aProductsBatch = await db.run(
                SELECT.from(ENTITIES.DB.RC_PC_EXECUTION_AND_ASSESSMENT).where({
                    material: batch,
                    runId,
                    sbu,
                    status,
                }),
            );
            aProducts.push(...aProductsBatch);
        }

        return aProducts;
    }


    async function updateMaterialLogStatus(
        materials,
        runId,
        oldStatus,
        newStatus,
        headerId,
        assessmentStatus,
    ) {
        const aBatchedItems = divideArrayInBatches(materials, DEFAULT_DB_BATCH_SIZE);
        for (const batch of aBatchedItems) {
            await db.run(
                UPDATE(ENTITIES.DB.RC_PC_EXECUTION)
                    .set({status: newStatus, assessmentId: headerId, assessmentStatus})
                    .where({status: oldStatus, runId, material: batch.map((i) => i.product)}),
            );
        }
    }

    async function getRequestNamesByPattern(pattern) {
        return await db.run(
            SELECT.from(ENTITIES.DB.MASS_ASSESSMENT_HEADER)
                .columns('requestName')
                .where('requestName like', `${pattern}%`)
                .limit(10000),
        );
    }

    return {
        getProductData,
        updateMaterialLogStatus,
        getRequestNamesByPattern,
    };
}

module.exports = {makeRcPcRepository};
