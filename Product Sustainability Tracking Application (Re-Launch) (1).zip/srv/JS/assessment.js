const cds = require('@sap/cds');
const { divideArrayInBatches } = require('./batching-utils');

/** Availabl sustianbility classess */
const SUSTAINABILITY_CLASS = {
    UNKNOWN: '01',
    PERFORMER_T2B: '02',
    PERFORMER: '20',
    TRANSITIONER_T1: '03',
    TRANSITIONER_T2A: '30',
    CONTRIBUTOR: '04',
    PIONEER: '05',
};

/** Assessment types as currently */
const ASSESSMENT_TYPE = {
    MASS: 'M',
    SINGLE: 'S',
};

/** Possible status of an assessment */
const ASSESSMENT_STATUS = {
    SAVED: '01',
    DRAFT: '91',
    SUBMITTED: '02',
    UNDER_RESUBMISSION: '03',
    RESUBMITTED: '04',
    APPROVED: '05',
    REJECTED: '06',
    UNDER_REVIEW: '07',
    FINALIZED: '08',
};

/** Available assessment on premise communication status */
const COMMUNICATION_STATUS = {
    PENDING: '01',
    PENDING_CPI_RETRY: "11",
    SENDED_CPI: '02',
    FEEDBACK_RECEIVED: '03',
    RETRYING: '04',
    COMPLETED: '05',
};

/** Available process types for assessment */
const ASSESSMENT_PROCESS = {
    PDP: 'PDP',
    MOC: 'MOC',
    HEART: 'HRT',
    RC_PREFLAG_MISMATCH: 'RCM',
    RC_POSITIVE_CONTRIBUTION: 'RCPC',
    MANUAL: '',
};

/** Available product types for an assessment */
const PRODUCT_TYPE = {
    IB: 'IB',
    IDH: 'IDH',
};

/** Used entitites and tables */
const ENTITIES = {
    DB: {
        IB_IDH: 'COM_SUSTAINABILITY_VT_V_IB_IDH',
        PRODUCT_PROOF_DOCUMENT_RELATION: 'com.sustainability.management.ProductProofDocumentRelation',
        MASS_ASSESSMENT_HEADER: 'com.sustainability.management.MassAssessmentHeader',
        SUSTAINABILITY_CLASS: 'com.sustainability.management.SustainabilityClass',
        MASS_ASSESSMENT_ITEMS: 'com.sustainability.management.MassAssessmentItems',
        ASSESSMENT_PROOF_DOCUMENT: 'com.sustainability.management.AssessmentProofDocument',
        RC_PREFLAG_MISMATCHED_LOG: "com.sustainability.background.rcpreflagsustclassmismatchedassessmentlog",
        ASSESSMENT_ADDITIONAL_DATA: "com.sustainability.management.AssessmentAdditionalData",
        HEART_ADDITIONAL_DATA: "com.sustainability.management.HeartAdditionalData",
        PDP_ADDITIONAL_DATA: "com.sustainability.management.PdpAdditionalData",
        MOC_ADDITIONAL_DATA: "com.sustainability.management.MocAdditionalData",
        IDH_UPDATED: "com.sustainability.idhupdated",
    }
};

/** Maps process types to their corresponding table */
const MAPPING_PROCESS_TO_ADDITIONAL_DATA_TABLE = [
    { processType: ASSESSMENT_PROCESS.HEART, entity: ENTITIES.DB.HEART_ADDITIONAL_DATA, idField: 'heart_ID' },
    { processType: ASSESSMENT_PROCESS.PDP, entity: ENTITIES.DB.PDP_ADDITIONAL_DATA, idField: 'pdp_ID' },
    { processType: ASSESSMENT_PROCESS.MOC, entity: ENTITIES.DB.MOC_ADDITIONAL_DATA, idField: 'moc_ID' },
];

/** Default database query batch size */
const DEFAULT_DB_BATCH_SIZE = 1000;

/**
 * Get mass assessment header data from its ID
 * @param {string} id - ID of the mass assessment header
 * @returns {Promise<Object>} Mass assessment header data 
 */
async function getMassAssessmentHeaderById (id) {

    return await cds.db.run(
        SELECT.one
            .from(ENTITIES.DB.MASS_ASSESSMENT_HEADER)
            .where({ID: id})
    );

};

/**
 * Get mass assessment item data from its ID
 * @param {string} id - ID of the mass assessment item
 * @returns {Promise<Object>} Mass assessment item data 
 */
async function getMassAssessmentItemById (id, columns = []) {

    const fnQuery = SELECT.one
        .from(ENTITIES.DB.MASS_ASSESSMENT_ITEMS)
        .where({ID: id})

    if (columns) {
        return await cds.db.run(
            fnQuery.columns(columns)
        )
    }

    return await cds.db.run(
        fnQuery
    );

};

/**
 * Recover related proof documents for a set of products
 * 
 * @async
 * @param {String[]} materials - Set of IDH materials to get the related IB documents from
 * @returns {Promise<Object[]>} List of documents and their data
 */
async function getRelatedIbProofDocuments(materials) {

    // Retrieval of related documents
    const aIbsToIdhs = await getIbsRelatedToIdhs(materials);
    if (!Array.isArray(aIbsToIdhs) || aIbsToIdhs.length === 0) {
            return [];
        }
    
    const aProductProofDocuments = await getProductProofDocuments(aIbsToIdhs.map(item => item.AI_PRODUCT_KEY));

    if (!Array.isArray(aProductProofDocuments) || aProductProofDocuments.length === 0) {
        return [];
    }

    const aRelatedIbProofDocuments = materials.map(material => {

        const aProducts = aIbsToIdhs
            .filter(item => item.MATERIAL_KEY === material)
            .map(item => item.AI_PRODUCT_KEY);

        const aProductProofDocumentsFiltered = aProductProofDocuments
            .filter(document => aProducts.includes(document.product));

        return {
            material: material,
            productProofDocuments: aProductProofDocumentsFiltered,
        };

    });

    return aRelatedIbProofDocuments;

};

/**
 * Recover related IB products for a set of IDH materials
 * 
 * @async
 * @param {String[]} materials - List of IDH material IDs
 * @returns {Promise<Object[]>} List of related IB product IDs
 */
async function getIbsRelatedToIdhs(materials) {

    const aMaterialBatches = divideArrayInBatches(materials, DEFAULT_DB_BATCH_SIZE);
    const aProducts = [];
    for (const materialBatch of aMaterialBatches) {

        aProductsBatch = await cds.run(
            SELECT
                .from(ENTITIES.DB.IB_IDH)
                .columns('MATERIAL_KEY', 'AI_PRODUCT_KEY')
                .where({ MATERIAL_KEY: materialBatch })
        );
        aProducts.push(...aProductsBatch);

    }

    return aProducts;

};

/**
 * Gets proof documents for a given product
 * 
 * @async
 * @param {String[]} products - List of products ID to recover products
 * @returns {Promise<Object[]>} List of products recovered 
 */
async function getProductProofDocuments(products) {

    const aBatches = divideArrayInBatches(products, DEFAULT_DB_BATCH_SIZE);
    const aProofDocuments = [];
    for (const batch of aBatches) {

        const aProofDocumentsBatch = await cds.run(
            SELECT
                .from(ENTITIES.DB.PRODUCT_PROOF_DOCUMENT_RELATION)
                .where({ product: batch })
        );
        aProofDocuments.push(...aProofDocumentsBatch);

    }

    return aProofDocuments;

};

/**
 * Gets sustainability class hierarchy master data
 * 
 * @async
 * @returns {Promise<Object[]>} Sustainability class hierarchy data
 */
async function getSustainabilityClassMasterData ()  {

    return await cds.db.run(
        SELECT
            .from(ENTITIES.DB.SUSTAINABILITY_CLASS)
    )

};

/**
 * Returns additional data for a given mass asssessment item additional data
 * @async
 * @param {Object} param0 - Additional data filters 
 * @param {string} param0.ID - ID of additional data 
 * @param {string} param0.processType - Process type of additional data 
 * @returns {Promise<Object>} Resulting additional data
 */
async function getMassAssessmentItemAdditionalDataByProcess({ID, processType}) {

    const oAdditionalData = await getMassAssessmentItemAdditionalDataById(ID);
    const oMapping = MAPPING_PROCESS_TO_ADDITIONAL_DATA_TABLE
        .find(mapping => mapping.processType === processType);
    
    if (!oMapping || !oMapping.entity) { 
        throw new Error(`Non supported process type for additional data`);
    }   
    
    return await cds.db.run(
        SELECT.one
            .from(oMapping.entity)
            .where({
                ID: oAdditionalData[oMapping.idField]
            })
    )
};

/**
 * Retrieves mass assessment item additional data
 * @async
 * @param {string} ID - Associated Mass assessment item data ID
 * @returns {Promise<Object>} Resulting additional data entry
 */
async function getMassAssessmentItemAdditionalDataById(ID) {
    return await cds.db.run(
        SELECT.one
            .from(ENTITIES.DB.ASSESSMENT_ADDITIONAL_DATA)
            .where({ID})
    )
};

/**
 * Inserts mass assessment header
 * @async
 * @param {Object[]} headers - Mass assessment headers to insert
 * @returns {Promise<Object>} Result
 */
async function createAssessmentHeaders(headers) {
    return await cds.db.run(INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_HEADER).entries(headers));
};

/**
 * Inserts mass assessment items
 * @async
 * @param {Object[]} headers - Mass assessment items to insert
 */
async function createAssessmentItems(items) {
    const aBatches = divideArrayInBatches(items, DEFAULT_DB_BATCH_SIZE);
    for (const batch of aBatches) {
        await cds.db.run(INSERT.into(ENTITIES.DB.MASS_ASSESSMENT_ITEMS).entries(batch));
    }
};

/**
 * Inserts assessment proof documents
 * @async
 * @param {Object[]} documents - Documents to insert
 */
async function createProofDocuments(documents) {
    if (documents.length === 0) return;
    const aBatches = divideArrayInBatches(documents, DEFAULT_DB_BATCH_SIZE);
    for (const batch of aBatches) {
        await cds.db.run(INSERT.into(ENTITIES.DB.ASSESSMENT_PROOF_DOCUMENT).entries(batch));
    }
};


module.exports = {
    ASSESSMENT_TYPE,
    ASSESSMENT_STATUS,
    COMMUNICATION_STATUS,
    PRODUCT_TYPE,
    ASSESSMENT_PROCESS,
    SUSTAINABILITY_CLASS,
    getRelatedIbProofDocuments,
    getIbsRelatedToIdhs,
    getProductProofDocuments,
    ENTITIES,
    getMassAssessmentHeaderById,
    getSustainabilityClassMasterData,
    getMassAssessmentItemById,
    getMassAssessmentItemAdditionalDataByProcess,
    createAssessmentHeaders,
    createAssessmentItems,
    createProofDocuments,
};