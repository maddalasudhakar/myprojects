const cds = require("@sap/cds");

const METHODS = {
    POST: "POST",
    GET: "GET",
    PATCH: "PATCH",
    DELETE: "DELETE",
};

function createMockRequest (method, data, user, headers, entity) {
    const oRequest = new cds.Request({
        method: method, // HTTP method 'PATCH'
        data: data, // Payload data
        user: user, // User information
        headers: headers, // HTTP headers
        entity: entity, //"SustainabilityManagement.MassAssessmentItems"
    });
    return oRequest;
};

function createMockPatchRequest (data, user, headers, entity) {
    const oRequest = createMockRequest(METHODS.PATCH, data, user, headers, entity);
    return oRequest;
};

module.exports = {
    createMockRequest,
    createMockPatchRequest,
}