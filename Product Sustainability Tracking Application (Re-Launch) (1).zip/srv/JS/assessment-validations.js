const cds = require("@sap/cds");
const { 
    getRules,
    checkRules, 
    checkSustClass, 
    checkTypeProofFieldsComplete, 
    checkContributors 
} = require("./rules-model/rules-model");
const { createMockPatchRequest } = require("./request-utils");
const { checkPermissionAndStatus } = require("./functions");

const ENTITIES = {
    SERVICE: {
        MASS_ASSESSMENT_HEADER: "SustainabilityManagement.MassAssessmentHeader",
        MASS_ASSESSMENT_ITEMS: "SustainabilityManagement.MassAssessmentItems",
    }
}

const STATUS = {
    SAVED: "01",
    SUBMITTED: "02",
    RESUBMITTED: "04",
    DRAFT: "91",
}

const MAX_IDS_PER_QUERY = 1000;

/**
 * Logic of validations before saving mass assessment 
 * 
 * @param {*} req 
 * @returns 
 */
async function beforeSaveMass(req) {

    const ALLOWED_STATUS = [
        STATUS.SAVED,
    ];

    if (!req.data.header || !req.data.items) {
        req.error(409, "Missing required parameters");
        return
    }    

    if (req.data.header.virtualAssessment) {
        req.error(409, "Method not allowed for virtual assessments. Please remove the assessment.");
        return        
    }

    // Check only status submitted is provided
    const bHeaderStatusIsAllowed = ALLOWED_STATUS.some(item => {
        return (item === req.data.header?.status || item === req.data.header?.approbalStatus);
    });
    const bNotAllItemsSaved = req.data.items.some(item => {
        return item.approbalStatus !== STATUS.SAVED &&  item.status !== STATUS.SAVED;
    });    

    if (!bHeaderStatusIsAllowed || bNotAllItemsSaved) {
        req.error(409, "Only saved status status is allowed for header and items");
        return;
    }

    const db = await cds.connect.to("db");
    const oMassAssessmentItems = db.entities["management.MassAssessmentItems"];    
    let aItemsQuery = [];
    let aItemsDB = [];
    for (const oItem of req.data.items) {
        aItemsQuery.push(oItem.ID);
        if (aItemsQuery.length === MAX_IDS_PER_QUERY) {
            const aItemsToAdd = await SELECT.from(oMassAssessmentItems).where({ ID: aItemsQuery });  
            aItemsDB.push(...aItemsToAdd);
            aItemsQuery = [];
        }
    }
    if (aItemsQuery.length > 0) {
        const aItemsToAdd = await SELECT.from(oMassAssessmentItems).where({ ID: aItemsQuery });  
        aItemsDB.push(...aItemsToAdd);
    }

    const bIsVirtualAssessment = aItemsDB.some(item => item.virtualAssessment);
    if (bIsVirtualAssessment) {
        req.error(409, "Method not allowed for virtual assessments. Please remove the assessment.");
        return;        
    }

    const ProductProofDocumentRelation = db.entities["management.ProductProofDocumentRelation"];    
    let aProductQuery = [];
    let aProductProofDocuments = [];
    for (const oItem of req.data.items) {
        aProductQuery.push(oItem.ID);
        if (aProductQuery.length === MAX_IDS_PER_QUERY) {
            const aProductsToAdd = await SELECT.from(ProductProofDocumentRelation).where({ product: aProductQuery });  
            aProductProofDocuments.push(...aProductsToAdd);
            aProductQuery = [];
        }
    }
    if (aProductQuery.length > 0) {
        const aProductsToAdd = await SELECT.from(ProductProofDocumentRelation).where({ product: aProductQuery });  
        aProductProofDocuments.push(...aProductsToAdd);
    }

    const aPromises = [beforeSaveHeaderValidations(req)];
    for (const oItem of req.data.items) {
        const oItemDB =  aItemsDB.find(item => item.ID === oItem.ID);
        const aProductProofDocumentsItem = aProductProofDocuments.filter(item => item.product === oItem.product)
        aPromises.push( beforeSaveItemValidations(req, oItem, oItemDB, aProductProofDocumentsItem) );
    }

    const aSettledRequests = await Promise.allSettled(aPromises);

    req.data.items = [];
    for (const oRequest of aSettledRequests) {
        if (oRequest.status === "rejected") {
            req.error(oRequest.reason);
        } else {
            if (oRequest.value.entity === ENTITIES.SERVICE.MASS_ASSESSMENT_HEADER) {
                req.data.header = oRequest.value.data;
            } else {
                req.data.items.push( oRequest.value.data );
            }
        }
    }

};

/**
 * Logic of validations before saving mass assessment header 
 * 
 * @param {*} req 
 * @returns 
 */
async function beforeSaveHeaderValidations(req) {
    // Process header validations
    const oHeader = req.data.header;
    const oHeaderRequest = createMockPatchRequest(oHeader, req.user, req.headers, ENTITIES.SERVICE.MASS_ASSESSMENT_HEADER );

    const bPermissionAndStatusValid = await checkPermissionAndStatus( oHeaderRequest );
    if (!bPermissionAndStatusValid) {
        return oHeaderRequest;
    }

    oHeaderRequest.data.assessor = req.user.id;

    return oHeaderRequest;
};  

/**
 * Logic of validations before saving mass assessment items
 * 
 * @param {*} req 
 * @returns 
 */
async function beforeSaveItemValidations(req, oItem, oItemDB, aProductProofDocumentsItem) {

    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const aOldItems = oItemDB || await SELECT.from(oMassAssessmentItems).where({ ID: oItem.ID });    
    const oOldItem = aOldItems[0];

    const oRequest = createMockPatchRequest(oItem, req.user, req.headers, ENTITIES.SERVICE.MASS_ASSESSMENT_ITEMS );
    
    oRequest.data.status = oRequest.data.approbalStatus;
    oRequest.data.itemDB = oItemDB;
    oRequest.data.productProofDocumentsDB = aProductProofDocumentsItem;
    if (oItemDB?.status === STATUS.DRAFT && oRequest.data.approbalStatus === STATUS.SAVED) {
        oRequest.data.status = oRequest.data.approbalStatus;
    }

    // oRequest.data.toProofDocumentsDB = aProofDocuments;    
    if (oRequest.data.status === STATUS.SUBMITTED) {
        oRequest.data.submitter = oRequest.user.id;        
        if (!oOldItem || !oOldItem.assessor || oOldItem.assessor === "") {
            oRequest.data.assessor = oRequest.user.id;
        }
    }
    else if (oRequest.data.status === STATUS.SAVED) {
        oRequest.data.submitter = oRequest.user.id;        
    }

    if (!(await checkPermissionAndStatus(oRequest))) {
        return oRequest;
    }    
    
    return oRequest;
};

/**
 * Handles validations before submitting
 *  
 * @param {Object} req request object
 * @returns 
 */
async function beforeSubmitMass(req) {

    const ALLOWED_STATUS = [
        STATUS.SUBMITTED,
        STATUS.RESUBMITTED,
    ];

    if (!req.data.header || !req.data.items) {
        req.error(409, "Missing required parameters");
        return
    }    
    
    if (req.data.header?.virtualAssessment) {
        req.error(409, "Method not allowed for virtual assessments. Please remove the assessment.");
        return;        
    }

    // Check only status submitted is provided
    const bHeaderStatusIsAllowed = ALLOWED_STATUS.some(item => {
        return (item === req.data.header?.status || item === req.data.header?.approbalStatus);
    });
    const bNotAllItemsSubmitted = req.data.items.some(item => {
        return item.approbalStatus !== STATUS.SUBMITTED &&  item.status !== STATUS.SUBMITTED;
    });
    const bNotAllItemsResubmitted = req.data.items.some(item => {
        return item.approbalStatus !== STATUS.RESUBMITTED &&  item.status !== STATUS.RESUBMITTED;
    });
    if (!bHeaderStatusIsAllowed || (bNotAllItemsSubmitted && bNotAllItemsResubmitted) ) {
        req.error(409, "Only submitted or resubmitted status is allowed for header and items");
        return;
    }

    // Retrieve data from database to complete missing data
    const aAssessments = await getMassAssessmentDataBeforeSubmit(req);   

    // Check eash assessment item according to rules model
    const oRules = await getRules();
    const oMasterData = await getAssessmentFieldMasterData();
    for (const oAssessement of aAssessments) {
        const oCheckRule = await checkRules(oAssessement, oRules, oMasterData.contributor);
        if (!oCheckRule.continue) {
            req.error(409, `Product ${oAssessement.product}: ${oCheckRule.reason}`);
        } else {
            const oCheckValues = await checkAssessmentFieldValues(oAssessement, oMasterData);
            if (!oCheckValues.valid) {
                req.error(409, `Product ${oAssessement.product}: ${oCheckValues.reason}`);
            }            
        }         
    }
    if (req?.errors && req.errors.length > 0) return;

    const db = await cds.connect.to("db");
    const oMassAssessmentItems = db.entities["management.MassAssessmentItems"];    
    let aItemsQuery = [];
    let aItemsDB = [];
    for (const oItem of req.data.items) {
        aItemsQuery.push(oItem.ID);
        if (aItemsQuery.length === MAX_IDS_PER_QUERY) {
            const aItemsToAdd = await SELECT.from(oMassAssessmentItems).where({ ID: aItemsQuery });  
            aItemsDB.push(...aItemsToAdd);
            aItemsQuery = [];
        }
    }
    if (aItemsQuery.length > 0) {
        const aItemsToAdd = await SELECT.from(oMassAssessmentItems).where({ ID: aItemsQuery });  
        aItemsDB.push(...aItemsToAdd);
    }

    const bIsVirtualAssessment = aItemsDB.some(item => item.virtualAssessment);
    if (bIsVirtualAssessment) {
        req.error(409, "Method not allowed for virtual assessments. Please remove the assessment.");
        return;        
    }

    const ProductProofDocumentRelation = db.entities["management.ProductProofDocumentRelation"];    
    let aProductQuery = [];
    let aProductProofDocuments = [];
    for (const oItem of req.data.items) {
        aProductQuery.push(oItem.ID);
        if (aProductQuery.length === MAX_IDS_PER_QUERY) {
            const aProductsToAdd = await SELECT.from(ProductProofDocumentRelation).where({ product: aProductQuery });  
            aProductProofDocuments.push(...aProductsToAdd);
            aProductQuery = [];
        }
    }
    if (aProductQuery.length > 0) {
        const aProductsToAdd = await SELECT.from(ProductProofDocumentRelation).where({ product: aProductQuery });  
        aProductProofDocuments.push(...aProductsToAdd);
    }

    const aPromises = [beforeSubmitHeaderValidations(req)];
    for (const oItem of req.data.items) {
        const oItemDB =  aItemsDB.find(item => item.ID === oItem.ID);
        // const aProofDocuments = aAssessments.filter(item => item.ID === oItem.ID)
        const aProductProofDocumentsItem = aProductProofDocuments.filter(item => item.product === oItem.product)
        aPromises.push( beforeSubmitItemValidations(req, oItem, oItemDB, aProductProofDocumentsItem) );
    }

    const aSettledRequestsPromises = await Promise.allSettled(aPromises);

    req.data.items = [];
    for (const oSettledPromise of aSettledRequestsPromises) {
        if (oSettledPromise.status === "rejected") {
            req.error(oSettledPromise.reason);
        } else {
            const oRequest = oSettledPromise.value;
            if (oRequest?.errors && oRequest.errors.length > 0) {
                for (const error of oRequest.errors) req.error(error);
            } else {
                if (oRequest.entity === ENTITIES.SERVICE.MASS_ASSESSMENT_HEADER) {
                    req.data.header = oRequest.data;
                } else {
                    req.data.items.push( oRequest.data );
                }
            }
        }
    }

};

/**
 * Retrieve needed assessment data 
 * 
 * @param {Object} req Request object 
 * @returns 
 */
async function getMassAssessmentDataBeforeSubmit(req) {
    const db = await cds.connect.to("db");

    const aItemIds = req.data.items.map(item => item.ID);

    // Get related proofpoints
    const AssessmentProofDocument = db.entities["management.AssessmentProofDocument"];
    // const aProofdocuments = await db.run(SELECT.from(AssessmentProofDocument).where({requestID: aItemIds}));
  
    let aItemsQuery = [];
    let aProofdocuments = [];
    for (const oItem of req.data.items) {
        aItemsQuery.push(oItem.ID);
        if (aItemsQuery.length === MAX_IDS_PER_QUERY) {
            const aItemsToAdd = await SELECT.from(AssessmentProofDocument).where({ requestID: aItemsQuery });  
            aProofdocuments.push(...aItemsToAdd);
            aItemsQuery = [];
        }
    }
    if (aItemsQuery.length > 0) {
        const aItemsToAdd = await SELECT.from(AssessmentProofDocument).where({ requestID: aItemsQuery });  
        aProofdocuments.push(...aItemsToAdd);
    }    
    
    const { requestName } = req.data.header;
    const oReturn = req.data.items.map(item => {
        const aProofDocumentsItem = aProofdocuments?.filter(document => document.requestId === item.ID) || [];
        return {
            ID: item.ID,
            product: item.product,
            sbu: item.sbu,
            rcPreFlag: item.rcPreFlag,
            requestName: requestName,
            sustClass: item.sustClass,
            comment: item.comment, 
            category1: item.category1,
            category2: item.category2,
            category3: item.category3,            
            contributor1: item.contributor1,
            contributor2: item.contributor2,
            contributor3: item.contributor3,
            approbalStatus: item.approbalStatus,            
            toProofDocuments: aProofDocumentsItem,
        };
    });

    return oReturn;
};

/**
 * Header validations for beforeSubmit
 * 
 * @param {*} req 
 * @returns request object with the results
 */
async function beforeSubmitHeaderValidations(req) {

    // Process header validations
    const oHeader = req.data.header;
    const oHeaderRequest = createMockPatchRequest(oHeader, req.user, req.headers, ENTITIES.SERVICE.MASS_ASSESSMENT_HEADER );

    const bPermissionAndStatusValid = await checkPermissionAndStatus( oHeaderRequest );
    if (!bPermissionAndStatusValid) {
        return oHeaderRequest;
    }

    oHeaderRequest.data.submitter = oHeaderRequest.user.id;
    oHeaderRequest.data.submitionDate = new Date().toISOString().slice(0, 10);

    return oHeaderRequest;

};

/**
 * Item validations for beforeSubmit
 * 
 * @param {*} req 
 * @param {*} oItem 
 * @returns request object with the results
 */
async function beforeSubmitItemValidations(req, oItem, oItemDB, aProductProofDocumentsItem) {

    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const aOldItems = oItemDB || await SELECT.from(oMassAssessmentItems).where({ ID: oItem.ID });    
    const oOldItem = aOldItems[0];

    const oRequest = createMockPatchRequest(oItem, req.user, req.headers, ENTITIES.SERVICE.MASS_ASSESSMENT_ITEMS );
    
    oRequest.data.status = oRequest.data.approbalStatus;
    oRequest.data.itemDB = oItemDB;
    oRequest.data.productProofDocumentsDB = aProductProofDocumentsItem;
    // oRequest.data.toProofDocumentsDB = aProofDocuments;    
    if (oRequest.data.status === STATUS.SUBMITTED) {
        oRequest.data.submitter = oRequest.user.id;        
        if (!oOldItem || !oOldItem.assessor || oOldItem.assessor === "") {
            oRequest.data.assessor = oRequest.user.id;
        }
    }

    if (!(await checkPermissionAndStatus(oRequest))) {
        return oRequest;
    }    

    return oRequest;

};

/**
 * Get master data from parametrized fields from DB
 * 
 * @returns 
 */
async function getAssessmentFieldMasterData() {
    const db = await cds.connect.to("db");
    const Sbu = db.entities["management.Sbu"];
    const SustainabilityClass = db.entities["management.SustainabilityClass"];
    const RcPreFlag = db.entities["management.RcPreFlag"];
    const SustainabilityCategory = db.entities["management.SustainabilityCategory"];
    const Contributor = db.entities["management.Contributor"];
    // const { Sbu, SustainabilityClass, rcPreFlag, SustainabilityCategory, Contributor} = db.entities;
    const oData = await db.run(async tx => {
        const aSbu = await SELECT.from(Sbu);
        const aSustainabilityClass = await SELECT.from(SustainabilityClass);
        const aRcPreFlag = await SELECT.from(RcPreFlag);
        const aSustainabilityCategory = await SELECT.from(SustainabilityCategory);
        const aContributor = await SELECT.from(Contributor);
        return {
            sbu: aSbu,
            sustainabilityClass: aSustainabilityClass,
            rcPreFlag: aRcPreFlag,
            sustainabilityCategory: aSustainabilityCategory,
            contributor: aContributor,
        };
    });
    return oData;
}

/**
 * Check that provided assessment field values are as parametrised
 * 
 * @param {*} oAssessement 
 * @returns 
 */
async function checkAssessmentFieldValues(oAssessement, oMasterData){
    const masterData = oMasterData || await getAssessmentFieldMasterData();

    const bSbuExists = masterData.sbu.some(item => item.sbu === oAssessement?.sbu);
    if (!bSbuExists) return {valid: false, reason: `SBU ${oAssessement?.sbu} does not exist`};

    const bSustainabilityClass = masterData.sustainabilityClass.some(item => item.code === oAssessement?.sustClass);
    if (!bSustainabilityClass) return {valid: false, reason: `Sustainability class ${oAssessement?.sustClass} does not exist`};

    const bRcPreFlag = masterData.rcPreFlag.some(item => item.code === oAssessement?.rcPreFlag);
    if (!bRcPreFlag) return {valid: false, reason: `RC Preflag ${oAssessement?.rcPreFlag} does not exist`};

    if (oAssessement?.category2 && oAssessement.category2 !== "") {
        const bCategory1 = masterData.sustainabilityCategory.some(item => item.code === oAssessement?.category1);
        if (!bCategory1) return {valid: false, reason: `Category 1 ${oAssessement?.category1} does not exist`};

        const bContributor1 = masterData.contributor.some(item => item.code === oAssessement?.contributor1);
        if (!bContributor1) return {valid: false, reason: `Contributor 1 ${oAssessement?.contributor1} does not exist`};
    }

    if (oAssessement?.category2 && oAssessement.category2 !== "") {
        const bCategory2 = masterData.sustainabilityCategory.some(item => item.code === oAssessement?.category2);
        if (!bCategory2) return {valid: false, reason: `Category 2 ${oAssessement?.category2} does not exist`};

        const bContributor2 = masterData.contributor.some(item => item.code === oAssessement?.contributor2);
        if (!bContributor2) return {valid: false, reason: `Contributor 2 ${oAssessement?.contributor2} does not exist`};
    }

    if (oAssessement?.category3 && oAssessement.category3 !== "") {
        const bCategory3 = masterData.sustainabilityCategory.some(item => item.code === oAssessement?.category3);
        if (!bCategory3) return {valid: false, reason: `Category 3 ${oAssessement?.category3} does not exist`};

        const bContributor3 = masterData.contributor.some(item => item.code === oAssessement?.contributor3);
        if (!bContributor3) return {valid: false, reason: `Contributor 3 ${oAssessement?.contributor3} does not exist`};
    }

    return {valid: true};
};

/**
 * Checks if all sustainability fields are right according to rules and
 * mappings for an assessment item
 * 
 * @param {Object} assessmentItem - Assessment item to evaluate
 * @param {Object[]} contributorMapping - Mapping of valid contributors for each csustainability category
 * @param {Object} rulesModel - Rules model configured
 * @returns {Boolean} true if all checks went well and nothing war overwritten, false otherwise
 */
function clearInvalidSustainabilityFieldsForItem( assessmentItem, contributorMapping, rulesModel ) {

    const { rcPreFlag, sustClass } = assessmentItem;

    // If sustainability class is not valid for RCPreflag, clear sust class and catgories
    const bHasValidSustainabilityClass = checkSustClass({ rcPreFlag, sustClass }, rulesModel);
    if (!bHasValidSustainabilityClass) {
        delete assessmentItem.sustClass;
        delete assessmentItem.category1;
        delete assessmentItem.category2;
        delete assessmentItem.category3;
    }

    // Check if contributors correspond to provided categories. If not, clear them
    const { areAllContributorsValid, invalidContributors } = checkContributors( assessmentItem, contributorMapping );
    if (!areAllContributorsValid) {

        invalidContributors.forEach(invalidField => {
            delete assessmentItem[invalidField];
        });

    }    

    // Check if all prooftype fields are valid of item documents are valid
    // If not, clear the key to avoid inconsistencies
    const { areAllProofFieldsValid, invalidProofDocuments } = checkTypeProofFieldsComplete( assessmentItem, rulesModel );
    if (!areAllProofFieldsValid) {

        invalidProofDocuments.forEach(invalidDocument => {
            const oDocument = assessmentItem.toProofDocuments.find( itemDocument => itemDocument.ID === invalidDocument)
            delete oDocument.type;
        });

    }

    // All checks are evaluated to return if any has gone wrong
    const bAreAllChecksRight = areAllProofFieldsValid && areAllContributorsValid;
    return bAreAllChecksRight;
};

module.exports = {
    beforeSubmitMass,
    checkAssessmentFieldValues,
    getAssessmentFieldMasterData,
    beforeSaveMass,
    getMassAssessmentDataBeforeSubmit,
    clearInvalidSustainabilityFieldsForItem,
};