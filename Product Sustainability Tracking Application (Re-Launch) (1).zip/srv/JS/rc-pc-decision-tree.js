const { ASSESSMENT_STATUS, SUSTAINABILITY_CLASS } = require("./assessment");

const UPDATE_TYPE = {
    DELETED: "Deleted",
    CHANGE: "Change",
    NEW: "New",
    NO_CHANGE: "No Change", // Possible value but not supported
};

const RC_PC_CATEGORY = "HS";
const RC_PC_CONTRIBUTOR = "SA";

/**
 * @typedef {Object} ExistingAssessment
 * @property {string} sustClass - Current sustainability class code
 * @property {string} rcPreFlag - Current RC preflag
 * @property {string} [category1] - First contribution category
 * @property {string} [contributor1] - First contributor identifier
 * @property {string} [category2] - Second contribution category
 * @property {string} [contributor2] - Second contributor identifier
 * @property {string} [category3] - Third contribution category
 * @property {string} [contributor3] - Third contributor identifier
 */

/**
 * @typedef {Object} SustClassMasterdataItem
 * @property {string} code - Sustainability class code
 * @property {number} level - Numeric level used to compare class rankings (higher = better)
 */

/**
 * @typedef {Object} DecisionTreeOutput
 * @property {string} status - Assessment status after the decision (e.g. SUBMITTED or SAVED)
 * @property {ExistingAssessment} newSustData - Updated sustainability data to persist
 */

/**
 * @typedef {Object} DecisionTreeDependencies
 * @property {Object} [assessmentStatus=ASSESSMENT_STATUS] - Map of valid assessment status values
 * @property {Object} [updateTypes=UPDATE_TYPE] - Map of valid update type values
 * @property {string} [rcPcCategory=RC_PC_CATEGORY] - RC/PC category identifier (default: "HS")
 * @property {string} [rcPcContributor=RC_PC_CONTRIBUTOR] - RC/PC contributor identifier (default: "SA")
 */

/**
 * Factory function that creates the RC/PC decision tree and all its associated methods.
 * Accepts injectable dependencies to allow testing and configuration overrides.
 *
 * @param {DecisionTreeDependencies} dependencies
 * @returns {{ 
 *   rootNode: Function,
 *   getHandler: Function,
 *   newHandler: Function,
 *   changeHandler: Function,
 *   deletedHandler: Function,
 *   buildNewAndUpgradeChangeOutput: Function,
 *   buildDeleteAndDowngradeChangeOutput: Function,
 *   checkPositiveContribution: Function,
 *   checkOnlyPositiveContribution: Function,
 *   getBestSustClass: Function,
 *   checkRcPcUpgrade: Function,
 *   getNonRcPcContributions: Function
 * }}
 */
function makeRcPcDecisionTree({
    assessmentStatus = ASSESSMENT_STATUS,
    updateTypes = UPDATE_TYPE,
    rcPcCategory = RC_PC_CATEGORY,
    rcPcContributor = RC_PC_CONTRIBUTOR,
} = {}) {

    /**
     * Entry point of the decision tree. Resolves and delegates to the appropriate
     * handler based on the given update type.
     *
     * @param {Object} params
     * @param {string} params.updateType - The type of update triggering this decision (e.g. "New", "Change", "Deleted")
     * @param {string} params.rcPcClass - The sustainability class code coming from the RC/PC classification
     * @param {string} params.previousRcPcClass - The last sustainability class code coming from the RC/PC classification
     * @param {ExistingAssessment} params.existingAssessment - The current state of the assessment before this update
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata - Master data used to rank sustainability classes
     * @returns {DecisionTreeOutput}
     * @throws {Error} If updateType is not a recognised and supported value
     */
    function rootNode({
        updateType,
        rcPcClass,
        previousRcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {
        const fnHandler = getHandler(updateType);
        if (!fnHandler) throw new Error(`Unknown updateType: "${updateType}"`);

        return fnHandler({
            rcPcClass,
            previousRcPcClass,
            existingAssessment,
            sustClassMasterdata,
        });
    }

    /**
     * Resolves the handler function for a given update type.
     * Returns undefined if the update type is not supported.
     *
     * @param {string} updateType - The update type to resolve
     * @returns {Function|undefined} The corresponding handler, or undefined if not found
     */
    function getHandler(updateType) {

        /** Mapping of handler to each root case */
        const UPDATE_TYPE_TO_RC_FLAG_HANDLER = {
            [updateTypes.NEW]: newHandler,
            [updateTypes.CHANGE]: changeHandler,
            [updateTypes.DELETED]: deletedHandler,
        };

        return UPDATE_TYPE_TO_RC_FLAG_HANDLER[updateType];

    }

    /**
     * Handles the "New" update type.
     * Delegates directly to {@link buildNewAndUpgradeChangeOutput}.
     *
     * @param {Object} params
     * @param {string} params.rcPcClass - Sustainability class from RC/PC
     * @param {ExistingAssessment} params.existingAssessment
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata
     * @returns {DecisionTreeOutput}
     */
    function newHandler({
        rcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {
        return buildNewAndUpgradeChangeOutput({
            rcPcClass,
            existingAssessment,
            sustClassMasterdata,
        });
    }

    /**
     * Handles the "Change" update type.
     * Determines whether the change is an upgrade or a downgrade compared to the existing
     * assessment, and delegates to the corresponding output builder.
     *
     * @param {Object} params
     * @param {string} params.rcPcClass - Sustainability class from RC/PC
     * @param {string} params.previousRcPcClass - Last Sustainability class from RC/PC
     * @param {ExistingAssessment} params.existingAssessment
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata
     * @returns {DecisionTreeOutput}
     */
    function changeHandler({
        rcPcClass,
        previousRcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {
        const bIsUpgraded = checkRcPcUpgrade(
            rcPcClass,
            previousRcPcClass,
            sustClassMasterdata,
        );

        if (bIsUpgraded) {
            // Upgrade case is equal to new case
            return buildNewAndUpgradeChangeOutput({
                rcPcClass,
                existingAssessment,
                sustClassMasterdata,
            });
        }

        // Downgrade is equal to deleted
        return buildDeleteAndDowngradeChangeOutput({
            rcPcClass,
            existingAssessment,
            sustClassMasterdata,
        });
    }


    /**
     * Handles the "Deleted" update type.
     * Delegates directly to {@link buildDeleteAndDowngradeChangeOutput}.
     *
     * @param {Object} params
     * @param {string} params.rcPcClass - Sustainability class from RC/PC
     * @param {ExistingAssessment} params.existingAssessment
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata
     * @returns {DecisionTreeOutput}
     */
    function deletedHandler({
        rcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {
        return buildDeleteAndDowngradeChangeOutput({
            rcPcClass,
            existingAssessment,
            sustClassMasterdata,
        });
    }

    /**
     * Builds the output for "New" and "Upgrade" (Change) cases.
     *
     * - Determines the best sustainability class between the incoming RC/PC class and the existing one.
     * - If the assessment does not already have a positive RC/PC contribution, adds one to the
     *   first available contributor slot. If all slots are taken, the last slot is overwritten.
     *
     * @param {Object} params
     * @param {string} params.rcPcClass - Sustainability class from RC/PC
     * @param {ExistingAssessment} params.existingAssessment
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata
     * @returns {DecisionTreeOutput} Output with status SUBMITTED
     */
    function buildNewAndUpgradeChangeOutput({
        rcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {

        const bHasPositiveContribution = checkPositiveContribution(existingAssessment);

        const sBestSustClass = getBestSustClass(
            [rcPcClass, existingAssessment.sustClass],
            sustClassMasterdata,
        );

        const oNewSustData = {
            ...existingAssessment,
            sustClass: sBestSustClass,
        };
        if (!bHasPositiveContribution) {
            // If does not have positive contribution, add corresponding contributor
            // if first available slot
            const aSlots = [1, 2, 3];
            const nEmptySlot = aSlots.find(i => !existingAssessment[`contributor${i}`]);            
            if (nEmptySlot) {
                oNewSustData[`category${nEmptySlot}`] = rcPcCategory;
                oNewSustData[`contributor${nEmptySlot}`] = rcPcContributor;                
            } else {
                // Default to last slot
                const nMaxSlot = Math.max(...aSlots);
                oNewSustData[`category${nMaxSlot}`] = rcPcCategory;
                oNewSustData[`contributor${nMaxSlot}`] = rcPcContributor;                  
            }

        }

        return {
            status: assessmentStatus.SUBMITTED,
            newSustData: oNewSustData,
        };

    }


    /**
     * Builds the output for "Deleted" and "Downgrade" (Change) cases.
     *
     * - If the assessment only contains RC/PC contributions, resets it to just the incoming
     *   RC/PC class and returns SUBMITTED.
     * - Otherwise, strips out any RC/PC contributions, keeps the remaining ones, and returns SAVED.
     *
     * @param {Object} params
     * @param {string} params.rcPcClass - Sustainability class from RC/PC
     * @param {ExistingAssessment} params.existingAssessment
     * @param {SustClassMasterdataItem[]} params.sustClassMasterdata
     * @returns {DecisionTreeOutput} Output with status SUBMITTED (only RC/PC) or SAVED (mixed contributions)
     */
    function buildDeleteAndDowngradeChangeOutput({
        rcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {

        const bOnlyHasRcPcContribution = checkOnlyPositiveContribution(existingAssessment);
        if (bOnlyHasRcPcContribution) {

            // New SC = RC preflag (max performer)
            const aClasses = [existingAssessment.rcPreFlag, SUSTAINABILITY_CLASS.PERFORMER];
            const sBestSustClass = getBestSustClass(aClasses, sustClassMasterdata);
            const sLowesttSustClass = aClasses.find(code => code !== sBestSustClass);

            return {
                status: assessmentStatus.SUBMITTED,
                newSustData: { sustClass: sLowesttSustClass },
            };
        }

        const oNonRcPcContributions = getNonRcPcContributions(existingAssessment);

        const oNewSustData = {
            sustClass: existingAssessment.sustClass,
            ...oNonRcPcContributions,
        };

        return {
            status: assessmentStatus.SAVED,
            newSustData: oNewSustData,
        };
    }

    /**
     * Checks whether the existing assessment already contains an RC/PC positive contribution,
     * i.e. whether the RC/PC category and contributor appear together across any of the three slots.
     *
     * @param {ExistingAssessment} existingAssessment
     * @returns {boolean} True if an RC/PC contribution is present
     */
    function checkPositiveContribution(existingAssessment) {

        const aSlots = [1, 2, 3];
        for (const slot of aSlots) {

            const bHasRcPcCategory = existingAssessment[`category${slot}`] === rcPcCategory;
            const bHasRcPcContributor = existingAssessment[`contributor${slot}`] === rcPcContributor;

            if (bHasRcPcCategory && bHasRcPcContributor) return true;
        }    

        return false;

    }

    /**
     * Checks whether all filled contribution slots in the assessment belong exclusively
     * to the RC/PC category and contributor. Returns false if no slots are filled.
     *
     * @param {ExistingAssessment} existingAssessment
     * @returns {boolean} True if all filled slots are RC/PC contributions, false if empty or mixed
     */
    function checkOnlyPositiveContribution(existingAssessment) {
        const {
            category1,
            contributor1,
            category2,
            contributor2,
            category3,
            contributor3,
        } = existingAssessment;

        const aFilledCategories = [category1, category2, category3].filter(Boolean);
        const aFilledContributors = [contributor1, contributor2, contributor3].filter(Boolean);

        const bOnlyHasRcPcCategory = aFilledCategories.every(
            (item) => item === rcPcCategory,
        );

        const bOnlyHasRcPcContributor = aFilledContributors.every((item) => item === rcPcContributor);

        return bOnlyHasRcPcCategory && 
            bOnlyHasRcPcContributor;
    }

    /**
     * Determines the best (highest-level) sustainability class from a given list of class codes,
     * by looking them up in the master data and comparing their levels.
     *
     * @param {string[]} sustClasses - Array of sustainability class codes to compare
     * @param {SustClassMasterdataItem[]} sustClassMasterdata - Master data containing codes and levels
     * @returns {string|undefined} The code of the highest-level sustainability class found, or undefined if none match
     */
    function getBestSustClass(sustClasses, sustClassMasterdata) {
        const oBestClass = sustClassMasterdata
            .filter((item) => sustClasses.includes(item.code))
            .reduce(
                (acc, curr) => {
                    if (acc.level > curr.level) return acc;
                    return curr;
                },
                { level: 0 },
            );

        return oBestClass.code;
    }

    /**
     * Checks whether the incoming RC/PC class represents an upgrade over the last known
     * sustainability class, by determining which of the two has the higher level.
     *
     * @param {string} rcPcClass - Incoming sustainability class from RC/PC
     * @param {string} lastSustClass - The existing sustainability class on the assessment
     * @param {SustClassMasterdataItem[]} sustClassMasterdata
     * @returns {boolean} True if rcPcClass is a higher level than lastSustClass
     */
    function checkRcPcUpgrade(rcPcClass, lastSustClass, sustClassMasterdata) {
        const sBestClass = getBestSustClass(
            [rcPcClass, lastSustClass],
            sustClassMasterdata,
        );

        return sBestClass !== lastSustClass;
    }

    /**
     * Extracts only the non-RC/PC contributions from an existing assessment,
     * re-indexed sequentially starting from slot 1.
     * A slot is considered RC/PC if its category matches rcPcCategory AND its contributor matches rcPcContributor.
     *
     * @param {ExistingAssessment} existingAssessment
     * @returns {Object} Flat object with re-indexed category/contributor keys (e.g. category1, contributor1, ...)
     */
    function getNonRcPcContributions(existingAssessment) {

        const {
            category1,
            category2,
            category3,
            contributor1,
            contributor2,
            contributor3,
        } = existingAssessment;

        const aContributions = [];
        if (category1 !== rcPcCategory || contributor1 !== rcPcContributor) {
            aContributions.push({
                category: category1,
                contributor: contributor1,
            });
        }

        if (category2 !== rcPcCategory || contributor2 !== rcPcContributor) {
            aContributions.push({
                category: category2,
                contributor: contributor2,
            });
        }

        if (category3 !== rcPcCategory || contributor3 !== rcPcContributor) {
            aContributions.push({
                category: category3,
                contributor: contributor3,
            });
        }

        const oContributions = {};
        aContributions.forEach((contribution, i) => {
            oContributions[`category${i + 1}`] = contribution.category;
            oContributions[`contributor${i + 1}`] = contribution.contributor;
        });

        return oContributions;
    }

    return {
        rootNode,
        getHandler,
        newHandler,
        changeHandler,
        deletedHandler,
        buildNewAndUpgradeChangeOutput,
        buildDeleteAndDowngradeChangeOutput,
        checkPositiveContribution,
        checkOnlyPositiveContribution,
        getBestSustClass,
        checkRcPcUpgrade,
        getNonRcPcContributions,
    }

}

module.exports = { makeRcPcDecisionTree };