const cds = require('@sap/cds');

/**
 * Base URL path for assessment notification service
 */
const BASE_PATH = 'odata/v4/assessment-notification';

/**
 * Resource endpoints for notification
 */
const NOTIFICATION_PATH = {
    ASSESSMENT_SAVED: 'notifyOnSave',
    ASSESSMENT_SUBMITTED: 'notifyOnSubmit',
    ASSESSMENT_UNDER_RESUBMISSION: 'notifyOnUnderResubmission',
    ASSESSMENT_RESUBMITTED: 'notifyOnResubmit',
    NEW_MOC_ASSESSMENT_SAVED: 'notifyOnNewMocSaved',
    NEW_PDP_ASSESSMENT_SAVED: 'notifyOnNewPdpSaved',
    NEW_RCPREFLAG_MISMATCH_ASSESSMENT_SUBMIT: 'notifyOnNewRcPreFlagMismatchSubmited',
    NEW_PDP_ASSESSMENT_SUBMITTED: 'notifyOnNewPdpSubmitted',
    BACKGORUND_ASSESSMENT_PRODUCT_BLOCKED: 'notifyAssessmentProductBlocked',
    PRODUCT_BLOCKED_PDP_MOC: 'notifyProductBlockedPdpMoc',
    MY_ID_USERS: 'getMyIdUsers',
    MY_ID_USERS_BY_GROUP: 'getMyIdUsersGroup',
    HEART_ASSESSMENT_SAVED:'notifyOnHeartAssessmentSaved',
    HEART_ASSESSMENT_SUBMITTED:'notifyOnHeartAssessmentSubmitted',
    PRODUCT_BLOCKED_HEART:'notifyProductBlockedHeart',
    RCPC_ASSESSMENT_SAVED:'notifyOnRcPositiveContributionAssessmentSaved',
    RCPC_ASSESSMENT_SUBMITTED:'notifyOnRcPositiveContributionAssessmentSubmitted',
};

/**
 * Required services to connect
 */
const SERVICE = {
    CUSTOM_NOTIFICATION: 'pst-custom-notification'
};

/**
 * HTTP connection methods
 */
const HTTP_METHOD = {
    POST: 'POST',
    GET: 'GET'
}

/**
 * Custom notificaiton service call
 * 
 * @param {Object} param0 - Parameters to make the call 
 * @returns {Promise} Result of http call
 */
async function callCustomNotification({ path, method, data = {} }) {
    const notificationService = await cds.connect.to(SERVICE.CUSTOM_NOTIFICATION);
    return await notificationService.send({
        path,
        method,
        data,
    })
};

/**
 * Post notification when saving assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.assessmentType - Type of assessment, MASS or SINGLE
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSave({ sbu, assessmentId, assessmentType }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.ASSESSMENT_SAVED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};


/**
 * Post notification when submitting assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.assessmentType - Type of assessment, MASS or SINGLE
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSubmitted({ sbu, assessmentId, assessmentType }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.ASSESSMENT_SUBMITTED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};


/**
 * Post notification when saving assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.assessmentType - Type of assessment, MASS or SINGLE
 * @param {string} param0.submitter - Submitter of assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnUnderResubmission({ sbu, assessmentId, assessmentType, submitter }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.ASSESSMENT_UNDER_RESUBMISSION}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType,
        submitter: submitter,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};


/**
 * Post notification when saving assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.assessmentType - Type of assessment, MASS or SINGLE
 * @param {string} param0.approver - Approver of the assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnResubmitted({ sbu, assessmentId, assessmentType, approver }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.ASSESSMENT_RESUBMITTED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType,
        approver: approver,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};

/**
 * Post notification when creating MOC assessment in saved status
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.type - Type of assessment, MOC or PDP
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSaveMoc({sbu, assessmentId, assessmentType}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.NEW_MOC_ASSESSMENT_SAVED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType, 
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/**
 * Post notification when creating a PDP assessment in saved status
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.type - Type of assessment, MOC or PDP
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSavePdp({sbu, assessmentId, assessmentType}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.NEW_PDP_ASSESSMENT_SAVED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType, 
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/**
 * Post notification when creating a PDP assessment in Submitted status
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notificationç
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.type - Type of assessment, MOC or PDP
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSubmitPdp({sbu, assessmentId, assessmentType}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.NEW_PDP_ASSESSMENT_SUBMITTED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
        assessmentType: assessmentType, 
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/**
 * Post notification when is not possible to create an assessment for specific product because are blocked in other assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.blockingAssessment - Assessment information that block the products
 * @param {string} param0.type - Type of assessment, MOC or PDP
 * @returns {Promise} Returned result of call
 */
async function postBlockingAssessmentNotification({blockingAssessment, assessmentType}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.BACKGORUND_ASSESSMENT_PRODUCT_BLOCKED}`;
    const oData = {
        blockingAssessment: blockingAssessment,
        type: assessmentType
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/**
 * Post notification when is not possible to create an assessment for specific products for PDP and MOC, notify the affected products
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.blockedProducts - Product information
 * @param {string} param0.sbu - sbu of the prodcut
 * @param {string} param0.type - Type of assessment, MOC or PDP
 * @returns {Promise} Returned result of call
 */
async function postProductBlockedNotificationPdpMoc({blockedProducts, sbu, type, adpProject}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.PRODUCT_BLOCKED_PDP_MOC}`;
    const oData = {
        blockedProducts: blockedProducts,
        sbu: sbu,
        type: type,
        adpProject: adpProject
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/** 
 * Retrieve users from MyIdUsers service
 * 
 * 
 * @param {Object} param0
 * @param {string} param0.sbu - SBU to filter users
 * @param {string} param0.status - Status to filter users
 * @param {string} param0.processType - Process type to filter users
 * @returns Array of user emails
 */
async function getMyIdUsers({ sbu, status, processType }) {
    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.MY_ID_USERS}`;
    const sParams = `(sbu='${sbu}',status='${status}',processType='${processType}')`;
    const sUrl = sPath + sParams;

    const result = await callCustomNotification({
        path: sUrl,
        method: HTTP_METHOD.GET,
    });


    return result || [];
};

/** 
 * Retrieve users by group from MyIdUsers service
 * 
 * 
 * @param {Object} param0
 * @param {string} param0.sbu - SBU to filter users
 * @param {string} param0.role - user's role
 * @param {string} param0.processType - Process type to filter users
 * @returns Array of user emails
 */
async function getMyIdUsersByGroup({ sbu, role, processType }) {
    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.MY_ID_USERS_BY_GROUP}`;
    const sFilter = `?sbu='${sbu}'&role='${role}'&processType='${processType}'`;
    const sUrl = sPath + sFilter;

    const result = await callCustomNotification({
        path: sUrl,
        method: HTTP_METHOD.GET,
    });


    return result || [];
};


/**
 * Post notification when creating RC Preflag Mismatch assessment in saved status
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of the assessment for notification
 * @param {string} param0.assessmentId - ID of the assessment
 * @param {string} param0.type - Type of assessment 
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnSubmitRcPreFlagMismatch({ sbu, assessmentId, assessmentType }) {
  const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.NEW_RCPREFLAG_MISMATCH_ASSESSMENT_SUBMIT}`;
  const oData = {
    sbu,
    assessmentId,
    assessmentType 
  };

  const result = await callCustomNotification({
    path: sPath,
    method: HTTP_METHOD.POST,
    data: oData
  });

  return result;
}

/**
 * Post notification when heart saving assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notification
 * @param {string} param0.assessmentId - ID of the assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnHeartAssessmentSave({ sbu, assessmentId }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.HEART_ASSESSMENT_SAVED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};

/**
 * Post notification when heart submitted assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notification
 * @param {string} param0.assessmentId - ID of the assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnHeartAssessmentSubmitted({ sbu, assessmentId }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.HEART_ASSESSMENT_SUBMITTED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};

/**
 * Post notification when is not possible to create an assessment for specific products for HEART, notify the affected products
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.blockedProducts - Product information
 * @param {string} param0.sbu - sbu of the prodcut
 * @returns {Promise} Returned result of call
 */
async function postProductBlockedNotificationHeart({blockedProducts, sbu}) {
    
    const sPath= `${BASE_PATH}/${NOTIFICATION_PATH.PRODUCT_BLOCKED_HEART}`;
    const oData = {
        blockedProducts: blockedProducts,
        sbu: sbu
    };

    const result = await callCustomNotification({path: sPath, method: HTTP_METHOD.POST, data: oData});

    return result;

};

/**
 * Post notification when RCPC saving assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notification
 * @param {string} param0.assessmentId - ID of the assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnRCPCAssessmentSave({ sbu, assessmentId }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.RCPC_ASSESSMENT_SAVED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};

/**
 * Post notification when RCPC submitted assessment
 * 
 * @param {Object} param0 - Parameters to call the notification service
 * @param {string} param0.sbu - SBU of assessment of notification
 * @param {string} param0.assessmentId - ID of the assessment
 * @returns {Promise} Returned result of call
 */
async function postNotificationOnRCPCAssessmentSubmitted({ sbu, assessmentId }) {

    const sPath = `${BASE_PATH}/${NOTIFICATION_PATH.RCPC_ASSESSMENT_SUBMITTED}`;
    const oData = {
        sbu: sbu,
        assessmentId: assessmentId,
    };

    const result = await callCustomNotification({ path: sPath, method: HTTP_METHOD.POST, data: oData });

    return result;

};

module.exports = {
    postNotificationOnSave,
    postNotificationOnSubmitted,
    postNotificationOnUnderResubmission,
    postNotificationOnResubmitted,
    postNotificationOnSaveMoc,
    postNotificationOnSavePdp,
    postNotificationOnSubmitRcPreFlagMismatch,
    postNotificationOnSubmitPdp,
    postBlockingAssessmentNotification,
    postProductBlockedNotificationPdpMoc,
    getMyIdUsers,
    getMyIdUsersByGroup,
    postNotificationOnHeartAssessmentSave,
    postNotificationOnHeartAssessmentSubmitted,
    postProductBlockedNotificationHeart,
    postNotificationOnRCPCAssessmentSave,
    postNotificationOnRCPCAssessmentSubmitted
}