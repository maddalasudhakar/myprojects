const { 
    ASSESSMENT_STATUS, 
    SUSTAINABILITY_CLASS,
} = require('./assessment');

/** HEART data update type values */
const UPDATE_TYPE = {
    DELETED: 'Deleted',
    UPDATE: 'Update',
    NEW: 'New',
    NO_CHANGES: 'No Changes',
};

/** Valid update types for assessment creation*/
const VALID_UPDATE_TYPE = {
    DELETED: UPDATE_TYPE.DELETED,
    UPDATE: UPDATE_TYPE.UPDATE,
    NEW: UPDATE_TYPE.NEW,
};

/** Cradle-to-gate cotributor */
const CONTRIBUTOR_CRADLE_TO_GATE = 'CM';

/** Proof point type for exemption L3 */
const EXEMPTION_L3_DOCUMENT = '20';

/** Mapping of handler to each root case */
const UPDATE_TYPE_TO_RC_FLAG_HANDLER = {
    [UPDATE_TYPE.NEW]: {
        [SUSTAINABILITY_CLASS.UNKNOWN]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T1]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.PERFORMER_T2B]: newOrUpdatePerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T2A]: newOrUpdatePerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.CONTRIBUTOR]: newOrUpdateContributorNode,
        [SUSTAINABILITY_CLASS.PIONEER]: newOrUpdatePioneerNode,
    },
    [UPDATE_TYPE.UPDATE]: {
        [SUSTAINABILITY_CLASS.UNKNOWN]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T1]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.PERFORMER_T2B]: newOrUpdatePerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T2A]: newOrUpdatePerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.CONTRIBUTOR]: newOrUpdateContributorNode,
        [SUSTAINABILITY_CLASS.PIONEER]: newOrUpdatePioneerNode,
    },
    [UPDATE_TYPE.DELETED]: {
        [SUSTAINABILITY_CLASS.UNKNOWN]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T1]: transitionerT1OrUnknownNode,
        [SUSTAINABILITY_CLASS.PERFORMER_T2B]: deletedPerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.TRANSITIONER_T2A]: deletedPerformerT2bOrTransistionerT2aNode,
        [SUSTAINABILITY_CLASS.CONTRIBUTOR]: deletedContributorNode,
        [SUSTAINABILITY_CLASS.PIONEER]: deletedPioneerNode,
    },                
}; 

/**
 * @typedef {Object} DecisionTreeParams
 * @property {string} heartSustClass - The sustainability class calculated by the HEART engine.
 * @property {string} rcPreFlag - The "Recycled Content" pre-flag status from master data.
 * @property {string} existingSustClass - The current class assigned to the material before this update.
 * @property {string} contributor1 - Primary material contributor.
 * @property {string} contributor2 - Secondary material contributor.
 * @property {string} contributor3 - Tertiary material contributor.
 * @property {string} proofDocuments - Comma-separated IDs or links to supporting verification.
 * @property {string} updateType - The trigger action (e.g., NEW, UPDATE, DELETED).
 * @property {string} sustClassMasterdata - Reference data used for class validation.
 */

/**
 * Base HEART decision tree node for calculating status and sustainability class.
 * @param {DecisionTreeParams} params
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped.
 */
function rootNode(params) {

    const { 
        heartSustClass, 
        rcPreFlag, 
        existingSustClass, 
        contributor1, 
        contributor2, 
        contributor3, 
        proofDocuments, 
        updateType, 
        sustClassMasterdata,
    } = params;

    const bIsValidUpdateType = Object.values( VALID_UPDATE_TYPE ).includes( updateType );
    if (!bIsValidUpdateType) {
        return false;
    }

    const fnUpdateTypeToRcPreFlagHandler = UPDATE_TYPE_TO_RC_FLAG_HANDLER[updateType]?.[rcPreFlag];
    if ( fnUpdateTypeToRcPreFlagHandler ) {

        return fnUpdateTypeToRcPreFlagHandler({ 
            heartSustClass, 
            rcPreFlag, 
            existingSustClass, 
            contributor1, 
            contributor2, 
            contributor3, 
            proofDocuments, 
            updateType,
            sustClassMasterdata,
        });

    }
    
    return false;

};

/**
 * Handles Transitioner T1 or Unknown RC Preflags
 * @param {Object} param0
 * @param {string} param0.rcPreFlag - Material RC Preflag 
 * @param {string} param0.existingSustClass - Material sustainability class 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped.
 */
function transitionerT1OrUnknownNode({ rcPreFlag, existingSustClass }) {
    
    return onlySavedFinalNode({ rcPreFlag, existingSustClass });

};

/**
 * Handles New and Update on Performer T2B or Transitioner T2a
 * @param {DecisionTreeParams} params 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function newOrUpdatePerformerT2bOrTransistionerT2aNode(params) {

    const { 
        heartSustClass, 
        rcPreFlag, 
        existingSustClass, 
        contributor1, 
        contributor2, 
        contributor3, 
        proofDocuments, 
        sustClassMasterdata,
    } = params;

    // Function to handle L3 exemption logic
    const fnL3ExemptionHandler = () => {
        return newOrUpdateIsHeartContributorOrPioneerNode({
            heartSustClass,
            existingSustClass, 
            contributor1, 
            contributor2, 
            contributor3, 
            sustClassMasterdata,    
        });
    };

    return performerT2bOrTransistionerT2aSharedNode(
        { 
            rcPreFlag, 
            existingSustClass, 
            proofDocuments, 
        }, 
        fnL3ExemptionHandler,
    );

};

/**
 * Calculates decision tree cases when in final node only saved status is possible
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped.
 */
function onlySavedFinalNode({ rcPreFlag, existingSustClass }) {

    const sNewClass = rcPreFlag;
    if (sNewClass === existingSustClass) return false;

    return { sustClass: sNewClass, status: ASSESSMENT_STATUS.SAVED };       
    
};

/**
 * Handles shared logic among New, Update and Deleted Update type flows
 * @param {*} param0 
 * @param {function} l3ExemptionNodeHandler 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function performerT2bOrTransistionerT2aSharedNode(
    { 
        rcPreFlag, 
        existingSustClass, 
        proofDocuments, 
    }, 
    l3ExemptionNodeHandler,
) {

    const bHasL3Exemption = proofDocuments.some( document => {
        return document.type === EXEMPTION_L3_DOCUMENT && document.active;
    });
    if ( bHasL3Exemption ) return l3ExemptionNodeHandler();

    return onlySavedFinalNode({ rcPreFlag, existingSustClass });    

};

/**
 * Handles New or Update contibutor Shared node
 * @param {DecisionTreeParams} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function newOrUpdateIsHeartContributorOrPioneerNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {

    // Check if HEART flag of existing sustainability class are contributor o pioneer. 
    // If yes, new class is contributor else performer
    const bIsContributorHeartOrExisting = ( 
        heartSustClass === SUSTAINABILITY_CLASS.CONTRIBUTOR || 
        existingSustClass === SUSTAINABILITY_CLASS.CONTRIBUTOR 
    );
    const bIsPioneerHeartOrExisting = ( 
        heartSustClass === SUSTAINABILITY_CLASS.PIONEER || 
        existingSustClass === SUSTAINABILITY_CLASS.PIONEER 
    );            
    const sNewClass = ( bIsContributorHeartOrExisting || bIsPioneerHeartOrExisting )
        ? SUSTAINABILITY_CLASS.CONTRIBUTOR
        : SUSTAINABILITY_CLASS.PERFORMER;

    const sStatus = newOrUpdateDecideSubmittedOrSavedNode({
        heartSustClass,
        existingSustClass,
        contributor1,
        contributor2,
        contributor3,
        sustClassMasterdata,
    });

    return { sustClass: sNewClass, status: sStatus };

};

/**
 * Handles New or Update Contributor RC Preflag
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function newOrUpdateContributorNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {

    return newOrUpdateIsHeartContributorOrPioneerNode({
        heartSustClass,
        existingSustClass,
        contributor1,
        contributor2,
        contributor3,
        sustClassMasterdata,
    })

};

/**
 * Handles New or Update Pioneer RC Preflag
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function newOrUpdatePioneerNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {

    // Check if HEART flag of existing sustainability class are contributor o pioneer. 
    // If yes, new class is contributor else performer
    const bIsContributorHeartOrExisting = ( 
        heartSustClass === SUSTAINABILITY_CLASS.CONTRIBUTOR || 
        existingSustClass === SUSTAINABILITY_CLASS.CONTRIBUTOR 
    );
    const bIsPioneerHeartOrExisting = ( 
        heartSustClass === SUSTAINABILITY_CLASS.PIONEER || 
        existingSustClass === SUSTAINABILITY_CLASS.PIONEER 
    );

    const sBestClass = getBestSustClass( [heartSustClass, existingSustClass], sustClassMasterdata );

    const sNewClass = ( bIsContributorHeartOrExisting || bIsPioneerHeartOrExisting )
        ? sBestClass
        : SUSTAINABILITY_CLASS.PERFORMER;

    const sStatus = newOrUpdateDecideSubmittedOrSavedNode({
        heartSustClass,
        existingSustClass,
        contributor1,
        contributor2,
        contributor3,
        sustClassMasterdata,
    });

    return { sustClass: sNewClass, status: sStatus };

};

/**
 * Handles New or Update status when either save or submitted could be the result
 * @param {*} param0 
 * @returns {string} Assessment status 
 */
function newOrUpdateDecideSubmittedOrSavedNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {

    // To determine status, downgrade of class in HEART and one contributor being 
    // cradle-to-gate are checked.
    const nHeartLevel = sustClassMasterdata.find(
        item => item.code === heartSustClass
    )?.level;
    const nSustClassLevel = sustClassMasterdata.find(
        item => item.code === existingSustClass
    )?.level;
    const bIsDowngraded = nHeartLevel < nSustClassLevel;

    const bHasOneCradleToGate = [ 
        contributor1, 
        contributor2, 
        contributor3,
    ].includes( CONTRIBUTOR_CRADLE_TO_GATE );

    if ( bIsDowngraded && bHasOneCradleToGate ) {  
        return ASSESSMENT_STATUS.SAVED; 
    } 

    return ASSESSMENT_STATUS.SUBMITTED; 

};

/**
 * Handles deleted Performer T2B and Transitioner T2A RC Preflag
 * @param {DecisionTreeParams} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped.  
 */
function deletedPerformerT2bOrTransistionerT2aNode({
    heartSustClass, 
    rcPreFlag, 
    existingSustClass, 
    contributor1, 
    contributor2, 
    contributor3, 
    proofDocuments, 
    sustClassMasterdata,
}) {

    // Function to handle L3 exemption logic
    const fnL3ExemptionHandler = () => {
        return deletedIsHeartContributorOrPioneerNode({
            heartSustClass,
            existingSustClass, 
            contributor1, 
            contributor2, 
            contributor3, 
            sustClassMasterdata            
        });
    };

    return performerT2bOrTransistionerT2aSharedNode(
        { 
            rcPreFlag, 
            existingSustClass, 
            proofDocuments, 
        }, 
        fnL3ExemptionHandler,
    );  

};

/**
 * Handles deleted update type Contributor Or Pioneer shared node
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function deletedIsHeartContributorOrPioneerNode({
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
}) {

    const bIsExistingContributor = ( 
        existingSustClass === SUSTAINABILITY_CLASS.CONTRIBUTOR 
    );
    const bIsExistingPioneer = ( 
        existingSustClass === SUSTAINABILITY_CLASS.PIONEER 
    );            
    const bIsOnlyContributorCradleToGate = (
        ( !contributor1 || contributor1 === CONTRIBUTOR_CRADLE_TO_GATE ) &&
        ( !contributor2 || contributor2 === CONTRIBUTOR_CRADLE_TO_GATE ) &&
        ( !contributor3 || contributor3 === CONTRIBUTOR_CRADLE_TO_GATE )
    );

    const bIsNewContributor = (
        ( bIsExistingContributor || bIsExistingPioneer ) && 
        !bIsOnlyContributorCradleToGate 
    );
    const sNewClass = bIsNewContributor
        ? SUSTAINABILITY_CLASS.CONTRIBUTOR 
        : SUSTAINABILITY_CLASS.PERFORMER;

    const sStatus = bIsOnlyContributorCradleToGate 
        ? ASSESSMENT_STATUS.SAVED
        : ASSESSMENT_STATUS.SUBMITTED;

    return { sustClass: sNewClass, status: sStatus };

};

/**
 * Handles Deleted contributor RC Preflag
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function deletedContributorNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {

    return deletedIsHeartContributorOrPioneerNode({
        heartSustClass,
        existingSustClass,
        contributor1,
        contributor2,
        contributor3,
        sustClassMasterdata,
    });

};

/**
 * Handles Deleted Pioneer RC Preflag
 * @param {*} param0 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function deletedPioneerNode({
    heartSustClass,
    existingSustClass,
    contributor1,
    contributor2,
    contributor3,
    sustClassMasterdata,
}) {
    return deletedIsHeartContributorOrPioneerNode({
        heartSustClass,
        existingSustClass,
        contributor1,
        contributor2,
        contributor3,
        sustClassMasterdata,
    });
};

/**
 * Calculates best sustainability class from a set of them
 * @param {*} sustClasses 
 * @param {*} sustClassMasterdata 
 * @returns {Object|boolean} Assessment status and sustainbility class or false if skipped. 
 */
function getBestSustClass( sustClasses, sustClassMasterdata ) {

    const oBestClass = sustClassMasterdata.filter(
        item => sustClasses.includes(item.code)
    )
    .reduce((acc, curr) => {
        if ( acc.level > curr.level ) return acc;
        return curr;
    }, { level: 0 });

    return oBestClass.code;

};

module.exports = {
    UPDATE_TYPE,
    VALID_UPDATE_TYPE,
    CONTRIBUTOR_CRADLE_TO_GATE,
    UPDATE_TYPE_TO_RC_FLAG_HANDLER,
    EXEMPTION_L3_DOCUMENT,
    rootNode,
    transitionerT1OrUnknownNode,
    newOrUpdatePerformerT2bOrTransistionerT2aNode,
    onlySavedFinalNode,
    performerT2bOrTransistionerT2aSharedNode,
    newOrUpdateIsHeartContributorOrPioneerNode,
    newOrUpdateContributorNode,
    newOrUpdatePioneerNode,
    newOrUpdateDecideSubmittedOrSavedNode,
    deletedPerformerT2bOrTransistionerT2aNode,
    deletedIsHeartContributorOrPioneerNode,
    transitionerT1OrUnknownNode,
    deletedContributorNode,
    deletedPioneerNode,
    getBestSustClass,
};
