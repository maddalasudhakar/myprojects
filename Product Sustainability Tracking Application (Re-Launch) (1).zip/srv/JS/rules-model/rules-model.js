const path = require('path');
const { readJSONFromFile } = require("../json-utils");

/**
 * Reads a file containing the rules model data 
 * @returns {Object} Object with the read data 
 */
async function getRules() {

    try {
        const filePath = path.join(__dirname, 'rules-model.json');
        const file = await readJSONFromFile(filePath);

        return file;
    } catch (e) {
        console.error("Error reading rules model file");
        return;
    }

}

/**
 * Check if assessment complies with rules model
 * 
 * @param {*} oAssessment 
 * @returns 
 */
async function checkRules(oAssessment, oRules, aContributorMapping) {

    const oRulesModel = oRules || await getRules();
    if (!oRulesModel) throw new Error("Submit validation rules missing");

    const {
        rcPreFlag,
        requestName,
        sustClass,
        approbalStatus,
    } = oAssessment;

    const oReturn = {
        continue: true,
        reason: "",
        hasSustainabilityError: false,
    }

    if (!requestName) {
        oReturn.continue = false;
        oReturn.reason = "No request name provided";
        return oReturn;
    }

    if (!approbalStatus) {
        oReturn.continue = false;
        oReturn.reason = "No approval status provided";
        return oReturn;
    }

    const bIsSustClassValid = checkSustClass( { rcPreFlag, sustClass }, oRulesModel );
    if (!bIsSustClassValid) {
        oReturn.continue = false;
        oReturn.reason = "No valid RC Preflag for sustainability Class";
        oReturn.hasSustainabilityError = true;
        return oReturn;
    }

    // Check all contributors to see if it follows parametrised ones to category
    const { areAllContributorsValid, invalidContributors } = checkContributors(oAssessment, aContributorMapping);
    if (!areAllContributorsValid) {
        const sInvalidContributor = oAssessment[invalidContributors[0]];
        const sCategory = oAssessment[invalidContributors[0].replace('contributor', 'category')];

        oReturn.continue = false;
        oReturn.reason = `Contributor ${sInvalidContributor} is not valid for sustainability category ${sCategory}`;
        oReturn.hasSustainabilityError = true;
        return oReturn;
    }

    // Backend specific validations before rules
    const { mandatory } = oRulesModel.backend;
    for (const key in mandatory) {
        if (oAssessment[key] && oAssessment[key] != "" && mandatory[key]?.coMandatory) {
            for (const coMandatory of mandatory[key].coMandatory) {
                if (!oAssessment[coMandatory] || oAssessment[coMandatory] == "") {
                    const sKeyDescription = oRulesModel.descriptors[key];                     
                    const sKeyCoMandatory = oRulesModel.descriptors[coMandatory];                     
                    oReturn.continue = false;
                    oReturn.reason = `Field ${sKeyCoMandatory} is mandatory when ${sKeyDescription} is also provided`;
                    return oReturn;                    
                }
            }
        }
    }

    const oRulesSustClass = oRulesModel[rcPreFlag][sustClass];
    if (oRulesSustClass.proofEnabled) {

        const bMandatoryProofFieldsCheck = checkMassMandatoryProofFields(oAssessment, oRulesSustClass.proofMandatory);
        if (!bMandatoryProofFieldsCheck) {
            oReturn.continue = false;
            oReturn.reason = "Error in proofpoints";
            return oReturn;
        }

        const bTypeProofFieldsCheck = checkTypeProofFields(oAssessment, oRulesModel);
        if (!bTypeProofFieldsCheck) {
            oReturn.continue = false;
            oReturn.reason = "Error in proofpoints: Fields do not match sustainability data provided";
            oReturn.hasSustainabilityError = true;
            return oReturn;
        }

        for (const [sKey, bMandatory] of Object.entries(oRulesSustClass.mandatory)) {
            sValue = oAssessment[sKey];
            if (bMandatory && (sValue === undefined || sValue === null || sValue === "" || sValue === "00")) {
                const sKeyDescription = oRulesModel.descriptors[sKey];
                oReturn.continue = false;
                oReturn.reason = `Missing mandatory field ${sKeyDescription}`;
                return oReturn;
            }
        }

    }

    return oReturn;
};

/**
 * Check mandatory proof fields of Single Assessment
 * @public
 */
function checkMassMandatoryProofFields(oAssessement, bMandadory) {

    let bHasActiveProofDocument = false;

    if (bMandadory && oAssessement.toProofDocuments.length === 0) {
        return false;
    }

    for (const oProofDocument of oAssessement.toProofDocuments) {
        if ((!oProofDocument.type || !oProofDocument.description || !oProofDocument.fileName) &&
            (!oProofDocument.imageMasterID && oProofDocument.active)) {
            return false;
        }

        if (oProofDocument.active) {
            bHasActiveProofDocument = true;
        }

    }

    if (bMandadory && !bHasActiveProofDocument) {
        return false;
    }

    return true;

};

/**
* Check if the type matches with the contributors and sustClass (special cases) for mass assessments
* @public
*/
function checkTypeProofFields(oAssessment, oRulesModel) {

    let aProofTypeRulesModel = oRulesModel.proofTypes,
        aSpecialProofTypes = oRulesModel.expecialProofTypes, // Retrieve special proof types
        aProofDocuments = oAssessment.toProofDocuments.filter(document => {
            return document.active && !document.imageMasterID; 
        }),
        sContributor1 = oAssessment.contributor1,
        sContributor2 = oAssessment.contributor2,
        sContributor3 = oAssessment.contributor3,
        sRcPreFlag = oAssessment.rcPreFlag,
        bValid = true,
        bValidForContributors = false,
        bValidForSustClass = false;

    // Loop through proof documents and validate
    for (const oProofDocument of aProofDocuments) {
        let sType = oProofDocument.type;

        if (sType) {
            let oEntry = aProofTypeRulesModel.find(function (aRule) {
                return aRule.typeId === sType;
            });

            if (oEntry) {
                // Check if the type is valid for contributors
                bValidForContributors = oEntry.contributorId.includes(sContributor1) || oEntry.contributorId.includes(sContributor2) ||
                    oEntry.contributorId.includes(sContributor3) || oEntry.contributorId.includes(sRcPreFlag);
            }

            // Check if the type is valid for special sRcPreFlag
            let aSpecialRulesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
                return specialRule.sustClass === sRcPreFlag;
            });

            if (aSpecialRulesForsRcPreFlag.length > 0) {
                // If it is a special case, validate for sRcPreFlag
                bValidForSustClass = aSpecialRulesForsRcPreFlag.some(function (specialRule) {
                    return specialRule.typeId.includes(sType);
                });
            }

            // If not valid for both contributors and sustClass, mark as invalid
            if (!bValidForContributors && !bValidForSustClass) {
                bValid = false;
                break; // No need to continue checking other documents if one is invalid
            }
        }
    }

    return bValid;
};

/**
 * Checks if RCPreflag is valid for the sustainability class according to rules model
 * 
 * @param {Object} assessmentItem - Assessment item data to check
 * @param {String} assessmentItem.rcPreFlag - RC Preflag of product
 * @param {String} assessmentItem.sustClass - Selected sustainability class of assessment
 * @param {*} rulesModel - Rules model data
 * @returns {Boolean} True if valid, false otherwise
 */
function checkSustClass ( { rcPreFlag, sustClass }, rulesModel ) {
    const bIsRcPreFlagValidForSustClass = rulesModel[rcPreFlag] && rulesModel[rcPreFlag][sustClass];
    return bIsRcPreFlagValidForSustClass;
};

/**
 * Copy of checkTypeProofFields but checking and returning all proof fields that
 * are mistaken
 * 
 * @param {Object} oAssessment - Assessment item dafa, including proof documents
 * @param {Object} oRulesModel - Rules data
 * @returns {Object[]} List of wrong documents and fields
 */
function checkTypeProofFieldsComplete(oAssessment, oRulesModel) {

    const aProofDocuments = oAssessment.toProofDocuments.filter(document => {
            return document.active && !document.imageMasterID; 
        });

    // Loop through proof documents and validate prooffield
    const aProofDocumentsInvalid = aProofDocuments.reduce((acc, curr) => {

        const bIsValid = checkProofDocumentType(oAssessment, curr, oRulesModel);
        if (bIsValid) {
            acc.push(curr.ID);
        }

        return acc;

    }, []);

    return {
        areAllValid: aProofDocumentsInvalid.length === 0, 
        invalidProofDocuments: aProofDocumentsInvalid, 
    };

};

/**
 * Check if proof document type is valid
 * 
 * @param {Object} assessmentItem - Assessment data which has the proofPoint 
 * @param {Object} proofDocument - Proof document to check 
 * @param {Object} rulesModel - Rules model 
 * @returns {String[]} List of document IDs that are not valid
 */
function checkProofDocumentType ( assessmentItem, proofDocument, rulesModel ) {

    const sType = proofDocument.type;
    const sContributor1 = assessmentItem.contributor1;
    const sContributor2 = assessmentItem.contributor2;
    const sContributor3 = assessmentItem.contributor3;
    const sRcPreFlag = assessmentItem.rcPreFlag;
    const aProofTypeRulesModel = rulesModel.proofTypes;    
    const aSpecialProofTypes = rulesModel.expecialProofTypes;
    let bValidForContributors = false,
        bValidForSustClass = false;    

    if (sType) {
        let oEntry = aProofTypeRulesModel.find(function (aRule) {
            return aRule.typeId === sType;
        });

        if (oEntry) {
            // Check if the type is valid for contributors
            bValidForContributors = oEntry.contributorId.includes(sContributor1) || oEntry.contributorId.includes(sContributor2) ||
                oEntry.contributorId.includes(sContributor3) || oEntry.contributorId.includes(sRcPreFlag);
        }

        // Check if the type is valid for special sRcPreFlag
        let aSpecialRulesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
            return specialRule.sustClass === sRcPreFlag;
        });

        if (aSpecialRulesForsRcPreFlag.length > 0) {
            // If it is a special case, validate for sRcPreFlag
            bValidForSustClass = aSpecialRulesForsRcPreFlag.some(function (specialRule) {
                return specialRule.typeId.includes(sType);
            });
        }

        // If not valid for both contributors and sustClass, mark as invalid
        if (!bValidForContributors && !bValidForSustClass) {
            return false;
        }
        return true;
    }  

    return false;
};

/**
 * Checks if provided contributors for a sustainability category are valid
 * 
 * @param {Object} assessmentItem 
 * @param {Object} contributorMapping 
 * @returns 
 */
function checkContributors ( assessmentItem, contributorMapping ) {

    const CONTRIBUTOR_MAX_NUMBER = 3;
    const CATEGORY = 'category';
    const CONTRIBUTOR = 'contributor';
    const aInvalidContributors = [];

    for ( let i = 1; i <= CONTRIBUTOR_MAX_NUMBER; i++ ) {

        const sCategoryKey = `${CATEGORY}${i}`;
        const sContributorKey = `${CONTRIBUTOR}${i}`;
        
        const sCategory = assessmentItem[sCategoryKey];
        const sContributor = assessmentItem[sContributorKey];

        if (sContributor) {
            const bIsValid = contributorMapping.some( item => {
                return item.categoryCode === sCategory && item.code === sContributor;
            });

            if (!bIsValid)  aInvalidContributors.push(sContributorKey);
        }

    }

    return {
        areAllContributorsValid: aInvalidContributors.length === 0,
        invalidContributors: aInvalidContributors,
    };

};

module.exports = {
    getRules,
    checkRules,
    checkSustClass,
    checkTypeProofFieldsComplete,
    checkContributors,
};