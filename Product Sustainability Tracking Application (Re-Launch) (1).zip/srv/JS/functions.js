const { PutObjectCommand, GetObjectCommand, DeleteObjectCommand, GetBucketAccelerateConfigurationCommand } = require('@aws-sdk/client-s3');
const { divideArrayInBatches } = require("./batching-utils");
const cds = require('@sap/cds/libx/_runtime/cds');
const { getMassAssessmentHeaderById } = require('./assessment'); 
const TYPE_IB = "IB";
const TYPE_IDH = "IDH";
const COMMUNICATION_STATUS = {
    PENDING: '01',
    PENDING_CPI_RETRY: "11",
    SENDED_CPI: '02',
    FEEDBACK_RECEIVED: '03',
    RETRYING: '04',
    COMPLETED: '05',
}

const ENTITIES = {
    DB: {
        MASS_ASSESSMENT_HEADER: "management.MassAssessmentHeader",
        MASS_ASSESSMENT_ITEMS: "management.MassAssessmentItems",
    }
}

/**
 * Builds a query for assessments based on the user's role.
 * @param {string} assessmentType - The type of assessment (Single or Mass).
 * @param {string} sbu - The SBU associated with the user.
 * @param {string} role - The role of the user (Submitter, Assessor, Approver, Viewer).
 * @param {string} userId - The ID of the user.
 * @returns {Object} The constructed query for the specified assessment type.
 */
function buildAssessmentQuery(assessmentType, userId) {//sbu, role, userId) {
    let query = SELECT('status', 'count(*) as assessments')
        .from(assessmentType)
        .where({ status: ['01', '02', '03', '04', '05'] })
        .groupBy('status');

    query = query.and`submitter = ${userId} or assessor = ${userId} or assessor = ${userId}`;

    return query; // Return the constructed query
}

/**
 * Dynamically builds the queries for Single and Mass assessments.
 * @param {string} singleAssessment - The SingleAssessment table name.
 * @param {string} massAssessmentHeader - The MassAssessmentHeader table name.
 * @param {string} sbu - The SBU associated with the user.
 * @param {string} role - The role of the user.
 * @param {string} userId - The ID of the user.
 * @returns {Object} An object containing both assessment queries.
 */
function assessmentsCountQuery(singleAssessment, massAssessmentHeader, sbu, role, userId) {
    const querySingleAssessment = buildAssessmentQuery(singleAssessment, sbu, role, userId);
    const queryMassAssessment = buildAssessmentQuery(massAssessmentHeader, sbu, role, userId);

    return {
        singleAssessment: querySingleAssessment,
        massAssessmentHeader: queryMassAssessment
    }; // Return both assessment queries
}

/**
 * Retrieves user parameters including SBU and roles.
 * @param {Object} user - The user object containing roles and ID.
 * @returns {Object} An object with user parameters: SBU array, role object, composed roles, and user ID.
 */
function userParameters(user) {
    const aSbu = ['ACM', 'AMC', 'AME', 'AMI', 'AMO', 'APC', 'APP', 'ACB', 'ACC'];
    const aRoles = ['Viewer', 'Assessor', 'Submitter', 'Approver', 'ViewerPlus', 'ITTechnicalMaintenance'];

    let oUserRoles = user.roles; // Object containing user roles (e.g., { 'ACC.Submitter': true, 'Approver': true })

    // Initialize the object to store user parameters
    let oUserParameters = {
        sbu: {
            newAssessment: [], // SBUs where the user is an Assessor or Submitter
            approveAssessment: [] // SBUs where the user is an Approver
        },
        role: {},            // Object to hold role flags (e.g., { Submitter: true })
        composedRoles: [],   // Array to hold full SBU.Role (e.g., 'ACC.Submitter', 'AMO.Approver')
        userId: user.id      // String representing the user ID
    };

    // Iterate over each key in the user roles object
    for (const roleEntry in oUserRoles) {
        if (oUserRoles.hasOwnProperty(roleEntry)) {
            // Split the roleEntry into SBU and Role parts (if applicable)
            const [sbu, role] = roleEntry.includes('.') ? roleEntry.split('.') : [null, roleEntry];

            // Check if it's an SBU-Role combination
            if (sbu && aSbu.includes(sbu)) {
                oUserParameters.composedRoles.push(roleEntry); // Add the full SBU.Role (e.g., 'ACC.Submitter')

                // Add to the appropriate SBU list based on the role
                if (role === 'Assessor' || role === 'Submitter') {
                    oUserParameters.sbu.newAssessment.push(sbu); // Add SBUs for new assessment
                } else if (role === 'Approver') {
                    oUserParameters.sbu.approveAssessment.push(sbu); // Add SBUs for approve assessment
                }
            }

            // Check if it's a valid role (either standalone or part of an SBU)
            const roleToCheck = role || roleEntry; // If no split happened, use roleEntry as the role
            if (aRoles.includes(roleToCheck)) {
                oUserParameters.role[roleToCheck] = true; // Mark the role as true (e.g., 'Submitter': true)
            }
        }
    }

    return oUserParameters; // Return the user parameters object
}

/**
 * Validate user's permissions based on SBU and status.
 * @param {Object} req - The request object.
 * @returns {Boolean} Returns true if the user has the required permissions, false otherwise.
 */
function validateSingleAssementUserPermissions(req) {
    const allowedSbu = ['ACM', 'AMC', 'AME', 'AMI', 'AMO', 'APC', 'APP', 'ACB', 'ACC'];
    const { sbu, status } = req.data;


    // Validate that `sbu` is within the allowed list
    if (!allowedSbu.includes(sbu)) {
        req.error(400, `The SBU ${sbu} is not valid.`);
        return false;
    }

    // Define required roles based on the `status`
    const requiredRole = {
        '01': [`${sbu}.Assessor`, `${sbu}.Submitter`],
        '02': [`${sbu}.Submitter`],
        '03': [`${sbu}.Approver`],
        '04': [`${sbu}.Submitter`],
        '05': [`${sbu}.Approver`],
        '06': [`${sbu}.Approver`]
    }[status];

    // If no roles are defined for this status, return an error
    if (!requiredRole) {
        req.error(400, `Invalid status ${status} provided.`);
        return false;
    }

    // Check if the user has any of the required roles
    const hasPermission = requiredRole.some(role => req.user.is(role));
    if (!hasPermission) {
        req.error(403, `You do not have the necessary permissions for this action with status ${status} and SBU ${sbu}.`);
        return false;
    }

    return true;
}

function formatUUIDWithHyphens(sUUID) {
    return sUUID.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, '$1-$2-$3-$4-$5');
}

function removeHyphensFromUUID(sUUID) {
    return sUUID.replace(/-/g, '');
}

async function createImageMasterDocument(oDocument, s3Response, oImageMasterService, oReqData) {

    try {

        const streamToBase64 = async (stream) => {
            const chunks = [];
            for await (const chunk of stream) {
                chunks.push(chunk);
            }
            const buffer = Buffer.concat(chunks);
            return buffer.toString('base64');
        };

        const base64Content = await streamToBase64(s3Response.Body);
        const sUUID = removeHyphensFromUUID(oDocument.ID);
        let oImageMasterDocument = {};

        const oBody = {
            "documentType": { "name": 'Sustainability_Tracking' },
            "revisions": [
                {
                    "attributes": [
                        {
                            "definition": {
                                "name": 'Sustainability_Tracking.ID'
                            },
                            "values": [sUUID]
                        }
                    ],
                    "contents": [
                        {
                            "key": sUUID,
                            "fileName": oDocument.fileName,
                            "data": { "base64": base64Content },
                            "mimeType": s3Response.ContentType
                        }
                    ]
                }
            ]
        };
        const sBody = JSON.stringify(oBody);

        oImageMasterDocument = await oImageMasterService.send({
            method: "POST",
            headers: {
                'Ima-Request-Id': `Sustainability_Tracking-{${sUUID}}`,
                "Content-Type": "application/json",
                "Accept": "application/json"
            },
            path: `/rest/core/documents`,
            data: sBody
        });

    } catch (e) {
        try {
            await setCommunicationErrorLog(oReqData?.ID, oReqData?.product, "imageMaster", sBody, error);
        } catch (e) {

        }
        req.error(409, "Error updating the ProofPoints of the assessment");
        console.log(JSON.stringify(e));
    }

}

async function updateImageMasterreference(oDocument) {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument'];

    let oSet = {};
    oSet.url = "ProductProofDocument(product='',proofPointId=" + oDocument.ID + ")/content";
    oSet.imageMasterID = removeHyphensFromUUID(oDocument.ID);
    oSet.objectStoreId = "";

    try {

        await cds.run(
            UPDATE(oProofDocuments)
                .set(oSet)
                .where({ ID: oDocument.ID })
        );

        oDocument.imageMasterID = oSet.imageMasterID;

    } catch (e) {
        req.error(409, "Error updating the ProofPoints of the assessment");
        console.log(JSON.stringify(e));
    }

    return oDocument;
}

async function refreshProductDocumentMapping(oDocument, oItem) {
    const oDb = await cds.connect.to('db'); // Connect to the database
    const oProductProofDocument = oDb.entities['management.ProductProofDocumentRelation'];
    //const sNormalizedProductReference = oDocument.productReference?.replace(/^0+/, '');
    const sNormalizedProduct = oItem.product;

    //const sFinalNormalizedProduct = sNormalizedProductReference || sNormalizedProduct;

    if (oDocument.productReference) {
        return;
    }

    try {

        const aProductDocument = await cds.run(SELECT.from(oProductProofDocument).where({ product: sNormalizedProduct, proofPointId: oDocument.imageMasterID }));

        if (aProductDocument.length === 1) {
            const oSet = {
                "type": oDocument.type,
                "description": oDocument.description,
                "active": oDocument.active
            }

            await cds.run(
                UPDATE(oProductProofDocument)
                    .set(oSet)
                    .where({ product: sNormalizedProduct, proofPointId: oDocument.imageMasterID })
            );

        } else {

            const oInsert = {
                "product": sNormalizedProduct,
                "productType": oItem.productType ?? "",
                "proofPointId": oDocument.imageMasterID,
                "filename": oDocument.fileName,
                "type": oDocument.type,
                "description": oDocument.description,
                "active": oDocument.active,
                "externalUrl": false
            }

            await cds.run(INSERT.into(oProductProofDocument).entries(oInsert));

        }

    } catch (error) {
        req.error(409, "Error updating the ProofPoints of the assessment");
    }
}

async function removeObjectStoreDocument(bucketName, s3, oDocument) {

    try {

        const objParamsDelete = {
            Bucket: bucketName,
            Key: oDocument.objectStoreId ? oDocument.objectStoreId : oDocument.ID
        };

        // Delete the document from S3
        await s3.send(new DeleteObjectCommand(objParamsDelete));

    } catch (oError) {
        console.error(oError);
    }
}

/**
 * Gets allowed SBU for the given request
 * 
 * @param {Object} req Request object
 * @returns {Array} array of Possible SBU values
 */
function getAllowedSbu(req) {
    const allowedSbu = ['ACM', 'AMC', 'AME', 'AMI', 'AMO', 'APC', 'APP', 'ACB', 'ACC'];
    return allowedSbu;
};

/**
 * Gets the required role for the request and status of the object to change
 * 
 * @param {Object} req Request object
 * @param {String} status Status of the assessment processed
 * @param {String} sbu SBU of the assessment processed
 * @returns {String} Role required to process the request
 */
function getRequiredRoles(req, status, sbu) {
    // Define required roles based on the `status`
    const requiredRole = {
        '91': [`${sbu}.Assessor`, `${sbu}.Submitter`],
        '01': [`${sbu}.Assessor`, `${sbu}.Submitter`],
        '02': [`${sbu}.Submitter`],
        '03': [`${sbu}.Approver`],
        '04': [`${sbu}.Submitter`],
        '05': [`${sbu}.Approver`],
        '06': [`${sbu}.Approver`],
        '91': [`${sbu}.Assessor`, `${sbu}.Submitter`],
    }[status];
    if (req.method === "DELETE") {
        delete requiredRole["02"];
        delete requiredRole["03"];
        delete requiredRole["04"];
        delete requiredRole["05"];
        delete requiredRole["06"];
    }

    return requiredRole;
};

/**
 * Gets the required data from entity to check 
 * 
 * @param {Object} req Request object
 * @param {Object} oAssessmentOld Assessment data in DB
 * @returns {Object} data required to perform the checks
 */
async function getAssesmentPermissionData(req, oAssessmentOld) {
    const oReturnData = {};

    if (req.data.sbu && req.data.status) {
        oReturnData.sbu = req.data.sbu;
        oReturnData.status = req.data.status;
    } else {
        const db = await cds.connect.to('db');
        const sEntity = req.entity;
        let sEntityName;
        if (sEntity === "SustainabilityManagement.SingleAssessment") {
            sEntityName = "management.SingleAssessment";
        } else if (sEntity === "SustainabilityManagement.MassAssessmentHeader") {
            sEntityName = "management.MassAssessmentHeader";
        } else if (sEntity === "SustainabilityManagement.MassAssessmentItems") {
            sEntityName = "management.MassAssessmentItems";
        } else {
            req.error(409, "Invalid entity to validate permissions");
            return;
        }
        const oAssessmentEntity = db.entities[sEntityName];

        const aSingleAsessment = oAssessmentOld ? [oAssessmentOld] : await SELECT.from(oAssessmentEntity).where({ ID: req.data.ID });
        if (aSingleAsessment && Array.isArray(aSingleAsessment)) {
            const oSingleAsessment = aSingleAsessment[0];
            oReturnData.sbu = req.data.sbu ? req.data.sbu : oSingleAsessment.sbu;
            oReturnData.status = req.data.status ? req.data.status : oSingleAsessment.status;
        }
    }

    return oReturnData;
};

/**
 * Permission and status related validations
 * @param {Object} req  Request object 
 * @returns true if valid, else false
 */
async function checkPermissionAndStatus(req) {
    const aAssessmentDB = req.data?.itemDB ? [req.data?.itemDB] : await getAssesmentDB(req);
    const bStatusTransitionAllowed = await checkStatusTransition(req, aAssessmentDB[0]);
    if (!bStatusTransitionAllowed) {
        try {
            await cds.spawn({}, async (tx) => {
                await setCommunicationErrorLog(aAssessmentDB[0]?.ID, aAssessmentDB[0]?.product, "assessment", req.data, req.errors);
            });
        } catch (e) {
            console.error(e);
        }
        return false;
    }

    const bUserHasPermissions = await validateAssementUserPermissions(req, aAssessmentDB[0]);
    if (!bUserHasPermissions) {
        try {
            await cds.spawn({}, async (tx) => {
                await setCommunicationErrorLog(aAssessmentDB[0]?.ID, aAssessmentDB[0]?.product, "assessment", req.data, req.errors);
            });
        } catch (e) {
            console.error(e);
        }
        return false;
    }

    const bCheckPoofPoints = await checkAssessmentProofPoints(req, aAssessmentDB[0]);
    if (!bCheckPoofPoints) {
        try {
            await cds.spawn({}, async (tx) => {
                await setCommunicationErrorLog(aAssessmentDB[0]?.ID, aAssessmentDB[0]?.product, "assessment", req.data, req.errors);
            });
        } catch (e) {
            console.error(e);
        }
        return false;
    }

    return true;
};

/**
 * Checks status related modifications
 * @param {Object} req  Request object 
 * @param {Object} oAssessmentOld   Object with assessment as is in database
 * @returns true if valid, else false
 */
async function checkStatusTransition(req, oAssessmentOld) {

    const SAVED = "01";
    const SUBMITTED = "02";
    const UNDER_RESUBMISSION = "03";
    const RESUBMITTED = "04";
    const APPROVED = "05";
    const REJECTED = "06";
    const DRAFT = "91";

    // Mapping of possible transitions
    const aAllowedTransitions = {
        POST: [
            { statusTo: [SAVED, SUBMITTED, DRAFT] }
        ],
        PATCH: [
            { statusFrom: DRAFT, statusTo: [SAVED, SUBMITTED] },
            { statusFrom: SAVED, statusTo: [SAVED, SUBMITTED] },
            { statusFrom: SUBMITTED, statusTo: [SUBMITTED, UNDER_RESUBMISSION, APPROVED, REJECTED] },
            { statusFrom: UNDER_RESUBMISSION, statusTo: [RESUBMITTED] },
            { statusFrom: RESUBMITTED, statusTo: [UNDER_RESUBMISSION, APPROVED, REJECTED] },
        ],
        DELETE: [
            { statusFrom: SAVED },
            { statusFrom: DRAFT }
        ]
    }[req.method];


    // Retrieve assessment data from DB
    const oAssessmentDB = oAssessmentOld || (await getAssesmentDB(req))[0];

    const sStatusTo = req?.data?.status;
    const sStatusFrom = oAssessmentDB?.status;

    if (req.method === "POST") {

        // If assessment from background process such as PDP or MOC, dont allow adding products
        const sEntity = getDbEntityFromReq(req);
        if (
            sEntity === "management.MassAssessmentItems"
        ) {

            const { processType } = await getMassAssessmentHeaderById( oAssessmentDB.headerId );
            const FORBIDDEN_PROCESS_TYPES = ["PDP", "MOC"];
            if (FORBIDDEN_PROCESS_TYPES.includes(processType)) {
                req.error(403, `Assessment deletion for ${processType} assessment not allowed`);
                return false;
            }

        }

        // Status check for creation
        const bAllowed = aAllowedTransitions[0].statusTo.some(item => item === sStatusTo);
        if (!bAllowed) {
            req.error(403, `Assessment creation with status ${sStatusTo} not allowed`);
            return false;
        }

        // If toItems is present in creation (for assessmente header), check item status
        if (req.data.toItems) {
            for (const oItem of req.data.toItems) {
                const bAllowed = aAllowedTransitions[0].statusTo.some(item => item === oItem.status);
                if (!bAllowed) {
                    req.error(403, `Assessment creation with status ${oItem.status} not allowed`);
                    return false;
                }
            }
        }

    } else if (req.method === "PATCH") {

        // Check status transition
        if (sStatusTo) {
            const oAllowedTransitions = aAllowedTransitions.find(item => item.statusFrom === sStatusFrom);
            if (!oAllowedTransitions) {
                req.error(403, `No transition allowed for the current DB status: ${sStatusFrom}`);
                return false;
            }
            const bAllowedTransition = oAllowedTransitions.statusTo.some(item => item === sStatusTo);
            if (!bAllowedTransition) {
                req.error(403, `Assessment transition from status ${sStatusFrom} to ${sStatusTo} not allowed`);
                return false;
            }
        }

        // Status for special validations
        const STATUS_FOR_SUBMITTER = [RESUBMITTED];
        const STATUS_FOR_APPROVER = [UNDER_RESUBMISSION, APPROVED, REJECTED];
        const STATUS_FOR_ASSESSOR = [DRAFT];

        // If an status belongs to an assessor, check that it is the same that existed
        if (STATUS_FOR_ASSESSOR.some(item => item === oAssessmentDB.status) && req.user.id !== oAssessmentDB.assessor) {
            req.error(403, `Only the user that is an assessor can modify this assessments in this status`);
            return false;
        }

        // If an status belongs to a submitter, check that it is the same that existed
        if (STATUS_FOR_SUBMITTER.some(item => item === req.data.status) && (req.user.id !== oAssessmentDB.submitter && oAssessmentDB.submitter )) {
            req.error(403, `Only the user that submitted can resubmit`);
            return false;
        }

        // If the action is for an approver 
        if (oAssessmentDB.approver && STATUS_FOR_APPROVER.some(item => item === req.data.status) && req.user.id !== oAssessmentDB.approver) {
            req.error(403, `Only the user that first approved can change the status`);
            return false;
        }

    } else if (req.method === "DELETE") {

        // If assessment from background process such as PDP or MOC, dont delete
        const sEntity = getDbEntityFromReq(req);
        if (
          sEntity === "management.MassAssessmentHeader" ||
          sEntity === "management.MassAssessmentItems"
        ) {
            
            const sProcessType = sEntity === "management.MassAssessmentHeader"
                ? oAssessmentDB.processType
                : ( await getMassAssessmentHeaderById( oAssessmentDB.headerId ) ).processType;
            const FORBIDDEN_PROCESS_TYPES = ["PDP", "MOC"];
            if (FORBIDDEN_PROCESS_TYPES.includes(sProcessType)) {
                req.error(403, `Assessment deletion for ${sProcessType} assessment not allowed`);
                return false;
            }

        }

        // Status check for deletion
        const bAllowed = aAllowedTransitions.some(item => item.statusFrom === sStatusFrom);
        if (!bAllowed) {
            req.error(403, `Assessment deletion with status ${sStatusFrom} not allowed`);
            return false;

        }

    }

    return true;

}

/**
 * Checks if user has required pèrmissions to perform request operation over asessment
 * 
 * @param {Objet} req Request object
 */
async function validateAssementUserPermissions(req, oAssessmentOld) {

    const aAllowedSbu = getAllowedSbu(req);
    const { sbu, status } = await getAssesmentPermissionData(req, oAssessmentOld);
    const aRequiredRole = getRequiredRoles(req, status, sbu);

    // Validate that `sbu` is within the allowed list
    if (!aAllowedSbu.includes(sbu)) {
        req.error(400, `The SBU ${sbu} is not valid.`);
        return false;
    }

    // If no roles are defined for this status, return an error
    if (!aRequiredRole || aRequiredRole.length === 0) {
        req.error(400, `Invalid status ${status} provided.`);
        return false;
    }

    // Check if the user has any of the required roles
    const bHasPermission = aRequiredRole.some(role => req.user.is(role));
    if (!bHasPermission) {
        req.error(403, `You do not have the necessary permissions for this action with status ${status} and SBU ${sbu}.`);
        return false;
    }

    return true;

};

async function checkAssessmentProofPoints(req, oAssessment) {

    if (req.data.status === "05") {
        const SUST_CLASS_MANDATORY = ["O4", "O5"];
        const bCheckMandatory = SUST_CLASS_MANDATORY.some(item => item === oAssessment.sustClass);
        if (bCheckMandatory) {
            let aProductProofDocuments;

            if (req.data?.productProofDocumentsDB) {
                aProductProofDocuments = req.data?.productProofDocumentsDB;
            } else {
                const db = await cds.connect.to('db');
                const ProductProofDocumentRelation = db.entities["management.ProductProofDocumentRelation"];

                aProductProofDocuments = await SELECT.from(ProductProofDocumentRelation).where({ product: oAssessment.product })
            };
            if (!aProductProofDocuments || aProductProofDocuments.length === 0) {
                req.error(409, `Mandatory proof points missing for product ${oAssessment.product}`);
                return false;
            }

        }
    }
    return true;

};

/**
 * Check products already in assessment
 * @param {Array} aProducts products to check
 * @returns {Array} Products already in assessment
 */
async function checkProductsInAssessment(aProducts) {

    const db = await cds.connect.to('db');
    const AssessmentProducts = db.entities["management.AssessmentProducts"];

    if (!aProducts || aProducts.length === 0) {
        return [];  // If no products are sent, there is nothing to check.
    }

    const ITEMS_PER_BATCH = 1000;
    const aBatches = divideArrayInBatches(aProducts, ITEMS_PER_BATCH);

    // Query for SingleAssessment
    const aAssessmentProducts = [];
    for (const batch of aBatches) {
        const aAssessmentProductsBatch = await SELECT.from(AssessmentProducts)
        .where({
            product: { in: batch },
            and: { status: { 'not in': ['05', '06'] }, or: { communicationStatus: { 'not in': ['05', ''] } } }
        })
        .columns('product');
        aAssessmentProducts.push(...aAssessmentProductsBatch);
    }
    return aAssessmentProducts;

};

/**
 * Check products already in assessment for PDP, MOC and Heart
 * @param {Array} aProducts products to check
 * @returns {Array} Products already in assessment
 */
async function checkProductsInAssessmentforPdpMocHeart(aProducts) {

    const db = await cds.connect.to('db');
    const AssessmentProducts = db.entities["management.AssessmentProducts"];

    if (!aProducts || aProducts.length === 0) {
        return [];  // If no products are sent, there is nothing to check.
    }

    const ITEMS_PER_BATCH = 1000;
    const aBatches = divideArrayInBatches(aProducts, ITEMS_PER_BATCH);

    // Query for SingleAssessment
    const aAssessmentProducts = [];
    for (const batch of aBatches) {
        const aAssessmentProductsBatch = await SELECT.from(AssessmentProducts)
            .where({
                product: { in: batch },
                and: { status: { 'not in': ['05', '06'] }, or: { communicationStatus: { 'not in': ['05', ''] } } }
            });
        aAssessmentProducts.push(...aAssessmentProductsBatch);
    }
    return aAssessmentProducts;

};


/*function mapIdhWhereFilters(aWhere) {
    const aMappedWhere = aWhere.map(filter => {
        if (typeof filter === 'object' && filter.ref) {
            // Map frontend fields to database fields
            switch (filter.ref[0]) {
                case 'materialtNumber':
                    return { ref: ['IDH_MATERIAL_NR'] };
                case 'materialDescription':
                    return { ref: ['PRODUCT_NAME_MAT_DSC'] };
                case 'sbu':
                    return { ref: ['LEADINGSBUCODE'] };
                case 'sustClass':
                    return { ref: ['SUSTAINABILITY_CLASS_KEY'] };
                case 'category':
                    return { ref: ['PRIMARY_SUSTAINABILITY_CATEG'] };
                case 'category2':
                    return { ref: ['SEC_SUSTAINABILITY_CATEG_A_KEY'] };
                case 'category3':
                    return { ref: ['SEC_SUSTAINABILITY_CATEG_B_KEY'] };
                case 'contributor':
                    return { ref: ['PRIMARY_CONTRIBUTOR_KEY'] };
                case 'contributor2':
                    return { ref: ['SECONDARY_CONTRIBUTOR_A_KEY'] };
                case 'contributor3':
                    return { ref: ['SECONDARY_CONTRIBUTOR_B_KEY'] };
                case 'assesor':
                    return { ref: ['ASSESOR'] };
                case 'approver':
                    return { ref: ['APPROVER'] };
                case 'technologyL2':
                    return { ref: ['TECHNOLOGY_LEVEL2_KEY'] };
                case 'applicationL2':
                    return { ref: ['APPLICATION_LEVEL_KEY'] };
                case 'rcPreFlag':
                    return { ref: ['RC_SUSTAINABILITYCLASSKEY'] };
                case 'approvalDate':
                    return {
                        ref: ['ASSESSED_ON'],
                        // Convert the date format from YYYY-MM-DD to AAAAMMDD
                        value: oDbItem.ASSESSED_ON ? oDbItem.ASSESSED_ON.toISOString().slice(0, 10).replace(/-/g, '') : null
                    };
                default:
                    return filter; // Pass through other filters unchanged
            }
        }
        return filter; // Non-object filters (e.g., values, operators) are passed unchanged
    });

    return aMappedWhere;
};*/

/*function mapIdhDatasPhereToIdhServiceEntity(aIdhListDb) {
    // Map database results to the Idh entity
    const oIdhList = aIdhListDb.map(oDbItem => ({
        materialtNumber: oDbItem.IDH_MATERIAL_NR,
        materialDescription: oDbItem.PRODUCT_NAME_MAT_DSC,
        sbu: oDbItem.LEADINGSBUCODE,
        sbuDescription: null, // No corresponding field in the database table
        sustClass: oDbItem.SUSTAINABILITY_CLASS_KEY,
        sustClassDescription: oDbItem.SUSTAINABILITY_CLASS_DESC,
        category: oDbItem.PRIMARY_SUSTAINABILITY_CATEG,
        categoryDescription: oDbItem.PRIMARY_SUSTAINABIL_CATEG_DESC,
        category2: oDbItem.SEC_SUSTAINABILITY_CATEG_A_KEY,
        category2Description: oDbItem.SEC_SUSTAINABILITY_CATG_A_DESC,
        category3: oDbItem.SEC_SUSTAINABILITY_CATEG_B_KEY,
        category3Description: oDbItem.SEC_SUSTAINABILITY_CATG_B_DESC,
        contributor: oDbItem.PRIMARY_CONTRIBUTOR_KEY,
        contributorDescription: oDbItem.PRIMARY_CONTRIBUTOR_DESC,
        contributor2: oDbItem.SECONDARY_CONTRIBUTOR_A_KEY,
        contributor2Description: oDbItem.SECONDARY_CONTRIBUTOR_A_DESC,
        contributor3: oDbItem.SECONDARY_CONTRIBUTOR_B_KEY,
        contributor3Description: oDbItem.SECONDARY_CONTRIBUTOR_B_DESC,
        assesor: oDbItem.ASSESOR,
        approver: oDbItem.APPROVER,
        technologyL2: oDbItem.TECHNOLOGY_LEVEL2_KEY,
        technologyL2Description: oDbItem.TECHNOLOGY_LEVEL2_DESC,
        rcPreFlag: oDbItem.RC_SUSTAINABILITYCLASSKEY,
        rcPreFlagDescription: RC_SUSTAINABILITYFLAG,
        applicationL2: oDbItem.APPLICATION_LEVEL_KEY,
        applicationL2Description: oDbItem.APPLICATION_LEVEL2_DESC,
        approvalDate: oDbItem.ASSESSED_ON ? new Date(oDbItem.ASSESSED_ON) : null
    }));

    return oIdhList;
};*/

function getIdhMapping() {
    const IDH_VT_MAPPING = [
        { from: "IDH_MATERIAL_NR", to: "materialtNumber" },
        { from: "PRODUCT_NAME_MAT_DSC", to: "materialDescription" },
        { from: "LEADINGSBUCODE", to: "sbu" },
        { from: "SUSTAINABILITY_CLASS_KEY", to: "sustClass" },
        { from: "SUSTAINABILITY_CLASS_DESC", to: "sustClassDescription" },
        { from: "PRIMARY_SUSTAINABILITY_CATEG", to: "category" },
        { from: "PRIMARY_SUSTAINABIL_CATEG_DESC", to: "categoryDescription" },
        { from: "SEC_SUSTAINABILITY_CATEG_A_KEY", to: "category2" },
        { from: "SEC_SUSTAINABILITY_CATG_A_DESC", to: "category2Description" },
        { from: "SEC_SUSTAINABILITY_CATEG_B_KEY", to: "category3" },
        { from: "SEC_SUSTAINABILITY_CATG_B_DESC", to: "category3Description" },
        { from: "PRIMARY_CONTRIBUTOR_KEY", to: "contributor" },
        { from: "PRIMARY_CONTRIBUTOR_DESC", to: "contributorDescription" },
        { from: "SECONDARY_CONTRIBUTOR_A_KEY", to: "contributor2" },
        { from: "SECONDARY_CONTRIBUTOR_A_DESC", to: "contributor2Description" },
        { from: "SECONDARY_CONTRIBUTOR_B_KEY", to: "contributor3" },
        { from: "SECONDARY_CONTRIBUTOR_B_DESC", to: "contributor3Description" },
        { from: "SUSTAINBILITY_MAINTMANUAL_DESC", to: "" },
        { from: "ASSESOR", to: "assesor" },
        { from: "APPROVER", to: "approver" },
        { from: "TECHNOLOGY_LEVEL2_KEY", to: "technologyL2" },
        { from: "TECHNOLOGY_LEVEL2_DESC", to: "technologyL2Description" },
        { from: "RC_SUSTAINABILITYCLASSKEY", to: "rcPreFlag" },
        { from: "RC_SUSTAINABILITYFLAG", to: "rcPreFlagDescription" },
        { from: "APPLICATION_LEVEL_KEY", to: "applicationL2" },
        { from: "APPLICATION_LEVEL2_DESC", to: "applicationL2Description" },
        { from: "ASSESSED_ON", to: "approvalDate" }
    ];

    return IDH_VT_MAPPING;
}

function getIbMapping() {
    const IB_VT_MAPPING = [
        { from: "IB_PRODUCT_NUMBER", to: "materialtNumber", },
        { from: "PRODUCT_NAME", to: "materialDescription", },
        { from: "ASSESOR", to: "assesor", },
        { from: "APPROVER", to: "approver", },
        { from: "LAST_ASSESTMENTAPPROVAL_DATE", to: "approvalDate", },
        { from: "TECHNOLOGY_LEVEL_2", to: "technologyL2", },
        { from: "TECHNOLOGY_LEVEL_2_DESC", to: "technologyL2Description", },
        { from: "APPLICATION_LEVEL2_KEY", to: "applicationL2", },
        { from: "APPLICATION_LEVEL2_DSC", to: "applicationL2Description", },
        { from: "SUST_CLASS_KEY", to: "sustClass", },
        { from: "SUST_CLASS_DESC", to: "sustClassDescription", },
        { from: "PRIM_SUSTAINABILITY_CATEG_KEY", to: "category", },
        { from: "PRIM_SUSTAINABILITY_CATEG_DESC", to: "categoryDescription", },
        { from: "SEC_SUSTAINABILITY_CAT_A_KEY", to: "category2", },
        { from: "SEC_SUSTAINABILITY_CAT_A_DESC", to: "category2Description", },
        { from: "SEC_SUSTAINABILITY_CAT_B_KEY", to: "category3", },
        { from: "SEC_SUSTAINABILITY_CAT_B_DESC", to: "category3Description", },
        { from: "PRIMARY_CONTRIBUTOR_KEY", to: "contributor", },
        { from: "PRIMARY_CONTRIBUTOR_DESC", to: "contributorDescription", },
        { from: "SECONDARY_CONTRIBUTOR_A_KEY", to: "contributor2", },
        { from: "SECONDARY_CONTRIBUTOR_A_DESC", to: "contributor2Description", },
        { from: "SECONDARY_CONTRIBUTOR_B_KEY", to: "contributor3", },
        { from: "SECONDARY_CONTRIBUTOR_B_DESC", to: "contributor3Description", },
        { from: "LEADING_SBU_CODE_DESC", to: "sbu", },
        { from: "RC_SUSTAINABILITYFLAG", to: "rcPreFlagDescription", },
        { from: "RC_SUSTAINABILITYCLASSKEY", to: "rcPreFlag", },
    ];

    return IB_VT_MAPPING;
}

/**
 * IB mapping to hana database table for productData
 * @returns Array of mappings
 */
function getIbVtToProductDataMapping() {
    return [
        { from: "IB_PRODUCT_NUMBER", to: "product" },
        { from: "PRODUCT_NAME", to: "productName" },
        { from: "ASSESOR", to: "lastSubmitter" },
        { from: "APPROVER", to: "lastApprover" },
        { from: "LAST_ASSESTMENTAPPROVAL_DATE", to: "lastAssessment", date: true },
        { from: "SUST_CLASS_KEY", to: "sustainabilityClassCode" },
        { from: "SUSTAINABILITY_CLASS_DESC", to: "existingSustainabilityClass" },
        { from: "TECHNOLOGY_LEVEL_2", to: "technologyL2Key" },
        { from: "TECHNOLOGY_LEVEL_2_DESC", to: "technologyLevel2" },
        { from: "APPLICATION_LEVEL2_KEY", to: "applicationLevel2Key" },
        { from: "APPLICATION_LEVEL2_DSC", to: "applicationLevel2" },
        { from: "LEADING_SBU_CODE_DESC", to: "sbu" },
        { from: "RC_SUSTAINABILITYFLAG", to: "rcPreFlagDescription" },
        { from: "RC_SUSTAINABILITYCLASSKEY", to: "rcPreFlag" },
        { from: "REAL_SUBSTANCE_NUMBER", to: "realSubstanceCode" },
        { from: "RSN_REAL_SUBSTANCE_NUMBER", to: "realSubstanceName" },
        //{ from: "RSN_REAL_SUBSTANCE_NUMBER", to: "region" },
    ];
};

/**
 * IDH mapping to hana database table for productData
 * @returns Array of mappings
 */
function getIdhVtToProductDataMapping() {
    return [
        { from: "IDH_MATERIAL_NR", to: "product" },
        { from: "PRODUCT_NAME_MAT_DSC", to: "productName" },
        { from: "ASSESOR", to: "lastSubmitter" },
        { from: "APPROVER", to: "lastApprover" },
        { from: "ASSESSED_ON", to: "lastAssessment", date: true },
        { from: "SUSTAINABILITY_CLASS_KEY", to: "sustainabilityClassCode" },
        { from: "SUST_CLASS_DESC", to: "existingSustainabilityClass" },
        { from: "TECHNOLOGY_LEVEL2_KEY", to: "technologyL2Key" },
        { from: "TECHNOLOGY_LEVEL2_DESC", to: "technologyLevel2" },
        { from: "APPLICATION_LEVEL2", to: "applicationLevel2Key" },
        { from: "APPLICATION_LEVEL2_DESC", to: "applicationLevel2" },
        { from: "LEADINGSBUCODE", to: "sbu" },
        { from: "RC_SUSTAINABILITYFLAG", to: "rcPreFlagDescription" },
        { from: "RC_SUSTAINABILITYCLASSKEY", to: "rcPreFlag" },
        { from: "RSN_REAL_SUBSTANCE_NUMBER", to: "realSubstanceCode" },
        { from: "RSN_REAL_SUBSTANCE_NUMBER", to: "realSubstanceName" },
        //{ from: "RSN_REAL_SUBSTANCE_NUMBER", to: "region" },
    ];
};

/**
 * Get mapping to hana database table for productData depending on type
 * @param {String} Type of product
 * @returns Array of mappings
 */
function getVtToProductDataMapping(sType) {
    if (sType === TYPE_IB) {
        return getIbVtToProductDataMapping();
    } else if (sType === TYPE_IDH) {
        return getIdhVtToProductDataMapping();
    }
}

/**
 * Translates filter query for selection of product data
 * @param {*} req 
 * @returns 
 */
/*function translateVtSelectQueryWhere(req) {

    const oWhere = {};

    // If key data is provided, translate and create where form it
    if (req.data && req.data.type) {

        const sType = req.data.type;
        oWhere[sType] = {};

        const aMapping = getVtToProductDataMapping( sType );
        const oData = oWhere[sType];

        for (const sKey in req.data) {
            const oMap = aMapping.find(item => item.to === sKey);
            if (oMap && oMap.from !== "") {
                oData[oMap.from] = req.data[sKey];
                if (oMap.date) {
                    // oMappedItem[oMap.to] = convertAbapToJSDate(oMappedItem[oMap.to]);
                }
            }
        }
        return oWhere;

    }

// If filter data is provided, translate and create where from it for every product kind
if ( req.query.SELECT && req.query.SELECT.where) {

    const aTypes = [TYPE_IB, TYPE_IDH];
    const iIndexOfType = req.query.SELECT.where.findIndex(item => {
        return item.ref && item.ref[0] && item.ref[0] === "type";
    });
    if (iIndexOfType >= 0) {
        req.query.SELECT.where.splice(iIndexOfType, 3);
        if (req.query.SELECT.where.length > iIndexOfType && 
            (req.query.SELECT.where[iIndexOfType] === "and" || req.query.SELECT.where[iIndexOfType] === "or")) {
            req.query.SELECT.where.splice(iIndexOfType, 1);
        }
        if (req.query.SELECT.where.length >= iIndexOfType && 
            (req.query.SELECT.where[req.query.SELECT.where.length - 1] === "and" || req.query.SELECT.where[req.query.SELECT.where.length - 1] === "or")) {
            req.query.SELECT.where.splice(req.query.SELECT.where.length - 1, 1);
        }            
    }

    const sOriginalWhere = JSON.stringify(req.query.SELECT.where);
    for (const sType of aTypes) {
        const aIbMapping = getVtToProductDataMapping(sType);
        const sReplacedWhere = aIbMapping.reduce((acc, curr) => {
            return acc.replaceAll(`"${curr.to}"`, `"${curr.from}"`);
        }, sOriginalWhere);

        oWhere[sType] = JSON.parse(sReplacedWhere);
    }
    return oWhere;

}

};*/

function translateVtResultsToProductData(aVtResults) {
    const aMapping = [
        ...getVtToProductDataMapping(TYPE_IB),
        ...getVtToProductDataMapping(TYPE_IDH)
    ];

    const aResults = aVtResults.map(item => {
        const oMappedItem = {};
        for (const sKey in item) {
            const oMapping = aMapping.find(item => item.from === sKey);
            if (oMapping && oMapping.to) {
                oMappedItem[oMapping.to] = item[sKey];
                if (oMapping.date) {
                    oMappedItem[oMapping.to] = convertAbapToJSDate(oMappedItem[oMapping.to]);
                }
            }
        }
        oMappedItem.region = "";
        //oMappedItem.realSubstanceName = "";
        return oMappedItem;
    });
    return aResults;
};

/**
 * Sets the modifications log for the assessments
 * 
 * @param {Object} req Request object 
 * @returns 
 */
async function setAssessmentLog(req) {

    const db = await cds.connect.to('db');
    const aRows = [];
    const EXCLUDED_FIELDS = ["ID"]; // Fields not saved in log

    // Obtain corresponding entity in DB
    const sEntity = req.entity;
    let sEntityName;
    if (sEntity === "SustainabilityManagement.SingleAssessment") {
        sEntityName = "management.SingleAssessment";
    } else if (sEntity === "SustainabilityManagement.MassAssessmentHeader") {
        sEntityName = "management.MassAssessmentHeader";
    } else if (sEntity === "SustainabilityManagement.MassAssessmentItems") {
        sEntityName = "management.MassAssessmentItems";
    } else {
        req.error(409, "Invalid entity to log");
        return;
    }
    const oAssessmentEntity = db.entities[sEntityName];

    const sEvent = req.event;
    const oDate = new Date();
    const sUser = req.user.id;

    // In update, obtain old modified fields values and store new ones. In other cases just store the operation
    if (sEvent === "UPDATE") {
        const oOldValues = await SELECT.one.from(oAssessmentEntity).where({ ID: req.data.ID });
        for (const sKey in req.data) {
            if (!EXCLUDED_FIELDS.some(item => item === sKey) && oOldValues[sKey] !== req.data[sKey]) {
                let sOldValue = oOldValues[sKey] ? oOldValues[sKey] : "";
                let sNewValue = req.data[sKey] ? req.data[sKey] : "";
                if (typeof sOldValue === "boolean") {
                    if (sOldValue) sOldValue = "true";
                    else sOldValue = "false";
                }

                if (typeof sNewValue === "boolean") {
                    if (sNewValue) sNewValue = "true";
                    else sNewValue = "false";
                }

                aRows.push({
                    assessmentID: req.data.ID,
                    entity: sEntityName,
                    createdAt: oDate,
                    createdBy: sUser,
                    operation: sEvent,
                    operation: sEvent,
                    fieldName: sKey,
                    oldValue: sOldValue,
                    newValue: sNewValue,
                });
            }
        }
    } else {
        aRows.push({
            assessmentID: req.data.ID,
            entity: sEntityName,
            createdAt: oDate,
            createdBy: sUser,
            operation: sEvent,
            fieldName: "",
        });
    }

    const oLogEntity = db.entities["management.AssessmentChangeLog"];
    // console.log({aRows, data: req.data});
    if (aRows.length > 0) {
        try {
            await INSERT(aRows).into(oLogEntity);
        } catch (e) {
            console.error({ e, data: aRows });
        }
    }


};

async function updateOnPremiseAssessmentProduct(oReqData, aProofDocuments) {
    const sType = oReqData.productType;
    if (sType != TYPE_IB && sType != TYPE_IDH) {
        return;
    }

    const oConfig = _getTypeClassUpdConfig(sType);
    if (!oConfig) {
        return;
    }
    const pstOnpremise = await cds.connect.to("pst-onpremise");

    // // If proof documents provided, pick the latest 3. If not, recover them first
    // let aDocuments = [...aProofDocuments];

    // const aNewDocuments = aProofDocuments.filter(item => !item.imageMasterID);
    // if ( aNewDocuments.length >= 3 ) {
    //     aDocuments = aNewDocuments;
    // }

    // const compare = (a, b) => {
    //     if (a.modifiedAt < b.modifiedAt) {
    //         return 1;
    //     } else {
    //         return -1;
    //     }
    // };
    // const aSortDocuments = aDocuments?.sort(compare);
    const aTypes = await getOnpremiseProofTypes(oReqData, aProofDocuments.filter(document => document.active));

    const oSendData = {};
    for (const oMap of oConfig.mapping) {

        oSendData[oMap.to] = oReqData[oMap.from] || "";
        if (oMap.proofDocument && aTypes && aTypes?.length > 0) {
            const sType = aTypes.splice(0, 1)[0];
            if (sType) oSendData[oMap.to] = sType;
        }
    }
    try {
        if (sType === TYPE_IB) {
            oConfig.path += `('${oReqData.product}')`;
        } else {
            oConfig.path += `('${oReqData.product}')`;
            if (oSendData.YidhAipSustMaintManual) {
                oSendData.YidhAipSustMaintManual = "YES";
            } else {
                oSendData.YidhAipSustMaintManual = "NO";
            }
        }

        oConfig.path += (oConfig.path.includes('?') ? '&' : '?') + 'sap-client=010';

        const response = await pstOnpremise.send({
            method: oConfig.method,
            path: oConfig.path,
            headers: {
                "Content-Type": "application/json"
            },
            data: oSendData
        });
        console.log("P03Data ", JSON.stringify(oSendData));
    } catch (error) {
        console.error("Error updating onpremise system");
        console.error(error);
        await setCommunicationErrorLog(oReqData?.ID, oReqData?.product, "onPremise", oSendData, error);
        throw new Error(409, "An error occurred sending assessment data to the on-premise system");

    }

};

async function getOnpremiseProofTypes(oReqData, aProofDocuments) {

    const TYPE_OTHER = "03";
    // const OTHER_SUST_CLASS = ["04", "05"];
    // const bSUstClassOther = OTHER_SUST_CLASS.some(item => item === oReqData?.sustClass);
    // if (!bSUstClassOther) return [];    

    if (!aProofDocuments || aProofDocuments.length === 0) return [];

    // If proof documents provided, pick the latest 3. If not, recover them first
    let aDocuments = [...aProofDocuments];

    const aNewDocuments = aProofDocuments.filter(item => !item.imageMasterID);
    if (aNewDocuments.length >= 3) {
        aDocuments = aNewDocuments;
    }

    // Aux comparison function
    const compare = (a, b) => {
        if (a.modifiedAt < b.modifiedAt) {
            return 1;
        } else {
            return -1;
        }
    };
    const aSortDocuments = aDocuments?.sort(compare);
    const aTypes = aSortDocuments.splice(0, 3).map(item => item.type);

    // For certain sustainability classes, alway return other type
    // const bSUstClassOther = OTHER_SUST_CLASS.some(item => item === oReqData?.sustClass);
    // if (bSUstClassOther) return aTypes.map(item => TYPE_OTHER);

    // Else, map according to db parametrization 
    const db = await cds.connect.to('db');
    const oProofTypes = db.entities["management.ProofType"];
    const aProofTypes = await SELECT.from(oProofTypes).where({ code: aTypes });
    const aReturn = aTypes.map(originalTypes => {
        const sType = aProofTypes?.find(proofTypes => proofTypes?.code === originalTypes)?.onPremiseCode;
        return sType || TYPE_OTHER;
    })
    return aReturn;

};

function _getTypeClassUpdConfig(sType) {
    aConfigs = [
        {
            type: TYPE_IDH,
            method: "PUT",
            path: "ymxidh_pe/default/sap/ymxidh_mat/0001/clas_upd",
            mapping: [
                { from: "product", to: "Material" },
                { from: "contributor1", to: "YidhAipPrimContr" },
                { from: "category1", to: "YidhAipPrimSustCat" },
                { from: "contributor2", to: "YidhAipSecContA" },
                { from: "contributor3", to: "YidhAipSecContB" },
                { from: "category2", to: "YidhAipSecSustCata" },
                { from: "category3", to: "YidhAipSecSustCatb" },
                { from: "sustClass", to: "YidhAipSustainClass" },
                { from: "propagation", to: "YidhAipSustMaintManual" },
                { from: "", to: "YidhAipPrimProof", proofDocument: true },
                { from: "", to: "YidhAipSecProofA", proofDocument: true },
                { from: "", to: "YidhAipSecProofB", proofDocument: true },
            ]
        },
        {
            type: TYPE_IB,
            method: "PATCH",
            path: "ymxidh_pe/default/sap/ymxidh_aip/0001/prd",
            mapping: [
                { from: "product", to: "ProdNbr" },
                { from: "sustClass", to: "YmmidhAipSustainClass" },
                { from: "category1", to: "YmmidhAipPriSustainCat" },
                { from: "category2", to: "YmmidhAipSecSustCatA" },
                { from: "category3", to: "YmmidhAipSecSustCatB" },
                { from: "contributor1", to: "YmmidhAipPrimContributor" },
                { from: "contributor2", to: "YmmidhAipSecContriA" },
                { from: "contributor3", to: "YmmidhAipSecContriB" },
                { from: "", to: "YmmidhAipPrimProofPt", proofDocument: true },
                { from: "", to: "YmmidhAipSecPrfPointA", proofDocument: true },
                { from: "", to: "YmmidhAipSecPrfPointB", proofDocument: true },
            ]
        }
    ];

    return aConfigs.find(item => item.type === sType);
};

function convertAbapToJSDate(sDate) {
    if (sDate && sDate !== "00000000") {
        const sYear = sDate.substring(0, 4);
        const iMonth = parseInt(sDate.substring(4, 6)) - 1;
        const sDay = sDate.substring(6);

        const oNewDate = (new Date(sYear, iMonth, sDay)).toISOString().substring(0, 10);
        return oNewDate;
    } else {
        return null;
    }
};

async function getProductApproverAssessor(sProduct) {

    const oDb = await cds.connect.to('db');
    const oSingleAsessment = oDb.entities["management.SingleAssessment"];
    const oMassAssessmentItems = oDb.entities["management.MassAssessmentItems"];

    const aAssessments = [
        ...await SELECT.from(oSingleAsessment).where({ product: sProduct, status: "05" }).columns("assessor", "approver", "approvalDate", "createdAt"),
        ...await SELECT.from(oMassAssessmentItems).where({ product: sProduct, status: "05" }).columns("assessor", "approver", "approvalDate", "createdAt"),
    ];

    const oLatestEntry = aAssessments.reduce((acc, curr) => {
        if (!acc.approvalDate) return curr;
        if (
            acc.approvalDate &&
            curr.approvalDate &&
            acc.approvalDate <= curr.approvalDate &&
            acc.createdAt < curr.createdAt
        ) {
            return curr;
        }
        return acc;
    }, {});
    return oLatestEntry;
};

function getDbEntityFromReq(req) {
    const sEntity = req.entity;
    if (sEntity === "SustainabilityManagement.SingleAssessment") {
        return "management.SingleAssessment";
    } else if (sEntity === "SustainabilityManagement.MassAssessmentHeader") {
        return "management.MassAssessmentHeader";
    } else if (sEntity === "SustainabilityManagement.MassAssessmentItems") {
        return "management.MassAssessmentItems";
    } else {
        req.error(409, "Invalid entity to validate permissions");
        return;
    }
};

async function getAssesmentDB(req) {

    const oReqData = req.data;
    const sEntity = getDbEntityFromReq(req);

    const oDb = await cds.connect.to('db');
    const oEntity = oDb.entities[sEntity];

    const oAssessment = await SELECT.from(oEntity).where({ ID: oReqData.ID });
    return oAssessment;

};

async function updateMassAssessmentItemsBatch(req, bucketName, s3) {

    const newInfrastructureLogicEnabled = true;

    console.time("full time");
    let aPromises = [];
    const aErrorRequest = [];
    const aSuccessRequest = [];

    // Batch items in packages for performance and avoiding bottlenecks. 
    const PROMISES_PER_BATCH = 200;
    const aBatchedItems = divideArrayInBatches(req.data.items, PROMISES_PER_BATCH);

    // For each batch, database data is recovered and then requests are created to execute approval process
    // for every item. Data is then processed depending on the result
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const ProductProofDocumentRelation = oDb.entities["management.ProductProofDocumentRelation"];
    let counter = 0;
    for (const batch of aBatchedItems) {
        const aIDs = batch.map(item => item.ID);
        const aItemsDB = await SELECT.from(oMassAssessmentItems).where({ ID: aIDs });

        console.time(`Update promises ${counter}`);
        const aProducts = batch.map(item => item.product);
        const aProductProofDocumentsDB = await SELECT.from(ProductProofDocumentRelation).where({ product: aProducts })

        // Approval process
        const aPromises = batch.map(item => {

            const oItemDB = aItemsDB.find(itemDB => itemDB.ID === item.ID);
            const oUpdateReq = new cds.Request({
                method: 'PATCH', // HTTP method
                data: {
                    ...item,
                    itemDB: oItemDB,
                    productProofDocumentsDB: aProductProofDocumentsDB.filter(document => document.product === item.product)
                }, // Payload data
                user: req.user, // User information
                headers: req.headers, // HTTP headers
                entity: "SustainabilityManagement.MassAssessmentItems"
            });

            return fullMassAssessmentItemUpdate(oUpdateReq, bucketName, s3, newInfrastructureLogicEnabled);

        });

        // Result processing
        const aSettledPromises = await Promise.allSettled(aPromises);
        for (const oSettledPromises of aSettledPromises) {
            const oRequest = oSettledPromises.value;
            if (oRequest?.errors) {
                aErrorRequest.push({ errors: oRequest.errors });
            } else if (oRequest?.reason || oSettledPromises?.reason) {
                const code = oRequest?.code || oSettledPromises?.reason.code;
                const message = oRequest?.message || oSettledPromises?.reason.message;
                aErrorRequest.push({ errors: [{ code: code, message: message }] });
            } else {
                aSuccessRequest.push(oRequest);
            }
        }
        console.timeEnd(`Update promises ${counter}`);
        counter++;
    }

    if (newInfrastructureLogicEnabled) {
        const dNow = new Date();
        const FIELDS_TO_MAP = [
            'ID',
            'status',
            'submitter',   
            'approver',   
            'approvalDate',   
            'comment',   
            'sustClass',   
            'category1',   
            'contributor1',   
            'category2',   
            'contributor2',   
            'category3',   
            'contributor3',   
            'propagation',   
            'externalCommunication',   
            'approberComment',
        ];

        // Mass update the assessment that where detected as valid
        const aUpsertData = aSuccessRequest.map(request => {
            const oUpsertData = FIELDS_TO_MAP.reduce((acc, curr) => {
                if (request.data[curr] !== undefined)     acc[curr] = request.data[curr];
                return acc;
            }, {});

            if (!oUpsertData.submitter && oUpsertData.status === '04') {
                oUpsertData.submitter = req.user.id;
            }

            oUpsertData.communicationStatus = (request.data.status === '05' || request.data.status == '06') ? '01' : null;
            oUpsertData.modifiedAt = dNow;
            oUpsertData.modifiedBy = req.user.id;

            return oUpsertData;
        })

        const aUpsertBatches = divideArrayInBatches(aUpsertData, 1000);
        const db = await cds.connect.to("db");
        const MassAssessmentItems = db.entities[ENTITIES.DB.MASS_ASSESSMENT_ITEMS];
        for (const batch of aUpsertBatches) {
            await db.run(UPSERT(batch).into(MassAssessmentItems));
        }
    }

    console.time("postprocessing");

    // Successful promises trigger succeeded event 
    req.on('succeeded', async () => {
        const oNotification = {
            underResubmission: false,
            resubmitted: false,
        };
        for (const oSuccessRequest of aSuccessRequest) {
            await oSuccessRequest?.emit('succeeded');

            // Check from status required notifications
            if (oSuccessRequest.data.status === '03') {
                oNotification.underResubmission = true;
                oNotification.data ??= oSuccessRequest.data.itemDB;     
            } else if (oSuccessRequest.data.status === '04') {
                oNotification.resubmitted = true;
                oNotification.data ??= oSuccessRequest.data.itemDB;
            }
        }

        if (oNotification.underResubmission || oNotification.resubmitted) {
            await cds.tx( async tx => {

                try {
                    const SustainabilityManagement = await cds.connect.to('SustainabilityManagement');
                    if (oNotification.underResubmission) {
                        await SustainabilityManagement.emit(
                            'assessmentUnderResubmission', 
                            {
                                sbu: oNotification.data.sbu, 
                                assessmentId: oNotification.data.headerId,
                                submitter: oNotification.data.submitter,
                                type: 'MASS',
                            }
                        );
                    }
                    if (oNotification.resubmitted) {
                        await SustainabilityManagement.emit('assessmentResubmitted', 
                            {
                                sbu: oNotification.data.sbu, 
                                assessmentId: oNotification.data.headerId,
                                approver: oNotification.data.approver,
                                type: 'MASS',
                            }
                        );
                    }
                } catch (error) {
                    console.log('Error sending notification:', error)
                }
            });
        }
    });

    // Once every request is processed, set status header   
    const sItemID = req.data.items[0].ID;
    const sUserId = req.user.id;
    req.on('done', async () => {
        await cds.tx(async () => {
            const oDb = await cds.connect.to('db');
            const oMassAssessmentItems = oDb.entities["management.MassAssessmentItems"];
            const oItem = await SELECT.one.from(oMassAssessmentItems).where({ ID: sItemID }).columns("headerId");
            const oHead = {
                params: [oItem.headerId],
                user: {
                    id: sUserId
                }
            };
            await setHeaderStatus(oHead);
        });
        console.timeEnd("postprocessing");
        console.timeEnd("full time");
    });

    for (const request of aErrorRequest) {
        for (const error of request.errors) {
            req.error(409, error.message);
        }
    }

    return [];

};

async function fullMassAssessmentItemUpdate(req, bucketName, s3, newInfrastructureLogicEnabled) {
    await beforeUpdateMassAssessmentItem(req, newInfrastructureLogicEnabled);
    if (req.errors) throw new Error(req.errors);
    
    return req;
}

async function beforeUpdateMassAssessmentItem(req, newInfrastructureLogicEnabled) {

    const cds = require("@sap/cds");
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const oOldItems = [req.data.itemDB] || await SELECT.from(oMassAssessmentItems).where({ ID: req.data.ID });

    // if (!req.data.status || !req.data.approbalStatus) {
    //     req.error(403, "Status and approbed status must not be empty");
    //     return;
    // }
    /* if (!req.data.status || !req.data.approbalStatus) {
         req.error(403, "Status and approbed status must not be empty");
         return;
     }*/

    // Check if the approval status meets specific criteria (approbal steps), then update the item's status accordingly
    if (req.data.approbalStatus === '03' || req.data.approbalStatus === '04' || req.data.approbalStatus === '05' || req.data.approbalStatus === '06') {
        req.data.status = req.data.approbalStatus;
        const sOldApprover = oOldItems[0]?.approver;
        if ((!req.data.approver || req.data.approver === "") && !sOldApprover) {
            req.data.approver = req.user.id;
        }
    }

    if ((req.data.approbalStatus === '03' || req.data.approbalStatus === '06') && !req.data.approberComment) {
        req.error(403, `Product ${oOldItems[0]?.product}: Approver comment must not be empty`);
    }

    if (req.data.status === '01') {
        req.data.assessor = req.user.id;
    } else if (req.data.status === '02') {
        req.data.submitter = req.user.id;
        if (!oOldItems || !oOldItems[0].assessor || oOldItems[0].assessor === "") {
            req.data.assessor = req.user.id;
        }
    }

    if (!(await checkPermissionAndStatus(req))) {
        return;
    }

    if (req.data.status === '05') {
        req.data.approvalDate = new Date().toISOString().slice(0, 10);
    }

    if (!newInfrastructureLogicEnabled) await setAssessmentLog(req);

    return req;
};

async function onUpdateMassAssessmentItem(req, bucketName, s3) {
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities['management.MassAssessmentItems'];
    const oProofDocuments = oDb.entities['management.AssessmentProofDocument'];

    let aUpdatedMassItem = [];
    let aProofDocumentsObjectStore = [];

    try {

        if (req.data.status === '05' || req.data.status == '06') {
            req.data.communicationStatus = '01';
        }
        await cds.tx(async () => {
            await cds.run(
                UPDATE(oMassAssessmentItems)
                    .set(req.data)
                    .where({ ID: req.data.ID })
            );
        });

        //throw new Error("crash");
        console.log(`MassAssessmentItem updated for ${req.data.ID} with ${JSON.stringify(req.data)}`);

    } catch (error) {
        console.log(JSON.stringify(error));
        req.reject(409, "Error updating the assessment data");
    }

    return req;
};

async function setHeaderStatus(req) {
    // Retrieve header ID
    const sHeaderId = req.params[0];

    // Retrieve related items
    const oDb = await cds.connect.to('db');
    const oMassAssessmentItems = oDb.entities["management.MassAssessmentItems"];
    const oMassAssessmentHeader = oDb.entities["management.MassAssessmentHeader"];
    const aItems = await SELECT.from(oMassAssessmentItems).where({ headerId: sHeaderId });

    const STATUS_SAVED = "O1";
    const STATUS_SUBMITTED = "02";
    const STATUS_RESUBMITTED = "04";
    const STATUS_APPROVED = "05";
    const STATUS_REJECTED = "06";
    const STATUS_UNDER_REVIEW = "07";
    const STATUS_FINALIZED = "08";

    // If every status is submitted or saved, set the header status to the same as items
    const bStatusSubmitted = !aItems.some(item => item.status !== STATUS_SUBMITTED);
    const oSet = {};
    oSet.status = bStatusSubmitted ? STATUS_SUBMITTED : undefined;

    if (!oSet.status) {
        const bStatusSaved = !aItems.some(item => item.status !== STATUS_SAVED);
        oSet.status = bStatusSaved ? STATUS_SAVED : bStatusSaved;
    }

    if (!oSet.status) {

        // If any of the items is not approved or rejected, the it is under review. Else, it is finalized
        const bAllAssessmentFinished = !aItems.some(item => {
            return item.status !== STATUS_APPROVED && item.status !== STATUS_REJECTED;
        });
        oSet.status = bAllAssessmentFinished ? STATUS_FINALIZED : STATUS_UNDER_REVIEW;

        // Get communication status
        if (bAllAssessmentFinished) {
            const bAllProcessed = !aItems.some(item => item.communicationStatus !== COMMUNICATION_STATUS.COMPLETED);
            if (bAllProcessed) {
                oSet.communicationStatus = COMMUNICATION_STATUS.COMPLETED;
            } else {
                oSet.communicationStatus = COMMUNICATION_STATUS.PENDING;
            }
        }

        if (aItems.some(item => item.status === STATUS_APPROVED)) {
            oSet.approvalDate = new Date().toISOString().slice(0, 10);
        }

        // If status is under review, the first time approver is set
        const oHeader = await SELECT.one.from(oMassAssessmentHeader).where({ ID: sHeaderId });
        if (!oHeader.approver || oHeader.approver === "") {
            oSet.approver = req.user.id;
        }

        const bHasResubmittedItems = aItems.some(item => item.status === STATUS_RESUBMITTED);
        if (oSet.status === STATUS_UNDER_REVIEW && bHasResubmittedItems && !oHeader.submitter) {
            oSet.submitter = aItems.find(item => item.submitter).submitter;
        }

    }

    // Update header
    await UPDATE(oMassAssessmentHeader, sHeaderId).set(oSet);

    // Return new status
    return `New header status for mass assesstment header ${sHeaderId} set to ${oSet.status}`;
}

async function setCommunicationErrorLog(assessmentID, product, system, payload, error) {

    await cds.tx(async (tx) => {
        const oDb = await cds.connect.to("db");
        const CommunicationErrorLog = oDb.entities["management.CommunicationErrorLog"];

        const oNewEntry = {
            assessmentID: assessmentID,
            product: product,
            system: system,
            payload: JSON.stringify(payload),
            error: JSON.stringify(error),
        };
        await INSERT.into(CommunicationErrorLog).entries(oNewEntry);
    });

}

// Export the functions for use in other modules
module.exports = {
    assessmentsCountQuery,
    userParameters,
    validateSingleAssementUserPermissions,
    formatUUIDWithHyphens,
    removeHyphensFromUUID,
    createImageMasterDocument,
    updateImageMasterreference,
    removeObjectStoreDocument,
    refreshProductDocumentMapping,
    validateSingleAssementUserPermissions,
    checkProductsInAssessment,
    checkProductsInAssessmentforPdpMocHeart,
    validateAssementUserPermissions,
    //mapIdhWhereFilters,
    //mapIdhDatasPhereToIdhServiceEntity,
    getIdhMapping,
    getIbMapping,
    //translateVtSelectQueryWhere,
    translateVtResultsToProductData,
    setAssessmentLog,
    updateOnPremiseAssessmentProduct,
    convertAbapToJSDate,
    getProductApproverAssessor,
    checkPermissionAndStatus,
    updateMassAssessmentItemsBatch,
    // checkProductsInAssessmentInfo
    COMMUNICATION_STATUS,
};