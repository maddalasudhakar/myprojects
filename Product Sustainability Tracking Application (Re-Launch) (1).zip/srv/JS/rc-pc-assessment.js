/**
 * Factory function that creates an RC/PC (Responsible Chemistry / Positive Contribution) assessment module.
 * Handles the creation, validation, and management of product assessments with sustainability classifications.
 *
 * @param {Object} params - Configuration object
 * @param {Object} params.rcPcRepository - Repository for RC/PC data persistence operations
 * @param {Object} params.decisionTree - Decision tree engine for determining assessment status and sustainability data
 * @param {Object} params.assessmentValidations - Assessment validation utilities
 * @param {Object} params.assessment - Assessment service containing core assessment operations
 * @param {Function} params.checkProductsInAssessment - Function to check if products have ongoing assessments
 * @param {Object} params.rulesModel - Rules engine for validating assessment items
 * @param {Function} params.getUuid - UUID generator function
 * @returns {Object} RC/PC assessment module with public API methods
 */
function makeRcPcAssessment({
    rcPcRepository,
    decisionTree,
    assessmentValidations,
    assessment,
    checkProductsInAssessment,
    rulesModel,
    getUuid,
}) {

    const {
        ASSESSMENT_PROCESS,
        getSustainabilityClassMasterData,
        ASSESSMENT_STATUS,
        PRODUCT_TYPE,
        ASSESSMENT_TYPE,
        getProductProofDocuments,
        getRelatedIbProofDocuments,
        createAssessmentHeaders,
        createAssessmentItems,
        createProofDocuments,
    } = assessment;

    const {
        clearInvalidSustainabilityFieldsForItem,
        checkAssessmentFieldValues,
        getAssessmentFieldMasterData,
    } = assessmentValidations;

    /** Possible product status for process  */
    const PRODUCT_STATUS = {
        PENDING: '01',
        RETRIAL: '02',
        PROCESSED: '03',
    };

    /** Trigger name for assessment naming template */
    const TRIGGER_NAME = 'RC Positive Contribution';

    /** Reason data */
    const VALIDATION_REASON = {
        PRODUCTS_BLOCKED: 'Ongoing assessment',
    };

    /** Mapping between assessment status codes and their request name suffix. */
    const STATUS_FOR_ASSESSMENTS = [
        {status: ASSESSMENT_STATUS.SAVED, nameSuffix: '_SAVED'},
        {status: ASSESSMENT_STATUS.SUBMITTED, nameSuffix: '_SUBMITTED'},
    ];


    /**
     * Retrieves product data for a given SBU and list of products.
     *
     * @async
     * @param {string} sbu - Strategic Business Unit identifier
     * @param {string[]} products - Array of product identifiers to retrieve data for
     * @param {string} status - Filter status for the product data
     * @param {string} runId - Run identifier for the data retrieval
     * @returns {Promise<Object[]>} Array of product data objects
     * @throws {Error} If sbu, products array, status, or runId are invalid
     */
    async function getProductData(sbu, products, status, runId) {
        if (!sbu || !Array.isArray(products) || products.length === 0) {
            throw new Error('Invalid parameters: sbu and non-empty products array are required');
        }
        if (!status || !runId) {
            throw new Error('Invalid parameters: status and runId are required');
        }

        return await rcPcRepository.getProductData(sbu, products, status, runId);
    }

    /**
     * Builds complete assessments from product data.
     * Retrieves sustainability classifications, existing proof documents, and constructs assessment items.
     * Validates items according to rules and separates them into SAVED and SUBMITTED assessments.
     *
     * @async
     * @param {Object[]} productData - Array of product data objects to build assessments from
     * @returns {Promise<Object[]>} Array of assessment objects, each containing header and items arrays
     */
    async function buildAssessments(productData) {
        // Retrieve sustainability class master data for calculations
        const aSustainabilityClassMasterData = await getSustainabilityClassMasterData();

        // Get already existing proof documents
        const aExistingProofDocuments = await getProductProofDocuments(
            productData.map((item) => item.material),
        );

        // Get related IB documents in case it is an IDH
        const aRelatedIbProofDocuments = await getRelatedIbProofDocuments(
            productData.map((item) => item.material),
        );

        // Build items
        const aItems = buildAssessmentItems(
            productData,
            aExistingProofDocuments,
            aRelatedIbProofDocuments,
            aSustainabilityClassMasterData,
        );

        // Build template header
        const oTemplateHeader = buildTemplateAssessmentHeader(aItems[0]);

        // Retrieve index number for status request name
        const oNumbersForStatus = await getRequestNameNumberByStatus(oTemplateHeader.requestName);

        const sSavedSuffix = STATUS_FOR_ASSESSMENTS.find(
            (item) => item.status === ASSESSMENT_STATUS.SAVED,
        ).nameSuffix;

        const sSubmittedSuffix = STATUS_FOR_ASSESSMENTS.find(
            (item) => item.status === ASSESSMENT_STATUS.SUBMITTED,
        ).nameSuffix;

        const oAssessments = {
            saved: {
                header: {
                    ...oTemplateHeader,
                    ID: getUuid(),
                    requestName:
                        oTemplateHeader.requestName + sSavedSuffix + `-${oNumbersForStatus.saved}`,
                    status: ASSESSMENT_STATUS.SAVED,
                },
                items: [],
            },
            submitted: {
                header: {
                    ...oTemplateHeader,
                    ID: getUuid(),
                    requestName:
                        oTemplateHeader.requestName +
                        sSubmittedSuffix +
                        `-${oNumbersForStatus.submitted}`,
                    submitionDate: new Date().toISOString().slice(0, 10),
                    status: ASSESSMENT_STATUS.SUBMITTED,
                },
                items: [],
            },
        };

        const oMasterData = await getAssessmentFieldMasterData();
        const oRules = await rulesModel.getRules();

        // Consistency is checked for final assessment building
        for (const item of aItems) {
            const oHeader =
                item.status === ASSESSMENT_STATUS.SAVED
                    ? oAssessments.saved.header
                    : oAssessments.submitted.header;

            const oDummyAssessment = {
                header: oHeader,
                items: [item],
            };

            const oCheck = await checkAndClearAssessmentSustainabilityData(
                oDummyAssessment,
                oMasterData,
                oRules,
            );

            if (oCheck.isValid && item.status === ASSESSMENT_STATUS.SUBMITTED) {
                item.headerId = oAssessments.submitted.header.ID;
                oAssessments.submitted.items.push(item);
            } else {
                item.headerId = oAssessments.saved.header.ID;
                oAssessments.saved.items.push(item);
            }
        }

        const aResultingAssessments = [];
        if (oAssessments.saved.items.length > 0) {
            aResultingAssessments.push(oAssessments.saved);
        }

        if (oAssessments.submitted.items.length > 0) {
            aResultingAssessments.push(oAssessments.submitted);
        }

        return aResultingAssessments;
    }

    /**
     * Builds assessment items from product data.
     * Processes each product and attaches proof documents.
     *
     * @param {Object[]} productData - Array of product data objects
     * @param {Object[]} existingProofDocuments - Previously created proof documents for products
     * @param {Object[]} relatedIbProofDocuments - Proof documents from related Internal Business (IB) entities
     * @param {Object[]} sustainabilityClassMasterData - Master data for sustainability classifications
     * @returns {Object[]} Array of assessment item objects
     */
    function buildAssessmentItems(
        productData,
        existingProofDocuments,
        relatedIbProofDocuments,
        sustainabilityClassMasterData,
    ) {
        const today = new Date();
        const formattedDate = today.toISOString().slice(2, 10).replace(/-/g, '.');

        /** Configuration of default proofpoint data */
        const defaultUrl =
            process.env.DEFAULT_RCPC_PROOFPOINT_URL ||
            'https://app.powerbi.com/groups/me/apps/0a5a073f-8045-4f69-8050-88d699f69bf8/reports/9d0d7f59-59e1-49e3-8b32-a0c58479f340/eace89e2d21056a30b0a?ctid=e8701075-0d9e-4ea1-991d-5a0d110a5d29&experience=power-bi';

        const DEFAULT_PROOFPOINT = {
            URL: defaultUrl,
            TYPE: '18', // Other
            FILENAME: 'Responsible Chemistry application - Power BI',
            DESCRIPTION: 'Automated data load from the Responsible Chemistry Tool',
        };

        const items = productData.map((item) => {
            return buildAssessmentItem({
                product: item,
                sustainabilityClassMasterData,
                existingProofDocuments,
                relatedIbProofDocuments,
                defaultProofDocument: DEFAULT_PROOFPOINT,
            });
        });

        return items;
    }

    /**
     * Builds a generic assessment header from item data.
     * Creates a header with naming convention including trigger name, SBU, and date.
     *
     * @param {Object} data - Item data containing SBU and product type information
     * @param {string} data.sbu - Strategic Business Unit identifier
     * @param {string} data.productType - Type of product being assessed
     * @returns {Object} Assessment header object with naming, metadata, and status information
     */
    function buildTemplateAssessmentHeader(data) {
        const today = new Date();
        const formattedDate = today.toISOString().slice(2, 10).replace(/-/g, '.');

        const oHeader = {
            requestName: `${TRIGGER_NAME}_${data.sbu}_${formattedDate}`,
            sbu: data.sbu,
            // assessor: data.assessor,
            productType: data.productType,
            // submitter: data.submitter,
            // submitionDate: today,
            // approver: ,
            // approvalDate: ,
            assesmentType: ASSESSMENT_TYPE.MASS,
            status: ASSESSMENT_STATUS.SUBMITTED,
            processType: ASSESSMENT_PROCESS.RC_POSITIVE_CONTRIBUTION,
            virtualAssessment: false,
        };

        return oHeader;
    }

    /**
     * Constructs proof documents for an assessment item.
     * Combines existing proof documents, related IB documents, and default proof point.
     *
     * @param {string} itemId - Unique identifier for the assessment item
     * @param {string} material - Material/product identifier
     * @param {Object[]} existingProofDocuments - Existing proof documents for the product
     * @param {Object[]} relatedIbProofDocuments - Related Internal Business proof documents
     * @param {Object} defaultProofDocument - Default proof document to use if no others exist
     * @param {string} defaultProofDocument.TYPE - Type code for proof document
     * @param {string} defaultProofDocument.DESCRIPTION - Description of the document
     * @param {string} defaultProofDocument.FILENAME - File name of the document
     * @param {string} defaultProofDocument.URL - URL to access the document
     * @returns {Object[]} Array of proof document objects with formatted data
     */
    function builtItemProofDocuments(
        itemId,
        material,
        existingProofDocuments,
        relatedIbProofDocuments,
        defaultProofDocument,
    ) {
        // Map proof document data to format, both incoming and existing in related IBs
        const proofDocuments = [
            ...(
                relatedIbProofDocuments.find((document) => document.material === material)
                    ?.productProofDocuments || []
            ).map((document) => {
                const {
                    type,
                    description,
                    fileName,
                    url,
                    externalUrl,
                    active,
                    product,
                    proofPointId,
                } = document;
                return {
                    requestId: itemId,
                    type,
                    description,
                    fileName,
                    url,
                    externalUrl,
                    imageMasterID: proofPointId,
                    active: active === null ? true : active,
                    productReference: product,
                };
            }),
            ...existingProofDocuments
                .filter((document) => document.product === material)
                .map((document) => {
                    const {type, description, fileName, url, externalUrl, active, proofPointId} = document;
                    return {
                        requestId: itemId,
                        type,
                        description,
                        fileName,
                        url,
                        externalUrl,
                        imageMasterID: proofPointId,
                        active: active === null ? true : active,
                    };
                }),
        ];

        // If no proofdocuments, add default one
        if (proofDocuments.length === 0) {
            proofDocuments.push({
                requestId: itemId,
                type: defaultProofDocument.TYPE,
                description: defaultProofDocument.DESCRIPTION,
                fileName: defaultProofDocument.FILENAME,
                url: defaultProofDocument.URL,
                externalUrl: true,
                active: true,
            });
        }

        return proofDocuments;
    }

    /**
     * Builds a single assessment item from product data.
     * Determines item status and sustainability data based on decision tree logic.
     * Attaches proof documents and sets assessment properties.
     *
     * @param {Object} params - Parameters object
     * @param {Object} params.product - Product data object
     * @param {Object[]} params.sustainabilityClassMasterData - Master data for sustainability classifications
     * @param {Object[]} params.existingProofDocuments - Existing proof documents
     * @param {Object[]} params.relatedIbProofDocuments - Related IB proof documents
     * @param {Object} params.defaultProofDocument - Default proof document fallback
     * @returns {Object} Assessment item object with all required properties
     */
    function buildAssessmentItem(params) { 
        const {
            product,
            sustainabilityClassMasterData,
            existingProofDocuments,
            relatedIbProofDocuments,
            defaultProofDocument,
        } = params;

        const sItemId = getUuid();

        // Map proof document data to format, both incoming and existing in related IBs
        const proofDocuments = builtItemProofDocuments(
            sItemId,
            product.material,
            existingProofDocuments,
            relatedIbProofDocuments,
            defaultProofDocument,
        );

        const {status, newSustData} = getStatusAndSustData({
            updateType: product.updateType,
            rcPcClass: product.sustClass,
            previousRcPcClass: product.previousRcPcClass,
            existingAssessment: {
                sustClass: product.existingSustClass,
                rcPreFlag: product.rcPreFlag,
                category1: product.category1,
                category2: product.category2,
                category3: product.category3,
                contributor1: product.contributor1,
                contributor2: product.contributor2,
                contributor3: product.contributor3,
            },
            sustClassMasterdata: sustainabilityClassMasterData,
        });

        // Final item to return
        const oItem = {
            ID: sItemId,
            virtualAssessment: false,
            status,
            product: product.material,
            productType: PRODUCT_TYPE.IDH,
            sbu: product.sbu,
            comment: `Automated Assessment generated because of change in the underlying Responsible Chemistry Data`,
            rcPreFlag: product.rcPreFlag,
            sustClass: newSustData?.sustClass,
            category1: newSustData?.category1,
            contributor1: newSustData?.contributor1,
            category2: newSustData?.category2,
            contributor2: newSustData?.contributor2,
            category3: newSustData?.category3,
            contributor3: newSustData?.contributor3,
            propagation: true,
            externalCommunication: false,
            toProofDocuments: proofDocuments,
        };

        return oItem;
    }

    /**
     * Determines assessment item status and sustainability data based on decision tree logic.
     * Evaluates product update type, sustainability class, and existing assessment data.
     *
     * @param {Object} params - Parameters object
     * @param {string} params.updateType - Type of update being processed
     * @param {string} params.rcPcClass - RC/PC sustainability class from current data
     * @param {string} params.previousRcPcClass - Last RC/PC sustainability class from current data
     * @param {Object} params.existingAssessment - Current assessment data for the product
     * @param {Object[]} params.sustClassMasterdata - Master data for sustainability classifications
     * @returns {Object} Result object containing status and new sustainability data
     * @returns {string} returns.status - Assessment status (SAVED or SUBMITTED)
     * @returns {Object} returns.newSustData - Updated sustainability data
     */
    function getStatusAndSustData({
        updateType,
        rcPcClass,
        previousRcPcClass,
        existingAssessment,
        sustClassMasterdata,
    }) {
        return decisionTree.rootNode({
            updateType,
            rcPcClass,
            previousRcPcClass,
            existingAssessment,
            sustClassMasterdata,
        });
    }

    /**
     * Validates and clears assessment sustainability data according to rules.
     * Checks if assessment items comply with business rules and master data.
     * Automatically clears invalid sustainability fields if rule violations occur.
     *
     * @async
     * @param {Object} params - Parameters object
     * @param {Object} params.header - Assessment header containing request name and status
     * @param {Object[]} params.items - Array of assessment items to validate
     * @param {Object} oMasterData - Master data for assessment field validation
     * @param {Object} oRules - Rules engine configuration
     * @returns {Promise<Object>} Validation result object
     * @returns {boolean} returns.isValid - Whether all items are valid
     * @returns {string[]} returns.reasons - Array of validation failure reasons
     * @returns {string[]} returns.productsToSave - Products that failed validation
     */
    async function checkAndClearAssessmentSustainabilityData({header, items}, oMasterData, oRules) {
        const oResult = {
            isValid: true,
            reasons: [],
            productsToSave: [],
        };

        for (const oItem of items) {
            //const oItem = { ...item };
            oItem.requestName = header.requestName;
            oItem.approbalStatus = header.status;

            // First check if assessment is correct according to rules.
            // If an error related to sustainability fields is risen, then individual fields are
            // checked to clear wrong sustainbility fields
            const oCheckRule = await rulesModel.checkRules(oItem, oRules, oMasterData.contributor);
            if (!oCheckRule.continue) {
                // Error found, delete sustainability fields that are wrong if needed
                if (oCheckRule.hasSustainabilityError) {
                    clearInvalidSustainabilityFieldsForItem(oItem, oMasterData.contributor, oRules);
                }

                oResult.isValid = oCheckRule.continue;
                oResult.reasons.push(`Product ${oItem.product}: ${oCheckRule.reason}`);
                oResult.productsToSave.push(oItem.product);
            } else {
                // Check if fields correspond to masterdata
                const oCheckValues = await checkAssessmentFieldValues(oItem, oMasterData);
                if (!oCheckValues.valid) {
                    oResult.isValid = false;
                    oResult.reasons.push(`Product ${oItem.product}: ${oCheckValues.reason}`);
                    oResult.productsToSave.push(oItem.product);
                }
            }
            delete oItem.requestName;
            delete oItem.approbalStatus;
        }

        return oResult;
    }

    /**
     * Validates which products are eligible for assessment creation.
     * Checks if products already have ongoing assessments that would block creation.
     *
     * @async
     * @param {string[]} products - Array of product identifiers to validate
     * @returns {Promise<Object>} Validation result object
     * @returns {string[]} returns.validProducts - Products eligible for assessment
     * @returns {Object[]} returns.invalidProducts - Products with blocking assessments
     * @returns {string} returns.invalidProducts[].product - Product identifier
     * @returns {Object} returns.invalidProducts[].blockingAssessment - Assessment blocking the product
     * @returns {string} returns.invalidProducts[].reason - Reason for blocking
     */
    async function checkValidProducts(products) {
        const oValidation = {
            validProducts: [],
            invalidProducts: [],
        };

        const aProductsInAssessment = await checkProductsInAssessment(products);
        if (aProductsInAssessment && aProductsInAssessment.length > 0) {
            oValidation.invalidProducts.push(
                ...aProductsInAssessment.map((item) => {
                    return {
                        product: item.product,
                        blockingAssessment: item,
                        reason: VALIDATION_REASON.PRODUCTS_BLOCKED,
                    };
                }),
            );
        }

        oValidation.validProducts = products.filter(
            (product) => !oValidation.invalidProducts.some((item) => item.product === product),
        );

        return oValidation;
    }

    /**
     * Creates assessments in the system along with their items and proof documents.
     * Flattens assessment structure and persists all data to repository.
     *
     * @async
     * @param {Object[]} assessmentsToCreate - Array of assessment objects to create
     * @param {Object} assessmentsToCreate[].header - Assessment header
     * @param {Object[]} assessmentsToCreate[].items - Assessment items
     * @returns {Promise<void>}
     */
    async function createAssessments(assessmentsToCreate) {
        const aFlattenedItems = assessmentsToCreate.flatMap((assessment) => assessment.items);
        const aItems = aFlattenedItems.map((item) => {
            const oItem = {...item};
            delete oItem.toProofDocuments;
            return oItem;
        });
        const aProofDocuments = aFlattenedItems.flatMap((item) => item.toProofDocuments);

        await createAssessmentHeaders(
            assessmentsToCreate.map((assessment) => assessment.header)
        );

        await createAssessmentItems(aItems);
        await createProofDocuments(aProofDocuments);

    }

    /**
     * Updates material log status to PROCESSED after successful assessment creation.
     * Marks materials as processed separately for SAVED and SUBMITTED assessments.
     *
     * @async
     * @param {Object[]} assessmentsCreated - Array of created assessment objects
     * @param {string} sbu - Strategic Business Unit identifier
     * @param {string} status - Current status code
     * @param {string} runId - Run identifier for the batch process
     * @returns {Promise<void>}
     */
    async function setLogsAsFinished(assessmentsCreated, sbu, status, runId) {
        // Saving of assessment generated as SAVED
        const oAssessmentSaved = assessmentsCreated.find(
            (assessment) => assessment.header.status === ASSESSMENT_STATUS.SAVED,
        );
        if (oAssessmentSaved && oAssessmentSaved.header) {
            await rcPcRepository.updateMaterialLogStatus(
                oAssessmentSaved.items,
                runId,
                status,
                PRODUCT_STATUS.PROCESSED,
                oAssessmentSaved.header.ID,
                oAssessmentSaved.header.status,
            );
        }

        // Saving of assessment generated as SUBMITTED
        const oAssessmentSubmitted = assessmentsCreated.find(
            (assessment) => assessment.header.status === ASSESSMENT_STATUS.SUBMITTED,
        );
        if (oAssessmentSubmitted && oAssessmentSubmitted.header) {
            await rcPcRepository.updateMaterialLogStatus(
                oAssessmentSubmitted.items,
                runId,
                status,
                PRODUCT_STATUS.PROCESSED,
                oAssessmentSubmitted.header.ID,
                oAssessmentSubmitted.header.status,
            );
        }
    }

    /**
     * Updates material log status to RETRIAL for materials that require reprocessing.
     * Marks materials for retry without an associated assessment.
     *
     * @async
     * @param {Object[]} materials - Array of material objects to mark for retrial
     * @param {string} sbu - Strategic Business Unit identifier
     * @param {string} status - Current status code
     * @param {string} runId - Run identifier for the batch process
     * @returns {Promise<void>}
     */
    async function setLogsAsRetrial(materials, sbu, status, runId) {
        await rcPcRepository.updateMaterialLogStatus(
            materials,
            runId,
            status,
            PRODUCT_STATUS.RETRIAL,
            null,
            null,
        );
    }

    /**
     * Retrieves the next sequential number for assessment request names by status.
     * Queries existing assessments with matching request name pattern and increments accordingly.
     *
     * @async
     * @param {string} requestName - Base request name pattern to search for
     * @returns {Promise<Object>} Object containing next numbers for each status
     * @returns {number} returns.saved - Next number for SAVED status assessments
     * @returns {number} returns.submitted - Next number for SUBMITTED status assessments
     */
    async function getRequestNameNumberByStatus(requestName) {
        const aMassHeaders = await rcPcRepository.getRequestNamesByPattern(requestName);

        const oStatus = {
            saved: getNextNumberForStatus(ASSESSMENT_STATUS.SAVED, aMassHeaders),
            submitted: getNextNumberForStatus(ASSESSMENT_STATUS.SUBMITTED, aMassHeaders),
        };

        return oStatus;
    }

    /**
     * Calculates the next sequential number for a given assessment status.
     * Parses existing request names to find the highest number and increments it.
     *
     * @param {string} status - Assessment status code
     * @param {Object[]} aExistingHeaders - Array of existing assessment headers
     * @param {string} aExistingHeaders[].requestName - Request name containing sequence number
     * @returns {number} Next sequential number for the given status
     */
    function getNextNumberForStatus(status, aExistingHeaders) {
        const statusConfig = STATUS_FOR_ASSESSMENTS.find((s) => s.status === status);

        const sameStatusHeaders = statusConfig
            ? aExistingHeaders.filter((h) => h.requestName.includes(statusConfig.nameSuffix))
            : [];

        let maxNumber = 0;
        for (const h of sameStatusHeaders) {
            const match = h.requestName.match(/-(\d+)$/);

            if (match) {
                const num = parseInt(match[1], 10);

                if (num > maxNumber) {
                    maxNumber = num;
                }
            }
        }

        return maxNumber + 1;
    }

    return {
        getProductData,
        buildAssessments,
        buildTemplateAssessmentHeader,
        buildAssessmentItems,
        buildAssessmentItem,
        getStatusAndSustData,
        checkAndClearAssessmentSustainabilityData,
        checkValidProducts,
        createAssessments,
        setLogsAsFinished,
        setLogsAsRetrial,
        getRequestNameNumberByStatus,
        getNextNumberForStatus,
    };
}

module.exports = {makeRcPcAssessment};