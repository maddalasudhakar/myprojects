const cds = require('@sap/cds');
const handlers = require('./handlers');

module.exports = cds.service.impl(async function (srv) {

    /**
    * Actions
    */
    srv.on('pdpAssessmentCreation', handlers.actions.pdpAssessmentCreation);
    srv.on('mocAssessmentCreation', handlers.actions.mocAssessmentCreation);
    srv.on('sustClassMismatchAssessmentCreation', handlers.actions.sustClassMismatchAssessmentCreation);
    srv.on('heartAssessmentCreation', handlers.actions.heartAssessmentCreation);
    srv.on('syncPdpDataFromDataSphere', handlers.actions.syncPdpDataFromDataSphere);
    srv.on('syncMocDataFromDataSphere', handlers.actions.syncMocDataFromDataSphere);
    srv.on('rcPcAssessmentCreation', handlers.actions.rcPcAssessmentCreation);

    /**
     * Events
     */
    srv.on('pdpAssessmentSaved', handlers.events.pdpAssessmentSaved);
    srv.on('pdpAssessmentSubmitted', handlers.events.pdpAssessmentSubmitted);
    srv.on('mocAssessmentSaved', handlers.events.mocAssessmentSaved);
    srv.on('rcPreFlagMismatchAssessmentCreated', handlers.events.rcPreFlagMismatchAssessmentCreated);
    srv.on('backgroundAssessmentCreationBlocking', handlers.events.backgroundAssessmentCreationBlocking);
    srv.on('productsBlockedPdpMoc', handlers.events.productsBlockedPdpMoc);
    srv.on('heartAssessmentSaved', handlers.events.heartAssessmentSaved);
    srv.on('heartAssessmentSubmitted', handlers.events.heartAssessmentSubmitted);
    srv.on('heartAssessmentProductsBlocked', handlers.events.heartAssessmentProductsBlocked);
    srv.on('rcPcAssessmentSaved', handlers.events.rcPcAssessmentSaved);
    srv.on('rcPcAssessmentSubmitted', handlers.events.rcPcAssessmentSubmitted);

});