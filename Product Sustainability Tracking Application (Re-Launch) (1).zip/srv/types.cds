type AssessmentsByStatus {
    started          : Integer;
    submited         : Integer;
    underReSubmitted : Integer;
    approved         : Integer;
}

