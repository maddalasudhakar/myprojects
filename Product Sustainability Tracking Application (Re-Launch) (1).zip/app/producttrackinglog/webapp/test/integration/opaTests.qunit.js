sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'com/sustainability/producttrackinglog/test/integration/FirstJourney',
		'com/sustainability/producttrackinglog/test/integration/pages/ProductLogMain'
    ],
    function(JourneyRunner, opaJourney, ProductLogMain) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('com/sustainability/producttrackinglog') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheProductLogMain: ProductLogMain
                }
            },
            opaJourney.run
        );
    }
);