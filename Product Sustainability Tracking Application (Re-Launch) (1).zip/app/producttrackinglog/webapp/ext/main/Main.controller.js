sap.ui.define(
    [
        'sap/fe/core/PageController',
        "sap/ui/core/Fragment",
        "sap/m/MessageBox",
        "sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
    ],
    function (PageController, Fragment, MessageBox, Filter, FilterOperator) {
        'use strict';

        return PageController.extend('com.sustainability.producttrackinglog.ext.main.Main', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             * @memberOf com.sustainability.producttrackinglog.ext.main.Main
             */
            //  onInit: function () {
            //      PageController.prototype.onInit.apply(this, arguments); // needs to be called to properly initialize the page controller
            //  },

            /**
             * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
             * (NOT before the first rendering! onInit() is used for that one!).
             * @memberOf com.sustainability.producttrackinglog.ext.main.Main
             */
            //  onBeforeRendering: function() {
            //
            //  },

            /**
             * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
             * This hook is the same one that SAPUI5 controls get after being rendered.
             * @memberOf com.sustainability.producttrackinglog.ext.main.Main
             */
            //  onAfterRendering: function() {
            //
            //  },

            /**
             * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
             * @memberOf com.sustainability.producttrackinglog.ext.main.Main
             */
            //  onExit: function() {
            //
            //  }

            onSearch: function () {
                let oFilterBar = this.getView().byId("FilterBar"),
                    oTable = this.getView().byId("productlog"),
                    aFilters = oFilterBar.getFilters();
                if (aFilters.filters.length > 0) {
                    oTable.bindRows({
                        path: "/ProductLog",
                        filters: aFilters.filters,  
                        sorters: [
                            new sap.ui.model.Sorter("approvalDate", false)
                        ]
                    });
                } else {
                    MessageBox.information(this.getResourceBundle().getText("mandatoryFilter"));
                }
            },

            onPressProofPointsCheck: function (oEvent) {
                let oContext = oEvent.getSource().getBindingContext();

                if (!this._proofPointsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.producttrackinglog.fragment.ProofPointsDialog",
                        controller: this
                    }).then(function (oProofPointsDialog) {
                        this._proofPointsDialog = oProofPointsDialog;
                        this.getView().byId("proofTable").setBindingContext(oContext);
                        this.getView().addDependent(this._proofPointsDialog);
                        this._proofPointsDialog.setModel(this.getView().getModel());
                        this._proofPointsDialog.open();
                    }.bind(this));
                } else {
                    this._proofPointsDialog.setModel(this.getView().getModel());
                    this.getView().byId("proofTable").setBindingContext(oContext);

                    this._proofPointsDialog.open();
                }
            },

            onCloseProofPointsDialog: function () {
                this._proofPointsDialog.close();
            },

            handleLinkPress: function (oEvent) {
                let oModel = this.getModel(),
                    oProofPoint = oEvent.getSource().getBindingContext().getObject(),
                    baseUrl = oModel.getServiceUrl(),
                    sUploadURL = "";

                if (oProofPoint.externalUrl) {
                    sUploadURL = oProofPoint.url;
                } else {
                    sUploadURL = baseUrl + oProofPoint.url;
                }

                window.open(sUploadURL, '_blank');

            },
        });
    }
);
