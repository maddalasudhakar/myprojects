sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.sustainability.producttrackinglog.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);