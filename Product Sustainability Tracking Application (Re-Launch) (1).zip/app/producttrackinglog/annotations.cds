using ProductTrackingLog as service from '../../srv/sustainability.service';

annotate service.ProductLog with @(
    UI.SelectionFields : [product],
    UI.SelectionVariant: {SelectOptions: [{PropertyName: product}]},
    Capabilities       : {
        SearchRestrictions: {Searchable: false},
        FilterRestrictions: {
            NonFilterableProperties: [ 'ID', 'requestName', 'sbu', 'productName', 'assessor', 'submitter', 'submitionDate', 'approver', 'approvalDate', 'comment', 'rcPreFlag', 'rcPreFlagDescription', 'sustClass', 'sustClassDescription', 'category1', 'category1Description', 'contributor1', 'contributor1Description'
             ,'category2' ,'category2Description' ,'contributor2' ,'contributor2Description' ,'category3' ,'category3Description' ,'contributor3' ,'contributor3Description' ,'propagation' ],
            FilterExpressionRestrictions: [{
            Property          : 'product',
            AllowedExpressions: 'SingleValue'
        }]}
    },

);

annotate service.ProductLog with {
    product @title: '{@i18n>productNameLabel}';
}
