## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Wed Jul 31 2024 10:08:20 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori-elements|
|**App Generator Version**<br>1.14.2|
|**Generation Platform**<br>SAP Business Application Studio|
|**Template Used**<br>Custom Page V4|
|**Service Type**<br>Local Cap|
|**Service URL**<br>http://localhost:4004/odata/v4/sustainability/management/|
|**Module Name**<br>overview|
|**Application Title**<br>Overview|
|**Namespace**<br>com.sustainability|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.126.2|
|**Enable Code Assist Libraries**<br>False|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>False|
|**Main Entity**<br>Idh|

## overview

Overview Application

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply start your CAP project and navigate to the following location in your browser:

http://localhost:4004/overview/webapp/index.html

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


