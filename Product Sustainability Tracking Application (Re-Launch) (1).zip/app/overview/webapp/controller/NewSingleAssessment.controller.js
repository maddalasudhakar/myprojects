sap.ui.define(
    [
        "./BaseController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "../model/formatter",
    ],
    function (BaseController, JSONModel, MessageBox, Filter, FilterOperator, formatter) {
        'use strict';

        return BaseController.extend('com.sustainability.overview.controller.NewSingleAssessment', {
            formatter: formatter,
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: function () {
                this.getRouter().getRoute("NewSingleAssessment").attachPatternMatched(this._onNewSingleAssessmentMatched, this);

                let oAssessmentModel = new JSONModel({
                    editMode: true,
                    firstAdditionalDetails: false,
                    secondAdditionalDetails: false,
                    proofEnabled: false,
                    approbeMode: false,
                    type: "",
                    prooftype: [],
                    contributors: [],
                    categories: [],
                    sustClass: [],
                    validProofType: [],
                    assesmentType: "",
                    productRelation: [],
                    userAction: "",
                    recipientsList: []

                });

                this.getView().setModel(oAssessmentModel, "assessmentModel");
            },

            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/

            onPropagationChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("propagation", bValue);
            },

            onActiveChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    oContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("active", bValue);
                this.setProofTypesOptions(oContext);
            },

            handleLinkPress: function (oEvent) {
                let oModel = this.getModel(),
                    oProofPoint = oEvent.getSource().getBindingContext().getObject(),
                    baseUrl = oModel.getServiceUrl(),
                    sUploadURL = "";

                if (oProofPoint.externalUrl) {
                    sUploadURL = oProofPoint.url;
                } else {
                    sUploadURL = baseUrl + oProofPoint.url;
                }

                window.open(sUploadURL, '_blank');

            },

            /**
            * Cancel new single assesment creation.
            * @public
            */
            onCancel: function () {
                let oPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oPage.getBindingContext();

                MessageBox.confirm(this.getResourceBundle().getText("confirmdeletionNonSaved"), {
                    onClose: function (sAction) {
                        if (sAction === 'OK') {
                            //oContext.delete("UpdateGroup");
                            this.getModel().resetChanges("UpdateGroup");
                            this.getRouter().navTo("ProductOverview", undefined, undefined, true);
                        }
                    }.bind(this)
                });
            },

            /**
            *Add new line in proof point table
            * @public
            */
            onAddProofPoint: function () {
                let oProofTable = this.getView().byId("proofTableSingle"),
                    oBinding = oProofTable.getBinding("rows");
                oBinding.create({ "active": true }, true);
            },

            /**
            * Delete selected proof points
            * @public
            */
            onDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("proofTableSingle").getSelectedIndices(),
                    aContext = [],
                    oProofTable = this.getView().byId("proofTableSingle");


                if (aSelectedIndices.length > 0) {

                    let bShowError = aSelectedIndices.some(iIndex => {
                        let oContext = oProofTable.getContextByIndex(iIndex);
                        // If the documents is in Image master is not possible delete it
                        if (oContext.getProperty("imageMasterID")) {
                            return true;
                        }

                        aContext.push(oContext);
                        return false;
                    });

                    if (bShowError) {
                        MessageBox.error(this.getResourceBundle().getText("removeProofPointsError"));
                        return;
                    }

                    MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionProofPoints"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                aContext.forEach(oContext => {
                                    oContext.delete("UpdateGroup");
                                });
                            }
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory1Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor1Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }
                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory2Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor2Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }

                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory3Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor3Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }
                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Reset sustainability class dependent fields.
            * @public
            */
            onClassChange: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    sRcPreFlag = oContext.getProperty("rcPreFlag");

                this.setDinamycFields(sSelectedKey, sRcPreFlag);

                let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);

                oContext.setProperty("category1", "");
                oContext.setProperty("contributor1", "");
                oContext.setProperty("category2", "");
                oContext.setProperty("contributor2", "");
                oContext.setProperty("category3", "");
                oContext.setProperty("contributor3", "");
                this.getView().byId("contributor1Id").setEnabled(false);
                this.getView().byId("contributor2Id").setEnabled(false);
                this.getView().byId("contributor3Id").setEnabled(false);

                this._checkTypeProofFields(oContext, true);
                this.setProofTypesOptions(oContext);
            },

            /**
            * Set valid proof types depending on the contributors.
            * @public
            */
            onContributorChange: function () {
                let oContext = this.getView().byId("ObjectPageLayout").getBindingContext();

                this._checkTypeProofFields(oContext, true);
                this.setProofTypesOptions(oContext);
                //let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                //this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);

            },

            onProofRowsUpdated: function () {
                let oContext = this.getView().byId("ObjectPageLayout").getBindingContext();
                if (oContext) {
                    if (Object.keys(oContext).length !== 0) {
                        this._checkTypeProofFields(oContext, true);
                        this.setProofTypesOptions(oContext);
                    }
                }
            },

            onFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oEvent.getParameter("files"),
                    oContext = oFileUploader.getBindingContext();

                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oContext.setProperty("content", sFileContent.split(',')[1], "UpdateGroup", true);
                        oContext.setProperty("fileName", oFile.name, "UpdateGroup", true);
                        oContext.setProperty("mediaType", oFile.type, "UpdateGroup", true);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            onOkNotificationsRecipientsDialog: async function () {
                const sAction = this.getModel("assessmentModel").getProperty("/userAction"),
                    oAssessmentContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    oModel = this.getModel(),
                    aSelectedContext = this.getView().byId("recipientsTableId").getSelectedContexts(),
                    sAssessmentID = oAssessmentContext.getProperty("ID"),
                    sStatus = sAction === "Save" ? "01" : "02";

                this.getView().setBusy(true);
                
                this.getView().byId("recipientsTableId").removeSelections();

                this.getModel("assessmentModel").setProperty("/userAction", "");
                this._notificationRecipientsDialog.close();

                if (!sAction) {
                    this.getView().setBusy(false);
                    return;
                }

                if ((!aSelectedContext || aSelectedContext.length === 0) && sAction === "Submit") {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("mandatoryRecipients"));

                    return;
                }

                // Build recipients payload for the action
                let aRecipients = [];
                if (aSelectedContext && aSelectedContext.length > 0) {
                    aRecipients = aSelectedContext
                        .map(oContext => oContext && oContext.getProperty("email"))
                        .filter(Boolean);
                }

                // If there is nothing to send and the user just saved, continue normal flow
                if (aRecipients.length === 0) {
                    if (sAction === "Save") {
                        await this._saveAssessment();
                    }
                    return;
                }

                try {

                    let oContextBinding = oModel.bindList("toRecipients", oAssessmentContext, undefined, undefined, { $$updateGroupId: "UpdateGroup" });

                    aRecipients.forEach((sRecipient) => {
                        oContextBinding.create({ recipientEmail: sRecipient, assessmentStatus: sStatus });
                    });

                    if (sAction === "Save") {
                        await this._saveAssessment();
                    } else if (sAction === "Submit") {
                        await this._submitAssessment();
                    }


                } catch (oError) {
                    // Handle errors from action execution
                    this.getView().setBusy(false);

                    console.error("saveRecipients action error", oError);
                }
            },


            /**
            * Submit new assessment (set status to submited).
            * @public
            */
            onSubmit: async function () {
                const oContext = this.getView().byId("ObjectPageLayout").getBindingContext()
                this.getModel("assessmentModel").setProperty("/userAction", "Submit");

                this.openRecipientsDialog("02", oContext.getProperty("sbu"), "");

            },

            /**
            * Save new assessment(set status to saved)
            * @public
            */
            onSave: function () {
                const oContext = this.getView().byId("ObjectPageLayout").getBindingContext()
                this.getModel("assessmentModel").setProperty("/userAction", "Save");

                this.openRecipientsDialog("01", oContext.getProperty("sbu"), "");

            },

            /**
            * Show additional block one
            * @public
            */
            onShowFirstAdditionalDetails: function () {
                this.getView().byId("category2block").setVisible(true);
                this.getView().byId("contributor2block").setVisible(true);
                this.getView().byId("additionalButton2block").setVisible(true);
                this.getView().byId("additionalButton1block").setVisible(false);
            },

            /**
            * Show additional block two
            * @public
            */
            onShowSecondtAdditionalDetails: function () {
                this.getView().byId("category3block").setVisible(true);
                this.getView().byId("contributor3block").setVisible(true);
                this.getView().byId("additionalButton2block").setVisible(false);
            },

            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/

            _onNewSingleAssessmentMatched: async function (oEvent) {
                let oView = this.getView().byId("ObjectPageLayout"),
                    oMasterDataForm = this.getView().byId("productMasterData"),
                    oChemestryPreCheck = this.getView().byId("chemestryPreCheck"),
                    oContext = this.getView().getModel("ui").getProperty("/oContext"),
                    sRcPreFlag = oContext.getProperty("rcPreFlag"),
                    sSbu = oContext.getProperty("sbu"),
                    sSustClass = oContext.getProperty("sustClass"),
                    aComposedRoles = this.getModel("ui").getProperty("/userParameters/composedRoles"),
                    aProofTypes = [],
                    aContributors = [],
                    aCategories = [],
                    aSustClass = [];

                this.getModel("assessmentModel").setProperty("/type", oContext.getProperty("productType"));
                this.getModel("assessmentModel").setProperty("/assesmentType", oContext.getProperty("assesmentType"));

                oView.setBindingContext(oContext);

                //oMasterDataForm.bindElement({ path: "/ProductData('" + oContext.getProperty("product") + "')" });
                //oChemestryPreCheck.bindElement({ path: "/ProductData('" + oContext.getProperty("product") + "')" });

                aProofTypes = await this.getProofTypes();
                aContributors = await this.getContributors();
                aCategories = await this.getCategories();
                aSustClass = await this.getSustClass();
                this.getModel("assessmentModel").setProperty("/proofType", aProofTypes);
                this.getModel("assessmentModel").setProperty("/contributors", aContributors);
                this.getModel("assessmentModel").setProperty("/categories", aCategories);
                this.getModel("assessmentModel").setProperty("/sustClass", aSustClass);
                this.getModel("assessmentModel").setProperty("/validProofType", aProofTypes);

                if (aComposedRoles.some(role => role === sSbu + ".Submitter")) {
                    this.getView().byId("submitButton").setVisible(true);
                    this.getView().byId("saveButton").setVisible(true);
                } else if (aComposedRoles.some(role => role === sSbu + ".Assessor")) {
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(true);
                } else {
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(false);
                }

                if (sSustClass === "" || sSustClass === undefined || sSustClass === null) {
                    sSustClass = "sustCodes";
                }
                this.setDinamycFields(sSustClass, sRcPreFlag);
                this.filterSustClass("sustCodes", sRcPreFlag);
                this._setAssessmentDetailsFields(oContext);
                this.setProofTypesOptions(oContext);
                let aRelatedProducts = await this.getRelatedProductsData(oContext.getProperty("productType"), oContext.getProperty("product"));
                this.getModel("assessmentModel").setProperty("/productRelation", aRelatedProducts);
                //this.getView().byId("contributor1Id").setEnabled(false);
                //this.getView().byId("contributor2Id").setEnabled(false);
                //this.getView().byId("contributor3Id").setEnabled(false);
            },

            _saveAssessment: async function () {
                var oModel = this.getModel(),
                    oObjectPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oObjectPage.getBindingContext(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                oContext.setProperty("status", "01", "UpdateGroup", true);
                this.getView().setBusy(true);

                oModel.submitBatch("UpdateGroup").then(function (odata, second) {
                    this.getView().setBusy(false);
                    if (!oModel.hasPendingChanges("UpdateGroup")) {
                        MessageBox.information(this.getResourceBundle().getText("assessmentSaved"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {

                                    this.getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    } else {
                        let aMessage = oMessageModel.getData(),
                            oLastMessage = aMessage[aMessage.length - 1];
                        MessageBox.error(oLastMessage.getMessage());
                    }
                }.bind(this)).catch(function (oError) {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                }.bind(this));
            },

            _submitAssessment: async function () {
                let oModel = this.getModel(),
                    oObjectPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oObjectPage.getBindingContext(),
                    bApproveMode = this.getView().getModel("assessmentModel").getProperty("/approveMode"),
                    sMessageText = this.getResourceBundle().getText(
                        bApproveMode ? "approvedDecisionGived" : "assessmentSubmited"
                    ),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();


                let oContinue = await this.checkMandatoryFields(oContext);

                if (oContinue.items && oContinue.prooPoints) {
                    oContext.setProperty("status", "02", "UpdateGroup", true);
                    this.getView().setBusy(true);
                    oModel.submitBatch("UpdateGroup").then(function (odata, second) {
                        this.getView().setBusy(false);
                        if (!oModel.hasPendingChanges("UpdateGroup")) {
                            MessageBox.information(sMessageText, {
                                onClose: function (sAction) {
                                    if (sAction === 'OK') {

                                        this.getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                    }
                                }.bind(this)
                            });
                        } else {
                            let aMessage = oMessageModel.getData(),
                                oLastMessage = aMessage[aMessage.length - 1];
                            MessageBox.error(oLastMessage.getMessage());
                        }
                    }.bind(this)).catch(function (oError) {
                        this.getView().setBusy(false);
                        MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                    }.bind(this));
                } else {
                    this.getView().setBusy(false);
                    if (!oContinue.prooPoints) {
                        MessageBox.information(this.getResourceBundle().getText("mandatoryProofPointError"));
                    } else {
                        MessageBox.information(this.getResourceBundle().getText("assessmentErrors"));
                    }
                }

            },

            /**
            * Set visualization of Assessment details block.
            * @private
            */
            _setAssessmentDetailsFields: function (oContext) {
                let sCategory1 = oContext.getProperty("category1"),
                    sContributor1 = oContext.getProperty("contributor1"),
                    sCategory2 = oContext.getProperty("category2"),
                    sContributor2 = oContext.getProperty("contributor2"),
                    sCategory3 = oContext.getProperty("category3"),
                    sContributor3 = oContext.getProperty("contributor3"),
                    aFilters = [];

                if ((sCategory1 !== "" && sCategory1 !== "00" && sCategory1 !== null) || (sContributor1 !== "" && sContributor1 !== null)) {
                    this.getView().byId("category1block").setVisible(true);
                    this.getView().byId("contributor1block").setVisible(true);
                    this.getView().byId("additionalButton1block").setVisible(true);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory1));
                    this.getView().byId("contributor1Id").getBinding("items").filter(aFilters);
                }
                if ((sCategory2 !== "" && sCategory2 !== "00" && sCategory2 !== null) || (sContributor2 !== "" && sContributor2 !== null)) {
                    this.getView().byId("category2block").setVisible(true);
                    this.getView().byId("contributor2block").setVisible(true);
                    this.getView().byId("additionalButton1block").setVisible(false);
                    this.getView().byId("additionalButton2block").setVisible(true);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory2));
                    this.getView().byId("contributor2Id").getBinding("items").filter(aFilters);
                }
                if ((sCategory3 !== "" && sCategory3 !== "00" && sCategory3 !== null) || (sContributor3 !== "" && sContributor3 !== null)) {
                    this.getView().byId("category3block").setVisible(true);
                    this.getView().byId("contributor3block").setVisible(true);
                    this.getView().byId("additionalButton2block").setVisible(false);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory3));
                    this.getView().byId("contributor3Id").getBinding("items").filter(aFilters);

                }

                if (sCategory1 !== "" && sCategory1 !== null) {
                    this.getView().byId("contributor1Id").setEnabled(true);
                }
                if (sCategory2 !== "" && sCategory2 !== null) {
                    this.getView().byId("contributor2Id").setEnabled(true);
                }
                if (sCategory2 !== "" && sCategory2 !== null) {
                    this.getView().byId("contributor3Id").setEnabled(true);
                }

            }

            /*_uploadAllFiles: async function () {
                let oTable = this.getView().byId("proofTable"),
                    oModel = this.getModel(),
                    aItems = oTable.getItems(),
                    oAssessment = this.getView().byId("ObjectPageLayout").getBindingContext().getObject();
                

                let baseUrl = oModel.getServiceUrl() + "ProofDocument";

                aItems.forEach((oItem, iIndex) => {
                    let oFileUploader = oItem.getCells()[2],
                        sUploadURL = baseUrl + "(" + oAssessment.toProofDocuments[iIndex].ID + ")/content";

                    if (oFileUploader && oFileUploader.getValue()) {
                        oFileUploader.setUploadUrl(sUploadURL);
                        oFileUploader.setSendXHR(true);
                        oFileUploader.upload();
                    }
                });

            }*/

        });
    }
);