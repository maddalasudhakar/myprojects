sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/UIComponent",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",

], function (Controller, UIComponent, Filter, FilterOperator, Fragment) {
	"use strict";

	return Controller.extend("com.sustainability.overview.controller.BaseController", {
		/**
		 * Convenience method for accessing the router.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function () {
			return UIComponent.getRouterFor(this);
		},

		/**
		 * Convenience method for getting the view model by name.
		 * @public
		 * @param {string} [sName] the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function (sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function (oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Getter for the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		getProofTypes: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/ProofType");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oProofType) {
				return oProofType.getObject();
			});
		},

		getContributors: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/Contributor");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oContributor) {
				return oContributor.getObject();
			});
		},

		getCategories: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/SustainabilityCategory");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oCategory) {
				return oCategory.getObject();
			});
		},

		getSustClass: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/SustainabilityClass");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oSustClass) {
				return oSustClass.getObject();
			});
		},

		getRelatedProductsData: async function (sType, sProduct) {
			let oModel = this.getModel(),
				sPath = "/getRelatedProductsData(productType='" + sType + "',product='" + sProduct + "')";

			this.getView().setBusy(true);

			let aRelatedproductData = await oModel.bindContext(sPath).requestObject().then((oObject) => {
				this.getView().setBusy(false);
				return oObject.value;
			}).catch((oError) => {
				this.getView().setBusy(false);
			});

			return aRelatedproductData;
		},

		getValidProofTypes: function (oContext, aProoftypes) {
			let oProofTypesMap = this._getProofTypesMap(aProoftypes),
				aValidProofTypes = [],
				aProofTypeRule = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types as well
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				aContributors = [sContributor1, sContributor2, sContributor3],
				sRcPreFlag = oContext.getProperty("rcPreFlag");

			// Add regular proof types based on contributors
			aProofTypeRule.forEach(function (rule) {
				aContributors.forEach(function (contributor) {
					if (rule.contributorId.includes(contributor) && !aValidProofTypes.some(proofType => proofType.code === rule.typeId)) {
						if (oProofTypesMap[rule.typeId]) {
							aValidProofTypes.push(oProofTypesMap[rule.typeId]);
						}
					}
				});
			});

			// Check if sRcPreFlag is a special case and add additional proof types if applicable
			let aSpecialProofTypesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
				return specialRule.sustClass === sRcPreFlag;
			});

			if (aSpecialProofTypesForsRcPreFlag.length > 0) {
				aSpecialProofTypesForsRcPreFlag.forEach(function (specialRule) {
					specialRule.typeId.forEach(function (specialTypeId) {
						// Add the special type if it exists in the proof type map and hasn't been added already
						if (oProofTypesMap[specialTypeId] && !aValidProofTypes.some(proofType => proofType.code === specialTypeId)) {
							aValidProofTypes.push(oProofTypesMap[specialTypeId]);
						}
					});
				});
			}

			return aValidProofTypes;
		},

		_getProofTypesMap: function (aProoftypes) {
			let oProofTypesMap = {};
			aProoftypes.forEach(function (proofType) {
				oProofTypesMap[proofType.code] = proofType;
			});
			return oProofTypesMap;
		},

		/***************************************************************
		*
		* Single Assessment methods
		*
		***************************************************************/

		/**
		* Control dinamyc fields of Single Assessment
		* @public
		*/
		setDinamycFields: function (sSelectedKey, sRcPreFlag) {
			let oRulesModel = this.getModel("rules").getProperty("/");

			// Apply visibility and enable/disable rules based on Sustainability class and sRcPreFlag
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSelectedKey]) {
				const oRules = oRulesModel[sRcPreFlag][sSelectedKey];
				this.setVisibility(oRules.show, true);
				this.setVisibility(oRules.hide, false);
				this.setProofEnable(oRules.proofEnabled);
			}
		},

		/**
		* Helper function to show or hide fields
		* @public
		*/
		setVisibility: function (aFields, bVisible) {
			aFields.forEach(id => {
				const oObject = this.getView().byId(id);
				if (oObject) {
					oObject.setVisible(bVisible);
				}
			});
		},

		/**
		* Helper function to enable proof documents fields
		* @public
		*/
		setProofEnable: function (bEnabled) {
			this.getModel("assessmentModel").setProperty("/proofEnabled", bEnabled);
		},

		/**
		* Set possible sustainability class values of Single Assessment
		* @public
		*/
		filterSustClass: function (sSelectedKey, sRcPreFlag) {
			let aFilters = [],
				oRulesModel = this.getModel("rules").getProperty("/"),
				oSustClassSelect = this.byId("sustClassId").getBinding("items");

			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSelectedKey]) {
				const oRules = oRulesModel[sRcPreFlag][sSelectedKey];
				oRules.codes.forEach(sCode => {
					aFilters.push(new Filter("code", FilterOperator.EQ, sCode));
				});

				oSustClassSelect.filter(aFilters);
			}
		},

		/**
		 * Check mandatory fields of Single Assessment
		 * @public
		 */
		checkMandatoryFields: function (oContext) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				sSustClass = oContext.getProperty("sustClass"),
				sValue = "",
				oAssessement = oContext.getObject(),
				bContinue = true,
				oContinue = {
					"items": true,
					"prooPoints": true
				}

			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustClass];

				//if (oRules.proofMandatory) {
				bContinue = this.checkMandatoryProofFields(oRules.proofMandatory);
				if (!bContinue) {
					return oContinue.prooPoints = false;
				}
				bContinue = this._checkTypeProofFields(oContext);
				if (!bContinue) {
					return oContinue.prooPoints = false;
				}
				//}

				if (bContinue) {
					for (const [sKey, bMandadotry] of Object.entries(oRules.mandatory)) {
						sValue = oContext.getProperty(sKey)
						if (bMandadotry && (sValue === undefined || sValue === null || sValue === "" || sValue === "00")) {
							bContinue = false;
							oContinue.items = false;
							break;
						}
					}
				}

				if (bContinue) {
					if ((oAssessement.category1 && !oAssessement.contributor1) || (oAssessement.category2 && !oAssessement.contributor2) ||
						(oAssessement.category3 && !oAssessement.contributor3)) {
						bContinue = false;
						oContinue.items = false;
					}
				}

			} else if ((sRcPreFlag === undefined || sRcPreFlag === null || sRcPreFlag === "") || (sSustClass === undefined || sSustClass === null || sSustClass === "")) {
				bContinue = false;
				oContinue.items = false;
			}

			return oContinue;
		},

		/**
		 * Check mandatory proof fields of Single Assessment
		 * @public
		 */
		checkMandatoryProofFields: function (bMandatory) {
			let oTable = this.byId("proofTableSingle"),
				aProofDocuments = oTable.getBindingContext().getObject().toProofDocuments,
				aItems = oTable.getRows(),
				bValid = true,
				bHasActiveProofDocument = false;

			if (bMandatory && aProofDocuments.length === 0) {
				return false;
			}

			for (const oProofDocument of aProofDocuments) {

				if ((!oProofDocument.type || !oProofDocument.description || !oProofDocument.fileName) &&
					(!oProofDocument.imageMasterID && oProofDocument.active)) {
					bValid = false;
					break;

				}

				if (oProofDocument.active) {
					bHasActiveProofDocument = true;
				}
			}

			if (bMandatory && !bHasActiveProofDocument) {
				bValid = false;
			}

			return bValid;

			/*aItems.forEach((oItem) => {

				if (!oItem.getBindingContext() || !bValid) {
					return;
				}

				let oProofDocument = oItem.getBindingContext().getObject();
				if (!oProofDocument.type || )
			});

			return bValid;*/
		},

		/**
			* Check if the type matches with the contributors and sustClass (special cases)
			* @public
			*/
		_checkTypeProofFields: function (oContext, bRemove) {
			let oTable = this.byId("proofTableSingle"),
				aItems = oTable.getRows(),
				aProofTypeRulesModel = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				sSustClass = oContext.getProperty("sustClass"),
				bValid = true,
				bValidForContributors = false,
				bValidForSustClass = false;

			for (const oItem of aItems) {

				if (!oItem.getBindingContext()) {
					continue;
				}

				let sType = oItem.getBindingContext().getProperty("type");
				let bActive = oItem.getBindingContext().getProperty("active");
				if (sType !== null && sType !== undefined && sType !== "") {
					let oEntry = aProofTypeRulesModel.find(function (item) {
						return item.typeId === sType;
					});

					if (oEntry) {
						// Check if the type is valid for contributors
						bValidForContributors = oEntry.contributorId.includes(sContributor1) || oEntry.contributorId.includes(sContributor2) ||
							oEntry.contributorId.includes(sContributor3) || oEntry.contributorId.includes(sRcPreFlag);
					}

					/// Check if the type is valid for special sustClass
					let aSpecialProofTypesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
						return specialRule.sustClass === sRcPreFlag;
					});

					if (aSpecialProofTypesForsRcPreFlag.length > 0) {
						// If it is a special case, validate for sustClass
						bValidForSustClass = aSpecialProofTypesForsRcPreFlag.some(function (specialRule) {
							return specialRule.typeId.includes(sType);
						});
					}
					// If not valid for both contributors and sustClass, take action (e.g., remove the proof type)
					if (!bValidForContributors && !bValidForSustClass && bActive) {
						if (bRemove) {
							oItem.getAggregation("cells")[1].setSelectedKey("");
						}
						bValid = false; // Mark as invalid
						break;
					}
				}
			};

			return bValid;
		},

		setProofTypesOptions: function (oContext) {
			let oTable = this.byId("proofTableSingle"),
				aItems = oTable.getRows(),
				aProofTypeRulesModel = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				aValidTypes = [],
				aSpecialTypes = [],
				aCells = [],
				aFilters = [];

			// Consolidate all contributors into one array
			let aContributors = [sContributor1, sContributor2, sContributor3].filter(Boolean);

			// Determine valid proof types based on contributors
			if (aContributors.length > 0) {
				aValidTypes = aProofTypeRulesModel
					.filter(oProofType =>
						oProofType.contributorId.some(contributor => aContributors.includes(contributor))
					)
					.map(oProofType => oProofType.typeId);
			}

			// If rcPreFlag is active, include special proof types
			if (sRcPreFlag) {
				aSpecialTypes = aSpecialProofTypes
					.filter(oSpecialType =>
						oSpecialType.sustClass === sRcPreFlag
					)
					.flatMap(oSpecialType => oSpecialType.typeId);
				//aValidTypes = [...new Set([...aValidTypes, ...aSpecialTypes])]; // Ensure no duplicates
			}

			let aMergedArray = aValidTypes.concat(
				aSpecialTypes.filter(type => !aValidTypes.includes(type))
			);


			// Iterate over table rows and apply filters
			for (const oItem of aItems) {
				if (!oItem.getBindingContext()) {
					continue;
				}

				aCells = oItem.getCells();

				aCells.forEach(oCell => {
					if (oCell.getId().includes("proofTypeIdSingle")) {
						aFilters = [];
						if (oItem.getBindingContext().getProperty("active")) {
							// Create a filter for valid proof types
							if (aMergedArray.length > 0) {
								aMergedArray.forEach(sType => {
									aFilters.push(new sap.ui.model.Filter({
										path: "code",
										operator: FilterOperator.EQ,
										value1: sType
									}));
								});
							} else {
								aFilters.push(new sap.ui.model.Filter({
									path: "code",
									operator: FilterOperator.EQ,
									value1: "empty"
								}));
							}
						}

						// Apply the filter to the cell's binding
						oCell.getBinding("items").filter(aFilters);
					}
				});
			}
		},

		/*
		*
		* Mass Assessment methods
		*
		*/

		/**
		* Set values of contributor field in a row, depending on the category value
		* @public
		*/
		setMassContributorItems: function (sSelectedKey, oContributorField) {
			let aFilters = [],
				oBinding = oContributorField.getBinding("items");

			if (sSelectedKey) {
				aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
			}

			oBinding.filter(aFilters);
		},

		/**
		* Set values of sustainability class field per each row, depending on the rcPreFlag value
		* @public
		*/
		setMassSustClass: function (oContext) {
			let aRows = this.getView().byId("massItems").getRows(),
				oRulesModel = this.getModel("rules").getProperty("/");

			aRows.forEach((oRow, index) => {
				this.setRowSustClass(oRow, oContext.getObject().toItems[index].rcPreFlag, oRulesModel);

			});

		},

		setRowSustClass: function (oRow, sRcPreFlag, oRulesModel) {
			let aCells = oRow.getCells(),
				aFilters = [];

			aCells.forEach((oCell) => {

				if (oCell.getId().includes("sustClassId")) {
					aFilters = [];
					if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag]["sustCodes"]) {
						const oRules = oRulesModel[sRcPreFlag]["sustCodes"];
						oRules.codes.forEach(sCode => {
							aFilters.push(new Filter("code", FilterOperator.EQ, sCode));
						});

						oCell.getBinding("items").filter(aFilters);
					}

				}

			});
		},

		/**
		* Set enabled fields per each row depending on Sustainability Class and rcPreFlag
		* @public
		*/
		setRowEnabledFields: function (oRow) {
			let aCells = oRow.getCells(),
				oContext = oRow.getBindingContext(),
				oRulesModel = this.getModel("rules").getProperty("/"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				sSustClass = oContext.getProperty("sustClass");

			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustClass]["massEnabled"];

				aCells.forEach((oCell) => {
					if (oCell.getId().includes("category1")) {
						if (oRules.category1) {
							oCell.setEnabled(true);
						} else {
							oCell.setEnabled(false);
						}
					} else if (oCell.getId().includes("category2")) {
						if (oRules.category2) {
							oCell.setEnabled(true);
						} else {
							oCell.setEnabled(false);
						}
					} else if (oCell.getId().includes("category3")) {
						if (oRules.category3) {
							oCell.setEnabled(true);
						} else {
							oCell.setEnabled(false);
						}
					}
				});

			}

		},

		setMassEnabledFields: function () {
			let aRows = this.getView().byId("massItems").getRows();

			aRows.forEach((oRow) => {

				this.setRowEnabledFields(oRow);

			});
		},

		/**
		* Reset category row fields value
		* @public
		*/
		resetMassCategoryFields: function (oRow) {
			let oContext = oRow.getBindingContext();

			oContext.setProperty("category1", "");
			oContext.setProperty("category2", "");
			oContext.setProperty("category3", "");
		},

		/**
		* Reset contributor row fields value
		* @public
		*/
		resetMassContributorFields: function (oRow) {
			let oContext = oRow.getBindingContext();

			oContext.setProperty("contributor1", "");
			oContext.setProperty("contributor2", "");
			oContext.setProperty("contributor3", "");
		},

		updatedRowFields: function (oContext) {
			let aRows = this.getView().byId("massItems").getRows(),
				oRulesModel = this.getModel("rules").getProperty("/");

			aRows.forEach((oRow, index) => {

				this.setRowSustClass(oRow, oContext.getObject().toItems[index].rcPreFlag, oRulesModel);
				this.setRowEnabledFields(oRow);

			});
		},

		openRecipientsDialog: async function (sStatus, sSbu, sProcessType) {

			await this.setRecipientsList(sStatus, sSbu, sProcessType);

			if (!this._notificationRecipientsDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.sustainability.overview.view.fragment.Assessment.NotificationsRecipientsDailog",
					controller: this
				}).then(function (oNotificationRecipientsDialog) {
					this._notificationRecipientsDialog = oNotificationRecipientsDialog;
					this.getView().addDependent(this._notificationRecipientsDialog);

					this._notificationRecipientsDialog.open();

				}.bind(this));
			} else {

				this._notificationRecipientsDialog.open();

			}

		},

		setRecipientsList: async function (sStatus, sSbu, sProcessType) {
			const oModel = this.getModel(),
				oContextBinding = oModel.bindContext("/GetUserFromMyId(...)");
			oContextBinding.setParameter("status", sStatus);
			oContextBinding.setParameter("sbu", sSbu);
			oContextBinding.setParameter("processType", sProcessType);

			await oContextBinding.execute().then(
				function () {
					const oContext = oContextBinding.getBoundContext(),
						aUsersEmail = (oContext.getObject().value);

					this.getModel("assessmentModel").setProperty("/recipientsList", aUsersEmail);
				}.bind(this)
			);
		}

	});

});