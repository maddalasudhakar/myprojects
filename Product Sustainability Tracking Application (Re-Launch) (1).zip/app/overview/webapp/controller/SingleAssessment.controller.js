sap.ui.define(
    [
        "./BaseController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/core/routing/History",
        "../model/formatter",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/Fragment",
    ],
    function (BaseController, JSONModel, MessageBox, History, formatter, Filter, FilterOperator, Fragment) {
        'use strict';

        return BaseController.extend('com.sustainability.overview.ext.assessment.SingleAssessment', {
            formatter: formatter,
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: function () {
                this.getRouter().getRoute("SingleAssessment").attachPatternMatched(this._onSingleAssessmentMatched, this);

                let oAssessmentModel = new JSONModel({
                    editMode: false,
                    firstAdditionalDetails: false,
                    secondAdditionalDetails: false,
                    proofEnabled: false,
                    approbeMode: false,
                    type: "",
                    prooftype: [],
                    contributors: [],
                    categories: [],
                    sustClass: [],
                    assesmentType: "",
                    approberDecision: "05",
                    productRelation: []
                });

                this.getView().setModel(oAssessmentModel, "assessmentModel");
            },

            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/
            onPropagationChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("propagation", bValue);
            },

            onCommunicationChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("externalCommunication", bValue);
            },

            onApproberDecisionChange: function () {
                let oContextDialog = this.getView().byId("SingleApprobeDialog").getBindingContext();
                oContextDialog.setProperty("approberComment", "");
            },

            onActiveChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("active", bValue);
            },

            handleLinkPress: function (oEvent) {
                let oModel = this.getModel(),
                    oProofPoint = oEvent.getSource().getBindingContext().getObject(),
                    baseUrl = oModel.getServiceUrl(),
                    sUploadURL = "";

                if (oProofPoint.externalUrl) {
                    sUploadURL = oProofPoint.url;
                } else {
                    sUploadURL = baseUrl + oProofPoint.url;
                }

                window.open(sUploadURL, '_blank');

            },
            /**
            *Add new line in proof point table
            * @public
            */
            onAddProofPoint: function () {
                let oProofTable = this.getView().byId("proofTableSingle"),
                    oBinding = oProofTable.getBinding("rows");
                oBinding.create({ "active": true }, true);
            },

            /**
            * Delete selected proof points
            * @public
            */
            onDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("proofTableSingle").getSelectedIndices(),
                    aContext = [],
                    oProofTable = this.getView().byId("proofTableSingle");


                if (aSelectedIndices.length > 0) {

                    let bShowError = aSelectedIndices.some(iIndex => {
                        let oContext = oProofTable.getContextByIndex(iIndex);
                        // If the documents is in Image master is not possible delete it
                        if (oContext.getProperty("imageMasterID")) {
                            return true;
                        }

                        aContext.push(oContext);
                        return false;
                    });

                    if (bShowError) {
                        MessageBox.error(this.getResourceBundle().getText("removeProofPointsError"));
                        return;
                    }

                    MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionProofPoints"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                aContext.forEach(oContext => {
                                    oContext.delete("UpdateGroup");
                                });
                            }
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory1Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor1Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }
                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory2Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor2Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }

                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Get dependet contributor on category.
            * @public
            */
            onCategory3Change: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContributorSelect = this.byId("contributor3Id"),
                    oBinding = oContributorSelect.getBinding("items"),
                    aFilters = [];

                if (sSelectedKey) {
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
                }

                oBinding.filter(aFilters);
                if (sSelectedKey === "00") {
                    oContributorSelect.setEnabled(false);
                } else {
                    oContributorSelect.setEnabled(true);
                }
                oContributorSelect.setSelectedKey("");
                this.onContributorChange();
            },

            /**
            * Reset sustainability class dependent fields.
            * @public
            */
            onClassChange: function (oEvent) {
                let sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    sRcPreFlag = oContext.getProperty("rcPreFlag");

                this.setDinamycFields(sSelectedKey, sRcPreFlag);

                let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);

                oContext.setProperty("category1", "", "UpdateGroup", true);
                oContext.setProperty("contributor1", "", "UpdateGroup", true);
                oContext.setProperty("category2", "", "UpdateGroup", true);
                oContext.setProperty("contributor2", "", "UpdateGroup", true);
                oContext.setProperty("category3", "", "UpdateGroup", true);
                oContext.setProperty("contributor3", "", "UpdateGroup", true);
                this.getView().byId("contributor1Id").setEnabled(false);
                this.getView().byId("contributor2Id").setEnabled(false);
                this.getView().byId("contributor3Id").setEnabled(false);

                this._checkTypeProofFields(oContext, true);
                this.setProofTypesOptions(oContext);
            },

            /**
            * Set valid proof types depending on the contributors.
            * @public
            */
            onContributorChange: function () {
                let oContext = this.getView().byId("ObjectPageLayout").getBindingContext();

                this._checkTypeProofFields(oContext, true);
                this.setProofTypesOptions(oContext);
                //let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                //this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);

            },

            onProofRowsUpdated: function () {
                let oContext = this.getView().byId("ObjectPageLayout").getBindingContext();
                if (oContext) {
                    if (Object.keys(oContext).length !== 0) {
                        this._checkTypeProofFields(oContext, true);
                        this.setProofTypesOptions(oContext);
                    }
                }
            },

            /**
            * Submit new assessment (set status to submited).
            * @public
            */
            onCancel: function () {
                if (this.getModel().hasPendingChanges("UpdateGroup")) {
                    MessageBox.confirm(this.getResourceBundle().getText("pendingChanges"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                this.getModel().resetChanges("UpdateGroup");
                                this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                                //this.getView().getModel("assessmentModel").setProperty("/approbeMode", false);
                            }
                        }.bind(this)
                    });
                } else {
                    this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                    //this.getView().getModel("assessmentModel").setProperty("/approbeMode", false);
                }

            },

            onFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oEvent.getParameter("files"),
                    oContext = oFileUploader.getBindingContext();

                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oContext.setProperty("content", sFileContent.split(',')[1], "UpdateGroup", true);
                        oContext.setProperty("fileName", oFile.name, "UpdateGroup", true);
                        oContext.setProperty("mediaType", oFile.type, "UpdateGroup", true);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            onPressApprobe: function () {
                let oContext = this.getView().byId("ObjectPageLayout").getBindingContext();
                if (!this._singleAssessmentApproberDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.SingleAssessmentApproberDialog",
                        controller: this
                    }).then(function (oSingleAssessmentApproberDialog) {
                        this._singleAssessmentApproberDialog = oSingleAssessmentApproberDialog;
                        this.getView().addDependent(this._singleAssessmentApproberDialog);
                        this._singleAssessmentApproberDialog.open();
                        this.getView().byId("SingleApprobeDialog").setBindingContext(oContext);
                    }.bind(this));
                } else {
                    this._singleAssessmentApproberDialog.open();
                    this.getView().byId("SingleApprobeDialog").setBindingContext(oContext);

                }
            },

            onPressCancelApprobe: function () {
                this.getModel().resetChanges("UpdateGroup");
                this.getModel("assessmentModel").setProperty("/approberDecision", "");

                this._singleAssessmentApproberDialog.close();
            },

            onOkNotificationsRecipientsDialog: async function () {
                const sAction = this.getModel("assessmentModel").getProperty("/userAction"),
                    oAssessmentContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    oModel = this.getModel(),
                    aSelectedContext = this.getView().byId("recipientsTableId").getSelectedContexts(),
                    sAssessmentID = oAssessmentContext.getProperty("ID"),
                    sStatus = sAction === "Save" ? "01" : "02";

                this.getView().setBusy(true);

                this.getView().byId("recipientsTableId").removeSelections();

                this.getModel("assessmentModel").setProperty("/userAction", "");
                this._notificationRecipientsDialog.close();

                if (!sAction) {
                    this.getView().setBusy(false);
                    return;
                }

                if ((!aSelectedContext || aSelectedContext.length === 0) && sAction === "Submit") {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("mandatoryRecipients"));

                    return;
                }

                // Build recipients payload for the action
                let aRecipients = [];
                if (aSelectedContext && aSelectedContext.length > 0) {
                    aRecipients = aSelectedContext
                        .map(oContext => oContext && oContext.getProperty("email"))
                        .filter(Boolean);
                }

                // If there is nothing to send and the user just saved, continue normal flow
                if (aRecipients.length === 0) {
                    if (sAction === "Save") {
                        await this._saveAssessment();
                    }
                    return;
                }

                try {
                    const oActionContext = oModel.bindContext("/saveRecipients(...)");
                    oActionContext.setParameter("assessmentId", sAssessmentID);
                    oActionContext.setParameter("recipientEmail", aRecipients);
                    oActionContext.setParameter("status", sStatus);


                    oActionContext.execute().then(
                        async function () {

                            // Continue with Save/Submit flows
                            if (sAction === "Save") {
                                await this._saveAssessment();
                            } else if (sAction === "Submit") {
                                await this._submitAssessment();
                            }
                        }.bind(this)
                    ).catch(function (oError) {
                        console.error("saveRecipients action error", oError);
                        this.getView().setBusy(false);

                    }.bind(this));
                } catch (oError) {
                    // Handle errors from action execution
                    this.getView().setBusy(false);

                    console.error("saveRecipients action error", oError);
                }
            },

            onSubmitApproberDecision: function () {
                let sStatus = this.getModel("assessmentModel").getProperty("/approberDecision"),
                    oModel = this.getModel(),
                    oContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                if ((sStatus === "03" || sStatus === "06") && !oContext.getProperty("approberComment")) {
                    MessageBox.error(this.getResourceBundle().getText("Mandatoryerror"));
                } else {
                    oContext.setProperty("status", sStatus, "UpdateGroup", true); //oContext.setProperty("status", sStatus);
                    this.getView().setBusy(true);
                    oModel.submitBatch("UpdateGroup").then(function (odata, second) {
                        this.getView().setBusy(false);
                        if (!oModel.hasPendingChanges("UpdateGroup")) {
                            MessageBox.information(this.getResourceBundle().getText("approvedDecisionGived"), {
                                onClose: function (sAction) {
                                    if (sAction === 'OK') {
                                        this.getView().getModel("assessmentModel").setProperty("/approbeMode", false);
                                        this.getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                    }
                                }.bind(this)
                            });
                        } else {
                            let aMessage = oMessageModel.getData(),
                                oLastMessage = aMessage[aMessage.length - 1];
                            MessageBox.error(oLastMessage.getMessage());
                        }
                    }.bind(this)).catch(function (oError) {
                        this.getView().setBusy(false);
                        MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                    }.bind(this));
                    this._singleAssessmentApproberDialog.close();
                }
            },

            /**
            * Delete Assessment.
            * @public
            */
            onPressDelete: function () {
                let oPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oPage.getBindingContext(),
                    oModel = this.getModel(),
                    oHistory = History.getInstance(),
                    sPreviousHash = oHistory.getPreviousHash(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();
                this.getView().setBusy(true);
                MessageBox.confirm(this.getResourceBundle().getText("confirmDeletion", oContext.getProperty("requestName")), {
                    onClose: function (sAction) {
                        if (sAction === 'OK') {
                            oContext.delete("UpdateGroup");
                            oModel.submitBatch("UpdateGroup").then(function () {
                                this.getView().setBusy(false);
                                if (!oModel.hasPendingChanges("UpdateGroup")) {
                                    if (sPreviousHash !== undefined) {
                                        window.history.go(-1);
                                    }
                                } else {
                                    let aMessage = oMessageModel.getData(),
                                        oLastMessage = aMessage[aMessage.length - 1];
                                    MessageBox.error(oLastMessage.getMessage());
                                }
                            }.bind(this)).catch(function (oError) {
                                MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                            }.bind(this));
                        }
                    }.bind(this)
                });
            },

            /**
            * change the screen from visualizatio to edition mode.
            * @public
            */
            onPressEdit: function () {
                let sStatus = this.getView().byId("ObjectPageLayout").getBindingContext().getProperty("status");

                this.getView().getModel("assessmentModel").setProperty("/editMode", true);

                /*if (sStatus === "02" || sStatus === "04") {
                    this.getView().getModel("assessmentModel").setProperty("/approbeMode", true);
                }*/
            },

            /**
            * Submit new assessment (set status to submited).
            * @public
            */
            onSubmit: async function () {
                const oContext = this.getView().byId("ObjectPageLayout").getBindingContext()
                this.getModel("assessmentModel").setProperty("/userAction", "Submit");

                this.openRecipientsDialog("02", oContext.getProperty("sbu"), "");
            },

            /**
            * Save new assessment(set status to saved)
            * @public
            */
            onSave: function () {
                const oContext = this.getView().byId("ObjectPageLayout").getBindingContext()
                this.getModel("assessmentModel").setProperty("/userAction", "Save");

                this.openRecipientsDialog("01", oContext.getProperty("sbu"), "");
            },

            /**
            * Show first block od additional fields.
            * @public
            */
            onShowFirstAdditionalDetails: function () {
                this.getView().byId("category2block").setVisible(true);
                this.getView().byId("contributor2block").setVisible(true);
                this.getView().byId("additionalButton2block").setVisible(true);
                this.getView().byId("additionalButton1block").setVisible(false);
            },

            /**
            * Show second block od additional fields.
            * @public
            */
            onShowSecondtAdditionalDetails: function () {
                this.getView().byId("category3block").setVisible(true);
                this.getView().byId("contributor3block").setVisible(true);
                this.getView().byId("additionalButton2block").setVisible(false);
            },

            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/

            _onSingleAssessmentMatched: async function (oEvent) {
                let oView = this.getView().byId("ObjectPageLayout"),
                    oMasterDataForm = this.getView().byId("productMasterData"),
                    oChemestryPreCheck = this.getView().byId("chemestryPreCheck"),
                    sId = oEvent.getParameter("arguments").assessment,
                    //sType = oEvent.getParameter("arguments").type,
                    sAssessmentType = oEvent.getParameter("arguments").assesmentType,
                    aComposedRoles = this.getModel("ui").getProperty("/userParameters/composedRoles"),
                    aProofTypes = [],
                    aContributors = [],
                    aCategories = [],
                    aSustClass = [];

                this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                //oMasterDataForm.bindElement({ path: "toProductData" });
                //oChemestryPreCheck.bindElement({ path: "toProductData" });
                this.getView().setBusy(true);

                if (!aComposedRoles || aComposedRoles.length < 1) {
                    const oModel = this.getModel(),
                        oUserParametersBinding = oModel.bindContext("/GetUserParameters(...)"),
                        oGetRulesModelBiding = oModel.bindContext("/GetRulesModel(...)");

                    await oGetRulesModelBiding.execute().then(
                        function () {
                            let oActionContext = oGetRulesModelBiding.getBoundContext(),
                                sRulesModel = (oActionContext.getObject().value),
                                oRlesModel = JSON.parse(sRulesModel);
                            this.getModel("rules").setProperty("/", oRlesModel);

                        }.bind(this)
                    );

                    await oUserParametersBinding.execute().then(
                        function () {
                            let oActionContext = oUserParametersBinding.getBoundContext(),
                                oUserParameters = (oActionContext.getObject().value);

                            this.getModel("ui").setProperty("/userParameters", oUserParameters);
                            aComposedRoles = oUserParameters.composedRoles;

                        }.bind(this)
                    );
                }

                oView.bindElement({
                    path: "/" + "SingleAssessment(" + sId + ")",
                    parameters: {
                        //bKeepAlive: true, // Mantener el contexto vivo
                        $expand: {
                            toProofDocuments: {
                                $select: '*'
                            }
                        },
                        $select: '*'

                    },
                    events: {
                        change: function (oEvent) {
                        }.bind(this),
                        dataRequested: function () {
                            this.getView().setBusy(true);
                        }.bind(this),
                        dataReceived: async function (oData) {
                            let sUserId = this.getModel("ui").getProperty("/userParameters/userId"),
                                oContext = this.getView().byId("ObjectPageLayout").getBindingContext(),
                                sSbu = oContext.getProperty("sbu"),
                                sStatus = oContext.getProperty("toStatus/code"),
                                sRcPreFlag = oContext.getProperty("rcPreFlag"),
                                sSustClass = oContext.getProperty("sustClass"),
                                sAssessor = oContext.getProperty("assessor"),
                                sSubmitter = oContext.getProperty("submitter"),
                                sApprover = oContext.getProperty("approver");

                            aProofTypes = await this.getProofTypes();
                            aContributors = await this.getContributors();
                            aCategories = await this.getCategories();
                            aSustClass = await this.getSustClass();
                            this.getModel("assessmentModel").setProperty("/contributors", aContributors);
                            this.getModel("assessmentModel").setProperty("/categories", aCategories);
                            this.getModel("assessmentModel").setProperty("/sustClass", aSustClass);
                            this.getModel("assessmentModel").setProperty("/proofType", aProofTypes);

                            this.getModel("assessmentModel").setProperty("/type", oContext.getProperty("productType"));
                            this.getModel("assessmentModel").setProperty("/assesmentType", "S");
                            this.getModel("assessmentModel").setProperty("/editMode", false);
                            this.getModel("assessmentModel").setProperty("/approbeMode", false);

                            // First case: Status is "" or 01 or 03, user has Submitter role, and sUserId matches sAssessor or sSubmitter
                            if ((sStatus === "" || sStatus === "01" || sStatus === "03") &&
                                aComposedRoles.some(role => role === sSbu + ".Submitter") &&
                                (sUserId === sSubmitter || sUserId === sAssessor || sSubmitter === "")) {

                                // User can edit, delete, submit, and save
                                this.getView().byId("editButton").setVisible(true);
                                if (sStatus === "01") {
                                    this.getView().byId("deleteButton").setVisible(true);
                                } else {
                                    this.getView().byId("deleteButton").setVisible(false);
                                }

                                this.getView().byId("submitButton").setVisible(true);  // Submitter can be Assessor or Submitter
                                this.getView().byId("saveButton").setVisible(true);

                                // Second case: Status is "" or 01, user has Assessor role, and sUserId matches sAssessor
                            } else if ((sStatus === "" || sStatus === "01") &&
                                aComposedRoles.some(role => role === sSbu + ".Assessor")) {
                                //&& sUserId === sAssessor) {

                                // User can edit, delete, and save but cannot submit
                                this.getView().byId("editButton").setVisible(true);
                                this.getView().byId("deleteButton").setVisible(true);
                                this.getView().byId("submitButton").setVisible(false);  // Only Submitter sees the submit button
                                this.getView().byId("saveButton").setVisible(true);

                                // Third case: Status is 02 or 04, user has Approver role, and sUserId matches sApprover
                            } else if ((sStatus === "02" || sStatus === "04") &&
                                aComposedRoles.some(role => role === sSbu + ".Approver") &&
                                (sUserId === sApprover || sApprover === "")) {

                                // User can edit but no delete, submit, or save
                                this.getView().byId("editButton").setVisible(true);
                                this.getModel("assessmentModel").setProperty("/approbeMode", true);
                                this.getView().byId("submitButton").setVisible(false);  // Only Submitter sees the submit button
                                this.getView().byId("saveButton").setVisible(false);

                                // Default case: None of the conditions are met
                            } else {
                                // Hide all buttons (edit, delete, submit, save)
                                this.getView().byId("editButton").setVisible(false);
                                this.getView().byId("deleteButton").setVisible(false);
                                this.getView().byId("submitButton").setVisible(false);
                                this.getView().byId("saveButton").setVisible(false);
                            }

                            if (sSustClass === "" || sSustClass === undefined || sSustClass === null) {
                                sSustClass = "sustCodes";
                            }
                            this.setDinamycFields(sSustClass, sRcPreFlag);
                            this.filterSustClass("sustCodes", sRcPreFlag);
                            this._setAssessmentDetailsFields(oContext);
                            this.setProofTypesOptions(oContext);

                            this._checkTypeProofFields(oContext, true);
                            let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                            this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);

                            if ((sStatus !== "01" && sStatus !== '03')) {
                                this.getModel("assessmentModel").setProperty("/proofEnabled", false);
                            }
                            let aRelatedProducts = await this.getRelatedProductsData(oContext.getProperty("productType"), oContext.getProperty("product"));
                            this.getModel("assessmentModel").setProperty("/productRelation", aRelatedProducts);
                            this.getView().setBusy(false);
                        }.bind(this)
                    }
                });

            },

            _saveAssessment: async function () {
                let oModel = this.getModel(),
                    oObjectPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oObjectPage.getBindingContext(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages()

                if (oContext.getProperty("status") === "01") {
                    oContext.setProperty("status", "01", "UpdateGroup", true);
                }
                //oContext.setProperty("status", "01");
                this.getView().setBusy(true);
                oModel.submitBatch("UpdateGroup").then(function (odata, second) {
                    this.getView().setBusy(false);
                    if (!oModel.hasPendingChanges("UpdateGroup")) {
                        MessageBox.information(this.getResourceBundle().getText("assessmentSaved"));
                        this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                    } else {
                        let aMessage = oMessageModel.getData(),
                            oLastMessage = aMessage[aMessage.length - 1];
                        MessageBox.error(oLastMessage.getMessage());
                    }

                }.bind(this)).catch(function (oError) {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                }.bind(this));

            },

            _submitAssessment: async function () {
                let oModel = this.getModel(),
                    oObjectPage = this.getView().byId("ObjectPageLayout"),
                    oContext = oObjectPage.getBindingContext(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                let oContinue = await this.checkMandatoryFields(oContext);

                if (oContinue.items && oContinue.prooPoints) {
                    if (oContext.getProperty("status") === "01") {
                        oContext.setProperty("status", "02", "UpdateGroup", true);

                    } else {
                        oContext.setProperty("status", "04", "UpdateGroup", true);
                    }

                    //oModel.submitBatch("UpdateGroup");
                    this.getView().setBusy(true);
                    oModel.submitBatch("UpdateGroup").then(function (odata, second) {
                        this.getView().setBusy(false);
                        if (!oModel.hasPendingChanges("UpdateGroup")) {
                            MessageBox.information(this.getResourceBundle().getText("assessmentSubmited"), {
                                onClose: function (sAction) {
                                    if (sAction === 'OK') {
                                        this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                                        this.getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                    }
                                }.bind(this)
                            });
                        } else {
                            let aMessage = oMessageModel.getData(),
                                oLastMessage = aMessage[aMessage.length - 1];
                            MessageBox.error(oLastMessage.getMessage());
                        }
                    }.bind(this)).catch(function (oError) {
                        this.getView().setBusy(false);
                        MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                    }.bind(this));
                } else {
                    this.getView().setBusy(false);
                    if (!oContinue.prooPoints) {
                        MessageBox.information(this.getResourceBundle().getText("mandatoryProofPointError"));
                    } else {
                        MessageBox.information(this.getResourceBundle().getText("assessmentErrors"));
                    }
                }

            },

            /**
            * Set visualization of Assessment details block.
            * @private
            */
            _setAssessmentDetailsFields: function (oContext) {
                let sCategory1 = oContext.getProperty("category1"),
                    sContributor1 = oContext.getProperty("contributor1"),
                    sCategory2 = oContext.getProperty("category2"),
                    sContributor2 = oContext.getProperty("contributor2"),
                    sCategory3 = oContext.getProperty("category3"),
                    sContributor3 = oContext.getProperty("contributor3"),
                    aFilters = [];

                if ((sCategory1 !== "" && sCategory1 !== "00" && sCategory1 !== null) || (sContributor1 !== "" && sContributor1 !== null)) {
                    this.getView().byId("category1block").setVisible(true);
                    this.getView().byId("contributor1block").setVisible(true);
                    this.getView().byId("additionalButton1block").setVisible(true);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory1));
                    this.getView().byId("contributor1Id").getBinding("items").filter(aFilters);
                }
                if ((sCategory2 !== "" && sCategory2 !== "00" && sCategory2 !== null) || (sContributor2 !== "" && sContributor2 !== null)) {
                    this.getView().byId("category2block").setVisible(true);
                    this.getView().byId("contributor2block").setVisible(true);
                    this.getView().byId("additionalButton1block").setVisible(false);
                    this.getView().byId("additionalButton2block").setVisible(true);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory2));
                    this.getView().byId("contributor2Id").getBinding("items").filter(aFilters);
                }
                if ((sCategory3 !== "" && sCategory3 !== "00" && sCategory3 !== null) || (sContributor3 !== "" && sContributor3 !== null)) {
                    this.getView().byId("category3block").setVisible(true);
                    this.getView().byId("contributor3block").setVisible(true);
                    this.getView().byId("additionalButton2block").setVisible(false);

                    aFilters = [];
                    aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sCategory3));
                    this.getView().byId("contributor3Id").getBinding("items").filter(aFilters);

                }

                if (sCategory1 !== "" && sCategory1 !== null) {
                    this.getView().byId("contributor1Id").setEnabled(true);
                }
                if (sCategory2 !== "" && sCategory2 !== null) {
                    this.getView().byId("contributor2Id").setEnabled(true);
                }
                if (sCategory2 !== "" && sCategory2 !== null) {
                    this.getView().byId("contributor3Id").setEnabled(true);
                }

            },

            /*_uploadAllFiles: async function () {
                let oTable = this.getView().byId("proofTable"),
                    oModel = this.getModel(),
                    aItems = oTable.getItems(),
                    oAssessment = this.getView().byId("ObjectPageLayout").getBindingContext().getObject();
                

                let baseUrl = oModel.getServiceUrl() + "ProofDocument";

                aItems.forEach((oItem, iIndex) => {
                    let oFileUploader = oItem.getCells()[2],
                        sUploadURL = baseUrl + "(" + oAssessment.toProofDocuments[iIndex].ID + ")/content";

                    if (oFileUploader && oFileUploader.getValue()) {
                        oFileUploader.setUploadUrl(sUploadURL);
                        oFileUploader.setSendXHR(true);
                        oFileUploader.upload();
                    }
                });

            }*/

        });
    }
);