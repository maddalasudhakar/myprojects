sap.ui.define(
    [
        './BaseController'
    ],
    function (BaseController) {
        'use strict';

        return BaseController.extend('com.sustainability.overview.controller.Main', {
            /**
            * Called when a controller is instantiated and its View controls (if available) are already created.
            * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
            */
            onInit: function () {
                this.getRouter().getRoute("Main").attachPatternMatched(this._onMainMatched, this);
            },

            onPress: function (oEvent) {
                oEvent.getParameter("listItem").setSelected(false);
                if (oEvent.getParameter("listItem").getId().includes("createAssessment")) {
                    this.getRouter().navTo("ProductOverview");
                } else {
                    this.getRouter().navTo("AssessmentOverview");
                }

            },

            _onMainMatched: function () {
                let sStartupParameter = this.getModel("ui").getProperty("/startupParameter");

                if (sStartupParameter === "assessments") {
                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                }
            }
        });
    }
);
