sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'com/sustainability/overview/test/integration/FirstJourney',
		'com/sustainability/overview/test/integration/pages/IdhMain'
    ],
    function(JourneyRunner, opaJourney, IdhMain) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('com/sustainability/overview') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheIdhMain: IdhMain
                }
            },
            opaJourney.run
        );
    }
);