sap.ui.define([], () => {
	"use strict";

	return {

		proofDocumentsButtonType: function (toProofDocuments) {
			return toProofDocuments && toProofDocuments.length > 0 ? "Emphasized" : "Default";
		},

		formCategory1visible: function (sSustClass, sRcPreFlag) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;
			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			// Apply visibility and enable/disable rules based on sSelectedKey and sRcPreFlag
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["show"];
				return oRules.category1;
			}
			return false;
		},

		formCategory1State: function (sSustClass, sRcPreFlag, sCategory1) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.category1 && (sCategory1 === "" || sCategory1 === "00" || sCategory1 === null || sCategory1 === undefined)) {
					return "Error"

				}
			}
			return "None";
		},

		formCategory1StateText: function (sSustClass, sRcPreFlag, sCategory1) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.category1 && (sCategory1 === "" || sCategory1 === "00" || sCategory1 === null || sCategory1 === undefined)) {
					return this.getResourceBundle().getText("mandatoryField");

				}
			}
			return "";
		},

		formContributor1Enabled: function (sSustClass, sCategory1) {

		},

		formContributor1State: function (sSustClass, sRcPreFlag, sContributor1, sCategory1) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.contributor1 && (sContributor1 === "" || sContributor1 === null || sContributor1 === undefined)) {
					return "Error"

				}
			}
			if (sCategory1 && !sContributor1) {
				return "Error"
			}
			return "None";
		},

		formContributor1StateText: function (sSustClass, sRcPreFlag, sContributor1, sCategory1) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.contributor1 && (sContributor1 === "" || sContributor1 === null || sContributor1 === undefined)) {
					return this.getResourceBundle().getText("mandatoryField");

				}
			}
			if (sCategory1 && !sContributor1) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formContributor2State: function (sCategory2, sContributor2) {
			if ((sCategory2 !== "" && sCategory2 !== "00" && sCategory2 !== undefined && sCategory2 !== null) && (sContributor2 === "" || sContributor2 === undefined || sContributor2 === null)) {
				return "Error"
			}
			return "None";
		},

		formContributor2StateText: function (sCategory2, sContributor2) {
			if ((sCategory2 !== "" && sCategory2 !== "00" && sCategory2 !== undefined && sCategory2 !== null) && (sContributor2 === "" || sContributor2 === undefined || sContributor2 === null)) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formContributor3State: function (sCategory3, sContributor3) {
			if ((sCategory3 !== "" && sCategory3 !== "00" && sCategory3 !== undefined && sCategory3 !== null) && (sContributor3 === "" || sContributor3 === undefined || sContributor3 === null)) {
				return "Error"
			}
			return "None";
		},

		formContributor3StateText: function (sCategory3, sContributor3) {
			if ((sCategory3 !== "" && sCategory3 !== "00" && sCategory3 !== undefined && sCategory3 !== null) && (sContributor3 === "" || sContributor3 === undefined || sContributor3 === null)) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formCommentState: function (sSustClass, sRcPreFlag, sComment) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.comment && (sComment === "" || sComment === null || sComment === undefined)) {
					return "Error"

				}
			}
			return "None";
		},

		formCommentStateText: function (sSustClass, sRcPreFlag, sComment) {
			let oRulesModel = this.getModel("rules").getProperty("/"),
				sSustainabilityClass = sSustClass;

			if (sSustClass === null || sSustClass === undefined || sSustClass === "") {
				sSustainabilityClass = "sustCodes";
			}
			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustainabilityClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustainabilityClass]["mandatory"];
				if (oRules.comment && (sComment === "" || sComment === null || sComment === undefined)) {
					return this.getResourceBundle().getText("mandatoryField");
				}
			}
			return "";
		},

		formProofDescriptionState: function (sDescription, sImageMasterId) {
			if (!sDescription && !sImageMasterId) {
				return "Error";
			}
			return "None";
		},

		formProofDescriptionStateText: function (sDescription, sImageMasterId) {
			if (!sDescription && !sImageMasterId) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formProofTypeState: function (sType, sImageMasterId) {
			if (!sType && !sImageMasterId) {
				return "Error";
			}
			return "None";
		},

		formProofTypeStateText: function (sType, sImageMasterId) {
			if (!sType && !sImageMasterId) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		RequestName: function (sRequestName) {
			if (!sRequestName) {
				return "Error";
			}
			return "None";
		},

		formRequestNameStateText: function (sRequestName) {
			if (!sRequestName) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formSustClassState: function (sSustClass) {
			if (!sSustClass) {
				return "Error";
			}
			return "None";
		},

		formSustClassStateText: function (sSustClass) {
			if (!sSustClass) {
				return this.getResourceBundle().getText("mandatoryField");
			}
			return "";
		},

		formApproberCommentState: function (sAproberDecision, sApproberComment) {
			if ((sAproberDecision === "03" || sAproberDecision === "06") && !sApproberComment) {
				return "Error";
			}

			return "None";
		},

		formApproberCommentStateText: function (sAproberDecision, sApproberComment) {
			if ((sAproberDecision === "03" || sAproberDecision === "06") && !sApproberComment) {
				return this.getResourceBundle().getText("mandatoryField");
			}

			return "";
		},

		getIconCommunicationStatus: function (sCommunicationStatus, status) {
			if (!sCommunicationStatus && (status === "05" || status === "06" || status === "08")) {
				if (status === "05" || status === "06" || status === "08") {
					return "sap-icon://accept";
				} else {
					return "";
				}
			} else {
				switch (sCommunicationStatus) {
					case "01":
					case "02":
					case "03":
					case "04":
						return "sap-icon://pending";
					case "05": return "sap-icon://accept";
					default: return "";
				}
			}

		},

		getIconCommunicationStatusColor: function (sCommunicationStatus) {
			switch (sCommunicationStatus) {
				case "01":
				case "02":
				case "03":
				case "04":
					return "#e78c07";
				case "05": return "#107e3e";
				default: return "";
			}
		},

		heartLineTypeText: function (sLineType) {
			if (sLineType === 'LAST') return 'Old version';
			if (sLineType === 'NEW') return 'New version';
			if (sLineType === 'DIFF') return 'Delta';
		},

		sustClassFormatter: function (sustClassCode, sustClassMaster) {
			const oSustClass = sustClassMaster.find(item => item.code === sustClassCode);
			return oSustClass?.description || '';
		},

		approveCommetTextAreaVisible: function (approberDataBlock, processType, approbalStatus) {
			return approberDataBlock && (processType !== 'HRT' || approbalStatus !== '06');
		},

	};
});