sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.sustainability.overview.Component", {
            metadata: {
                manifest: "json"
            },

            init: function () {
                Component.prototype.init.apply(this);
                let oModel = this.getModel(),
                    oActionODataContextBinding = oModel.bindContext("/GetUserParameters(...)"),
                    oGetRulesModelBiding = oModel.bindContext("/GetRulesModel(...)"),
                    //sStartupParameter = this.getComponentData().startupParameters.application[0],
                    sStartupParameter = this.getComponentData()?.startupParameters?.application?.[0] || "",

                    oRoles = {
                        "Viewer": false,
                        "Assessor": false,
                        "Submitter": false,
                        "Approver": false,
                        "ViewerPlus": false,
                        "ITTechnicalMaintenance": false
                    },
                    aSbu = [];

                this.setModel(sap.ui.getCore().getMessageManager().getMessageModel(), "message");

                oGetRulesModelBiding.execute().then(
                    function () {
                        let oActionContext = oGetRulesModelBiding.getBoundContext(),
                            sRulesModel = (oActionContext.getObject().value),
                            oRlesModel = JSON.parse(sRulesModel);
                        this.getModel("rules").setProperty("/", oRlesModel);
                        oActionODataContextBinding.execute().then(
                            function () {
                                let oActionContext = oActionODataContextBinding.getBoundContext(),
                                    oUserParameters = (oActionContext.getObject().value);

                                this.getModel("ui").setProperty("/userParameters", oUserParameters);
                                this.getModel("ui").setProperty("/startupParameter", sStartupParameter);

                                 if (sStartupParameter === "assessments" || sStartupParameter === "approval") {
                                    this.getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                } else if (sStartupParameter === "overview") {
                                    this.getRouter().navTo("Main", undefined, undefined, true);
                                }
                                
                            }.bind(this)
                        );

                    }.bind(this)
                );

            }
        });
    }
);