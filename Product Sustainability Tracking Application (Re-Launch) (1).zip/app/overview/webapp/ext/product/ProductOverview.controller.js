sap.ui.define(
    [
        "sap/fe/core/PageController",
        "sap/m/MessageBox",
        "sap/ui/core/Fragment",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/model/json/JSONModel"
    ],
    function (PageController, MessageBox, Fragment, Filter, FilterOperator, JSONModel) {
        'use strict';

        return PageController.extend('com.sustainability.overview.ext.product.ProductOverview', {
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: async function () {
                PageController.prototype.onInit.apply(this);
                this.getAppComponent().getRouter().getRoute("ProductOverview").attachPatternMatched(this._onProductOverviewMatched, this);

                let oProductModel = new JSONModel({
                    onlyDocuments: false
                });

                this.setModel(oProductModel, "productModel");
            },



            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/


            onCancelNewAssessment: function () {
                let oContext = this.getView().getModel("ui").getProperty("/oContext");;
                oContext.delete("UpdateGroup", false);
                this._newAssessmentDialog.close();
            },

            onChangeRequestName: function (oEvent) {
                let sValue = oEvent.getSource().getValue();
                if (sValue === "" || sValue === undefined) {
                    oEvent.getSource().setValueState("Error");
                    oEvent.getSource().setValueStateText("Mandatory field");
                    this.getView().byId("idCreateButton").setEnabled(false);
                } else {
                    oEvent.getSource().setValueState("None");
                    oEvent.getSource().setValueStateText("");
                    this.getView().byId("idCreateButton").setEnabled(true);
                }
            },

            onCreateNewAssessment: function () {
                let sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey(),
                    oContext = this.getView().getModel("ui").getProperty("/oContext"),
                    oModel = this.getModel();
                this._newAssessmentDialog.close();

                this.getView().setBusy(true);

                if (oContext.getProperty("assesmentType") === "S") {
                    this.getView().setBusy(false);
                    this.routing.navigateToRoute("NewSingleAssessment", { type: sSelectedKey }, undefined, true);
                    //this.getAppComponent().getRouter().navTo("NewSingleAssessment", { type: sSelectedKey }, undefined, true);
                } else {
                    oModel.submitBatch("UpdateGroup")
                        .then(function () {
                            this.getView().setBusy(false);
                            var oCreatedData = oContext.getObject();
                            this.routing.navigateToRoute("NewMassAssessment", { assessment: oCreatedData.ID, onlyDocuments: false }, undefined, true);
                        }.bind(this))
                        .catch(function (oError) {
                            this.getView().setBusy(false);
                            MessageBox.error(this.getResourceBundle().getText("errorCreatingAssessment"))
                            this.getModel().resetChanges("UpdateGroup");
                        }.bind(this));
                    //this.routing.navigateToRoute("NewMassAssessment", { type: sSelectedKey }, undefined, true);
                    //this.getAppComponent().getRouter().navTo("NewMassAssessment", { assessment: sSelectedKey }, undefined, true);
                }

            },

            onCreateMassAssessment: async function () {
                let sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey(),
                    oModel = this.getAppComponent().getModel(),
                    oListBinding = oModel.bindList("/MassAssessmentHeader", undefined, undefined, undefined, { $$updateGroupId: "UpdateGroup" }),
                    oContext,
                    aSelectedContext,
                    bValidationsOk = false,
                    bPropagation = false;

                this.getView().setBusy(true);

                this.getView().getModel("productModel").setProperty("/onlyDocuments", false);

                if (sSelectedKey === "IB") {
                    aSelectedContext = this.getView().byId("ibTable").getSelectedContexts();
                } else {
                    aSelectedContext = this.getView().byId("idhTable").getSelectedContexts();
                    bPropagation = true;
                }

                let aProducts = await this._getProductsData(aSelectedContext);

                bValidationsOk = await this._validateNewAssessment(aProducts);

                if (bValidationsOk) {
                    this._createMassAssessmentAfterValidationsOK(aProducts);
                    // const aProductMasterData = await this._getProductMasterData(aProducts, sSelectedKey);
                    // const aProductDocuments = await this._getProductsDocuments(aProducts, sSelectedKey);

                    // //const aProductMasterDataChecked = this.checkProductMasterData(aProductMasterData);

                    // let aItems = await Promise.all(aProducts.map(item => {
                    //     let oProductData = aProductMasterData.find(oProduct => oProduct.product === item.materialtNumber);
                    //     let aMappedDocuments = aProductDocuments.filter(oDocument => oDocument.product === item.materialtNumber)
                    //         .map(oDocument => ({
                    //             type: oDocument.type,
                    //             description: oDocument.description,
                    //             internalPath: "",
                    //             fileName: oDocument.fileName,
                    //             mediaType: oDocument.mediaType,
                    //             content: null,
                    //             active: oDocument.active !== null ? oDocument.active : true,
                    //             url: oDocument.url,
                    //             externalUrl: oDocument.externalUrl,
                    //             imageMasterID: oDocument.proofPointId,
                    //             productReference: oDocument.productReference
                    //         }));
                    //     return {
                    //         product: item.materialtNumber,
                    //         productType: sSelectedKey,
                    //         sustClass: item.sustClass,
                    //         category1: item.category,
                    //         contributor1: item.contributor,
                    //         category2: item.category2,
                    //         contributor2: item.contributor2,
                    //         category3: item.category3,
                    //         contributor3: item.contributor3,
                    //         rcPreFlag: oProductData.rcPreFlag,
                    //         sbu: item.sbu,
                    //         propagation: bPropagation,
                    //         externalCommunication: false,
                    //         approberComment: "",
                    //         //toProductData: oProductData ? oProductData : null,
                    //         rcPreFlagDescription: oProductData.rcPreFlagDescription,
                    //         productName: oProductData.productName,
                    //         technologyL2Key: oProductData.technologyL2Key,
                    //         technologyLevel2: oProductData.technologyLevel2,
                    //         sustainabilityClassCode: oProductData.sustainabilityClassCode,
                    //         existingSustainabilityClass: oProductData.existingSustainabilityClass,
                    //         realSubstanceCode: oProductData.realSubstanceCode,
                    //         realSubstanceName: oProductData.realSubstanceName,
                    //         region: oProductData.region,
                    //         applicationLevel2Key: oProductData.applicationLevel2Key,
                    //         applicationLevel2: oProductData.applicationLevel2,
                    //         lastAssessment: oProductData.lastAssessment,
                    //         lastSubmitter: oProductData.lastSubmitter,
                    //         lastApprover: item.approver,
                    //         toProofDocuments: aMappedDocuments
                    //     };
                    // })
                    // );

                    // aItems = await this.checkAssessmentData(aItems);

                    // oContext = await oListBinding.create({
                    //     "requestName": "",
                    //     "sbu": aProducts[0].sbu,
                    //     "assessor": "",
                    //     "submitter": "",
                    //     "approver": "",
                    //     "productType": sSelectedKey,
                    //     "assesmentType": "M",
                    //     "status": "01",
                    //     "projectId": "",
                    //     "toItems": aItems
                    // }, (aItems?.length > 500));
                    // this._openNewAssessmentDialog(oContext, "Mass");
                    // this.getView().getModel("ui").setProperty("/oContext", oContext);
                    // this.getView().getModel("ui").setProperty("/aItems", aItems);

                }

                this.getView().setBusy(false);
            },

            onPressOnlyDocuments: async function () {
                let sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey(),
                    oModel = this.getAppComponent().getModel(),
                    oListBinding = oModel.bindList("/MassAssessmentHeader", undefined, undefined, undefined, { $$updateGroupId: "UpdateGroup" }),
                    oContext,
                    aSelectedContext,
                    bValidationsOk = false,
                    bPropagation = false;

                this.getView().getModel("productModel").setProperty("/onlyDocuments", true);

                this.getView().setBusy(true);

                if (sSelectedKey === "IB") {
                    aSelectedContext = this.getView().byId("ibTable").getSelectedContexts();
                } else {
                    aSelectedContext = this.getView().byId("idhTable").getSelectedContexts();
                    bPropagation = true;
                }

                let aProducts = await this._getProductsData(aSelectedContext);

                bValidationsOk = await this._validateNewAssessment(aProducts, true);

                if (bValidationsOk) {
                    this._createMassAssessmentAfterValidationsOK(aProducts);
                }

                this.getView().setBusy(false);

            },

            onCreateSingleAssessment: async function () {
                let sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey(),
                    oModel = this.getAppComponent().getModel(),
                    oListBinding = oModel.bindList("/SingleAssessment", undefined, undefined, undefined, { $$updateGroupId: "UpdateGroup" }),
                    oContext,
                    aSelectedContext,
                    bValidationsOk = false,
                    bPropagation = false,
                    aAssessment = [],
                    oAssessment = {};

                this.getView().setBusy(true);

                this.getView().getModel("productModel").setProperty("/onlyDocuments", false);

                if (sSelectedKey === "IB") {
                    aSelectedContext = this.getView().byId("ibTable").getSelectedContexts();
                } else {
                    aSelectedContext = this.getView().byId("idhTable").getSelectedContexts();
                    bPropagation = true;
                }

                let aProducts = await this._getProductsData(aSelectedContext);

                bValidationsOk = await this._validateNewAssessment(aProducts);

                if (bValidationsOk) {
                    const aProductDocuments = await this._getProductsDocuments(aProducts, sSelectedKey);
                    const aProductMasterData = await this._getProductMasterData(aProducts, sSelectedKey);

                    const aMappedDocuments = await Promise.all(aProductDocuments.map(oDocument => ({
                        //ID: oDocument.proofPintId,
                        type: oDocument.type,
                        description: oDocument.description,
                        internalPath: "",
                        fileName: oDocument.fileName,
                        mediaType: oDocument.mediaType,
                        content: null,
                        active: oDocument.active !== null ? oDocument.active : true,
                        url: oDocument.url,
                        externalUrl: oDocument.externalUrl,
                        imageMasterID: oDocument.proofPointId,
                        productReference: oDocument.productReference
                    }))
                    );


                    oAssessment = {
                        "requestName": aProducts[0].materialDescription,
                        "sbu": aProducts[0].sbu,
                        "assessor": "",
                        "submitter": "",
                        "approver": "",
                        "productType": sSelectedKey,
                        "assesmentType": "S",
                        "status": "01",
                        "projectId": "",
                        "sustClass": aProducts[0].sustClass,
                        "category1": aProducts[0].category,
                        "contributor1": aProducts[0].contributor,
                        "category2": aProducts[0].category2,
                        "contributor2": aProducts[0].contributor2,
                        "category3": aProducts[0].category3,
                        "contributor3": aProducts[0].contributor3,
                        "product": aProducts[0].materialtNumber,
                        "rcPreFlag": aProductMasterData[0].rcPreFlag,
                        "rcPreFlagDescription": aProductMasterData[0].rcPreFlagDescription,
                        "externalCommunication": false,
                        "propagation": bPropagation,
                        "approberComment": "",
                        "productName": aProductMasterData[0].productName,
                        "technologyL2Key": aProductMasterData[0].technologyL2Key,
                        "technologyLevel2": aProductMasterData[0].technologyLevel2,
                        "sustainabilityClassCode": aProductMasterData[0].sustainabilityClassCode,
                        "existingSustainabilityClass": aProductMasterData[0].existingSustainabilityClass,
                        "realSubstanceCode": aProductMasterData[0].realSubstanceCode,
                        "realSubstanceName": aProductMasterData[0].realSubstanceName,
                        "region": aProductMasterData[0].region,
                        "applicationLevel2Key": aProductMasterData[0].applicationLevel2Key,
                        "applicationLevel2": aProductMasterData[0].applicationLevel2,
                        "lastAssessment": aProductMasterData[0].lastAssessment,
                        "lastSubmitter": aProductMasterData[0].lastSubmitter,
                        "lastApprover": aProducts[0].approver,
                        "toProofDocuments": aMappedDocuments
                    }

                    aAssessment.push(oAssessment)

                    aAssessment = await this.checkAssessmentData(aAssessment);

                    oAssessment = aAssessment[0];

                    oContext = oListBinding.create(oAssessment);

                    /*oContext = oListBinding.create({
                        "requestName": aProducts[0].materialDescription,
                        "sbu": aProducts[0].sbu,
                        "assessor": "",
                        "submitter": "",
                        "approver": "",
                        "productType": sSelectedKey,
                        "assesmentType": "S",
                        "status": "01",
                        "projectId": "",
                        "sustClass": aProducts[0].sustClass,
                        "category1": aProducts[0].category,
                        "contributor1": aProducts[0].contributor,
                        "category2": aProducts[0].category2,
                        "contributor2": aProducts[0].contributor2,
                        "category3": aProducts[0].category3,
                        "contributor3": aProducts[0].contributor3,
                        "product": aProducts[0].materialtNumber,
                        "rcPreFlag": aProductMasterData[0].rcPreFlag,
                        "rcPreFlagDescription": aProductMasterData[0].rcPreFlagDescription,
                        "externalCommunication": false,
                        "propagation": bPropagation,
                        "approberComment": "",
                        "productName": aProductMasterData[0].productName,
                        "technologyL2Key": aProductMasterData[0].technologyL2Key,
                        "technologyLevel2": aProductMasterData[0].technologyLevel2,
                        "sustainabilityClassCode": aProductMasterData[0].sustainabilityClassCode,
                        "realSubstanceCode": aProductMasterData[0].realSubstanceCode,
                        "realSubstanceName": aProductMasterData[0].realSubstanceName,
                        "region": aProductMasterData[0].region,
                        "applicationLevel2Key": aProductMasterData[0].applicationLevel2Key,
                        "applicationLevel2": aProductMasterData[0].applicationLevel2,
                        "lastAssessment": aProductMasterData[0].lastAssessment,
                        "lastSubmitter": aProductMasterData[0].lastSubmitter,
                        "lastApprover": aProductMasterData[0].lastApprover,
                        "toProofDocuments": aMappedDocuments
                    });*/
                    this._openNewAssessmentDialog(oContext, "Single");

                    this.getView().getModel("ui").setProperty("/oContext", oContext);
                }

                this.getView().setBusy(false);

            },

            onIbTableSelectionChanged: function (oEvent) {
                let iSelectedItems = oEvent.getSource().getSelectedContexts().length;

                this._enabledNewAssessmentButtons(iSelectedItems);
            },

            onIdhTableSelectionChanged: function (oEvent) {
                let iSelectedItems = oEvent.getSource().getSelectedContexts().length;

                this._enabledNewAssessmentButtons(iSelectedItems);
            },

            onSelectedIcon: function (oEvent) {
                let sSelectedKey = oEvent.getParameter("selectedKey"),
                    oIbTable = this.getView().byId("ibTable"),
                    oIdhTable = this.getView().byId("idhTable");

                if (sSelectedKey === "IB") {
                    this._enabledNewAssessmentButtons(oIbTable.getSelectedContexts().length);
                } else {
                    this._enabledNewAssessmentButtons(oIdhTable.getSelectedContexts().length);
                }
            },


            /**
             * Dialog closing
             * @param {*} oEvent 
             */
            onCloseProductsInAssessmentDialog: function (oEvent) {
                this._productsInAssessmentDialog.close();
            },

            /**
             * Continue removing selected
             * @param {*} oEvent 
             */
            onContinueProductsInAssessmentDialog: function (oEvent) {

                // this.getView().setBusy(true);

                const oAssessmentModel = this.getView().getModel("assessmentModel");
                const aProductsInAssessment = oAssessmentModel.getProperty("/prodctsInAssessment");

                const sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey();

                const sId = (sSelectedKey === "IB") ? "ibTable" : "idhTable";
                const oTable = this.getView().byId(sId);
                const aSelectedContext = oTable.getSelectedContexts();

                const aProductsToContinue = [];

                for (const oContext of aSelectedContext) {
                    const oObject = oContext.getObject();
                    const bAlreadyInAssessment = aProductsInAssessment.some(item => item.product === oObject.materialtNumber);

                    if (bAlreadyInAssessment) {
                        oContext?.setSelected(false);
                    } else {
                        aProductsToContinue.push(oObject);
                    }
                }

                this._productsInAssessmentDialog.close();
                if (aSelectedContext.length > aProductsInAssessment.length) {
                    const bValid = this._validationsAfterProductsInAssessment(aProductsToContinue);
                    if (bValid) this._createMassAssessmentAfterValidationsOK(aProductsToContinue);
                } else {
                    this.getView().setBusy(false);
                }


            },

            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/

            checkAssessmentData: async function (aAssessmentData) {
                let oModel = this.getModel(),
                    oContextBinding = oModel.bindList("/Contributor");

                var oRulesModel = this.getModel("rules").getProperty("/");

                const aContributorContext = await oContextBinding.requestContexts();

                var aContributors = await aContributorContext.map(function (oContributor) {
                    return oContributor.getObject();
                });

                aAssessmentData.forEach(oAssessmetData => {

                    for (const key in oAssessmetData) {
                        if (oAssessmetData.hasOwnProperty(key)) {
                            switch (key) {
                                case "rcPreFlag":

                                case "sustClass":
                                    const oRules = oRulesModel[oAssessmetData["rcPreFlag"]];
                                    if (!oRules.sustCodes.codes.includes(oAssessmetData[key])) {
                                        delete oAssessmetData["sustClass"];
                                        delete oAssessmetData["category1"];
                                        delete oAssessmetData["contributor1"];
                                        delete oAssessmetData["category2"];
                                        delete oAssessmetData["contributor2"];
                                        delete oAssessmetData["category3"];
                                        delete oAssessmetData["contributor"];
                                    }
                                    break;
                                case "contributor1":
                                    const sCategory1 = oAssessmetData["category1"];
                                    const sContributor1 = oAssessmetData[key];

                                    if (sContributor1 && sCategory1 &&
                                        !aContributors.some(oContributor =>
                                            oContributor.code === sContributor1 && oContributor.categoryCode === sCategory1
                                        )) {
                                        delete oAssessmetData["contributor1"];
                                    }
                                    break;

                                case "contributor2":
                                    const sCategory2 = oAssessmetData["category2"];
                                    const sContributor2 = oAssessmetData[key];

                                    if (sContributor2 && sCategory2 &&
                                        !aContributors.some(oContributor =>
                                            oContributor.code === sContributor2 && oContributor.categoryCode === sCategory2
                                        )) {
                                        delete oAssessmetData["contributor2"];
                                    }
                                    break;

                                case "contributor3":
                                    const sCategory3 = oAssessmetData["category3"];
                                    const sContributor3 = oAssessmetData[key];

                                    if (sContributor3 && sCategory3 &&
                                        !aContributors.some(oContributor =>
                                            oContributor.code === sContributor3 && oContributor.categoryCode === sCategory3
                                        )) {
                                        delete oAssessmetData["contributor3"];
                                    }
                                    break;


                                default:

                            }

                        }
                    }
                });


                return aAssessmentData;
            },

            _enabledNewAssessmentButtons: function (iSelectedItems) {
                let oSingleButton = this.getView().byId("createSingleButton"),
                    oMassButton = this.getView().byId("createMassButton");

                if (iSelectedItems === 1) {
                    oMassButton.setEnabled(false);
                    oSingleButton.setEnabled(true);
                } else if (iSelectedItems > 1) {
                    oMassButton.setEnabled(true);
                    oSingleButton.setEnabled(false);
                } else {
                    oMassButton.setEnabled(false);
                    oSingleButton.setEnabled(false);
                }
            },

            _getProductsData: async function (aSelectedContext) {
                let aProducts = [];
                const promises = aSelectedContext.map(async (oSelectedContext) => {
                    if (oSelectedContext.getPath()) {
                        //const oContextBinding = this.getModel().getKeepAliveContext(oSelectedContext.getPath());
                        //const oProduct = await oContextBinding.requestObject();
                        const oProduct = oSelectedContext.getObject();
                        if (oProduct !== undefined) {
                            aProducts.push(oProduct);
                        }
                    }
                });

                await Promise.all(promises);

                return aProducts;
            },

            _getProductsDocuments: async function (aProducts, sProductType) {
                let aFilters = [],
                    aMaterials = [],
                    aRelatedProducts = [],
                    aProductsDocuments = [],
                    oContextBinding = {};

                // aFilters = await aProducts.map(function (oProduct) {
                //     let sFormattedMaterialNumber = oProduct.materialtNumber;
                //     return (new Filter("product", FilterOperator.EQ, sFormattedMaterialNumber));
                // });

                // if (sProductType === "IDH") {
                //     const aMaterialNumbers = aProducts.map(product => product.materialtNumber);
                //     aRelatedProducts = await this.getIbLinkedToIdh(aMaterialNumbers);
                //     const aRelatedFilters = aRelatedProducts.map(relatedProduct => {
                //         let sFormattedProduct = relatedProduct.product;
                //         return new Filter("product", FilterOperator.EQ, sFormattedProduct);
                //     });

                //     aFilters = [...aFilters, ...aRelatedFilters];
                // }

                // oContextBinding = this.getModel().bindList("/ProductProofDocument").filter(aFilters);

                aFilters = await aProducts.map(item => item.materialtNumber);
                if (sProductType === "IDH") {
                    const aMaterialNumbers = aProducts.map(product => product.materialtNumber);
                    aRelatedProducts = await this.getIbLinkedToIdh(aMaterialNumbers);
                    const aRelatedFilters = aRelatedProducts.map(relatedProduct => relatedProduct.product);
                    aFilters = [...aFilters, ...aRelatedFilters];
                }
                let oModel = this.getModel(),
                    sEncodedProducts = encodeURIComponent(JSON.stringify(aFilters));

                let sPath = "/getProductDocuments(product='" + aFilters + "')";


                aProductsDocuments = await oModel.bindContext(sPath).requestObject().then((oObject) => {
                    return oObject.value;
                }).catch((oError) => {
                    this.getView().setBusy(false);
                });

                // const aProductDocumentContext = await oContextBinding.requestContexts();

                // aProductsDocuments = await aProductDocumentContext.map(function (oProductDocument) {
                //     return oProductDocument.getObject();
                // });

                if (aRelatedProducts.length > 0) {
                    const oMaterialToProductMap = new Map();


                    aRelatedProducts.forEach(oRelatedProduct => {
                        const productKey = oRelatedProduct.product;
                        const material = oRelatedProduct.material;

                        if (!oMaterialToProductMap.has(productKey)) {
                            oMaterialToProductMap.set(productKey, []);
                        }
                        oMaterialToProductMap.get(productKey).push(material);
                    });


                    aProductsDocuments = aProductsDocuments.flatMap(oDoc => {
                        const productKey = oDoc.product;
                        const relatedMaterials = oMaterialToProductMap.get(productKey) || [];

                        if (relatedMaterials.length > 0) {

                            return relatedMaterials.map(material => ({
                                ...oDoc,
                                product: material,
                                productReference: productKey,
                            }));
                        } else {

                            return {
                                ...oDoc,
                                product: productKey,
                                productReference: undefined
                            };
                        }
                    });
                }

                return aProductsDocuments;
            },

            getIbLinkedToIdh: async function (aMaterials) {
                let oModel = this.getModel(),
                    sEncodedMaterials = encodeURIComponent(JSON.stringify(aMaterials)),
                    sPath = "/getIbLinkedToIdh(materials='" + aMaterials + "')";

                //this.getView().setBusy(true);

                let aRelatedMaterialtData = await oModel.bindContext(sPath).requestObject().then((oObject) => {
                    //this.getView().setBusy(false);
                    return oObject.value;
                }).catch((oError) => {
                    this.getView().setBusy(false);
                });

                return aRelatedMaterialtData;
            },

            _getProductMasterData: async function (aProducts, sProductType) {
                const aMaterialNumbers = aProducts.map(product => product.materialtNumber);
                let oModel = this.getModel(),
                    sMaterialNumbers = JSON.stringify(aMaterialNumbers),
                    sPath = "/GetProductMasterdata(productType='" + sProductType + "',product='" + aMaterialNumbers + "')",
                    aProductMasterData = [];

                await oModel.bindContext(sPath).requestObject().then((oObject) => {
                    aProductMasterData = oObject.value;
                }).catch((oError) => {
                    this.getView().setBusy(false);
                });

                return aProductMasterData

                /*let oModel = this.getModel(),
                    aFilters = [],
                    oContextBinding = {};

                aFilters = await aProducts.map(function (oProduct) {
                    return (new Filter("product", FilterOperator.EQ, oProduct.materialtNumber));
                });

                oContextBinding = this.getModel().bindList("/ProductData").filter(aFilters);

                const aProductDataContext = await oContextBinding.requestContexts();

                return await aProductDataContext.map(function (oProductData) {
                    return oProductData.getObject();
                });*/

            },

            _onProductOverviewMatched: function () {
                const aDefaultIb = ["ACM", "AMC", "AME", "AMI", "AMO", "APC", "APP"],
                    aDefaultIdh = ["ACB", "ACC"];

                let aSbu = this.getModel("ui").getProperty("/userParameters/sbu/newAssessment"),
                    oProductsTabBar = this.getView().byId("productsTabBar");

                // Set Default User's SBU as default filter value for each SBU in the array
                aSbu.forEach(sSbu => {
                    this.getView().byId("ibFilterBar").setFilterValues("sbu", "EQ", sSbu);
                    this.getView().byId("idhFilterBar").setFilterValues("sbu", "EQ", sSbu);
                });

                if (aSbu.some(item => aDefaultIb.includes(item))) {
                    oProductsTabBar.setSelectedKey("IB");

                } else if (aSbu.some(item => aDefaultIdh.includes(item))) {
                    oProductsTabBar.setSelectedKey("IDH");
                }

                if (this.getModel().hasPendingChanges("UpdateGroup")) {
                    this.getModel().resetChanges("UpdateGroup");
                }

                this.getView().getModel("productModel").setProperty("/onlyDocuments", false);

                this.getView().byId("idhTable").getContent().clearSelection();
                this.getView().byId("ibTable").getContent().clearSelection();
                this.getView().byId("createSingleButton").setEnabled(false);
                this.getView().byId("createMassButton").setEnabled(false);
            },

            _openNewAssessmentDialog: function (oContext, sAssessmentType) {
                this.getView().setBusy(false);
                if (!this._newAssessmentDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.NewAssessmentDialog",
                        controller: this
                    }).then(function (oNewAssessmentDialog) {
                        this.getView().byId("newAssessmentDialog").setBindingContext(oContext);
                        this._newAssessmentDialog = oNewAssessmentDialog;
                        this.getView().addDependent(this._newAssessmentDialog);
                        this._newAssessmentDialog.open();
                        if (sAssessmentType === "Mass") {
                            this.getView().byId("requestNameId").setValueState("Error");
                            this.getView().byId("requestNameId").setValueStateText("Mandatory field");
                            this.getView().byId("idCreateButton").setEnabled(false);
                        }

                    }.bind(this));
                } else {
                    this._newAssessmentDialog.open();
                    if (sAssessmentType === "Mass") {
                        this.getView().byId("requestNameId").setValueState("Error");
                        this.getView().byId("requestNameId").setValueStateText("Mandatory field");
                        this.getView().byId("idCreateButton").setEnabled(false);
                    } else {
                        this.getView().byId("requestNameId").setValueState("None");
                        this.getView().byId("requestNameId").setValueStateText("");
                        this.getView().byId("idCreateButton").setEnabled(true);
                    }

                    this.getView().byId("newAssessmentDialog").setBindingContext(oContext);
                }
            },

            _validateNewAssessment: async function (aProducts) {
                let aUserRoles = this.getModel("ui").getProperty("/userParameters/composedRoles"),
                    oActionRoles = this.getModel("ui").getProperty("/userParameters/role"),
                    oModel = this.getModel(),
                    sFirstSbu = aProducts[0].sbu,
                    validRoles = ["Submitter", "Assessor"],
                    aProductIds = aProducts.map(product => product.materialtNumber),
                    sProducts = JSON.stringify(aProductIds),
                    sPath = "/checkProductInAssessment(products='" + encodeURIComponent(sProducts) + "')",
                    bValid = true;

                await oModel.bindContext(sPath).requestObject().then((oObject) => {

                    // If products already in assessment are recovered, then show the info
                    const aProductsInAssessment = oObject?.value;
                    if (aProductsInAssessment && aProductsInAssessment?.length > 0) {
                        bValid = false;

                        const oAssessmentModel = this.getView().getModel("assessmentModel");
                        const bIsMassAssessment = aProductIds.length > 1;
                        if (!oAssessmentModel) {
                            this.getView().setModel(new JSONModel({ prodctsInAssessment: aProductsInAssessment, isMassAssessment: bIsMassAssessment }), "assessmentModel");
                        } else {
                            oAssessmentModel.setProperty("/prodctsInAssessment", aProductsInAssessment);
                            oAssessmentModel.setProperty("/isMassAssessment", bIsMassAssessment);
                        }

                        if (!this._productsInAssessmentDialog) {

                            this.getExtensionAPI().loadFragment({
                                id: this.getView().getId(),
                                name: "com.sustainability.overview.view.fragment.ProductsInAssessment",
                                controller: this
                            }).then(function (oDialog) {
                                this._productsInAssessmentDialog = oDialog;
                                this.getView().addDependent(this._productsInAssessmentDialog);
                                this._productsInAssessmentDialog.open();

                                // this._productsInAssessmentDialog.attachEvent("onCloseProductsInAssessmentDialog", function () {
                                //     resolve('onCloseProductsInAssessmentDialog');
                                // });

                                // this._productsInAssessmentDialog.attachEvent("onContinueProductsInAssessmentDialog", function () {
                                //     resolve('onContinueProductsInAssessmentDialog');
                                // });
                            }.bind(this));
                            // }).then((response) => {
                            //     if (response === 'onCloseProductsInAssessmentDialog') {
                            //         // Aqui devuelves el bValid a false
                            //         this._productsInAssessmentDialog.close();
                            //         bValid = false;

                            //     } else if (response === 'OnContinueRemoving') {
                            //         //Aqui eliminas del array del prodcutos los que no son validos y no tocas el bValid para que se sigan ejecutando el resto de validaciones

                            //         this.getView().setBusy(true);
                            //         bValid = true;

                            //         const oAssessmentModel = this.getView().getModel("assessmentModel");
                            //         const aProductsInAssessment = oAssessmentModel.getProperty("/prodctsInAssessment");

                            //         const sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey();

                            //         const sId = (sSelectedKey === "IB") ? "ibTable" : "idhTable";
                            //         const oTable = this.getView().byId(sId);
                            //         const aSelectedContext = oTable.getSelectedContexts();
                            //         for (const oProduct of aProductsInAssessment) {
                            //             const oContext = aSelectedContext.find(item => {
                            //                 const oObject = item.getObject();
                            //                 return oObject.materialtNumber === oProduct.product;
                            //             });
                            //             oContext?.setSelected(false);
                            //         }
                            //         aProducts = aProducts.filter(product => {
                            //             return !aProductsInAssessment.some(productInAssessment => productInAssessment.product === product.product)
                            //         });

                            //         // const aSelectedItems = oTable.getSelectedItems();
                            //         // oTable.setSelectedItems(aSelectedItems, false, true);

                            //         // this._productsInAssessmentDialog.close();
                            //         // if (aSelectedContext.length > aProductsInAssessment.length) {
                            //         //     // this.onCreateMassAssessment();
                            //         // }                                    
                            //     }
                            //     this.getView().setBusy(false);
                            // });
                        } else {
                            this._productsInAssessmentDialog.open();
                        }
                        this.getView().setBusy(false);

                    }


                    // const sFormattedDetails = oObject.value.map(product => `- ${product}`).join('<br>');

                    // if (sFormattedDetails !== "") {
                    //     bValid = false;

                    //     MessageBox.information(this.getResourceBundle().getText("productInAssessmentError"), {
                    //         details: sFormattedDetails,
                    //         contentWidth: "100px",
                    //         dependentOn: this.getView()
                    //     });
                    // }
                }).catch((oError) => {
                    bValid = false;
                });

                if (!bValid) {
                    return false;
                }

                bValid = this._validationsAfterProductsInAssessment(aProducts);
                return bValid;

                // // Validate that all products belong to the same SBU
                // let bAllSameSbu = aProducts.every(function (oProduct) {
                //     return oProduct.sbu === sFirstSbu;
                // });

                // if (!bAllSameSbu) {
                //     // Show error message if SBUs of products differ
                //     MessageBox.error(this.getResourceBundle().getText("errorDiferentProductSBU"));
                //     return false;
                // }

                // // Validate if user has ViewerPlus role
                // if (oActionRoles.ViewerPlus) {
                //     return true;
                // }

                // // Validate that user has a valid role for the first SBU of the products
                // let bHasValidRole = false;

                // // Iterate over the user's roles using 'for...of' to get the actual role values
                // for (let role of aUserRoles) {
                //     let [userSbu, userRole] = role.includes('.') ? role.split('.') : [null, role];

                //     // Check if user has a specific SBU role (Submitter or Assessor)
                //     if (userSbu === sFirstSbu && validRoles.includes(userRole)) {
                //         bHasValidRole = true;
                //         break;
                //     }
                // }

                // if (!bHasValidRole) {
                //     // Show error message if user doesn't have a valid role for the products' SBU
                //     MessageBox.error(this.getResourceBundle().getText("errorUserProductSBU"));
                //     return false;
                // }

                // // All validations passed
                // return true;
            },

            _validationsAfterProductsInAssessment: function (aProducts) {
                const sFirstSbu = aProducts[0].sbu;
                const oActionRoles = this.getModel("ui").getProperty("/userParameters/role");
                const aUserRoles = this.getModel("ui").getProperty("/userParameters/composedRoles");
                const validRoles = ["Submitter", "Assessor"];

                // Validate that all products belong to the same SBU
                let bAllSameSbu = aProducts.every(function (oProduct) {
                    return oProduct.sbu === sFirstSbu;
                });

                if (!bAllSameSbu) {
                    // Show error message if SBUs of products differ
                    MessageBox.error(this.getResourceBundle().getText("errorDiferentProductSBU"));
                    return false;
                }

                // Validate if user has ViewerPlus role
                if (oActionRoles.ViewerPlus) {
                    return true;
                }

                // Validate that user has a valid role for the first SBU of the products
                let bHasValidRole = false;

                // Iterate over the user's roles using 'for...of' to get the actual role values
                for (let role of aUserRoles) {
                    let [userSbu, userRole] = role.includes('.') ? role.split('.') : [null, role];

                    // Check if user has a specific SBU role (Submitter or Assessor)
                    if (userSbu === sFirstSbu && validRoles.includes(userRole)) {
                        bHasValidRole = true;
                        break;
                    }
                }

                if (!bHasValidRole) {
                    // Show error message if user doesn't have a valid role for the products' SBU
                    MessageBox.error(this.getResourceBundle().getText("errorUserProductSBU"));
                    return false;
                }

                // All validations passed
                return true;

            },

            _createMassAssessmentAfterValidationsOK: async function (aProducts) {
                let sSelectedKey = this.getView().byId("productsTabBar").getSelectedKey(),
                    bOnlyDocuments = this.getView().getModel("productModel").getProperty("/onlyDocuments");
                const bPropagation = (sSelectedKey === "IDH");

                this.getView().setBusy(true);

                const aProductMasterData = await this._getProductMasterData(aProducts, sSelectedKey);
                const aProductDocuments = await this._getProductsDocuments(aProducts, sSelectedKey);

                let aItems = await Promise.all(aProducts.map(item => {
                    let oProductData = aProductMasterData.find(oProduct => oProduct.product === item.materialtNumber);
                    let aMappedDocuments = aProductDocuments.filter(oDocument => oDocument.product === item.materialtNumber)
                        .map(oDocument => ({
                            type: oDocument.type,
                            description: oDocument.description,
                            internalPath: "",
                            fileName: oDocument.fileName,
                            mediaType: oDocument.mediaType,
                            content: null,
                            active: oDocument.active !== null ? oDocument.active : true,
                            url: oDocument.url,
                            externalUrl: oDocument.externalUrl,
                            imageMasterID: oDocument.proofPointId,
                            productReference: oDocument.productReference
                        }));
                    return {
                        status: "91",
                        product: item.materialtNumber,
                        productType: sSelectedKey,
                        sustClass: item.sustClass,
                        category1: item.category,
                        contributor1: item.contributor,
                        category2: item.category2,
                        contributor2: item.contributor2,
                        category3: item.category3,
                        contributor3: item.contributor3,
                        rcPreFlag: oProductData.rcPreFlag,
                        sbu: item.sbu,
                        propagation: bPropagation,
                        externalCommunication: false,
                        approberComment: "",
                        comment: bOnlyDocuments ? "Virtual assessment for proofPoints" : "",
                        virtualAssessment: bOnlyDocuments ? true : false,
                        //toProductData: oProductData ? oProductData : null,
                        rcPreFlagDescription: oProductData.rcPreFlagDescription,
                        productName: oProductData.productName,
                        technologyL2Key: oProductData.technologyL2Key,
                        technologyLevel2: oProductData.technologyLevel2,
                        sustainabilityClassCode: oProductData.sustainabilityClassCode,
                        existingSustainabilityClass: oProductData.existingSustainabilityClass,
                        realSubstanceCode: oProductData.realSubstanceCode,
                        realSubstanceName: oProductData.realSubstanceName,
                        region: oProductData.region,
                        applicationLevel2Key: oProductData.applicationLevel2Key,
                        applicationLevel2: oProductData.applicationLevel2,
                        lastAssessment: oProductData.lastAssessment,
                        lastSubmitter: oProductData.lastSubmitter,
                        lastApprover: item.approver,
                        toProofDocuments: aMappedDocuments
                    };
                }));

                aItems = await this.checkAssessmentData(aItems);

                const oModel = this.getModel();
                const oListBinding = oModel.bindList("/MassAssessmentHeader", undefined, undefined, undefined, { $$updateGroupId: "UpdateGroup" });
                const oContext = await oListBinding.create({
                    "requestName": bOnlyDocuments ? "Virtual request for proofPoints" : "",
                    "sbu": aProducts[0].sbu,
                    "assessor": "",
                    "submitter": "",
                    "approver": "",
                    "productType": sSelectedKey,
                    "assesmentType": "M",
                    "status": "91",
                    "projectId": "",
                    "virtualAssessment": bOnlyDocuments ? true : false,
                    "toItems": aItems
                }, (aItems?.length > 500));
                //this._openNewAssessmentDialog(oContext, "Mass");
                this.getView().getModel("ui").setProperty("/oContext", oContext);
                this.getView().getModel("ui").setProperty("/aItems", aItems);
                if (bOnlyDocuments) {
                    this._createOnlyDocumentsAssessment();;
                } else {
                    this._openNewAssessmentDialog(oContext, "Mass");
                }
                this.getView().setBusy(false);

            },

            _createOnlyDocumentsAssessment: async function () {
                let oContext = this.getView().getModel("ui").getProperty("/oContext"),
                    oModel = this.getModel();

                oModel.submitBatch("UpdateGroup")
                    .then(function () {
                        this.getView().setBusy(false);
                        var oCreatedData = oContext.getObject();
                        this.routing.navigateToRoute("NewMassAssessment", { assessment: oCreatedData.ID, onlyDocuments: true }, undefined, true);
                    }.bind(this))
                    .catch(function (oError) {
                        MessageBox.error(this.getResourceBundle().getText("errorCreatingAssessment"))
                        this.getModel().resetChanges("UpdateGroup");
                        this.getView().setBusy(false);
                    }.bind(this));
            },

        });
    }
);