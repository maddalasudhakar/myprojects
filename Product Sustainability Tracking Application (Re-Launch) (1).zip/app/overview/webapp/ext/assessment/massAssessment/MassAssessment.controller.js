sap.ui.define(
    [
        "./AssessmentController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/core/Fragment",
        "../../../model/formatter",
        "sap/ui/core/routing/History",
        "sap/m/MessageToast",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
    ],
    function (AssessmentController, JSONModel, MessageBox, Fragment, formatter, History, MessageToast, Filter, FilterOperator) {
        'use strict';

        return AssessmentController.extend('com.sustainability.overview.ext.assessment.massAssessment.MassAssessment', {
            formatter: formatter,
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: function () {
                this.initialize();
                //this.getRouter().getRoute("MassAssessment").attachPatternMatched(this._onMassAssessmentMatched, this);
                this.getAppComponent().getRouter().getRoute("MassAssessment").attachPatternMatched(this._onMassAssessmentMatched, this);

                let oAssessmentModel = new JSONModel({
                    editMode: false,
                    approbeMode: false,
                    prooftype: [],
                    validProofType: [],
                    contributors: [],
                    categories: [],
                    sustClass: [],
                    assesmentType: "",
                    masterDataBlock: false,
                    assessmentDetailsBlock: false,
                    approberDataBlock: false,
                    copyItem: {},
                    copyMassProofPoint: {},
                    copyMapProofPoint: {},
                    massProofPoints: [],
                    selectedRows: 0,
                    selectedMassRows: 0,
                    selectedMapRows: 0,
                    propagationList: [],
                    itemContext: {},
                    productRelation: [],
                    onlyDocuments: false,
                    header: {},
                    items: [],
                    userAction: "",
                    recipientsList: [],
                    pasteApprovalStatus: false,
                    rulesAddProofEnabled: false
                });

                this.setModel(oAssessmentModel, "assessmentModel");
            },

            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/

            onAddMapUploadProofPointsDialog: async function () {
                const oItemsTable = this.getView().byId("massItems"),
                    oModel = this.getModel(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aItemContexts = oItemsTable.getBinding("rows").getContexts(),
                    sGroupId = "proofDocumentsGroup";

                if (!aProofPoints || aProofPoints.length === 0) {
                    MessageBox.error(this.getResourceBundle().getText("noDocumentsToUpload"));
                    return;
                }

                let bShowMessage = false;

                if (aProofPoints.length > 0) {
                    const oProofDocsBinding = oModel.bindList("/AssessmentProofDocument", undefined, undefined, undefined, {
                        $$updateGroupId: sGroupId
                    });

                    for (const oProofDocument of aProofPoints) {
                        const sFileName = oProofDocument.fileName;
                        if (!sFileName) {
                            // File name is required to extract product reference
                            bShowMessage = true;
                            continue;
                        }

                        const sProductIdentifier = sFileName.split("_")[0].replace(/^0+/, "");

                        // Find matching item by comparing product field (removing leading zeros)
                        const oMatchingContext = aItemContexts.find(oCtx => {
                            const sProduct = oCtx.getProperty("product") || "";
                            return sProduct.replace(/^0+/, "") === sProductIdentifier;
                        });

                        if (oMatchingContext) {
                            const oItem = oMatchingContext.getObject();
                            // Validate required fields and custom logic
                            const bTypeValid = this.checkTypeProofFields(oMatchingContext, oProofDocument);
                            const bMandatoryFields = oProofDocument.type && oProofDocument.description && oProofDocument.fileName;

                            if (bTypeValid && bMandatoryFields) {
                                // Assign the related requestId to link document with item
                                oProofDocument.requestId = oItem.ID;
                                oProofDocument.active = true;

                                // Create the document directly using the entity path
                                oProofDocsBinding.create(oProofDocument);
                            } else {
                                bShowMessage = true;
                            }
                        } else {
                            // No matching item found
                            bShowMessage = true;
                        }
                    }

                    // Submit the batch if there are pending changes
                    if (oModel.hasPendingChanges(sGroupId)) {
                        try {
                            this.getView().setBusy(true);
                            await oModel.submitBatch(sGroupId);
                            this.getView().setBusy(false);

                            if (bShowMessage) {
                                MessageToast.show(this.getResourceBundle().getText("noSuccessMassUpload"));
                            } else {
                                MessageToast.show(this.getResourceBundle().getText("successMassUpload"));
                            }

                            this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                            this._mapUploadProofPointsDialog.close();
                        } catch (oError) {
                            this.getView().setBusy(false);
                            MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                        }
                    } else {
                        MessageToast.show(this.getResourceBundle().getText("noDocumentsMatch"));
                    }
                }
            },

            onPropagationChange: function (oEvent) {
                const sSelectedKey = oEvent.getParameter("selectedItem").getKey();
                const bValue = sSelectedKey === "true";

                const oContext = oEvent.getSource().getBindingContext("assessmentModel");
                oContext.getModel().setProperty(oContext.getPath() + "/propagation", bValue);
            },

            onActiveChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext"),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("active", bValue);
                if (oContext) {
                    this.setProofTypesOptions(oContext);
                }
            },

            onCommunicationChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    bValue = (oSelectedKey === "true");

                const oContext = oEvent.getSource().getBindingContext("assessmentModel");
                oContext.getModel().setProperty(oContext.getPath() + "/externalCommunication", bValue);
            },

            handleLinkPress: function (oEvent) {
                let oModel = this.getModel(),
                    oProofPoint = oEvent.getSource().getBindingContext().getObject(),
                    baseUrl = oModel.getServiceUrl(),
                    sUploadURL = "";

                if (oProofPoint.externalUrl) {
                    sUploadURL = oProofPoint.url;
                } else {
                    sUploadURL = baseUrl + oProofPoint.url;
                }

                window.open(sUploadURL, '_blank');

            },
            /**
            * Add new proof table line
            * @public
            */
            onAddProofPoint: function () {
                let oProofTable = this.getView().byId("proofTable"),
                    oBinding = oProofTable.getBinding("rows"),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext");
                oBinding.create({ "active": true, "requestId": oContext.getProperty("ID") }, true);

            },

            /**
            * Add new Assessment products in item's table
            * @public
            */
            onAddSelectedProducts: async function () {
                let sProductType = this.getModel("assessmentModel").getProperty("/type"),
                    oItemsTable = this.getView().byId("massItems"),
                    oBinding = oItemsTable.getBinding("rows"),
                    aSelectedContext = [],
                    bPropagation = false;

                this.getView().setBusy(true);
                if (sProductType === "IB") {
                    aSelectedContext = this.getView().byId("ibDialogTable").getSelectedContexts();
                } else {
                    aSelectedContext = this.getView().byId("idhDialogTable").getSelectedContexts();
                    bPropagation = true;
                }

                if (!aSelectedContext || aSelectedContext.length === 0) {
                    this.getView().setBusy(false);
                    MessageBox.information(this.getResourceBundle().getText("noProductsSelected"));
                    return;
                }

                MessageBox.confirm(this.getResourceBundle().getText("confirmSaveNewProducts"), {
                    onClose: async function (sAction) {
                        if (sAction === 'OK') {
                            let aProducts = await this.getProductsData(aSelectedContext);
                            let aDuplicatedProducts = this.checkDuplicatedProducts(aProducts);
                            let aProductsInAssessments = await this.checkProductsInAssessment(aProducts);

                            aProductsInAssessments = aProductsInAssessments.filter(product =>
                                !aDuplicatedProducts.some(dup => dup.materialtNumber === product.materialtNumber)
                            );


                            if (aProductsInAssessments.length > 0) {
                                aProductsInAssessments = aProductsInAssessments.map(item => {
                                    return {
                                        product: item.materialtNumber,
                                        requestName: item.requestName,
                                    }
                                });

                                //const oSetUniqueProducts = new Set(aProductsInAssessments);
                                //const aProductsNotInUnique = aProducts.filter(materialtNumber => !oSetUniqueProducts.has(materialtNumber));

                                const oAssessmentModel = this.getView().getModel("assessmentModel");
                                oAssessmentModel.setProperty("/prodctsInAssessment", aProductsInAssessments);

                                if (!this._productsInAssessmentDialog) {

                                    this.getExtensionAPI().loadFragment({
                                        id: this.getView().getId(),
                                        name: "com.sustainability.overview.view.fragment.ProductsInAssessment",
                                        controller: this
                                    }).then(function (oDialog) {
                                        this._productsInAssessmentDialog = oDialog;
                                        this.getView().addDependent(this._productsInAssessmentDialog);
                                        this._productsInAssessmentDialog.open();
                                    }.bind(this));
                                } else {
                                    this._productsInAssessmentDialog.open();
                                }
                                this.getView().setBusy(false);



                            } else if (aDuplicatedProducts.length > 0) {

                                this._addProductsDuplicated(aProducts, aDuplicatedProducts, sProductType);

                            } else {
                                this._addProducts(aProducts, sProductType);

                            }
                        }

                    }.bind(this)
                });

            },

            onCancel: function () {
                var sStatus = this.getView().getBindingContext().getProperty("toStatus/code")
                if (this.getModel().hasPendingChanges("UpdateGroup")) {
                    MessageBox.confirm(this.getResourceBundle().getText("pendingChanges"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                this.getModel().resetChanges("UpdateGroup");
                                this.getModel("assessmentModel").setProperty("/editMode", false);
                                //this.getView().byId("deleteButton").setVisible(true);
                            }
                        }.bind(this)
                    });
                } else {
                    this.getModel("assessmentModel").setProperty("/editMode", false);
                    //this.getView().byId("deleteButton").setVisible(true);
                }

                if (sStatus === '01') {
                    this.getView().byId("deleteButton").setVisible(true);
                } else {
                    this.getView().byId("deleteButton").setVisible(false);
                }
            },

            onCancelAddProducts: function () {
                this._addProductsDialog.close();
            },

            onCreateMassUploadProofPointsDialog: async function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aProofPointsToSave = [],
                    aValiditems = [],
                    oModel = this.getModel(),
                    bTypeValid = true,
                    bMandatoryFields = true,
                    bShowMessage = false;

                const oActionODataContextBinding = oModel.bindContext("/MassUploadDocuments(...)");

                for (const oProofDocument of aProofPoints) {
                    aValiditems = [];
                    aProofPointsToSave = [];
                    for (const iIndex of aIndices) {
                        let oContext = oItemsTable.getContextByIndex(iIndex);


                        bTypeValid = this.checkTypeProofFields(oContext, oProofDocument);
                        oProofDocument.active = true;

                        if (bTypeValid && bMandatoryFields) {
                            aValiditems.push(oContext.getObject());

                        } else {
                            bShowMessage = true;
                        }

                    }

                    if (aValiditems.length > 0) {
                        aProofPointsToSave.push(oProofDocument);
                        oActionODataContextBinding.setParameter("items", aValiditems);
                        oActionODataContextBinding.setParameter("documents", aProofPointsToSave);

                        await oActionODataContextBinding.execute().then(
                            async function (oData, test) {

                                this.getView().setBusy(false);

                            }.bind(this)
                        ).catch(function (oError) {

                            this.getView().setBusy(false);
                        }.bind(this));
                    }

                }

                if (bShowMessage) {
                    MessageToast.show(this.getResourceBundle().getText("noSuccessMassUpload"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("successMassUpload"));
                }

                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this._massUploadProofPointsDialog.close();
            },

            onCloseAdpAdditionalDataDialog: function () {
                this._adpDialog.close();
            },

            onCloseMapUploadProofPointsDialog: function () {
                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this.getModel("assessmentModel").setProperty("/copyMapProofPoint", {});
                this._mapUploadProofPointsDialog.close();
            },

            onCloseMassUploadProofPointsDialog: function () {
                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this.getModel("assessmentModel").setProperty("/copyMassProofPoint", {});
                this._massUploadProofPointsDialog.close();
            },

            onCloseProofPointsDialog: function () {
                let oModel = this.getModel();
                this.getModel("assessmentModel").setProperty("/itemContext", {});
                oModel.submitBatch("proofDocumentsGroup").then(function (odata, second) {
                    this.getView().setBusy(false);
                    if (!oModel.hasPendingChanges("proofDocumentsGroup")) {

                    } else {
                        let aMessage = oMessageModel.getData(),
                            oLastMessage = aMessage[aMessage.length - 1];
                        MessageBox.error(oLastMessage.getMessage());
                    }
                }.bind(this)).catch(function (oError) {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                }.bind(this));
                this._proofPointsDialog.close();
            },

            onCopyItem: async function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    oContext = {},
                    oItem = {};

                if (aIndices.length === 1) {

                    oContext = oItemsTable.getContextByIndex(aIndices[0]);
                    oItem = this.getModel("assessmentModel").getProperty(oContext.getPath());
                    //oItem.toProofDocuments = [];

                    // Await the creation of the proof points fragment if it doesn't exist
                    /*if (!this._proofPointsDialog) {
                        await this.createProofPointsFragment(oContext);
                    }

                    this.getView().byId("proofTable").setBindingContext(oContext);
                    // Bind to the toProofDocuments list
                    let aProofContext = await this.getView().byId("proofTable").getBinding("rows").requestContexts(0, Infinity);
                    //let aProofContext = this.getView().byId("proofTable").getBinding("rows");
                    for (const oProofContext of aProofContext) {
                        if (oProofContext.isTransient()) {
                            oItem.toProofDocuments.push(oProofContext.getObject());
                        }

                    }*/

                    this.getModel("assessmentModel").setProperty("/copyItem", oItem);
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onCopyMassProofPoint: function () {
                let aIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                if (aIndices.length === 1) {
                    let iSelectedIndex = aIndices[0];
                    let oSelectedRow = aMassProofPoints[iSelectedIndex];

                    this.getModel("assessmentModel").setProperty("/copyMassProofPoint", oSelectedRow);
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onCopyMapProofPoint: function () {
                let aIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                if (aIndices.length === 1) {
                    let iSelectedIndex = aIndices[0];
                    let oSelectedRow = aMassProofPoints[iSelectedIndex];

                    this.getModel("assessmentModel").setProperty("/copyMapProofPoint", oSelectedRow);
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onFilterItems: function (oEvent) {
                const filterBar = this.getView().byId("massIemFilterbar"),
                    allFilters = filterBar.getFilters(),
                    oTable = this.byId("massItems"),
                    oBinding = oTable.getBinding("rows");

                oBinding.filter(allFilters.filters, "Application");
            },


            onMassSelectionChange: function () {
                let aSelectedItems = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedMassRows", aSelectedItems);
            },

            onMapSelectionChange: function () {
                let aSelectedItems = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedMapRows", aSelectedItems);
            },

            onOkNotificationsRecipientsDialog: async function () {
                const sAction = this.getModel("assessmentModel").getProperty("/userAction"),
                    oModel = this.getModel(),
                    oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aSelectedContext = this.getView().byId("recipientsTableId").getSelectedContexts(),
                    sStatus = sAction === "Save" ? "01" : "02";

                this.getView().setBusy(true);

                this.getView().byId("recipientsTableId").removeSelections();


                this.getModel("assessmentModel").setProperty("/userAction", "");
                this._notificationRecipientsDialog.close();

                if (!sAction) {
                    this.getView().setBusy(false);
                    return;
                }

                if ((!aSelectedContext || aSelectedContext.length === 0) && sAction === "Submit") {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("mandatoryRecipients"));

                    return;
                }

                // Build recipients payload for the action
                let aRecipients = [];
                if (aSelectedContext && aSelectedContext.length > 0) {
                    aRecipients = aSelectedContext
                        .map(oContext => oContext && oContext.getProperty("email"))
                        .filter(Boolean);
                }

                // If there is nothing to send and the user just saved, continue normal flow
                if (aRecipients.length === 0) {
                    if (sAction === "Save") {
                        await this._saveAssessment();
                    }
                    return;
                }

                try {
                    const oActionContext = oModel.bindContext("/saveRecipients(...)");
                    oActionContext.setParameter("assessmentId", oHeader.ID);
                    oActionContext.setParameter("recipientEmail", aRecipients);
                    oActionContext.setParameter("status", sStatus);


                    oActionContext.execute().then(
                        async function () {

                            // Continue with Save/Submit flows
                            if (sAction === "Save") {
                                await this._saveAssessment();
                            } else if (sAction === "Submit") {
                                await this._submitAssessment();
                            }
                        }.bind(this)
                    ).catch(function (oError) {
                        console.error("saveRecipients action error", oError);
                        this.getView().setBusy(false);

                    }.bind(this));
                } catch (oError) {
                    // Handle errors from action execution
                    this.getView().setBusy(false);

                    console.error("saveRecipients action error", oError);
                }
            },

            onDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("proofTable").getSelectedIndices(),
                    aContext = [],
                    oProofTable = this.getView().byId("proofTable");

                if (aSelectedIndices.length > 0) {

                    let bShowError = aSelectedIndices.some(iIndex => {
                        let oContext = oProofTable.getContextByIndex(iIndex);
                        // If the documents is in Image master is not possible delete it
                        if (oContext.getProperty("imageMasterID")) {
                            return true;
                        }

                        aContext.push(oContext);
                        return false;
                    });

                    if (bShowError) {
                        MessageBox.error(this.getResourceBundle().getText("removeProofPointsError"));
                        return;
                    }

                    MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionProofPoints"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                aContext.forEach(oContext => {
                                    if (oContext.isTransient()) {
                                        oContext.delete();
                                    } else {
                                        oContext.delete("$auto");
                                    }
                                });
                            }
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            onDeleteSelectedItems: function () {
                const oView = this.getView(),
                    oTable = oView.byId("massItems"),
                    oAssessmentModel = oView.getModel("assessmentModel"),
                    oODataModel = oView.getModel(),
                    aItems = oAssessmentModel.getProperty("/items") || [],
                    sUpdateGroup = "deleteGroup";

                // Get selected indices from the UI table (visual indices)
                const aSelectedIndices = oTable.getDependents()[0].getSelectedIndices();

                if (aSelectedIndices.length === 0) {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                    return;
                }

                // Map selected indices to actual data objects using their binding contexts
                const aSelectedItems = aSelectedIndices
                    .map(iIndex => oTable.getContextByIndex(iIndex))
                    .filter(oContext => !!oContext)
                    .map(oContext => oContext.getObject());

                MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionItems"), {
                    onClose: async function (sAction) {
                        if (sAction !== "OK") return;

                        oView.setBusy(true);

                        try {
                            // Prepare deletion requests for all selected items
                            const aContextPromises = aSelectedItems.map(async oItem => {
                                const sPath = `/MassAssessmentItems(${oItem.ID})`;
                                const oContextBinding = oODataModel.bindContext(sPath, undefined, {
                                    $$updateGroupId: sUpdateGroup
                                });
                                await oContextBinding.requestObject();
                                return oContextBinding.getBoundContext();
                            });

                            const aContexts = await Promise.all(aContextPromises);

                            // Call delete on each bound context
                            for (const oContext of aContexts) {
                                oContext.delete(sUpdateGroup);
                            }

                            // Submit all deletes as a batch
                            await oODataModel.submitBatch(sUpdateGroup);

                            // Update local model by removing deleted items
                            const aRemainingItems = aItems.filter(item =>
                                !aSelectedItems.some(sel => sel.ID === item.ID)
                            );
                            oAssessmentModel.setProperty("/items", aRemainingItems);
                        } catch (oError) {
                            MessageBox.error("Error during batch deletion: " + (oError.message || "Unknown error"));
                        } finally {
                            oView.setBusy(false);
                        }
                    }.bind(this)
                });
            },

            onFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oEvent.getParameter("files"),
                    oContext = oFileUploader.getBindingContext();

                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oContext.setProperty("content", sFileContent.split(',')[1], "proofDocumentsGroup", true);
                        oContext.setProperty("fileName", oFile.name, "proofDocumentsGroup", true);
                        oContext.setProperty("mediaType", oFile.type, "proofDocumentsGroup", true);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            onMultipleUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oFileUploader.oFileUpload.files,
                    oProofTable = this.getView().byId("proofTable"),
                    oBinding = oProofTable.getBinding("rows"),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext");

                if (aFiles.length === 0) {
                    MessageToast.show("No se seleccionaron archivos.");
                    return;
                }

                let aPromises = Array.from(aFiles).map(oFile => {
                    return new Promise((resolve, reject) => {
                        let oReader = new FileReader();

                        oReader.onload = function (e) {
                            resolve({
                                requestId: oContext.getProperty("ID"),
                                fileName: oFile.name,
                                mediaType: oFile.type,
                                content: e.currentTarget.result.split(',')[1],
                                internalPath: oFile.name,
                                active: true
                            });
                        };

                        oReader.onerror = function () {
                            reject(`Error leyendo el archivo: ${oFile.name}`);
                        };

                        oReader.readAsDataURL(oFile);
                    });
                });


                Promise.all(aPromises)
                    .then(aFileList => {
                        aFileList.forEach(oFile => {
                            oBinding.create(oFile, true);
                        });
                        oFileUploader.clear();
                    })
                    .catch(error => {
                        MessageToast.show(error);
                    });
            },

            onMapProofsUpload: function () {
                if (!this._mapUploadProofPointsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.MapProofPointsDialog",
                        controller: this
                    }).then(function (oMapUploadProofPointsDialog) {
                        this._mapUploadProofPointsDialog = oMapUploadProofPointsDialog;
                        this.getView().addDependent(this._mapUploadProofPointsDialog);
                        this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                        this._mapUploadProofPointsDialog.open();
                    }.bind(this));
                } else {
                    this._mapUploadProofPointsDialog.open();
                    this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                }
            },

            onMassMultipleUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aFiles = oFileUploader.oFileUpload.files,
                    aFileList = [];

                if (aFiles.length === 0) {
                    MessageToast.show("No se seleccionaron archivos.");
                    return;
                }

                let aPromises = Array.from(aFiles).map(oFile => {
                    return new Promise((resolve, reject) => {
                        let oReader = new FileReader();

                        oReader.onload = function (e) {
                            resolve({
                                fileName: oFile.name,
                                mediaType: oFile.type,
                                content: e.currentTarget.result.split(',')[1],
                                internalPath: oFile.name,
                                active: "Y"
                            });
                        };

                        oReader.onerror = function () {
                            reject(`Error leyendo el archivo: ${oFile.name}`);
                        };

                        oReader.readAsDataURL(oFile);
                    });
                });


                Promise.all(aPromises)
                    .then(aFileList => {
                        let aUpdatedFiles = aProofPoints.concat(aFileList);
                        this.getModel("assessmentModel").setProperty("/massProofPoints", aUpdatedFiles);
                        oFileUploader.clear();
                    })
                    .catch(error => {
                        MessageToast.show(error);
                    });
            },

            onMassUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    oAssessmentModel = this.getView().getModel("assessmentModel"),
                    aFiles = oEvent.getParameter("files"),
                    sPath = oFileUploader.getBindingInfo("value").binding.getContext().getPath();


                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oAssessmentModel.setProperty(sPath + "/content", sFileContent.split(',')[1]);
                        oAssessmentModel.setProperty(sPath + "/fileName", oFile.name);
                        oAssessmentModel.setProperty(sPath + "/mediaType", oFile.type);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            //Set contributor's items value depending on the category
            onMassCategory2Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor2");
                });

                oModel.setProperty(sPath + "/contributor2", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            //Set contributor's items value depending on the category
            onMassCategory1Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor1");
                });

                oModel.setProperty(sPath + "/contributor1", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            //Set contributor's items value depending on the category
            onMassCategory3Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor3");
                });

                oModel.setProperty(sPath + "/contributor3", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            onMassClassChange: function (oEvent) {
                const oItem = oEvent.getSource(),
                    oContext = oItem.getBindingContext("assessmentModel"),
                    oRow = oEvent.getSource().getParent();

                this.resetMassCategoryFields(oContext);
                this.resetMassContributorFields(oContext);
                this.setRowEnabledFields(oRow);
            },

            onMessagePopoverPress: async function (oEvent) {
                const oSourceControl = oEvent.getSource();
                const oMessagePopover = await this._getMessagePopover();
                oMessagePopover.openBy(oSourceControl);
            },

            onMessagePopoverPress: async function (oEvent) {
                const oSourceControl = oEvent.getSource();
                const oMessagePopover = await this._getMessagePopover();
                oMessagePopover.openBy(oSourceControl);
            },

            onSelectionChange: function (oEvent) {
                let aSelectedItems = this.getView().byId("massItems").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedRows", aSelectedItems);
            },

            onPressDelete: async function () {
                let oPage = this.getView().byId("massPage"),
                    oContext = oPage.getBindingContext(),
                    oODataModel = this.getModel(),
                    oAssessmentModel = this.getModel("assessmentModel"),
                    oHistory = History.getInstance(),
                    sPreviousHash = oHistory.getPreviousHash(),
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel(),
                    oHeader = oAssessmentModel.getProperty("/header"),
                    sRequestId = oHeader.ID;

                sap.ui.getCore().getMessageManager().removeAllMessages();

                MessageBox.confirm(this.getResourceBundle().getText("confirmDeletion", oHeader.requestName), {
                    onClose: async function (sAction) {
                        if (sAction === 'OK') {
                            //oContext.delete("UpdateGroup");
                            this.getView().setBusy(true);
                            const sPath = "/" + "MassAssessmentHeader(" + sRequestId + ")";

                            const oContextBinding = oODataModel.bindContext(sPath, null, { $$updateGroupId: "$auto" });
                            await oContextBinding.requestObject();
                            const oContext = oContextBinding.getBoundContext();
                            //oModel.submitBatch("UpdateGroup").then(function () {
                            oContext.delete("$auto").then(function () {
                                this.getView().setBusy(false);
                                oAssessmentModel.setProperty("/header", null);
                                oAssessmentModel.setProperty("/Items", []);
                                // if (!oModel.hasPendingChanges("UpdateGroup")) {
                                if (sPreviousHash !== undefined) {
                                    window.history.go(-1);
                                }
                                /*  } else {
                                      let aMessage = oMessageModel.getData(),
                                          oLastMessage = aMessage[aMessage.length - 1];
                                      MessageBox.error(oLastMessage.getMessage());
                                  }*/
                            }.bind(this)).catch(function (oError) {
                                this.getView().setBusy(false);
                                MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                            }.bind(this));
                        }
                    }.bind(this)
                });
            },

            onMassUpload: function () {
                let aSelectedIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices();

                if (aSelectedIndices.length > 0) {
                    if (!this._massUploadProofPointsDialog) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.sustainability.overview.view.fragment.Assessment.MassUploadProofPointsDialog",
                            controller: this
                        }).then(function (oMassUploadProofPointsDialog) {
                            this._massUploadProofPointsDialog = oMassUploadProofPointsDialog;
                            this.getView().addDependent(this._massUploadProofPointsDialog);
                            this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                            this._massUploadProofPointsDialog.open();
                        }.bind(this));
                    } else {
                        this._massUploadProofPointsDialog.open();
                        this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                    }
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            onMassUploadAddProofRow: function () {
                let aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");
                aProofPoints.push({
                    "active": "Y"
                });
                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
            },

            onMassUploadDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                aSelectedIndices.reverse().forEach(function (iIndice) {
                    aProofPoints.splice(iIndice, 1);
                });

                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
                //this.getView().byId("massUploadProofTable").removeSelections(true);
            },

            onMapUploadDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                aSelectedIndices.reverse().forEach(function (iIndice) {
                    aProofPoints.splice(iIndice, 1);
                });

                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
                //this.getView().byId("massUploadProofTable").removeSelections(true);
            },

            onPressEdit: function () {
                this.getModel("assessmentModel").setProperty("/editMode", true);
                this.getView().byId("deleteButton").setVisible(false);
            },

            onAddNewItem: function () {
                let aSbu = [];
                aSbu.push(this.getModel("assessmentModel").getProperty("/sbu"));
                if (!this._addProductsDialog) {
                    this.getExtensionAPI().loadFragment({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.AddNewProductsDialog",
                        controller: this
                    }).then(function (oAddNewProductsDialog) {
                        this._addProductsDialog = oAddNewProductsDialog;
                        this.getView().addDependent(this._addProductsDialog);
                        this.getView().byId("ibDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                        this.getView().byId("idhDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                        this.getView().byId("ibDialogFilterbar").setFilterFieldEnabled("sbu", false);
                        this.getView().byId("idhDialogFilterbar").setFilterFieldEnabled("sbu", false);
                        this.getView().byId("idhDialogTable").getContent().clearSelection();
                        this.getView().byId("ibDialogTable").getContent().clearSelection();
                        this._addProductsDialog.open();
                    }.bind(this));
                } else {
                    this.getView().byId("ibDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                    this.getView().byId("idhDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                    this.getView().byId("ibDialogFilterbar").setFilterFieldEnabled("sbu", false);
                    this.getView().byId("idhDialogFilterbar").setFilterFieldEnabled("sbu", false);
                    this.getView().byId("idhDialogTable").getContent().clearSelection();
                    this.getView().byId("ibDialogTable").getContent().clearSelection();
                    this._addProductsDialog.open();
                }
            },

            onPasteItem: async function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    oCopyItem = this.getModel("assessmentModel").getProperty("/copyItem"),
                    bApprobeMode = this.getModel("assessmentModel").getProperty("/approbeMode"),
                    oRulesModel = this.getModel("rules").getProperty("/"),
                    oModel = this.getModel(),
                    oAssessmentModel = this.getView().getModel("assessmentModel"),
                    bShowMessage = false,
                    aProperties = [],
                    oPageContext = this.getView().byId("massPage").getBindingContext();

                this.getView().setBusyIndicatorDelay(0);
                this.getView().setBusy(true);

                if (bApprobeMode) {
                    aProperties = [
                        "approbalStatus",
                        "approberComment",
                        "externalCommunication"
                    ];
                } else {
                    aProperties = [
                        "comment",
                        "sustClass",
                        "category1",
                        "contributor1",
                        "category2",
                        "contributor2",
                        "category3",
                        "contributor3",
                        "propagation"
                    ];
                }

                const aFilteredProperties = [
                    "category1",
                    "contributor1",
                    "category2",
                    "contributor2",
                    "category3",
                    "contributor3"
                ];

                setTimeout(() => {
                    // Check if any rows are selected
                    if (aIndices.length > 0) {
                        for (let iIndex of aIndices) {
                            const oContext = oItemsTable.getContextByIndex(iIndex),
                                sItemPath = oContext.getPath(),
                                sRcPreFlag = oContext.getProperty("rcPreFlag");

                            if (oContext.getObject() === oCopyItem) {
                                continue;
                            }

                            if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag]["sustCodes"]) {
                                var oRulesSustCodes = oRulesModel[sRcPreFlag]["sustCodes"];

                                let sStatus = oContext.getProperty("status");

                                if (bApprobeMode && (sStatus !== '02' && sStatus !== '04')) {
                                    bShowMessage = true;
                                    continue;
                                }

                                if (!bApprobeMode && (sStatus !== '01' && sStatus !== '03' && sStatus !== '91')) {
                                    bShowMessage = true;
                                    continue;
                                }

                                // Check if the rcPreFlag of the selected row matches that of the copied item

                                if (oRulesSustCodes.codes.includes(oCopyItem["sustClass"]) && !bApprobeMode) {
                                    var oMassEnabledFlieds = oRulesModel[sRcPreFlag][oCopyItem["sustClass"]].massEnabled;

                                    // Copy properties from oCopyItem to the selected row
                                    for (let property of aProperties) {
                                        if (oCopyItem[property]) {
                                            oAssessmentModel.setProperty(`${sItemPath}/${property}`, oCopyItem[property]);

                                            if (property === "category1") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor1`, "");
                                            } else if (property === "category2") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor2`, "");
                                            } else if (property === "category3") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor3`, "");
                                            }
                                        } else {
                                            if (!oMassEnabledFlieds[property] && aFilteredProperties.includes(property) && !bApprobeMode) {
                                                oAssessmentModel.setProperty(`${sItemPath}/${property}`, "");
                                            }
                                        }
                                    }

                                    if (bApprobeMode) {
                                        continue;
                                    }

                                } else if (bApprobeMode) {
                                    for (let property of aProperties) {
                                        if (oCopyItem[property] !== null &&
                                            oCopyItem[property] !== undefined &&
                                            oCopyItem[property] !== "") {
                                            oAssessmentModel.setProperty(`${sItemPath}/${property}`, oCopyItem[property]);
                                        }
                                    }
                                } else {
                                    bShowMessage = true;
                                }
                            } else {
                                bShowMessage = true;
                            }
                        }

                        //if (oPageContext) {
                        this.updatedRowFields();
                        //}

                        // Show appropriate message after pasting the items
                        if (bShowMessage) {
                            MessageToast.show(this.getResourceBundle().getText("noSuccessPaste"));
                        } else {
                            MessageToast.show(this.getResourceBundle().getText("successPaste"));
                        }

                    } else {
                        // Show message if no rows are selected
                        MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                    }

                    this.getView().setBusy(false);
                }, 0);
            },

            onPasteItemApprovalStatus: function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    bApprobeMode = this.getModel("assessmentModel").getProperty("/approbeMode"),
                    oItemsTable = this.getView().byId("massItems"),
                    oCopyItem = this.getModel("assessmentModel").getProperty("/copyItem"),
                    oAssessmentModel = this.getView().getModel("assessmentModel"),
                    bShowMessage = false,
                    aProperties = [];

                this.getView().setBusyIndicatorDelay(0);
                this.getView().setBusy(true);

                aProperties = [
                    "approbalStatus",
                ];

                setTimeout(() => {
                    // Check if any rows are selected
                    if (aIndices.length > 0) {
                        for (let iIndex of aIndices) {
                            const oContext = oItemsTable.getContextByIndex(iIndex),
                                sItemPath = oContext.getPath(),
                                sStatus = oContext.getProperty("status");

                            if (oContext.getObject() === oCopyItem) {
                                continue;
                            }

                            if (!bApprobeMode && sStatus === '03') {
                                // Copy properties from oCopyItem to the selected row
                                for (let property of aProperties) {
                                    if (oCopyItem[property]) {
                                        oAssessmentModel.setProperty(`${sItemPath}/${property}`, oCopyItem[property]);
                                    }
                                }
                            } else {
                                bShowMessage = true;
                            }
                        }

                        this.updatedRowFields();

                        // Show appropriate message after pasting the items
                        if (bShowMessage) {
                            MessageToast.show(this.getResourceBundle().getText("noSuccessPaste"));
                        } else {
                            MessageToast.show(this.getResourceBundle().getText("successPaste"));
                        }

                    } else {
                        // Show message if no rows are selected
                        MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                    }

                    this.getView().setBusy(false);
                }, 0);
            },

            onPasteMassProofPoint: function () {
                let aIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    oCopyRow = this.getModel("assessmentModel").getProperty("/copyMassProofPoint");


                if (!oCopyRow) {
                    MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                    return;
                }

                const aProperties = [
                    "type",
                    "description"
                ];


                let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                for (let iIndex of aIndices) {

                    if (aMassProofPoints[iIndex]) {
                        let oTargetRow = aMassProofPoints[iIndex];


                        for (let sProperty of aProperties) {
                            if (oCopyRow.hasOwnProperty(sProperty)) {
                                if (oCopyRow[sProperty]) {
                                    oTargetRow[sProperty] = oCopyRow[sProperty];
                                }

                            }
                        }
                    }
                }


                this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);


                MessageToast.show(this.getResourceBundle().getText("pastedRows"));
            },

            onPasteMapProofPoint: function () {
                let aIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    oCopyRow = this.getModel("assessmentModel").getProperty("/copyMapProofPoint");


                if (!oCopyRow) {
                    MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                    return;
                }

                const aProperties = [
                    "type",
                    "description"
                ];


                let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                for (let iIndex of aIndices) {

                    if (aMassProofPoints[iIndex]) {
                        let oTargetRow = aMassProofPoints[iIndex];


                        for (let sProperty of aProperties) {
                            if (oCopyRow.hasOwnProperty(sProperty)) {
                                if (oCopyRow[sProperty]) {
                                    oTargetRow[sProperty] = oCopyRow[sProperty];
                                }
                            }
                        }
                    }
                }


                this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);


                MessageToast.show(this.getResourceBundle().getText("successPaste"));
            },

            onPressAdpDataCheck: function (oEvent) {
                const oContext = oEvent.getSource().getBindingContext("assessmentModel")
                if (!this._adpDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.AdpAdditionalDataDialog",
                        controller: this
                    }).then(function (oAdpDialog) {
                        this._adpDialog = oAdpDialog;
                        this.getView().addDependent(this._adpDialog);
                        //this._adpDialog.unbindElement();
                        //this._adpDialog.setBindingContext(null);
                        this._getAdpAdditionaData(oContext);


                    }.bind(this));
                } else {
                    this._getAdpAdditionaData(oContext);
                }
            },


            onPressProofPointsCheck: function (oEvent) {
                let oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel(),
                    oRulesModel = this.getModel("rules").getProperty("/"),
                    sRcPreFlag = oContext.getProperty("rcPreFlag"),
                    sSustClas = oContext.getProperty("sustClass");

                const sProcessType = oModel.getProperty('/header/processType');
                const bIsPdpProcess = (sProcessType === 'PDP');
                const bApprobeMode = oModel.getProperty('/approbeMode');

                if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClas]) {
                    const oRules = oRulesModel[sRcPreFlag][sSustClas];
                    const bProofEnable = !bApprobeMode && (oRules.proofEnabled || bIsPdpProcess);
                    this.setProofEnable(bProofEnable);
                    this.getModel("assessmentModel").setProperty("/rulesAddProofEnabled", oRules.proofEnabled);
                } else {
                    this.setProofEnable(false);
                }

                if (!this._proofPointsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.ProofPointsDialog",
                        controller: this
                    }).then(function (oProofPointsDialog) {
                        //this.getView().byId("proofPointsDialog").setBindingContext(oContext);
                        this._proofPointsDialog = oProofPointsDialog;
                        this.getView().addDependent(this._proofPointsDialog);
                        let oTable = this.getView().byId("proofTable"),
                            oBinding = oTable.getBinding("rows");

                        if (oBinding) {
                            let oFilter = new Filter("requestId", FilterOperator.EQ, oModel.getProperty(sPath + "/ID"));

                            oBinding.filter([oFilter]);
                        }
                        this._proofPointsDialog.open();
                        this.getModel("assessmentModel").setProperty("/itemContext", oContext);
                        //this.checkMandatoryProofFields(oContext);

                    }.bind(this));
                } else {
                    this.getModel("assessmentModel").setProperty("/itemContext", oContext);
                    let oTable = this.getView().byId("proofTable"),
                        oBinding = oTable.getBinding("rows");

                    if (oBinding) {
                        let oFilter = new Filter("requestId", FilterOperator.EQ, oContext.getProperty("ID"));

                        oBinding.filter([oFilter]);
                    }
                    this._proofPointsDialog.open();
                    //this.getView().byId("proofPointsDialog").setBindingContext(oContext);
                    //this.setProofTypesOptions(oContext);
                    //this._setProofValidTypes(oContext);


                    //this.checkMandatoryProofFields(oContext);
                }
            },

            /*onRowsUpdated: function (oEvent) {
                //let oContext = this.getView().getModel("ui").getProperty("/oContext")
                let oContext = this.getView().byId("massPage").getBindingContext();
                if (oContext) {
                    if (Object.keys(oContext).length !== 0) {
                        this.updatedRowFields(oContext);
                    }
                }
                //this.setMassSustClass(oContext);
            },*/

            onPressHeartDataCheck: function (oEvent) {
                // let oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                //     sPath = oContext.getPath(),
                //     oModel = oContext.getModel();
                const oContext = oEvent.getSource().getBindingContext("assessmentModel");
                const oAssessmentItem = oContext.getObject();
                // const sNewBindingPath = `/MassAssessmentItems(${oAssessmentItem.ID})`;

                const oModel = this.getView().getModel();
                // const oBindingContext = oModel.createBindingContext(`/MassAssessmentItems(${oAssessmentItem.ID})/SustainabilityManagement.getHeartDeltaData(...)`);
                const oBindingContext = oModel.bindContext(`/MassAssessmentItems(${oAssessmentItem.ID})/SustainabilityManagement.getHeartDeltaData(...)`);
                oBindingContext.invoke().then(
                    result => {
                        const oResult = oBindingContext.getBoundContext().getObject();

                        if (!this._heartAdditionalDataDialog) {

                            Fragment.load({
                                id: this.getView().getId(),
                                name: "com.sustainability.overview.view.fragment.Assessment.HeartAdditionalData",
                                controller: this
                            }).then(function (oDialog) {

                                this.getView().setModel(
                                    new JSONModel({
                                        deltaAdditionalData: oResult.value
                                    }
                                    ), "heartModel");
                                this._heartAdditionalDataDialog = oDialog;
                                this.getView().addDependent(this._heartAdditionalDataDialog);

                                // const oTable = this.getView().byId("heartDeltaTable");
                                // oTable.bindObject(sNewBindingPath);

                                this._heartAdditionalDataDialog.open();

                            }.bind(this));

                        } else {

                            this.getView().getModel("heartModel").setProperty("/deltaAdditionalData", oResult.value);
                            this._heartAdditionalDataDialog.open();

                        }

                    },
                    error => {
                        console.log('error', error);
                        MessageToast.show(error);
                    }
                )


            },

            onCloseHeartDeltaDialog(oEvent) {
                this._heartAdditionalDataDialog.close();
            },

            onProofRowsUpdated: function () {
                const oContext = this.getModel("assessmentModel").getProperty("/itemContext"),
                    bEditMode = this.getModel("assessmentModel").getProperty("/editMode");
                //Only set valid types if edi mode is active, view mode show all posible values
                if (bEditMode) {
                    if (Object.keys(oContext).length !== 0) {
                        this._setProofValidTypes(oContext);
                        this.setProofTypesOptions(oContext);
                    }
                }
            },

            onPressRelatedProductsDialog: async function (oEvent) {
                let oAssessmentModel = this.getModel("assessmentModel"),
                    oItemContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    //oHeaderContext = this.getView().byId("massPage").getBindingContext(),
                    sProduct = oAssessmentModel.getProperty(oItemContext.getPath() + "/product"),
                    oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aRelatedProducts = await this.getRelatedProductsData(oHeader.productType, sProduct);
                this.getModel("assessmentModel").setProperty("/productRelation", aRelatedProducts);

                if (!this._relatedproductsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.RelatedProductsDialog",
                        controller: this
                    }).then(function (oRelatedProductsDialog) {
                        this._relatedproductsDialog = oRelatedProductsDialog;
                        this.getView().addDependent(this._relatedproductsDialog);
                        this._relatedproductsDialog.open();

                    }.bind(this));
                } else {
                    this._relatedproductsDialog.open();
                }
            },

            onCloseRelatedProductsDialog: function () {
                this._relatedproductsDialog.close();
            },


            /**
            * Triggered each time the table rows are updated.
            * @public
            */
            onRowsUpdated: function (oEvent) {
                //let oContext = this.getView().getModel("ui").getProperty("/oContext")
                let oContext = this.getView().byId("massPage").getBindingContext();
                if (oContext) {
                    if (Object.keys(oContext).length !== 0) {
                        this.updatedRowFields(oContext);
                    }
                }
                //this.setMassSustClass(oContext);
            },

            onSubmit: async function () {
                const oAssessmentModel = this.getModel("assessmentModel"),
                    bApprobeMode = this.getModel("assessmentModel").getProperty("/approbeMode");
                let oModel = this.getModel(),
                    bApproveMode = this.getView().getModel("assessmentModel").getProperty("/approbeMode"),
                    sMessageText = this.getResourceBundle().getText(
                        bApproveMode ? "approvedDecisionGived" : "assessmentSubmited"
                    );

                let oHeader = oAssessmentModel.getProperty("/header");
                let aItems = oAssessmentModel.getProperty("/items");

                this.getView().setBusy(true);

                sap.ui.getCore().getMessageManager().removeAllMessages();

                if (oHeader.status === "01") {
                    oHeader.status = "02";
                    oAssessmentModel.setProperty("/header", oHeader);
                }

                const bApprove = aItems.some(item =>
                    ["03", "04", "05", "06"].includes(item.approbalStatus)
                );

                // Validate if approver does not set  items
                if (!bApprove && bApprobeMode) {
                    MessageBox.error(this.getResourceBundle().getText("noModifiedApprovalStatus"));
                    this.getView().setBusy(false);
                    return;
                }

                if (bApprove) {

                    const oActionODataContextBinding = oModel.bindContext("/updateMassAssessmentItemsBatch(...)");
                    const aItemsToUpdate = aItems.filter(item => {
                        return (item.status !== "05" && item.status !== "06" && item.approbalStatus !== item.status && item.approbalStatus);
                    }).map(item => {
                        // Only modified products
                        if (item.approbalStatus !== item.status) {
                            const oItem = {};
                            const bOnlyStatus = item.approbalStatus === "05" || item.approbalStatus === "06" || item.status !== "03";
                            if (bOnlyStatus) {
                                if (item.approbalStatus !== item.status) {
                                    oItem.ID = item.ID;
                                    oItem.approbalStatus = item.approbalStatus;
                                    oItem.approberComment = item.approberComment;
                                    oItem.externalCommunication = item.externalCommunication;
                                }
                            } else {
                                for (const key in item) oItem[key] = item[key];
                            }
                            return oItem;
                        }
                    });
                    if (aItemsToUpdate.length === 0) {
                        MessageBox.error(this.getResourceBundle().getText("noModifiedApprovalStatus"));
                        this.getView().setBusy(false);
                        return;
                    }
                    oActionODataContextBinding.setParameter("items", aItemsToUpdate);
                    oActionODataContextBinding.execute().then(
                        async function (oData, test) {
                            this.getView().setBusy(false);
                            const oActionContext = oActionODataContextBinding.getBoundContext();
                            if (oActionContext.getObject().value.length === 0) {
                                MessageBox.information(sMessageText, {
                                    onClose: function (sAction) {
                                        if (sAction === 'OK') {
                                            this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                                            this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                        }
                                    }.bind(this)
                                });
                            } else {
                                this.getView().setBusy(false);
                                MessageBox.error(oActionContext?.getObject()?.value?.[0]?.message);
                            }

                        }.bind(this)
                    ).catch(function (eroor) {
                        this.getView().setBusy(false);

                    }.bind(this));

                } else {
                    this.getModel("assessmentModel").setProperty("/userAction", "Submit");

                    this.openRecipientsDialog("02", oHeader.sbu, "");

                }

            },

            onSubmitDocuments: function () {
                let oModel = this.getModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                let oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    oItems = this.getModel("assessmentModel").getProperty("/items");

                const oActionODataContextBinding = oModel.bindContext("/submitProofpointsVirtualAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", oItems);

                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSubmited"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {
                                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    }.bind(this)
                ).catch(function (oError) {
                    this.getView().setBusy(false);
                }.bind(this));
            },

            onSave: function () {
                const oHeader = this.getModel("assessmentModel").getProperty("/header");
                this.getModel("assessmentModel").setProperty("/userAction", "Save");

                this.openRecipientsDialog("01", oHeader.sbu, "");

            },

            onApproberDecisionChange: function (oEvent) {

                // Retreive current and previous selection
                const oSelectedItem = oEvent.getParameter('selectedItem');
                const oAssessmentModel = this.getView().getModel('assessmentModel');
                const sProcessType = oAssessmentModel.getProperty('/header/processType');
                if (sProcessType === 'HRT') {

                    // For HEART assessment, approver comment is cleaned when changing 
                    // from approved to rejected status so that sending not allowed 
                    // values is avoided
                    const STATUS_REJECTED = '06';
                    const bIsRejectedInNew = (oSelectedItem?.getKey() === STATUS_REJECTED);

                    if (bIsRejectedInNew) {
                        const sPath = oEvent.getSource().getBindingContext('assessmentModel').getPath();
                        const sApproverCommentPath = `${sPath}/approberComment`;
                        oAssessmentModel.setProperty(sApproverCommentPath, '');
                    }
                }

            },

            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/
            _onMassAssessmentMatched: async function (oEvent) {
                let oView = this.getView().byId("massPage"),
                    sId = oEvent.getParameter("arguments").assessment,
                    aComposedRoles = this.getModel("ui").getProperty("/userParameters/composedRoles"),
                    sStartupParameter = this.getModel("ui").getProperty("/startupParameter"),
                    aProofTypes = [],
                    aPropagationValues = [],
                    aContributors = [],
                    aCategories = [],
                    aSustClass = [],
                    aAssessmentData = [];

                sap.ui.getCore().getMessageManager().removeAllMessages();

                //this.getView().byId("proofPointsPanel").setBindingContext(undefined);
                //oView.setBindingContext(undefined);   
                //this.getView().setBusy(true);
                //this.getView().byId("massItems").bindRows("toItems");

                this.getView().setBusy(true)
                sap.ui.getCore().getMessageManager().removeAllMessages();

                //For direct navigation roles could not retrived, in that cases should be readed before continue
                if (!aComposedRoles || aComposedRoles.length < 1) {
                    const oModel = this.getModel(),
                        oUserParametersBinding = oModel.bindContext("/GetUserParameters(...)"),
                        oGetRulesModelBiding = oModel.bindContext("/GetRulesModel(...)");

                    await oGetRulesModelBiding.execute().then(
                        function () {
                            let oActionContext = oGetRulesModelBiding.getBoundContext(),
                                sRulesModel = (oActionContext.getObject().value),
                                oRlesModel = JSON.parse(sRulesModel);
                            this.getModel("rules").setProperty("/", oRlesModel);

                        }.bind(this)
                    );

                    await oUserParametersBinding.execute().then(
                        function () {
                            let oActionContext = oUserParametersBinding.getBoundContext(),
                                oUserParameters = (oActionContext.getObject().value);

                            this.getModel("ui").setProperty("/userParameters", oUserParameters);
                            aComposedRoles = oUserParameters.composedRoles;

                        }.bind(this)
                    );
                }


                this.getView().byId("massItems").getDependents()[0].setLimit(0);
                aAssessmentData = await this.getAssessmentData(sId);
                let { toItems, ...oHeader } = aAssessmentData[0];
                this.getModel("assessmentModel").setProperty("/header", oHeader);
                this.getModel("assessmentModel").setProperty("/items", toItems);

                this._setButtonsVisibility(oHeader, toItems, aComposedRoles, sStartupParameter);

                // Additional configuration based on productType, assessmentType and SBU
                this.getModel("assessmentModel").setProperty("/type", oHeader.productType);
                this.getModel("assessmentModel").setProperty("/sbu", oHeader.sbu);
                this.getModel("assessmentModel").setProperty("/assesmentType", oHeader.assesmentType);

                aContributors = await this.getContributors();
                aCategories = await this.getCategories();
                aSustClass = await this.getSustClass();
                this.getModel("assessmentModel").setProperty("/contributors", aContributors);
                this.getModel("assessmentModel").setProperty("/categories", aCategories);
                this.getModel("assessmentModel").setProperty("/sustClass", aSustClass);

                this.getView().byId("massItems").bindRows("assessmentModel>/items");

                this.getView().setBusy(false);

                aProofTypes = await this.getProofTypes();

                this.getModel("assessmentModel").setProperty("/proofType", aProofTypes);

            },

            _getMessagePopover() {
                return this.loadFragment({
                    name: "com.sustainability.overview.view.fragment.MessagePopover"
                });
            },

            _getAdpAdditionaData: function (oContext) {
                const sProcessType = this.getModel("assessmentModel").getProperty("/header/processType");
                const sId = oContext.getProperty("ID");

                const sExpandPdp =
                    "toAdditionalData($expand=pdp($expand=sustainabilityClass,category1,contributor1,category2,contributor2,category3,contributor3))";

                const sExpandMoc =
                    "toAdditionalData($expand=moc($expand=sustainabilityClass,category1))";

                const sExpand = (sProcessType === "PDP") ? sExpandPdp : sExpandMoc;

                const oCtxBinding = this.getModel().bindContext(`/MassAssessmentItems(${sId})`, null, {
                    $expand: sExpand
                });

                oCtxBinding.requestObject().then(function (oData) {
                    this.getModel("assessmentModel").setProperty("/adpAdditionalData", oData);
                    this._adpDialog.open();
                }.bind(this))

                /* this._adpDialog.bindElement({
                     path: sPath,
                     parameters: {
                         expand: sExpand
                     },
                     events: {
                         dataReceived: function (oData) {
                             this._adpDialog.open();
                         }.bind(this)
                     }
                 });*/
            },

            _saveAssessment: async function () {
                const oModel = this.getModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                this.getModel("assessmentModel").setProperty("/header/status", "01");
                this.setItemsStatus("01");
                this.getView().setBusy(true);

                let oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aItems = this.getModel("assessmentModel").getProperty("/items");

                const oActionODataContextBinding = oModel.bindContext("/SaveMassAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", aItems);

                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSaved"));
                        this.getView().getModel("assessmentModel").setProperty("/editMode", false);
                    }.bind(this)
                ).catch(function (oError) {
                    this.getView().setBusy(false);

                }.bind(this));

            },

            _submitAssessment: async function () {
                const oModel = this.getModel();
                const oAssessmentModel = this.getModel("assessmentModel");
                let oHeader = oAssessmentModel.getProperty("/header"),
                    aItems = oAssessmentModel.getProperty("/items");

                this.getView().setBusy(true);

                sap.ui.getCore().getMessageManager().removeAllMessages();

                if (oHeader.status === "01") {
                    oHeader.status = "02";
                    oAssessmentModel.setProperty("/header", oHeader);
                }

                oAssessmentModel.setProperty("/header/status", "02");
                this.setItemsStatus("02");

                const oActionODataContextBinding = oModel.bindContext("/SubmitMassAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", aItems);

                this.getView().setBusy(true);
                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSubmited"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {
                                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    }.bind(this)
                ).catch(function (oError) {
                    this.getModel("assessmentModel").setProperty("/header/status", "01");
                    this.getView().setBusy(false);
                }.bind(this));
            },

            _setProofValidTypes: function (oContext) {

                this.checkRemoveTypeProofFields(oContext);
                //let aValidproofTypes = this.getValidProofTypes(oContext, this.getModel("assessmentModel").getProperty("/proofType"));
                //this.getModel("assessmentModel").setProperty("/validProofType", aValidproofTypes);
            },

            _setButtonsVisibility: function (oHeader, toItems, aComposedRoles, sStartupParameter) {
                // Retrieve user ID from the UI model
                const sUserId = this.getModel("ui").getProperty("/userParameters/userId"),
                    sSbu = oHeader.sbu,
                    sStatus = oHeader.status,
                    sAssessor = oHeader.assessor,
                    sSubmitter = oHeader.submitter,
                    sApprover = oHeader.approver,
                    virtualAssessment = oHeader.virtualAssessment,
                    sProcessType = oHeader.processType,
                    aItems = toItems;  // Retrieve assessment items

                // Set initial configuration for the assessment model
                this.getModel("assessmentModel").setProperty("/editMode", false);
                this.getView().getModel("assessmentModel").setProperty("/approbeMode", false);
                this.getView().getModel("assessmentModel").setProperty("/approberDataBlock", false);
                this.getView().getModel("assessmentModel").setProperty("/pasteApprovalStatus", false)

                // Enable approver data block if status is not empty or "01"
                if (sStatus !== "" && sStatus !== "01") {
                    this.getView().getModel("assessmentModel").setProperty("/approberDataBlock", true);
                }

                // Check if at least one item matches status "" or "01" or "03" (for Submitter and Assessor roles)
                let bItemStatusMatchedForSubmitterAssessor = aItems.some(item => {
                    return item.status === "" || item.status === "01" || item.status === "03";
                });

                // Check if at least one item matches status "02" or "04" (for Approver role)
                let bItemStatusMatchedForApprover = aItems.some(item => {
                    return item.status === "02" || item.status === "04";
                });

                // Conditions to display buttons based on role and item status

                // Case 1: Users with Submitter role can edit, delete, submit, and save
                if (bItemStatusMatchedForSubmitterAssessor &&
                    aComposedRoles.some(role => role === sSbu + ".Submitter") &&
                    (sUserId === sSubmitter || sSubmitter === "" || !sSubmitter)) {

                    this.getView().byId("editButton").setVisible(true);
                    this.getView().byId("submitButton").setVisible(true);
                    this.getView().byId("saveButton").setVisible(true);

                    if (this.getView().getModel("assessmentModel").getProperty("/approberDataBlock") && sStatus !== "" && sStatus !== "01") {
                        this.getView().getModel("assessmentModel").setProperty("/pasteApprovalStatus", true)
                    }

                    // Case 2: Users with Assessor role can edit, delete, and save, but cannot submit
                } else if (bItemStatusMatchedForSubmitterAssessor &&
                    aComposedRoles.some(role => role === sSbu + ".Assessor") && sStatus === "01") {

                    this.getView().byId("editButton").setVisible(true);
                    // this.getView().byId("deleteButton").setVisible(true);
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(true);

                    // Case 3: Users with Approver role can edit if at least one item has status "02" or "04"
                } else if (bItemStatusMatchedForApprover &&
                    aComposedRoles.some(role => role === sSbu + ".Approver") &&
                    (sUserId === sApprover || sApprover === "" || !sApprover)) {

                    this.getView().byId("editButton").setVisible(true);
                    this.getView().byId("deleteButton").setVisible(false);
                    this.getView().getModel("assessmentModel").setProperty("/approbeMode", true);
                    this.getView().byId("submitButton").setVisible(true);

                    //Edit mode by default
                    if (sStartupParameter === "approval") {
                        this.getView().byId("editButton").setVisible(false);
                        this.getModel("assessmentModel").setProperty("/editMode", true);
                    }

                    // In draft status
                } else if (sStatus === "91" && sUserId === sAssessor) {
                    this.getView().byId("editButton").setVisible(true);
                    this.getView().byId("submitButton").setVisible(true);
                    this.getView().byId("saveButton").setVisible(true);
                    this.getView().byId("deleteButton").setVisible(true);
                } else {
                    this.getView().byId("editButton").setVisible(false);
                    this.getView().byId("deleteButton").setVisible(false);
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(false);
                }

                // Show delete button if status is "01" and the user has a Submitter or Assessor role
                if (sStatus === "01" &&
                    (aComposedRoles.some(role => role === sSbu + ".Submitter") || aComposedRoles.some(role => role === sSbu + ".Assessor")) &&
                    (sUserId === sSubmitter || sUserId === sAssessor || sSubmitter === "")) {
                    this.getView().byId("deleteButton").setVisible(true);
                } else {
                    if (sStatus !== "91") {
                        this.getView().byId("deleteButton").setVisible(false);
                    }

                }

                //Delete and save button not posible for other status
                if (sStatus !== "01" && sStatus !== "91") {
                    this.getView().byId("saveButton").setVisible(false);
                    this.getView().byId("deleteButton").setVisible(false);
                }

                //Delete  button not posible for PDP and MOC assessments
                if (sProcessType === "PDP" || sProcessType === "MOC") {
                    this.getView().byId("deleteButton").setVisible(false);
                }

                //Only add documents funcionality has a specific special logic that overwrite the last cases
                if (virtualAssessment && (sStatus === '91' || sStatus === '01') && sUserId === sAssessor) {
                    this.getModel("assessmentModel").setProperty("/onlyDocuments", true);
                    this.getModel("assessmentModel").setProperty("/editMode", false);
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(false);
                    this.getView().byId("editButton").setVisible(false);
                } else {
                    this.getModel("assessmentModel").setProperty("/onlyDocuments", false);
                }

            }

        });
    }
);