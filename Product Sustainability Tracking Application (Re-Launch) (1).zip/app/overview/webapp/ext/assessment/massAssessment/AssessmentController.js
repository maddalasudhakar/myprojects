sap.ui.define([
	"sap/fe/core/PageController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet",
	"sap/ui/export/library",    	
], function (PageController, Filter, FilterOperator, Fragment, MessageBox, MessageToast, Spreadsheet, exportLibrary) {
	"use strict";

    const EdmType = exportLibrary.EdmType;

	return PageController.extend("com.sustainability.overview.ext.assessment.massAssessment.AssessmentController", {

		initialize: function () {
			PageController.prototype.onInit.apply(this);
		},

		createProofPointsFragment: async function (oContext) {
			let oProofPointsDialog = await Fragment.load({
				id: this.getView().getId(),
				name: "com.sustainability.overview.view.fragment.Assessment.ProofPointsDialog",
				controller: this
			});
			this._proofPointsDialog = oProofPointsDialog;
			this.getView().byId("proofTable").setBindingContext(oContext);
			this.getView().addDependent(this._proofPointsDialog);
		},

		/**
		 * Get all the proof type 
		 * @public
		 */
		getProofTypes: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/ProofType");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oProofType) {
				return oProofType.getObject();
			});
		},

		getAssessmentData: async function (sId) {
			const oFilter = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, sId);
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/MassAssessmentHeader", null, null, [oFilter], {
					$expand: "toItems,toStatus"
				});

			const aAssessmentData = await oContextBinding.requestContexts();

			return await aAssessmentData.map(function (oAssessmetData) {
				return oAssessmetData.getObject();
			});
		},

		getContributors: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/Contributor");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oContributor) {
				return oContributor.getObject();
			});
		},

		getCategories: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/SustainabilityCategory");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oCategory) {
				return oCategory.getObject();
			});
		},

		getSustClass: async function () {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/SustainabilityClass");

			const aProofTypeContext = await oContextBinding.requestContexts();

			return await aProofTypeContext.map(function (oSustClass) {
				return oSustClass.getObject();
			});
		},

		getMessagePopover: async function () {

			return await Fragment.load({
				id: this.getView().getId(),
				name: "com.sustainability.overview.view.fragment.MessagePopover",
				controller: this
			});
		},

		getRelatedProductsData: async function (sType, sProduct) {
			let oModel = this.getModel(),
				sPath = "/getRelatedProductsData(productType='" + sType + "',product='" + sProduct + "')";

			this.getView().setBusy(true);

			let aRelatedproductData = await oModel.bindContext(sPath).requestObject().then((oObject) => {
				this.getView().setBusy(false);
				return oObject.value;
			}).catch((oError) => {
				this.getView().setBusy(false);
			});

			return aRelatedproductData;
		},

		getIbLinkedToIdh: async function (aMaterials) {
			let oModel = this.getModel(),
				sEncodedMaterials = encodeURIComponent(JSON.stringify(aMaterials)),
				sPath = "/getIbLinkedToIdh(materials='" + aMaterials + "')";

			//this.getView().setBusy(true);

			let aRelatedMaterialtData = await oModel.bindContext(sPath).requestObject().then((oObject) => {
				//this.getView().setBusy(false);
				return oObject.value;
			}).catch((oError) => {
				this.getView().setBusy(false);
			});

			return aRelatedMaterialtData;
		},

		/**
		 * Get valid Proof Types depending on the Item's contributors
		 * @public
		 */
		getValidProofTypes: function (oContext, aProoftypes) {
			let oProofTypesMap = this._getProofTypesMap(aProoftypes),
				aValidProofTypes = [],
				aProofTypeRule = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types as well
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				aContributors = [sContributor1, sContributor2, sContributor3],
				sRcPreFlag = oContext.getProperty("rcPreFlag");

			// Add regular proof types based on contributors
			aProofTypeRule.forEach(function (rule) {
				aContributors.forEach(function (contributor) {
					if (rule.contributorId.includes(contributor) && !aValidProofTypes.some(proofType => proofType.code === rule.typeId)) {
						if (oProofTypesMap[rule.typeId]) {
							aValidProofTypes.push(oProofTypesMap[rule.typeId]);
						}
					}
				});
			});

			// Check if sRcPreFlag is a special case and add additional proof types if applicable
			let aSpecialProofTypesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
				return specialRule.sustClass === sRcPreFlag;
			});

			if (aSpecialProofTypesForsRcPreFlag.length > 0) {
				aSpecialProofTypesForsRcPreFlag.forEach(function (specialRule) {
					specialRule.typeId.forEach(function (specialTypeId) {
						// Add the special type if it exists in the proof type map and hasn't been added already
						if (oProofTypesMap[specialTypeId] && !aValidProofTypes.some(proofType => proofType.code === specialTypeId)) {
							aValidProofTypes.push(oProofTypesMap[specialTypeId]);
						}
					});
				});
			}

			return aValidProofTypes;
		},

		/**
		* Helper function to enable proof documents fields
		* @public
		*/
		setProofEnable: function (bEnabled) {
			this.getModel("assessmentModel").setProperty("/proofEnabled", bEnabled);
		},

		checkAssessmentData: async function (aAssessmentData) {
			let oModel = this.getModel(),
				oContextBinding = oModel.bindList("/Contributor");

			var oRulesModel = this.getModel("rules").getProperty("/");

			const aContributorContext = await oContextBinding.requestContexts();

			var aContributors = await aContributorContext.map(function (oContributor) {
				return oContributor.getObject();
			});

			aAssessmentData.forEach(oAssessmetData => {

				for (const key in oAssessmetData) {
					if (oAssessmetData.hasOwnProperty(key)) {
						switch (key) {
							case "rcPreFlag":

							case "sustClass":
								const oRules = oRulesModel[oAssessmetData["rcPreFlag"]];
								if (!oRules.sustCodes.codes.includes(oAssessmetData[key])) {
									delete oAssessmetData["sustClass"];
									delete oAssessmetData["category1"];
									delete oAssessmetData["contributor1"];
									delete oAssessmetData["category2"];
									delete oAssessmetData["contributor2"];
									delete oAssessmetData["category3"];
									delete oAssessmetData["contributor"];
								}
								break;
							case "contributor1":
								const sCategory1 = oAssessmetData["category1"];
								const sContributor1 = oAssessmetData[key];

								if (sContributor1 && sCategory1 &&
									!aContributors.some(oContributor =>
										oContributor.code === sContributor1 && oContributor.categoryCode === sCategory1
									)) {
									delete oAssessmetData["contributor1"];
								}
								break;

							case "contributor2":
								const sCategory2 = oAssessmetData["category2"];
								const sContributor2 = oAssessmetData[key];

								if (sContributor2 && sCategory2 &&
									!aContributors.some(oContributor =>
										oContributor.code === sContributor2 && oContributor.categoryCode === sCategory2
									)) {
									delete oAssessmetData["contributor2"];
								}
								break;

							case "contributor3":
								const sCategory3 = oAssessmetData["category3"];
								const sContributor3 = oAssessmetData[key];

								if (sContributor3 && sCategory3 &&
									!aContributors.some(oContributor =>
										oContributor.code === sContributor3 && oContributor.categoryCode === sCategory3
									)) {
									delete oAssessmetData["contributor3"];
								}
								break;


							default:

						}

					}
				}
			});


			return aAssessmentData;
		},

		/**
			* Removes duplicated products by comparing them to existing items.
			* 
			* @public
			*/
		checkDuplicatedProducts: function (aProducts) {
			let aItems = this.getModel("assessmentModel").getProperty("/items");

			// Filter products, keeping duplicates
			let aDuplicatedProducts = aProducts.filter(product =>
				aItems.some(item => item.product === product.materialtNumber)
			);

			// Return the array with duplicated products
			return aDuplicatedProducts;
		},

		checkProductsInAssessment: async function (aProducts) {
			let aProductIds = aProducts.map(product => product.materialtNumber),
				sProducts = JSON.stringify(aProductIds),
				sPath = "/checkProductInAssessment(products='" + encodeURIComponent(sProducts) + "')",
				oModel = this.getModel();

			let aProductsInAssessment = [];

			await oModel.bindContext(sPath).requestObject().then((oObject) => {
				const aProductsToKeep = oObject.value;

				// Keep only products that are in assessment
				aProductsInAssessment = aProducts.filter(product =>
					aProductsToKeep.some(item => item.product === product.materialtNumber)
				).map(product => {
					const oProductInAssessment = aProductsToKeep.find(item => item.product === product.materialtNumber);
					const oReturn = { ...product, requestName: oProductInAssessment.requestName };
					return oReturn;
				});

			}).catch((oError) => {
				aProductsInAssessment = [];
			});

			return aProductsInAssessment;
		},

		/**
		 * Check mandatory proof fields of Single Assessment
		 * @public
		 */
		checkMassMandatoryProofFields: function (oContext, aProofContext, bMandadotry) {
			let oItem = {},
				bValid = true,
				bHasActiveProofDocument = false;

			if (oContext) {
				oItem = oContext.getObject();

				if (bMandadotry && oItem.toProofDocuments.length === 0) {
					return false;
				}

				for (const oProofDocument of oItem.toProofDocuments) {
					if ((!oProofDocument.type || !oProofDocument.description || !oProofDocument.fileName) &&
						(!oProofDocument.imageMasterID && oProofDocument.active)) {
						bValid = false;
						break;
					}

					if (oProofDocument.active) {
						bHasActiveProofDocument = true;
					}

				}
				//return bValid;

			} else {

				if (bMandadotry && aProofContext.length === 0) {
					return false;
				}

				for (const oProofContext of aProofContext) {
					if ((!oProofContext.getProperty("type") || !oProofContext.getProperty("description") || !oProofContext.getProperty("fileName")) &&
						(!oProofContext.getProperty("imageMasterID") && oProofContext.getProperty("active"))) {
						bValid = false;
						break;
					}

					if (oProofContext.getProperty("active")) {
						bHasActiveProofDocument = true;
					}
				}
				//return bValid;
			}

			if (bMandadotry && !bHasActiveProofDocument) {
				bValid = false;
			}

			return bValid;
		},

		/**
 * Check if the type matches with the contributors and sustClass (special cases) for mass assessments
 * @public
 */
		checkTypeProofFields: function (oContext, oProofDocument, aProofContext) {
			let aProofTypeRulesModel = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types
				aProofDocuments = [],
				oItem = oContext.getObject(),
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				sSustClass = oContext.getProperty("sustClass"),
				bValid = true,
				bValidForContributors = false,
				bValidForSustClass = false;

			// Collect proof documents
			if (oProofDocument) {
				aProofDocuments.push(oProofDocument);
			} else if (aProofContext.length > 0) {
				for (const oProofContext of aProofContext) {
					aProofDocuments.push(oProofContext.getObject());
				}
			} else {
				aProofDocuments = oItem.toProofDocuments;
			}

			// Loop through proof documents and validate
			for (const oProofDocument of aProofDocuments) {
				let sType = oProofDocument.type;

				if (sType) {
					let oEntry = aProofTypeRulesModel.find(function (aRule) {
						return aRule.typeId === sType;
					});

					if (oEntry) {
						// Check if the type is valid for contributors
						bValidForContributors = oEntry.contributorId.includes(sContributor1) || oEntry.contributorId.includes(sContributor2) ||
							oEntry.contributorId.includes(sContributor3) || oEntry.contributorId.includes(sRcPreFlag);
					}

					// Check if the type is valid for special sRcPreFlag
					let aSpecialRulesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
						return specialRule.sustClass === sRcPreFlag;
					});

					if (aSpecialRulesForsRcPreFlag.length > 0) {
						// If it is a special case, validate for sRcPreFlag
						bValidForSustClass = aSpecialRulesForsRcPreFlag.some(function (specialRule) {
							return specialRule.typeId.includes(sType);
						});
					}

					// If not valid for both contributors and sustClass, mark as invalid
					if (!bValidForContributors && !bValidForSustClass) {
						bValid = false;
						break; // No need to continue checking other documents if one is invalid
					}
				}
			}

			return bValid;
		},

		/**
 * Check if the proofType matches with the valid proofTypes (contributors and sustClass special cases)
 * If the proofType doesn't match, it is deleted
 * @public
 */
		checkRemoveTypeProofFields: function (oContext) {
			let oTable = this.byId("proofTable"),
				aItems = oTable.getRows(),
				aProofTypeRulesModel = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				sSustClass = oContext.getProperty("sustClass"),
				bValid = true;

			aItems.forEach((oItem) => {

				if (!oItem.getBindingContext()) {
					return;
				}

				let sType = oItem.getBindingContext().getProperty("type");
				let bActive = oItem.getBindingContext().getProperty("active");
				if (sType !== null && sType !== undefined && sType !== "") {
					let oEntry = aProofTypeRulesModel.find(function (item) {
						return item.typeId === sType;
					});

					// Check if the type is valid for contributors
					let bValidForContributors = false;
					if (oEntry) {
						bValidForContributors = oEntry.contributorId.includes(sContributor1) || oEntry.contributorId.includes(sContributor2) ||
							oEntry.contributorId.includes(sContributor3) || oEntry.contributorId.includes(sRcPreFlag);
					}

					// Check if the type is valid for special sRcPreFlag
					let bValidForSustClass = false;
					let aSpecialRulesForsRcPreFlag = aSpecialProofTypes.filter(function (specialRule) {
						return specialRule.sustClass === sRcPreFlag;
					});

					if (aSpecialRulesForsRcPreFlag.length > 0) {
						bValidForSustClass = aSpecialRulesForsRcPreFlag.some(function (specialRule) {
							return specialRule.typeId.includes(sType);
						});
					}

					// If not valid for both contributors and sRcPreFlag, remove the proof type
					if (!bValidForContributors && !bValidForSustClass && bActive) {
						oItem.getAggregation("cells")[1].setSelectedKey("");
						bValid = false; // Mark as invalid
					}
				}
			});

			return bValid;
		},

		setProofTypesOptions: function (oContext) {
			let oTable = this.byId("proofTable"),
				aItems = oTable.getRows(),
				aProofTypeRulesModel = this.getModel("rules").getProperty("/proofTypes"),
				aSpecialProofTypes = this.getModel("rules").getProperty("/expecialProofTypes"), // Retrieve special proof types
				sContributor1 = oContext.getProperty("contributor1"),
				sContributor2 = oContext.getProperty("contributor2"),
				sContributor3 = oContext.getProperty("contributor3"),
				sRcPreFlag = oContext.getProperty("rcPreFlag"),
				aValidTypes = [],
				aSpecialTypes = [],
				aCells = [],
				aFilters = [];

			// Consolidate all contributors into one array
			let aContributors = [sContributor1, sContributor2, sContributor3].filter(Boolean);

			// Determine valid proof types based on contributors
			if (aContributors.length > 0) {
				aValidTypes = aProofTypeRulesModel
					.filter(oProofType =>
						oProofType.contributorId.some(contributor => aContributors.includes(contributor))
					)
					.map(oProofType => oProofType.typeId);
			}

			// If rcPreFlag is active, include special proof types
			if (sRcPreFlag) {
				aSpecialTypes = aSpecialProofTypes
					.filter(oSpecialType =>
						oSpecialType.sustClass === sRcPreFlag
					)
					.flatMap(oSpecialType => oSpecialType.typeId);
				//aValidTypes = [...new Set([...aValidTypes, ...aSpecialTypes])]; // Ensure no duplicates
			}

			let aMergedArray = aValidTypes.concat(
				aSpecialTypes.filter(type => !aValidTypes.includes(type))
			);


			// Iterate over table rows and apply filters
			for (const oItem of aItems) {
				if (!oItem.getBindingContext()) {
					continue;
				}

				aCells = oItem.getCells();

				aCells.forEach(oCell => {
					if (oCell.getId().includes("proofTypeId")) {
						aFilters = [];
						if (oItem.getBindingContext().getProperty("active")) {
							// Create a filter for valid proof types
							if (aMergedArray.length > 0) {
								aMergedArray.forEach(sType => {
									aFilters.push(new sap.ui.model.Filter({
										path: "code",
										operator: FilterOperator.EQ,
										value1: sType
									}));
								});
							} else {
								aFilters.push(new sap.ui.model.Filter({
									path: "code",
									operator: FilterOperator.EQ,
									value1: "empty"
								}));
							}
						}

						// Apply the filter to the cell's binding
						oCell.getBinding("items").filter(aFilters);
					}
				});
			}
		},

		/**
		* Set values of contributor field in a row, depending on the category value
		* @public
		*/
		setMassContributorItems: function (sSelectedKey, oContributorField) {
			let aFilters = [],
				oBinding = oContributorField.getBinding("items");

			if (sSelectedKey) {
				aFilters.push(new Filter("categoryCode", FilterOperator.EQ, sSelectedKey));
			}

			oBinding.filter(aFilters);
		},

		/**
		* Check mandatory row fields
		* @public
		*/
		checkMassField: async function (oContext) {
			let //oRulesModel = this.getModel("rules").getProperty("/"),
				//sRcPreFlag = oContext.getProperty("rcPreFlag"),
				//sSustClass = oContext.getProperty("sustClass"),
				sApprobalStatus = oContext.getProperty("approbalStatus"),
				sApproberComment = oContext.getProperty("approberComment"),
				//sRequestName = this.getView().byId("massPage").getBindingContext().getProperty("requestName"),
				bApprobeMode = this.getView().getModel("assessmentModel").getProperty("/approbeMode"),
				sValue = "",
				oAssessement = oContext.getObject(),
				bContinue = true,
				oContinue = {
					"items": true,
					"prooPoints": true
				};

			/*if (!sRequestName) {
				oContinue.items = false;
				return oContinue;
			}*/

			if (!sApproberComment && (sApprobalStatus === "03" || sApprobalStatus === "06")) {
				oContinue.items = false;
				return oContinue;
			}

			if (bApprobeMode && !sApprobalStatus) {
				oContinue.items = false;
				return oContinue;
			}

			if (bApprobeMode) {
				return oContinue;
			}

			/*if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustClass];

				if (oRules.proofEnabled) {
					if (!oContext.isTransient()) {

						if (!this._proofPointsDialog) {
							await this.createProofPointsFragment(oContext);

						} else {
							this.getView().byId("proofTable").setBindingContext(oContext);
						}

						let aProofontext = await this.getView().byId("proofTable").getBinding("rows").requestContexts(0, Infinity);
						bContinue = this.checkMassMandatoryProofFields(null, aProofontext, oRules.proofMandatory);
						if (!bContinue) {
							oContinue.prooPoints = false;
							return oContinue;
						}
						bContinue = this.checkTypeProofFields(oContext, {}, aProofontext);
						if (!bContinue) {
							oContinue.prooPoints = false;
							return oContinue;
						}

					} else {
						bContinue = this.checkMassMandatoryProofFields(oContext, [], oRules.proofMandatory);
						if (!bContinue) {
							oContinue.prooPoints = false;
							return oContinue;
						}
						bContinue = this.checkTypeProofFields(oContext, {}, []);
						if (!bContinue) {
							oContinue.prooPoints = false;
							return oContinue;
						}
					}
				}*/

			//bContinue = this.checkMassMandatoryProofFields(aProofontext);
			/*if (!bContinue) {
				return bContinue;
			}
			bContinue = this.checkTypeProofFields(oContext, {}, aProofontext);
			if (!bContinue) {
				return bContinue;
			}*/
			//}
			/*if (bContinue) {
				for (const [sKey, bMandadotry] of Object.entries(oRules.mandatory)) {
					sValue = oContext.getProperty(sKey)
					if (bMandadotry && (sValue === undefined || sValue === null || sValue === "" || sValue === "00")) {
						bContinue = false;
						oContinue.items = false;
						break;
					}
				}
			}

			if (bContinue) {
				if ((oAssessement.category1 && !oAssessement.contributor1) || (oAssessement.category2 && !oAssessement.contributor2) ||
					(oAssessement.category3 && !oAssessement.contributor3)) {
					bContinue = false;
					oContinue.items = false;
				}
			}

		} else if ((sRcPreFlag === undefined || sRcPreFlag === null || sRcPreFlag === "") || (sSustClass === undefined || sSustClass === null || sSustClass === "")) {
			bContinue = false;
			oContinue.items = false;
		}*/

			return oContinue;
		},

		/**
		 * Check all the tablés fields
		 * @public
		 */
		checkMassFields: async function (oContextBinding) {
			let oContinue = {
				"items": true,
				"prooPoints": true
			};

			const aItemContext = await oContextBinding.requestContexts();

			//const oContextBinding2 = this.getModel().getKeepAliveContext(aItemContext[0].getPath() + "/toProofDocuments");
			//      const oProduct = await oContextBinding2.requestObject();
			//      let odata = await oModel.bindContext(aItemContext[0].getPath() + "/toProofDocuments").requestObject();
			for (const oItemContext of aItemContext) {

				oContinue = await this.checkMassField(oItemContext);
				if (!oContinue.items || !oContinue.prooPoints) {
					break;
				}
			}
			return oContinue;
		},

		/**
		* Set values of sustainability class field per each row, depending on the rcPreFlag value
		* @public
		*/
		setMassSustClass: function (oContext) {
			let aRows = this.getView().byId("massItems").getRows(),
				oRulesModel = this.getModel("rules").getProperty("/");

			aRows.forEach((oRow, index) => {
				this.setRowSustClass(oRow, oContext.getObject().toItems[index].rcPreFlag, oRulesModel);

			});

		},

		/**
		 * Set the list of the sustainability class depending on the RCPreFlag value
		 * @public
		 */
		setRowSustClass: function (oRow, sRcPreFlag, oRulesModel) {
			let aCells = oRow.getCells(),
				aFilters = [];

			aCells.forEach((oCell) => {

				if (oCell.getId().includes("sustClassId")) {
					aFilters = [];
					if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag]["sustCodes"]) {
						const oRules = oRulesModel[sRcPreFlag]["sustCodes"];
						oRules.codes.forEach(sCode => {
							aFilters.push(new Filter("code", FilterOperator.EQ, sCode));
						});

						oCell.getBinding("items").filter(aFilters);
					}

				}

			});
		},

		setRowContributors: function (oRow) {
			const aCells = oRow.getCells();
			const oContext = oRow.getBindingContext("assessmentModel");
			if (!oContext) return;

			const oItem = oContext.getObject();
			let aFilters;

			aCells.forEach((oCell) => {
				const sId = oCell.getId();

				if (sId.includes("contributor1")) {
					aFilters = [];

					if (oItem.category1) {
						aFilters.push(new Filter("categoryCode", FilterOperator.EQ, oItem.category1));
						oCell.getBinding("items").filter(aFilters);
					}

				} else if (sId.includes("contributor2")) {
					aFilters = [];

					if (oItem.category2) {
						aFilters.push(new Filter("categoryCode", FilterOperator.EQ, oItem.category2));
						oCell.getBinding("items").filter(aFilters);
					}

				} else if (sId.includes("contributor3")) {
					aFilters = [];

					if (oItem.category3) {
						aFilters.push(new Filter("categoryCode", FilterOperator.EQ, oItem.category3));
						oCell.getBinding("items").filter(aFilters);
					}
				}
			});
		},

		setApprobalStatus: function (oRow) {
			const aCells = oRow.getCells();
			const oContext = oRow.getBindingContext("assessmentModel");
			if (!oContext) return;

			const oItem = oContext.getObject();
			let aFilters;

			aCells.forEach((oCell) => {
				if (oCell.getId().includes("approbalStatus")) {
					aFilters = [];

					if (oItem.status) {
						aFilters.push(new Filter("filterStatus", FilterOperator.EQ, oItem.status));
						oCell.getBinding("items").filter(aFilters);
					}
				}
			});
		},

		/**
		* Set enabled fields per each row depending on Sustainability Class and rcPreFlag
		* @public
		*/
		setRowEnabledFields: function (oRow) {
			//const oContext = oControlInRow.getBindingContext("assessmentModel");
			const oContext = oRow.getBindingContext("assessmentModel");
			if (!oContext) return;
			const sPath = oContext.getPath(),
				oModel = oContext.getModel();

			const oRulesModel = this.getModel("rules").getProperty("/");

			const sRcPreFlag = oModel.getProperty(sPath + "/rcPreFlag") ?? "";
			const sSustClass = oModel.getProperty(sPath + "/sustClass") ?? "sustCodes";

			if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClass]) {
				const oRules = oRulesModel[sRcPreFlag][sSustClass]["massEnabled"];


				//const oRow = oControlInRow.getParent();
				const aCells = oRow.getCells();

				aCells.forEach((oCell) => {
					const sCellId = oCell.getId();

					if (sCellId.includes("category1")) {
						oCell.setEnabled(oRules.category1);
						if (!oRules.category1) {
							oModel.setProperty(sPath + "/category1", "");
							oModel.setProperty(sPath + "/contributor1", "");
						}
					}

					if (sCellId.includes("category2")) {
						oCell.setEnabled(oRules.category2);
						if (!oRules.category2) {
							oModel.setProperty(sPath + "/category2", "");
							oModel.setProperty(sPath + "/contributor2", "");
						}
					}

					if (sCellId.includes("category3")) {
						oCell.setEnabled(oRules.category3);
						if (!oRules.category3) {
							oModel.setProperty(sPath + "/category3", "");
							oModel.setProperty(sPath + "/contributor3", "");
						}
					}
				});
			}
		},

		/**
		 * Set enabled fields in the items table
		 * @public
		 */
		setMassEnabledFields: function () {
			let aRows = this.getView().byId("massItems").getRows();

			aRows.forEach((oRow) => {

				this.setRowEnabledFields(oRow);

			});
		},

		/**
		* Reset category row fields value
		* @public
		*/
		resetMassCategoryFields: function (oContext) {
			const sPath = oContext.getPath();
			const oModel = oContext.getModel();

			oModel.setProperty(sPath + "/category1", "");
			oModel.setProperty(sPath + "/category2", "");
			oModel.setProperty(sPath + "/category3", "");
		},

		/**
		* Reset contributor row fields value
		* @public
		*/
		resetMassContributorFields: function (oContext) {
			const sPath = oContext.getPath();
			const oModel = oContext.getModel();

			oModel.setProperty(sPath + "/contributor1", "");
			oModel.setProperty(sPath + "/contributor2", "");
			oModel.setProperty(sPath + "/contributor3", "");
		},

		/**
		 * Get all the proof type list
		 * @public
		 */
		updatedRowFields: function () {
			let aRows = this.getView().byId("massItems").getRows(),
				oRulesModel = this.getModel("rules").getProperty("/"),
				//oObject = oContext.getObject(),
				sProduct = this.getModel("assessmentModel").getProperty("/type");
			let aItems = this.getModel("assessmentModel").getProperty("/items");

			aRows.forEach((oRow, index) => {
				const oContext = oRow.getBindingContext("assessmentModel");
				if (!oContext) {
					return;
				}
				const sPath = oContext.getPath();
				const sPropagation = this.getModel("assessmentModel").getProperty(sPath + "/propagation");

				if (aItems && aItems[index] && oContext) {
					if (sPropagation === "true" || sPropagation === "false") {
						this.getModel("assessmentModel").setProperty(sPath + "/propagation", sProduct === "IDH");
					}

					const rcPreFlag = this.getModel("assessmentModel").getProperty(sPath + "/rcPreFlag");
					this.setRowSustClass(oRow, rcPreFlag, oRulesModel);
					this.setRowContributors(oRow);
					this.setApprobalStatus(oRow);
					this.setRowEnabledFields(oRow);
				}
			});

		},
		/**
		 * Get the data of the selectd products
		 * @public
		 */
		getProductsData: async function (aSelectedContext) {
			/*let aProducts = [];
			const promises = aSelectedContext.map(async (oSelectedContext) => {
				if (oSelectedContext.getPath()) {
					const oContextBinding = this.getModel().getKeepAliveContext(oSelectedContext.getPath());
					const oProduct = await oContextBinding.requestObject();
					if (oProduct !== undefined) {
						aProducts.push(oProduct);
					}
				}
			});
	    
			await Promise.all(promises);
	    
			return aProducts;*/
			let aProducts = [];
			const promises = aSelectedContext.map(async (oSelectedContext) => {
				if (oSelectedContext.getPath()) {
					//const oContextBinding = this.getModel().getKeepAliveContext(oSelectedContext.getPath());
					//const oProduct = await oContextBinding.requestObject();
					const oProduct = oSelectedContext.getObject();
					if (oProduct !== undefined) {
						aProducts.push(oProduct);
					}
				}
			});

			await Promise.all(promises);

			return aProducts;
		},

		/*_getProductsDocuments: async function (aProducts) {
			let aFilters = [],
				oContextBinding = {};

			aFilters = await aProducts.map(function (oProduct) {
				let sFormattedMaterialNumber = oProduct.materialtNumber.replace(/^0+/, '');
				return (new Filter("product", FilterOperator.EQ, sFormattedMaterialNumber));
			});

			oContextBinding = this.getModel().bindList("/ProductProofDocument").filter(aFilters);

			const aProductDocumentContext = await oContextBinding.requestContexts();

			return await aProductDocumentContext.map(function (oProductDocument) {
				return oProductDocument.getObject();
			});
		},*/

		_getProductsDocuments: async function (aProducts, sProductType) {
			let aFilters = [],
				aMaterials = [],
				aRelatedProducts = [],
				aProductsDocuments = [],
				oContextBinding = {};

			aFilters = await aProducts.map(function (oProduct) {
				let sFormattedMaterialNumber = oProduct.materialtNumber;
				return (new Filter("product", FilterOperator.EQ, sFormattedMaterialNumber));
			});

			if (sProductType === "IDH") {
				const aMaterialNumbers = aProducts.map(product => product.materialtNumber);
				aRelatedProducts = await this.getIbLinkedToIdh(aMaterialNumbers);
				const aRelatedFilters = aRelatedProducts.map(relatedProduct => {
					let sFormattedProduct = relatedProduct.product;
					return new Filter("product", FilterOperator.EQ, sFormattedProduct);
				});

				aFilters = [...aFilters, ...aRelatedFilters];
			}

			oContextBinding = this.getModel().bindList("/ProductProofDocument").filter(aFilters);

			const aProductDocumentContext = await oContextBinding.requestContexts();

			aProductsDocuments = await aProductDocumentContext.map(function (oProductDocument) {
				return oProductDocument.getObject();
			});

			if (aRelatedProducts.length > 0) {
				const oMaterialToProductMap = new Map();


				aRelatedProducts.forEach(oRelatedProduct => {
					const productKey = oRelatedProduct.product;
					const material = oRelatedProduct.material;

					if (!oMaterialToProductMap.has(productKey)) {
						oMaterialToProductMap.set(productKey, []);
					}
					oMaterialToProductMap.get(productKey).push(material);
				});


				aProductsDocuments = aProductsDocuments.flatMap(oDoc => {
					const productKey = oDoc.product;
					const relatedMaterials = oMaterialToProductMap.get(productKey) || [];

					if (relatedMaterials.length > 0) {

						return relatedMaterials.map(material => ({
							...oDoc,
							product: material,
							productReference: productKey,
						}));
					} else {

						return {
							...oDoc,
							product: productKey,
							productReference: undefined
						};
					}
				});
			}

			return aProductsDocuments;
		},

		/**
		 * Get the Products master data (navigation property of the prodcuts)
		 * @public
		 */
		getProductMasterData: async function (aProducts, sProductType) {
			const aMaterialNumbers = aProducts.map(product => product.materialtNumber),
				sMaterialNumbers = JSON.stringify(aMaterialNumbers);
			let oModel = this.getModel(),
				sPath = "/GetProductMasterdata(productType='" + sProductType + "',product='" + aMaterialNumbers + "')",
				aProductMasterData = [];

			await oModel.bindContext(sPath).requestObject().then((oObject) => {
				aProductMasterData = oObject.value;
			}).catch((oError) => {
				//this.getView().setBusy(false);
			});

			return aProductMasterData
			/*let oModel = this.getModel(),
				aFilters = [],
				oContextBinding = {};

			aFilters = await aProducts.map(function (oProduct) {
				return (new Filter("product", FilterOperator.EQ, oProduct.materialtNumber));
			});

			oContextBinding = this.getModel().bindList("/ProductData").filter(aFilters);

			const aProductDataContext = await oContextBinding.requestContexts();

			return await aProductDataContext.map(function (oProductData) {
				return oProductData.getObject();
			});*/

		},

		setItemsStatus: function (sStatus) {
			let oModel = this.getModel("assessmentModel"),
				aItems = oModel.getProperty("/items");

			if (aItems && Array.isArray(aItems)) {
				aItems.forEach(function (oItem, index) {

					if (sStatus === "01") {
						oItem.status = sStatus;
						oItem.approbalStatus = sStatus;
					} else {
						oItem.approbalStatus = sStatus;
					}
				});

				oModel.setProperty("/items", aItems);
			}
		},

		/**
		 * Get all the proof type list
		 * @private
		 */
		_getProofTypesMap: function (aProoftypes) {
			let oProofTypesMap = {};
			aProoftypes.forEach(function (proofType) {
				oProofTypesMap[proofType.code] = proofType;
			});
			return oProofTypesMap;
		},

		/**
		 * Dialog closing
		 * @param {*} oEvent 
		 */
		onCloseProductsInAssessmentDialog: function (oEvent) {
			this._productsInAssessmentDialog.close();
		},

		/**
		 * Continue removing selected
		 * @param {*} oEvent 
		 */
		onContinueProductsInAssessmentDialog: function (oEvent) {

			this.getView().setBusy(true);

			const oAssessmentModel = this.getView().getModel("assessmentModel");
			const aProductsInAssessment = oAssessmentModel.getProperty("/prodctsInAssessment");
			const sProductType = this.getModel("assessmentModel").getProperty("/type");

			const sId = (sProductType === "IB") ? "ibDialogTable" : "idhDialogTable";
			const oTable = this.getView().byId(sId);
			const aSelectedContext = oTable.getSelectedContexts();

			const aProductsToContinue = [];

			for (const oContext of aSelectedContext) {
				const oObject = oContext.getObject();
				const bAlreadyInAssessment = aProductsInAssessment.some(item => item.product === oObject.materialtNumber);

				if (bAlreadyInAssessment) {
					oContext?.setSelected(false);
				} else {
					aProductsToContinue.push(oObject);
				}
			}

			this._productsInAssessmentDialog.close();
			if (aSelectedContext.length > aProductsInAssessment.length) {
				let aDuplicatedProducts = this.checkDuplicatedProducts(aProductsToContinue);

				const bValid = (!aDuplicatedProducts || aDuplicatedProducts.length == 0) ? true : false;

				if (bValid) this._addProducts(aProductsToContinue, sProductType);
				else this._addProductsDuplicated(aProductsToContinue, aDuplicatedProducts, sProductType);
			} else {
				this.getView().setBusy(false);
			}


		},

		openRecipientsDialog: async function (sStatus, sSbu, sProcessType) {

			await this.setRecipientsList(sStatus, sSbu, sProcessType);

			if (!this._notificationRecipientsDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "com.sustainability.overview.view.fragment.Assessment.NotificationsRecipientsDailog",
					controller: this
				}).then(function (oNotificationRecipientsDialog) {
					this._notificationRecipientsDialog = oNotificationRecipientsDialog;
					this.getView().addDependent(this._notificationRecipientsDialog);

					this._notificationRecipientsDialog.open();

				}.bind(this));
			} else {

				this._notificationRecipientsDialog.open();

			}

		},

		setRecipientsList: async function (sStatus, sSbu, sProcessType) {
			const oModel = this.getModel(),
				oContextBinding = oModel.bindContext("/GetUserFromMyId(...)");
			oContextBinding.setParameter("status", sStatus);
			oContextBinding.setParameter("sbu", sSbu);
			oContextBinding.setParameter("processType", sProcessType);

			await oContextBinding.execute().then(
				function () {
					const oContext = oContextBinding.getBoundContext(),
						aUsersEmail = (oContext.getObject().value);

					this.getModel("assessmentModel").setProperty("/recipientsList", aUsersEmail);
				}.bind(this)
			);
		},

		setProofValidTypes: function (oContext) {

			this.checkRemoveTypeProofFields(oContext);

		},

 		/**
		 * Handles the press event of the "Export to Excel" button.
		 * Exports the content of the massItems table to an .xlsx file,
		 * resolving codes to their descriptions and respecting the same
		 * column-visibility flags used in the view.
		 */
		onExportToExcel: function () {
			const oTable = this.byId("massItems");
			if (!oTable) {
				MessageToast.show(this.getResourceBundle().getText("exportTableNotFound"));
				return;
			}
		
			const oBinding = oTable.getBinding("rows");
			if (!oBinding) {
				MessageToast.show(this.getResourceBundle().getText("exportNoData"));
				return;
			}
		
			const oModel = oBinding.getModel();
			const sPath = oBinding.getPath();
			const aData = oModel.getProperty(sPath) || [];
		
			if (aData.length === 0) {
				MessageToast.show(this.getResourceBundle().getText("exportNoData"));
				return;
			}
		
			// 1) Build code -> description lookups from the model collections
			const oLookups = this._buildExportLookups();
		
			// 2) Enrich rows (non-destructive copies) with "_Text" properties
			const aEnriched = this._enrichRowsForExport(aData, oLookups);
		
			// 3) Snapshot the current visibility flags from the model
			const oVisibility = this._getExportVisibility();
		
			// 4) Build full column list, then keep only the ones currently visible
			const aCols = this._createExcelColumnConfig().filter(function (oCol) {
				return !oCol._visible || oCol._visible(oVisibility);
			}).map(function (oCol) {
				// Strip the internal flag before handing the config to Spreadsheet
				var oClean = Object.assign({}, oCol);
				delete oClean._visible;
				return oClean;
			});
		
			const oResourceBundle = this.getResourceBundle();
			const sFileName = oResourceBundle.getText("exportFileName") || "AssessmentItems";
			const sSheetName = oResourceBundle.getText("exportSheetName") || "Items";
		
			const oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level",
					context: {
						sheetName: sSheetName,
						application: "Sustainability Assessment",
						version: "1.0"
					}
				},
				dataSource: aEnriched,
				fileName: sFileName + "_" + this._getFormattedTimestamp() + ".xlsx",
				worker: false
			};
		
			const oSheet = new Spreadsheet(oSettings);
		
			oSheet.build()
				.then(function () {
					sap.m.MessageToast.show(oResourceBundle.getText("exportSuccess") || "Export completed");
				})
				.catch(function (oError) {
					sap.m.MessageBox.error(
						(oResourceBundle.getText("exportError") || "Error while exporting:") +
						" " + (oError.message || oError)
					);
				})
				.finally(function () {
					oSheet.destroy();
				});
		},          		

		_addProducts: async function (aProducts, sProductType) {

			this.getView().setBusy(true);

			const oOverviewModel = this.getModel("assessmentModel");
			const sStatus = oOverviewModel.getProperty("/header/status");
			const oODataModel = this.getModel();
			const sUpdateGroup = "AddItemsGroup";
			const sHeaderId = this.getModel("assessmentModel").getProperty("/header/ID");

			let aProductMasterData = await this.getProductMasterData(aProducts, sProductType);
			let aProductDocuments = await this._getProductsDocuments(aProducts, sProductType);
			let bPropagation = (sProductType === "IDH");

			let aItems = await aProducts.map(item => {
				let oProductData = aProductMasterData.find(oProduct => oProduct.product === item.materialtNumber);
				let aMappedDocuments = aProductDocuments.filter(oDocument => oDocument.product === item.materialtNumber)
					.map(oDocument => ({
						type: oDocument.type,
						description: oDocument.description,
						internalPath: "",
						fileName: oDocument.fileName,
						mediaType: oDocument.mediaType,
						content: null,
						active: oDocument.active !== null ? oDocument.active : true,
						url: oDocument.url,
						externalUrl: oDocument.externalUrl,
						imageMasterID: oDocument.proofPointId
					}));
				return {
					status: sStatus,
					product: item.materialtNumber,
					productType: sProductType,
					sustClass: item.sustClass,
					category1: item.category,
					contributor1: item.contributor,
					category2: item.category2,
					contributor2: item.contributor2,
					category3: item.category3,
					contributor3: item.contributor3,
					rcPreFlag: oProductData.rcPreFlag,
					sbu: item.sbu,
					propagation: bPropagation,
					externalCommunication: false,
					approberComment: "",
					//toProductData: oProductData ? oProductData : null,
					rcPreFlagDescription: oProductData.rcPreFlagDescription,
					productName: oProductData.productName,
					technologyL2Key: oProductData.technologyL2Key,
					technologyLevel2: oProductData.technologyLevel2,
					sustainabilityClassCode: oProductData.sustainabilityClassCode,
					existingSustainabilityClass: oProductData.existingSustainabilityClass,
					realSubstanceCode: oProductData.realSubstanceCode,
					realSubstanceName: oProductData.realSubstanceName,
					region: oProductData.region,
					applicationLevel2Key: oProductData.applicationLevel2Key,
					applicationLevel2: oProductData.applicationLevel2,
					lastAssessment: oProductData.lastAssessment,
					lastSubmitter: oProductData.lastSubmitter,
					lastApprover: oProductData.lastApprover,
					headerId: sHeaderId,
					toProofDocuments: aMappedDocuments
				};
			});

			aItems = await this.checkAssessmentData(aItems);
			const aCreatedContexts = [];
			let oContextBinding = oODataModel.bindList("/MassAssessmentItems", undefined, undefined, undefined, { $$updateGroupId: sUpdateGroup });
			aItems.forEach(oItem => {
				const oCreatedContext = oContextBinding.create(oItem);
				aCreatedContexts.push(oCreatedContext);
			});

			if (aItems.length > 0) {
				oODataModel.submitBatch(sUpdateGroup)
					.then(() => {
						const aLocalItems = oOverviewModel.getProperty("/items") || [];
						const aCreatedItems = aCreatedContexts.map(oContext => {
							const oCreatedObject = oContext.getObject();
							delete oCreatedObject["@odata.context"];
							delete oCreatedObject["@$ui5.context.isTransient"];

							delete oCreatedObject["createdAt"];
							delete oCreatedObject["createdBy"];
							delete oCreatedObject["modifiedAt"];
							delete oCreatedObject["modifiedBy"];
							const { toProofDocuments, ...rest } = oCreatedObject;
							return rest;
						});

						oOverviewModel.setProperty("/items", aLocalItems.concat(aCreatedItems));

						this._addProductsDialog.close();
						this.getView().setBusy(false);
					})
					.catch(oError => {
						this._addProductsDialog.close();
						this.getView().setBusy(false);
					});
			} else {
				this.getView().setBusy(false);
			}
		},

		_addProductsDuplicated: async function (aProducts, aDuplicatedProducts, sProductType) {

			this.getView().setBusy(true);

			const oOverviewModel = this.getModel("assessmentModel");
			const sStatus = oOverviewModel.getProperty("/header/status");
			const oODataModel = this.getModel();
			const sUpdateGroup = "AddItemsGroup";
			const sHeaderId = this.getModel("assessmentModel").getProperty("/header/ID");

			//const oItemsTable = this.getView().byId("massItems");
			//const oBinding = oItemsTable.getBinding("rows");
			let bPropagation = (sProductType === "IDH");
			let aCorrectProducts = aProducts.filter(product =>
				!aDuplicatedProducts.some(dup => dup.materialtNumber === product.materialtNumber)
			);

			const sFormattedDetails = aDuplicatedProducts.map(product => `- ${product.materialtNumber}`).join('<br>');

			this.getView().setBusy(false);
			if (sFormattedDetails !== "") {
				MessageBox.information(this.getResourceBundle().getText("duplicatedProducts"), {
					details: sFormattedDetails,
					contentWidth: "100px",
					dependentOn: this.getView(),
					onClose: async function (sAction) {
						if (sAction === 'OK') {
							this.getView().setBusy(true);
							let aProductMasterData = await this.getProductMasterData(aCorrectProducts, sProductType);
							let aProductDocuments = await this._getProductsDocuments(aCorrectProducts, sProductType);

							let aItems = await aCorrectProducts.map(item => {
								let oProductData = aProductMasterData.find(oProduct => oProduct.product === item.materialtNumber);
								let aMappedDocuments = aProductDocuments.filter(oDocument => oDocument.product === item.materialtNumber)
									.map(oDocument => ({
										type: oDocument.type,
										description: oDocument.description,
										internalPath: "",
										fileName: oDocument.fileName,
										mediaType: oDocument.mediaType,
										content: null,
										active: oDocument.active !== null ? oDocument.active : true,
										url: oDocument.url,
										externalUrl: oDocument.externalUrl,
										imageMasterID: oDocument.proofPointId
									}));
								return {
									status: sStatus,
									product: item.materialtNumber,
									productType: sProductType,
									sustClass: item.sustClass,
									category1: item.category,
									contributor1: item.contributor,
									category2: item.category2,
									contributor2: item.contributor2,
									category3: item.category3,
									contributor3: item.contributor3,
									rcPreFlag: oProductData.rcPreFlag,
									sbu: item.sbu,
									propagation: bPropagation,
									externalCommunication: false,
									approberComment: "",
									//toProductData: oProductData ? oProductData : null,
									rcPreFlagDescription: oProductData.rcPreFlagDescription,
									productName: oProductData.productName,
									technologyL2Key: oProductData.technologyL2Key,
									technologyLevel2: oProductData.technologyLevel2,
									sustainabilityClassCode: oProductData.sustainabilityClassCode,
									existingSustainabilityClass: oProductData.existingSustainabilityClass,
									realSubstanceCode: oProductData.realSubstanceCode,
									realSubstanceName: oProductData.realSubstanceName,
									region: oProductData.region,
									applicationLevel2Key: oProductData.applicationLevel2Key,
									applicationLevel2: oProductData.applicationLevel2,
									lastAssessment: oProductData.lastAssessment,
									lastSubmitter: oProductData.lastSubmitter,
									lastApprover: oProductData.lastApprover,
									toProofDocuments: aMappedDocuments
								};
							});

							aItems = await this.checkAssessmentData(aItems);
							const aCreatedContexts = [];
							let oContextBinding = oODataModel.bindList("/MassAssessmentItems", undefined, undefined, undefined, { $$updateGroupId: sUpdateGroup });
							aItems.forEach(oItem => {
								const oCreatedContext = oContextBinding.create(oItem);
								aCreatedContexts.push(oCreatedContext);
							});

							if (aItems.length > 0) {
								oODataModel.submitBatch(sUpdateGroup)
									.then(() => {
										const aLocalItems = oOverviewModel.getProperty("/items") || [];
										const aCreatedItems = aCreatedContexts.map(oContext => {
											const oCreatedObject = oContext.getObject();
											const { toProofDocuments, ...rest } = oCreatedObject;
											return rest;
										});

										oOverviewModel.setProperty("/items", aLocalItems.concat(aCreatedItems));

										this._addProductsDialog.close();
										this.getView().setBusy(false);
									})
									.catch(oError => {
										this._addProductsDialog.close();
										this.getView().setBusy(false);
									});
							} else {
								this.getView().setBusy(false);
							}
						}
					}.bind(this)
				});
			}
		},


		/**
		 * Snapshots the flags from assessmentModel used to drive column visibility.
		 */
		_getExportVisibility: function () {
			const oAssessmentModel = this.getView().getModel("assessmentModel");
			const fnGet = function (sPath) {
				return oAssessmentModel ? oAssessmentModel.getProperty(sPath) : undefined;
			};
		
			return {
				masterDataBlock:        !!fnGet("/masterDataBlock"),
				assessmentDetailsBlock: !!fnGet("/assessmentDetailsBlock"),
				approberDataBlock:      !!fnGet("/approberDataBlock"),
				processType:            fnGet("/header/processType") || "",
				type:                   fnGet("/type") || "",
				status:                 fnGet("/header/status") || ""
			};
		},
		
		/**
		 * Builds code-to-description lookup maps from the collections already
		 * loaded into the view models.
		 */
		_buildExportLookups: function () {
			const oAssessmentModel = this.getView().getModel("assessmentModel");
			const oRulesModel = this.getView().getModel("rules");
		
			const mSustClass = {};
			const mCategories = {};
			const mContributors = {};
			const mApprobalStatus = {};
		
			if (oAssessmentModel) {
				(oAssessmentModel.getProperty("/sustClass") || []).forEach(function (o) {
					if (o && o.code != null) { mSustClass[o.code] = o.description; }
				});
				(oAssessmentModel.getProperty("/categories") || []).forEach(function (o) {
					if (o && o.code != null) { mCategories[o.code] = o.description; }
				});
				(oAssessmentModel.getProperty("/contributors") || []).forEach(function (o) {
					if (o && o.code != null) {
						mContributors[(o.categoryCode || "") + "|" + o.code] = o.description;
						if (mContributors[o.code] === undefined) {
							mContributors[o.code] = o.description;
						}
					}
				});
			}
		
			if (oRulesModel) {
				(oRulesModel.getProperty("/approbalStatusOption") || []).forEach(function (o) {
					if (o && o.approbalStatus != null) {
						mApprobalStatus[o.approbalStatus] = o.description;
					}
				});
			}
		
			return {
				sustClass: mSustClass,
				categories: mCategories,
				contributors: mContributors,
				approbalStatus: mApprobalStatus
			};
		},
		
		_resolveCode: function (mMap, sCode) {
			if (sCode === undefined || sCode === null || sCode === "") { return ""; }
			return (mMap && mMap[sCode] !== undefined) ? mMap[sCode] : sCode;
		},
		
		_resolveContributor: function (mContributors, sCategoryCode, sContributorCode) {
			if (!sContributorCode) { return ""; }
			const sKey = (sCategoryCode || "") + "|" + sContributorCode;
			if (mContributors[sKey] !== undefined) { return mContributors[sKey]; }
			if (mContributors[sContributorCode] !== undefined) { return mContributors[sContributorCode]; }
			return sContributorCode;
		},
		
		/**
		 * Converts the propagation boolean/string into a localized Yes/No.
		 */
		_resolvePropagation: function (vValue) {
			if (vValue === undefined || vValue === null || vValue === "") { return ""; }
		
			const bTrue = (vValue === true || vValue === "true");
			const oResourceBundle = this.getResourceBundle();
		
			let sYes = oResourceBundle.getText("yes");
			let sNo  = oResourceBundle.getText("no");
			if (sYes === "yes") { sYes = "Yes"; }
			if (sNo === "no")   { sNo  = "No";  }
		
			return bTrue ? sYes : sNo;
		},
		
		/**
		 * Maps the communicationStatus code (and parent approbalStatus when the
		 * communication code is empty) to a readable text. Mirrors the logic of
		 * formatter.getIconCommunicationStatus, so the exported cell matches
		 * the icon the user sees on screen.
		 *
		 * Icon mapping recap:
		 *   - "accept"  when communicationStatus === "05"
		 *     OR when communicationStatus is empty AND approbalStatus in (05, 06, 08)
		 *   - "pending" when communicationStatus in (01, 02, 03, 04)
		 *   - none      otherwise
		 *
		 * To customize the exported labels per code, replace the generic
		 * "Pending"/"Completed" texts below with i18n lookups, e.g.:
		 *   return oResourceBundle.getText("commStatus_" + sCommunicationStatus);
		 */
		_resolveCommunicationStatus: function (sCommunicationStatus, sApprobalStatus) {
			const oResourceBundle = this.getResourceBundle();
		
			// Helper that returns the i18n value if defined, otherwise a default.
			const fnText = function (sKey, sDefault) {
				var sValue = oResourceBundle.getText(sKey);
				return (sValue && sValue !== sKey) ? sValue : sDefault;
			};
		
			const sPending   = fnText("commStatusPending",   "Pending");
			const sCompleted = fnText("commStatusCompleted", "Completed");
		
			// Implicit "accept" — no comm status yet, but the approbal status
			// indicates the flow already reached a final state.
			if (!sCommunicationStatus &&
				(sApprobalStatus === "05" || sApprobalStatus === "06" || sApprobalStatus === "08")) {
				return sCompleted;
			}
		
			switch (sCommunicationStatus) {
				case "01":
				case "02":
				case "03":
				case "04":
					return sPending;
				case "05":
					return sCompleted;
				default:
					return "";
			}
		},
		
		/**
		 * Returns new shallow-copied rows enriched with "_<field>Text" properties.
		 */
		_enrichRowsForExport: function (aData, oLookups) {
			return aData.map(function (oRow) {
				const oCopy = Object.assign({}, oRow);
		
				oCopy._sustClassText           = this._resolveCode(oLookups.sustClass, oRow.sustClass);
				oCopy._category1Text           = this._resolveCode(oLookups.categories, oRow.category1);
				oCopy._category2Text           = this._resolveCode(oLookups.categories, oRow.category2);
				oCopy._category3Text           = this._resolveCode(oLookups.categories, oRow.category3);
				oCopy._contributor1Text        = this._resolveContributor(oLookups.contributors, oRow.category1, oRow.contributor1);
				oCopy._contributor2Text        = this._resolveContributor(oLookups.contributors, oRow.category2, oRow.contributor2);
				oCopy._contributor3Text        = this._resolveContributor(oLookups.contributors, oRow.category3, oRow.contributor3);
				oCopy._approbalStatusText      = this._resolveCode(oLookups.approbalStatus, oRow.approbalStatus);
				oCopy._propagationText         = this._resolvePropagation(oRow.propagation);
				oCopy._communicationStatusText = this._resolveCommunicationStatus(
													oRow.communicationStatus,
													oRow.approbalStatus);
		
				return oCopy;
			}.bind(this));
		},
		
		/**
		 * Builds the full column configuration for the Excel export.
		 */
		_createExcelColumnConfig: function () {
			const oResourceBundle = this.getResourceBundle();
			const oAssessmentModel = this.getView().getModel("assessmentModel");
			const sType = oAssessmentModel ? oAssessmentModel.getProperty("/type") : "IDH";
		
			const sProductNameLabel = sType === "IDH"
				? oResourceBundle.getText("idhNameLabel")
				: oResourceBundle.getText("ibNameLabel");
		
			const sProductLabel = sType === "IDH"
				? oResourceBundle.getText("idhNumberLabel")
				: oResourceBundle.getText("ibNumberLabel");
		
			const sPropagationLabel = sType === "IDH"
				? oResourceBundle.getText("linkIdhLabel")
				: oResourceBundle.getText("linkIbLabel");
		
			// Visibility predicates
			const isMasterData   = function (v) { return v.masterDataBlock;        };
			const isDetailsBlock = function (v) { return v.assessmentDetailsBlock; };
			const isApproverData = function (v) { return v.approberDataBlock;      };
			const isIDH          = function (v) { return v.type === "IDH";         };
		
			return [
				// Always visible --------------------------------------------------
				{ label: sProductNameLabel,                                      property: "productName",                 type: EdmType.String, width: 25 },
				{ label: sProductLabel,                                          property: "product",                     type: EdmType.String, width: 15 },
				{ label: oResourceBundle.getText("realSubstNumber"),             property: "realSubstanceName",           type: EdmType.String, width: 25 },
		
				// Master data block ----------------------------------------------
				{ label: oResourceBundle.getText("techLevel2"),                  property: "technologyLevel2",            type: EdmType.String, width: 20, _visible: isMasterData },
				{ label: oResourceBundle.getText("applL2"),                      property: "applicationLevel2",           type: EdmType.String, width: 20, _visible: isMasterData },
		
				// Always visible --------------------------------------------------
				{ label: oResourceBundle.getText("existingSustClass"),           property: "existingSustainabilityClass", type: EdmType.String, width: 18 },
		
				// Master data block ----------------------------------------------
				{ label: oResourceBundle.getText("lastAssessmentApprovalLabel"), property: "lastAssessment",              type: EdmType.String, width: 20, _visible: isMasterData },
				{ label: oResourceBundle.getText("lastSubmitter"),               property: "lastSubmitter",               type: EdmType.String, width: 20, _visible: isMasterData },
				{ label: oResourceBundle.getText("lastApprover"),                property: "lastApprover",                type: EdmType.String, width: 20, _visible: isMasterData },
		
				// Always visible --------------------------------------------------
				{ label: oResourceBundle.getText("rcPreFlagLabel"),              property: "rcPreFlagDescription",        type: EdmType.String, width: 18 },
				{ label: oResourceBundle.getText("assessmentExplanationLabel"),  property: "comment",                     type: EdmType.String, width: 80 },
				{ label: oResourceBundle.getText("primaryClassLabel"),           property: "_sustClassText",              type: EdmType.String, width: 20 },
				{ label: oResourceBundle.getText("sustCategory1"),               property: "_category1Text",              type: EdmType.String, width: 25 },
				{ label: oResourceBundle.getText("sustContributor1"),            property: "_contributor1Text",           type: EdmType.String, width: 25 },
		
				// Assessment details block ---------------------------------------
				{ label: oResourceBundle.getText("sustCategory2"),               property: "_category2Text",              type: EdmType.String, width: 25, _visible: isDetailsBlock },
				{ label: oResourceBundle.getText("sustContributor2"),            property: "_contributor2Text",           type: EdmType.String, width: 25, _visible: isDetailsBlock },
				{ label: oResourceBundle.getText("sustCategory3"),               property: "_category3Text",              type: EdmType.String, width: 25, _visible: isDetailsBlock },
				{ label: oResourceBundle.getText("sustContributor3"),            property: "_contributor3Text",           type: EdmType.String, width: 25, _visible: isDetailsBlock },
		
				// Propagation / Link IDH - only when type === 'IDH' --------------
				{ label: sPropagationLabel,                                      property: "_propagationText",            type: EdmType.String, width: 12, _visible: isIDH },
		
				// Approver block -------------------------------------------------
				{ label: oResourceBundle.getText("statusLabel"),                 property: "_approbalStatusText",         type: EdmType.String, width: 20, _visible: isApproverData },
				{ label: oResourceBundle.getText("processingStatusLabel"),       property: "_communicationStatusText",    type: EdmType.String, width: 18, _visible: isApproverData },
				{ label: oResourceBundle.getText("approberCommentLabel"),        property: "approberComment",             type: EdmType.String, width: 40, _visible: isApproverData }
			];
		},
		
		_getFormattedTimestamp: function () {
			const oDate = new Date();
			const sPad = function (n) { return n < 10 ? "0" + n : "" + n; };
			return oDate.getFullYear() +
				sPad(oDate.getMonth() + 1) +
				sPad(oDate.getDate()) + "_" +
				sPad(oDate.getHours()) +
				sPad(oDate.getMinutes()) +
				sPad(oDate.getSeconds());
		},		


	});

});