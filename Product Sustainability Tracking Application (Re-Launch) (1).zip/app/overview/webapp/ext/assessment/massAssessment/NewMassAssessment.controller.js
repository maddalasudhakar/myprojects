sap.ui.define(
    [
        "./AssessmentController",
        "sap/ui/model/json/JSONModel",
        "sap/m/MessageBox",
        "sap/ui/core/Fragment",
        "../../../model/formatter",
        "sap/m/MessageToast",
        "sap/ui/core/Item",
        "sap/ui/core/routing/History",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/Messaging"
    ],
    function (AssessmentController, JSONModel, MessageBox, Fragment, formatter, MessageToast, Item, History, Filter, FilterOperator, Messaging) {
        'use strict';

        return AssessmentController.extend('com.sustainability.overview.ext.assessment.massAssessment.NewMassAssessment', {
            formatter: formatter,
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: function () {
                this.initialize();
                //this.getRouter().getRoute("NewMassAssessment").attachPatternMatched(this._onNewMassAssessmentMatched, this);
                this.getAppComponent().getRouter().getRoute("NewMassAssessment").attachPatternMatched(this._onNewMassAssessmentMatched, this);

                let oAssessmentModel = new JSONModel({
                    editMode: true,
                    prooftype: [],
                    validProofType: [],
                    contributors: [],
                    categories: [],
                    sustClass: [],
                    assesmentType: "",
                    masterDataBlock: false,
                    assessmentDetailsBlock: false,
                    approberDataBlock: false,
                    copyItem: {},
                    copyMassProofPoint: {},
                    copyMapProofPoint: {},
                    massProofPoints: [],
                    selectedRows: 0,
                    selectedMassRows: 0,
                    selectedMapRows: 0,
                    propagationList: [],
                    itemContext: {},
                    productRelation: [],
                    onlyDocuments: false,
                    items: [],
                    userAction: "",
                    recipientsList: [],
                    pasteApprovalStatus: false,
                    rulesAddProofEnabled: false
                });

                this.setModel(oAssessmentModel, "assessmentModel");

            },

            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/

            onAddMapUploadProofPointsDialog: async function () {
                const oItemsTable = this.getView().byId("massItems"),
                    oModel = this.getModel(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aItemContexts = oItemsTable.getBinding("rows").getContexts(),
                    sGroupId = "proofDocumentsGroup";

                if (!aProofPoints || aProofPoints.length === 0) {
                    MessageBox.error(this.getResourceBundle().getText("noDocumentsToUpload"));
                    return;
                }

                let bShowMessage = false;

                if (aProofPoints.length > 0) {
                    const oProofDocsBinding = oModel.bindList("/AssessmentProofDocument", undefined, undefined, undefined, {
                        $$updateGroupId: sGroupId
                    });

                    for (const oProofDocument of aProofPoints) {
                        const sFileName = oProofDocument.fileName;
                        if (!sFileName) {
                            // File name is required to extract product reference
                            bShowMessage = true;
                            continue;
                        }

                        const sProductIdentifier = sFileName.split("_")[0].replace(/^0+/, "");

                        // Find matching item by comparing product field (removing leading zeros)
                        const oMatchingContext = aItemContexts.find(oCtx => {
                            const sProduct = oCtx.getProperty("product") || "";
                            return sProduct.replace(/^0+/, "") === sProductIdentifier;
                        });

                        if (oMatchingContext) {
                            const oItem = oMatchingContext.getObject();
                            // Validate required fields and custom logic
                            const bTypeValid = this.checkTypeProofFields(oMatchingContext, oProofDocument);
                            const bMandatoryFields = oProofDocument.type && oProofDocument.description && oProofDocument.fileName;

                            if (bTypeValid && bMandatoryFields) {
                                // Assign the related requestId to link document with item
                                oProofDocument.requestId = oItem.ID;
                                oProofDocument.active = true;

                                // Create the document directly using the entity path
                                oProofDocsBinding.create(oProofDocument);
                            } else {
                                bShowMessage = true;
                            }
                        } else {
                            // No matching item found
                            bShowMessage = true;
                        }
                    }

                    // Submit the batch if there are pending changes
                    if (oModel.hasPendingChanges(sGroupId)) {
                        try {
                            this.getView().setBusy(true);
                            await oModel.submitBatch(sGroupId);
                            this.getView().setBusy(false);

                            if (bShowMessage) {
                                MessageToast.show(this.getResourceBundle().getText("noSuccessMassUpload"));
                            } else {
                                MessageToast.show(this.getResourceBundle().getText("successMassUpload"));
                            }

                            this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                            this._mapUploadProofPointsDialog.close();
                        } catch (oError) {
                            this.getView().setBusy(false);
                            MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                        }
                    } else {
                        MessageToast.show(this.getResourceBundle().getText("noDocumentsMatch"));
                    }
                }
            },

            /**
            * Add new proof table line
            * @public
            */
            onAddProofPoint: function () {
                let oProofTable = this.getView().byId("proofTable"),
                    oBinding = oProofTable.getBinding("rows"),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext");
                oBinding.create({ "active": true, "requestId": oContext.getProperty("ID") }, true);
            },

            /**
            * Add new Assessment products in item's table
            * @public
            */
            onAddSelectedProducts: async function () {
                let sProductType = this.getModel("assessmentModel").getProperty("/type"),
                    oItemsTable = this.getView().byId("massItems"),
                    oBinding = oItemsTable.getBinding("rows"),
                    aSelectedContext = [],
                    bPropagation = false;

                // this._addProducts(sProductType, oItemsTable, oBinding, aSelectedContext, bPropagation);

                this.getView().setBusy(true);
                if (sProductType === "IB") {
                    aSelectedContext = this.getView().byId("ibDialogTable").getSelectedContexts();
                } else {
                    aSelectedContext = this.getView().byId("idhDialogTable").getSelectedContexts();
                    bPropagation = true;
                }

                if (!aSelectedContext || aSelectedContext.length === 0) {
                    this.getView().setBusy(false);
                    MessageBox.information(this.getResourceBundle().getText("noProductsSelected"));
                    return;
                }

                MessageBox.confirm(this.getResourceBundle().getText("confirmSaveNewProducts"), {
                    onClose: async function (sAction) {
                        if (sAction === 'OK') {
                            let aProducts = await this.getProductsData(aSelectedContext);
                            let aDuplicatedProducts = this.checkDuplicatedProducts(aProducts);
                            let aProductsInAssessments = await this.checkProductsInAssessment(aProducts);

                            /*aProductsInAssessments = aProductsInAssessments.filter(product =>
                                !aDuplicatedProducts.some(dup => dup.materialtNumber === product.materialtNumber)
                            );*/


                            if (aProductsInAssessments.length > 0) {

                                aProductsInAssessments = aProductsInAssessments.map(item => {
                                    return {
                                        product: item.materialtNumber,
                                        requestName: item.requestName,
                                    }

                                });




                                const oAssessmentModel = this.getView().getModel("assessmentModel");

                                oAssessmentModel.setProperty("/prodctsInAssessment", aProductsInAssessments);


                                if (!this._productsInAssessmentDialog) {
                                    this.getExtensionAPI().loadFragment({
                                        id: this.getView().getId(),
                                        name: "com.sustainability.overview.view.fragment.ProductsInAssessment",
                                        controller: this
                                    }).then(function (oDialog) {
                                        this._productsInAssessmentDialog = oDialog;
                                        this.getView().addDependent(this._productsInAssessmentDialog);
                                        this._productsInAssessmentDialog.open();
                                    }.bind(this));
                                } else {
                                    this._productsInAssessmentDialog.open();

                                }


                                this.getView().setBusy(false);


                            } else if (aDuplicatedProducts.length > 0) {


                                this._addProductsDuplicated(aProducts, aDuplicatedProducts, sProductType);

                            } else {
                                this._addProducts(aProducts, sProductType);

                            }

                        }
                    }.bind(this)
                });



            },

            /**
            * Cancel non saved changes
            * @public
            */
            onCancel: function () {
                const oView = this.getView(),
                    oModel = this.getModel(),
                    oAssessmentModel = this.getModel("assessmentModel"),
                    oODataModel = this.getModel(),
                    oHistory = sap.ui.core.routing.History.getInstance(),
                    sPreviousHash = oHistory.getPreviousHash(),
                    oMessageManager = sap.ui.getCore().getMessageManager(),
                    oHeader = oAssessmentModel.getProperty("/header"),
                    sRequestId = oHeader.ID;

                oMessageManager.removeAllMessages();

                MessageBox.confirm(
                    this.getResourceBundle().getText("confirmDeletion", oHeader.requestName),
                    {
                        onClose: async function (sAction) {
                            if (sAction === 'OK') {
                                oView.setBusy(true);

                                try {
                                    const sPath = "/" + "MassAssessmentHeader(" + sRequestId + ")";

                                    const oContextBinding = oODataModel.bindContext(sPath, null, { $$updateGroupId: "$auto" });
                                    await oContextBinding.requestObject();
                                    const oContext = oContextBinding.getBoundContext();

                                    await oContext.delete("$auto");

                                    oView.setBusy(false);

                                    oAssessmentModel.setProperty("/header", null);
                                    oAssessmentModel.setProperty("/Items", []);

                                    if (sPreviousHash !== undefined) {
                                        window.history.go(-1);
                                    } else {
                                        this.getRouter().navTo("defaultRoute");
                                    }


                                } catch (oError) {
                                    oView.setBusy(false);
                                    MessageBox.error(this.getResourceBundle().getText("assessmentDeleteError"));
                                }
                            }
                        }.bind(this)
                    }
                );
            },


            /**
            * Cancel and close Add new products dialog
            * @public
            */
            onCancelAddProducts: function () {
                this._addProductsDialog.close();
            },

            /**
            * Add proof points to selected items
            * @public
            */
            onCreateMassUploadProofPointsDialog: async function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aProofPointsToSave = [],
                    aValiditems = [],
                    oModel = this.getModel(),
                    bTypeValid = true,
                    bMandatoryFields = true,
                    bShowMessage = false;

                const oActionODataContextBinding = oModel.bindContext("/MassUploadDocuments(...)");

                for (const oProofDocument of aProofPoints) {
                    aValiditems = [];
                    aProofPointsToSave = [];
                    for (const iIndex of aIndices) {
                        let oContext = oItemsTable.getContextByIndex(iIndex);

                        bTypeValid = this.checkTypeProofFields(oContext, oProofDocument);
                        oProofDocument.active = true;

                        if (bTypeValid && bMandatoryFields) {
                            aValiditems.push(oContext.getObject());

                        } else {
                            bShowMessage = true;
                        }

                    }

                    if (aValiditems.length > 0) {
                        aProofPointsToSave.push(oProofDocument);
                        oActionODataContextBinding.setParameter("items", aValiditems);
                        oActionODataContextBinding.setParameter("documents", aProofPointsToSave);

                        await oActionODataContextBinding.execute().then(
                            async function (oData, test) {

                                this.getView().setBusy(false);

                            }.bind(this)
                        ).catch(function (oError) {

                            this.getView().setBusy(false);
                        }.bind(this));
                    }

                }

                if (bShowMessage) {
                    MessageToast.show(this.getResourceBundle().getText("noSuccessMassUpload"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("successMassUpload"));
                }

                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this._massUploadProofPointsDialog.close();
            },

            onCloseMapUploadProofPointsDialog: function () {
                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this.getModel("assessmentModel").setProperty("/copyMapProofPoint", {});
                this._mapUploadProofPointsDialog.close();
            },

            /**
            * Cancel and close mass upload dialog
            * @public
            */
            onCloseMassUploadProofPointsDialog: function () {
                this.getModel("assessmentModel").setProperty("/massProofPoints", []);
                this.getModel("assessmentModel").setProperty("/copyMassProofPoint", {});
                this._massUploadProofPointsDialog.close();
            },

            /**
            * Close proof points dialog
            * @public
            */
            onCloseProofPointsDialog: function () {
                let oModel = this.getModel();
                this.getModel("assessmentModel").setProperty("/itemContext", {});
                oModel.submitBatch("proofDocumentsGroup").then(function (odata, second) {
                    this.getView().setBusy(false);
                    if (!oModel.hasPendingChanges("proofDocumentsGroup")) {

                    } else {
                        let aMessage = oMessageModel.getData(),
                            oLastMessage = aMessage[aMessage.length - 1];
                        MessageBox.error(oLastMessage.getMessage());
                    }
                }.bind(this)).catch(function (oError) {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("assessmentSaveError"));
                }.bind(this));
                this._proofPointsDialog.close();
            },

            /**
            * Copy selected row
            * @public
            */
            onCopyItem: function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    oContext = {};

                if (aIndices.length === 1) {

                    oContext = oItemsTable.getContextByIndex(aIndices[0]);

                    this.getModel("assessmentModel").setProperty("/copyItem", oContext.getObject());
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onCopyMassProofPoint: function () {
                let aIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                if (aIndices.length === 1) {
                    let iSelectedIndex = aIndices[0];
                    let oSelectedRow = aMassProofPoints[iSelectedIndex];

                    this.getModel("assessmentModel").setProperty("/copyMassProofPoint", oSelectedRow);
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onCopyMapProofPoint: function () {
                let aIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                if (aIndices.length === 1) {
                    let iSelectedIndex = aIndices[0];
                    let oSelectedRow = aMassProofPoints[iSelectedIndex];

                    this.getModel("assessmentModel").setProperty("/copyMapProofPoint", oSelectedRow);
                    MessageToast.show(this.getResourceBundle().getText("copiedRow"));
                } else {
                    MessageToast.show(this.getResourceBundle().getText("copyOnlyOneRow"));
                }
            },

            onFilterItems: function (oEvent) {
                const filterBar = this.getView().byId("newMassIemFilterbar"),
                    allFilters = filterBar.getFilters(),
                    oTable = this.byId("massItems"),
                    oBinding = oTable.getBinding("rows");

                oBinding.filter(allFilters.filters, "Application");
            },

            onMassSelectionChange: function () {
                let aSelectedItems = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedMassRows", aSelectedItems);
            },

            onMapSelectionChange: function () {
                let aSelectedItems = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedMapRows", aSelectedItems);
            },

            onSearch: function (oEvent) {
                const sQuery = oEvent.getSource().getValue().trim();
                const oTable = this.byId("massItems");
                const oBinding = oTable.getBinding("rows");

                let aFilters = [];

                if (sQuery) {
                    aFilters.push(new sap.ui.model.Filter("product", sap.ui.model.FilterOperator.Contains, sQuery));
                }

                oBinding.filter(aFilters, "Application");
            },

            onOkNotificationsRecipientsDialog: async function () {
                const sAction = this.getModel("assessmentModel").getProperty("/userAction"),
                    oModel = this.getModel(),
                    oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aSelectedContext = this.getView().byId("recipientsTableId").getSelectedContexts(),
                    sStatus = sAction === "Save" ? "01" : "02";

                this.getView().setBusy(true);

                this.getView().byId("recipientsTableId").removeSelections();


                this.getModel("assessmentModel").setProperty("/userAction", "");
                this._notificationRecipientsDialog.close();

                if (!sAction) {
                    this.getView().setBusy(false);
                    return;
                }

                if ((!aSelectedContext || aSelectedContext.length === 0) && sAction === "Submit") {
                    this.getView().setBusy(false);
                    MessageBox.error(this.getResourceBundle().getText("mandatoryRecipients"));

                    return;
                }

                // Build recipients payload for the action
                let aRecipients = [];
                if (aSelectedContext && aSelectedContext.length > 0) {
                    aRecipients = aSelectedContext
                        .map(oContext => oContext && oContext.getProperty("email"))
                        .filter(Boolean);
                }

                // If there is nothing to send and the user just saved, continue normal flow
                if (aRecipients.length === 0) {
                    if (sAction === "Save") {
                        await this._saveAssessment();
                    }
                    return;
                }

                try {
                    const oActionContext = oModel.bindContext("/saveRecipients(...)");
                    oActionContext.setParameter("assessmentId", oHeader.ID);
                    oActionContext.setParameter("recipientEmail", aRecipients);
                    oActionContext.setParameter("status", sStatus);


                    oActionContext.execute().then(
                        async function () {

                            // Continue with Save/Submit flows
                            if (sAction === "Save") {
                                await this._saveAssessment();
                            } else if (sAction === "Submit") {
                                await this._submitAssessment();
                            }
                        }.bind(this)
                    ).catch(function (oError) {
                        console.error("saveRecipients action error", oError);
                        this.getView().setBusy(false);

                    }.bind(this));
                } catch (oError) {
                    // Handle errors from action execution
                    this.getView().setBusy(false);

                    console.error("saveRecipients action error", oError);
                }
            },

            /**
            * Delete selected proof rows
            * @public
            */
            onDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("proofTable").getSelectedIndices(),
                    aContext = [],
                    oProofTable = this.getView().byId("proofTable");

                if (aSelectedIndices.length > 0) {

                    let bShowError = aSelectedIndices.some(iIndex => {
                        let oContext = oProofTable.getContextByIndex(iIndex);
                        // If the documents is in Image master is not possible delete it
                        if (oContext.getProperty("imageMasterID")) {
                            return true;
                        }

                        aContext.push(oContext);
                        return false;
                    });

                    if (bShowError) {
                        MessageBox.error(this.getResourceBundle().getText("removeProofPointsError"));
                        return;
                    }

                    MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionProofPoints"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                aContext.forEach(oContext => {
                                    if (oContext.isTransient()) {
                                        oContext.delete();
                                    } else {
                                        oContext.delete("$auto");
                                    }
                                });
                            }
                        }.bind(this)
                    });
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            /**
            * Delete selected items
            * @public
            */
            onDeleteSelectedItems: function () {
                const oView = this.getView(),
                    oTable = oView.byId("massItems"),
                    oAssessmentModel = oView.getModel("assessmentModel"),
                    oODataModel = oView.getModel(),
                    aItems = oAssessmentModel.getProperty("/items") || [],
                    sUpdateGroup = "deleteGroup";

                // Get selected indices from the UI table (visual indices)
                const aSelectedIndices = oTable.getDependents()[0].getSelectedIndices();

                if (aSelectedIndices.length === 0) {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                    return;
                }

                // Map selected indices to actual data objects using their binding contexts
                const aSelectedItems = aSelectedIndices
                    .map(iIndex => oTable.getContextByIndex(iIndex))
                    .filter(oContext => !!oContext)
                    .map(oContext => oContext.getObject());

                MessageBox.confirm(this.getResourceBundle().getText("confirmDeletionItems"), {
                    onClose: async function (sAction) {
                        if (sAction !== "OK") return;

                        oView.setBusy(true);

                        try {
                            // Prepare deletion requests for all selected items
                            const aContextPromises = aSelectedItems.map(async oItem => {
                                const sPath = `/MassAssessmentItems(${oItem.ID})`;
                                const oContextBinding = oODataModel.bindContext(sPath, undefined, {
                                    $$updateGroupId: sUpdateGroup
                                });
                                await oContextBinding.requestObject();
                                return oContextBinding.getBoundContext();
                            });

                            const aContexts = await Promise.all(aContextPromises);

                            // Call delete on each bound context
                            for (const oContext of aContexts) {
                                oContext.delete(sUpdateGroup);
                            }

                            // Submit all deletes as a batch
                            await oODataModel.submitBatch(sUpdateGroup);

                            // Update local model by removing deleted items
                            const aRemainingItems = aItems.filter(item =>
                                !aSelectedItems.some(sel => sel.ID === item.ID)
                            );
                            oAssessmentModel.setProperty("/items", aRemainingItems);
                        } catch (oError) {
                            MessageBox.error("Error during batch deletion: " + (oError.message || "Unknown error"));
                        } finally {
                            oView.setBusy(false);
                        }
                    }.bind(this)
                });
            },

            onFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oEvent.getParameter("files"),
                    oContext = oFileUploader.getBindingContext();

                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oContext.setProperty("content", sFileContent.split(',')[1], "proofDocumentsGroup", true);
                        oContext.setProperty("fileName", oFile.name, "proofDocumentsGroup", true);
                        oContext.setProperty("mediaType", oFile.type, "proofDocumentsGroup", true);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            onMultipleUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aFiles = oFileUploader.oFileUpload.files,
                    oProofTable = this.getView().byId("proofTable"),
                    oBinding = oProofTable.getBinding("rows"),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext");

                if (aFiles.length === 0) {
                    MessageToast.show("No se seleccionaron archivos.");
                    return;
                }

                let aPromises = Array.from(aFiles).map(oFile => {
                    return new Promise((resolve, reject) => {
                        let oReader = new FileReader();

                        oReader.onload = function (e) {
                            resolve({
                                requestId: oContext.getProperty("ID"),
                                fileName: oFile.name,
                                mediaType: oFile.type,
                                content: e.currentTarget.result.split(',')[1],
                                internalPath: oFile.name,
                                active: true
                            });
                        };

                        oReader.onerror = function () {
                            reject(`Error leyendo el archivo: ${oFile.name}`);
                        };

                        oReader.readAsDataURL(oFile);
                    });
                });


                Promise.all(aPromises)
                    .then(aFileList => {
                        aFileList.forEach(oFile => {
                            oBinding.create(oFile, true);
                        });
                        oFileUploader.clear();
                    })
                    .catch(error => {
                        MessageToast.show(error);
                    });
            },

            onMapProofsUpload: function () {
                if (!this._mapUploadProofPointsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.MapProofPointsDialog",
                        controller: this
                    }).then(function (oMapUploadProofPointsDialog) {
                        this._mapUploadProofPointsDialog = oMapUploadProofPointsDialog;
                        this.getView().addDependent(this._mapUploadProofPointsDialog);
                        this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                        this._mapUploadProofPointsDialog.open();
                    }.bind(this));
                } else {
                    this._mapUploadProofPointsDialog.open();
                    this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                }
            },

            onMassMultipleUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints"),
                    aFiles = oFileUploader.oFileUpload.files,
                    aFileList = [];

                if (aFiles.length === 0) {
                    MessageToast.show("No se seleccionaron archivos.");
                    return;
                }

                let aPromises = Array.from(aFiles).map(oFile => {
                    return new Promise((resolve, reject) => {
                        let oReader = new FileReader();

                        oReader.onload = function (e) {
                            resolve({
                                fileName: oFile.name,
                                mediaType: oFile.type,
                                content: e.currentTarget.result.split(',')[1],
                                internalPath: oFile.name,
                                active: "Y"
                            });
                        };

                        oReader.onerror = function () {
                            reject(`Error leyendo el archivo: ${oFile.name}`);
                        };

                        oReader.readAsDataURL(oFile);
                    });
                });


                Promise.all(aPromises)
                    .then(aFileList => {
                        let aUpdatedFiles = aProofPoints.concat(aFileList);
                        this.getModel("assessmentModel").setProperty("/massProofPoints", aUpdatedFiles);
                        oFileUploader.clear();
                    })
                    .catch(error => {
                        MessageToast.show(error);
                    });
            },

            onMassUploadFileChange: function (oEvent) {
                let oFileUploader = oEvent.getSource(),
                    oAssessmentModel = this.getView().getModel("assessmentModel"),
                    aFiles = oEvent.getParameter("files"),
                    sPath = oFileUploader.getBindingInfo("value").binding.getContext().getPath();


                if (aFiles && aFiles.length > 0) {
                    let oFile = aFiles[0];

                    var oReader = new FileReader();
                    oReader.onload = function (e) {
                        var sFileContent = e.currentTarget.result;

                        oAssessmentModel.setProperty(sPath + "/content", sFileContent.split(',')[1]);
                        oAssessmentModel.setProperty(sPath + "/fileName", oFile.name);
                        oAssessmentModel.setProperty(sPath + "/mediaType", oFile.type);

                    }.bind(this);

                    oReader.onerror = function (e) {
                        sap.m.MessageToast.show("Error reading file");
                    };

                    oReader.readAsDataURL(oFile);

                }
            },

            /**
            * Set contributor's items value depending on the category
            * @public
            */
            onMassCategory1Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor1");
                });

                oModel.setProperty(sPath + "/contributor1", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            /**
            * Set contributor's items value depending on the category
            * @public
            */
            onMassCategory2Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor2");
                });

                oModel.setProperty(sPath + "/contributor2", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            /**
            * Set contributor's items value depending on the category
            * @public
            */
            onMassCategory3Change: function (oEvent) {
                let aCells = oEvent.getSource().getParent().getCells(),
                    sSelectedKey = oEvent.getSource().getSelectedKey(),
                    oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel();

                let oContributor = aCells.find(function (oCell) {
                    return oCell.getId().includes("contributor3");
                });

                oModel.setProperty(sPath + "/contributor3", "");
                this.setMassContributorItems(sSelectedKey, oContributor);
            },

            /**
            * Reset and set fields wich depending on sustainability class
            * @public
            */
            onMassClassChange: function (oEvent) {
                const oItem = oEvent.getSource(),
                    oContext = oItem.getBindingContext("assessmentModel"),
                    oRow = oEvent.getSource().getParent();

                this.resetMassCategoryFields(oContext);
                this.resetMassContributorFields(oContext);
                this.setRowEnabledFields(oRow);
            },

            /**
            * check number of selected rows in item's table
            * @public
            */
            onSelectionChange: function (oEvent) {
                let aSelectedItems = this.getView().byId("massItems").getDependents()[0].getSelectedIndices().length;
                this.getModel("assessmentModel").setProperty("/selectedRows", aSelectedItems);
            },

            /**
            * Mass upload open dialog
            * @public
            */
            onMassUpload: function () {
                let aSelectedIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices();

                if (aSelectedIndices.length > 0) {
                    if (!this._massUploadProofPointsDialog) {
                        Fragment.load({
                            id: this.getView().getId(),
                            name: "com.sustainability.overview.view.fragment.Assessment.MassUploadProofPointsDialog",
                            controller: this
                        }).then(function (oMassUploadProofPointsDialog) {
                            this._massUploadProofPointsDialog = oMassUploadProofPointsDialog;
                            this.getView().addDependent(this._massUploadProofPointsDialog);
                            this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                            this._massUploadProofPointsDialog.open();
                        }.bind(this));
                    } else {
                        this._massUploadProofPointsDialog.open();
                        this.getModel("assessmentModel").setProperty("/validProofType", this.getModel("assessmentModel").getProperty("/proofType"));
                    }
                } else {
                    MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                }
            },

            /**
            * Add new row to mass proof points Dialog
            * @public
            */
            onMassUploadAddProofRow: function () {
                let aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");
                aProofPoints.push({});
                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
            },

            /**
            * Delete selected rows on mass proof points Dialog
            * @public
            */
            onMassUploadDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                aSelectedIndices.reverse().forEach(function (iIndice) {
                    aProofPoints.splice(iIndice, 1);
                });

                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
                //this.getView().byId("massUploadProofTable").removeSelections(true);
            },

            onMapUploadDeleteProofRow: function () {
                let aSelectedIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    aProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                aSelectedIndices.reverse().forEach(function (iIndice) {
                    aProofPoints.splice(iIndice, 1);
                });

                this.getModel("assessmentModel").setProperty("/massProofPoints", aProofPoints);
                //this.getView().byId("massUploadProofTable").removeSelections(true);
            },

            onMessagePopoverPress: async function (oEvent) {
                const oSourceControl = oEvent.getSource();
                const oMessagePopover = await this._getMessagePopover();
                oMessagePopover.openBy(oSourceControl);
            },

            onMessagePopoverPress: async function (oEvent) {
                const oSourceControl = oEvent.getSource();
                const oMessagePopover = await this._getMessagePopover();
                oMessagePopover.openBy(oSourceControl);
            },

            /**
            * Open Add new products dialog
            * The SBU of the assessment seted in the filters
            * @public
            */
            onAddNewItem: function () {
                let aSbu = [];
                aSbu.push(this.getModel("assessmentModel").getProperty("/sbu"));
                if (!this._addProductsDialog) {
                    this.getExtensionAPI().loadFragment({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.AddNewProductsDialog",
                        controller: this
                    }).then(function (oAddNewProductsDialog) {
                        this._addProductsDialog = oAddNewProductsDialog;
                        this.getView().addDependent(this._addProductsDialog);
                        this.getView().byId("ibDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                        this.getView().byId("idhDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                        this.getView().byId("ibDialogFilterbar").setFilterFieldEnabled("sbu", false);
                        this.getView().byId("idhDialogFilterbar").setFilterFieldEnabled("sbu", false);
                        this.getView().byId("idhDialogTable").getContent().clearSelection();
                        this.getView().byId("ibDialogTable").getContent().clearSelection();
                        this._addProductsDialog.open();
                    }.bind(this));
                } else {
                    this.getView().byId("ibDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                    this.getView().byId("idhDialogFilterbar").setFilterValues("sbu", "EQ", aSbu);
                    this.getView().byId("ibDialogFilterbar").setFilterFieldEnabled("sbu", false);
                    this.getView().byId("idhDialogFilterbar").setFilterFieldEnabled("sbu", false);
                    this.getView().byId("idhDialogTable").getContent().clearSelection();
                    this.getView().byId("ibDialogTable").getContent().clearSelection();
                    this._addProductsDialog.open();
                }
            },

            /**
            * Paste copy items in selected rows
            * Only editable fields with values are pasted
            * The function evaluate the RcPreFalg property
            * @public
            */
            onPasteItem: function () {
                let aIndices = this.getView().byId("massItems").getDependents()[0].getSelectedIndices(),
                    oItemsTable = this.getView().byId("massItems"),
                    oCopyItem = this.getModel("assessmentModel").getProperty("/copyItem"),
                    oModel = this.getModel(),
                    oRulesModel = this.getModel("rules").getProperty("/"),
                    oAssessmentModel = this.getView().getModel("assessmentModel"),
                    bShowMessage = false,
                    oPageContext = this.getView().byId("massPage").getBindingContext();

                this.getView().setBusyIndicatorDelay(0);
                this.getView().setBusy(true);

                const aProperties = [
                    "comment",
                    "sustClass",
                    "category1",
                    "contributor1",
                    "category2",
                    "contributor2",
                    "category3",
                    "contributor3",
                    "propagation"
                ];

                const aFilteredProperties = [
                    "category1",
                    "contributor1",
                    "category2",
                    "contributor2",
                    "category3",
                    "contributor3"
                ];
                setTimeout(() => {
                    if (aIndices.length > 0) {

                        for (let iIndex of aIndices) {
                            let oContext = oItemsTable.getContextByIndex(iIndex),
                                oRow = oItemsTable.getRows()[iIndex],
                                sItemPath = oContext.getPath(),
                                sRcPreFlag = oContext.getProperty("rcPreFlag");

                            if (oContext.getObject() === oCopyItem) {
                                continue;
                            }

                            if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag]["sustCodes"]) {
                                var oRulesSustCodes = oRulesModel[sRcPreFlag]["sustCodes"];


                                //if (oContext.getProperty("rcPreFlag") === oCopyItem.rcPreFlag) {
                                if (oRulesSustCodes.codes.includes(oCopyItem["sustClass"])) {
                                    var oMassEnabledFlieds = oRulesModel[sRcPreFlag][oCopyItem["sustClass"]].massEnabled;
                                    aProperties.forEach(property => {
                                        if (oCopyItem[property]) {

                                            oAssessmentModel.setProperty(`${sItemPath}/${property}`, oCopyItem[property]);

                                            if (property === "category1") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor1`, "");
                                            } else if (property === "category2") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor2`, "");
                                            } else if (property === "category3") {
                                                oAssessmentModel.setProperty(`${sItemPath}/contributor3`, "");
                                            }
                                        } else {
                                            if (!oMassEnabledFlieds[property] && aFilteredProperties.includes(property)) {
                                                oAssessmentModel.setProperty(`${sItemPath}/${property}`, "");
                                            }
                                        }

                                    });

                                    /*let oContextBinding = oModel.bindList("toProofDocuments", oContext, undefined, undefined, { $$updateGroupId: "UpdateGroup" });
        
                                    oCopyItem.toProofDocuments.forEach((oProofDocument, iIndex) => {
                                        oContextBinding.create(oProofDocument, true);
                                    });*/
                                    /*if (oRow) {
                                        this.setRowEnabledFields(oRow);
                                    }*/
                                } else {
                                    bShowMessage = true;
                                }

                            } else {
                                bShowMessage = true;
                            }
                        };

                        //if (oPageContext) {
                        this.updatedRowFields();
                        //}

                        if (bShowMessage) {
                            MessageToast.show(this.getResourceBundle().getText("noSuccessPaste"));
                        } else {
                            MessageToast.show(this.getResourceBundle().getText("successPaste"));
                        }

                    } else {
                        MessageToast.show(this.getResourceBundle().getText("noSelectedRows"));
                    }

                    this.getView().setBusy(false);
                }, 0);
            },

            onPasteMassProofPoint: function () {
                let aIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                    oCopyRow = this.getModel("assessmentModel").getProperty("/copyMassProofPoint");


                if (!oCopyRow) {
                    MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                    return;
                }

                const aProperties = [
                    "type",
                    "description"
                ];


                let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                for (let iIndex of aIndices) {

                    if (aMassProofPoints[iIndex]) {
                        let oTargetRow = aMassProofPoints[iIndex];


                        for (let sProperty of aProperties) {
                            if (oCopyRow.hasOwnProperty(sProperty)) {
                                if (oCopyRow[sProperty]) {
                                    oTargetRow[sProperty] = oCopyRow[sProperty];
                                }
                            }
                        }
                    }
                }


                this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);


                MessageToast.show(this.getResourceBundle().getText("successPaste"));
            },

            onPasteMapProofPoint: function () {
                let aIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    oCopyRow = this.getModel("assessmentModel").getProperty("/copyMapProofPoint");


                if (!oCopyRow) {
                    MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                    return;
                }

                const aProperties = [
                    "type",
                    "description"
                ];


                let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                for (let iIndex of aIndices) {

                    if (aMassProofPoints[iIndex]) {
                        let oTargetRow = aMassProofPoints[iIndex];


                        for (let sProperty of aProperties) {
                            if (oCopyRow.hasOwnProperty(sProperty)) {
                                if (oCopyRow[sProperty]) {
                                    oTargetRow[sProperty] = oCopyRow[sProperty];
                                }
                            }
                        }
                    }
                }


                this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);


                MessageToast.show(this.getResourceBundle().getText("successPaste"));
            },

            /* onPasteMassProofPoint: function () {
                 let aIndices = this.getView().byId("massUploadProofTable").getDependents()[0].getSelectedIndices(),
                     oCopyRow = this.getModel("assessmentModel").getProperty("/copyMassProofPoint");
 
 
                 if (!oCopyRow) {
                     MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                     return;
                 }
 
                 const aProperties = [
                     "type",
                     "description"
                 ];
 
 
                 let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");
 
                 for (let iIndex of aIndices) {
 
                     if (aMassProofPoints[iIndex]) {
                         let oTargetRow = aMassProofPoints[iIndex];
 
 
                         for (let sProperty of aProperties) {
                             if (oCopyRow.hasOwnProperty(sProperty)) {
                                 if (oCopyRow[sProperty]) {
                                     oTargetRow[sProperty] = oCopyRow[sProperty];
                                 }
                             }
                         }
                     }
                 }
 
 
                 this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);
 
 
                 MessageToast.show(this.getResourceBundle().getText("pastedRows"));
             },*/

            /*onPasteMapProofPoint: function () {
                let aIndices = this.getView().byId("mapUploadProofTable").getDependents()[0].getSelectedIndices(),
                    oCopyRow = this.getModel("assessmentModel").getProperty("/copyMapProofPoint");


                if (!oCopyRow) {
                    MessageToast.show(this.getResourceBundle().getText("noRowCopied"));
                    return;
                }

                const aProperties = [
                    "type",
                    "description"
                ];


                let aMassProofPoints = this.getModel("assessmentModel").getProperty("/massProofPoints");

                for (let iIndex of aIndices) {

                    if (aMassProofPoints[iIndex]) {
                        let oTargetRow = aMassProofPoints[iIndex];


                        for (let sProperty of aProperties) {
                            if (oCopyRow.hasOwnProperty(sProperty)) {
                                if (oCopyRow[sProperty]) {
                                    oTargetRow[sProperty] = oCopyRow[sProperty];
                                }
                            }
                        }
                    }
                }


                this.getModel("assessmentModel").setProperty("/massProofPoints", aMassProofPoints);


                MessageToast.show(this.getResourceBundle().getText("pastedRows"));
            },*/

            /**
            * Open proof points Dialog
            * @public
            */
            onPressProofPointsCheck: function (oEvent) {
                let oContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    sPath = oContext.getPath(),
                    oModel = oContext.getModel(),
                    oRulesModel = this.getModel("rules").getProperty("/"),
                    sRcPreFlag = oContext.getProperty("rcPreFlag"),
                    sSustClas = oContext.getProperty("sustClass");

                if (oRulesModel[sRcPreFlag] && oRulesModel[sRcPreFlag][sSustClas]) {
                    const oRules = oRulesModel[sRcPreFlag][sSustClas];
                    this.setProofEnable(oRules.proofEnabled);
                    this.getModel("assessmentModel").setProperty("/rulesAddProofEnabled", oRules.proofEnabled);
                } else {
                    this.setProofEnable(false);
                }

                if (!this._proofPointsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.ProofPointsDialog",
                        controller: this
                    }).then(function (oProofPointsDialog) {
                        //this.getView().byId("proofPointsDialog").setBindingContext(oContext);
                        this._proofPointsDialog = oProofPointsDialog;
                        this.getView().addDependent(this._proofPointsDialog);
                        let oTable = this.getView().byId("proofTable"),
                            oBinding = oTable.getBinding("rows");

                        if (oBinding) {
                            let oFilter = new Filter("requestId", FilterOperator.EQ, oModel.getProperty(sPath + "/ID"));

                            oBinding.filter([oFilter]);
                        }
                        this._proofPointsDialog.open();
                        this.getModel("assessmentModel").setProperty("/itemContext", oContext);
                        //this.checkMandatoryProofFields(oContext);

                    }.bind(this));
                } else {
                    this.getModel("assessmentModel").setProperty("/itemContext", oContext);
                    let oTable = this.getView().byId("proofTable"),
                        oBinding = oTable.getBinding("rows");

                    if (oBinding) {
                        let oFilter = new Filter("requestId", FilterOperator.EQ, oContext.getProperty("ID"));

                        oBinding.filter([oFilter]);
                    }
                    this._proofPointsDialog.open();
                    //this.getView().byId("proofPointsDialog").setBindingContext(oContext);
                    //this.setProofTypesOptions(oContext);
                    //this._setProofValidTypes(oContext);


                    //this.checkMandatoryProofFields(oContext);
                }
            },

            onProofRowsUpdated: function () {
                let oContext = this.getModel("assessmentModel").getProperty("/itemContext");
                if (Object.keys(oContext).length !== 0) {
                    this._setProofValidTypes(oContext);
                    this.setProofTypesOptions(oContext);
                }

            },

            onPressRelatedProductsDialog: async function (oEvent) {
                let oAssessmentModel = this.getModel("assessmentModel"),
                    oItemContext = oEvent.getSource().getBindingContext("assessmentModel"),
                    //oHeaderContext = this.getView().byId("massPage").getBindingContext(),
                    sProduct = oAssessmentModel.getProperty(oItemContext.getPath() + "/product"),
                    oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aRelatedProducts = await this.getRelatedProductsData(oHeader.productType, sProduct);
                this.getModel("assessmentModel").setProperty("/productRelation", aRelatedProducts);

                if (!this._relatedproductsDialog) {
                    Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overview.view.fragment.Assessment.RelatedProductsDialog",
                        controller: this
                    }).then(function (oRelatedProductsDialog) {
                        this._relatedproductsDialog = oRelatedProductsDialog;
                        this.getView().addDependent(this._relatedproductsDialog);
                        this._relatedproductsDialog.open();

                    }.bind(this));
                } else {
                    this._relatedproductsDialog.open();
                }
            },

            onCloseRelatedProductsDialog: function () {
                this._relatedproductsDialog.close();
            },

            /**
            * Triggered each time the table rows are updated.
            * @public
            */
            onRowsUpdated: function (oEvent) {
                //let oContext = this.getView().getModel("ui").getProperty("/oContext")
                let oContext = this.getView().byId("massPage").getBindingContext();
                if (oContext) {
                    if (Object.keys(oContext).length !== 0) {
                        this.updatedRowFields(oContext);
                    }
                }
                //this.setMassSustClass(oContext);
            },

            /**
            * Submit the mass Assessment
            * The assessment is evaluated before submit action
            * @public
            */
            onSubmit: async function () {
                const oHeader = this.getModel("assessmentModel").getProperty("/header");
                this.getModel("assessmentModel").setProperty("/userAction", "Submit");

                this.openRecipientsDialog("02", oHeader.sbu, "");
            },

            onSubmitDocuments: function () {
                let oModel = this.getModel(),
                    oObjectPage = this.getView().byId("massPage"),
                    oHeaderContext = oObjectPage.getBindingContext(),
                    oItemsContext = this.getView().byId("massItems").getBinding("rows"),
                    bContinue = true,
                    oMessageModel = sap.ui.getCore().getMessageManager().getMessageModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                //oHeaderContext.setProperty("status", "02", "UpdateGroup", true);
                //this.setItemsStatus("02");

                /* let oMassAssessment = oHeaderContext.getObject();
 
                 let { toItems, ...restOfObject } = oMassAssessment;
 
                 delete restOfObject["@odata.context"];
                 delete restOfObject.toStatus;*/

                //const oActionODataContextBinding = oModel.bindContext("/submitProofpointsVirtualAssessment(...)");
                //oActionODataContextBinding.setParameter("header", restOfObject);
                //oActionODataContextBinding.setParameter("items", toItems);

                let oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    oItems = this.getModel("assessmentModel").getProperty("/items");

                const oActionODataContextBinding = oModel.bindContext("/submitProofpointsVirtualAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", oItems);

                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSubmited"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {
                                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    }.bind(this)
                ).catch(function (oError) {
                    oHeaderContext.setProperty("status", "91", "UpdateGroup", true);
                    this.getView().setBusy(false);
                }.bind(this));
            },

            /**
            * Save new Assessment
            * In the save funcioanlity te Assessment is not evaluated
            * @public
            */
            onSave: async function () {
                const oHeader = this.getModel("assessmentModel").getProperty("/header");
                this.getModel("assessmentModel").setProperty("/userAction", "Save");

                this.openRecipientsDialog("01", oHeader.sbu, "");

            },

            handleLinkPress: function (oEvent) {
                let oModel = this.getModel(),
                    oProofPoint = oEvent.getSource().getBindingContext().getObject(),
                    baseUrl = oModel.getServiceUrl(),
                    sUploadURL = "";

                if (oProofPoint.externalUrl) {
                    sUploadURL = oProofPoint.url;
                } else {
                    sUploadURL = baseUrl + oProofPoint.url;
                }

                window.open(sUploadURL, '_blank');

            },

            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/
            onPropagationChange: function (oEvent) {
                const sSelectedKey = oEvent.getParameter("selectedItem").getKey();
                const bValue = sSelectedKey === "true";

                const oContext = oEvent.getSource().getBindingContext("assessmentModel");
                oContext.getModel().setProperty(oContext.getPath() + "/propagation", bValue);
            },

            _getMessagePopover() {
                return this.loadFragment({
                    name: "com.sustainability.overview.view.fragment.MessagePopover"
                });
            },

            onActiveChange: function (oEvent) {
                let oSelectedKey = oEvent.getParameter("selectedItem").getKey(),
                    oContext = this.getModel("assessmentModel").getProperty("/itemContext"),
                    bValue = (oSelectedKey === "true");

                oEvent.getSource().getBindingContext().setProperty("active", bValue);
                if (oContext) {
                    this.setProofTypesOptions(oContext);
                }

            },

            _onNewMassAssessmentMatched: async function (oEvent) {
                let oView = this.getView().byId("massPage"),
                    //oContext = this.getView().getModel("ui").getProperty("/oContext"),
                    oContext = this.getModel("ui").getProperty("/oContext"),
                    sId = oEvent.getParameter("arguments").assessment,
                    onlyDocuments = oEvent.getParameter("arguments").onlyDocuments,
                    //sSbu = oContext.getProperty("sbu"),
                    aComposedRoles = this.getModel("ui").getProperty("/userParameters/composedRoles"),
                    aProofTypes = [],
                    aPropagationValues = [],
                    aContributors = [],
                    aCategories = [],
                    aSustClass = [],
                    aAssessmentData = [];

                sap.ui.getCore().getMessageManager().removeAllMessages();


                this.getView().byId("massItems").getDependents()[0].setLimit(0);
                aAssessmentData = await this.getAssessmentData(sId);
                let { toItems, ...oHeader } = aAssessmentData[0];
                this.getModel("assessmentModel").setProperty("/header", oHeader);
                this.getModel("assessmentModel").setProperty("/items", toItems);

                //this.getView().byId("requestData").bindElement("assessmentModel>/header");

                let sSbu = oHeader.sbu;

                this.getView().byId("massPage").setShowFooter(true);

                if (aComposedRoles.some(role => role === sSbu + ".Submitter")) {
                    this.getView().byId("submitButton").setVisible(true);
                    this.getView().byId("saveButton").setVisible(true);
                } else if (aComposedRoles.some(role => role === sSbu + ".Assessor")) {
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(true);
                } else {
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(false);
                }

                this.getModel("assessmentModel").setProperty("/type", oHeader.productType);
                this.getModel("assessmentModel").setProperty("/sbu", oHeader.sbu);
                this.getModel("assessmentModel").setProperty("/assesmentType", oHeader.assesmentType);

                aProofTypes = await this.getProofTypes();
                aContributors = await this.getContributors();
                aCategories = await this.getCategories();
                aSustClass = await this.getSustClass();
                this.getModel("assessmentModel").setProperty("/contributors", aContributors);
                this.getModel("assessmentModel").setProperty("/categories", aCategories);
                this.getModel("assessmentModel").setProperty("/sustClass", aSustClass);
                this.getModel("assessmentModel").setProperty("/proofType", aProofTypes);
                this.getModel("assessmentModel").setProperty("/validProofType", aProofTypes);

                if (onlyDocuments === "true") {
                    this.getModel("assessmentModel").setProperty("/onlyDocuments", true);
                    this.getModel("assessmentModel").setProperty("/editMode", false);
                    this.getView().byId("submitButton").setVisible(false);
                    this.getView().byId("saveButton").setVisible(false);
                    this.getView().byId("submitOnlyDouments").setVisible(true);

                } else {
                    this.getModel("assessmentModel").setProperty("/onlyDocuments", false);
                    this.getModel("assessmentModel").setProperty("/editMode", true);
                    this.getView().byId("submitButton").setVisible(true);
                    this.getView().byId("saveButton").setVisible(true);
                    this.getView().byId("submitOnlyDouments").setVisible(false);
                }

                sap.ui.getCore().getMessageManager().removeAllMessages();

                this.getView().setBusy(false);

                this.getView().byId("massItems").bindRows("assessmentModel>/items");

            },

            _saveAssessment: async function () {
                const oModel = this.getModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();

                this.getModel("assessmentModel").setProperty("/header/status", "01");
                this.setItemsStatus("01");
                this.getView().setBusy(true);

                let oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aItems = this.getModel("assessmentModel").getProperty("/items");

                const oActionODataContextBinding = oModel.bindContext("/SaveMassAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", aItems);

                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSaved"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {

                                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    }.bind(this)
                ).catch(function (oError) {
                    this.getView().setBusy(false);

                }.bind(this));
            },

            _submitAssessment: async function () {
                const oModel = this.getModel();

                sap.ui.getCore().getMessageManager().removeAllMessages();


                this.getModel("assessmentModel").setProperty("/header/status", "02");
                this.setItemsStatus("02");
                this.getView().setBusy(true);

                let oHeader = this.getModel("assessmentModel").getProperty("/header"),
                    aItems = this.getModel("assessmentModel").getProperty("/items");

                const oActionODataContextBinding = oModel.bindContext("/SubmitMassAssessment(...)");
                oActionODataContextBinding.setParameter("header", oHeader);
                oActionODataContextBinding.setParameter("items", aItems);

                oActionODataContextBinding.execute().then(
                    async function (oData, test) {
                        this.getView().setBusy(false);
                        MessageBox.information(this.getResourceBundle().getText("assessmentSubmited"), {
                            onClose: function (sAction) {
                                if (sAction === 'OK') {
                                    this.getAppComponent().getRouter().navTo("AssessmentOverview", undefined, undefined, true);
                                }
                            }.bind(this)
                        });
                    }.bind(this)
                ).catch(function (oError) {
                    this.getModel("assessmentModel").setProperty("/header/status", "01");
                    this.getView().setBusy(false);
                }.bind(this));

            },

            /**
            * Set valid proof types depending on the contributors selected
            * @private
            */
            _setProofValidTypes: function (oContext) {

                this.checkRemoveTypeProofFields(oContext);
            }

        });
    }
);