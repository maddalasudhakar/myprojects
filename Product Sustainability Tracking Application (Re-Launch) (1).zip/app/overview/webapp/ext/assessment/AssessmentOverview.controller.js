sap.ui.define(
    [
        "sap/fe/core/PageController",
        "sap/ui/model/json/JSONModel",
        "../../model/formatter",
    ],
    function (PageController, JSONModel, formatter) {
        'use strict';

        return PageController.extend('com.sustainability.overview.ext.assessment.AssessmentOverview', {
            formatter: formatter,
            /**
             * Called when a controller is instantiated and its View controls (if available) are already created.
             * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
             */
            onInit: function () {
                PageController.prototype.onInit.apply(this);
                let oViewModel = new JSONModel({
                    status: {},
                    selectedStatuses: []
                });
                this.setModel(oViewModel, "assessmentOverviewModel");
                this.getAppComponent().getRouter().getRoute("AssessmentOverview").attachPatternMatched(this._onAssessmentOverviewMatched, this);

            },

            /***********************************************************************
            *
            * Public Methods
            * 
            ***********************************************************************/

            onAssessmentPress: async function (oEvent) {
                let oAssessmet = await this._getAssessmentData(oEvent.getParameter("bindingContext"));

                if (oAssessmet.assesmentType === "S") {
                    // this.routing.navigateToRoute("SingleAssessment", {
                    //     assessment: oAssessmet.ID
                    // });
                    this.getAppComponent().getRouter().navTo("SingleAssessment", { assessment: oAssessmet.ID });
                } else {
                    // this.routing.navigateToRoute("MassAssessment", { assessment: oAssessmet.ID });
                    this.getAppComponent().getRouter().navTo("MassAssessment", { assessment: oAssessmet.ID });
                    /*this.routing.navigateToRoute("MassAssessment", {
                        assessment: oAssessmet.ID
                    }, undefined);*/
                }

            },

            onCloseStatusFilterbar: function () {
                this._statusFilterbarDialog.close();
            },

            onPressDialogOverview: function () {
                if (!this._statusFilterbarDialog) {
                    sap.ui.core.Fragment.load({
                        id: this.getView().getId(),
                        name: "com.sustainability.overviewfpm.fragment.StatusOverviewFiltersDialog",
                        controller: this
                    }).then(function (oStatusFilterbarDialog) {
                        this._statusFilterbarDialog = oStatusFilterbarDialog;
                        this.getView().addDependent(this._statusFilterbarDialog);
                        this._statusFilterbarDialog.open();
                    }.bind(this));
                } else {
                    this._statusFilterbarDialog.open();
                }
            },
            onSearchFilters: async function () {
                const oView = this.getView();
                const oViewModel = oView.getModel("assessmentOverviewModel");

                const oFilterBar = oView.byId("assessmentFilterBar");
                const oFilterResult = await oFilterBar.getFilters();
                const aStandardFilters = oFilterResult?.filters || [];

                const aSelectedStatuses = oViewModel.getProperty("/selectedStatuses") || [];

                let oStatusInnerFilter = null;
                if (aSelectedStatuses.length > 0) {
                    const aStatusFilters = aSelectedStatuses.map((status) =>
                        new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, status)
                    );

                    oStatusInnerFilter = new sap.ui.model.Filter({
                        filters: aStatusFilters,
                        and: false
                    });
                }

                const aFinalFilters = [];

                aStandardFilters.forEach(f => aFinalFilters.push(f));

                if (oStatusInnerFilter) {
                    aFinalFilters.push(oStatusInnerFilter);
                }

                const oCombinedFilter = new sap.ui.model.Filter({
                    filters: aFinalFilters,
                    and: true
                });

                const oTable = this.getView().byId("assessmentTable");
                const oBinding = oTable?.getRowBinding?.();

                if (oBinding) {
                    if (oBinding.isSuspended()) {
                        oBinding.resume();
                    }
                    oTable.removeStyleClass("table-blocked");
                    oTable.addStyleClass("table-unblocked");

                    oBinding.filter(oCombinedFilter);

                } else {
                    console.warn("Binding not found.");
                }
            },

            onFilterChanged: function () {
                const oTable = this.byId("assessmentTable");


                oTable.addStyleClass("table-blocked");
                oTable.removeStyleClass("table-unblocked");
            },

            onStatusFilterChanged: function () {
                const oTable = this.byId("assessmentTable");

                oTable.addStyleClass("table-blocked");
                oTable.removeStyleClass("table-unblocked");
            },



            /***********************************************************************
            *
            * Private Methods
            * 
            ***********************************************************************/

            _getAssessmentData: async function (oSelectedContext) {
                let oModel = this.getModel()

                try {
                    let oAssessmet = await oModel.bindContext(oSelectedContext.getPath()).requestObject();
                    return oAssessmet;
                } catch (oError) {

                }

            },

            _onAssessmentOverviewMatched: async function () {
                let aSbu = this.getModel("ui").getProperty("/userParameters/sbu"),
                    aRoles = this.getModel("ui").getProperty("/userParameters/role"),
                    sUserId = this.getModel("ui").getProperty("/userParameters/userId"),
                    sStartupParameter = this.getModel("ui").getProperty("/startupParameter"),
                    sRoleKey = Object.keys(aRoles).find(key => aRoles[key] === true),
                    oModel = this.getModel(),
                    sPath = "/GetAssessmentsUser()",
                    aDefaultStatuses = [];

                this.getView().setBusy(true);

                /*const oTable = this.getView().byId("assessmentTable");
                const oBinding = oTable?.getRowBinding?.();
                oBinding.suspend();*/

                if (this.getModel().hasPendingChanges("UpdateGroup")) {
                    this.getModel().resetChanges("UpdateGroup");
                }

                /*if (aRoles.Assessor && sStartupParameter === "assessments") {
                    this.getView().byId("assessmentFilterBar").setFilterValues("assessor", "EQ", sUserId);
                }
                if (aRoles.Submitter && sStartupParameter === "assessments") {
                    this.getView().byId("assessmentFilterBar").setFilterValues("submitter", "EQ", sUserId);
                }*/

                if (sStartupParameter === "assessments") {
                    let aSbuNewAssessment = this.getModel("ui").getProperty("/userParameters/sbu/newAssessment");
                    aSbuNewAssessment.forEach(sSbu => {
                        this.getView().byId("assessmentFilterBar").setFilterValues("sbu", "EQ", sSbu);
                    });
                }

                if (sStartupParameter === "overview") {
                    let aSbuNewAssessment = this.getModel("ui").getProperty("/userParameters/sbu/newAssessment");
                    aSbuNewAssessment.forEach(sSbu => {
                        this.getView().byId("assessmentFilterBar").setFilterValues("sbu", "EQ", sSbu);
                    });
                    aDefaultStatuses = ["01"];
                    this.getView().getModel("assessmentOverviewModel").setProperty("/selectedStatuses", aDefaultStatuses);
                    //await this.getView().byId("assessmentFilterBar").setFilterValues("status", "EQ", "01");
                    // Obtén la referencia del MultiComboBox
                    //var oMultiComboBox = this.byId("statusComboBox");

                    // Establece el valor por defecto, en este caso "01"
                    //oMultiComboBox.setSelectedKeys(["01"]);
                }

                if (aRoles.Approver && sStartupParameter === "approval") {
                    let aApproveSbu = this.getModel("ui").getProperty("/userParameters/sbu/approveAssessment");
                    //this.getView().byId("assessmentFilterBar").setFilterValues("approver", "EQ", sUserId);
                    //this.getView().byId("assessmentFilterBar").setFilterValues("status", "EQ", "02");
                    //this.getView().byId("assessmentFilterBar").setFilterValues("status", "EQ", "04");
                    //this.getView().byId("assessmentFilterBar").setFilterValues("status", "EQ", "07");

                    aDefaultStatuses = ["02", "04", "07"];
                    this.getView().getModel("assessmentOverviewModel").setProperty("/selectedStatuses", aDefaultStatuses);

                    aApproveSbu.forEach(sSbu => {
                        this.getView().byId("assessmentFilterBar").setFilterValues("sbu", "EQ", sSbu);
                    });
                }

                this.getView().byId("assessmentTable").getContent().clearSelection();
                //this.getView().byId("assessmentTable").setBusy(true);

                oModel.bindContext(sPath).requestObject().then((oObject) => {
                    this.getModel("assessmentOverviewModel").setProperty("/status", oObject);
                    this.getView().setBusy(false);
                }).catch((oError) => {
                    this.getView().setBusy(false);
                });

            }

        });
    }
);