using SustainabilityManagement as service from '../../srv/sustainability.service';


annotate service.Idh with {
    materialtNumber          @title: '{@i18n>materialLabel}';
    materialDescription      @title: '{@i18n>materialDescriptionLabel}';
    sbu                      @title: '{@i18n>sbuLabel}';
    sbuDescription           @title: '{@i18n>sbuDescriptionLabel}';
    sustClass                @title: '{@i18n>primaryClassLabel}';
    sustClassDescription     @title: '{@i18n>primaryClassLabel}';
    category                 @title: '{@i18n>sustCategory1}';
    categoryDescription      @title: '{@i18n>sustCategory1}';
    contributor              @title: '{@i18n>sustContributor1}';
    contributorDescription   @title: '{@i18n>sustContributor1}';
    assesor                  @title: '{@i18n>assessorLabel}';
    approver                 @title: '{@i18n>approverLabel}';
    technologyL2             @title: '{@i18n>technologyLabel}';
    technologyL2Description  @title: '{@i18n>technologyLabel}';
    rcPreFlag                @title: '{@i18n>rcPreFlagLabel}';
    rcPreFlagDescription     @title: '{@i18n>rcPreFlagLabel}';
    applicationL2            @title: '{@i18n>applicationLevelLabel}';
    applicationL2Description @title: '{@i18n>applicationLevelLabel}';
    approvalDate             @title: '{@i18n>lastAssessmentApprovalLabel}';
}


annotate service.Ib with {
    materialtNumber          @title: '{@i18n>materialLabel}';
    materialDescription      @title: '{@i18n>materialDescriptionLabel}';
    sbu                      @title: '{@i18n>sbuLabel}';
    sbuDescription           @title: '{@i18n>sbuDescriptionLabel}';
    sustClass                @title: '{@i18n>primaryClassLabel}';
    sustClassDescription     @title: '{@i18n>primaryClassLabel}';
    category                 @title: '{@i18n>sustCategory1}';
    categoryDescription      @title: '{@i18n>sustCategory1}';
    contributor              @title: '{@i18n>sustContributor1}';
    contributorDescription   @title: '{@i18n>sustContributor1}';
    assesor                  @title: '{@i18n>assessorLabel}';
    approver                 @title: '{@i18n>approverLabel}';
    technologyL2             @title: '{@i18n>technologyLabel}';
    technologyL2Description  @title: '{@i18n>technologyLabel}';
    rcPreFlag                @title: '{@i18n>rcPreFlagLabel}';
    rcPreFlagDescription     @title: '{@i18n>rcPreFlagLabel}';
    applicationL2            @title: '{@i18n>applicationLevelLabel}';
    applicationL2Description @title: '{@i18n>applicationLevelLabel}';
    approvalDate             @title: '{@i18n>lastAssessmentApprovalLabel}';
}

annotate service.AssessmentList with {
    requestName   @title: '{@i18n>requestNameLabel}';
    submitter     @title: '{@i18n>submiterLabel}';
    submitionDate @title: '{@i18n>submitionDateLabel}';
    assesmentType @title: '{@i18n>massSingleAssessmentLabel}';
    status        @title: '{@i18n>statusLabel}';
    sbu           @title: '{@i18n>sbuLabel}';
    assessor      @title: '{@i18n>assessorLabel}';
    approver      @title: '{@i18n>approverLabel}';
    approvalDate  @title: '{@i18n>approvalDateLabel}';
    productType   @title: '{@i18n>productTypeLabel}'
}

annotate service.MassAssessmentItems with {
    product         @title: '{@i18n>productLabel}';
    sustClass       @title: '{@i18n>primaryClassLabel}';
    category1       @title: '{@i18n>sustCategory1}';
    category2       @title: '{@i18n>sustCategory2}';
    category3       @title: '{@i18n>sustCategory3}';
    contributor1    @title: '{@i18n>sustContributor1}';
    contributor2    @title: '{@i18n>sustContributor2}';
    contributor3    @title: '{@i18n>sustContributor3}';
    rcPreFlag       @title: '{@i18n>rcPreFlagLabel}';

}

annotate service.StatusVH with {
    description @title: '{@i18n>statusLabel}';
}

annotate service.AssessmentType with {
    description @title: '{@i18n>massSingleAssessmentLabel}';
}

annotate service.Idh {
    sbu         @(Common: {
        ValueListWithFixedValues,
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'Sbu',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sbu,
                    ValueListProperty: 'sbu'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'sbuDescription'
                }
            ]
        }
    });
    sustClass   @(Common: {
        ValueListWithFixedValues,
        Text           : sustClass,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityClass',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sustClass,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    rcPreFlag   @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'RcPreFlag',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: rcPreFlag,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    category    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityCategory',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: category,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    contributor @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'Contributor',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: contributor,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

}

annotate service.Ib {
    sbu         @(Common: {
        ValueListWithFixedValues,
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'Sbu',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sbu,
                    ValueListProperty: 'sbu'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'sbuDescription'
                }
            ]
        }
    });
    sustClass   @(Common: {
        ValueListWithFixedValues,
        Text           : sustClass,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityClass',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sustClass,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    rcPreFlag   @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'RcPreFlag',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: rcPreFlag,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    category    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityCategory',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: category,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    contributor @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'Contributor',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: contributor,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

}

annotate service.StatusVH with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

annotate service.AssessmentType with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

annotate service.SustainabilityClass with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

annotate service.RcPreFlag with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

annotate service.SustainabilityCategory with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

annotate service.Contributor with {
    code @Common: {
        Text           : description,
        TextArrangement: #TextOnly
    };
}

//annotate service.AssessmentHeader {
annotate service.AssessmentList {
    sbu           @(Common: {
        ValueListWithFixedValues,
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'Sbu',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sbu,
                    ValueListProperty: 'sbu'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'sbuDescription'
                }
            ]
        }
    });
    assesmentType @(Common: {
        ValueListWithFixedValues,
        Text           : status,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'AssessmentType',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: assesmentType,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                }
            ]
        }
    });

    productType   @(Common: {
        ValueListWithFixedValues,
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'ProductType',
            Parameters     : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: productType,
                ValueListProperty: 'type'
            }]
        }
    });

}

annotate service.MassAssessmentItems with @(
    UI.SelectionFields: [
        product,
        sustClass,
        category1,
        category2,
        category3,
        contributor1,
        contributor2,
        contributor3,
        rcPreFlag
    ],

    Capabilities      : {
        SearchRestrictions: {Searchable: false},
        FilterRestrictions: {NonFilterableProperties: [
            'ID',
            'headerId',
            'approbalStatus',
            'rcPreFlagDescription',
            'communicationStatus',
            'virtualAssessment',
            'submitter',
            'assessor',
            'approver',
            'approvalDate',
            'sbu',
            'comment',
            'propagation',
            'externalCommunication',
            'approberComment',
            'realSubstanceName',
            'idhAssessmentOverwrite',
            'productName',
            'technologyL2Key',
            'technologyLevel2',
            'sustainabilityClassCode',
            'existingSustainabilityClass',
            'realSubstanceCode',
            'realSubstanceName',
            'region',
            'applicationLevel2Key',
            'applicationLevel2',
            'lastAssessment',
            'lastSubmitter',
            'lastApprover',
            'productType',
            'status'
        ]}
    }
);

annotate service.MassAssessmentItems {

    sustClass    @(Common: {
        ValueListWithFixedValues,
        Text           : sustClass,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityClass',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: sustClass,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    rcPreFlag    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'RcPreFlag',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: rcPreFlag,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    category1    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityCategory',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: category1,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    contributor1 @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'Contributor',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: contributor1,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    category2    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityCategory',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: category2,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    contributor2 @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'Contributor',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: contributor2,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    category3    @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'SustainabilityCategory',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: category3,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });

    contributor3 @(Common: {
        ValueListWithFixedValues,
        Text           : rcPreFlag,
        TextArrangement: #TextOnly,
        ValueList      : {
            SearchSupported: true,
            CollectionPath : 'Contributor',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: contributor3,
                    ValueListProperty: 'code'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'description'
                },
            ]
        }
    });
};

annotate service.Idh with @(

    UI.HeaderInfo                : {
        TypeName      : 'IDH Finished Goods',
        TypeNamePlural: 'IDH Finished Goods',
    },

    UI.SelectionFields           : [
        sbu,
        materialtNumber,
        materialDescription,
        technologyL2Description,
        applicationL2Description,
        sustClass,
        rcPreFlag
    ],

    UI.SelectionFields #AddNewIdh: [
        sbu,
        materialtNumber,
        materialDescription,
        technologyL2Description,
        applicationL2Description,
        sustClass,
        rcPreFlag
    ],

    UI.LineItem                  : [
        {
            $Type                : 'UI.DataField',
            Value                : sbu,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '8%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : materialtNumber,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '10%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : materialDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '21%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : technologyL2Description,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : applicationL2Description,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : sustClassDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : rcPreFlagDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type            : 'UI.DataField',
            Value            : sbuDescription,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : sustClass,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : applicationL2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : technologyL2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : rcPreFlag,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category2Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category3,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category3Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor2Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor3,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor3Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : HasDraftEntity,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : realSubstanceCode,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : realSubstanceName,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : submitter,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },

    ],
    Capabilities                 : {
        SearchRestrictions: {Searchable: false},
        FilterRestrictions: {
            NonFilterableProperties     : [
                'applicationL2',
                'technologyL2',
                'sustClassDescription',
                'rcPreFlagDescription',
                'sbuDescription',
                'categoryDescription',
                'category2',
                'category2Description',
                'category3',
                'category3Description',
                'contributorDescription',
                'contributor2',
                'contributor2Description',
                'contributor3',
                'contributor3Description',
                'HasDraftEntity',
                'realSubstanceCode',
                'realSubstanceName',
                'submitter'
            ],
            FilterExpressionRestrictions: [{
                Property          : 'approvalDate',
                AllowedExpressions: 'SingleRange'
            }]
        }
    }

);

annotate service.Ib with @(

    UI.HeaderInfo                : {
        TypeName      : 'IB Product Groups',
        TypeNamePlural: 'IB Product Groups',
    },

    UI.SelectionFields           : [
        sbu,
        materialtNumber,
        materialDescription,
        technologyL2Description,
        applicationL2Description,
        sustClass,
        rcPreFlag
    ],

    UI.SelectionFields #AddNewIdh: [
        sbu,
        materialtNumber,
        materialDescription,
        technologyL2Description,
        applicationL2Description,
        sustClass,
        rcPreFlag
    ],

    UI.LineItem                  : [
        {
            $Type                : 'UI.DataField',
            Value                : sbu,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '8%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : materialtNumber,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '10%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : materialDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '21%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : technologyL2Description,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : applicationL2Description,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : sustClassDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : rcPreFlagDescription,
            ![@UI.Importance]    : #High,
            ![@HTML5.CssDefaults]: {width: '16%'}
        },
        {
            $Type            : 'UI.DataField',
            Value            : sbuDescription,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : sustClass,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : applicationL2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : technologyL2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : rcPreFlag,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category2Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category3,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : category3Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor2,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor2Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor3,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : contributor3Description,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : HasDraftEntity,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : realSubstanceCode,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : realSubstanceName,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },
        {
            $Type            : 'UI.DataField',
            Value            : submitter,
            ![@UI.Importance]: #High,
            ![@UI.Hidden]    : true
        },

    ],
    Capabilities                 : {
        SearchRestrictions: {Searchable: false},
        FilterRestrictions: {
            NonFilterableProperties     : [
                'applicationL2',
                'technologyL2',
                'sustClassDescription',
                'rcPreFlagDescription',
                'sbuDescription',
                'categoryDescription',
                'category2',
                'category2Description',
                'category3',
                'category3Description',
                'contributorDescription',
                'contributor2',
                'contributor2Description',
                'contributor3',
                'contributor3Description',
                'HasDraftEntity',
                'realSubstanceCode',
                'realSubstanceName',
                'submitter',
            ],
            FilterExpressionRestrictions: [{
                Property          : 'approvalDate',
                AllowedExpressions: 'SingleRange'
            }]
        }
    }

);

//annotate service.AssessmentHeader with @(

annotate service.AssessmentList with @(

    UI.SelectionFields: [
        sbu,
        requestName,
        assessor,
        submitter,
        submitionDate,
        approver,
        assesmentType,
        status
    ],

    UI.LineItem       : [
        {
            $Type                : 'UI.DataField',
            Value                : sbu,
            ![@HTML5.CssDefaults]: {width: '8%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : requestName,
            ![@HTML5.CssDefaults]: {width: '14%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : assessor,
            ![@HTML5.CssDefaults]: {width: '14%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : submitter,
            ![@HTML5.CssDefaults]: {width: '14%'}

        },
        {
            $Type                : 'UI.DataField',
            Value                : submitionDate,
            ![@HTML5.CssDefaults]: {width: '12%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : approver,
            ![@HTML5.CssDefaults]: {width: '14%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : toAssessmentType.description,
            ![@HTML5.CssDefaults]: {width: '12%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : toStatus.description,
            ![@HTML5.CssDefaults]: {width: '12%'}
        },
        {
            $Type        : 'UI.DataField',
            Value        : ID,
            ![@UI.Hidden]: true
        },
        {
            $Type        : 'UI.DataField',
            Value        : projectId,
            ![@UI.Hidden]: true
        },
        {
            $Type        : 'UI.DataField',
            Value        : statusDescription,
            ![@UI.Hidden]: true
        }

    ],
    Capabilities      : {
        SearchRestrictions: {Searchable: false},
        FilterRestrictions: {
            NonFilterableProperties     : [
                'ID',
                'projectId',
                'statusDescription',
                'communicationStatus',
                'virtualAssessment'
                

            ],
            FilterExpressionRestrictions: [{
                Property          : 'submitionDate',
                AllowedExpressions: 'SingleRange'
            }]
        }
    },
);

/*annotate service.MaterialData with @(

UI.LineItem: [
    {
        $Type: 'UI.DataField',
        Value: material,

    },
    {
        $Type: 'UI.DataField',
        Value: meterialDescription,

    },
    {
        $Type: 'UI.DataField',
        Value: realSubstance,

    },
    {
        $Type: 'UI.DataField',
        Value: realSubstanceName,
    },
    {
        $Type: 'UI.DataField',
        Value: chemicalSubstance,
    },
    {
        $Type: 'UI.DataField',
        Value: chemicalSubstanceName,
    },
    {
        $Type: 'UI.DataField',
        Value: technologyLevel1,
    },
    {
        $Type: 'UI.DataField',
        Value: technologyLevel2,
    }
]

);*/
