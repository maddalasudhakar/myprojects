/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "com/sustainability/support/model/models"
],
    function (UIComponent, Device, models) {
        "use strict";

        return UIComponent.extend("com.sustainability.support.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: function () {
                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");

                let oModel = this.getModel(),
                    oActionODataContextBinding = oModel.bindContext("/GetUserRole(...)");

                oActionODataContextBinding.execute().then(
                    function () {
                        let oActionContext = oActionODataContextBinding.getBoundContext(),
                            oUserParameters = (oActionContext.getObject().value);
                        if (oUserParameters.ViewerPlus) {
                            this.getModel("menuModel").setProperty("/isViewerPlus", true);
                        }
                    }.bind(this)
                );
            }
        });
    }
);