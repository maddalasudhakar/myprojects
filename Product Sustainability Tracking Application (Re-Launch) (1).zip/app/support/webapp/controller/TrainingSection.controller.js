sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
],
    function (BaseController, JSONModel, MessageBox) {
        "use strict";

        return BaseController.extend("com.sustainability.support.controller.TrainingSection", {
            onInit: function () {
                let oViewModel = new JSONModel({
                    editMode: false
                });

                this.setModel(oViewModel, "trainingSectionView");

                this.getRouter().getRoute("TrainingSection").attachPatternMatched(this._onTrainingSectionMatched, this);
            },

            onCancel: function () {
                let oModel = this.getModel(),
                    oViewModel = this.getView().getModel("trainingSectionView");

                if (!oModel.hasPendingChanges()) {
                    oModel.resetChanges();
                    oViewModel.setProperty("/editMode", false);
                } else {
                    MessageBox.confirm(this.getResourceBundle().getText("pendingChangesMessage"), {
                        onClose: function (sAction) {
                            if (sAction === 'OK') {
                                oModel.resetChanges();
                                oViewModel.setProperty("/editMode", false);
                            }
                        }.bind(this)
                    });
                }
            },

            onPressEdit: function () {
                let bEdtiMode = this.getView().getModel("trainingSectionView").getProperty("/editMode");

                if (bEdtiMode) {
                    this.getView().getModel("trainingSectionView").setProperty("/editMode", false);
                } else {
                    this.getView().getModel("trainingSectionView").setProperty("/editMode", true);
                }
            },

            onSave: function () {
                let oDataModel = this.getModel(),
                    oViewModel = this.getView().getModel("trainingSectionView");
                if (oDataModel.hasPendingChanges()) {
                    oDataModel.submitBatch("UpdateGroup")
                        .then(() => {
                            if (!oDataModel.hasPendingChanges()) {
                                MessageBox.success(this.getResourceBundle().getText("saveSuccessMessage"));

                                oViewModel.setProperty("/editMode", false);
                            } else {
                                MessageBox.error(this.getResourceBundle().getText("saveErrorMessage"));
                            }
                        })
                        .catch((oError) => {
                            // handle error
                            MessageBox.error(this.getResourceBundle().getText("saveErrorDetailMessage") + " " + oError.message);

                        });
                } else {
                    MessageBox.information(this.getResourceBundle().getText("noPendingChangesMessage"));
                }
            },

            _onTrainingSectionMatched: function () {
                let oManualForm = this.getView().byId("assessorsAndSubmitters"),
                    sAssessmentSupportPath = "/SupportSection('Traning')";

                oManualForm.bindElement(sAssessmentSupportPath);

            }
        });
    });