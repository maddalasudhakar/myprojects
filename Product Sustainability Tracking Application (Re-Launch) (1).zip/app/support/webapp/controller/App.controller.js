sap.ui.define(
  [
    './BaseController',
    'sap/ui/Device',
  ],
  function (BaseController, Device) {
    "use strict";

    return BaseController.extend("com.sustainability.support.controller.App", {
      onInit: function () {

        this.getRouter().attachRouteMatched(this.onRouteChange.bind(this));

        //this.onSideNavButtonPress();
      },

      onRouteChange: function (oEvent) {
        this.getModel("menuModel").setProperty("/selectedKey", oEvent.getParameter("name"));

        if (Device.system.phone) {
          this.onSideNavButtonPress();
        }
      },

      onSideNavButtonPress: function () {
        var oToolPage = this.byId("app");
        var bSideExpanded = oToolPage.getSideExpanded();
        this._setToggleButtonTooltip(bSideExpanded);
        oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
      },

      onItemSelect: function (oEvent) {
        let sSelectedKey = oEvent.getParameter("item").getProperty("key");
        
        this.getRouter().navTo(sSelectedKey);
      },

      getBundleText: function (sI18nKey, aPlaceholderValues) {
        return this.getResourceBundle().getText(sI18nKey);
      },

      _setToggleButtonTooltip: function (bSideExpanded) {
        var oToggleButton = this.byId('sideNavigationToggleButton');
        /*this.getResourceBundle(bSideExpanded ? "expandMenuButtonText" : "collpaseMenuButtonText").then(function(sTooltipText){
          oToggleButton.setTooltip(sTooltipText);
        });*/
      },

    });
  }
);
