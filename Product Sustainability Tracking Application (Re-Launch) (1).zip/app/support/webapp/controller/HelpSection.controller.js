sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
],
function (BaseController, JSONModel, MessageBox) {
    "use strict";

    return BaseController.extend("com.sustainability.support.controller.HelpSection", {
        onInit: function () {
            let oViewModel = new JSONModel({
                editMode: false
            });

            this.setModel(oViewModel, "helpSectionView");

            this.getRouter().getRoute("HelpSection").attachPatternMatched(this._onHelpSectionMatched, this);

        },

        onCancel: function () {
            let oModel = this.getModel(),
                oViewModel = this.getView().getModel("helpSectionView");

            if (!oModel.hasPendingChanges()) {
                oModel.resetChanges();
                oViewModel.setProperty("/editMode", false);
            } else {
                MessageBox.confirm(this.getResourceBundle().getText("pendingChangesMessage"), {
                    onClose: function (sAction) {
                        if (sAction === 'OK') {
                            oModel.resetChanges();
                            oViewModel.setProperty("/editMode", false);
                        }
                    }.bind(this)
                });
            }
        },

        onPressEdit: function () {
            let bEdtiMode = this.getView().getModel("helpSectionView").getProperty("/editMode");

            if (bEdtiMode) {
                this.getView().getModel("helpSectionView").setProperty("/editMode", false);
            } else {
                this.getView().getModel("helpSectionView").setProperty("/editMode", true);
            }
        },

        onSave: function () {
            let oDataModel = this.getModel(),
                oViewModel = this.getView().getModel("helpSectionView");
            if (oDataModel.hasPendingChanges()) {
                oDataModel.submitBatch("UpdateGroup")
                    .then(() => {
                        if (!oDataModel.hasPendingChanges()) {
                            MessageBox.success(this.getResourceBundle().getText("saveSuccessMessage"));

                            oViewModel.setProperty("/editMode", false);
                        } else {
                            MessageBox.error(this.getResourceBundle().getText("saveErrorMessage"));
                        }
                    })
                    .catch((oError) => {
                        // handle error
                        MessageBox.error(this.getResourceBundle().getText("saveErrorDetailMessage") + " " + oError.message);

                    });
            } else {
                MessageBox.information(this.getResourceBundle().getText("noPendingChangesMessage"));
            }
        },

        _onHelpSectionMatched: function () {
            let oManualForm = this.getView().byId("manual"),
                oGuidanceForm = this.getView().byId("guidance"),
                oPortfolioForm = this.getView().byId("portfolio"),
                oTroubleshootingForm = this.getView().byId("troubleshooting"),
                oTechnicalSupportForm = this.getView().byId("technicalSupport"),
                oAssessmentSupportForm = this.getView().byId("assessmentSupport"),
                oQaForm = this.getView().byId("qa"),
                oFeedbackForm = this.getView().byId("feedback"),
                sManualPath = "/SupportSection('Manual')",
                sGuidancelPath = "/SupportSection('Guidance')",
                sPortfolioPath = "/SupportSection('Portfolio')",
                sTroubleshootingPath = "/SupportSection('Troubleshooting')",
                sTechnicalSupportPath = "/SupportSection('TechnicalSupport')",
                sAssessmentSupportPath = "/SupportSection('AssessmentSupport')",
                sqaPath = "/SupportSection('QA')",
                sFeedbackPath = "/SupportSection('Feedback')";

            oManualForm.bindElement(sManualPath);
            oGuidanceForm.bindElement(sGuidancelPath);
            oPortfolioForm.bindElement(sPortfolioPath);
            oTroubleshootingForm.bindElement(sTroubleshootingPath);
            oTechnicalSupportForm.bindElement(sTechnicalSupportPath);
            oAssessmentSupportForm.bindElement(sAssessmentSupportPath);
            oQaForm.bindElement(sqaPath);
            oFeedbackForm.bindElement(sFeedbackPath);
        }
    });
});
