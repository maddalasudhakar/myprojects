"use strict";
const rulesModel = require("../../srv/JS/rules-model/rules-model");
const assessmentValidations = require("../../srv/JS/assessment-validations");

// jest.mock("../../srv/code/getCarriers");

module.exports = {
    test: function(oTestClass) {
        describe("assessment-validations.js functions check", () =>  {
            const log = oTestClass.cds.test.log();
            const { GET, POST, test, expect } = oTestClass;
            beforeAll(async () => {});
            beforeEach(async () => {
                await test.data.reset();
            });

            // Test 1 create a book
            it("Read rules model file", async () => {
                const getRules = await rulesModel.getRules();
                expect(getRules).to.not.be.empty;
            });            

            it("Check rules model:", async () => {
                const oReturn = await rulesModel.checkRules({});
                expect(oReturn.continue).to.equal(false);
                expect(oReturn.reason).to.equal("No request name provided");

                const oReturn2 = await rulesModel.checkRules({requestName: "test name"});
                expect(oReturn2.continue).to.equal(false);
                expect(oReturn2.reason).to.equal("No approval status provided");             
                
                const oReturn3 = await rulesModel.checkRules({requestName: "test name", approbalStatus: "02", rcPreFlag: "99", sustClass: "70"});
                expect(oReturn3.continue).to.equal(false);
                expect(oReturn3.reason).to.equal("No valid RC Preflag for sustainability Class");            

                const oReturn4 = await rulesModel.checkRules({requestName: "test name", approbalStatus: "02", rcPreFlag: "02", sustClass: "04", toProofDocuments: []});
                expect(oReturn4.continue).to.equal(false);
                expect(oReturn4.reason).to.equal("Field category1 is mandatory");    

                const oReturn5 = await rulesModel.checkRules({requestName: "test name", approbalStatus: "02", rcPreFlag: "02", sustClass: "04", category1: "01", toProofDocuments: []});
                expect(oReturn5.continue).to.equal(false);
                expect(oReturn5.reason).to.equal("Field contributor1 is mandatory when category1 is also provided");   
                
                const oReturn6= await rulesModel.checkRules({requestName: "test name", approbalStatus: "02", rcPreFlag: "02", sustClass: "04", category1: "01", contributor1: "01", toProofDocuments: []});
                expect(oReturn6.continue).to.equal(false);
                expect(oReturn6.reason).to.equal("Error in proofpoints");                    

                const oReturn7 = await rulesModel.checkRules({
                    requestName: "test name", 
                    approbalStatus: "02", 
                    rcPreFlag: "04", 
                    sustClass: "04", 
                    category1: "01", 
                    contributor1: "AA",
                    toProofDocuments: [{fileName: "test", description: "test", type: "01", active: true}]},
                );
                expect(oReturn7.continue).to.equal(false);
                expect(oReturn7.reason).to.equal("Error in proofpoints: Fields do not match sustainability data provided");         
                
                const oReturn8 = await rulesModel.checkRules({
                    requestName: "test name", 
                    approbalStatus: "02", 
                    rcPreFlag: "04", 
                    sustClass: "04", 
                    category1: "01", 
                    contributor1: "WC",
                    toProofDocuments: [{fileName: "test", description: "test", type: "01", active: true, }]},
                );
                expect(oReturn8.reason).to.equal("Missing mandatory field comment");         
                expect(oReturn8.continue).to.equal(false);           
                
                const oReturn9 = await rulesModel.checkRules({
                    requestName: "test name", 
                    approbalStatus: "02", 
                    rcPreFlag: "04", 
                    sustClass: "04", 
                    category1: "01", 
                    contributor1: "WC",
                    comment: "test",
                    toProofDocuments: [{fileName: "test", description: "test", type: "01", active: true, }]},
                );      
                expect(oReturn9.continue).to.equal(true);                
            });       

            it("Check master data assessment validations", async () => {
                const oAssessement = {
                    sbu: "KO",
                    sustClass: "KO",
                    rcPreFlag: "KO",
                    category1: "KO",
                    contributor1: "KO",
                    category2: "KO",
                    contributor2: "KO",
                    category3: "KO",
                    contributor3: "KO",
                };
                const masterData = {
                    sbu: [{code: "ACC"}],
                    rcPreFlag: [{code: "01"}],
                    sustClass: [{code: "01"}],
                    sustainabilityCategory: [{code: "01"}, {code: "02"}, {code: "03"}],
                    contributor: [{code: "01"}, {code: "02"}, {code: "03"}],
                };
                let result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;
                expect(result.reason).to.equal(`SBU ${oAssessement?.sbu} does not exist`);     
                
                oAssessement.sbu = "ACC";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Sustainability class ${oAssessement?.sustClass} does not exist`);         

                oAssessement.sustClass = "01";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`RC Preflag ${oAssessement?.rcPreFlag} does not exist`);     
                
                oAssessement.rcPreFlag = "01";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Category 1 ${oAssessement?.category1} does not exist`);   
                
                oAssessement.category1 = "01";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Contributor 1 ${oAssessement?.contributor1} does not exist`);  
                
                oAssessement.contributor1 = "01";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Category 2 ${oAssessement?.category2} does not exist`);   
                
                oAssessement.category2 = "02";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Contributor 2 ${oAssessement?.contributor2} does not exist`); 
                
                oAssessement.contributor2 = "02";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Category 3 ${oAssessement?.category3} does not exist`);   
                
                oAssessement.category3 = "03";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.false;    
                expect(result.reason).to.equal(`Contributor 3 ${oAssessement?.contributor3} does not exist`);  
                
                oAssessement.contributor3 = "03";
                result = await assessmentValidations.checkAssessmentFieldValues( oAssessement, masterData);
                expect(result.valid).to.be.true;                  
                                
            });

            // // Test 2, retrieve book
            // it("Get book", async () => {
            //     const newBook = {
            //         ID: 999,
            //         title: "Test",
            //         stock: 999
            //     };

            //     await POST("/odata/v4/catalog/Books", newBook);

            //     const response = await GET(`/odata/v4/catalog/Books('${newBook.ID}')`);
            //     expect(response?.data?.ID).toBeTruthy(.ID);
            //     // expect(data?.ID).to.equal(999);
            // });

            // // Test module
            // it("Testing dummy function", async () => {
            //     const result = sum(2, 2);
            //     expect(result).to.equal(4);
            // });


        });
        
    },
}