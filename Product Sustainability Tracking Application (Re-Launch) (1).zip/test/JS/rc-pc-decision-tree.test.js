const { makeRcPcDecisionTree } = require('../../srv/JS/rc-pc-decision-tree.js');

const { ASSESSMENT_STATUS } = require('../../srv/JS/assessment');

const UPDATE_TYPE = {
    DELETED: 'Deleted',
    CHANGE: 'Change',
    NEW: 'New',
    NO_CHANGE: 'No Change', // Possible value but not supported
};

const RC_PC_CATEGORY = 'HS';
const RC_PC_CONTRIBUTOR = 'SA';

/**
 * Utility methods
 */

describe('getBestSustClass', () => {
    const { getBestSustClass } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    it('Should be get best sustainability class', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const bestClass = getBestSustClass(['01', '02', '03'], sustClassMasterdata);

        expect(bestClass).toBe('01');
    });

    it('Should work if only one class is provided', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const bestClass = getBestSustClass(['02'], sustClassMasterdata);

        expect(bestClass).toBe('02');
    });

    it('Should return undefined if no match in master data', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const bestClass = getBestSustClass(['04'], sustClassMasterdata);

        expect(bestClass).toBeUndefined();
    });
});

describe('checkRcPcUpgrade', () => {
    const { checkRcPcUpgrade } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    it('Should return upgrade if provided class is better', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const isUpgrade = checkRcPcUpgrade('01', '02', sustClassMasterdata);

        expect(isUpgrade).toBeTruthy();
    });

    it('Should not return upgrade if provided class is worse', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const isUpgrade = checkRcPcUpgrade('03', '02', sustClassMasterdata);

        expect(isUpgrade).toBeFalsy();
    });

    it('Should not return upgrade if equal', () => {
        /** Masterdata with three levels */
        const sustClassMasterdata = [
            { code: '01', level: 3 },
            { code: '02', level: 2 },
            { code: '03', level: 1 },
        ];

        const isUpgrade = checkRcPcUpgrade('03', '03', sustClassMasterdata);

        expect(isUpgrade).toBeFalsy();
    });
});

describe('checkPositiveContribution', () => {
    const { checkPositiveContribution } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    it('Should return true if has a positive contribution and category in same slot', () => {
        const existingAssessment = {
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
        };

        const hasPositiveContribution = checkPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeTruthy();
    });

    it('Should return true if has several positive contribution and category in same slot', () => {
        const existingAssessment = {
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
            category2: RC_PC_CATEGORY,
            contributor2: RC_PC_CONTRIBUTOR,
            category3: '99',
            contributor3: '99',
        };

        const hasPositiveContribution = checkPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeTruthy();
    });

    it('Should return false if has positive contribution and category in different slot', () => {
        const existingAssessment = {
            category1: RC_PC_CATEGORY,
            contributor1: '99',
            category2: '99',
            contributor2: RC_PC_CONTRIBUTOR,
            category3: '99',
            contributor3: '99',
        };

        const hasPositiveContribution = checkPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeFalsy();
    });

    it('Should return false if does not have positive contribution', () => {
        const existingAssessment = {
            category1: '99',
            contributor1: '99',
        };

        const hasPositiveContribution = checkPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeFalsy();
    });

    it('Should return false if no slots filled', () => {
        const existingAssessment = {};

        const hasPositiveContribution = checkPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeFalsy();
    });
});

describe('checkOnlyPositiveContribution', () => {
    const { checkOnlyPositiveContribution } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    it('Should return true if only positive contributions are provided', () => {
        const existingAssessment = {
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
            category2: RC_PC_CATEGORY,
            contributor2: RC_PC_CONTRIBUTOR,
        };

        const hasPositiveContribution = checkOnlyPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeTruthy();
    });

    it('Should return false if not all are PC', () => {
        const existingAssessment = {
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
            category2: RC_PC_CATEGORY,
            contributor2: RC_PC_CONTRIBUTOR,
            category3: '99',
            contributor3: '99',
        };

        const hasPositiveContribution = checkOnlyPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeFalsy();
    });

    it('Should return false if not any PC', () => {
        const existingAssessment = {
            category1: '99',
            contributor1: '99',
            category2: '99',
            contributor2: '99',
            category3: '99',
            contributor3: '99',
        };

        const hasPositiveContribution = checkOnlyPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeFalsy();
    });

    it('Should return true if not contributors provided', () => {
        const existingAssessment = {};

        const hasPositiveContribution = checkOnlyPositiveContribution(existingAssessment);

        expect(hasPositiveContribution).toBeTruthy();
    });
});

describe('getNonRcPcContributions', () => {
    const { getNonRcPcContributions } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    it('Should remove RC/PC slot and re-indexes remaining ones', () => {
        const assessment = {
            sustClass: '00',
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR, // RC/PC → removed
            category2: 'XX',
            contributor2: 'YY', // kept → becomes slot 1
            category3: 'AA',
            contributor3: 'BB', // kept → becomes slot 2
        };
        const result = getNonRcPcContributions(assessment);

        expect(result).toEqual({
            category1: 'XX',
            contributor1: 'YY',
            category2: 'AA',
            contributor2: 'BB',
        });
    });

    it('Should return all slots when none are RC/PC', () => {
        const assessment = {
            sustClass: 'B',
            category1: 'X1',
            contributor1: 'Y1',
            category2: 'X2',
            contributor2: 'Y2',
        };

        const result = getNonRcPcContributions(assessment);

        expect(result).toEqual({
            category1: 'X1',
            contributor1: 'Y1',
            category2: 'X2',
            contributor2: 'Y2',
        });
    });

    it('Should return an empty object when all slots are RC/PC', () => {
        const assessment = {
            sustClass: 'B',
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
            category2: RC_PC_CATEGORY,
            contributor2: RC_PC_CONTRIBUTOR,
        };

        const result = getNonRcPcContributions(assessment);

        expect(result).toEqual({});
    });

    it('Should return an empty object when no slots are filled', () => {
        expect(getNonRcPcContributions({ sustClass: 'B' })).toEqual({});
    });
});

/**
 * Output methods
 */

describe('buildNewAndUpgradeChangeOutput', () => {
    const { buildNewAndUpgradeChangeOutput } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    const sustClassMasterdata = [
        { code: '01', level: 1 },
        { code: '02', level: 2 },
        { code: '03', level: 3 },
    ];

    it('Should SUBMITTED status', () => {
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: { sustClass: '02' },
            sustClassMasterdata,
        });

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);
    });

    it('Should use the best class between rcPcClass and existing sustClass', () => {
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: { sustClass: '02' },
            sustClassMasterdata,
        });

        expect(result.newSustData.sustClass).toBe('02');
    });

    it('Should add RC/PC contribution to first empty slot when not already present', () => {
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: { sustClass: '02' },
            sustClassMasterdata,
        });

        expect(result.newSustData.category1).toBe(RC_PC_CATEGORY);
        expect(result.newSustData.contributor1).toBe(RC_PC_CONTRIBUTOR);
    });

    it('Should fill slot 2 when slot 1 is already occupied', () => {
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: {
                sustClass: 'C',
                category1: 'XX',
                contributor1: 'YY',
            },
            sustClassMasterdata,
        });

        expect(result.newSustData.category2).toBe(RC_PC_CATEGORY);
        expect(result.newSustData.contributor2).toBe(RC_PC_CONTRIBUTOR);
    });

    it('Should overwrite slot 3 (last) when all slots are occupied and no RC/PC present', () => {
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: {
                sustClass: '02',
                category1: 'X1',
                contributor1: 'Y1',
                category2: 'X2',
                contributor2: 'Y2',
                category3: 'X3',
                contributor3: 'Y3',
            },
            sustClassMasterdata,
        });

        expect(result.newSustData.category3).toBe(RC_PC_CATEGORY);
        expect(result.newSustData.contributor3).toBe(RC_PC_CONTRIBUTOR);

        // slots 1 and 2 are untouched
        expect(result.newSustData.category1).toBe('X1');
        expect(result.newSustData.category2).toBe('X2');
    });

    it('Should not add an extra contribution when RC/PC is already present', () => {
        const existingAssessment = {
            sustClass: '01',
            category1: RC_PC_CATEGORY,
            contributor1: RC_PC_CONTRIBUTOR,
        };
        const result = buildNewAndUpgradeChangeOutput({
            rcPcClass: '02',
            existingAssessment,
            sustClassMasterdata,
        });

        // Slot 2 should NOT be set
        expect(result.newSustData.category2).toBeUndefined();
        expect(result.newSustData.contributor2).toBeUndefined();
    });
});

describe('buildDeleteAndDowngradeChangeOutput', () => {
    const { buildDeleteAndDowngradeChangeOutput } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });
       const sustClassMasterdata = [
        { code: '01', level: 1 }, 
        { code: '02', level: 2 },
        { code: '03', level: 3 },
        { code: '04', level: 4 },
        { code: '20', level: 5 }, 
        { code: '05', level: 6 },
    ];


    it('Should return SAVED and keep non-RC/PC contributions when mixed', () => {
        const result = buildDeleteAndDowngradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: {
                sustClass: '02',
                rcPreFlag: '01',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
                category2: 'XX',
                contributor2: 'YY',
            },
            sustClassMasterdata,
        });

        expect(result.status).toBe(ASSESSMENT_STATUS.SAVED);
        expect(result.newSustData.sustClass).toBe('02');
        expect(result.newSustData.category1).toBe('XX');
        expect(result.newSustData.contributor1).toBe('YY');

        // RC/PC slot removed
        expect(result.newSustData.category2).toBeUndefined();
    });

    it('Should preserve existing sustClass (not rcPcClass) in SAVED case', () => {
        const result = buildDeleteAndDowngradeChangeOutput({
            rcPcClass: '01',
            existingAssessment: {
                sustClass: '02',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
                category2: 'XX',
                contributor2: 'YY',
            },
            sustClassMasterdata,
        });
        expect(result.newSustData.sustClass).toBe('02');
    });

    it('Should return SUBMITTED and use PERFORMER when rcPcClass is better than PERFORMER', () => {
        const result = buildDeleteAndDowngradeChangeOutput({
            rcPcClass: '05', 
            existingAssessment: {
                sustClass: '04',
                rcPreFlag: '05',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
            },
            sustClassMasterdata
        });

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);

      
        expect(result.newSustData).toEqual({
            sustClass: '20',
        });
    });
         it('Should return SUBMITTED and use rcPcClass when rcPcClass is worse than PERFORMER', () => {
        const result = buildDeleteAndDowngradeChangeOutput({
            rcPcClass:'01',
            existingAssessment: {
                rcPreFlag:'01',
                sustClass: '05',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
            },
            sustClassMasterdata
        });

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);

        expect(result.newSustData).toEqual({
            sustClass: '01',
        });
    });
});

/**
 * Handlers
 */

describe('newHandler', () => {
    const { newHandler } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    const sustClassMasterdata = [
        { code: 'CONTRIBUTOR', level: 1 },
        { code: 'PIONEER', level: 2 },
    ];

    it('Should return SUBMITTED and add category and contributor and best class', () => {
        const result = newHandler({
            rcPcClass: 'CONTRIBUTOR',
            existingAssessment: { sustClass: 'PIONEER' },
            sustClassMasterdata,
        });

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);
        expect(result.newSustData.sustClass).toBe('PIONEER');
        expect(result.newSustData.category1).toBe(RC_PC_CATEGORY);
        expect(result.newSustData.contributor1).toBe(RC_PC_CONTRIBUTOR);
    });

    it('Should return SUBMITTED and not add category and contributor and best class', () => {
        const input = {
            rcPcClass: 'PIONEER',
            existingAssessment: {
                sustClass: 'CONTRIBUTOR',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
            },
            sustClassMasterdata,
        };
        const result = newHandler(input);

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);
        expect(result.newSustData.sustClass).toBe('PIONEER');
        expect(result.newSustData.category1).toBe(RC_PC_CATEGORY);
        expect(result.newSustData.contributor1).toBe(RC_PC_CONTRIBUTOR);
        expect(result.newSustData.category2).toBe(undefined);
        expect(result.newSustData.contributor2).toBe(undefined);
    });
});

describe('changeHandler', () => {
    const { changeHandler } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    const sustClassMasterdata = [
        { code: 'CONTRIBUTOR', level: 1 },
        { code: 'PIONEER', level: 2 },
    ];

    it('Should return SUBMITTED, best class and RCPC contribution', () => {
        const input = {
            rcPcClass: 'PIONEER',
            existingAssessment: {
                sustClass: 'CONTRIBUTOR',
                rcPreFlag: 'PIONEER',
                category1: '99',
                contributor1: '99',
            },
            sustClassMasterdata,
        };

        const result = changeHandler(input);

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);
        expect(result.newSustData.sustClass).toBe('PIONEER');
        expect(result.newSustData.contributor1).toBe('99');
        expect(result.newSustData.contributor2).toBe(RC_PC_CONTRIBUTOR);
        expect(result.newSustData.category1).toBe('99');
        expect(result.newSustData.category2).toBe(RC_PC_CATEGORY);
    });

    it('Should return SAVED, existing class and contribution', () => {
        const input = {
            rcPcClass: 'CONTRIBUTOR',
            previousRcPcClass: 'PIONEER',
            existingAssessment: {
                sustClass: 'PIONEER',
                category1: '99',
                contributor1: '99',
            },
            sustClassMasterdata,
        };

        const result = changeHandler(input);

        expect(result.status).toBe(ASSESSMENT_STATUS.SAVED);
        expect(result.newSustData.sustClass).toBe('PIONEER');
        expect(result.newSustData.contributor1).toBe('99');
        expect(result.newSustData.category1).toBe('99');
    });
});

describe('deletedHandler', () => {
    const { deletedHandler } = makeRcPcDecisionTree({
        assessmentStatus: ASSESSMENT_STATUS,
        updateTypes: UPDATE_TYPE,
        rcPcCategory: RC_PC_CATEGORY,
        rcPcContributor: RC_PC_CONTRIBUTOR,
    });

    const sustClassMasterdata = [
        { code: 'CONTRIBUTOR', level: 1 },
        { code: 'PIONEER', level: 2 },
    ];

    it('Should return SUBMITTED, best class and RCPC contribution', () => {
        const input = {
            rcPcClass: 'PIONEER',
            existingAssessment: {
                rcPreFlag: 'PIONEER',                
                sustClass: 'CONTRIBUTOR',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
            },
            sustClassMasterdata,
        };

        const result = deletedHandler(input);

        expect(result.status).toBe(ASSESSMENT_STATUS.SUBMITTED);
        expect(result.newSustData.sustClass).toBe('20');
        expect(result.newSustData.contributor1).toBe(undefined);
        expect(result.newSustData.category1).toBe(undefined);
    });

    it('Should return SUBMITTED, best class and RCPC contribution', () => {
        const input = {
            rcPcClass: 'PIONEER',
            existingAssessment: {
                sustClass: 'CONTRIBUTOR',
                category1: RC_PC_CATEGORY,
                contributor1: RC_PC_CONTRIBUTOR,
                category2: RC_PC_CATEGORY,
                contributor2: RC_PC_CONTRIBUTOR,
                category3: '99',
                contributor3: '99',
            },
            sustClassMasterdata,
        };

        const result = deletedHandler(input);

        expect(result.status).toBe(ASSESSMENT_STATUS.SAVED);
        expect(result.newSustData.sustClass).toBe('CONTRIBUTOR');
        expect(result.newSustData.contributor1).toBe('99');
        expect(result.newSustData.category1).toBe('99');
        expect(result.newSustData.contributor2).toBe(undefined);
        expect(result.newSustData.category2).toBe(undefined);
        expect(result.newSustData.contributor3).toBe(undefined);
        expect(result.newSustData.category3).toBe(undefined);
    });
});
