
const { ASSESSMENT_STATUS, SUSTAINABILITY_CLASS, UPDATE_TYPE_TO_RC_FLAG_HANDLER, getSustainabilityClassMasterData } = require('../../srv/JS/assessment.js');
const heartAssessmentDecisionTree = require('../../srv/JS/heart-assessment-status-decision-tree.js');


describe('Test heart-assessment-decision-tree.js', () => {

    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('rootNode', () => {

        test('rootNode should return false if not using a valid update type', () => {
            const result = heartAssessmentDecisionTree.rootNode({updateType: 'MOCK'});
            expect( result ).toBeFalsy();
        });

        test('rooNode should return false if not a rcPreflag with handler is provided', () => {
            const result = heartAssessmentDecisionTree.rootNode({updateType: 'New', rcPreFlag: '99'});
            expect( result ).toBeFalsy();
        });

        test('rootNode should valid result returned by handler', () => {

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.UNKNOWN
            };

            const testInput = {
                updateType: heartAssessmentDecisionTree.UPDATE_TYPE.NEW,
                rcPreFlag: SUSTAINABILITY_CLASS.UNKNOWN,
            };

            const unknownHandlerMock = jest.fn(() => expectedResult);
            heartAssessmentDecisionTree.UPDATE_TYPE_TO_RC_FLAG_HANDLER[testInput.updateType][testInput.rcPreFlag] = unknownHandlerMock;

            const result = heartAssessmentDecisionTree.rootNode( testInput );

            expect( typeof result ).toBe( 'object' );
            expect( unknownHandlerMock ).toHaveBeenCalled();
            expect( result?.status ).toBe( expectedResult.status );
            expect( result?.sustClass ).toBe( expectedResult.sustClass );
            
        });

    });

    describe('transitionerT1OrUnknownNode', () => {

        test('transitionerT1OrUnknownNode should return SAVED and NEW SC = RCPREFLAG if different from existing', () => {
            
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.TRANSITIONER_T1,
                existingSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
            };

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.TRANSITIONER_T1
            };
                      
            const result = heartAssessmentDecisionTree.transitionerT1OrUnknownNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );

        });


        test('transitionerT1OrUnknownNode should return FALSE if RCPREFLAG = Existing SC', () => {
            
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.UNKNOWN,
                existingSustClass: SUSTAINABILITY_CLASS.UNKNOWN,
            };

            const expectedResult = false;
                      
            const result = heartAssessmentDecisionTree.transitionerT1OrUnknownNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toBe( expectedResult );

        });     
        
    });

    describe('newOrUpdatePerformerT2bOrTransistionerT2aNode', () => {

        test('should return SAVED and NEW SC = RCPREFLAG if different from existing and no L3 exemption' , () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                existingSustClass: SUSTAINABILITY_CLASS.UNKNOWN,
                proofDocuments: [],
            };

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER_T2B
            };
                      
            const result = heartAssessmentDecisionTree.newOrUpdatePerformerT2bOrTransistionerT2aNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );            

        });

        test('should return FALSE if no change in SC and no L3 exemption' , () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.TRANSITIONER_T2A,
                existingSustClass: SUSTAINABILITY_CLASS.TRANSITIONER_T2A,
                proofDocuments: [],
            };

            const expectedResult = false;
                      
            const result = heartAssessmentDecisionTree.newOrUpdatePerformerT2bOrTransistionerT2aNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toBe( expectedResult );            

        });    
        
        test("should return SUBMITTED CONTRIBUTOR if PIONEER SC and L3 exemption and one C2G contributor", () => {
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                existingSustClass: SUSTAINABILITY_CLASS.PIONEER,
                heartSustClass: SUSTAINABILITY_CLASS.PIONEER,
                contributor1: 'DUMMY',
                contributor2: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED,
                sustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
            };

            const result = heartAssessmentDecisionTree.newOrUpdatePerformerT2bOrTransistionerT2aNode(input);

            expect(typeof result).toBe(typeof expectedResult);
            expect(result).toMatchObject(expectedResult);
        });  
        
        test('should return SAVED PERFORMER if PIONEER SC and L3 exemption and NO C2G contributor' , () => {
            
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                existingSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: 'DUMMY',
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                      
            const result = heartAssessmentDecisionTree.newOrUpdatePerformerT2bOrTransistionerT2aNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );               

        });          

    })

    describe('newOrUpdateContributorNode', () => {

        test('should return SUBMITTED PERFORMER if, HEART and SC PERFORMER no downgrade and no C2G', () => {
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                existingSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: 'DUMMY',
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                   
            const result = heartAssessmentDecisionTree.newOrUpdateContributorNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );                  
        });

        test('should return SAVED CONTRIBUTOR if, HEART CONTRIBUTOR, downgrade and C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                existingSustClass: SUSTAINABILITY_CLASS.PIONEER,
                heartSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR
            };
                   
            const result = heartAssessmentDecisionTree.newOrUpdateContributorNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });        

    });

    describe('newOrUpdatePioneerNode', () => {

        test('should return SAVED PIONEER if, SC PIONEER, downgrade and C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PIONEER,
                existingSustClass: SUSTAINABILITY_CLASS.PIONEER,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.PIONEER
            };
                   
            const result = heartAssessmentDecisionTree.newOrUpdatePioneerNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });     

        test('should return SUBMITTED PERFORMER if, SC PERFORMER, downgrade and C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PIONEER,
                existingSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                   
            const result = heartAssessmentDecisionTree.newOrUpdatePioneerNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });           

    });

    describe('deletedPerformerT2bOrTransistionerT2aNode', () => {

        test('should return SAVED and NEW SC = RCPREFLAG if different from existing and no L3 exemption' , () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                existingSustClass: SUSTAINABILITY_CLASS.UNKNOWN,
                proofDocuments: [],
            };

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER_T2B
            };
                      
            const result = heartAssessmentDecisionTree.deletedPerformerT2bOrTransistionerT2aNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );            

        });

        test('should return SUBMITTED and NEW SC = PERFORMER if different from existing and L3 exemption' , () => {
            
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                existingSustClass: SUSTAINABILITY_CLASS.PERFORMER_T2B,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: 'DUMMY',
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                      
            const result = heartAssessmentDecisionTree.deletedPerformerT2bOrTransistionerT2aNode(input)
            
            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );            

        });       

    });

    describe('deletedContributorNode', () => {

        test('should return PERFORMER SUBMITTED if CONTRIBUTOR and ONLY C2G', () => {
            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                existingSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                heartSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                contributor1: 'DUMMY',
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR
            };
                   
            const result = heartAssessmentDecisionTree.deletedContributorNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );                  
        });

        test('should return SAVED PERFORMER if, HEART CONTRIBUTOR, downgrade and C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                existingSustClass: SUSTAINABILITY_CLASS.PIONEER,
                heartSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                   
            const result = heartAssessmentDecisionTree.deletedContributorNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });        

    });

    describe('deletedPioneerNode', () => {

        test('should return SUBMITTED PERFORMER if SC PERFORMER and not only C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PIONEER,
                existingSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                heartSustClass: SUSTAINABILITY_CLASS.PERFORMER,
                contributor1: 'DUMMY',
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SUBMITTED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                   
            const result = heartAssessmentDecisionTree.deletedPioneerNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });     

        test('should return SAVED PERFORMER if SC CONTRIBUTOR and C2G', () => {

            const input = {
                rcPreFlag: SUSTAINABILITY_CLASS.PIONEER,
                existingSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                heartSustClass: SUSTAINABILITY_CLASS.CONTRIBUTOR,
                contributor1: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                contributor2: heartAssessmentDecisionTree.CONTRIBUTOR_CRADLE_TO_GATE,
                proofDocuments: [{
                    type: heartAssessmentDecisionTree.EXEMPTION_L3_DOCUMENT, active: true
                }],
                sustClassMasterdata: [
                    {code: SUSTAINABILITY_CLASS.PIONEER, level: 3},
                    {code: SUSTAINABILITY_CLASS.CONTRIBUTOR, level: 2},
                    {code: SUSTAINABILITY_CLASS.PERFORMER, level: 1}
                ]
            };            

            const expectedResult = {
                status: ASSESSMENT_STATUS.SAVED, 
                sustClass: SUSTAINABILITY_CLASS.PERFORMER
            };
                   
            const result = heartAssessmentDecisionTree.deletedPioneerNode(input);

            expect( typeof result ).toBe( typeof expectedResult );
            expect( result ).toMatchObject( expectedResult );           

        });           

    });

});
