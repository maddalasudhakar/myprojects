const { makeRcPcAssessment } = require('../../srv/JS/rc-pc-assessment.js'); // Update with actual path

describe('makeRcPcAssessment Module', () => {
    let rcPcAssessment;
    let mocks;

    beforeEach(() => {
        // 1. Setup Mocks for all injected dependencies
        mocks = {
            rcPcRepository: {
                getProductData: jest.fn(),
                updateMaterialLogStatus: jest.fn(),
                getRequestNamesByPattern: jest.fn(),
            },
            decisionTree: {
                rootNode: jest.fn(),
            },
            assessmentValidations: {
                clearInvalidSustainabilityFieldsForItem: jest.fn(),
                checkAssessmentFieldValues: jest.fn(),
                getAssessmentFieldMasterData: jest.fn(),
            },
            assessment: {
                ASSESSMENT_PROCESS: { RC_POSITIVE_CONTRIBUTION: 'RC_PC' },
                ASSESSMENT_STATUS: { SAVED: '01', SUBMITTED: '02' },
                PRODUCT_TYPE: { IDH: 'IDH' },
                ASSESSMENT_TYPE: { MASS: 'MASS' },
                getSustainabilityClassMasterData: jest.fn(),
                getProductProofDocuments: jest.fn(),
                getRelatedIbProofDocuments: jest.fn(),
                createAssessmentHeaders: jest.fn(),
                createAssessmentItems: jest.fn(),
                createProofDocuments: jest.fn(),
            },
            checkProductsInAssessment: jest.fn(),
            rulesModel: {
                getRules: jest.fn(),
                checkRules: jest.fn(),
            },
            getUuid: jest.fn(() => 'mocked-uuid'),
        };

        // 2. Instantiate the module with mocks
        rcPcAssessment = makeRcPcAssessment(mocks);

        // 3. Mock system date to ensure predictable request names
        jest.useFakeTimers().setSystemTime(new Date('2024-05-15T12:00:00Z'));
    });

    afterEach(() => {
        jest.useRealTimers();
        jest.clearAllMocks();
    });

    describe('getProductData', () => {
        it('should successfully retrieve product data', async () => {
            const mockData = [{ material: 'MAT-01' }];
            mocks.rcPcRepository.getProductData.mockResolvedValue(mockData);

            const result = await rcPcAssessment.getProductData(
                'SBU1',
                ['MAT-01'],
                'PENDING',
                'RUN-123',
            );

            expect(mocks.rcPcRepository.getProductData).toHaveBeenCalledWith(
                'SBU1',
                ['MAT-01'],
                'PENDING',
                'RUN-123',
            );
            expect(result).toEqual(mockData);
        });

        it('should throw an error if sbu or products are invalid', async () => {
            await expect(
                rcPcAssessment.getProductData(null, ['MAT-01'], 'PENDING', 'RUN-123'),
            ).rejects.toThrow('Invalid parameters: sbu and non-empty products array are required');

            await expect(
                rcPcAssessment.getProductData('SBU1', [], 'PENDING', 'RUN-123'),
            ).rejects.toThrow('Invalid parameters: sbu and non-empty products array are required');
        });

        it('should throw an error if status or runId are missing', async () => {
            await expect(
                rcPcAssessment.getProductData('SBU1', ['MAT-01'], null, 'RUN-123'),
            ).rejects.toThrow('Invalid parameters: status and runId are required');
        });
    });

    describe('checkValidProducts', () => {
        it('should separate valid products from those with blocking assessments', async () => {
            const products = ['MAT-01', 'MAT-02', 'MAT-03'];
            const blockingData = [{ product: 'MAT-02', id: 'ASSESS-1' }];

            mocks.checkProductsInAssessment.mockResolvedValue(blockingData);

            const result = await rcPcAssessment.checkValidProducts(products);

            expect(mocks.checkProductsInAssessment).toHaveBeenCalledWith(products);
            expect(result.validProducts).toEqual(['MAT-01', 'MAT-03']);
            expect(result.invalidProducts).toHaveLength(1);
            expect(result.invalidProducts[0]).toEqual({
                product: 'MAT-02',
                blockingAssessment: blockingData[0],
                reason: 'Ongoing assessment',
            });
        });

        it('should return all products as valid if there are no blocking assessments', async () => {
            const products = ['MAT-01', 'MAT-02'];
            mocks.checkProductsInAssessment.mockResolvedValue([]);

            const result = await rcPcAssessment.checkValidProducts(products);

            expect(result.validProducts).toEqual(products);
            expect(result.invalidProducts).toEqual([]);
        });
    });

    describe('getStatusAndSustData', () => {
        it('should call decisionTree.rootNode with correct parameters', () => {
            const params = {
                updateType: 'UPDATE',
                rcPcClass: 'A',
                existingAssessment: { sustClass: 'B' },
                sustClassMasterdata: [],
            };

            const mockTreeResult = { status: '02', newSustData: { sustClass: 'A' } };
            mocks.decisionTree.rootNode.mockReturnValue(mockTreeResult);

            const result = rcPcAssessment.getStatusAndSustData(params);

            expect(mocks.decisionTree.rootNode).toHaveBeenCalledWith(params);
            expect(result).toEqual(mockTreeResult);
        });
    });

    describe('getNextNumberForStatus', () => {
        it('should return the next sequential number based on existing headers', () => {
            const existingHeaders = [
                { requestName: 'RC Positive Contribution_SBU1_24.05.15_SAVED-1' },
                { requestName: 'RC Positive Contribution_SBU1_24.05.15_SAVED-4' },
                { requestName: 'RC Positive Contribution_SBU1_24.05.15_SUBMITTED-2' },
            ];

            // Test for SAVED ('01')
            const nextSaved = rcPcAssessment.getNextNumberForStatus('01', existingHeaders);
            expect(nextSaved).toBe(5); // 4 + 1

            // Test for SUBMITTED ('02')
            const nextSubmitted = rcPcAssessment.getNextNumberForStatus('02', existingHeaders);
            expect(nextSubmitted).toBe(3); // 2 + 1
        });

        it('should return 1 if no matching headers exist', () => {
            const nextNumber = rcPcAssessment.getNextNumberForStatus('01', []);
            expect(nextNumber).toBe(1);
        });
    });

    describe('checkAndClearAssessmentSustainabilityData', () => {
        it('should validate items and handle sustainability errors', async () => {
            const header = { requestName: 'REQ-1', status: '02' };
            const items = [{ product: 'MAT-01', category1: 'BAD_CAT' }];
            const oMasterData = { contributor: {} };
            const oRules = {};

            // Mock rule check failing with a sustainability error
            mocks.rulesModel.checkRules.mockResolvedValue({
                continue: false,
                hasSustainabilityError: true,
                reason: 'Invalid category',
            });

            const result = await rcPcAssessment.checkAndClearAssessmentSustainabilityData(
                { header, items },
                oMasterData,
                oRules,
            );

            expect(
                mocks.assessmentValidations.clearInvalidSustainabilityFieldsForItem,
            ).toHaveBeenCalledWith(
                expect.objectContaining({ product: 'MAT-01' }),
                oMasterData.contributor,
                oRules,
            );

            expect(result.isValid).toBe(false);
            expect(result.productsToSave).toEqual(['MAT-01']);
            expect(result.reasons).toEqual(['Product MAT-01: Invalid category']);
        });

        it('should validate fields against masterdata if rules pass', async () => {
            const header = { requestName: 'REQ-1', status: '02' };
            const items = [{ product: 'MAT-01' }];
            const oMasterData = {};
            const oRules = {};

            mocks.rulesModel.checkRules.mockResolvedValue({ continue: true });

            // Mock masterdata check failing
            mocks.assessmentValidations.checkAssessmentFieldValues.mockResolvedValue({
                valid: false,
                reason: 'Value not in master data',
            });

            const result = await rcPcAssessment.checkAndClearAssessmentSustainabilityData(
                { header, items },
                oMasterData,
                oRules,
            );

            expect(result.isValid).toBe(false);
            expect(result.reasons).toEqual(['Product MAT-01: Value not in master data']);
        });
    });

    describe('createAssessments', () => {
        it('should flatten structure and call repository creation methods', async () => {
            const mockAssessments = [
                {
                    header: { ID: 'H1' },
                    items: [
                        { ID: 'I1', toProofDocuments: [{ ID: 'D1' }] },
                        { ID: 'I2', toProofDocuments: [{ ID: 'D2' }] },
                    ],
                },
            ];

            await rcPcAssessment.createAssessments(mockAssessments);

            expect(mocks.assessment.createAssessmentHeaders).toHaveBeenCalledWith([{ ID: 'H1' }]);

            // Should pass items with toProofDocuments removed
            expect(mocks.assessment.createAssessmentItems).toHaveBeenCalledWith([
                { ID: 'I1' },
                { ID: 'I2' },
            ]);

            expect(mocks.assessment.createProofDocuments).toHaveBeenCalledWith([
                { ID: 'D1' },
                { ID: 'D2' },
            ]);
        });
    });
});
