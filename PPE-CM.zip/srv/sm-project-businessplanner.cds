using {Apo as Apos} from './external/Apo.csn';

using {
    v_idhProjectPlantSalesInfo
} from '../db/views';


service BusinessPlannerService @(path: '/ppe/cm/businessplanner') @(requires: 'authenticated-user') {

    @cds.persistence.skip
    @readonly
    entity PastForecast   as
        projection on Apos.GetData_ApoDp {
            key ''         as nodeId         : String(50),
                ''         as parentNodeId   : String(50),
                0          as hierarchyLevel : Integer,
                'expanded' as drillState     : String(20),
                ''         as level          : String(100),
                0          as month1         : Decimal(16, 3),
                0          as month2         : Decimal(16, 3),
                0          as month3         : Decimal(16, 3),
                0          as month4         : Decimal(16, 3),
                *
        };

    @cds.persistence.skip
    @readonly
    entity FutureForecast as
        projection on Apos.GetData_ApoDp {
            key ''         as nodeId         : String(50),
                ''         as parentNodeId   : String(50),
                0          as hierarchyLevel : Integer,
                'expanded' as drillState     : String(20),
                ''         as level          : String(100),
                0          as month1         : Decimal(16, 3),
                0          as month2         : Decimal(16, 3),
                0          as month3         : Decimal(16, 3),
                0          as month4         : Decimal(16, 3),
                0          as month5         : Decimal(16, 3),
                0          as month6         : Decimal(16, 3),
                0          as month7         : Decimal(16, 3),
                0          as month8         : Decimal(16, 3),
                0          as month9         : Decimal(16, 3),
                0          as month10        : Decimal(16, 3),
                0          as month11        : Decimal(16, 3),
                0          as month12        : Decimal(16, 3),
                *
        };
    @readonly
    entity IdhProjectPlantSalesInfo as projection on  v_idhProjectPlantSalesInfo{
        key material,
        key uuid,
        key salesCountry,
        key regionScope,
        key plant,
        *
    };
    @restrict: [{
         grant: [
             'CREATE',
             'READ'
         ],
         to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
     }]     
    action getSPPhaseOutDate(projectId : String(20), material: String(18))        returns String;
    @restrict: [{
         grant: [
             'CREATE',
             'READ'
         ],
         to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
     }]
    action getSubstMat(projectID : String, material : String) returns String;
};
