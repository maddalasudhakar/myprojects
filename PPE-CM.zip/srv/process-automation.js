const cds = require("@sap/cds");
const { SELECT, INSERT, UPDATE} = cds.ql;

module.exports = cds.service.impl(async function () {
    const { WorkFlowLogs } = cds.entities('ProcessAutomation');
     
    this.before('*', async (req) => {
        if (req.event === 'DELETE')
            req.reject(406, "Not accepted");

        if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
            const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
            const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
            let payload = JSON.stringify(req.data);

            sBlacklistExactTokens.forEach((token) => {
                const regex = new RegExp(`\\b${token}\\b`);
                if (payload.toLowerCase().match(regex))
                    req.reject(406, "Not accepted");
            });
            sBlacklistIncludeTokens.forEach((token) => {
                if (payload.toLowerCase().includes(token))
                    req.reject(406, "Not accepted");
            });

            Object.keys(req.data).forEach((key) => {
                if(key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")){

                    // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                    if (!emailRegex.test(req.data[key])) 
                        req.reject(406, "Not accepted - Invalid email format");
                }
            });
        }
    });

    this.on("getY4Readiness", async (req) => {
        const material = req.data.material;
        const plant = req.data.plant;
        const { ProjectIDHPlants } = cds.entities('ComplexityManagement');

        if (!material || !plant)
            return req.reject(400, 'Required Input data is missing.');

        const ready = "Yes";
        const notReady = "No";

        const plants = await SELECT.from(ProjectIDHPlants).where({ material: material, plant: plant, phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] } });
        source = plants[0].sourceSystem;

        // read open purchase orders
        if (source === "92") {
            var openPOApi = await cds.connect.to("OpenPO");
        } else {
            var openPOApi = await cds.connect.to("APAC_OpenPO");
        }
        const openPOQuery = SELECT.from('OpenPO')
            .where({ Material: material, Werks: plant });

        let openPOData = await openPOApi.run(openPOQuery);

        // read open process orders
        if (source === "92") {
            var openProcessOApi = await cds.connect.to("OpenProcessOrders");
        } else {
            var openProcessOApi = await cds.connect.to("APAC_OpenProcessOrders");
        }
        const openProcessOQuery = SELECT.from('ProcessOrd')
            .where({ Material: material, Prodplant: plant });

        let openProcessOData = await openProcessOApi.run(openProcessOQuery);

        if ((openPOData.length == 0 || openPOData[0].QuantityBuom == "              0.000")
            && (openProcessOData.length == 0 || openProcessOData[0].TargetQty == 0)) {
            return ready;
        }
        else {
            return notReady;
        };
    });

    this.on("getY5Readiness", async (req) => {
        const material = req.data.material;
        const plant = req.data.plant;
        const { MatPlants } = cds.entities('ComplexityManagement');

        if (!material || !plant)
            return req.reject(400, 'Required Input data is missing.');

        const ready = "Yes";
        const notReady = "No";

        // determine source
        const plants = await SELECT.from(MatPlants).where({ matnr: material, werks: plant });
        const source = plants[0].source_system;

        if (source === "92") {
            var mardApi = await cds.connect.to("MatStocks");
        } else {
            var mardApi = await cds.connect.to("APAC_MatStocks");
        }

        // read data from odata
        const mardQuery = SELECT.from('stock_cal')
            .where({ Material: material, Plant: plant });
        let mardData = await mardApi.run(mardQuery);

        //  If NO stock exists for that IDH (OR) if stock exists only in Storage Location 9002, then it is Y5 ready

        if (!mardData || mardData.length == 0) {
            return ready;
        };
        if (mardData[0].Y5Ready) {
            return ready;
        } else {
            return notReady;
        };
    });

    this.on("checkSaleableInventoryVsFixedIssues", async (req) => {
        const material = req.data.material;
        const plant = req.data.plant;
        const { MatPlants } = cds.entities('ComplexityManagement');

        if (!material || !plant)
            return req.reject(400, 'Required Input data is missing.');

        let mardApi = null;

        // determine source
        const plants = await SELECT.from(MatPlants).where({ matnr: material, werks: plant });
        const source = plants[0].source_system;

        if (source === "92") {
            mardApi = await cds.connect.to("MatStocks");
        } else {
            mardApi = await cds.connect.to("APAC_MatStocks");
        }

        // read data from odata
        let stockInfo = await mardApi.run(SELECT.from('stock_cal')
            .where({ Material: material, Plant: plant }));

        if (stockInfo.length > 0) {
            if (stockInfo[0].TsiQuant >= stockInfo[0].FixedIssues)
                return "Yes";
            else
                return "No";
        } else
            return "No";
    });

    this.on("getForecastExists", async (req) => {
        const material = req.data.material;
        const projectUuid = req.data.projectUuid;
        const fasttrack = req.data.fasttrack;
        
        let result = "", aFinalDp = [];

        // fetch regions from the project
        const { ProjectIDHs } = cds.entities('ComplexityManagement');

        let idhRegionScopes = await SELECT.from(ProjectIDHs).columns(`uuid`, `regionScope`).where({
            l_ev_uuid: projectUuid,
            material: material,
            phaseOutNEEDED: true
        });
        let aRegionScope = idhRegionScopes.map(regionScope => `Region eq '${regionScope.regionScope}'`);
        let sRegionFilter = aRegionScope.join(" or ");

        let sFilter = `Material eq '${material}' and (${sRegionFilter})`;

        // Step 2: Fetch demand planners based on sales country
        const apoDemandPlannerApi = await cds.connect.to("ApoDp");
        let aDemandPlanners = await apoDemandPlannerApi.get(`/DpData?$filter=${sFilter}`);

        if (aDemandPlanners.length === 0) return "";

       
        aDemandPlanners.forEach(demandPlanner => {
            if (!aFinalDp.includes(demandPlanner.DemandPlanner)) {
                aFinalDp.push(demandPlanner.DemandPlanner);

                if (result !== "")
                    result += `;${demandPlanner.DemandPlanner}|${demandPlanner.Email}`;
                else
                    result = `${demandPlanner.DemandPlanner}|${demandPlanner.Email}`;
            }
        });

        // Update cluster 4 in APO
        let data = ``, flagApo = false, aFinalResponse = [], reasonCode = ``;

        let uniqueRegionScopes = Array.from(
            new Map(
                idhRegionScopes.map(obj => [obj.regionScope, { regionScope: obj.regionScope }])
            ).values()
        );

        if (fasttrack)
            reasonCode = "RC1";
        else
            reasonCode = "RC2";


        for await (let uniqueRegion of uniqueRegionScopes) {
            data += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST EncCluster HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"Material": "${material}", "Region": "${uniqueRegion.regionScope}", "Cluster": "4", "ReasonCode": "${reasonCode}"}\r\n\r\n\r\n`;
            flagApo = true;
        }

        data = data + `--batch--`;

        if (flagApo) {
            const apoApi = await cds.connect.to("ApoDp");
            let sStatusUpdateResult = await apoApi.send({
                method: 'POST',
                path: '/$batch',
                headers: {
                    'Content-Type': 'multipart/mixed;boundary=batch'
                },
                data: data
            });

            // batch response needs to be decoded to identify individual one's
            // so use regex to find out JSON outputs from the total batch response
            let regex = /\{.*\}/g,
                oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

            // use JSON parse to parse the string to JSON
            for await (let response of oEachResponseIterator) {
                aFinalResponse.push(JSON.parse(response[0]));
            }
        }

        return result;
    });
    
    this.on("checkCompUsage", async (req) => {
        const material = req.data.material;
        const projectID = req.data.projectID;
        const projectUuid = req.data.projectUuid;
        const { ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');
        const { CompUsageJobInfo, CompUsage } = cds.entities('ppe.cm.md');

        const regular = "Regular";
        const fasttrack = "Fasttrack";
        const calculated = "To be Calculated";
        const actSAInactivePL = "ActSAInactivePL";

        const projectIDHPOS = await SELECT.from(ProjectIDHs).where({ material: material, l_ev_uuid: projectUuid, phaseOutScenario: actSAInactivePL });
        if (projectIDHPOS.length > 0) {
            return actSAInactivePL;
        }
        const plants = await SELECT.from(ProjectIDHPlants).where({ material: material, l_ev_uuid: projectUuid });
        const bAtleastOneYes = plants.some(item => item.openTransaction === "Yes");

        let aPlantsToUpdate = [];

        if (!bAtleastOneYes) {
            const records = await SELECT.from(CompUsageJobInfo).where({ projectID: projectID });
            if (records.length === 0)
                return calculated;

            let jobStatus = records[0].jobStatus;
            //If job is completed
            if (jobStatus === "Completed") {
                const aExclusiveComps = await SELECT.from(CompUsage).where({ fg_idh: material, projectID: projectID, unique: true });

                if (aExclusiveComps.length === 0){
                     await UPDATE(ProjectIDHs).with(
                        {
                            phaseOutScenario: fasttrack
                        }
                    ).where({
                        material: material,
                        l_ev_uuid: projectUuid
                    });
                    return fasttrack;
                }
                   

                let b92Flag = false, b93Flag = false;
                if (plants.some(item => item.sourceSystem === "92"))
                    b92Flag = true;

                if (plants.some(item => item.sourceSystem === "93"))
                    b93Flag = true;

                let aggregateResults = 0;

                if (b92Flag) {
                    const MatStocksApi = await cds.connect.to("MatStocks");
                    const { stock_cal } = MatStocksApi.entities;

                    for (const { plant, component_id } of aExclusiveComps) {

                        // best practice to send one batch call instead of multiple calls to SAP
                        // check with backend team to implement this one
                        // // Build stock request
                        // const stockRequest = `GET stock_cal?$filter%3DMaterial%20eq%20%27${component_id}%27%20and%20Plant%20eq%20%27${plant}%27 HTTP/1.1`;
                        // stocksRequests.push(stockRequest);
                        let results = await MatStocksApi.run(SELECT.from(stock_cal).where({
                            Material: component_id,
                            Plant: plant
                        }));

                        if (results.length > 0) {
                            if (results[0].TsiQuant > 0) {
                                aPlantsToUpdate.push(plant);
                            }
                            aggregateResults += results[0].TsiQuant;
                        }
                    }
                }

                if (b93Flag) {
                    const MatStocksApi = await cds.connect.to("APAC_MatStocks");

                    const { stock_cal } = MatStocksApi.entities;

                    for (const { plant, component_id } of aExclusiveComps) {

                        // best practice to send one batch call instead of multiple calls to SAP
                        // check with backend team to implement this one
                        // // Build stock request
                        // const stockRequest = `GET stock_cal?$filter%3DMaterial%20eq%20%27${component_id}%27%20and%20Plant%20eq%20%27${plant}%27 HTTP/1.1`;
                        // stocksRequests.push(stockRequest);
                        let results = await MatStocksApi.run(SELECT.from(stock_cal).where({
                            Material: component_id,
                            Plant: plant
                        }));

                        if (results.length > 0) {
                            if (results[0].TsiQuant > 0) {
                                aPlantsToUpdate.push(plant);
                            }
                            aggregateResults += results[0].TsiQuant;
                        }
                    }
                }

                if (aggregateResults === 0) {
                    await UPDATE(ProjectIDHs).with(
                        {
                            phaseOutScenario: fasttrack
                        }
                    ).where({
                        material: material,
                        l_ev_uuid: projectUuid
                    });
                    return fasttrack;
                } else {
                    await UPDATE(ProjectIDHs).with(
                        {
                            phaseOutScenario: regular
                        }
                    ).where({
                        material: material,
                        l_ev_uuid: projectUuid
                    });

                    await UPDATE(ProjectIDHPlants).with(
                        {
                            openTransaction: "Yes"
                        }).where({
                            material: material,
                            plant: {
                                in: aPlantsToUpdate
                            },
                            l_ev_uuid: projectUuid
                        });
                    return regular;

                }

            } else {
                return calculated;
            }
        } else {
            await UPDATE(ProjectIDHs).with(
                {
                    phaseOutScenario: regular
                }
            ).where({
                material: material,
                l_ev_uuid: projectUuid
            });
            return regular;
        }

    });

    this.on("getEmailAddress", async (req) => {
        const projectID = req.data.projectID;
        const material = req.data.material;
        const { CompUsage, AllMatTypePlants } = cds.entities('ppe.cm.md');
        const compusageResults = await SELECT.columns(["component_id", "plant"]).from(CompUsage).where({ projectID: projectID, fg_idh: material, unique: true });
        let allMatTypePlantsResults, result = "", componentIdString = "";
        if (compusageResults.length > 0) {
            allMatTypePlantsResults = await SELECT.columns(["matnr", "werks", "source_system", "dispo"]).from(AllMatTypePlants).where({
                matnr: {
                    "in": compusageResults?.map(item => item.component_id)
                },
                werks: {
                    "in": compusageResults?.map(item => item.plant)
                }
            });
            result = await getEmailAddressController(allMatTypePlantsResults);
        }
        if (compusageResults.length > 0) {
            let commponentIDResults = [];
            for (const element of compusageResults) {
                commponentIDResults.push(element.component_id);
            };
            componentIdString = commponentIDResults.join();
        }
        if (result !== "") {
            return result + "||" + componentIdString;
        } else {
            result = "mukund.anandatheerthan@henkel.com" + "||" + componentIdString;
            return result;
        }
    });

    this.on("getCsxMail", async (req) => {

        const material = req.data.material;
        const projectUUID = req.data.projectUuid;
        const { ProjectIDHPlants } = cds.entities('ComplexityManagement');
        var result;
        if (!material)
            return req.reject(400, 'Required Input data is missing.');

        let projectIDHPlant_CONFDATE = await SELECT.columns(["uuid", "l_ev_uuid", "confDatePerRegion"]).from(ProjectIDHPlants).where({ l_ev_uuid: projectUUID, material: material });

        if (projectIDHPlant_CONFDATE.length > 0) {
            let latest_date = projectIDHPlant_CONFDATE.reduce((latestItem, currentItem) => {
                return new Date(currentItem.confDatePerRegion) > new Date(latestItem.confDatePerRegion) ? currentItem : latestItem;
            });
            result = latest_date.confDatePerRegion;
            // return result;
        }

        let idhPlants = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`, `material`, `plant`, `sourceSystem`).where({ material: material, phaseOutNEEDED: 'Yes', phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] } });

        let data92 = ``, data93 = ``, data92flag = false, data93flag = false, oJobStatus = {};

        for await (let idhPlant of idhPlants) {
            if (idhPlant.sourceSystem === '92') {
                data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET OpenSO4Csx?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27%20 HTTP/1.1\r\n\r\n\r\n`;
                data92flag = true;
            } else {
                data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET OpenSO4Csx?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27%20 HTTP/1.1\r\n\r\n\r\n`;
                data93flag = true;
            }
        }

        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        let openSOData = [];

        const aPromises = [];

        if (data92flag) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const openSoApi = await cds.connect.to("OpenSO");
                try {
                    const response = await openSoApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data92
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        if (data93flag) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const openSo93Api = await cds.connect.to("APAC_OpenSO");
                try {
                    const response = await openSo93Api.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data93
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        await Promise.allSettled(aPromises).then(async (aResponses) => {
            for (let response of aResponses) {

                if (response.status === 'fulfilled') {
                    // batch response needs to be decoded to identify individual one's
                    // so use regex to find out JSON outputs from the total batch response
                    let regex = /\{.*\}/g,
                        oEachResponseIterator = response.value.matchAll(regex);

                    // use JSON parse to parse the string to JSON
                    for await (let response of oEachResponseIterator) {
                        const finalResponse = JSON.parse(response[0]).value;
                        openSOData = finalResponse.length > 0 ? openSOData.concat(finalResponse) : openSOData;
                    }
                }
            }
        });

        const grouped = {};

        // Daten group by Email
        openSOData.forEach(entry => {
            if (!grouped[entry.SmtpAddr]) {
                grouped[entry.SmtpAddr] = [];
            }
            grouped[entry.SmtpAddr].push(`Sales order number: ${entry.Vbeln}`);
        });

        // format as String
        // return Object.entries(grouped)
        //     .map(([email, vbelnList]) => `${email}||${vbelnList.join("|")}`)
        //     .join("|||");
        let stringResult = Object.entries(grouped)
            .map(([email, vbelnList]) => `${email}||${vbelnList.join("|")}`)
            .join("|||");

        return stringResult + "||||" + result;

         let resultsss = stringResult + "||||" + result;

        // if (resultsss != "") {
        //     var splitValueForSPDate = resultsss.split("||||");
        //     var splitValueForMailAndSalesOrder = splitValueForSPDate[0];
        //     var spPhaseDate = splitValueForSPDate[1];
        //     if (splitValueForMailAndSalesOrder.length > 0) {
        //         var splitValueforMail = splitValueForMailAndSalesOrder.split("|||");

        //         var onlyMail = "";
        //         var salesorder = [];
        //         // var salesOrder = "";
        //         for (var i = 0; i < splitValueforMail.length; i++) {
        //             if (onlyMail !== "") {
        //                 onlyMail += "," + splitValueforMail[i].split("||")[0];
        //                 salesorder.push(splitValueforMail[i].split("||")[0] + " -- " + splitValueforMail[i].split("||")[1].split("|Sales order number:").join());
        //             } else {
        //                 onlyMail = splitValueforMail[i].split("||")[0];
        //                 salesorder.push(splitValueforMail[i].split("||")[0] + " -- " + splitValueforMail[i].split("||")[1].split("|Sales order number:").join());
        //             }
        //         }
        //         var cxsmail = onlyMail;
        //         // var csxsalesorder = salesorder;
        //         // console.log(csxsalesorder);
        //         var convertString = salesorder.join('\n');
        //         // console.log(convertString);
        //         var obj = {};
        //         obj.mails = cxsmail;
        //         obj.salesorders = convertString;
        //         obj.phaseOutDate = spPhaseDate;
        //         let stringfyResult = JSON.stringify(obj);
        //         return stringfyResult;
        //     }
        // }

    });

    async function getEmailAddressController(allMatTypePlantsResults) {
        let data92 = ``, data93 = ``, data92flag = false, data93flag = false, mailresult = "", aFinalResponse92 = [], aFinalResponse93 = [];

        for await (let data of allMatTypePlantsResults) {
            if (data.source_system === '92') {
                data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MrpCtrl(Werks='${data.werks}',Dispo='${data.dispo}')?$expand=to_user_item HTTP/1.1\r\n\r\n\r\n`;
                data92flag = true;
            } else {
                data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MrpCtrl(Werks='${data.werks}',Dispo='${data.dispo}')?$expand=to_user_item HTTP/1.1\r\n\r\n\r\n`;
                data93flag = true;
            }
        }

        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        if (data92flag) {
            let PlannerApi = await cds.connect.to("Planner");
            let sStatusUpdateResult92 = await PlannerApi.send({
                method: 'POST',
                path: '/$batch',
                headers: {
                    'Content-Type': 'multipart/mixed;boundary=batch'
                },
                data: data92
            });

            // batch response needs to be decoded to identify individual one's
            // so use regex to find out JSON outputs from the total batch response
            let regex = /\{.*\}/g,
                oEachResponseIterator = sStatusUpdateResult92.matchAll(regex);

            // use JSON parse to parse the string to JSON
            for await (let response of oEachResponseIterator) {
                aFinalResponse92.push(JSON.parse(response[0]));
            }

            for (const item92 of aFinalResponse92) {
                if (mailresult !== "") {
                    if (item92.to_user_item != undefined) {
                        mailresult += `,${item92.to_user_item.Email}`;
                    }
                } else {
                    if (item92.to_user_item != undefined) {
                        mailresult = `${item92.to_user_item.Email}`;
                    }
                }
            }
        }
        if (data93flag) {
            let PlannerApi = await cds.connect.to("APAC_Planner");
            let sStatusUpdateResult93 = await PlannerApi.send({
                method: 'POST',
                path: '/$batch',
                headers: {
                    'Content-Type': 'multipart/mixed;boundary=batch'
                },
                data: data93
            });

            // batch response needs to be decoded to identify individual one's
            // so use regex to find out JSON outputs from the total batch response
            let regex = /\{.*\}/g,
                oEachResponseIterator = sStatusUpdateResult93.matchAll(regex);

            // use JSON parse to parse the string to JSON
            for await (let response of oEachResponseIterator) {
                aFinalResponse93.push(JSON.parse(response[0]));
            }
            for (const item93 of aFinalResponse93) {
                if (mailresult !== "") {
                    if (item93.to_user_item != undefined) {
                        mailresult += `,${item93.to_user_item.Email}`;
                    }
                } else {
                    if (item93.to_user_item != undefined) {
                        mailresult = `${item93.to_user_item.Email}`;
                    }
                }
            }
        }
        return mailresult;
    };

    this.on("getMrpContrlEmailNew", async (req) => {
        const {CompUsage, AllMatTypePlants, RpSupplyPlanner} = cds.entities('ppe.cm.md');
        const projectId = req.data.projectID;
        const mat = req.data.material;
        const compUsage = await SELECT.from(CompUsage).columns('component_id', 'plant').where({projectID : projectId, fg_idh : mat});
        if(compUsage.length > 0){
            const amatnr = compUsage?.map((elm) => elm['component_id']);
            const aPlants = compUsage?.map((elm) => elm['plant']);
            const aMrpControllerPlant =  await SELECT.from(AllMatTypePlants).columns('werks', 'dispo').where({matnr : {in : amatnr}});
            if(aMrpControllerPlant.length > 0){
            const aMrpController =  aMrpControllerPlant?.map((elm) => elm['dispo']); 
            const aEmailAddress = await SELECT.from(RpSupplyPlanner).columns('email').where({mrpController : {in : aMrpController}, plant : {in : aPlants}});
            if(aEmailAddress.length > 0){
                const listEmail = aEmailAddress?.map(elm => elm['email']);
                const emailSet = new Set(listEmail);
                const emails = [...emailSet].join(',');
                return emails;
            }else {
             return "mukund.anandatheerthan@henkel.com";
            }
          }else {
              return "mukund.anandatheerthan@henkel.com";
          }
        } else{
            return "mukund.anandatheerthan@henkel.com"
        }
        
        // if(process.env.DEPLOY_ENV === 'DEV' || process.env.DEPLOY_ENV === 'QA'){
        //     return "";
        // }else{
        //     return emails;
        // }
        
        
    });

    this.on('updateProjectIDHPlantY5', async (req) => {
            const uuid = req.data.uuid;
            const material = req.data.material;
            // const status = req.data.status;

            const { ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');

            let oCurrentStatus = await SELECT.one.from(ProjectIDHPlants).columns(`plantYSTATUS`) .where({ l_ev_uuid: uuid, material: material});
            
            if (oCurrentStatus.plantYSTATUS === "Y5" || oCurrentStatus.plantYSTATUS === "")
                {
                    await UPDATE(ProjectIDHPlants)
                    .data({ phaseOutStatus_uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"})
                    .where({ l_ev_uuid: uuid, material: material});
     
                    await UPDATE(ProjectIDHs).with({
                        phaseOutStatus_uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
                    }).where({
                        l_ev_uuid: uuid,
                        material: material
                    });
                }
                else
                {
                    await UPDATE(ProjectIDHPlants)
                    .data({ phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960"})
                    .where({ l_ev_uuid: uuid, material: material});
     
                    await UPDATE(ProjectIDHs).with({
                        phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960"
                    }).where({
                        l_ev_uuid: uuid,
                        material: material
                    });
                }
    
            return 'Success';
    
    });
//Logics added for Workflowlogs. It will insert data in workflow logs
    this.on('workflowLoggingTaskStart', async (req, res) => {
        const { IdhProjectPlantSalesInfo, ProjectIDHs, ProjectIDHPlants } = cds.entities('ComplexityManagement');
        const projectID = req.data.projectID;
        const taskUniqueId = req.data.taskUniqueId;
        const material = req.data.material;
        const processStep = req.data.processStep;
        const taskUserEmaiId = req.data.taskUserEmaiId;

        const spDataRead = await SELECT.from(ProjectIDHs, item => {
            item.regionScope,
                item.accountingSBU,
                item.l_ev_uuid,
                item.l_ev(b => {
                    b.projectID
                })
        }).where({ 'l_ev.projectID': projectID, 'material': material, 'phaseOutNEEDED': true });

        const accSBUList = spDataRead[0]?.accountingSBU;
        //const regionScopeList = spDataRead.map(item => item.regionScope).join(",");

        let obj = {
            processStep: processStep,
            status: "Open",
            taskUniqueId: taskUniqueId,
            taskUserEmaiId: taskUserEmaiId,
            projectID: projectID,
            material: material,
            plant: "",
            accountingSBU: accSBUList,
            regionScope: ""
        }
        if (processStep === 'SP') {
            const getPlants = await SELECT.from(ProjectIDHPlants).where({ material: material, l_ev_uuid: spDataRead[0].l_ev_uuid, mrpController: taskUniqueId, phaseOutNEEDED: 'Yes', plantYSTATUS: { 'not in': ['Y5'] } });
            const plantList = getPlants.map(item => item.plant).join(",");
            obj.plant = plantList;
            const regionScopeList = getPlants[0]?.regionScope;
            obj.regionScope = regionScopeList;
        }
        if(processStep === 'BP'){
            let sFilter = `Material eq '${material}' and DemandPlanner eq '${taskUniqueId}'`;
            const apoDemandPlannerApi = await cds.connect.to("ApoDp");
            let aDemandPlanners = await apoDemandPlannerApi.get(`/DpData?$filter=${sFilter}`);
            obj.regionScope = aDemandPlanners[0]?.Region;
        }
        try {
            const newRecord = await cds.run(INSERT.into(WorkFlowLogs).entries(obj));
            return newRecord.results[0].values[9];
        } catch (err) {
            return err;
        }
    });
//Logics added for Workflowlogs. It will update the status from Open to Completed in workflow logs
    this.on('workflowLoggingTaskEnd', async (req) => {
        const uuid = req.data.uuid;
        try {
            await cds.run(UPDATE(WorkFlowLogs).set({ status: "Completed" }).where({ uuid: uuid }));
            return 'successfully updated'
        } catch (err) {
            return err;
        }
    });

    // this.before('READ', WorkFlowLogs, async (req) => {
    //     // if(!req.user.is("CMAdmin")){

    //     // }
    //     try{
    //         if(req.data.taskModifiedEmail){
    //             await cds.run(UPDATE(WorkFlowLogs).set({ taskModificationFlag : false}).where({ uuid: req.data.uuid }));
    //             return "success";
    //         }

    //     }catch (err) {
    //         return err;
    //     } 
    // });

    this.on("getUserRole", async(req)=>{
        if(req.user.is("CMAdmin") || req.user.is("CMOPSupport")){
            return "validUser"
        }else{
            return "Others"
        }
    });

    this.on("customUpdateAction", async(req)=>{
        let oData = req.data.params;
        let obj = { taskModificationFlag : oData.taskModificationFlag};
        if(oData?.taskModifiedEmail != undefined) obj.taskModifiedEmail = oData.taskModifiedEmail;
        await cds.run(UPDATE(WorkFlowLogs).set(obj).where({ uuid : {in : oData.uuid} }));
        //await cds.run(SELECT(WorkFlowLogs).where({ uuid : {in : oData.uuid} }));
        return "Updated Successfully!"
    });

    this.on("plantBaseMatScenario2", async(req)=>{
        const material = req.data.material;
        const projectUuid = req.data.uuid;
        const { ProjectIDHPlants } = cds.entities('ComplexityManagement');
        const plants = await SELECT.from(ProjectIDHPlants).columns(`plant`, `openTransaction`).where({ material: material, l_ev_uuid: projectUuid, phaseOutNEEDED : 'Yes' });
        let keyword = "";
        let hasYes = plants.filter((item) => item.openTransaction === "Yes");
        let OpenTransactionYesPlants = hasYes?.map(elm => elm.plant)?.join(',');
        let hasNo = plants.filter((item) => item.openTransaction === "No");
        let OpenTransactionNoPlants = hasNo?.map(elm => elm.plant)?.join(',');
        if (OpenTransactionYesPlants && OpenTransactionNoPlants) {
            keyword = "RegFast";
        } else if (OpenTransactionYesPlants) {
            keyword = "Regular";
        } else if (OpenTransactionNoPlants) {
            keyword = "Fasttrack";
        }
        return `${keyword}|${OpenTransactionYesPlants}|${OpenTransactionNoPlants}`;
    });

    this.on("autoApprovalSPFORM", async (req) => {
        const projectID = req.data.projectID;
        const material = req.data.material;
        const mrpController = req.data.mrpController;
        const plantYStatus = 'Y5';
        const { ProjectIDHPlants, ProjectHeaders } = cds.entities('ComplexityManagement');
        const { SupplyPlanFormItems } = cds.entities('SupplyPlannerSummaryService');
        const projectheaderUUID = await SELECT.columns(["uuid", "projectID"]).from(ProjectHeaders).where({ projectID: projectID });
        const projectIDHPlantsData = await SELECT.columns(["confDatePerRegion", "futureY4Date"]).from(ProjectIDHPlants).where({ l_ev_uuid: projectheaderUUID[0].uuid, material: material, mrpController: mrpController, plantYStatus: { 'not in': ['Y5'] } });
        // const plants = await SELECT.from(ProjectIDHPlants).columns(`plant`, `openTransaction`).where({ material: material, l_ev_uuid: projectUuid, phaseOutNEEDED : 'Yes' });
        var confDate2Month = new Date();
        confDate2Month.setMonth(confDate2Month.getMonth() + 2);
        var futureY4Date1Month = new Date();
        futureY4Date1Month.setMonth(futureY4Date1Month.getMonth() + 1);

        const spFormData = await SELECT.from(SupplyPlanFormItems).where({ projectID: projectID, material: material, mrpController: mrpController, plantYStatus: { 'not in': ['Y5'] } });
        if (projectIDHPlantsData.length > 0 && projectIDHPlantsData[0].confDatePerRegion === null) {
            try {
                const MaterialService = await cds.connect.to('MaterialService');

                await UPDATE(ProjectIDHPlants).with(
                    {
                        confDatePerRegion: confDate2Month.toISOString().split('T')[0],
                        futureY4Date: futureY4Date1Month.toISOString().split('T')[0]
                    }
                ).where({
                    uuid: {
                        "in": spFormData?.map(item => item.nodeId)
                    }
                });

                for await (const item of spFormData) {

                    let dDate = new Date(confDate2Month);
                    let formattedDateConfDatePerRegion = dDate.getFullYear().toString() + (dDate.getMonth() + 1).toString().padStart(2, '0') + dDate.getDate().toString().padStart(2, '0');
                    let dDate1 = new Date(futureY4Date1Month);
                    let formattedDateFutureY4Date = dDate1.getFullYear().toString() + (dDate1.getMonth() + 1).toString().padStart(2, '0') + dDate1.getDate().toString().padStart(2, '0');

                    // console.log(formattedDate);
                    const resultDateChange = await MaterialService.tx(req).send('updateMaterialPlantDateStatus', {
                        material: item.material,
                        plant: item.regionOrPlant,
                        date: formattedDateConfDatePerRegion,
                        field: "YYA_LC_Y4"
                    });

                    const resultDateChange1 = await MaterialService.tx(req).send('updateMaterialPlantDateStatus', {
                        material: item.material,
                        plant: item.regionOrPlant,
                        date: formattedDateFutureY4Date,
                        field: "YYA_LC_SP_PHO_DATE"
                    });
                }
            } catch (error) {
                throw (error);
            }
        }
    });

    // In this function we are writting the logic to get sales data on the basis of UUID for Scenario 3.
    this.on("checkFasttrachAndRegularSales", async (req) => {
        // We are reading Project Header UUID
        const projectuuid = req.data.uuid;
        const material = req.data.material;
        const region = req.data.region;
        // const { ProjectIDHPlants, ProjectHeaders, projectPlantSalesArea } = cds.entities('ComplexityManagement');
        const { ProjectHeaders, ProjectIDHSalesArea, ProjectIDHPlants, ProjectIDHs, ProjectStatuses, projectPlantSalesArea } = cds.entities('ComplexityManagement');

        const salesData = await SELECT.from(projectPlantSalesArea).where({
            projectUUID: projectuuid,
            material: material,
            phaseOutNEEDED: 'Yes'
        });

        // we need only required property for scenario 3 so we are reading only some property which is required for scenario 3 like material, plant and etc...
        let requiredSalesData = salesData.map(({ uuid, material, plant, salesyStatus, salesCountry, salesOrg, distChanel, phaseOutNEEDED, openTransactionSales, projectID, sourceSystem }) => ({ uuid, material, plant, salesyStatus, salesCountry, salesOrg, distChanel, phaseOutNEEDED, openTransactionSales, projectID, sourceSystem }));

        // We are filtering fasttrack sales data on the basis of open transaction sales if openTransactionSales value is no then it is fasttrack
        let fasttrackSalesData = requiredSalesData.filter(data => data.openTransactionSales === 'No');
        // We are filtering regular sales data on the basis of openTransactionSales === 'Yes'
        let regularSalesData = requiredSalesData.filter(data => data.openTransactionSales === 'Yes');

        if (fasttrackSalesData.length > 0) {
            let aIdhPlantUuids = fasttrackSalesData.map(idhSales => idhSales.uuid);
            let yStatus = 'Y5'

            let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
            let isFasttrack = true;
            // if (openTransactionSales === 'No') {
            //     isFasttrack = true;
            // }

            for await (let idhPlantSalesArea of fasttrackSalesData) {
                if (idhPlantSalesArea.sourceSystem === "92") {
                    data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectID}"}\r\n\r\n\r\n`;
                    flag92 = true;
                }
                else {
                    data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectID}"}\r\n\r\n\r\n`;
                    flag93 = true;
                }
            }

            data92 = data92 + `--batch--`;
            data93 = data93 + `--batch--`;

            if (flag92) {
                const matApi = await cds.connect.to("Materials");
                let sStatusUpdateResult = await matApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data92
                });

                // batch response needs to be decoded to identify individual one's
                // so use regex to find out JSON outputs from the total batch response
                let regex = /\{.*\}/g,
                    oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

                // use JSON parse to parse the string to JSON
                for await (let response of oEachResponseIterator) {
                    aFinalResponse.push(JSON.parse(response[0]));
                }
            }
            if (flag93) {
                const matApi = await cds.connect.to("APAC_Materials");
                let sStatusUpdateResult = await matApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data93
                });

                // batch response needs to be decoded to identify individual one's
                // so use regex to find out JSON outputs from the total batch response
                let regex = /\{.*\}/g,
                    oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

                // use JSON parse to parse the string to JSON
                for await (let response of oEachResponseIterator) {
                    aFinalResponse.push(JSON.parse(response[0]));
                }
            }
            // check if every result is success
            let bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

            if (bAllSuccess) {
                await UPDATE(ProjectIDHSalesArea).with(
                    {
                        salesyStatus: yStatus,
                        yStatusValidfrom: new Date().toISOString().split('T')[0],
                        phaseOutStatus_uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
                    }
                ).where({
                    uuid: {
                        in: aIdhPlantUuids
                    }
                });
                // return "Success";
                // fetch current status code and identifier
                // let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
                //     uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
                // });
                // console.log(projectuuid);
                // console.log(material);
                // await cds.run(UPDATE(ProjectIDHs).with({
                //     phaseOutStatus_uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
                // }).where({
                //     l_ev_uuid: projectuuid,
                //     material: material
                // })).catch((error) => {
                //     throw error;
                // });

                // let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`uuid`).where({
                //     l_ev_uuid: projectuuid,
                //     material: material
                // });
                // const plantsDataForSales = await
                //     SELECT.from(ProjectIDHPlants, o => {
                //         o('*'),
                //             o.projectIDHSalesAreas(items => { items('*') })
                //     }).where({ l_ev_uuid: projectuuid });

                // let plantSalesData = plantsDataForSales.map(plant => ({
                //     ...plant,
                //     projectIDHSalesAreas: plant.projectIDHSalesAreas.map(sales => ({
                //         ...sales,
                //         material: plant.material,
                //         plant: plant.plant,
                //         regionScope: plant.regionScope,
                //         l_ev_id: projectuuid
                //     }))
                // }));

                // let filteredData = plantSalesData.flatMap(obj => obj.projectIDHSalesAreas);
                // let filteredDataPhaseOut = filteredData.filter(item => item.phaseOutNEEDED === 'Yes');
                // // let filtercurrentData = filteredDataPhaseOut.filter(item => item.uuid === uuid);
                // let finalFilterData = filteredDataPhaseOut.filter(item => item.material === material && item.regionScope === region);
                // let projectStatusUUID = finalFilterData.map(item => item.phaseOutStatus_uuid);

                // if (projectStatusUUID.length > 0) {
                //     // fetch all plant status ordered by code ascending
                //     let aRegionStatus = await SELECT.from(ProjectStatuses).columns(`code`, `uuid`).where({
                //         uuid: {
                //             in: projectStatusUUID
                //         }
                //     }).orderBy(`code`);

                //     // if received status is smaller then take the status identifier of received code
                //     // else take the status identifier of the index 0 (since it has min value in this index)
                //     const finalMinStatus = oCurrentStatus.code <= aRegionStatus[0].code ? oCurrentStatus.uuid : aRegionStatus[0].uuid;
                //     await UPDATE(ProjectIDHs).with({
                //         phaseOutStatus_uuid: finalMinStatus
                //     }).where({
                //         l_ev_uuid: projectuuid,
                //         material: material,
                //         regionScope: region
                //     });
                // }
            }

        }
        if (regularSalesData.length > 0) {
            let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
            let isFasttrack = true;
            let aIdhPlantUuids = regularSalesData.map(idhSales => idhSales.uuid);
            let yStatus = 'Y4'
            for await (let idhPlantSalesArea of regularSalesData) {
                if (idhPlantSalesArea.sourceSystem === "92") {
                    data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectID}"}\r\n\r\n\r\n`;
                    flag92 = true;
                }
                else {
                    data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectID}"}\r\n\r\n\r\n`;
                    flag93 = true;
                }
            }

            data92 = data92 + `--batch--`;
            data93 = data93 + `--batch--`;

            if (flag92) {
                const matApi = await cds.connect.to("Materials");
                let sStatusUpdateResult = await matApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data92
                });

                // batch response needs to be decoded to identify individual one's
                // so use regex to find out JSON outputs from the total batch response
                let regex = /\{.*\}/g,
                    oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

                // use JSON parse to parse the string to JSON
                for await (let response of oEachResponseIterator) {
                    aFinalResponse.push(JSON.parse(response[0]));
                }
            }
            if (flag93) {
                const matApi = await cds.connect.to("APAC_Materials");
                let sStatusUpdateResult = await matApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data93
                });

                // batch response needs to be decoded to identify individual one's
                // so use regex to find out JSON outputs from the total batch response
                let regex = /\{.*\}/g,
                    oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

                // use JSON parse to parse the string to JSON
                for await (let response of oEachResponseIterator) {
                    aFinalResponse.push(JSON.parse(response[0]));
                }
            }
            // check if every result is success
            let bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

            if (bAllSuccess) {
                await UPDATE(ProjectIDHSalesArea).with(
                    {
                        salesyStatus: yStatus,
                        yStatusValidfrom: new Date().toISOString().split('T')[0],
                        phaseOutStatus_uuid: "90f96838-33c1-4a4a-87ed-82f0337370f5"
                    }
                ).where({
                    uuid: {
                        in: aIdhPlantUuids
                    }
                });

                // await cds.run(UPDATE(ProjectIDHs).with({
                //     phaseOutStatus_uuid: "90f96838-33c1-4a4a-87ed-82f0337370f5"
                // }).where({
                //     l_ev_uuid: projectuuid,
                //     material: material,
                //     regionScope: region
                // })).catch((error) => {
                //     throw error;
                // });
                // return "Success";
                // fetch current status code and identifier
                let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
                    uuid: "90f96838-33c1-4a4a-87ed-82f0337370f5"
                });
            }
        }
        const uniqueRegionSalesData = [
            ...new Map(salesData.map(item => [item.regionScope, item])).values()
        ];
        if ((fasttrackSalesData.length > 0 && regularSalesData.length > 0) || uniqueRegionSalesData.length > 0) {

            let salesUUID = salesData.map(id => id.uuid);

            const uniqueMap = new Map();
            uniqueRegionSalesData.forEach(item => {
                const key = item.material + "|" + item.regionScope;
                if(!uniqueMap.has(key)){
                    uniqueMap.set(key, item);
                }
            });

            const uniqueArray = Array.from(uniqueMap.values());

            const allIDHPlantData = new Set(salesData.map(item => ` ${item.material}_${item.regionScope}`));
            // let uniqueRegionSalesData = [
            //     ...new Map(salesData.map(item => [item.regionScope, item])).values()
            // ];
            if (uniqueRegionSalesData.length > 0) {
                for (let salesdata of uniqueArray) {
                    const filterOnRegionScope = salesData.filter(item => item.material === material && item.regionScope === salesdata.regionScope && item.phaseOutNEEDED === 'Yes');
                    const filteredOnopenTransactionSales = filterOnRegionScope.filter(item => item.openTransactionSales === 'Yes');
                    let finalMinStatus = '';
                    if (filteredOnopenTransactionSales.length > 0) {
                        finalMinStatus = '90f96838-33c1-4a4a-87ed-82f0337370f5';
                    } else {
                        finalMinStatus = '1c290c86-d4ee-44e0-98df-87de0a09c945';
                    }
                //    console.log("final test" + finalMinStatus);
                //    console.log("final test" + salesdata.regionScope);
                //     console.log("final test" + projectuuid);
                //      console.log("final test" + material);
                    await cds.run(UPDATE(ProjectIDHs).with({
                        phaseOutStatus_uuid: finalMinStatus
                    }).where({
                        l_ev_uuid: projectuuid,
                        material: material,
                        regionScope: salesdata.regionScope
                    })).catch((error) => {
                        throw error;
                    });
                    // let getUUIDOfSales = filterOnRegionScope.map(item => item.salesPhaseOutStatus);
                    // fetch current status code and identifier
                    // let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
                    //     uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
                    // });

                    // if (getUUIDOfSales.length > 0) {
                    //     // fetch all plant status ordered by code ascending
                    //     let aRegionStatus = await SELECT.from(ProjectStatuses).columns(`code`, `uuid`).where({
                    //         uuid: {
                    //             in: getUUIDOfSales
                    //         }
                    //     }).orderBy(`code`);

                    //     // if received status is smaller then take the status identifier of received code
                    //     // else take the status identifier of the index 0 (since it has min value in this index)
                    //     let finalMinStatus = oCurrentStatus.code <= aRegionStatus[0].code ? oCurrentStatus.uuid : aRegionStatus[0].uuid;
                    //     // console.log(salesdata.regionScope);
                    //     await cds.run(UPDATE(ProjectIDHs).with({
                    //         phaseOutStatus_uuid: finalMinStatus
                    //     }).where({
                    //         l_ev_uuid: projectuuid,
                    //         material: material,
                    //         regionScope: salesdata.regionScope
                    //     })).catch((error) => {
                    //         throw error;
                    //     });
                    // }

                }
            }
        }
        return {
            LIST_SAS_FT: fasttrackSalesData,
            LIST_SAS_RG: regularSalesData
        }
    });
});