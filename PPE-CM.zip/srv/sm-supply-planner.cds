using {
    ppe.cm.md.MatSorgs as Sorgs,
    ppe.cm.md.AllMatTypes as MatTypes,
    ppe.cm.md.RpSupplyPlanner as RpSp
} from '../db/ingested-master-data';
using {ppe.cm.pd as pd} from '../db/project-dashboard';
using {MatBomsService.BomItemsTree as BomItemsTree} from './BackendServices';
using {MatBomsService.WhereUsedBomItems as WhereUsedBomItems} from './BackendServices';
using {MatX03Service.MatType as MatType} from './BackendServices';
using from 'cds-spreadsheetimporter-plugin';

using {
    V_MatValList,
    V_MRPEmailValList,
    v_supplyplanneritems,
    v_idhProjectPlantSalesInfo
} from '../db/views';

service SupplyPlannerSummaryService @(path: 'ppe/cm/sps-services') @(requires: 'authenticated-user') {
// service SupplyPlannerSummaryService @(path: 'ppe/cm/sps-services') {    
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity SalesOrgs           as
        select from Sorgs {
            key matnr,
            key vkorg,
            key vtweg,
                dwerk,
                name,
                country,
                country_name,
                vmsta,
                vmstd,
        }

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity AllMatTypes         as
        select from MatTypes {
            key matnr,
                mtart,
                mtart_descr,
        }

    entity ProjectIDHPlants    as projection on pd.ProjectIDHPlants;

    @readonly
    // @restrict: [{
    //     grant: ['READ'],
    //     to   : [
    //         'CMAdmin',
    //         'CMSupplyPlanner'
    //     ]
    // }]
    entity BomTree             as projection on BomItemsTree;
    @readonly
    // @restrict: [{
    //     grant: ['READ'],
    //     to   : [
    //         'CMAdmin',
    //         'CMSupplyPlanner'
    //     ]
    // }]
    entity BomCompParents      as projection on WhereUsedBomItems;    

    @readOnly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity ProjectHeaders      as projection on pd.ProjectHeaders
                                  where
                                      projectStatus.projectStatus <> 'Draft';

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity MatValList          as
        projection on V_MatValList {
            key projectID,
            key material,
                materialText,
        };

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity MRPEmailValList     as
        projection on V_MRPEmailValList {
            key mrpControllerEmail,
        };

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity SupplyPlanItems     as
        projection on v_supplyplanneritems {
            key projectID,
            key material,
            key hierarchyLevel,
            key regionOrPlant,
                *
        }
        order by
            material,
            regionScope,
            hierarchyLevel;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity SupplyPlanFormItems as
        projection on v_supplyplanneritems {
            key projectID,
            key material,
            key hierarchyLevel,
            key regionOrPlant,
                *
        };

    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
         to   : [
            'CMAdmin',
            'CMSupplyPlanner'
        ]
     }]

    // field can be: YYA_LC_Y3, YYA_LC_Y4, YYA_LC_PLM_PHO_DATE, YYA_LC_SP_PHO_DATE
    action updateMaterialPlantDateStatus(material : String(18), plant : String(4), field : String(20), date : String(102))                         returns String;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner'
        ]
    }]
    entity IdhProjectPlantSalesInfo as projection on  v_idhProjectPlantSalesInfo{
       key material,
       key uuid,
       key salesCountry,
       key regionScope,
       key plant,
       key salesOrg,
       key distChanel,
       *
    }

    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE',
             'READ',
             'DELETE'
         ],
         to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMRPSupplyplanner'
        ]
    }]

    entity RpSupplyPlanner as projection on RpSp;
    @readonly
    // @restrict: [{
    //     grant: ['READ'],
    //     to   : [
    //         'CMAdmin',
    //         'CMSupplyPlanner'
    //     ]
    // }]
    entity MatTypesX03      as projection on MatType;   

    @restrict: [{
         grant: [
             'CREATE',
             'READ'
         ],
         to   : [
            'CMAdmin',
            'CMSupplyPlanner'
        ]
     }]

    action getSubstMat(projectID : String, material : String) returns String;   
}
