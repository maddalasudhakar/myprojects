using {Materials as Mat} from './external/Materials.csn';
using {MatStorageLocs as strLocs} from './external/MatStorageLocs.csn';
using {MatStocks} from './external/MatStocks.csn';
using {MatBoms as Boms} from './external/MatBoms.csn';
using {Apo as Apos} from './external/Apo.csn';
using {ApoDp as ApoDps} from './external/ApoDp.csn';
using {Planner as Planners} from './external/Planner.csn';
using {MaterialsX03 as MatX03} from './external/MaterialsX03';



service MaterialService @(path: 'ppe/cm/materials') @cds.persistance.skip @(requires: 'authenticated-user') {
    @readonly
  @restrict: [{
         grant: ['READ'],
         to   : [
             'CMAdmin',
             'CMPLM',
             'CMSupplyPlanner',
             'CMBusinessPlanner',
             'CMControlTower'
         ]
     }]
    entity Marc as projection on Mat.marc;
 
    @readonly
     @restrict: [{
         grant: ['READ'],
         to   : [
             'CMAdmin',
             'CMPLM',
             'CMSupplyPlanner',
             'CMBusinessPlanner',
             'CMControlTower'
         ]
     }]
    entity Mvke as projection on Mat.mvke;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Mbew as projection on Mat.mbew;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action updateMaterialPlantStatus(material : String(18), plant : String(4), status : String(2))         returns String;
    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
         to   : [
             'CMAdmin',
             'CMPLM',
             'CMSupplyPlanner',
             'CMBusinessPlanner',
             'CMControlTower'
         ]
     }]

    // field can be: YYA_LC_Y3, YYA_LC_Y4, YYA_LC_PLM_PHO_DATE, YYA_LC_SP_PHO_DATE
    action updateMaterialPlantDateStatus(material : String(18), plant : String(4), field : String(20), date : String(12))                         returns String;
    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action updateMaterialPlantSAStatus(material : String(18), projectUuid : UUID, status : String(2))      returns String;
    action updateMaterialPlantSalesAreaStatus(material : String(18), plantUuid : UUID, status : String(2)) returns String;
     @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
         to   : [
             'CMAdmin',
             'CMPLM',
             'CMSupplyPlanner',
             'CMBusinessPlanner',
             'CMControlTower'
         ]
     }]
    action getDemandPlanners(material : String(18), projectUuid : UUID, regionScope : String(6))           returns String;
    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getMrpController(material : String(18), projectUuid : UUID)                                     returns String;
  
  @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action updateSaleStatusScenario03(uuid : UUID, material : String(18), salesOrg : String(10), distChanel : String(10), projectID : Integer, sourceSystem : String(10), openTransactionSales : String(10))      returns String;
   

   @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action updateSalesAreaStatusScenario3(uuid : UUID, material : String(18), salesOrg : String(10), distChanel : String(10), projectID : Integer, sourceSystem : String(10), openTransactionSales : String(10))      returns String;
   

}

service MatStrLocs @(path: 'ppe/cm/matstoragelocs') @cds.persistance.skip {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Mard as projection on strLocs.Mard;
}

service MaterialStocks @(path: 'ppe/cm/matstocks') @cds.persistance.skip {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Stocks    as projection on MatStocks.Stock;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity StocksCal as projection on MatStocks.stock_cal;
}

service MatBomsService @(path: 'ppe/cm/matboms') @cds.persistance.skip {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity BomItems          as projection on Boms.BomItem;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity BomItemsTree      as projection on Boms.BomItemTree;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity WhereUsedBomItems as projection on Boms.WhereUsedBomItem;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action setBomToInactive(material : String(18), plant : String(4))      returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action setBomToDelete(material : String(18), plant : String(4))      returns String;
}

service ApoService @(path: 'ppe/cm/apos') @cds.persistance.skip {
    @readonly
    @restrict: [{
         grant: ['READ'],
         to   : [
             'CMAdmin',
             'CMPLM',
             'CMSupplyPlanner',
             'CMBusinessPlanner',
             'CMControlTower'
         ]
     }]
    entity ApoDp          as projection on Apos.GetData_ApoDp;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity ApoSnp         as projection on Apos.GetData_ApoSnp;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity DemandPlanners as projection on ApoDps.DpData;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower',
            'CMJobScheduler'
        ]
    }]
    action updateStatusCluster2Obs( material : String(18), plant : String(4))         returns String;
}

service PlannersService @(path: 'ppe/cm/planners') @cds.persistance.skip {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity User      as projection on Planners.UserItem;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity CtPlanner as projection on Planners.PlannerItem;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MrpCtrl   as projection on Planners.MrpCtrl;
}

service MatDepObjsService @(path: 'ppe/cm/matdepobjs') @cds.persistance.skip {

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action setMasterPrdToInactive(material : String(18), plant : String(4))      returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action setMasterPrdToDelete(material : String(18), plant : String(4))      returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action setPirSourcelistToDelete(material : String(18), plant : String(4))      returns String;

}

service MatX03Service @(path: 'ppe/cm/materialsx03') @cds.persistance.skip {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MatType         as projection on MatX03.mat_typ;

}