
const cds = require('@sap/cds');
const SequenceHelper = require("./lib/SequenceHelper");
const JobSchedulerClient = require('@sap/jobs-client');
const { select } = require('@sap/cds/libx/_runtime/hana/execute');
const { SELECT, UPDATE } = require('@sap/cds/lib/ql/cds-ql');
const { FG1Boms } = cds.entities('ppe.cm.md');
const { CompUsageJobInfo } = cds.entities('ppe.cm.md');
const { ReplaceEmailWorkflow } = cds.entities('ppe.cm.pd');

module.exports = cds.service.impl(async function () {
    const { MatPlants, MatSorgs, SalesBoms, ProjectIDHs, ProjectIDHPlants, ProjectStatuses, DepObjIbProducts, DepObjLinkedRsns, ProjectHeaders, DepObjBoms, CompUsage, FGMatCls, FG1BomItems, PhaseOutScenario, IdhProjectPlantSalesInfo, ProjectIDHSalesArea } = this.entities;

    this.before('*', async (req) => {
        if (req.event === 'DELETE')
            req.reject(406, "Not accepted");

        if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
            const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
            const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
            let payload = JSON.stringify(req.data);

            sBlacklistExactTokens.forEach((token) => {
                const regex = new RegExp(`\\b${token}\\b`);
                if (payload.toLowerCase().match(regex))
                    req.reject(406, "Not accepted");
            });
            sBlacklistIncludeTokens.forEach((token) => {
                if (payload.toLowerCase().includes(token))
                    req.reject(406, "Not accepted");
            });

            Object.keys(req.data).forEach((key) => {
                if(key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")){

                    // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                    if (!emailRegex.test(req.data[key])) 
                        req.reject(406, "Not accepted - Invalid email format");
                }
            });
        }
    });

    this.on('userAuth', async (req) => {
        return {
            "create": req.user.is("CMAdmin") || req.user.is("CMPLM") || req.user.is("CMSupplyPlanner"),
            "edit" : req.user.is("CMAdmin") || req.user.is("CMPLM") || req.user.is("CMSupplyPlanner"),
            "userEmail" : req.user.id
        };
    });
    this.on('getIDHDetails', async (req) => {
        var projectIDHs = [], projectIDHPlants = [], res, filteredArrayOnlyInactive;
        const materialString = req.data.material[0];
        const decodedString = decodeURIComponent(materialString);
        const material = decodedString.split(',');
        const projectScenario = req.data.projectSec;
        const idsToExclude = ['', 'Y1', 'Y5', 'Y6'];
        var Results = await SELECT.from(MatPlants).where({ matnr: { in: material }, mmsta: { 'not in': idsToExclude } });
        const SAResults = await SELECT.from(MatSorgs).where({ matnr: { in: material }, vmsta: { 'not in': idsToExclude } });
        const ResultsActive = await SELECT.from(MatPlants).where({ matnr: { in: material }, mmsta: { 'in': idsToExclude } });
        try {
            if ((Results.length == 0 && ResultsActive.length >= 0 && SAResults.length == 0)) {
                throw new Error('The selected IDH has no active plants for Phase Out. Please select another IDH.');
            }
        } catch (error) {
            customErrorHandler(req, error);
            return;
        }
       if(projectScenario === "Scenario01" || projectScenario === undefined){
        if (SAResults.length > 0 && ResultsActive.length > 0 && Results.length > 0) {
            var ResultsActiveNotInResults = ResultsActive.filter(item => !new Set(Results.map(item => item.matnr)).has(item.matnr));
           
            if (ResultsActiveNotInResults.length > 0) {
                 filteredArrayOnlyInactive = ResultsActiveNotInResults.filter(item1 => {
                    return SAResults.some(item2 => {
                        // return item1.matnr === item2.matnr && item1.werks === item2.dwerk;
                        return item1.matnr === item2.matnr;
                    });
                });
                if (filteredArrayOnlyInactive.length > 0) {
                    Results = [...Results, ...filteredArrayOnlyInactive];
                }

                // Results = [...Results, ...ResultsActiveNotInResults];
            }
        }
        var uniqueRegios, inactiveFlag = true;
        if (SAResults.length > 0 && ResultsActive.length > 0 && Results.length == 0) {
            uniqueRegios = getUniqueMaterialRegionCombinations(ResultsActive);
            inactiveFlag = true;
        } else {
            uniqueRegios = getUniqueMaterialRegionCombinations(Results);
            inactiveFlag = false;
        }
        const sbuResults = await SELECT.columns(['matnr','leading_sbu_sbi','yidh_leading_sbu']).from(FGMatCls).where({ matnr: { "in": uniqueRegios?.map(item => item.matnr)}});
        for await (const item of uniqueRegios) {
            var IDHRegion = {};
            var filterItemMaterial = sbuResults.filter(material => material.matnr === item.matnr);
            IDHRegion.material = item.matnr;
            IDHRegion.regionScope = item.regio;
            IDHRegion.materialText = item.maktx;
            IDHRegion.phaseOutNEEDED = true;
            IDHRegion.subsMaterial = "";
            IDHRegion.subsMaterialText = "";
            IDHRegion.phaseOutDate = null;
            IDHRegion.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
            IDHRegion.workflowFlag = "";
            IDHRegion.phaseOutScenario = "Regular";
            IDHRegion.spConfirmedDate = null;
            IDHRegion.accountingSBU = filterItemMaterial[0].leading_sbu_sbi || filterItemMaterial[0].yidh_leading_sbu;
            projectIDHs.push(IDHRegion);

            var IDHPlant;
            if (inactiveFlag) {
                IDHPlant = ResultsActive.filter((r) => r.matnr === item.matnr && r.regio === item.regio);
            } else {
                IDHPlant = Results.filter((r) => r.matnr === item.matnr && r.regio === item.regio);
            }
            // var IDHPlant = Results.filter((r) => r.matnr === item.matnr && r.regio === item.regio);
            let allNoOpenTransaction = true;
            for await (const element of IDHPlant) {
                 var filterMatPlantCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({material : element.matnr, plant : element.werks, statusText : { 'not in': ['Draft', 'Phase-Out Cancelled']}, phaseOutNEEDED : 'Yes', plant_status_uuid : {'not in' : ['a3549a6e-fd81-4b82-8caa-c19c93b431b8']}});
               if(filterMatPlantCombo?.length == 0){
                var plantList = {};
                plantList.material = element.matnr;
                plantList.plant = element.werks;
                plantList.materialText = element.maktx;
                plantList.plantYSTATUS = element.mmsta;
                plantList.regionScope = element.regio;
                plantList.pValidFrom = element.mmstd;
                plantList.phaseOutNEEDED = "Yes";
                plantList.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
                plantList.phaseOutDate = null;
                plantList.sourceSystem = element.source_system;
                plantList.mrpController = element.dispo;
                plantList.ctPlanner = element.yya_plan_ct;


                let promises = [
                    getmrpController(plantList),
                    getctPlannerEmail(plantList),
                    getOpenTransactions(plantList)
                ];

                const [mrpControllerEmail, ctPlannerEmail, openTransactions] = await Promise.all(promises);

                plantList.mrpControllerEmail = mrpControllerEmail.mail;
                // if (mrpControllerEmail.mail === "" && element.regio != 'EU') {
                //     // const { ReplaceEmailWorkflow } = cds.entities('ppe.cm.pd');
                //     const replaceMail = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: element.regio });
                //     if (replaceMail.length > 0) {
                //         plantList.mrpControllerEmail = replaceMail[0].mrp_email;
                //     }
                // }
                plantList.ctPlannerEmail = ctPlannerEmail.CtPlannerEmail;

                if (openTransactions.OpenTransactions === "Yes") {
                    plantList.openTransaction = "Yes";
                    allNoOpenTransaction = false;
                } else {
                    plantList.openTransaction = "No";
                }
                var projectIDHSA = [];
                var IDHPlantSA = SAResults.filter((i) => i.matnr === element.matnr && i.dwerk === element.werks);
                   for await (const salesArea of IDHPlantSA) {
                       let filterSalesCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: element.matnr, plant: element.werks, salesOrg: salesArea.vkorg, distChanel: salesArea.vtweg, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] } });
                       let filterSalesComboScenari3;
                       if (filterSalesCombo?.length > 0) {
                           let filterSalesComboScenari31 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "Yes"));
                           let filterSalesComboScenari32 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "No"));
                           let filterSalesComboScenari33 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "Yes"));
                           let filterSalesComboScenari34 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "No"));

                           if (filterSalesComboScenari31?.length > 0) {
                               filterSalesComboScenari3 = filterSalesComboScenari31;
                           } else if (filterSalesComboScenari33?.length > 0) {
                               filterSalesComboScenari3 = filterSalesComboScenari33;
                           } else if (((filterSalesComboScenari32?.length > 0) || filterSalesComboScenari34?.length > 0) && filterSalesComboScenari33?.length === 0) {
                               filterSalesComboScenari3 = filterSalesComboScenari33
                           }
                       }
                       if (filterSalesCombo?.length === 0 || filterSalesComboScenari3?.length === 0) {
                           var plantSA = {};
                           plantSA.salesOrg = salesArea.vkorg;
                           plantSA.distChanel = salesArea.vtweg;
                           plantSA.sourceSystem = salesArea.source_system;
                           plantSA.salesCountry = salesArea.country;
                           plantSA.salesCountryName = salesArea.country_name;
                           plantSA.salesOrgDescr = salesArea.name;
                           plantSA.salesyStatus = salesArea.vmsta;
                           plantSA.yStatusValidfrom = salesArea.vmstd;
                           projectIDHSA.push(plantSA);
                       }
                   };
                if (inactiveFlag) {
                    if (IDHPlantSA.length > 0) {
                        plantList.projectIDHSalesAreas = projectIDHSA;
                        projectIDHPlants.push(plantList);
                    }
                } else {
                    let checkingInActiveMatInResult = filteredArrayOnlyInactive?.filter((j) => j.matnr === element.matnr);
                    if (checkingInActiveMatInResult != undefined && checkingInActiveMatInResult.length > 0) {
                        if (IDHPlantSA.length > 0) {
                            plantList.projectIDHSalesAreas = projectIDHSA;
                            projectIDHPlants.push(plantList);
                        }
                    } else {
                        plantList.projectIDHSalesAreas = projectIDHSA;
                        projectIDHPlants.push(plantList);
                    }
                }
            }
            };
            if (allNoOpenTransaction) {
                IDHRegion.phaseOutScenario = "Fasttrack"; // Set to "Fasttrack" if all plant has openTransaction = "No"
            }
            let addInactiveMatResult = filteredArrayOnlyInactive?.filter((j) => j.matnr === item.matnr);
            if(inactiveFlag){
                IDHRegion.phaseOutScenario = "ActSAInactivePL"; // Set to "ActSAInactivePL" for inactive plant which has active sales area which is added in active result 
            } else if (addInactiveMatResult != undefined && addInactiveMatResult.length > 0) {
                IDHRegion.phaseOutScenario = "ActSAInactivePL";
            }
            // logic to handle  combination fo MRP controller  for EU region        
            if ((projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length > 0) {
                let euRegionMail = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: item.regio });
                if ((projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio)).length ==
                    (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length) {
                    for (let data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
                        if (data.mrpControllerEmail === "") {
                            data.mrpControllerEmail = euRegionMail[0].mrp_email
                        }
                    }
                }
                else {
                    let filteredDataNoEmail = projectIDHPlants.filter((itemplant) => itemplant.mrpControllerEmail != "" && itemplant.material === item.matnr && itemplant.regionScope === item.regio);

                    if (filteredDataNoEmail.length > 0) {

                        let emailCount = {};

                        filteredDataNoEmail.forEach(item => {
                            emailCount[item.mrpControllerEmail] = (emailCount[item.mrpControllerEmail] || 0) + 1;
                        });

                        let maxDuplicateEmail = Object.keys(emailCount).filter(email => emailCount[email] > 1);
                        let emailToPlaceintoEmptyEmail = "";
                        if (maxDuplicateEmail.length > 0) {
                            emailToPlaceintoEmptyEmail = maxDuplicateEmail[0];
                        } else {
                            emailToPlaceintoEmptyEmail = filteredDataNoEmail[0].mrpControllerEmail;
                        }

                        for (data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
                            if (data.mrpControllerEmail === "") {
                                data.mrpControllerEmail = emailToPlaceintoEmptyEmail;
                            }
                        }

                    }

                }
            }
        };
        if (inactiveFlag) {
            // var inActiveIDHS = projectIDHs.filter(item => new Set(projectIDHPlants.map(item => item.regionScope)).has(item.regionScope))
            // const getUniquePlantData = !new Set(projectIDHPlants.map(item => ` ${item.material}_${item.regionScope}`));
            // const inActiveIDHS = projectIDHs.filter(plant => getUniquePlantData.has(` ${plant.material}_${plant.regionScope}`));
            const inActiveIDHS = projectIDHs.filter(plant => !new Set(projectIDHPlants.map(item => `${item.material}_${item.regionScope}`)).has(`${plant.material}_${plant.regionScope}`));
            // projectIDHs = inActiveIDHS;
            const filterUniqueInActiveMaterial = Array.from(new Set(inActiveIDHS.map(obj => obj.material))).map(material => inActiveIDHS.find(obj => obj.material === material));
            for await (const idh of filterUniqueInActiveMaterial) {
                var plantidh = {};
                plantidh.material = idh.material;
                plantidh.plant = "NAN";
                plantidh.materialText = idh.materialText;
                plantidh.plantYSTATUS = "";
                plantidh.regionScope = idh.regionScope;
                plantidh.pValidFrom = idh.pValidFrom;
                plantidh.phaseOutNEEDED = "Yes";
                plantidh.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
                plantidh.phaseOutDate = null;
                plantidh.sourceSystem = idh.sourceSystem;
                plantidh.mrpController = "";
                plantidh.ctPlanner = "";
                plantidh.openTransaction = "";
                plantidh.ctPlannerEmail = "";
                plantidh.mrpControllerEmail = "";
                
                var projectIDHSales = [];
                var IDHPlantSALE = SAResults.filter((i) => i.matnr === idh.material);
                const checkSalesAreaPlant = projectIDHPlants.filter(plant => new Set(IDHPlantSALE.map(item => `${item.matnr}_${item.dwerk}`)).has(`${plant.material}_${plant.plant}`));
                if (checkSalesAreaPlant.length > 0) {
                    continue;
                }
                for await (const salesAreaResult of IDHPlantSALE) {
                    let filterSalesCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: idh.material, plant: "NAN", salesOrg: salesAreaResult.vkorg, distChanel: salesAreaResult.vtweg, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] } });
                       let filterSalesComboScenari3;
                    if (filterSalesCombo?.length > 0) {
                        let filterSalesComboScenari31 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "Yes"));
                        let filterSalesComboScenari32 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "No"));
                        let filterSalesComboScenari33 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "Yes"));
                        let filterSalesComboScenari34 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "No"));

                        if (filterSalesComboScenari31?.length > 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari31;
                        } else if (filterSalesComboScenari33?.length > 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari33;
                        } else if (((filterSalesComboScenari32?.length > 0) || filterSalesComboScenari34?.length > 0) && filterSalesComboScenari33?.length === 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari33
                        }
                    } 
                    if (filterSalesCombo?.length === 0 || filterSalesComboScenari3?.length === 0) {
                        var plantSALEObject = {};
                        plantSALEObject.salesOrg = salesAreaResult.vkorg;
                        plantSALEObject.distChanel = salesAreaResult.vtweg;
                        plantSALEObject.sourceSystem = salesAreaResult.source_system;
                        plantSALEObject.salesCountry = salesAreaResult.country;
                        plantSALEObject.salesCountryName = salesAreaResult.country_name;
                        plantSALEObject.salesOrgDescr = salesAreaResult.name;
                        plantSALEObject.salesyStatus = salesAreaResult.vmsta;
                        plantSALEObject.yStatusValidfrom = salesAreaResult.vmstd;
                        projectIDHSales.push(plantSALEObject);
                    }
                };
                if(IDHPlantSALE.length > 0){
                plantidh.projectIDHSalesAreas = projectIDHSales;
                projectIDHPlants.push(plantidh);
                }
            };
            const getUniquePlantDataNew = new Set(projectIDHPlants.map(item => ` ${item.material}_${item.regionScope}`));
            const inActiveIDHSNew = projectIDHs.filter(plant => getUniquePlantDataNew.has(` ${plant.material}_${plant.regionScope}`));
            projectIDHs = inActiveIDHSNew;
        } else if (projectIDHs.length > 0 && projectIDHPlants.length > 0) {
            const allIDHDataCheck = projectIDHs.filter(item => !new Set(projectIDHPlants.map(item => item.material)).has(item.material));
            // const filterUniqueInActiveMat = allIDHDataCheck.filter(item => new Set(allIDHDataCheck.map(item => item.material)).has(item.material));
            const filterUniqueInActiveMat = Array.from(new Set(allIDHDataCheck.map(obj => obj.material))).map(material => allIDHDataCheck.find(obj => obj.material === material));
            for await (const idhmat of filterUniqueInActiveMat) {
                let plantidhmat = {};
                plantidhmat.material = idhmat.material;
                plantidhmat.plant = "NAN";
                plantidhmat.materialText = idhmat.materialText;
                plantidhmat.plantYSTATUS = "";
                plantidhmat.regionScope = idhmat.regionScope;
                plantidhmat.pValidFrom = idhmat.pValidFrom;
                plantidhmat.phaseOutNEEDED = "Yes";
                plantidhmat.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
                plantidhmat.phaseOutDate = null;
                plantidhmat.sourceSystem = idhmat.sourceSystem;
                plantidhmat.mrpController = "";
                plantidhmat.ctPlanner = "";
                plantidhmat.openTransaction = ""
                plantidhmat.ctPlannerEmail = "";
                plantidhmat.mrpControllerEmail = "";
                var projectIDHSalesMat = [];
                var IDHPlantSALEMat = SAResults.filter((i) => i.matnr === idhmat.material);
                for await (const salesAreaResult of IDHPlantSALEMat) {
                      let filterSalesCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: idhmat.material, plant: "NAN", salesOrg: salesAreaResult.vkorg, distChanel: salesAreaResult.vtweg, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] } });
                      let filterSalesComboScenari3;
                    if (filterSalesCombo?.length > 0) {
                        let filterSalesComboScenari31 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "Yes"));
                        let filterSalesComboScenari32 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "No"));
                        let filterSalesComboScenari33 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "Yes"));
                        let filterSalesComboScenari34 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "No"));

                        if (filterSalesComboScenari31?.length > 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari31;
                        } else if (filterSalesComboScenari33?.length > 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari33;
                        } else if (((filterSalesComboScenari32?.length > 0) || filterSalesComboScenari34?.length > 0) && filterSalesComboScenari33?.length === 0) {
                            filterSalesComboScenari3 = filterSalesComboScenari33
                        }
                    } 
                        if (filterSalesCombo?.length === 0 || filterSalesComboScenari3?.length === 0) {
                        var plantSALEObjectMat = {};
                        plantSALEObjectMat.salesOrg = salesAreaResult.vkorg;
                        plantSALEObjectMat.distChanel = salesAreaResult.vtweg;
                        plantSALEObjectMat.sourceSystem = salesAreaResult.source_system;
                        plantSALEObjectMat.salesCountry = salesAreaResult.country;
                        plantSALEObjectMat.salesCountryName = salesAreaResult.country_name;
                        plantSALEObjectMat.salesOrgDescr = salesAreaResult.name;
                        plantSALEObjectMat.salesyStatus = salesAreaResult.vmsta;
                        plantSALEObjectMat.yStatusValidfrom = salesAreaResult.vmstd;
                        projectIDHSalesMat.push(plantSALEObjectMat);
                    }
                };
               
                    plantidhmat.projectIDHSalesAreas = projectIDHSalesMat;
                    projectIDHPlants.push(plantidhmat);
               
            };
            const allIDHDataCheckNew = new Set(projectIDHPlants.map(item => ` ${item.material}_${item.regionScope}`));
            const resultData = projectIDHs.filter(plant => allIDHDataCheckNew.has(` ${plant.material}_${plant.regionScope}`));
            projectIDHs = resultData;
        } 
        const allIDHPlantData = new Set(projectIDHPlants.map(item => ` ${item.material}_${item.regionScope}`));
        const resultDataIDH = projectIDHs.filter(plant => allIDHPlantData.has(` ${plant.material}_${plant.regionScope}`));
        projectIDHs = resultDataIDH;
        const result = {
            ProjectIDHs: projectIDHs,
            ProjectIDHPlants: projectIDHPlants
        }
        return result;
       } else if (projectScenario === "Scenario02") {
            try {
               if ((Results.length == 0)) {
                   throw new Error('The selected IDH has no active plants for Phase Out. Please select another IDH.');
               }
           } catch (error) {
               customErrorHandler(req, error);
               return;
           }
           var uniqueRegiosSec02 = getUniqueMaterialRegionCombinations(Results);
           const sbuResultsSec02 = await SELECT.columns(['matnr', 'leading_sbu_sbi', 'yidh_leading_sbu']).from(FGMatCls).where({ matnr: { "in": uniqueRegiosSec02?.map(item => item.matnr) } });

           for await (const item of uniqueRegiosSec02) {
               var IDHRegionSec02 = {};
               var filterItemMaterialSec02 = sbuResultsSec02.filter(material => material.matnr === item.matnr);
               IDHRegionSec02.material = item.matnr;
               IDHRegionSec02.regionScope = item.regio;
               IDHRegionSec02.materialText = item.maktx;
               IDHRegionSec02.phaseOutNEEDED = true;
               IDHRegionSec02.subsMaterial = "";
               IDHRegionSec02.subsMaterialText = "";
               IDHRegionSec02.phaseOutDate = null;
               IDHRegionSec02.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
               IDHRegionSec02.workflowFlag = "";
               IDHRegionSec02.phaseOutScenario = "Regular";
               IDHRegionSec02.spConfirmedDate = null;
               IDHRegionSec02.accountingSBU = filterItemMaterialSec02[0].leading_sbu_sbi || filterItemMaterialSec02[0].yidh_leading_sbu;
               projectIDHs.push(IDHRegionSec02);

               var IDHPlantSec02 = Results.filter((r) => r.matnr === item.matnr && r.regio === item.regio);
               let allNoOpenTransaction = true;
               for await (const element of IDHPlantSec02) {
                   var filterMatPlantCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({material : element.matnr, plant : element.werks, statusText : { 'not in': ['Draft', 'Phase-Out Cancelled']}, phaseOutNEEDED : 'Yes', plant_status_uuid : {'not in' : ['a3549a6e-fd81-4b82-8caa-c19c93b431b8']}});
                   //if(filterMatPlantCombo?.length == 0 || (filterMatPlantCombo?.length > 0 && filterMatPlantCombo[0]?.statusText == 'Draft' && ) || (filterMatPlantCombo?.length > 0 && filterMatPlantCombo[0]?.phaseOutNEEDED == 'No' && filterMatPlantCombo[0]?.statusText == 'Phase-Out Execution')){
                    if(filterMatPlantCombo?.length == 0){
                        var plantListSec02 = {};
                        plantListSec02.material = element.matnr;
                        plantListSec02.plant = element.werks;
                        plantListSec02.materialText = element.maktx;
                        plantListSec02.plantYSTATUS = element.mmsta;
                        plantListSec02.regionScope = element.regio;
                        plantListSec02.pValidFrom = element.mmstd;
                        plantListSec02.phaseOutNEEDED = "Yes";
                        plantListSec02.phaseOutStatus_uuid = "1ec074a4-a78a-45fb-b0bb-27f18f17d3de";
                        plantListSec02.phaseOutDate = null;
                        plantListSec02.sourceSystem = element.source_system;
                        plantListSec02.mrpController = element.dispo;
                        plantListSec02.ctPlanner = element.yya_plan_ct;


                        let promises = [
                            getmrpController(plantListSec02),
                            getctPlannerEmail(plantListSec02),
                            getOpenTransactions(plantListSec02)
                        ];

                        const [mrpControllerEmail, ctPlannerEmail, openTransactions] = await Promise.all(promises);

                        plantListSec02.mrpControllerEmail = mrpControllerEmail.mail;
                        // if (mrpControllerEmail.mail === "" && element.regio != 'EU') {
                        //     // const { ReplaceEmailWorkflow } = cds.entities('ppe.cm.pd');
                        //     const replaceMailSec02 = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: element.regio });
                        //     if (replaceMailSec02.length > 0) {
                        //         plantListSec02.mrpControllerEmail = replaceMailSec02[0].mrp_email;
                        //     }
                        // }
                        plantListSec02.ctPlannerEmail = ctPlannerEmail.CtPlannerEmail;

                        if (openTransactions.OpenTransactions === "Yes") {
                            plantListSec02.openTransaction = "Yes";
                            allNoOpenTransaction = false;
                        } else {
                            plantListSec02.openTransaction = "No";
                        }
                        var projectIDHSASec02 = [];
                        var IDHPlantSASec02 = SAResults.filter((i) => i.matnr === element.matnr && i.dwerk === element.werks);
                        if (IDHPlantSASec02.length === 0) {
                            plantListSec02.projectIDHSalesAreas = projectIDHSASec02;
                            projectIDHPlants.push(plantListSec02);
                        }
                   }
               };
               if (allNoOpenTransaction) {
                   IDHRegionSec02.phaseOutScenario = "Fasttrack"; // Set to "Fasttrack" if all plant has openTransaction = "No"
               }
               // logic to handle  combination fo MRP controller  for EU region        
               if ((projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length > 0) {
                   let euRegionMail = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: item.regio });
                   if ((projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio)).length ==
                       (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length) {
                       for (let data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
                           if (data.mrpControllerEmail === "") {
                               data.mrpControllerEmail = euRegionMail[0].mrp_email
                           }
                       }
                   }
                   else {
                      let filteredDataNoEmail = projectIDHPlants.filter((itemplant) => itemplant.mrpControllerEmail != "" && itemplant.material === item.matnr && itemplant.regionScope === item.regio);


                       if (filteredDataNoEmail.length > 0) {

                           let emailCount = {};

                           filteredDataNoEmail.forEach(item => {
                               emailCount[item.mrpControllerEmail] = (emailCount[item.mrpControllerEmail] || 0) + 1;
                           });

                           let maxDuplicateEmail = Object.keys(emailCount).filter(email => emailCount[email] > 1);
                           let emailToPlaceintoEmptyEmail = "";
                           if (maxDuplicateEmail.length > 0) {
                               emailToPlaceintoEmptyEmail = maxDuplicateEmail[0];
                           } else {
                               emailToPlaceintoEmptyEmail = filteredDataNoEmail[0].mrpControllerEmail;
                           }

                           for (data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
                               if (data.mrpControllerEmail === "") {
                                   data.mrpControllerEmail = emailToPlaceintoEmptyEmail;
                               }
                           }

                       }

                   }
               }
           };
         const allIDHDataCheckNewPlant = new Set(projectIDHPlants?.map(item => ` ${item.material}_${item.regionScope}`));
         const resultDataPlant = projectIDHs?.filter(plant => allIDHDataCheckNewPlant?.has(` ${plant.material}_${plant.regionScope}`));
         //comparing which idh region table records is not available in plant for information message
        //  var recordsNotPresentInPlantTable = projectIDHs.filter(arr1 => 
        //     !resultDataPlant.some(arr2 => arr2.material === arr1.material && arr2.regionScope === arr1.regionScope)
        //  ); 
        //  if(recordsNotPresentInPlantTable.length > 0 ){
        //    let arrOfMaterialsRegionDisplay = [];
        //                 for(let mat of recordsNotPresentInPlantTable){
        //                     let obj = {};
        //                     obj.Material = mat.material;
        //                     obj.RegionScope = mat.regionScope;
        //                     arrOfMaterialsRegionDisplay.push(obj);
        //                 } 
        //                 req.error({
        //                     message: `This ${JSON.stringify(arrOfMaterialsRegionDisplay)} records not available in plant table for phaseout so we are not adding this records inside Region Table `,
        //                     code: 'IDH_HAS_NOT_Mat_AND_Region_STATUS',
        //                     details: arrOfMaterialsRegionDisplay,
        //                     status: 400
        //                 }); 
        //  }
           projectIDHs = resultDataPlant;
           const result = {
               ProjectIDHs: projectIDHs,
               ProjectIDHPlants: projectIDHPlants
           }
           return result;

       }
       else if (projectScenario === "Scenario03") {
           var allMaterial = await SELECT.from(MatPlants).where({ matnr: { in: material } });
           try {
               if ((SAResults.length == 0 || allMaterial.length == 0)) {
                   throw new Error('The selected IDH has no sales for Phase Out. Please select another IDH.');
               }
           } catch (error) {
               customErrorHandler(req, error);
               return;
           }

           var uniqueRegiosSec03 = getUniqueMaterialRegionCombinations(allMaterial);
           const sbuResultsSec03 = await SELECT.columns(['matnr', 'leading_sbu_sbi', 'yidh_leading_sbu']).from(FGMatCls).where({ matnr: { "in": uniqueRegiosSec03?.map(item => item.matnr) } });

           for await (const item of uniqueRegiosSec03) {
               var IDHRegionSec03 = {};
               var filterItemMaterialSec03 = sbuResultsSec03.filter(material => material.matnr === item.matnr);
               IDHRegionSec03.material = item.matnr;
               IDHRegionSec03.regionScope = item.regio;
               IDHRegionSec03.materialText = item.maktx;
               IDHRegionSec03.phaseOutNEEDED = false;
               IDHRegionSec03.subsMaterial = "";
               IDHRegionSec03.subsMaterialText = "";
               IDHRegionSec03.phaseOutDate = null;
               IDHRegionSec03.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";
               IDHRegionSec03.workflowFlag = "";
               IDHRegionSec03.phaseOutScenario = "";
               IDHRegionSec03.spConfirmedDate = null;
               IDHRegionSec03.accountingSBU = filterItemMaterialSec03[0].leading_sbu_sbi || filterItemMaterialSec03[0].yidh_leading_sbu;
               projectIDHs.push(IDHRegionSec03);

               var IDHPlantSec03 = allMaterial.filter((r) => r.matnr === item.matnr && r.regio === item.regio);
               let allNoOpenTransaction = true;
               for await (const element of IDHPlantSec03) {
                //    var filterMatPlantCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: element.matnr, plant: element.werks, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] }, phaseOutNEEDED: 'Yes', plant_status_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] } });
                   //if(filterMatPlantCombo?.length == 0 || (filterMatPlantCombo?.length > 0 && filterMatPlantCombo[0]?.statusText == 'Draft' && ) || (filterMatPlantCombo?.length > 0 && filterMatPlantCombo[0]?.phaseOutNEEDED == 'No' && filterMatPlantCombo[0]?.statusText == 'Phase-Out Execution')){
                //    if (filterMatPlantCombo?.length == 0) {
                       var plantListSec03 = {};
                       plantListSec03.material = element.matnr;
                       plantListSec03.plant = element.werks;
                       plantListSec03.materialText = element.maktx;
                       plantListSec03.plantYSTATUS = element.mmsta;
                       plantListSec03.regionScope = element.regio;
                       plantListSec03.pValidFrom = element.mmstd;
                       plantListSec03.phaseOutNEEDED = "No";
                       plantListSec03.phaseOutStatus_uuid = "";
                       plantListSec03.phaseOutDate = null;
                       plantListSec03.sourceSystem = element.source_system;
                       plantListSec03.mrpController = element.dispo;
                       plantListSec03.ctPlanner = element.yya_plan_ct;


                       let promises = [
                           getmrpController(plantListSec03),
                           getctPlannerEmail(plantListSec03),
                           getOpenTransactions(plantListSec03)
                       ];

                       const [mrpControllerEmail, ctPlannerEmail, openTransactions] = await Promise.all(promises);

                       plantListSec03.mrpControllerEmail = mrpControllerEmail.mail;
                    //    if (mrpControllerEmail.mail === "" && element.regio != 'EU') {
                    //        // const { ReplaceEmailWorkflow } = cds.entities('ppe.cm.pd');
                    //        const replaceMailSec03 = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: element.regio });
                    //        if (replaceMailSec03.length > 0) {
                    //            plantListSec03.mrpControllerEmail = replaceMailSec03[0].mrp_email;
                    //        }
                    //    }
                       plantListSec03.ctPlannerEmail = ctPlannerEmail.CtPlannerEmail;

                       if (openTransactions.OpenTransactions === "Yes") {
                           plantListSec03.openTransaction = "Yes";
                           allNoOpenTransaction = false;
                       } else {
                           plantListSec03.openTransaction = "No";
                       }
                       var projectIDHSA03 = [];
                       var IDHPlantSASec03 = SAResults.filter((i) => i.matnr === element.matnr && i.dwerk === element.werks);
                       IDHPlantSASec03 = IDHPlantSASec03.filter((j) => j.vtweg !== "IC");
                       for await (const salesArea of IDHPlantSASec03) {
                         let filterSalesCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: element.matnr, plant: element.werks, salesOrg:salesArea.vkorg, distChanel:salesArea.vtweg, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] } });
                         let filterSalesComboScenari3;
                         if(filterSalesCombo?.length > 0){
                          let  filterSalesComboScenari31 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "Yes") );
                          let  filterSalesComboScenari32 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario01') && (item.phaseOutNEEDED === "No") );
                          let  filterSalesComboScenari33 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "Yes") );
                          let  filterSalesComboScenari34 = filterSalesCombo.filter(item => (item.ProjectPhaseOutScenario === 'Scenario03') && (item.salesPhaseOutneeded === "No") );
                           
                             if (filterSalesComboScenari31?.length > 0) {
                                 filterSalesComboScenari3 = filterSalesComboScenari31;
                             } else if (filterSalesComboScenari33?.length > 0) {
                                 filterSalesComboScenari3 = filterSalesComboScenari33;
                             } else if (((filterSalesComboScenari32?.length > 0) ||filterSalesComboScenari34?.length >0) && filterSalesComboScenari33?.length === 0) {
                                 filterSalesComboScenari3 = filterSalesComboScenari33
                             }
                         }
                          if(filterSalesCombo?.length == 0){  
                           let plantSA = {};
                           plantSA.material = element.matnr;
                           plantSA.plant = element.werks;
                           plantSA.salesOrg = salesArea.vkorg;
                           plantSA.distChanel = salesArea.vtweg;
                           plantSA.sourceSystem = salesArea.source_system;
                           plantSA.salesCountry = salesArea.country;
                           plantSA.salesCountryName = salesArea.country_name;
                           plantSA.salesOrgDescr = salesArea.name;
                           plantSA.salesyStatus = salesArea.vmsta;
                           plantSA.yStatusValidfrom = salesArea.vmstd;
                           plantSA.phaseOutNEEDED = "No";
                           plantSA.region = element.regio;
                           plantSA.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";

                           let promisesSales = [
                               getOpenTransactionsSa(plantSA)
                           ];
                           const [openTransactionsSa] = await Promise.all(promisesSales);
                           if (openTransactionsSa > 0) {
                               plantSA.openTransactionSales = "Yes";
                           } else {
                               plantSA.openTransactionSales = "No";
                           }
                           projectIDHSA03.push(plantSA);
                        }else{
                            if(filterSalesComboScenari3?.length === 0){ 
                           let plantSA = {};
                           plantSA.material = element.matnr;
                           plantSA.plant = element.werks;
                           plantSA.salesOrg = salesArea.vkorg;
                           plantSA.distChanel = salesArea.vtweg;
                           plantSA.sourceSystem = salesArea.source_system;
                           plantSA.salesCountry = salesArea.country;
                           plantSA.salesCountryName = salesArea.country_name;
                           plantSA.salesOrgDescr = salesArea.name;
                           plantSA.salesyStatus = salesArea.vmsta;
                           plantSA.yStatusValidfrom = salesArea.vmstd;
                           plantSA.phaseOutNEEDED = "No";
                           plantSA.region = element.regio;
                           plantSA.phaseOutStatus_uuid = "d941bc7c-2042-4e41-8f9c-57f7f9d89481";

                           let promisesSales = [
                               getOpenTransactionsSa(plantSA)
                           ];
                           const [openTransactionsSa] = await Promise.all(promisesSales);
                           if (openTransactionsSa > 0) {
                               plantSA.openTransactionSales = "Yes";
                           } else {
                               plantSA.openTransactionSales = "No";
                           }
                           projectIDHSA03.push(plantSA);

                            }
                        }
                       };
                       if (projectIDHSA03.length > 0) {
                           plantListSec03.projectIDHSalesAreas = projectIDHSA03;
                           projectIDHPlants.push(plantListSec03);
                       }
                       // var projectIDHSASec03 = [];
                       // var IDHPlantSASec03 = SAResults.filter((i) => i.matnr === element.matnr && i.dwerk === element.werks);
                       // if (IDHPlantSASec03.length === 0) {
                       //     plantListSec03.projectIDHSalesAreas = projectIDHSASec03;
                       //     projectIDHPlants.push(plantListSec03);
                       // }
                //    }
               };
               if (allNoOpenTransaction) {
                   IDHRegionSec03.phaseOutScenario = "Fasttrack"; // Set to "Fasttrack" if all plant has openTransaction = "No"
               }
               // logic to handle  combination fo MRP controller  for EU region        
            //    if (item.regio === "EU" && (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length > 0) {
            //        let euRegionMail = await SELECT.from(ReplaceEmailWorkflow).where({ regionScope: item.regio });
            //        if ((projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio)).length ==
            //            (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio && r.mrpControllerEmail === "")).length) {
            //            for (let data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
            //                if (data.mrpControllerEmail === "") {
            //                    data.mrpControllerEmail = euRegionMail[0].mrp_email
            //                }
            //            }
            //        }
            //        else {
            //            let filteredDataNoEmail = projectIDHPlants.filter(item => item.mrpControllerEmail != "");

            //            if (filteredDataNoEmail.length > 0) {

            //                let emailCount = {};

            //                filteredDataNoEmail.forEach(item => {
            //                    emailCount[item.mrpControllerEmail] = (emailCount[item.mrpControllerEmail] || 0) + 1;
            //                });

            //                let maxDuplicateEmail = Object.keys(emailCount).filter(email => emailCount[email] > 1);
            //                let emailToPlaceintoEmptyEmail = "";
            //                if (maxDuplicateEmail.length > 0) {
            //                    emailToPlaceintoEmptyEmail = maxDuplicateEmail[0];
            //                } else {
            //                    emailToPlaceintoEmptyEmail = filteredDataNoEmail[0].mrpControllerEmail;
            //                }

            //                for (data of (projectIDHPlants.filter((r) => r.material === item.matnr && r.regionScope === item.regio))) {
            //                    if (data.mrpControllerEmail === "") {
            //                        data.mrpControllerEmail = emailToPlaceintoEmptyEmail;
            //                    }
            //                }

            //            }

            //        }
            //    }
           };
           const allIDHDataCheckNewPlant = new Set(projectIDHPlants?.map(item => ` ${item.material}_${item.regionScope}`));
           const resultDataPlant = projectIDHs?.filter(plant => allIDHDataCheckNewPlant?.has(` ${plant.material}_${plant.regionScope}`));

           projectIDHs = resultDataPlant;
           const result = {
               ProjectIDHs: projectIDHs,
               ProjectIDHPlants: projectIDHPlants
           }
           return result;

       }
    });
    // error handles
    function customErrorHandler(req, err) {
        const error = new Error(err.message);
        error.code = +err.code || +err.statusCode || 400;
        console.error(err);
        req.error(error);
    };
    function getUniqueMaterialRegionCombinations(materials) {
        const uniqueCombinations = new Set();
        const uniqueRecords = materials.filter(materialObj => {
            const uniqueKey = `${materialObj.matnr}_${materialObj.regio}`;
            if (!uniqueCombinations.has(uniqueKey)) {
                uniqueCombinations.add(uniqueKey);
                return true;
            }
            return false;
        });
        return uniqueRecords;
    };
    function getUniqueMaterialCombinations(materials) {
        const uniqueCombinations = new Set();
        const uniqueRecords = materials.filter(materialObj => {
            const uniqueKey = `${materialObj.material}`;
            if (!uniqueCombinations.has(uniqueKey)) {
                uniqueCombinations.add(uniqueKey);
                return true;
            }
            return false;
        });
        return uniqueRecords;
    };
    async function getOpenTransactions(plantList) {
        const material = plantList.material;
        const plant = plantList.plant;
        let region = plantList.regionScope;
        let source = plantList.sourceSystem;
        var openTransactions = {};
        openTransactions.material = material;
        openTransactions.plant = plant;
        openTransactions.OpenTransactions = "No";
        if (source === "") {
            const plants = await SELECT.from(ProjectIDHPlants).where({ material: material, plant: plant });
            source = plants[0].sourceSystem;
            if (region === "") {
                region = plants[0].regionScope;
            }
        }

        const Results = await SELECT.from(SalesBoms).where({ idnrk: material });
        if (Results.length !== 0) {
            openTransactions.SBOMPart = "Yes";
            openTransactions.BOMData = Results;
        } else {
            openTransactions.SBOMPart = "No";
        }
        if (source === "92") {
            const MatStocksApi = await cds.connect.to("MatStocks");
            const { stock_cal } = MatStocksApi.entities;
            const resultsCal = await MatStocksApi.run(SELECT.from(stock_cal)
                .where({ Material: material, Plant: plant, IsOtCall: true, Region: region }));
            // if (result.length !== 0) {
            //     openTransactions.OpenStock = result[0].Sum01;
            //     openTransactions.OpenDemand = result[0].Sum04;
            //     openTransactions.OpenOrders = result[0].Sum02;
            //     openTransactions.RAWPackFG = result[0].Sum01;
            //     openTransactions.UOM = result[0].Meins;
            // }
            if (resultsCal.length !== 0) {
                openTransactions.OpenStock = resultsCal[0].TsiQuant;
                openTransactions.OpenDemand = resultsCal[0].FixedIssues;
                openTransactions.OpenOrders = resultsCal[0].FixedReceipts;
                openTransactions.OtherMRPElements = resultsCal[0].OthMrpEle === 'Y' ? 'Yes' : 'No';
                openTransactions.RAWPackFG = "To be calculated";
                openTransactions.UOM = resultsCal[0].BaseUom;
            }
            for (let [key, value] of Object.entries(openTransactions)) {
                if (!["SBOMPart", "material", "plant", "BOMData", "UOM", "OtherMRPElements", "RAWPackFG", "OpenTransactions"].includes(key)) {
                    if (value > 0 || openTransactions.OtherMRPElements === 'Yes' || openTransactions.SBOMPart === "Yes") {
                        openTransactions.OpenTransactions = "Yes";
                        break;
                    }
                }
            }
        }
        else {
            const MatStocksApi = await cds.connect.to("APAC_MatStocks");
            const { stock_cal } = MatStocksApi.entities;
            const resultsCal = await MatStocksApi.run(SELECT.from(stock_cal)
                .where({ Material: material, Plant: plant, IsOtCall: true, Region: region }));

            // if (result.length !== 0) {
            //     // openTransactions.OpenStock = result[0].Sum01;
            //     openTransactions.OpenDemand = result[0].Sum04;
            //     openTransactions.OpenOrders = result[0].Sum02;
            //     openTransactions.RAWPackFG = result[0].Sum01;
            //     openTransactions.UOM = result[0].Meins;
            // }

            if (resultsCal.length !== 0) {
                openTransactions.OpenStock = resultsCal[0].TsiQuant;
                openTransactions.OpenDemand = resultsCal[0].FixedIssues;
                openTransactions.OpenOrders = resultsCal[0].FixedReceipts;
                openTransactions.OtherMRPElements = resultsCal[0].OthMrpEle === 'Y' ? 'Yes' : 'No';
                openTransactions.RAWPackFG = "To be calculated";
                openTransactions.UOM = resultsCal[0].BaseUom;
            }

            for (let [key, value] of Object.entries(openTransactions)) {
                if (!["SBOMPart", "material", "plant", "BOMData", "UOM", "OtherMRPElements", "RAWPackFG", "OpenTransactions"].includes(key)) {
                    if (value > 0 || openTransactions.OtherMRPElements === 'Yes' || openTransactions.SBOMPart === "Yes") {
                        openTransactions.OpenTransactions = "Yes";
                        break;
                    }
                }
            }

        }
        return openTransactions;
    };
    async function getmrpController(plantList) {

        if (plantList.mrpController) {
            const mrpid = plantList.mrpController;
            const plant = plantList.plant;

            if (plantList.sourceSystem === '92') {
                const PlannerApi = await cds.connect.to("Planner");
                // const { MrpCtrl } = PlannerApi.entities;
                let omrpDetails = await PlannerApi.send({
                    method: 'GET',
                    path: `/MrpCtrl(Werks='${plant}',Dispo='${mrpid}')?$expand=to_user_item`,
                });

                return {
                    mail: omrpDetails?.to_user_item.Email
                };
            } else {
                const PlannerApi = await cds.connect.to("APAC_Planner");
                // const { MrpCtrl } = PlannerApi.entities;
                let omrpDetails = await PlannerApi.send({
                    method: 'GET',
                    path: `/MrpCtrl(Werks='${plant}',Dispo='${mrpid}')?$expand=to_user_item`,
                });

                return {
                    mail: omrpDetails?.to_user_item.Email
                };
            }
        }

        return {
            mail: ""
        }
    };

    async function getctPlannerEmail(plantList) {

        if (plantList.ctPlanner) {
            const ctPlanner = plantList.ctPlanner;

            if (plantList.sourceSystem === "92") {
                const PlannerApi = await cds.connect.to("Planner");
                const { PlannerItem } = PlannerApi.entities;
                const result = await PlannerApi.run(SELECT.from(PlannerItem)
                    .where({ CtPlanner: ctPlanner }));

                if (result.length > 0)
                    return result[0];
            } else {
                const PlannerApi = await cds.connect.to("APAC_Planner");
                const { PlannerItem } = PlannerApi.entities;
                const result = await PlannerApi.run(SELECT.from(PlannerItem)
                    .where({ CtPlanner: ctPlanner }));

                if (result.length > 0)
                    return result[0];
            }
        }

        return {
            CtPlannerEmail: ""
        }
    };


    this.before(['CREATE', 'UPDATE'], 'ProjectHeaders', async (req) => {
        if (req.event === 'CREATE') {
            const DB = await cds.connect.to("db"),
                projectid = new SequenceHelper({
                    db: DB,
                    sequence: "PROJECTID",
                    table: "PPE_CM_PD_PROJECTHEADERS",
                    field: "PROJECTID",
                });
            req.data.projectID = await projectid.getNextNumber();
        }
        if (req.data.projectStatus_uuid === "dc18e443-c22b-4a0f-9b95-9ce796daffb9") {
            try {
                // 1. Validating Material-Region existence in existing projects
                //const currentProjectsIDHArray = req.data.projectIDHs;
                const currentProjectsIDHArray = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == true)
                const activeProjects = await SELECT.from(ProjectHeaders).columns('projectID', 'uuid', 'phaseOutScenario_id').where({ projectStatus_uuid: { 'not in': ['21c74e08-b4d6-4632-89b8-f6f33bb6cdb8', 'dae19016-c2da-47f4-9813-692f4b8d94d7'] } });
                //const activeProjects = await SELECT.from(ProjectHeaders).columns('projectID','uuid').where({ projectStatus_uuid:{ in: ['21c74e08-b4d6-4632-89b8-f6f33bb6cdb8']}});
                const activeProjectsArray = await materialRegionArray(activeProjects);
                const duplicates = findDuplicates(activeProjectsArray, currentProjectsIDHArray);

                if (duplicates.length > 0 && duplicates[0]?.phaseOutScenario_id == 'Scenario01') {
                    req.error({
                        message: `The following material-region combinations already exist in other projects:${JSON.stringify(duplicates)}`,
                        code: 'DUPLICATE_MATERIAL_REGION',
                        details: duplicates,
                        status: 400
                    });
                    return;
                }
                let getIDHValue = req.data.projectIDHs.map(item =>  item.material);
                if(duplicates[0]?.phaseOutScenario_id == 'Scenario02'){
                    let filteredPlants = req.data.projectIDHPlants?.filter(elm => elm.phaseOutNEEDED === "Yes");
                    //let plantsVal = filteredPlants?.map(item => item.plant);
                    for(let elm in filteredPlants){
                        
                        var filterMatPlantCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({material : filteredPlants[elm].material, plant : filteredPlants[elm].plant, statusText : { 'not in': ['Draft', 'Phase-Out Cancelled']}, phaseOutNEEDED : 'Yes', plant_status_uuid : {'not in' : ['a3549a6e-fd81-4b82-8caa-c19c93b431b8']}});
                            if(filterMatPlantCombo.length > 0){
                                req.error({
                                    message: `The plant has been already selected for phaseout`,
                                    code: 'DUPLICATE_MATERIAL_REGION',
                                    details: filteredPlants,
                                    status: 400
                                });
                                return req.errors;
                            }
                    }
                }
                // Validation for When an FG that is selected for phase out is part of another FG's 1 BOM, then it must not be allowed for phase out
                // 1. I am taking all the material from project idh 
                
                // 2. Checking this material present inside FG1BomItems table or not
                const { FG1BomItems } = cds.entities('ppe.cm.md');
                var checkFG1BomItemsTable = await SELECT.from(FG1BomItems).where({ idnrk: { "in": getIDHValue } });
                // 3. if any data will come from FG1BomItems Table for material then we will check further logic
                if (checkFG1BomItemsTable.length > 0) {
                    // 4. Checking coming material from FG1BomItems in Matplants table. 
                    var checkMatPlantTableStatus = await SELECT.from(MatPlants).where({
                        matnr: {
                            "in": checkFG1BomItemsTable?.map(item => item.matnr)
                        },
                        werks: {
                            "in": checkFG1BomItemsTable?.map(item => item.werks)
                        }
                    });
                    let checkStatus = ['Y2','Y3','Y4','Y1'];
                    //5 checking 'Y2','Y3','Y4','Y1' status of coming results from matplants table
                    var checkStatusOfMatplants = checkMatPlantTableStatus.filter(item => checkStatus.includes(item.mmsta));
                    //6 if any result is coming with 'Y2','Y3','Y4','Y1' status then only we are displaying error 
                    if (checkStatusOfMatplants.length > 0 && req.data.phaseOutScenario_id === 'Scenario01') {
                        // var idhNotincludeY5orY6 = new Set(checkStatusOfMatplants.map(item => item.matnr));
                        // var idhNotincludeY5orY6 = checkStatusOfMatplants.map(item => item.matnr);
                         const gettingAllFilteredStatusIDH = new Set(checkStatusOfMatplants.map(item => ` ${item.matnr}_${item.werks}`));
                         let displayIdhError = checkFG1BomItemsTable.filter(plant => gettingAllFilteredStatusIDH.has(` ${plant.matnr}_${plant.werks}`));
                             displayIdhError = Array.from(new Map(displayIdhError.map(item => [`${item.idnrk}_${item.werks}`, item])).values());
                        var arrOfMaterialsDisplay = [];
                        for(let mat of displayIdhError){
                            let obj = {};
                            obj.Material = mat.idnrk;
                            arrOfMaterialsDisplay.push(obj);
                        } 
                        req.error({
                            message: `The FG ${JSON.stringify(arrOfMaterialsDisplay)} is part of the Production BOM of another active FG and hence cannot be phased out`,
                            code: 'IDH_HAS_NOT_Y5_AND_Y6_STATUS',
                            details: arrOfMaterialsDisplay,
                            status: 400
                        });
                        return;
                    }
                }   
                // Validation for sales phase-out if for one material we have 3 sales area then we can phase-out only maximum 2 sales area '
                // Suppose for 1 material we have only 1 sales area then we are not checking this validation
                // We are also validating if we have sales area for diffent different material and plant then we need to select 1 sales area for phase out other wise it will throw error
                if (req.data.phaseOutScenario_id === 'Scenario03') {
                    let plantsData = req.data.projectIDHPlants;
                    let plantSalesDataPhaeout = req.data.projectIDHPlants.map(plant => ({
                        ...plant,
                        projectIDHSalesAreas: plant.projectIDHSalesAreas.map(sales => ({
                            ...sales,
                            material: plant.material,
                            plant: plant.plant,
                            regionScope: plant.regionScope
                        }))
                    }));
                    let filteredSalesDataOnly = plantSalesDataPhaeout.flatMap(obj => obj.projectIDHSalesAreas);
                    var allSalesAreaPhaseOut = [];
                    var allSalesAreaPhaseOutNotSingle = [];
                    for (let i in plantsData) {
                        let obj = {};
                        let obj1 = {};
                        var filterSalesDataPhaseOut = filteredSalesDataOnly.filter(item => item.material === plantsData[i].material && item.plant === plantsData[i].plant && item.regionScope === plantsData[i].regionScope);
                        if (filterSalesDataPhaseOut.length >= 1) {
                            var toCheclAllSelesAreaPhaseout = filterSalesDataPhaseOut.filter(item => item.phaseOutNEEDED === 'Yes');
                            if (filterSalesDataPhaseOut.length === toCheclAllSelesAreaPhaseout.length) {
                                obj.Material = plantsData[i].material;
                                obj.plant = plantsData[i].plant;
                                allSalesAreaPhaseOut.push(obj);
                            }
                            // if (toCheclAllSelesAreaPhaseout.length == 0) {
                            //     obj1.Material = plantsData[i].material;
                            //     obj1.plant = plantsData[i].plant;
                            //     allSalesAreaPhaseOutNotSingle.push(obj1);
                            // }
                        }
                    }
                    // if (allSalesAreaPhaseOutNotSingle?.length > 0) {
                    //     req.error({
                    //         message: `At least select 1 phase-out Sales area for given Material":${JSON.stringify(allSalesAreaPhaseOutNotSingle)}`,
                    //         code: 'AllPHASEOUT_SALES_AREA',
                    //         details: allSalesAreaPhaseOutNotSingle,
                    //         status: 400
                    //     });
                    //     return;
                    // }
                    if (allSalesAreaPhaseOut?.length > 0) {
                        req.error({
                            message: `We can not phase-out all the Sales area for given Material and Plant":${JSON.stringify(allSalesAreaPhaseOut)}`,
                            code: 'AllPHASEOUT_SALES_AREA',
                            details: allSalesAreaPhaseOut,
                            status: 400
                        });
                        return;
                    }
                }
                // Validation for sales area scenario 3 which sales area already submitted and another customer 
                if (req.data.phaseOutScenario_id === 'Scenario03') {
                    let plantSalesData = req.data.projectIDHPlants.map(plant => ({
                        ...plant,
                        projectIDHSalesAreas: plant.projectIDHSalesAreas.map(sales => ({
                            ...sales,
                            material: plant.material,
                            plant: plant.plant,
                            regionScope: plant.regionScope
                        }))
                    }));
                    let filteredData = plantSalesData.flatMap(obj => obj.projectIDHSalesAreas);
                    let filteredDataPhaseOut = filteredData.filter(item => item.phaseOutNEEDED === 'Yes');
                    var salesDuplicate = [];
                    let filterSalesOnPhaseOutNeeded;
                    for (let i in filteredDataPhaseOut) {
                        let obj = {};
                        let filterSalesCombo = await SELECT.from(IdhProjectPlantSalesInfo).where({ material: filteredDataPhaseOut[i].material, plant: filteredDataPhaseOut[i].plant, salesOrg: filteredDataPhaseOut[i].salesOrg, distChanel: filteredDataPhaseOut[i].distChanel, statusText: { 'not in': ['Draft', 'Phase-Out Cancelled'] } });
                        if (filterSalesCombo?.length > 0) {
                            if (filterSalesCombo[0].ProjectPhaseOutScenario === 'Scenario01') {
                                filterSalesOnPhaseOutNeeded = filterSalesCombo.filter(item => item.phaseOutNEEDED === "Yes");
                            } else {
                                filterSalesOnPhaseOutNeeded = filterSalesCombo.filter(item => item.salesPhaseOutneeded === "Yes");
                            }
                            if (filterSalesOnPhaseOutNeeded?.length > 0) {
                                obj.ProjectID = filterSalesOnPhaseOutNeeded[0].projectID;
                                obj.Material = filterSalesOnPhaseOutNeeded[0].material;
                                obj.plant = filterSalesOnPhaseOutNeeded[0].plant;
                                obj.salesOrg = filterSalesOnPhaseOutNeeded[0].salesOrg;
                                salesDuplicate.push(obj);
                            }
                        }

                    }
                    if (salesDuplicate?.length > 0) {
                        req.error({
                            message: `This Sales area is already submitted:${JSON.stringify(salesDuplicate)}`,
                            code: 'DUPLICATE_SALES_AREA',
                            details: salesDuplicate,
                            status: 400
                        });
                        return;
                    }
                }
                // validation closed

                // Phase Out not possible for the following IDH since the regions NOT selected for Phase out do not have any Production Plants available.
                // If any materials have mixed region status (some true, some false for phaseOutNeeded)
                // let getIDHValue = req.data.projectIDHs.map(item =>  item.material);
                // let checkingPhaseOutyesIDH = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == true);
                let getIDHValuePhaseOutYes = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == true)?.map(item => item.material);
                for (material of getIDHValuePhaseOutYes) {
                    const currentProjectIDHPlantsArrayFilter = req.data.projectIDHPlants.filter(item => item.phaseOutNEEDED == 'No' && item.material == material);
                    const currentProjectIDHPlantArrayFilterYes = req.data.projectIDHPlants.filter(item => item.phaseOutNEEDED == 'Yes' && item.material == material);
                    var materialNoProducitonPlant = [];
                    if (currentProjectIDHPlantArrayFilterYes.length > 0) {
                        let object = {}
                        let productionPlantYesforIDH = await SELECT.from(FG1Boms).where({
                            matnr: {
                                "in": currentProjectIDHPlantArrayFilterYes?.map(item => item.material)
                            },
                            werks: {
                                "in": currentProjectIDHPlantArrayFilterYes?.map(item => item.plant)
                            },
                            stlan: "1"
                        });
                        if (productionPlantYesforIDH.length > 0 && currentProjectIDHPlantsArrayFilter.length > 0) {
                            let productionPlantNoforIDH = await SELECT.from(FG1Boms).where({
                                matnr: {
                                    "in": currentProjectIDHPlantsArrayFilter?.map(item => item.material)
                                },
                                werks: {
                                    "in": currentProjectIDHPlantsArrayFilter?.map(item => item.plant)
                                },
                                stlan: "1"
                            });
                            if (productionPlantNoforIDH.length === 0) {
                                for (item of productionPlantNoforIDH) {
                                    object.Material = item.matnr;
                                    materialNoProducitonPlant.push(object);
                                }
                            }
                        }
                    }
                    
                    // const materialwithPlantGroup = new Map();
                    // currentProjectIDHPlantArrayFilterYes.forEach(item => {
                    //     if (!materialwithPlantGroup.has(item.material)) {
                    //         materialwithPlantGroup.set(item.material, new Set());
                    //     }
                    //     materialwithPlantGroup.get(item.material).add(item);
                    // });
                    // var fg1BomsResult3;
                    // var materialNoProducitonPlant = [];
                    // var booleancheck = true;
                    // for await (let [material, record] of materialwithPlantGroup.entries()) {
                    //     booleancheck = true;
                    //     let object = {}
                    //     for await (let rec of record) {
                    //         fg1BomsResult3 = await SELECT.from(FG1Boms).where({ matnr: material, werks: rec.plant, stlan: '1' });
                    //         if (fg1BomsResult3.length == 1) {
                    //             booleancheck = false;
                    //             break;
                    //         }
                    //     }
                    //     if (booleancheck) {
                    //         object.Material = material;
                    //         materialNoProducitonPlant.push(object);
                    //     }
                    // }
                    if (materialNoProducitonPlant.length > 0 && req.data.phaseOutScenario_id === 'Scenario01') {
                        req.error({
                            message: `Phase Out not possible for the following IDH since the regions NOT selected for Phase out do not have any Production Plants available:${JSON.stringify(materialNoProducitonPlant)}`,
                            code: 'DUPLICATE_MATERIAL_REGION',
                            details: materialNoProducitonPlant,
                            status: 400
                        });
                        return;
                    }
                }
                // Please select Plant for All added IDHs or delete the IDH If you don't want to phase-out we are doing validation for scenario 2 if for each idh at least one plant is not selected
                // in this also we are checking production plant for selected plant for phase out 
                if (req.data.phaseOutScenario_id === 'Scenario02') {
                    let totalIDHResult = req.data.projectIDHs;
                    let phaseoutIDHResult = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == true);
                    if ((totalIDHResult.length != phaseoutIDHResult.length) || phaseoutIDHResult.length > 0) {
                        var plantForError = [];
                        var productionPlantResults = [];
                        for (idh of totalIDHResult) {
                            let obj = {};
                            let obj1 = {};
                            let filterIDHPlantResult = req.data.projectIDHPlants.filter(item => item.material == idh.material);
                            let filterPlantPhaseOutNeededYes = filterIDHPlantResult.filter(item => item.phaseOutNEEDED == 'Yes');
                            let filterPlantPhaseoutNo = filterIDHPlantResult.filter(item => item.phaseOutNEEDED === 'No');
                            if (filterPlantPhaseOutNeededYes.length == 0) {
                                obj.Material = filterIDHPlantResult[0].material;
                                obj.Plant = filterIDHPlantResult[0].plant;
                                plantForError.push(obj);
                            }
                            if (filterPlantPhaseOutNeededYes.length > 0) {
                                let productionPlantYes = await SELECT.from(FG1Boms).where({
                                    matnr: {
                                        "in": filterPlantPhaseOutNeededYes?.map(item => item.material)
                                    },
                                    werks: {
                                        "in": filterPlantPhaseOutNeededYes?.map(item => item.plant)
                                    },
                                    stlan: "1"
                                });
                                if (productionPlantYes.length > 0 && filterPlantPhaseoutNo.length > 0) {
                                    // let matttt = filterPlantPhaseoutNo.map(item => item.material);
                                    let remainingProductionPlantYes = await SELECT.from(FG1Boms).where({
                                        matnr: {
                                            "in": filterPlantPhaseoutNo.map(item => item.material)
                                        },
                                        werks: {
                                            "in": filterPlantPhaseoutNo.map(item => item.plant)
                                        },
                                        stlan: "1"
                                    });
                                    if (remainingProductionPlantYes.length == 0) {
                                        for (item of remainingProductionPlantYes) {
                                            obj1.Material = item.matnr;
                                            obj1.Plant = item.werks;
                                            productionPlantResults.push(obj);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (plantForError.length > 0) {
                        req.error({
                            message: `Please select atleast one plant per material for phase out or remove the material:${JSON.stringify(plantForError)}`,
                            code: 'Plant_Region_Not_Selected_PhaseOut',
                            details: plantForError,
                            status: 400
                        });
                        return;
                    }
                    if (productionPlantResults.length > 0) {
                        req.error({
                            message: `Phase Out not possible for the following IDH since the regions NOT selected for Phase out do not have any Production Plants available:${JSON.stringify(productionPlantResults)}`,
                            code: 'DUPLICATE_PLANT_REGION',
                            details: productionPlantResults,
                            status: 400
                        });
                        return;
                    }
                }
                // At least one material should be selected for phase out
                // if material do not have any phaseout needed false we are skipping.
                // if (req.data.phaseOutScenario_id === 'Scenario01') {
                    if ((req.data.projectIDHs.filter(item => item.phaseOutNEEDED == false)).length == 0) {
                        return;
                    }
                    var materialWithYesPhaseout = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == true)
                    var materialWithNoPhaseout = req.data.projectIDHs.filter(item => item.phaseOutNEEDED == false)
                    if (materialWithYesPhaseout.length == 0 && materialWithNoPhaseout.length >= 0) {
                        req.error({
                            message: `At least one material should be selected for phase out`,
                            code: 'ATLEAST_ONCE_OPTPHASEOUT',
                            status: 400
                        });
                        return;
                    }
                // }
                // If no any material having phaseout true belongs to any of the material having phase out false then we are skipping.
                var validateBolean = true;
                for (yes of materialWithYesPhaseout) {
                    for (no of materialWithNoPhaseout) {
                        if (no.material == yes.material) {
                            validateBolean = false;
                            break
                        }
                    }
                    if (!validateBolean) {
                        break;
                    }
                }
                if (validateBolean) {
                    return;
                }

            // }
                 

            } catch (err) {
                req.error({
                    message: `An error occurred during the validation: ${err.message}`,
                    code: 'VALIDATION_ERROR',
                    status: 500
                });
            }
        }

    });
    //@peeyush for valdiaiton     
    async function getProjectMaterials(uuid_project) {
        return await cds.run(
            SELECT.from(ProjectIDHs).columns('material', 'regionScope').where({ l_ev_uuid: uuid_project, phaseOutNEEDED: true, phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }})
        )
    };

    async function materialRegionArray(activeProjects) {
        const projectMaterialRegionArray = [];
        // Iterate over each project
        for (const project of activeProjects) {
            // Get the materials for the project (await the result)
            const projectMaterials = await getProjectMaterials(project.uuid);
            for (const material of projectMaterials) {
                projectMaterialRegionArray.push({
                    projectID: project.projectID,
                    material: material.material,
                    regionScope: material.regionScope,
                    phaseOutScenario_id : project.phaseOutScenario_id,
                });
            }
        }
        return projectMaterialRegionArray;
    };

    function findDuplicates(activeProjectsArray, currentProjectsIDHArray) {
        const duplicates = [];
        var object = {}

        // Iterate over currentProjectsIDHArray using for...of
        for (const currentProject of currentProjectsIDHArray) {
            // Directly access properties of currentProject
            for (const activeProject of activeProjectsArray) {
                if (activeProject.material === currentProject.material
                    && activeProject.regionScope === currentProject.regionScope && activeProject.phaseOutNEEDED == true) {
                    //duplicates.push("Material "+currentProject.material+" Region "+ currentProject.regionScope);
                    object.Material = currentProject.material;
                    object.RegionScope = currentProject.regionScope;
                    object.phaseOutScenario_id = activeProject.phaseOutScenario_id;
                    object.projectID = activeProject.projectID;
                    duplicates.push(object);
                    object = {};
                    break;
                }
            }
        }
        return duplicates;
    };
    // End @peeyush for valdiaiton 

    this.after(['CREATE', 'UPDATE'], 'ProjectHeaders', async (res, req) => {
        if (res.projectStatus_uuid === "dc18e443-c22b-4a0f-9b95-9ce796daffb9") {

            const { ProjectHeaders } = cds.entities("ComplexityManagement");

            // fetch necessary project details for the workflow
            let projectDetails = await SELECT.from(ProjectHeaders).columns(projectHeader => {
                projectHeader.uuid,
                    projectHeader.projectID,
                    projectHeader.projectDescription,
                    projectHeader.phaseOutManager,
                    projectHeader.phaseOutManagerEmail,
                    projectHeader.phaseOutDate,
                    projectHeader.phaseOutScenario_id,
                    projectHeader.projectStatus(projectStatus => {
                        projectStatus.projectStatus
                    }),
                    projectHeader.createdFrom,
                    projectHeader.createdAt,
                    projectHeader.createdBy,
                    projectHeader.projectIDHs(projectIdh => {
                        projectIdh.uuid,
                            projectIdh.material,
                            projectIdh.regionScope,
                            projectIdh.phaseOutNEEDED,
                            projectIdh.phaseOutDate,
                            projectIdh.phaseOutStatus(phaseOutStatus => {
                                phaseOutStatus.projectStatus
                            }),
                            projectIdh.subsMaterial,
                            projectIdh.phaseOutScenario,
                            projectIdh.materialText,
                            projectIdh.subsMaterialText,
                            projectIdh.workflowFlag
                    }),
                    projectHeader.projectIDHPlants(projectIdhPlant => {
                        projectIdhPlant.uuid,
                            projectIdhPlant.material,
                            projectIdhPlant.materialText,
                            projectIdhPlant.plant,
                            projectIdhPlant.regionScope,
                            projectIdhPlant.plantYSTATUS,
                            projectIdhPlant.phaseOutNEEDED,
                            projectIdhPlant.phaseOutDate,
                            projectIdhPlant.openTransaction,
                            projectIdhPlant.phaseOutStatus(phaseOutStatus => {
                                phaseOutStatus.projectStatus
                            }),
                            projectIdhPlant.workflowFlag,
                            projectIdhPlant.mrpController,
                            projectIdhPlant.mrpControllerEmail,
                            projectIdhPlant.ctPlanner,
                            projectIdhPlant.ctPlannerEmail,
                            projectIdhPlant.projectIDHSalesAreas(projectIDHSalesAreas => {
                                projectIDHSalesAreas.uuid,
                                    projectIDHSalesAreas.salesyStatus,
                                    projectIDHSalesAreas.salesCountry,
                                    projectIDHSalesAreas.salesOrg,
                                    projectIDHSalesAreas.distChanel
                            })
                    })
            }).where({
                uuid: res.uuid
            });
            projectDetails[0].projectIDHs = projectDetails[0].projectIDHs.filter(idh => idh.phaseOutNEEDED === true);
            const uniqueMaterial = getUniqueMaterialCombinations(projectDetails[0].projectIDHs);
            let projectIDHs = [], projectIdhPlant = [];

              for await (const item of uniqueMaterial) {
                if (projectDetails[0].phaseOutScenario_id === "Scenario03") {
                    projectDetails[0].phaseOutDate = new Date().toISOString().split('T')[0];
                    projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'No');
                    projectIdhPlant = projectIdhPlant.map(items => ({
                        ...items,
                        phaseOutDate: new Date().toISOString().split('T')[0]
                    }));
                } else {
                    projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'Yes');
                }
                // projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'Yes');
                //&& idhPlant.regionScope === item.regionScope);
                if (projectDetails[0].phaseOutScenario_id === "Scenario03") {
                    projectIDHs = projectDetails[0].projectIDHs.filter(idh => idh.material === item.material);
                    projectIDHs = projectIDHs.map(items => ({
                        ...items,
                        phaseOutDate: new Date().toISOString().split('T')[0]
                    }));
                } else {
                    projectIDHs = projectDetails[0].projectIDHs.filter(idh => idh.material === item.material);
                }

                let oContext = {
                    projectHeader: {
                        uuid: projectDetails[0].uuid,
                        projectID: projectDetails[0].projectID,
                        projectDescription: projectDetails[0].projectDescription,
                        phaseOutManager: projectDetails[0].phaseOutManager,
                        phaseOutManagerEmail: projectDetails[0].phaseOutManagerEmail,
                        phaseOutDate: projectDetails[0].phaseOutDate,
                        createdFrom: projectDetails[0].createdFrom,
                        createdOn: projectDetails[0].createdAt,
                        createdBy: projectDetails[0].createdBy,
                        projectStatus: projectDetails[0].projectStatus.projectStatus,
                        phaseOutScenario_id : projectDetails[0].phaseOutScenario_id
                    },
                    projectIdh: projectIDHs,
                    projectIdhPlant: projectIdhPlant
                }

                // trigger process flow
                const pfApi = await cds.connect.to("CmProcessFlow");

                await pfApi.send({
                    method: 'POST',
                    path: '/workflow-instances',
                    data: {
                        "definitionId": "eu10.henkel-dev-sap-build.prhatidhfullblownphaseout.wF_HAT_IDH_Full_Phase_Out",
                        "context": oContext
                    }
                });
            }
            /////// change/////
            //Start write down IB Status change - Details to be written to X03 table.
            let resultIbIDHData = await this.getDepObjIbProducts(req.data.uuid);
            /*let resultIbIDHData = await SELECT.from(DepObjIbProducts)
                .columns(
                    DepObjIbProducts.material,
                    DepObjIbProducts.ibProduct,
                    DepObjIbProducts.projectId
                )
                .where({
                    projectUuid: req.data.uuid
                }
                );
                */

            if (resultIbIDHData || resultIbIDHData.length > 0) {
                let dataXo3 = "";

                for await (const itemIbData of resultIbIDHData) {
                    dataXo3 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST phout HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"ProjectId": "${itemIbData.projectId}", "Material": "${itemIbData.material}", "IbProduct": "${itemIbData.ibProduct}"}\r\n\r\n\r\n`;
                }
                dataXo3 = dataXo3 + `--batch--`;
                try {
                    let oSAPConnection = await cds.connect.to("YMXIDH_AIP");
                    await oSAPConnection.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: dataXo3
                    });

                } catch (error) {
                    cds.log("XO3_Connection").error("Error Occurred on POST-->", { error });
                }



            }
            //end write IB Status change - Details to be written to P03 table.

            const scheduler = new JobSchedulerClient.Scheduler();
            var mySchedule = {
                "data": {
                    "projectId": projectDetails[0].projectID
                },
                "active": true,
                "time": "now"
            };
            var req = {
                jobId: process.env.jobId,//1332929,
                schedule: mySchedule
            };
            scheduler.createJobSchedule(req, function (err, result) {
                if (err) {

                    cds.log("jobfailedLog").error(err);

                    return;

                }
                //Schedule created successfully
            });

            ////

            // for await (const item of uniqueMaterial) {
            //     if (projectDetails[0].phaseOutScenario_id === "Scenario03") {
            //         projectDetails[0].phaseOutDate = new Date().toISOString().split('T')[0];
            //         projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'No');
            //         projectIdhPlant = projectIdhPlant.map(items => ({
            //             ...items,
            //             phaseOutDate: new Date().toISOString().split('T')[0]
            //         }));
            //     } else {
            //         projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'Yes');
            //     }
            //     // projectIdhPlant = projectDetails[0].projectIDHPlants.filter(idhPlant => idhPlant.material === item.material && idhPlant.phaseOutNEEDED === 'Yes');
            //     //&& idhPlant.regionScope === item.regionScope);
            //     if (projectDetails[0].phaseOutScenario_id === "Scenario03") {
            //         projectIDHs = projectDetails[0].projectIDHs.filter(idh => idh.material === item.material);
            //         projectIDHs = projectIDHs.map(items => ({
            //             ...items,
            //             phaseOutDate: new Date().toISOString().split('T')[0]
            //         }));
            //     } else {
            //         projectIDHs = projectDetails[0].projectIDHs.filter(idh => idh.material === item.material);
            //     }

            //     let oContext = {
            //         projectHeader: {
            //             uuid: projectDetails[0].uuid,
            //             projectID: projectDetails[0].projectID,
            //             projectDescription: projectDetails[0].projectDescription,
            //             phaseOutManager: projectDetails[0].phaseOutManager,
            //             phaseOutManagerEmail: projectDetails[0].phaseOutManagerEmail,
            //             phaseOutDate: projectDetails[0].phaseOutDate,
            //             createdFrom: projectDetails[0].createdFrom,
            //             createdOn: projectDetails[0].createdAt,
            //             createdBy: projectDetails[0].createdBy,
            //             projectStatus: projectDetails[0].projectStatus.projectStatus,
            //             phaseOutScenario_id : projectDetails[0].phaseOutScenario_id
            //         },
            //         projectIdh: projectIDHs,
            //         projectIdhPlant: projectIdhPlant
            //     }

            //     // trigger process flow
            //     const pfApi = await cds.connect.to("CmProcessFlow");

            //     await pfApi.send({
            //         method: 'POST',
            //         path: '/workflow-instances',
            //         data: {
            //             "definitionId": "eu10.henkel-dev-sap-build.prhatidhfullblownphaseout.wF_HAT_IDH_Full_Phase_Out",
            //             "context": oContext
            //         }
            //     });
            // }
            
            return;

        }
    });
    /*  this.after(['READ'], 'ProjectIDHPlants', async (res, req) => {
          var openTransactions = await getOpenTransactions(res);
          if (openTransactions.OpenTransactions === "Yes") {
              res.openTransaction = "Yes";
          } else {
              res.openTransaction = "No";
          }
      });*/

    this.on('getOpenTransactions', async (req) => {
        const material = req.data.material;
        const plant = req.data.plant;
        let region = '';
        let source = req.data.source;
        var openTransactions = {};
        openTransactions.material = material;
        openTransactions.plant = plant;
        if (source === "") {
            const plants = await SELECT.from(ProjectIDHPlants).where({ material: material, plant: plant });
            source = plants[0].sourceSystem;
            region = plants[0].regionScope;
        }

        const Results = await SELECT.from(SalesBoms).where({ idnrk: material });
        if (Results.length !== 0) {
            openTransactions.SBOMPart = "Yes";
            openTransactions.BOMData = Results;
        } else {
            openTransactions.SBOMPart = "No";
        }
        if (source === "92") {
            const MatStocksApi = await cds.connect.to("MatStocks");
            const { stock_cal } = MatStocksApi.entities;
            // const result = await MatStocksApi.run(SELECT.from(Stock)
            //     .where({ Material: material, Plant: plant }));
            const resultsCal = await MatStocksApi.run(SELECT.from(stock_cal)
                .where({ Material: material, Plant: plant, IsOtCall: true, Region: region }));

            if (resultsCal.length !== 0) {
                openTransactions.OpenStock = resultsCal[0].TsiQuant;
                openTransactions.OpenDemand = resultsCal[0].FixedIssues;
                openTransactions.OpenOrders = resultsCal[0].FixedReceipts;
                openTransactions.OtherMRPElements = resultsCal[0].OthMrpEle === 'Y' ? 'Yes' : 'No';
                openTransactions.RAWPackFG = "To be calculated";
                openTransactions.UOM = resultsCal[0].BaseUom;
            }
            for (let [key, value] of Object.entries(openTransactions)) {
                // if (key !== "SBOMPart" && key !== "material" && key !== "plant" && key !== "BOMData" && key !== "UOM") {
                if (!["SBOMPart", "material", "plant", "BOMData", "UOM", "OtherMRPElements", "RAWPackFG", "OpenTransactions"].includes(key)) {
                    if (value > 0 || openTransactions.OtherMRPElements === 'Yes') {
                        // if (value > 0) {
                        openTransactions.OpenTransactions = "Yes";
                        break;
                    }
                }
            }
        }
        else {
            const MatStocksApi = await cds.connect.to("APAC_MatStocks");
            const { stock_cal } = MatStocksApi.entities;
            const resultsCal = await MatStocksApi.run(SELECT.from(stock_cal)
                .where({ Material: material, Plant: plant, IsOtCall: true, Region: region }));

            if (resultsCal.length !== 0) {
                openTransactions.OpenStock = resultsCal[0].TsiQuant;
                openTransactions.OpenDemand = resultsCal[0].FixedIssues;
                openTransactions.OpenOrders = resultsCal[0].FixedReceipts;
                openTransactions.OtherMRPElements = resultsCal[0].OthMrpEle === 'Y' ? 'Yes' : 'No';
                openTransactions.RAWPackFG = "To be calculated";
                openTransactions.UOM = resultsCal[0].BaseUom;
            }


            for (let [key, value] of Object.entries(openTransactions)) {
                if (!["SBOMPart", "material", "plant", "BOMData", "UOM", "OtherMRPElements", "RAWPackFG", "OpenTransactions"].includes(key)) {
                    if (value > 0 || openTransactions.OtherMRPElements === 'Yes') {
                        openTransactions.OpenTransactions = "Yes";
                        break;
                    }
                }
            }

        }
        return openTransactions;

    });

    this.on('getOpenTransactionsSa', async (req) => {
        const material = req.data.material;
        const salesOrg = req.data.salesOrg;
        const distChanel = req.data.distChanel;
        let source = req.data.source;
        let result;

        if (source === "") {
            const salesAreas = await SELECT.from(ProjectIDHSalesArea).where({ salesOrg: salesOrg, distChanel: distChanel });
            source = salesAreas[0].sourceSystem;
        }

        if (source === "92") {
            const OpenSOApi = await cds.connect.to("OpenSO");
            const { OpenSO4Sa } = OpenSOApi.entities;

            result = await OpenSOApi.run(
                SELECT.one.from(OpenSO4Sa)
                    .byKey({ Material: material, Vkorg: salesOrg, Vtweg: distChanel })
            );
        }
        else {
            const OpenSOApi = await cds.connect.to("APAC_OpenSO");
            const { OpenSO4Sa } = OpenSOApi.entities;

            result = await OpenSOApi.run(
                SELECT.one.from(OpenSO4Sa)
                    .byKey({ Material: material, Vkorg: salesOrg, Vtweg: distChanel })
            );
        }
        return result ? parseFloat(result.Quantity).toFixed(3) : 0;
    });

    async function getOpenTransactionsSa(req) {
        const material = req.material;
        const salesOrg = req.salesOrg;
        const distChanel = req.distChanel;
        let source = req.sourceSystem;
        let result;

        if (source === "") {
            const salesAreas = await SELECT.from(ProjectIDHSalesArea).where({ salesOrg: salesOrg, distChanel: distChanel });
            source = salesAreas[0].sourceSystem;
        }

        if (source === "92") {
            const OpenSOApi = await cds.connect.to("OpenSO");
            const { OpenSO4Sa } = OpenSOApi.entities;

            result = await OpenSOApi.run(
                SELECT.one.from(OpenSO4Sa)
                    .byKey({ Material: material, Vkorg: salesOrg, Vtweg: distChanel })
            );
        }
        else {
            const OpenSOApi = await cds.connect.to("APAC_OpenSO");
            const { OpenSO4Sa } = OpenSOApi.entities;

            result = await OpenSOApi.run(
                SELECT.one.from(OpenSO4Sa)
                    .byKey({ Material: material, Vkorg: salesOrg, Vtweg: distChanel })
            );
        }
        return result ? parseFloat(result.Quantity).toFixed(3) : 0;
    };

    this.on('updateProjectIDHPlant', async (req) => {
        const uuid = req.data.uuid;
        const material = req.data.material;
        const status = req.data.status;
        const mrp = req.data.mrp;
        //Category is introduced to handle different places the status is changed from in the workkflow
        const category = req.data.category;
        const plant = req.data.plant;

        // if MRP controller is received then it is SP form plant status update
        // else it is BP update which is for all plants together
        if (category === "SP") {
            await UPDATE(ProjectIDHPlants)
                .data({ phaseOutStatus_uuid: status })
                .where({ l_ev_uuid: uuid, material: material, mrpController: mrp, phaseOutNEEDED: `Yes` });
        }
        else if (category === "BP") {
            await UPDATE(ProjectIDHPlants)
                .data({ phaseOutStatus_uuid: status })
                .where({ l_ev_uuid: uuid, material: material, phaseOutNEEDED: `Yes` });
        }
        else {
            await UPDATE(ProjectIDHPlants)
                .data({ phaseOutStatus_uuid: status })
                .where({ l_ev_uuid: uuid, material: material, plant: plant, phaseOutNEEDED: `Yes` });

        }

        // fetch current status code and identifier
        let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
            uuid: status
        });

        // fetch entire plant table status identifiers
        let aAllPlantStatus = await SELECT.from(ProjectIDHPlants).columns(`phaseOutStatus_uuid`).where({
            l_ev_uuid: uuid,
            material: material,
            phaseOutNEEDED: `Yes`
        });

        const aAllPlantUuids = aAllPlantStatus.map(item => item.phaseOutStatus_uuid);

        if (aAllPlantUuids.length > 0) {
            // fetch all plant status ordered by code ascending
            let aRegionStatus = await SELECT.from(ProjectStatuses).columns(`code`, `uuid`).where({
                uuid: {
                    in: aAllPlantUuids
                }
            }).orderBy(`code`);

            // if received status is smaller then take the status identifier of received code
            // else take the status identifier of the index 0 (since it has min value in this index)
            const finalMinStatus = oCurrentStatus.code <= aRegionStatus[0].code ? oCurrentStatus.uuid : aRegionStatus[0].uuid;
            await UPDATE(ProjectIDHs).with({
                phaseOutStatus_uuid: finalMinStatus
            }).where({
                l_ev_uuid: uuid,
                material: material
            });
        } else {
            cds.log("IDHPhaseOutUpdateInfo").info("The phase out date is not updated at IDH level");
        }

        return 'Success';

    });

    this.on("READ", "ProjectIDHDepObjs", async (req, res) => {
        let projectIDHDepObjs = [];
        // read uuid
        const projectUUID = extractFilters(req, 'project_uuid');
        if (!projectUUID) return projectIDHDepObjs;

        const btn_color = { blue: 'Neutral', orange: 'Critical', green: 'Accept' };


        // define data array for the dependent objects table

        let depObj = {};
        depObj.project_uuid = projectUUID;

        // IB Product
        depObj.ibProduct = 'X';
        depObj.ibProductData = await this.getDepObjIbProducts(projectUUID);

        if (depObj.ibProductData && depObj.ibProductData.length !== 0) {
            let is_notIbProdPhasedout = depObj.ibProductData.some(entry => entry.ibStatus != 'DEL');
            depObj.ibProductColor = is_notIbProdPhasedout ? btn_color.blue : btn_color.green;
        } else {
            depObj.ibProductColor = btn_color.orange;
        };

        // RSN
        depObj.rsn = 'X';
        depObj.rsnData = await this.getDepObjRsns(projectUUID);

        if (depObj.rsnData && depObj.rsnData.length !== 0) { depObj.rsnColor = btn_color.blue } else { depObj.rsnColor = btn_color.orange };

        // BOM
        depObj.firstBom = 'X';
        depObj.firstBomData = await this.getDepObjBoms(projectUUID);
        if (depObj.firstBomData && depObj.firstBomData.length !== 0) {
            let is_notBomPhasedout = depObj.firstBomData.some(entry => entry.bom_stat != 'Inactive');
            depObj.firstBomColor = is_notBomPhasedout ? btn_color.blue : btn_color.green;
        } else {
            depObj.firstBomColor = btn_color.orange;
        };

        depObj.masterRecipePrdVersion = 'X';
        depObj.masterRecipePrdVersionData = await this.getDepObjMasterRecipePrdVersion(projectUUID);
        if (depObj.masterRecipePrdVersionData && depObj.masterRecipePrdVersionData.length !== 0) {
            let is_notRecipePhasedout = depObj.masterRecipePrdVersionData.some(entry => entry.usage != '1');
            depObj.masterRecipePrdVersionColor = is_notRecipePhasedout ? btn_color.blue : btn_color.green;
        } else {
            depObj.masterRecipePrdVersionColor = btn_color.orange;
        };

        depObj.pirSourceList = 'X';
        depObj.pirSourceListData = await this.getDepObjDepObjPirSourceList(projectUUID);
        if (depObj.pirSourceListData && depObj.pirSourceListData.length !== 0) {
            let is_notEinePhasedout = depObj.pirSourceListData.some(entry => entry.eineLoekz != 'X');
            let is_notEinaPhasedout = depObj.pirSourceListData.some(entry => entry.einaLoekz != 'X');
            depObj.pirSourceListColor = (is_notEinePhasedout || is_notEinaPhasedout) ? btn_color.blue : btn_color.green;
        } else {
            depObj.pirSourceListColor = btn_color.orange;
        };


        projectIDHDepObjs.push(depObj);

        return projectIDHDepObjs;

    });

    this.on('getDepObjIbProducts', async (req) => {
        const uuid = req.data.uuid;

        const materials = await SELECT.from(ProjectIDHs).where({ l_ev_uuid: uuid, phaseOutNEEDED: true });

        // read project-ID
        let projectIds = await SELECT.from(ProjectHeaders)
            .columns(ProjectHeaders.projectID)
            .where({ uuid: uuid });
        let projectId = projectIds[0].projectID;

        let data03 = ``, oJobStatus = {};

        for await (let material of materials) {
            data03 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET ibDepobj?$filter=Material%20eq%20%27${material.material}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
        }

        data03 = data03 + `--batch--`;

        let result = [], mappedResult = [];

        const aPromises = [];

        if (data03) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const IbApi = await cds.connect.to("YMXIDH_AIP");
                try {
                    const response = await IbApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data03
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }


        await Promise.allSettled(aPromises).then(async (aResponses) => {
            for (let response of aResponses) {
                if (response.status === 'fulfilled') {
                    // batch response needs to be decoded to identify individual one's
                    // so use regex to find out JSON outputs from the total batch response
                    let regex = /\{.*\}/g,
                        oEachResponseIterator = response.value.matchAll(regex);

                    // use JSON parse to parse the string to JSON
                    for await (let response of oEachResponseIterator) {
                        const finalResponse = JSON.parse(response[0]).value;
                        if (finalResponse && Array.isArray(finalResponse))
                            result = finalResponse.length > 0 ? result.concat(finalResponse) : result;
                    }
                } else {
                    error03 = true;
                    cds.log("03failed").error(response.reason.message);
                }
            }
        });

        for (const line of result) {

            let Idh = materials.filter((r) => r.material == line.Material);
            let new_result = {};
            new_result.projectUuid = uuid;
            new_result.projectId = projectId;
            new_result.material = line.Material;
            new_result.materialDescription = Idh[0]?.materialText;
            new_result.ibProduct = line.IbProduct;
            new_result.ibName = line.IbName;
            new_result.ibStatus = line.IbStatus;
            mappedResult.push(new_result);
        }

        if (!mappedResult || mappedResult.length === 0) {
            mappedResult = [];
        }

        mappedResult = mappedResult.filter((obj, index, self) =>
            index === self.findIndex((t) => t.material === obj.material && t.ibProduct === obj.ibProduct)
        );

        return mappedResult;

    });

    this.on("READ", "DepObjRsns", async (req, res) => {

        // read uuid
        const projectUUID = extractFilters(req, 'projectUuid');

        return await this.getDepObjRsns(projectUUID);
    });

    this.on('getDepObjRsns', async (req) => {
        const uuid = req.data.uuid;
        let resultRsn = rsnLinks = [];

        // read rsn from HDI
        let Rsns = await SELECT.from(DepObjLinkedRsns)
            .columns(
                DepObjLinkedRsns.rsn,
                DepObjLinkedRsns.material,
                DepObjLinkedRsns.rsnStatus

            )
            .where({
                projectUuid: uuid
            }
            );

        // read project-ID
        let projectIds = await SELECT.from(ProjectHeaders)
            .columns(ProjectHeaders.projectID)
            .where({ uuid: uuid });
        let projectId = projectIds[0].projectID;

        // read RSN-Materials
        const LinkedRsnApi = await cds.connect.to("MaterialsX03");
        const { rsn_link } = LinkedRsnApi.entities;
        // const whereConditions4LinkedRsn = Rsns.map(line => ({ Rsn: line.rsn }));
        const rsnIds = Rsns.map(line => line.rsn);

        if (rsnIds.length != 0) {

            rsnLinks = await LinkedRsnApi.run(SELECT.from(rsn_link)
                .where({ Rsn: { in: rsnIds } }));

        } else {
            return resultRsn;
        };

        if (rsnLinks && rsnLinks.length !== 0) {

            // read all other relevant tables for output (CompUsage)
            const linkedMaterials = rsnLinks.map(line => line.LinkedMatnr);

            let compUsage = await SELECT.from(CompUsage)
                .columns(CompUsage.component_id, CompUsage.unique)
                .where({ projectID: projectId, component_id: { in: linkedMaterials } });

            for (let rsn of Rsns) {

                let matchingLinks = rsnLinks.filter(rsnLink => rsnLink.Rsn === rsn.rsn);
                for (let match of matchingLinks) {

                    let rsnEntry = {
                        project_uuid: uuid,
                        rsn: rsn.rsn,
                        material: rsn.material,
                        rsnStatus: rsn.rsnStatus,
                        otherMaterial: match.LinkedMatnr,
                        materialType: match.MatType,
                        isComponent: '',
                        isUnique: ''
                    };

                    const compUsageLine = compUsage.find(entry => entry.component_id === rsnEntry.otherMaterial);
                    if (compUsageLine) {
                        rsnEntry.isComponent = 'X';
                        rsnEntry.isUnique = compUsageLine.unique;
                    };

                    resultRsn.push(rsnEntry);
                }
            }

        }
        return resultRsn;

    });

    this.on("READ", "DepObjBoms", async (req, res) => {

        // read uuid
        const projectUUID = extractFilters(req, 'projectUuid');
        return await this.getDepObjBoms(projectUUID);
    });

    this.on('getDepObjBoms', async (req) => {
        const uuid = req.data.uuid;

        const matPlants = await SELECT.from(ProjectIDHPlants).where({ l_ev_uuid: uuid, phaseOutNEEDED: "Yes" });


        let data92 = ``, data93 = ``, flag92 = false, flag93 = false, oJobStatus = {};

        for await (let idhPlant of matPlants) {
            if (idhPlant.sourceSystem === "92") {
                data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET Bom?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag92 = true;
            } else {
                data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET Bom?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag93 = true;
            }
        }

        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        let result = [], mappedResult = [];

        const aPromises = [];

        if (flag92) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data92
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        if (flag93) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("APAC_DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data93
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        await Promise.allSettled(aPromises).then(async (aResponses) => {
            for (let response of aResponses) {
                if (response.status === 'fulfilled') {
                    // batch response needs to be decoded to identify individual one's
                    // so use regex to find out JSON outputs from the total batch response
                    let regex = /\{.*\}/g,
                        oEachResponseIterator = response.value.matchAll(regex);

                    // use JSON parse to parse the string to JSON
                    for await (let response of oEachResponseIterator) {
                        const finalResponse = JSON.parse(response[0]).value;
                        if (finalResponse && Array.isArray(finalResponse))
                            result = finalResponse.length > 0 ? result.concat(finalResponse) : result;
                    }
                } else {
                    if (response.reason.message.includes('92')) {
                        error92 = true;
                        cds.log("92failed").error(response.reason.message);
                    } else if (response.reason.message.includes('93')) {
                        error93 = true;
                        cds.log("93failed").error(response.reason.message);
                    }
                }
            }
        });

        for (const line of result) {
            let IDHPlant = matPlants.filter((r) => r.material == line.Material && r.plant == line.Plant);

            let new_result = {};
            new_result.projectUuid = uuid;
            if (IDHPlant && Array.isArray(IDHPlant) && IDHPlant.length > 0) {
                new_result.sourceSystem = IDHPlant[0].sourceSystem;
            } else {
                new_result.sourceSystem = '';
            };
            new_result.material = line.Material;
            new_result.plant = line.Plant;
            new_result.stlnr = line.Stlnr;
            new_result.stlal = line.Stlal;
            new_result.stlan = line.Stlan;
            new_result.bom_stat = line.Sttxt;
            mappedResult.push(new_result);
        }

        if (!mappedResult || mappedResult.length === 0) {
            mappedResult = [];
        }
        return mappedResult;
    });

    this.on("READ", "DepObjMasterRecipePrdVersion", async (req, res) => {

        // read uuid
        const projectUUID = extractFilters(req, 'projectUuid');

        return await this.getDepObjMasterRecipePrdVersion(projectUUID);
    });

    this.on('getDepObjMasterRecipePrdVersion', async (req) => {
        const uuid = req.data.uuid;

        const matPlants = await SELECT.from(ProjectIDHPlants).where({ l_ev_uuid: uuid, phaseOutNEEDED: "Yes" });


        let data92 = ``, data93 = ``, flag92 = false, flag93 = false, oJobStatus = {};

        for await (let idhPlant of matPlants) {
            if (idhPlant.sourceSystem === "92") {
                data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MasterPrd?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag92 = true;
            } else {
                data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MasterPrd?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag93 = true;
            }
        }

        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        let result = [], mappedResult = [];

        const aPromises = [];

        if (flag92) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data92
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        if (flag93) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("APAC_DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data93
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        await Promise.allSettled(aPromises).then(async (aResponses) => {
            for (let response of aResponses) {
                if (response.status === 'fulfilled') {
                    // batch response needs to be decoded to identify individual one's
                    // so use regex to find out JSON outputs from the total batch response
                    let regex = /\{.*\}/g,
                        oEachResponseIterator = response.value.matchAll(regex);

                    // use JSON parse to parse the string to JSON
                    for await (let response of oEachResponseIterator) {
                        const finalResponse = JSON.parse(response[0]).value;
                        if (finalResponse && Array.isArray(finalResponse))
                            result = finalResponse.length > 0 ? result.concat(finalResponse) : result;
                    }
                } else {
                    if (response.reason.message.includes('92')) {
                        error92 = true;
                        cds.log("92failed").error(response.reason.message);
                    } else if (response.reason.message.includes('93')) {
                        error93 = true;
                        cds.log("93failed").error(response.reason.message);
                    }
                }
            }
        });

        for (const line of result) {
            let IDHPlant = matPlants.filter((r) => r.material == line.Material && r.plant == line.Plant);

            let new_result = {};
            new_result.projectUuid = uuid;
            if (IDHPlant && Array.isArray(IDHPlant) && IDHPlant.length > 0) {
                new_result.sourceSystem = IDHPlant[0].sourceSystem;
            } else {
                new_result.sourceSystem = '';
            };
            new_result.material = line.Material;
            new_result.plant = line.Plant;
            new_result.recipeGroup = line.Recipegroup;
            new_result.groupCounter = line.Groupcounter;
            new_result.description = line.Description;
            new_result.recipeStatus = line.Recipestatus;
            new_result.prodVersion = line.Prodversion;
            new_result.usage = line.Usage;

            mappedResult.push(new_result);
        }

        if (!mappedResult || mappedResult.length === 0) {
            mappedResult = [];
        }
        return mappedResult;
    });

    this.on("READ", "DepObjPirSourceList", async (req, res) => {

        // read uuid
        const projectUUID = extractFilters(req, 'projectUuid');

        return await this.getDepObjDepObjPirSourceList(projectUUID);
    });

    this.on('getDepObjDepObjPirSourceList', async (req) => {
        const uuid = req.data.uuid;

        const matPlants = await SELECT.from(ProjectIDHPlants).where({ l_ev_uuid: uuid, phaseOutNEEDED: "Yes" });


        let data92 = ``, data93 = ``, flag92 = false, flag93 = false, oJobStatus = {};

        for await (let idhPlant of matPlants) {
            if (idhPlant.sourceSystem === "92") {
                data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET PirSourcelist?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag92 = true;
            } else {
                data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET PirSourcelist?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27 HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
                flag93 = true;
            }
        }

        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        let result = [], mappedResult = [];

        const aPromises = [];

        if (flag92) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data92
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        if (flag93) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const DepObjApi = await cds.connect.to("APAC_DepObjects");
                try {
                    const response = await DepObjApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data93
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        await Promise.allSettled(aPromises).then(async (aResponses) => {
            for (let response of aResponses) {
                if (response.status === 'fulfilled') {
                    // batch response needs to be decoded to identify individual one's
                    // so use regex to find out JSON outputs from the total batch response
                    let regex = /\{.*\}/g,
                        oEachResponseIterator = response.value.matchAll(regex);

                    // use JSON parse to parse the string to JSON
                    for await (let response of oEachResponseIterator) {
                        const finalResponse = JSON.parse(response[0]).value;
                        if (finalResponse && Array.isArray(finalResponse))
                            result = finalResponse.length > 0 ? result.concat(finalResponse) : result;
                    }
                } else {
                    if (response.reason.message.includes('92')) {
                        error92 = true;
                        cds.log("92failed").error(response.reason.message);
                    } else if (response.reason.message.includes('93')) {
                        error93 = true;
                        cds.log("93failed").error(response.reason.message);
                    }
                }
            }
        });


        for (const line of result) {
            let IDHPlant = matPlants.filter((r) => r.material == line.Material && r.plant == line.Plant);

            let new_result = {};
            new_result.projectUuid = uuid;
            if (IDHPlant && Array.isArray(IDHPlant) && IDHPlant.length > 0) {
                new_result.sourceSystem = IDHPlant[0].sourceSystem;
            } else {
                new_result.sourceSystem = '';
            };
            new_result.material = line.Material;
            new_result.plant = line.Plant;
            new_result.vendor = line.Vendor;
            new_result.groupCounter = line.Groupcounter;
            new_result.infoRecordCategory = line.Inforecordcategory;
            new_result.sourceList = line.Sourcelist;
            new_result.validFrom = line.Validfrom;
            new_result.validTo = line.Validto;
            new_result.fixedVendor = line.fixedVendor;
            new_result.eineLoekz = line.Eineloekz;
            new_result.einaLoekz = line.Einaloekz;

            mappedResult.push(new_result);
        }

        if (!mappedResult || mappedResult.length === 0) {
            mappedResult = [];
        }
        return mappedResult;
    });

    this.on("READ", "ExclusiveComponents", async (req, next) => {

        if (req.req.url.includes("/$count")) {
            return;
        }
        let projectId = extractFilters(req, 'projectID');
        let res = await next();

        if (res.length === 0) {
            let compusesUniComponentBOMNotfound = await SELECT.from(CompUsageJobInfo).columns(`jobStatus`).where({ projectID: projectId });
            if ((compusesUniComponentBOMNotfound.length >= 1) && (compusesUniComponentBOMNotfound[0].jobStatus === 'Completed')) {
                return [{
                    projectID: "",
                    plant: "",
                    component_id: "",
                    unique: false,
                    component_buom: "",
                    totalTsiQuant: 0,
                    message: "No Exclusive Components found"
                }];
            }
            return [{
                projectID: "",
                plant: "",
                component_id: "",
                unique: false,
                component_buom: "",
                totalTsiQuant: 0,
                message: "To be calculated"
            }];
        }

        if (res.length === 1 && res[0].jobStatus === 'In Progress') {
            return [{
                projectID: "",
                plant: "",
                component_id: "",
                unique: false,
                component_buom: "",
                totalTsiQuant: 0,
                message: "To be calculated"
            }];
        } else if (res.length === 1 && res[0].jobStatus === 'Completed' && res[0].error === 'No Components found') {
            return [{
                projectID: "",
                plant: "",
                component_id: "",
                unique: false,
                component_buom: "",
                totalTsiQuant: 0,
                message: "No Exclusive Components found"
            }];
        } else if (res.length === 1 && res[0].jobStatus === 'Error') {
            return [{
                projectID: "",
                plant: "",
                component_id: "",
                unique: false,
                component_buom: "",
                totalTsiQuant: 0,
                message: "Error in determination"
            }];
        }

        let aExclusiveComps = res.filter(item => item.unique === true);
        const bExclusiveCheck = res.every(item => item.unique === false);

        // If no exclusive components are flagged
        if (bExclusiveCheck) {
            return [{
                projectID: "",
                plant: "",
                component_id: "",
                unique: false,
                component_buom: "",
                totalTsiQuant: 0,
                message: "No Exclusive Components found"
            }];
        }

        const projectUuid = await SELECT.from(ProjectHeaders).columns(`uuid`).where({ projectID: res[0].projectID });
        const sSourceSystem = await SELECT.from(ProjectIDHPlants).columns(`sourceSystem`).where({
            l_ev_uuid: projectUuid[0].uuid
        });

        const MatStocksApi = await cds.connect.to(sSourceSystem[0].sourceSystem === "92" ? "MatStocks" : "APAC_MatStocks");

        let aggregateResults = {};
        // let stocksRequests = [];

        const { stock_cal } = MatStocksApi.entities;

        for (const { plant, component_id } of aExclusiveComps) {

            let results = await MatStocksApi.run(SELECT.from(stock_cal).where({
                Material: component_id,
                Plant: plant
            }));

            if (results.length !== 0) {
                if (Object.keys(aggregateResults).includes(results[0].BaseUom))
                    aggregateResults[results[0].BaseUom] += results[0].TsiQuant;
                else
                    aggregateResults[results[0].BaseUom] = results[0].TsiQuant;

            }

            // best practice to send one batch call instead of multiple calls to SAP
            // check with backend team to implement this one
            // // Build stock request
            // const stockRequest = `GET stock_cal?$filter%3DMaterial%20eq%20%27${component_id}%27%20and%20Plant%20eq%20%27${plant}%27 HTTP/1.1`;
            // stocksRequests.push(stockRequest);
        }

        // if (stocksRequests.length > 0) {
        //     const dataBatchStocks = stocksRequests.map(request =>
        //         `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\n${request}\r\n\r\n\r\n`
        //     ).join('') + '--batch--';

        //     const stockResults = await MatStocksApi.send({
        //         method: 'POST',
        //         path: '/$batch',
        //         headers: {
        //             'Content-Type': 'multipart/mixed;boundary=batch'
        //         },
        //         data: dataBatchStocks
        //     });

        //     // Aggregate stock quantities
        //     const stockRegex = /\{.*\}/g;
        //     for (const match of stockResults.match(stockRegex)) {
        //         const result = JSON.parse(match);
        //         const { TsiQuant, BaseUom } = result;

        //         if (!aggregateResults[BaseUom]) {
        //             aggregateResults[BaseUom] = 0; // Initialize if not present
        //         }

        //         aggregateResults[BaseUom] += TsiQuant; // Accumulate quantity
        //     }
        // }

        // Prepare final results
        const finalResults = Object.entries(aggregateResults).map(([baseUom, totalTsiQuant]) => ({
            projectID: aExclusiveComps[0].projectID,
            plant: aExclusiveComps[0].plant,
            component_id: aExclusiveComps[0].component_id,
            unique: aExclusiveComps[0].unique,
            component_buom: baseUom,
            totalTsiQuant: totalTsiQuant, // Accumulated quantity for this UOM
            message: ""
        }));

        // Return results or a message if no data was found
        return finalResults.length > 0 ? finalResults : [{
            projectID: "",
            plant: "",
            component_id: "",
            unique: false,
            component_buom: "",
            totalTsiQuant: 0,
            message: "No stock data found"
        }];
    });


    function extractFilters(req, field) {

        const filters = req.query.SELECT.where;

        if (filters) {
            for (let i = 0; i < filters.length; i++) {

                if (filters[i].xpr) {
                    for (let j = 0; j < filters[i].xpr.length; j++) {
                        if (filters[i].xpr[j].ref && filters[i].xpr[j].ref[0] === field) {
                            return filters[i].xpr[j + 2].val;
                        }
                    }
                }
                else {
                    if (filters[i].ref && filters[i].ref[0] === field) {
                        return filters[i + 2].val;
                    }
                }
            }
        }
    }
    this.on("statusCheckForBackendSystem", statusCheckForBackendSystem);
    async function statusCheckForBackendSystem() {
        // system status check for SAP 32 
        const aErr = [];
        let sEnvC = "";
        let sEnvR = "";
        if(process.env.DEPLOY_ENV === 'DEV' || process.env.DEPLOY_ENV === 'QA'){
            sEnvC = "C";
            sEnvR = "R";

        }else{
            sEnvC = "P";
            sEnvR = "P";
        }
        try {
            const apoSnpApi = await cds.connect.to("Apo");
           let  pingSAP32 = await apoSnpApi.send({
                method: 'GET',
                path: `/`,
            });
        } catch (error) {
            if (error.reason.status) {
                
               aErr.push(`SAP ${sEnvC}32 system is unavailable`);
            }

        }
        // system status check for SAP 92 
        try {
            const matStocksApi = await cds.connect.to("MatStocks");
           let pingSAP92 = await matStocksApi.send({
                method: 'GET',
                path: `/`,
            });
        } catch (error) {
            if (error.reason.status) {
                
                aErr.push(`SAP ${sEnvR}92 system is unavailable`);
            }

        }
        // system status check for SAP 93
        try {
            const matStocksApi93 = await cds.connect.to("APAC_MatStocks");
            let pingSAP93 = await matStocksApi93.send({
                method: 'GET',
                path: `/`,
            });
        } catch (error) {
            if (error.reason.status) {
                
                aErr.push(`SAP ${sEnvR}93 system is unavailable`);
            }

        }
       
        // system status check for SAP 03
        try {
            const matTypesApi = await cds.connect.to("MaterialsX03");
            const matTypesQuery = SELECT.from('mat_typ')
            .where({ Material: '1189219' });
            let Check03 = await matTypesApi.run(matTypesQuery);
            let value=Check03
        } catch (error) {
            if (error.reason.status) {
                aErr.push(`SAP ${sEnvC}03 system is unavailable`);
            }
        }
       return sText = aErr.length === 0 ? "" : aErr.join(" *** ") + "*** Please do not create new projects at this moment, as data fetch & workflows may be Impacted.";
    };

    this.on('getStdMaterial', async (req) => {
        console.log(req);
        let mat = (req.data.material)[0]?.split(",") || [];
        let subMat = (req.data.subMaterial)[0]?.split(",") || [];
        const stdMaterial = await SELECT.columns(['matnr']).from(FGMatCls).where({ matnr: { "in": mat}, mtart : "STD"});
        const stdSubsMaterial = await SELECT.columns(['matnr']).from(FGMatCls).where({ matnr: { "in": subMat}, mtart : "STD"});
        const amaterial = stdMaterial?.map((item) => item['matnr']);
        const asubMaterial = stdSubsMaterial?.map((item) => item['matnr']);
        try{
            if(amaterial.length === 0){
                throw new Error('Only Material Type "STD" allowed to add.');
            }else{
                return {
                    aMaterial :  amaterial,
                    aSubMaterial : asubMaterial
                }
            }
        }catch(error){
            customErrorHandler(req, error);
            return;
        }
        
    });

    this.on('READ', 'PhaseOutScenario', async (req) => {
        if(req.user.is('CMSupplyPlanner') && !req.user.is('CMAdmin') && !req.user.is('CMPLM')){
           return cds.run(SELECT.from(PhaseOutScenario).where({id : {'!=' : 'Scenario01'}}).orderBy('id'));
        }else{
            return cds.run(SELECT.from(PhaseOutScenario).orderBy('id'));
        }
    });

});