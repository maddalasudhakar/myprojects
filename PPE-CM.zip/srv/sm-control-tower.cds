using {ppe.cm.pd as pd} from '../db/project-dashboard';
using {ppe.cm.md as md} from '../db/ingested-master-data';

using {
    V_ProjMatSummary,
    V_MatValList,
} from '../db/views';

service ControlTower @(path: '/ppe/cm/ct-services') @(requires: 'authenticated-user') {

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity ControlTower        as
        projection on V_ProjMatSummary {
            key projectID,
            key material,
            key plant,
            key salesOrg,
            key distChannel,
            key subsMaterial,
                *,
                //0 as totalActiveValue  : Decimal(13, 3),
                0 as sellableStock     : Decimal(13, 3),
                0 as openOrderQuantity : Decimal(13, 3),
                0 as openPoQuantity    : Decimal(13, 3),
                0 as openPoQuantityBuom : Decimal(13, 3),
                0 as balanceOpenOrder  : Decimal(13, 3)
    }

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity MatValList          as
        projection on V_MatValList {
            key projectID,
            key material,
                materialText,
        };

    @readOnly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity ProjectHeaders      as projection on pd.ProjectHeaders;

    @readOnly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity ProjectIDHPlants    as projection on pd.ProjectIDHPlants;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity ProjectIDHSalesArea as projection on pd.ProjectIDHSalesArea;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity FGMatCls            as projection on md.FGMatCls;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity AllMatTypes         as projection on md.AllMatTypes;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity MatPlants           as projection on md.MatPlants;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMControlTower'
        ]
    }]
    entity MatSorgs            as projection on md.MatSorgs;
}
