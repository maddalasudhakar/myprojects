using ppe.cm.pd as pd from '../db/project-dashboard';
using ppe.cm.md as md from '../db/ingested-master-data';
using ppe.cm.td as td from '../db/ingested-transaction-data';
using {
    v_idhDepObjLinkedRsn,
    v_projectstatusbyagerange,
    v_materialplantsplannedphasedout,
    v_idhProjectPlantSalesInfo,
    v_FGMatClsStd,
     v_idhProjectPlantSales
} from '../db/views';

@cds.server.body_parser.limit: '3mb'
service ComplexityManagement @(path: '/ppe/cm/complexity-management')  {
    @assert.unique: {projectID: [projectID]}
    @cds.redirection.target
    @restrict     : [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                'CMAdmin',
                'CMPLM'
            ]
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ProjectHeaders                        as projection on pd.ProjectHeaders
                                                 where Deletion = false
                                                 order by
                                                        projectID desc;
    @cds.odata.valuelist
    @readonly
    @restrict     : [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                'CMAdmin',
                'CMPLM'
            ]
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]

    entity PhaseOutScenario as projection on pd.PhaseOutScenario;

    @assert.unique: {
        material   : [material],
        l_ev       : [projectID],
        regionScope: [regionScope]
    }
    @cds.redirection.target
    @restrict     : [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                'CMAdmin',
                'CMPLM'
            ]
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ProjectIDHs                           as projection on pd.ProjectIDHs;

    @assert.unique: {
        l_ev : [
            l_ev_uuid,
            material,
            regionScope
        ],
        plant: [plant]
    }
    @cds.redirection.target
    @restrict     : [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner'
            ]
        },
        {
            grant: ['READ']
        }
    ]
    entity ProjectIDHPlants                      as projection on pd.ProjectIDHPlants;

    @cds.odata.valuelist
    @readonly
    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ProjectStatuses                       as projection on pd.ProjectStatuses;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity FGMatCls                              as projection on md.FGMatCls;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity AllMatTypes                           as projection on md.AllMatTypes;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity MatPlants                             as projection on md.MatPlants;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity MatSorgs                              as projection on md.MatSorgs;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ProjectIDHSalesArea                   as projection on pd.ProjectIDHSalesArea;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity SalesBoms                             as projection on td.SalesBoms;


    type OpenTransactions {
        material         : String(20);
        plant            : String(4);
        OpenTransactions : String(3);
        OpenStock        : Decimal(13, 3);
        OpenDemand       : Decimal(13, 3);
        OpenOrders       : Decimal(13, 3);
        OtherMRPElements : String(3);
        SBOMPart         : String(3);
        RAWPackFG        : String(30);
        UOM              : String(5);
        BOMData          : Composition of many SalesBoms
    }

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getOpenTransactions(material : String, plant : String, source : String)  returns OpenTransactions;

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    
    action getOpenTransactionsSa(material : String, salesOrg : String(10), distChanel : String(10), source : String)  returns Decimal(13, 3);

    type ProjectIdh {
        material         : String(18);
        regionScope      : String(6);
        materialText     : String(40);
        subsMaterial     : String(18);
        subsMaterialText : String(40);
        phaseOutNEEDED   : Boolean;
        phaseOutDate     : Date;
        phaseOutStatus   : String(10);
        workflowFlag     : String(10);
        phaseOutScenario : String(15);
        spConfirmedDate  : Date;
    }

    type ProjectIdhPlant {
        material             : String(18);
        materialText         : String(40);
        plant                : String(10);
        plantYSTATUS         : String(10);
        phaseOutNEEDED       : String(10);
        phaseOutDate         : Date;
        phaseOutStatus       : String(10);
        openTransaction      : String(10);
        sourceSystem         : String(3);
        mrpController        : String(3);
        mrpControllerEmail   : String(254);
        ctPlanner            : String(3);
        ctPlannerEmail       : String(254);
        projectIDHSalesAreas : array of {
            salesOrg         : String(10);
            distChanel       : String(10);
            sourceSystem     : String(10);
            salesCountry     : String(10);
            salesOrgDescr    : String(40);
            salesyStatus     : String(10);
            yStatusValidfrom : Date;
        }
    }

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getIDHDetails(material : array of String, projectSec : String(15))                                returns {
        ProjectIDHs : array of ProjectIdh;
        ProjectIDHPlants : array of ProjectIdhPlant;
    };

    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower']
        }
    ]
    action   updateProjectIDHPlant(uuid : UUID, material : String(18), mrp: String(3), status : UUID, plant: String(4), category: String(5)) returns String;


	@restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : ['CMAdmin']
        },
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity CompUsage                             as projection on md.CompUsage;
	
    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjIbProducts                      as projection on pd.DepObjIbProduct;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getDepObjIbProducts(uuid : UUID)                                         returns array of DepObjIbProducts;

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjRsns                            as projection on pd.DepObjRsns;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjLinkedRsns                      as
        projection on v_idhDepObjLinkedRsn {
            key projectUuid,
            key projectId,
            key material,
            key rsn,
                rsnStatus
        };
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity IdhProjectPlantSalesInfo as projection on  v_idhProjectPlantSalesInfo{
        key material,
        key uuid,
        key salesCountry,
        key regionScope,
        key plant,
        key salesOrg,
        key distChanel,
        *
    };
    
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getDepObjRsns(uuid : UUID)                                               returns array of DepObjRsns;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjBoms                            as projection on pd.DepObjBom;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getDepObjBoms(uuid : UUID)                                               returns array of DepObjBoms;

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjMasterRecipePrdVersion          as projection on pd.DepObjMasterRecipePrdVersion;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getDepObjMasterRecipePrdVersion(uuid : UUID)                             returns array of DepObjMasterRecipePrdVersion;

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity DepObjPirSourceList                   as projection on pd.DepObjPirSourceList;

    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function getDepObjDepObjPirSourceList(uuid : UUID)                                returns array of DepObjPirSourceList;
@restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function userAuth() returns {};
    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ProjectIDHDepObjs {
        key project_uuid                : UUID;
            ibProduct                   : String(1);
            ibProductData               : Composition of DepObjIbProducts;
            ibProductColor              : String;
            rsn                         : String(1);
            rsnData                     : Composition of DepObjRsns;
            rsnColor                    : String;
            firstBom                    : String(1);
            firstBomData                : Composition of DepObjBoms;
            firstBomColor               : String;
            masterRecipePrdVersion      : String(1);
            masterRecipePrdVersionData  : Composition of DepObjMasterRecipePrdVersion;
            masterRecipePrdVersionColor : String;
            pirSourceList               : String(1);
            pirSourceListData           : Composition of DepObjPirSourceList;
            pirSourceListColor          : String;
    }


    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity ExclusiveComponents as select from md.CompUsageJobInfo as job left join md.CompUsage as comps on comps.projectID = job.projectID {
        key job.projectID as projectID,    
        key comps.plant as plant,
        key comps.component_id as component_id,
        comps.unique as unique,
        job.jobStatus as jobStatus,   
        job.error as error,
        comps.fg_idh as fg_idh, 
        key comps.component_buom as component_buom,
        0 as totalTsiQuant : Decimal(13,3),
        '' as message : String(50)
    };

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity KpiProjectsByStatusByMonth            as
        select from pd.ProjectHeaders {
            key TO_VARCHAR(
                    MONTH(createdAt)
                ) || '-' || TO_VARCHAR(
                    YEAR(createdAt)
                ) as month               : String(7),
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Draft'
                        then
                            1
                        else
                            0
                    end
                ) as projectsInDraft     : Integer,
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Submitted'
                        then
                            1
                        else
                            0
                    end
                ) as projectsInSubmitted : Integer,
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Approved'
                        then
                            1
                        else
                            0
                    end
                ) as projectsInApproved  : Integer,
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Archived'
                        then
                            1
                        else
                            0
                    end
                ) as projectsInArchived  : Integer,
        }
        where
            createdAt >= ADD_MONTHS(
                $now, -12
            )
        group by
                        TO_VARCHAR(
                        MONTH(
                        createdAt
                    )
            )
        ||
                        '-'
        ||
                        TO_VARCHAR(
                        YEAR(
                        createdAt
                    )
            );

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity KpiActiveProjectsByTotalProjects      as
        select from pd.ProjectHeaders {
            key 'Counts'   as ID              : String(6),
                count( * ) as totalCount      : Integer,
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Draft'
                        then
                            1
                        when
                            'Submitted'
                        then
                            1
                        else
                            0
                    end
                )          as totalInProgress : Integer,
                SUM(
                    case projectStatus.projectStatus
                        when
                            'Approved'
                        then
                            1
                        when
                            'Archived'
                        then
                            1
                        else
                            0
                    end
                )          as totalCompleted  : Integer
        }
        where
            createdAt >= ADD_MONTHS(
                $now, -12
            );

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity KpiProjectMaterialsPerRegion          as
        select from pd.ProjectIDHs {
            key regionScope     as region,
                COUNT(material) as materialCount : Integer
        }
        where
            l_ev.createdAt >= ADD_MONTHS(
                $now, -12
            )
        group by
            regionScope;

    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity KpiProjectByStatusWithFilter          as
        projection on v_projectstatusbyagerange {
            key projectStatus,
            key openDays,
                statusCount
        };

    
    @readonly
    @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity KpiMaterialPlantsPlannedToBePhasedOut as
        projection on v_materialplantsplannedphasedout {
            key mpWeek,
                mpCount
    };
     @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity FGMatClsStd as projection on v_FGMatClsStd;
     @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    function statusCheckForBackendSystem() returns String;
    @restrict: [
        {
            grant: [
                'CREATE',
                'UPDATE'
            ],
            to   : [
                 'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    action getStdMaterial(material : many String, subMaterial: many String)   returns {
        aMaterial : many String;
        aSubMaterial : many String;
    };

     @restrict: [
        {
            grant: ['READ'],
            to   : [
                'CMAdmin',
                'CMPLM',
                'CMSupplyPlanner',
                'CMBusinessPlanner',
                'CMControlTower'
            ]
        }
    ]
    entity projectPlantSalesArea as projection on  v_idhProjectPlantSales{
        key material,
        key plantUUID,
        key projectUUID,
        key uuid,
        *
    };

/* this one is for sqlite and used for local card preview

entity KpiProjectsByStatusByMonth as select from pd.ProjectHeaders {
    key CAST(MONTH(createdAt) as String(2)) || '-' || CAST(YEAR(createdAt) as String(4)) as month: String(7),
    SUM(case projectStatus.projectStatus
        when 'Draft' then 1
        else 0
    end) as projectsInDraft: Integer,
    SUM(case projectStatus.projectStatus
        when 'Submitted' then 1
        else 0
    end) as projectsInSubmitted: Integer,
    SUM(case projectStatus.projectStatus
        when 'Approved' then 1
        else 0
    end) as projectsInApproved: Integer,
    SUM(case projectStatus.projectStatus
        when 'Archived' then 1
        else 0
    end) as projectsInArchived: Integer,
} where createdAt >= DATE($now,'-12 month')
    group by CAST(MONTH(createdAt) as String(2)) || '-' || CAST(YEAR(createdAt) as String(4));

entity KpiActiveProjectsByTotalProjects as select from pd.ProjectHeaders {
    key 'Counts' as ID: String(6),
    count(*) as totalCount: Integer,
    SUM(case projectStatus.projectStatus
        when 'Draft' then 1
        when 'Submitted' then 1
        else 0
    end) as totalInProgress: Integer,
    SUM(case projectStatus.projectStatus
        when 'Approved' then 1
        when 'Archived' then 1
        else 0
    end) as totalCompleted: Integer
} where createdAt >= DATE($now,'-12 month');

entity KpiProjectMaterialsPerRegion as select from pd.ProjectIDHs {
    key regionScope as region,
    COUNT(material) as materialCount: Integer
} where l_ev.createdAt >= DATE($now,'-12 month')
    group by regionScope;
    */

};

