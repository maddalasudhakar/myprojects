const cds = require("@sap/cds");
const { SELECT } = require("@sap/cds/lib/ql/cds-ql");

// Calculate total stock value - Standard Price
function calStdPrice(stockInput) {
    let stdPrice;
    stdPrice = stockInput.Labst + stockInput.Insme + stockInput.Speme + stockInput.Einme + stockInput.Retme;
    return stdPrice;
}

// Stock Odata
async function triggerMatStocksFetch(materials, plants, system) {
    let matStocksApi = null;
    if (system === '92') {
        matStocksApi = await cds.connect.to("MatStocks");
    } else {
        matStocksApi = await cds.connect.to("APAC_MatStocks");
    }

    //const stockQuery = SELECT.from('Stock')
    const stockQuery = SELECT.from('stock_cal')
        .where({ Material: { in: materials }, Plant: { in: plants } });

    return matStocksApi.run(stockQuery);
}

// OpenPO Odata
async function triggerOpenPoFetch(materials, plants, system) {
    let openPOApi = null;
    if (system === '92') {
        openPOApi = await cds.connect.to("OpenPO");
    } else {
        openPOApi = await cds.connect.to("APAC_OpenPO");
    }

    const openPoQuery = SELECT.from('OpenPO')
        .where({ Material: { in: materials }, Werks: { in: plants } });
    return openPOApi.run(openPoQuery);
}

// OpenSO Odata
async function triggerOpenSoFetch(materials, plants, system) {
    let openSOApi = null;
    if (system === '92') {
        openSOApi = await cds.connect.to("OpenSO");
    } else {
        openSOApi = await cds.connect.to("APAC_OpenSO");
    }

    const openSoQuery = SELECT.from('OpenSO')
        .where({ Material: { in: materials }, Plant: { in: plants } });
    return openSOApi.run(openSoQuery);
}

module.exports = cds.service.impl(async function () {

    this.before('*', async (req) => {
        if (req.event === 'DELETE')
            req.reject(406, "Not accepted");

        if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
            const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
            const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
            let payload = JSON.stringify(req.data);

            sBlacklistExactTokens.forEach((token) => {
                const regex = new RegExp(`\\b${token}\\b`);
                if (payload.toLowerCase().match(regex))
                    req.reject(406, "Not accepted");
            });
            sBlacklistIncludeTokens.forEach((token) => {
                if (payload.toLowerCase().includes(token))
                    req.reject(406, "Not accepted");
            });

            Object.keys(req.data).forEach((key) => {
                if(key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")){

                    // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                    if (!emailRegex.test(req.data[key])) 
                        req.reject(406, "Not accepted - Invalid email format");
                }
            });
        }
    });
    
    this.after('READ', 'ControlTower', async (res, req) => {
        try {
            let promises = [];
            let projMatSummaryViewData = res;

            const materials = [...new Set(projMatSummaryViewData.map(item => item.material))];
            const plants = [...new Set(projMatSummaryViewData
                .filter(item => item.sourceSystem === '92')
                .map(item => item.plant))];
            const plantsAPAC = [...new Set(projMatSummaryViewData
                .filter(item => item.sourceSystem === '93')
                .map(item => item.plant))];

            if (materials.length > 0 && plants.length > 0) {
                promises.push(triggerMatStocksFetch(materials, plants, '92'));
                promises.push(triggerOpenPoFetch(materials, plants, '92'));
                promises.push(triggerOpenSoFetch(materials, plants, '92'));
            }

            if (materials.length > 0 && plantsAPAC.length > 0) {
                promises.push(triggerMatStocksFetch(materials, plantsAPAC, '93'));
                promises.push(triggerOpenPoFetch(materials, plantsAPAC, '93'));
                promises.push(triggerOpenSoFetch(materials, plantsAPAC, '93'));
            }

            await Promise.all(promises).then((data) => {
                const stockSet = data[0] || [];
                const openPo = data[1] || [];
                const openSo = data[2] || [];
                const stockSetAPAC = data[3] || [];
                const openPoAPAC = data[4] || [];
                const openSoAPAC = data[5] || [];
                res = projMatSummaryViewData.map(ctRow => {
                    let stock = [], stockAPAC = [], openPO = [], openPOAPAC = [], openSO = [], openSOAPAC = [];
                    if (stockSet) {
                        stock = stockSet.find(stockItem =>
                            stockItem.Material === ctRow.material && stockItem.Plant === ctRow.plant
                        );
                    }

                    if (stockSetAPAC) {
                        stockAPAC = stockSetAPAC.find(stockItem =>
                            stockItem.Material === ctRow.material && stockItem.Plant === ctRow.plant
                        );
                    }

                    if (openPo) {
                        openPO = openPo.find(openPOItem =>
                            openPOItem.Material === ctRow.material && openPOItem.Werks === ctRow.plant
                        );
                    }

                    if (openPoAPAC) {
                        openPOAPAC = openPoAPAC.find(openPOItem =>
                            openPOItem.Material === ctRow.material && openPOItem.Werks === ctRow.plant
                        );
                    }

                    if (openSo) {
                        openSO = openSo.find(openSOItem =>
                            openSOItem.Material === ctRow.material && openSOItem.Plant === ctRow.plant
                        );
                    }

                    if (openSoAPAC) {
                        openSOAPAC = openSoAPAC.find(openSOItem =>
                            openSOItem.Material === ctRow.material && openSOItem.Plant === ctRow.plant
                        );

                    }
                    //ctRow.totalActiveValue = stock ? stock.TotalActiveStock : stockAPAC ? stockAPAC.TotalActiveStock : 0;
                    ctRow.sellableStock = stock ? stock.TsiQuant : stockAPAC ? stockAPAC.TsiQuant : 0;
                    ctRow.openOrderQuantity = openSO ? parseFloat(openSO.Quantity).toFixed(3) : openSOAPAC ? parseFloat(openSOAPAC.Quantity).toFixed(3) : 0;
                    ctRow.openPoQuantity = openPO ? parseFloat(openPO.Quantity).toFixed(3) : openPOAPAC ? parseFloat(openPOAPAC.Quantity).toFixed(3) : 0;
                    ctRow.openPoQuantityBuom = openPO ? parseFloat(openPO.QuantityBuom).toFixed(3) : openPOAPAC ? parseFloat(openPOAPAC.QuantityBuom).toFixed(3) : 0;
                    //ctRow.balanceOpenOrder = ctRow.totalActiveValue - ctRow.openOrderQuantity;
                    ctRow.balanceOpenOrder = ctRow.sellableStock - ctRow.openOrderQuantity;
                    return ctRow;
                });
            });
            return res;
        } catch (error) {
            cds.log("CTPlannerLog").error(error);
            req.error(500, 'An error occurred while fetching data');
        }
    });
});