const cds = require('@sap/cds');
const helmet = require('helmet');

cds.on('bootstrap', (app) => {
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          connectSrc: ["sapui5.hana.ondemand.com", "'self'"],
          scriptSrc: ["sapui5.hana.ondemand.com", "'self'"],
          styleSrc: ["sapui5.hana.ondemand.com", "'self'"],
          fontSrc: ["sapui5.hana.ondemand.com", "'self'"],
          imgSrc: ["sapui5.hana.ondemand.com", "'self'"]
        },
      },
    }),
  );
});

module.exports = cds.server;
