using ppe.cm.td as td from '../db/ingested-transaction-data';
using {
    ppe.cm.md.AllMatTypes as Mat,
    ppe.cm.md.Customers as Cust
} from '../db/ingested-master-data';


service TransactionDataServices @(path: 'ppe/cm/td-services') @(requires: 'authenticated-user') {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity CustContracts        as projection on td.CustContracts;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity PurContracts         as projection on td.PurContracts;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity CustMatInfoRecords   as projection on td.CustMatInfoRecords;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity claimsCustComplaints as projection on td.ClaimsCustComplaints;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity AllMatTypes          as projection on Mat;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Customers            as projection on Cust;
}
