using ppe.cm.md as md from '../db/ingested-master-data';

service MasterDataService @(path: 'ppe/cm/md-services') @(requires: 'authenticated-user') {
    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity AllMatTypes           as projection on md.AllMatTypes;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity FGPfCls               as projection on md.FGPfCls;

    @readonly  @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower',
            'TdxReader'
        ]
    }]
    entity FGMatCls              as projection on md.FGMatCls;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity AllMatTypePlants      as projection on md.AllMatTypePlants;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MatPlants             as projection on md.MatPlants;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MatSorgs              as projection on md.MatSorgs;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Customers             as projection on md.Customers;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity IBProducts            as projection on md.IBProducts;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity ChemUnderDis          as projection on md.ChemUnderDis;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MatRsnLinks           as projection on md.MatRsnLinks;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity Relations             as projection on md.Relations;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity FG1Boms               as projection on md.FG1Boms;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity FG1BomItems           as projection on md.FG1BomItems;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity OneBoms               as projection on md.OneBoms;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity OneBomItems           as projection on md.OneBomItems;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity ActivePlants          as projection on md.ActivePlants;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity IBPManagers           as projection on md.IBPManagers;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity PEWorkflowHeaders     as projection on md.PEWorkflowHeaders;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity PlantRegions          as projection on md.PlantRegions;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity RFBasRecords          as projection on md.RFBasRecords;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity RFHeaders             as projection on md.RFHeaders;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity RSNOwners             as projection on md.RSNOwners;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity TechNavBrandRelations as projection on md.TechNavBrandRelations;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity AllowedValPred        as projection on md.AllowedValPred;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity SalesAreas            as projection on md.SalesAreas;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity EstDueDatePred        as projection on md.EstDueDatePred;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity MatAipProd            as projection on md.MatAipProd;

    @readonly
    @restrict: [{
        grant: ['READ'],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    entity CompUsage             as projection on md.CompUsage;
}
