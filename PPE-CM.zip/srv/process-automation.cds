
using {ppe.cm.pd as pd} from '../db/project-dashboard';
service ProcessAutomation @(path: '/ppe/cm/process_automation') @(requires: 'authenticated-user') {

    type demandPlanner {
        Material      : String(20);
        Country       : String(4);
        DemandPlanner : String(9);
        Email         : String(200)
    }

    type ModifiedObj {
        uuid : array of String; 
        taskModifiedEmail : String;
        taskModificationFlag : Boolean default false;
    }

    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getY4Readiness(material : String(18), plant : String(4))                      returns String;
    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getY5Readiness(material : String(18), plant : String(4))                      returns String;
    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getForecastExists(material : String(18), projectUuid : UUID, fasttrack : Boolean)                  returns String;
    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action checkSaleableInventoryVsFixedIssues(material : String(18), plant : String(4)) returns String;

    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action checkCompUsage(material : String(18), projectID : Integer, projectUuid : UUID ) returns String;

    @restrict: [{
         grant: [
             'CREATE',
             'UPDATE'
         ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getEmailAddress(projectID : Integer, material : String(18))                      returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getCsxMail(material : String(18), projectUuid : UUID)      returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action getMrpContrlEmailNew(material : String, projectID:Integer) returns String;

    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE'
        ],
        to   : [
            'CMAdmin',
            'CMPLM',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMControlTower'
        ]
    }]
    action   updateProjectIDHPlantY5(uuid : UUID, material : String(18)) returns String;
    @restrict: [{
        grant: [
            'UPDATE',
            'READ',
            'CREATE',
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    @odata.draft.enabled
    entity WorkFlowLogs as projection on pd.WorkFlowLogs{
        *,
        linkToProject.phaseOutManagerEmail as submittedBy,
        linkToProject.phaseOutScenario.description as projectScenario
    };
    @cds.odata.valuelist
    @restrict: [{
        grant: [
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    entity Statuses as projection on pd.Statuses;
    @cds.odata.valuelist
    @restrict: [{
        grant: [
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    entity ProcessSteps as projection on pd.ProcessSteps;
    @restrict: [{
        grant: [
            'UPDATE',
            'READ',
            'CREATE',
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    action customUpdateAction(params : ModifiedObj) returns String;
     @restrict: [{
        grant: [
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    function getUserRole() returns String;
     @restrict: [{
        grant: [
            'CREATE',
            'UPDATE',
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    action   workflowLoggingTaskStart(projectID : Integer, taskUniqueId : String(10), material: String(18), processStep : String(50), taskUserEmaiId : String(100)) returns String;
    
    @restrict: [{
        grant: [
            'CREATE',
            'UPDATE',
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    action   autoApprovalSPFORM(projectID : Integer, material: String(18), mrpController : String(100)) returns String;
   
    @restrict: [{
        grant: [
            'UPDATE',
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    action   workflowLoggingTaskEnd(uuid : UUID) returns String;
    action plantBaseMatScenario2(material : String(18), uuid : UUID) returns String;
  type salesData {
        uuid                 : UUID;
        material             : String(18);
        plant                : String(10);
        salesyStatus         : String(10);
        salesCountry         : String(10);
        salesOrg             : String(10);
        distChanel           : String(10);
        phaseOutNEEDED       : String(10);
        openTransactionSales : String(10);
        projectID            : Integer;
        sourceSystem         : String(10);
    }

    @restrict: [{
        grant: [
            'UPDATE',
            'READ'
        ],
        to   : [
            'CMAdmin',
            'CMSupplyPlanner',
            'CMBusinessPlanner',
            'CMPLM',
            'CMOPSupport'
        ]
    }]
    // action   checkFasttrachAndRegularSales(uuid: UUID)                                                                                                          returns {
    //     LIST_SAS_FT : Composition of many {
    //                       uuid                 : UUID;
    //                       material             : String(18);
    //                       plant                : String(10);
    //                       salesyStatus         : String(10);
    //                       salesCountry         : String(10);
    //                       salesOrg             : String(10);
    //                       distChanel           : String(10);
    //                       phaseOutNEEDED       : String(10);
    //                       openTransactionSales : String(10);
    //                   }[];
    //     LIST_SAS_RG : Composition of many {
    //                       uuid                 : UUID;
    //                       material             : String(18);
    //                       plant                : String(10);
    //                       salesyStatus         : String(10);
    //                       salesCountry         : String(10);
    //                       salesOrg             : String(10);
    //                       distChanel           : String(10);
    //                       phaseOutNEEDED       : String(10);
    //                       openTransactionSales : String(10);
    //                   }[];
    // };
    // this action is using scenario 3 to filter fasttrack and regular sales data.
    action   checkFasttrachAndRegularSales(uuid: UUID, material: String(10), region:String(10))                                                                                                          returns {
        LIST_SAS_FT : array of salesData;
        LIST_SAS_RG : array of salesData;
    }
};