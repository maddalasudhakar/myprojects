const cds = require("@sap/cds");
const { UPDATE } = require("@sap/cds/lib/ql/cds-ql");
const { stat } = require("@sap/cds/lib/utils/cds-utils");
const { FailedUpdateLogs } = cds.entities('ppe.cm.pd');

class MaterialService extends cds.ApplicationService {
    init() {
        this.before('*', checkForVulnerability);
        this.on("READ", "Marc", fetchMarc);
        this.on("READ", "Mvke", fetchMvke);
        this.on("READ", "Mbew", fetchMbew);

        this.on("updateMaterialPlantStatus", updateMaterialPlantStatus);
        this.on("updateMaterialPlantDateStatus", updateMaterialPlantDateStatus);
        this.on("updateMaterialPlantSAStatus", updateMaterialPlantSAStatus);
        this.on("updateMaterialPlantSalesAreaStatus", updateMaterialPlantSalesAreaStatus);
        this.on("getDemandPlanners", getDemandPlanners);
        this.on("getMrpController", getMrpController);
        this.on("updateSaleStatusScenario03", updateSaleStatusScenario03);
        this.on("updateSalesAreaStatusScenario3",updateSalesAreaStatusScenario3);
        super.init();
    }
}

class ApoService extends cds.ApplicationService {
    init() {
        this.on("READ", "ApoDp", fetchApoDp);
        this.on("READ", "ApoSnp", fetchApoSnp);
        this.on("READ", "DemandPlanners", fetchDemandPlanners);
        this.on("updateStatusCluster2Obs", updateStatusCluster2Obs);
        super.init();
    }
}
class MatStrLocs extends cds.ApplicationService {
    init() {
        this.on("READ", "Mard", fetchMard)
        super.init();
    }
}

class MaterialStocks extends cds.ApplicationService {
    init() {
        this.on("READ", "Stocks", fetchStocks)
        this.on("READ", "StocksCal", fetchStocksCal)
        super.init();
    }
}


class MatBomsService extends cds.ApplicationService {
    init() {
        this.on("READ", "BomItems", fetchBomItems)
        this.on("READ", "BomItemsTree", fetchBomItemsTree)
        this.on("READ", "WhereUsedBomItems", fetchWhereUsedBomItems)
        this.on("setBomToInactive", setBomToInactive);
        this.on("setBomToDelete", setBomToDelete);
        super.init();
    }
}

class PlannersService extends cds.ApplicationService {
    init() {
        this.on("READ", "User", fetchUser);
        this.on("READ", "CtPlanner", fetchCtPlanner);
        super.init();
    }
}

class MatDepObjsService extends cds.ApplicationService {
    init() {
        this.on("setMasterPrdToInactive", setMasterPrdToInactive);
        this.on("setMasterPrdToDelete", setMasterPrdToDelete);
        this.on("setPirSourcelistToDelete", setPirSourcelistToDelete);
        super.init();
    }
}

class MatX03Service extends cds.ApplicationService {
    init() {
        this.on("READ", "MatType", fetchMatType);
        super.init();
    }
}

async function fetchUser(req, res, next) {
    const api = await cds.connect.to("Planner");
    return await api.run(req.query);
}

async function fetchCtPlanner(req, res, next) {
    const api = await cds.connect.to("Planner");
    return await api.run(req.query);
}

async function fetchMarc(req, res, next) {
    const materialsApi = await cds.connect.to("Materials");
    return await materialsApi.run(req.query);
}

async function fetchMvke(req, res, next) {
    const materialsApi = await cds.connect.to("Materials");
    return await materialsApi.run(req.query)
}

async function fetchMbew(req, res, next) {
    const materialsApi = await cds.connect.to("Materials");
    return await materialsApi.run(req.query)
}

async function fetchMard(req, res, next) {
    const matStrLocsApi = await cds.connect.to("MatStorageLocs");
    return await matStrLocsApi.run(req.query)
}

async function fetchStocks(req, res, next) {
    const matStocksApi = await cds.connect.to("MatStocks");
    return await matStocksApi.run(req.query)
}

async function fetchStocksCal(req, res, next) {
    const matStocksCalApi = await cds.connect.to("MatStocks");
    return await matStocksCalApi.run(req.query)
}

async function fetchBomItems(req, res, next) {
    const matBomItemsApi = await cds.connect.to("MatBoms");
    return await matBomItemsApi.run(req.query)
}

async function fetchBomItemsTree(req, res, next) {
    const matBomItemsTreeApi = await cds.connect.to("MatBoms");
    return await matBomItemsTreeApi.run(req.query)
}

async function fetchWhereUsedBomItems(req, res, next) {
    const matWhereUsedBomItemsApi = await cds.connect.to("MatBoms");
    return await matWhereUsedBomItemsApi.run(req.query)
}

async function fetchApoDp(req, res, next) {
    const apoDpApi = await cds.connect.to("Apo");
    return await apoDpApi.run(req.query);
}

async function fetchApoSnp(req, res, next) {
    const apoSnp = await cds.connect.to("Apo");
    return await apoSnp.run(req.query);
}

async function fetchDemandPlanners(req, res, next) {
    const apoDemandPlannerApi = await cds.connect.to("ApoDp");
    return await apoDemandPlannerApi.run(req.query);
}

async function fetchMatType(req, res, next) {
    const matX03Api = await cds.connect.to("MaterialsX03");
    return await matX03Api.run(req.query);
}

async function updateStatusCluster2Obs(req, res) {

    const material = req.data.material;
    const plant = req.data.plant;

    return "Success"; // no longer necessary

    const { ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');

    let regionScope = '';

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`, `regionScope`).where({
        material: material,
        plant: plant,
        phaseOutNEEDED: `Yes`,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length <= 0) {
        return "Failed";
    }
    // determine regionScope
    regionScope = aProjectUuid[0].regionScope;

    // check fasttrack
    let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
        l_ev_uuid: aProjectUuid[0].l_ev_uuid,
        regionScope: regionScope,
        material: material
    });

    if (aProjectIdhScenario.length > 0 && aProjectIdhScenario[0].phaseOutScenario === "Fasttrack")
        return "Success";
    else
        reasonCode = "RC2";

    // Check if all material plants of region are in status Y5
    let aProjectIdhPlants = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`, `plant`, `plantYSTATUS`).where({
        material: material,
        regionScope: regionScope,
        phaseOutNEEDED: `Yes`,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectIdhPlants.some(entry => entry.plantYSTATUS !== 'Y5')) {
        // Not all plants in status Y5
        return "Success";
    }

     // Update cluster OBS in APO
    const apoApi = await cds.connect.to("ApoDp");
    let sStatusUpdateResult = await apoApi.send({
        method: 'POST',
        path: `/EncCluster`,
        data: {
            Material: material,
            Region: regionScope,
            Cluster: `OBS`,
            ReasonCode: reasonCode
        }
    });

    return "Success";
}

async function updateMaterialPlantStatus(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;
    const yStatus = req.data.status;
    const { ProjectHeaders, MatPlants, ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');

    const currentDate = new Date();
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0');
    const day = String(currentDate.getDate()).padStart(2, '0');
    const formattedDate = `${year}${month}${day}`; // Format as yyyymmdd
    let isFasttrack = false;
    let projectId = '';

    let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
        matnr: material,
        werks: plant
    });

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`,`openTransaction`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };


        let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
            l_ev_uuid: aProjectUuid[0].l_ev_uuid,
            material: material
        });

        if ((aProjectIdhScenario.length > 0 && aProjectIdhScenario[0].phaseOutScenario === "Fasttrack") || aProjectUuid[0].openTransaction === 'No') {
            isFasttrack = true;
        }
    }

    if (aSourceSystem.length > 0) {

        // Trigger update of unique components in case of Y3 status change
        await updateUniqueComponent4MaterialPlantStatus( material, plant, yStatus, formattedDate, projectId, isFasttrack, aSourceSystem[0].source_system );

        if (aSourceSystem[0].source_system === "92") {
            const matApi = await cds.connect.to("Materials");
            let statusUpdateResult = await matApi.send({
                method: 'POST',
                path: `/marc(Material='${material}',Plant='${plant}')/SAP__self.chg_status_plant`,
                data: {
                    status_plant: yStatus,
                    is_fasttrack: isFasttrack,
                    project_id: `${projectId}`
                }
            });

            if (statusUpdateResult?.Type === 'S') {
                try {
                    if (yStatus === "Y5") {

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0],
                                openTransaction: 'No'
                            }
                        ).where({
                            material: material,
                            plant: plant
                        });

                    } else if(yStatus === "Y4"){

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0]
                            }
                        ).where({
                            material: material,
                            plant: plant
                        });

                    }
                    else {

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0]
                            }
                        ).where({
                            material: material,
                            plant: plant,
                            plantYSTATUS: 'Y2'
                        });

                    }

                    // return "Success";
                } catch (error) {
                    cds.log("PlantStatusUpdate").error(`Error updating ProjectIDHPlants: ${error.message}`);
                    return "Failed to update ProjectIDHPlants";
                }
            } else {
                cds.log("PlantStatusUpdate").error({ Material: statusUpdateResult?.Material, Plant: statusUpdateResult?.Plant, MessageType: statusUpdateResult?.Type, Message: statusUpdateResult?.Message });
                await INSERT.into(FailedUpdateLogs).entries({
                    ID: cds.utils.uuid(),  // Generate a unique ID
                    Material: statusUpdateResult.Material,
                    Plant: statusUpdateResult.Plant,
                    MessageType: statusUpdateResult.Type,
                    Message: statusUpdateResult.Message,
                    Timestamp: new Date() // Store current timestamp
                });
                return "Failed";
            }
        } else {
            const matApi = await cds.connect.to("APAC_Materials");
            let statusUpdateResult = await matApi.send({
                method: 'POST',
                path: `/marc(Material='${material}',Plant='${plant}')/SAP__self.chg_status_plant`,
                data: {
                    status_plant: yStatus,
                    is_fasttrack: isFasttrack,
                    project_id: `${projectId}`
                }
            });

            if (statusUpdateResult?.Type === 'S') {
                try {
                    if (yStatus === "Y5") {

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0],
                                openTransaction: 'No'
                            }
                        ).where({
                            material: material,
                            plant: plant
                        });

                    }
                    else if(yStatus === "Y4"){

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0]
                            }
                        ).where({
                            material: material,
                            plant: plant
                        });

                    } else {

                        await UPDATE(ProjectIDHPlants).with(
                            {
                                plantYSTATUS: yStatus,
                                pValidFrom: new Date().toISOString().split('T')[0]
                            }
                        ).where({
                            material: material,
                            plant: plant,
                            plantYSTATUS: 'Y2'
                        });

                    }
                    //  return "Success";
                } catch (error) {
                    cds.log("PlantStatusUpdate").error(`Error updating ProjectIDHPlants: ${error.message}`);
                    return "Failed to update ProjectIDHPlants";
                }
            } else {
                cds.log("PlantStatusUpdate").error({ Material: statusUpdateResult?.Material, Plant: statusUpdateResult?.Plant, MessageType: statusUpdateResult?.Type, Message: statusUpdateResult?.Message });
                await INSERT.into(FailedUpdateLogs).entries({
                    ID: cds.utils.uuid(),  // Generate a unique ID
                    Material: statusUpdateResult.Material,
                    Plant: statusUpdateResult.Plant,
                    MessageType: statusUpdateResult.Type,
                    Message: statusUpdateResult.Message,
                    Timestamp: new Date() // Store current timestamp
                });
                return "Failed";
            }
        }


        // follow ups for dependend objects
        try {
            const DepObjService = await cds.connect.to('MatDepObjsService');
            const MatBomService = await cds.connect.to('MatBomsService');
            const ApoService = await cds.connect.to('ApoService');

            if (yStatus === 'Y3') {

                const resultDateUpdateY3 = await updateMaterialPlantDateStatus({
                    data: {
                        "material": req.data.material,
                        "plant": req.data.plant,
                        "date": formattedDate,
                        "field": "YYA_LC_Y3"
                    }
                });

                if (resultDateUpdateY3 === "Success")
                    return "Success";
                else
                    return "Failed to update dependend objects";

            } else if (yStatus === 'Y4') {
                const resultDepObjBom = await MatBomService.tx(req).send('setBomToInactive', {
                    material: req.data.material,
                    plant: req.data.plant
                });
                const resultDepObjMasterPrd = await DepObjService.tx(req).send('setMasterPrdToInactive', {
                    material: req.data.material,
                    plant: req.data.plant
                });

                const resultDateUpdateY4 = await updateMaterialPlantDateStatus({
                    data: {
                        "material": req.data.material,
                        "plant": req.data.plant,
                        "date": formattedDate,
                        "field": "YYA_LC_Y4"
                    }
                });

                if (resultDepObjBom === "Success" && resultDepObjMasterPrd === "Success" && resultDateUpdateY4 === "Success")
                    return "Success";
                else
                    return "Failed to update dependend objects";


            } else if (yStatus === 'Y5') {
                const resultDepObjBom = await MatBomService.tx(req).send('setBomToDelete', {
                    material: req.data.material,
                    plant: req.data.plant
                });
                const resultDepObjMasterPrd = await DepObjService.tx(req).send('setMasterPrdToDelete', {
                    material: req.data.material,
                    plant: req.data.plant
                });
                const resultDepObjPirSourcelist = await DepObjService.tx(req).send('setPirSourcelistToDelete', {
                    material: req.data.material,
                    plant: req.data.plant
                });

                const resultApoUpdate = await ApoService.tx(req).send('updateStatusCluster2Obs', {
                    material: req.data.material,
                    plant: req.data.plant
                });

                 const resultDateUpdateY5 = await updateMaterialPlantDateStatus({
                    data: {
                        "material": req.data.material,
                        "plant": req.data.plant,
                        "date": formattedDate,
                        "field": "YYA_LC_Y5"
                    }
                }); 

                if (resultDepObjBom === "Success" && resultDepObjMasterPrd === "Success" && resultDepObjPirSourcelist === "Success" && resultApoUpdate === "Success" && resultDateUpdateY5 === "Success")
                    return "Success";
                else
                    return "Failed to update dependend objects";
            } else {
                return "Success"; // no follow up necessary
            }


        } catch (error) {
            cds.log("PlantStatusUpdate").error(error.message);
            return "Failed to update dependend objects";
        }
    }
}

async function updateUniqueComponent4MaterialPlantStatus( originMaterial, plant, yStatus, formattedDate, projectId, isFasttrack, sourceSystem ) {

    // only for Status Y3
    if ( yStatus !== 'Y3' )
        return;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    const { CompUsage } = cds.entities('ppe.cm.md');

    let aComponent = await SELECT.from(CompUsage).columns(`component_id`).where({
        projectID: projectId,
        fg_idh: originMaterial,
        plant: plant,
        unique: true
    });

    for (let component of aComponent) {
        if (sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST marc(Material='${component.component_id}',Plant='${plant}')/SAP__self.chg_status_plant HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_plant": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST marc(Material='${component.component_id}',Plant='${plant}')/SAP__self.chg_status_plant HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_plant": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;

    if (flag92) {
        const matApi = await cds.connect.to("Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // extract successful one's alone
    const aSuccessfulItems = [];
    aFinalResponse.forEach((result, index) => result.Type === 'S' ? aSuccessfulItems.push(index) : null);

    for( let index in aSuccessfulItems ){
        if (sourceSystem === "92") {
            const matApi = await cds.connect.to("Materials");
            await matApi.send({
                method: 'POST',
                path: `/marc(Material='${aComponent[index].component_id}',Plant='${plant}')/SAP__self.chg_valid_date_plant`,
                data: {
                    field: "YYA_LC_Y3",
                    date: formattedDate,
                    project_id: `${projectId}`
                 }
            });
        }
        else {
            const matApi = await cds.connect.to("APAC_Materials");
            await matApi.send({
                method: 'POST',
                path: `/marc(Material='${aComponent[index].component_id}',Plant='${plant}')/SAP__self.chg_valid_date_plant`,
                data: {
                    field: "YYA_LC_Y3",
                    date: formattedDate,
                    project_id: `${projectId}`
                 }
            });
        }
    }
}

async function updateMaterialPlantSAStatus(req, res) {
    const material = req.data.material;
    const yStatus = req.data.status;
    const projectUuid = req.data.projectUuid;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    let isFasttrack = false;

    const { ProjectHeaders, ProjectIDHPlants, ProjectIDHSalesArea, ProjectIDHs } = cds.entities('ComplexityManagement');

    let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: projectUuid });
    let projectId = '';
    if (aProjectID.length > 0) {
        projectId = aProjectID[0].projectID;
    };

    let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
        l_ev_uuid: projectUuid,
        material: material
    });

    if (aProjectIdhScenario.length > 0 && (aProjectIdhScenario[0].phaseOutScenario === "Fasttrack" || aProjectIdhScenario[0].phaseOutScenario === "ActSAInactivePL")) {
        isFasttrack = true;
    }

    let idhPlantUuid = await SELECT.from(ProjectIDHPlants).columns(`uuid`).where({
        l_ev_uuid: projectUuid,
        material: material,
        phaseOutNEEDED: `Yes`,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    let aIdhPlantUuids = idhPlantUuid.map(idhPlant => idhPlant.uuid);

    let idhPlantSalesAreas = await SELECT.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`, `sourceSystem`).where({
        l_ev_uuid: {
            in: aIdhPlantUuids
        }
    });

    for await (let idhPlantSalesArea of idhPlantSalesAreas) {
        if (idhPlantSalesArea.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matApi = await cds.connect.to("Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

    if (bAllSuccess) {
        await UPDATE(ProjectIDHSalesArea).with(
            {
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0]
            }
        ).where({
            l_ev_uuid: {
                in: aIdhPlantUuids
            }
        });
        return "Success";
    } else {

        // extract successful one's alone and update project transaction tables
        const aSuccessfulItems = [];
        aFinalResponse.forEach((result, index) => result.Type === 'S' ? aSuccessfulItems.push(index) : null);

        let aIdhSalesAreaSuccess = aSuccessfulItems.map((item) => idhPlantSalesAreas[item].uuid);

        if (aIdhSalesAreaSuccess.length > 0) {
            await UPDATE(ProjectIDHSalesArea).with({
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0]
            }).where({
                uuid: {
                    in: aIdhSalesAreaSuccess
                }
            });
        }

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        // good to show the sales area also in the message (write now this is the quick and dirty solution)
        const aFailedItems = aFinalResponse.filter((result) => result.Type !== 'S');
        const sErrorMessages = aFailedItems.map(failedItem => `Material: ${failedItem.Material}, SalesOrg: ${failedItem.Vkorg}, DistributionChannel: ${failedItem.Vtweg},` +
            `MessageType: ${failedItem.Type}, Message: ${failedItem.Message}`).join("|");
        cds.log("SalesAreaStatusUpdate").error(sErrorMessages);
        await INSERT.into(FailedUpdateLogs).entries(aFailedItems.map(failedItem => ({
            ID: cds.utils.uuid(),
            Material: failedItem.Material,
            SalesOrg: failedItem.SalesOrg,
            DistributionChannel: failedItem.DistributionChannel,
            MessageType: failedItem.Type,
            Message: failedItem.Message,
            Timestamp: new Date()
        })));
        return "Atleast one update failed";
    }
}

async function updateMaterialPlantSalesAreaStatus(req, res) {
    const material = req.data.material;
    const yStatus = req.data.status;
    const plantUuid = req.data.plantUuid;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    let isFasttrack = false;
    let projectId = '';

    const { ProjectHeaders, ProjectIDHSalesArea, ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        uuid: plantUuid
    });

    if (aProjectUuid.length > 0) {
        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });
        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };

        let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
            l_ev_uuid: aProjectUuid[0].l_ev_uuid,
            material: material
        });

        if (aProjectIdhScenario.length > 0 && aProjectIdhScenario[0].phaseOutScenario === "Fasttrack") {
            isFasttrack = true;
        }
    }

    let idhPlantSalesAreas = await SELECT.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`, `sourceSystem`).where({
        l_ev_uuid: plantUuid
    });

    for await (let idhPlantSalesArea of idhPlantSalesAreas) {
        if (idhPlantSalesArea.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matApi = await cds.connect.to("Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

    if (bAllSuccess) {

        await UPDATE(ProjectIDHSalesArea).with(
            {
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0]
            }
        ).where({
            l_ev_uuid: plantUuid
        });
        return "Success";
    } else {

        // extract successful one's alone and update project transaction tables
        const aSuccessfulItems = [];
        aFinalResponse.forEach((result, index) => result.Type === 'S' ? aSuccessfulItems.push(index) : null);

        let aIdhSalesAreaSuccess = aSuccessfulItems.map((item) => idhPlantSalesAreas[item].uuid);

        if (aIdhSalesAreaSuccess.length > 0) {
            await UPDATE(ProjectIDHSalesArea).with({
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0]
            }).where({
                uuid: {
                    in: aIdhSalesAreaSuccess
                }
            });
        }

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        // good to show the sales area also in the message (write now this is the quick and dirty solution)
        const aFailedItems = aFinalResponse.filter((result) => result.Type !== 'S');
        const sErrorMessages = aFailedItems.map((failedItem => `Material: ${failedItem.Material}, SalesOrg: ${failedItem.Vkorg}, DistributionChannel: ${failedItem.Vtweg},` +
            `MessageType: ${failedItem.Type}, Message: ${failedItem.Message}`)).join("|");
        cds.log("SalesAreaStatusUpdate").error(sErrorMessages);
        await INSERT.into(FailedUpdateLogs).entries(aFailedItems.map(failedItem => ({
            ID: cds.utils.uuid(),
            Material: failedItem.Material,
            SalesOrg: failedItem.SalesOrg,
            DistributionChannel: failedItem.DistributionChannel,
            MessageType: failedItem.Type,
            Message: failedItem.Message,
            Timestamp: new Date()
        })));
        return "Atleast one update failed";
    }
}
async function updateMaterialPlantDateStatus(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;
    const field = req.data.field;
    let datum = req.data.date;
    let projectId = '';
    const { ProjectHeaders, ProjectIDHPlants, MatPlants } = cds.entities('ComplexityManagement');
    cds.log("updateMaterialPlantDateStatus").info(`Date for all field ${datum}`);
    if (datum.length === 10) {
        const dDate = new Date(datum);
        datum = dDate.getFullYear().toString() + (dDate.getMonth() + 1).toString().padStart(2, '0') + dDate.getDate().toString().padStart(2, '0');
        cds.log("updateMaterialPlantDateStatus").info(`Date for all field ${datum}`);
    }
    let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
        matnr: material,
        werks: plant
    });

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    if (aSourceSystem.length > 0) {
        if (aSourceSystem[0].source_system === "92") {
            const matApi = await cds.connect.to("Materials");

            let statusUpdateResult = await matApi.send({
                method: 'POST',
                path: `/marc(Material='${material}',Plant='${plant}')/SAP__self.chg_valid_date_plant`,
                data: {
                    field: field,
                    date: datum,
                    project_id: `${projectId}`
                }
            });

            if (statusUpdateResult?.Type === 'S') {
                return "Success";
            } else {
                cds.log("PlantStatusUpdate").error({ Material: statusUpdateResult?.Material, Plant: statusUpdateResult?.Plant, MessageType: statusUpdateResult?.Type, Message: statusUpdateResult?.Message });
                await INSERT.into(FailedUpdateLogs).entries({
                    ID: cds.utils.uuid(),  // Generate a unique ID
                    Material: statusUpdateResult.Material,
                    Plant: statusUpdateResult.Plant,
                    MessageType: statusUpdateResult.Type,
                    Message: statusUpdateResult.Message,
                    Timestamp: new Date() // Store current timestamp
                });
                return "Failed";
            }
        } else {
            const matApi = await cds.connect.to("APAC_Materials");

            let statusUpdateResult = await matApi.send({
                method: 'POST',
                path: `/marc(Material='${material}',Plant='${plant}')/SAP__self.chg_valid_date_plant`,
                data: {
                    field: field,
                    date: datum,
                    project_id: `${projectId}`
                }
            });

            if (statusUpdateResult?.Type === 'S') {
                return "Success";
            } else {
                cds.log("PlantStatusUpdate").error({ Material: statusUpdateResult?.Material, Plant: statusUpdateResult?.Plant, MessageType: statusUpdateResult?.Type, Message: statusUpdateResult?.Message });
                await INSERT.into(FailedUpdateLogs).entries({
                    ID: cds.utils.uuid(),  // Generate a unique ID
                    Material: statusUpdateResult.Material,
                    Plant: statusUpdateResult.Plant,
                    MessageType: statusUpdateResult.Type,
                    Message: statusUpdateResult.Message,
                    Timestamp: new Date() // Store current timestamp
                });
                return "Failed";
            }
        }
    }

}
async function getDemandPlanners(req, res) {
    const material = req.data.material;
    const projectUuid = req.data.projectUuid;
    const regionScope = req.data.regionScope;

    // fetch regions from the project
    const { ProjectIDHs } = cds.entities('ComplexityManagement');

    let idhRegionScopes = await SELECT.from(ProjectIDHs).columns(`uuid`, `regionScope`).where({
        l_ev_uuid: projectUuid,
        material: material,
        phaseOutNEEDED: true
    });

    let aRegionScope = idhRegionScopes.map(regionScope => `Region eq '${regionScope.regionScope}'`);
    let sRegionFilter = aRegionScope.join(" or ");
    let filter = `Material eq '${material}' and (${sRegionFilter})`;

    const apoDemandPlannerApi = await cds.connect.to("ApoDp");
    let response = await apoDemandPlannerApi.get(`/DpData?$filter=${filter}`);
    let uniqueresponse = response.filter(
        (obj, index, self) =>
            index === self.findIndex((t) => t.DemandPlanner === obj.DemandPlanner && t.Email === obj.Email)
    );
    const { ReplaceEmailWorkflow } = cds.entities('ppe.cm.pd');
    const replaceMail = await SELECT.from(ReplaceEmailWorkflow).columns(`regionScope`, `dp_email`);
    if (uniqueresponse.length > 0 && replaceMail.length > 0) {
        for (let i = 0; i < uniqueresponse.length; i++) {
            if (uniqueresponse[i].Email === "") {
                let filteredEmailResults = replaceMail.filter(item => item.regionScope === uniqueresponse[i].Region);
                if (filteredEmailResults.length > 0) {
                    uniqueresponse[i].Email = filteredEmailResults[0].dp_email;
                }
            }
        }
    }
    uniqueresponse = uniqueresponse.map(item => `${item.DemandPlanner}|${item.Email}`);

    return uniqueresponse.join(";");

}
async function getMrpController(req, res) {
    const material = req.data.material;
    const projectUuid = req.data.projectUuid;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];

    const { ProjectIDHPlants, ProjectIDHSalesArea } = cds.entities('ComplexityManagement');

    let idhPlantUuid = await SELECT.from(ProjectIDHPlants).columns(`plant`, `sourceSystem`, `mrpController`).where({
        l_ev_uuid: projectUuid,
        material: material,
        phaseOutNEEDED: `Yes`
        // regionScope: regionScope
    });

    for await (let idhPlant of idhPlantUuid) {
        if (idhPlant.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MrpCtrl(Werks='${idhPlant.plant}',Dispo='${idhPlant.mrpController}')?$expand=to_user_item HTTP/1.1\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET MrpCtrl(Werks='${idhPlant.plant}',Dispo='${idhPlant.mrpController}')?$expand=to_user_item HTTP/1.1\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;

    if (flag92) {
        const matApi = await cds.connect.to("Planner");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Planner");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

    if (bAllSuccess) {
        return "Success";
    } else {
        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        // good to show the sales area also in the message (write now this is the quick and dirty solution)
        const aFailedItems = aFinalResponse.filter((result) => result.Type !== 'S');
        const sErrorMessages = aFailedItems.map((failedItems) => failedItems.Message).join("|");
        cds.log("SalesAreaStatusUpdate", sErrorMessages);
        return "Atleast one update failed";

    }
}

async function setBomToInactive(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];

    const { ProjectHeaders, ProjectIDHPlants } = cds.entities('ComplexityManagement');

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    const ComplexityManagementService = await cds.connect.to('ComplexityManagement');
    let depObjBoms = await ComplexityManagementService.tx(req).send('getDepObjBoms', {
        uuid: aProjectUuid[0].l_ev_uuid
    });

    let depObjBomsFiltered = depObjBoms.filter((r) => r.material == material && r.plant == plant);

    for await (let depObjBom of depObjBomsFiltered) {
        if (depObjBom.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST Bom(Material='${depObjBom.material}',Plant='${depObjBom.plant}',BomUsage='${depObjBom.stlan}',BomAlternative='${depObjBom.stlal}')/SAP__self.bom_inactive HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST Bom(Material='${depObjBom.material}',Plant='${depObjBom.plant}',BomUsage='${depObjBom.stlan}',BomAlternative='${depObjBom.stlal}')/SAP__self.bom_inactive HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matBomApi = await cds.connect.to("MatBoms");
        let sResult = await matBomApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matBomApi = await cds.connect.to("APAC_MatBoms");
        let sResult = await matBomApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Error === false);

    if (bAllSuccess) {
        return "Success";
    } else {

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        const aFailedItems = aFinalResponse.filter((result) => result.Error === true);
        const sErrorMessages = aFailedItems.map((failedItems) => failedItems.Message).join("|");
        cds.log("SetBomToInactive").error(sErrorMessages);
        return "Atleast one update failed";
    }
}

async function setBomToDelete(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    let projectId = '';

    const { ProjectHeaders, ProjectIDHPlants } = cds.entities('ComplexityManagement');

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    const ComplexityManagementService = await cds.connect.to('ComplexityManagement');
    let depObjBoms = await ComplexityManagementService.tx(req).send('getDepObjBoms', {
        uuid: aProjectUuid[0].l_ev_uuid
    });

    let depObjBomsFiltered = depObjBoms.filter((r) => r.material == material && r.plant == plant);

    for await (let depObjBom of depObjBomsFiltered) {
        if (depObjBom.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST Bom(Material='${depObjBom.material}',Plant='${depObjBom.plant}',BomUsage='${depObjBom.stlan}',BomAlternative='${depObjBom.stlal}')/SAP__self.bom_delete HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag92 = true;
        }
        else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST Bom(Material='${depObjBom.material}',Plant='${depObjBom.plant}',BomUsage='${depObjBom.stlan}',BomAlternative='${depObjBom.stlal}')/SAP__self.bom_delete HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"project_id": "${projectId}"}\r\n\r\n\r\n`;
            flag93 = true;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matBomApi = await cds.connect.to("MatBoms");
        let sResult = await matBomApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matBomApi = await cds.connect.to("APAC_MatBoms");
        let sResult = await matBomApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Error === false);

    if (bAllSuccess) {
        return "Success";
    } else {

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        const aFailedItems = aFinalResponse.filter((result) => result.Error === true);
        const sErrorMessages = aFailedItems.map((failedItems) => failedItems.Message).join("|");
        cds.log("SetBomToInactive").error(sErrorMessages);
        return "Atleast one update failed";
    }
}

async function setMasterPrdToInactive(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;
    const { ProjectHeaders, MatPlants, ProjectIDHPlants } = cds.entities('ComplexityManagement');

    let projectId = '';

    let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
        matnr: material,
        werks: plant
    });

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    if (aSourceSystem.length > 0) {
        if (aSourceSystem[0].source_system === "92") {
            const depObjApi = await cds.connect.to("DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/master_prd_inactive`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setMasterPrdToInactive").error(updateResult?.Message);
                return "Failed";
            }
        } else {
            const depObjApi = await cds.connect.to("APAC_DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/master_prd_inactive`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setMasterPrdToInactive").error(updateResult?.Message);
                return "Failed";
            }
        }
    }
}

async function setMasterPrdToDelete(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;
    const { ProjectHeaders, MatPlants, ProjectIDHPlants } = cds.entities('ComplexityManagement');

    let projectId = '';

    let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
        matnr: material,
        werks: plant
    });

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    if (aSourceSystem.length > 0) {
        if (aSourceSystem[0].source_system === "92") {
            const depObjApi = await cds.connect.to("DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/master_prd_delete`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setMasterPrdToDelete").error(updateResult?.Message);
                return "Failed";
            }
        } else {
            const depObjApi = await cds.connect.to("APAC_DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/master_prd_delete`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setMasterPrdToDelete").error(updateResult?.Message);
                return "Failed";
            }
        }
    }
}

async function setPirSourcelistToDelete(req, res) {
    const material = req.data.material;
    const plant = req.data.plant;
    const { MatPlants, ProjectIDHPlants, ProjectHeaders } = cds.entities('ComplexityManagement');

    let projectId = '';

    let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
        matnr: material,
        werks: plant
    });

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
        material: material,
        plant: plant,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length > 0) {

        let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });

        if (aProjectID.length > 0) {
            projectId = aProjectID[0].projectID;
        };
    };

    if (aSourceSystem.length > 0) {
        if (aSourceSystem[0].source_system === "92") {
            const depObjApi = await cds.connect.to("DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/pir_sourcelist_delete`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setPirSourcelistToDelete").error(updateResult?.Message);
                return "Failed";
            }
        } else {
            const depObjApi = await cds.connect.to("APAC_DepObjects");
            let updateResult = await depObjApi.send({
                method: 'POST',
                path: `/pir_sourcelist_delete`,
                data: {
                    material: material,
                    plant: plant,
                    project_id: `${projectId}`
                }
            });

            if (updateResult?.Error === false) {
                return "Success";
            } else {
                cds.log("setPirSourcelistToDelete").error(updateResult?.Message);
                return "Failed";
            }
        }
    }
}

async function checkForVulnerability(req, res) {

    if (req.event === 'DELETE')
        req.reject(406, "Not accepted");

    if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
        const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
        const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
        let payload = JSON.stringify(req.data);

        sBlacklistExactTokens.forEach((token) => {
            const regex = new RegExp(`\\b${token}\\b`);
            if (payload.toLowerCase().match(regex))
                req.reject(406, "Not accepted");
        });
        sBlacklistIncludeTokens.forEach((token) => {
            if (payload.toLowerCase().includes(token))
                req.reject(406, "Not accepted");
        });

        Object.keys(req.data).forEach((key) => {
            if (key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")) {

                // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                if (!emailRegex.test(req.data[key]))
                    req.reject(406, "Not accepted - Invalid email format");
            }
        });
    }
}

async function updateSaleStatusScenario03(req, res) {
    const material = req.data.material;
    const yStatus = 'Y5';
    const projectID = req.data.projectID;
    const salesOrg = req.data.salesOrg;
    const distChanel = req.data.distChanel;
    const sourceSystem = req.data.sourceSystem;
    const uuid = req.data.uuid;
    const openTransactionSales = req.data.openTransactionSales;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    let isFasttrack = false;
    if (openTransactionSales === 'No') {
        isFasttrack = true;
    }

    const { ProjectHeaders, ProjectIDHPlants, ProjectIDHSalesArea, ProjectIDHs, ProjectStatuses } = cds.entities('ComplexityManagement');

    // let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: projectUuid });
    // let projectId = '';
    // if (aProjectID.length > 0) {
    //     projectId = aProjectID[0].projectID;
    // };

    // let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
    //     l_ev_uuid: projectUuid,
    //     material: material
    // });

    // if (aProjectIdhScenario.length > 0 && (aProjectIdhScenario[0].phaseOutScenario === "Fasttrack" || aProjectIdhScenario[0].phaseOutScenario === "ActSAInactivePL")) {
    //     isFasttrack = true;
    // }

    // let idhPlantUuid = await SELECT.from(ProjectIDHPlants).columns(`uuid`).where({
    //     l_ev_uuid: projectUuid,
    //     material: material,
    //     phaseOutNEEDED: `Yes`,
    //     phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    // });

    // let aIdhPlantUuids = idhPlantUuid.map(idhPlant => idhPlant.uuid);

    // let idhPlantSalesAreas = await SELECT.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`, `sourceSystem`).where({
    //     l_ev_uuid: {
    //         in: aIdhPlantUuids
    //     }
    // });

    // for await (let idhPlantSalesArea of idhPlantSalesAreas) {
    // await new Promise(resolve => setTimeout(resolve, 2000));
    if (sourceSystem === "92") {
        data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${salesOrg}',Vtweg='${distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectID}"}\r\n\r\n\r\n`;
        flag92 = true;
    }
    else {
        data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${salesOrg}',Vtweg='${distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectID}"}\r\n\r\n\r\n`;
        flag93 = true;
    }
    // }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matApi = await cds.connect.to("Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

    if (bAllSuccess) {
        await UPDATE(ProjectIDHSalesArea).with(
            {
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0],
                phaseOutStatus_uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
            }
        ).where({
            uuid: uuid
        });

        // fetch current status code and identifier
        let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
            uuid: "1c290c86-d4ee-44e0-98df-87de0a09c945"
        });

        let aProjectUUID = await SELECT.from(ProjectHeaders).columns('uuid').where({ projectID: projectID });
        let projectUuid = '';
        if (aProjectUUID.length > 0) {
            projectUuid = aProjectUUID[0].uuid;
        };

        let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`uuid`).where({
            l_ev_uuid: projectUuid,
            material: material
        });
        const plantsDataForSales = await
            SELECT.from(ProjectIDHPlants, o => {
                o('*'),
                    o.projectIDHSalesAreas(items => { items('*') })
            }).where({ l_ev_uuid: projectUuid });

        let plantSalesData = plantsDataForSales.map(plant => ({
            ...plant,
            projectIDHSalesAreas: plant.projectIDHSalesAreas.map(sales => ({
                ...sales,
                material: plant.material,
                plant: plant.plant,
                regionScope: plant.regionScope,
                l_ev_id: projectUuid
            }))
        }));

        let filteredData = plantSalesData.flatMap(obj => obj.projectIDHSalesAreas);
        let filteredDataPhaseOut = filteredData.filter(item => item.phaseOutNEEDED === 'Yes');
        let filtercurrentData = filteredDataPhaseOut.filter(item => item.uuid === uuid);
        let finalFilterData = filteredDataPhaseOut.filter(item => item.material === filtercurrentData[0].material && item.plant === filtercurrentData[0].plant && item.regionScope === filtercurrentData[0].regionScope);
        let projectStatusUUID = finalFilterData.map(item => item.phaseOutStatus_uuid);

        if (projectStatusUUID.length > 0) {
            // fetch all plant status ordered by code ascending
            let aRegionStatus = await SELECT.from(ProjectStatuses).columns(`code`, `uuid`).where({
                uuid: {
                    in: projectStatusUUID
                }
            }).orderBy(`code`);

            // if received status is smaller then take the status identifier of received code
            // else take the status identifier of the index 0 (since it has min value in this index)
            const finalMinStatus = oCurrentStatus.code <= aRegionStatus[0].code ? oCurrentStatus.uuid : aRegionStatus[0].uuid;
            await UPDATE(ProjectIDHs).with({
                phaseOutStatus_uuid: finalMinStatus
            }).where({
                l_ev_uuid: projectUuid,
                material: material,
                regionScope: filtercurrentData[0].regionScope
            });
        }

        return "Success";
    } else {

        // extract successful one's alone and update project transaction tables
        const aSuccessfulItems = [];
        aFinalResponse.forEach((result, index) => result.Type === 'S' ? aSuccessfulItems.push(index) : null);

        // let aIdhSalesAreaSuccess = aSuccessfulItems.map((item) => idhPlantSalesAreas[item].uuid);

        // if (aIdhSalesAreaSuccess.length > 0) {
        //     await UPDATE(ProjectIDHSalesArea).with({
        //         salesyStatus: yStatus,
        //         yStatusValidfrom: new Date().toISOString().split('T')[0]
        //     }).where({
        //         uuid: {
        //             in: aIdhSalesAreaSuccess
        //         }
        //     });
        // }

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        // good to show the sales area also in the message (write now this is the quick and dirty solution)
        const aFailedItems = aFinalResponse.filter((result) => result.Type !== 'S');
        const sErrorMessages = aFailedItems.map(failedItem => `Material: ${failedItem.Material}, SalesOrg: ${failedItem.Vkorg}, DistributionChannel: ${failedItem.Vtweg},` +
            `MessageType: ${failedItem.Type}, Message: ${failedItem.Message}`).join("|");
        cds.log("SalesAreaStatusUpdate").error(sErrorMessages);
        await INSERT.into(FailedUpdateLogs).entries(aFailedItems.map(failedItem => ({
            ID: cds.utils.uuid(),
            Material: failedItem.Material,
            SalesOrg: failedItem.SalesOrg,
            DistributionChannel: failedItem.DistributionChannel,
            MessageType: failedItem.Type,
            Message: failedItem.Message,
            Timestamp: new Date()
        })));
        return "Updation failed";
    }
}

async function updateSalesAreaStatusScenario3(req, res) {
   const material = req.data.material;
    const yStatus = 'Y4';
    const projectID = req.data.projectID;
    const salesOrg = req.data.salesOrg;
    const distChanel = req.data.distChanel;
    const sourceSystem = req.data.sourceSystem;
    const uuid = req.data.uuid;
    const openTransactionSales = req.data.openTransactionSales;

    let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
    let isFasttrack = true;
    let projectId = '';
    // if (openTransactionSales === "Yes") {
    //     isFasttrack = true;
    // } else {
    //     isFasttrack = true
    // }
    const { ProjectHeaders, ProjectIDHSalesArea, ProjectIDHPlants, ProjectIDHs, ProjectStatuses, projectPlantSalesArea } = cds.entities('ComplexityManagement');

    // let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`).where({
    //     uuid: plantUuid
    // });

    // if (aProjectUuid.length > 0) {
    //     let aProjectID = await SELECT.from(ProjectHeaders).columns('projectID').where({ uuid: aProjectUuid[0].l_ev_uuid });
    //     if (aProjectID.length > 0) {
    //         projectId = aProjectID[0].projectID;
    //     };

    //     let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
    //         l_ev_uuid: aProjectUuid[0].l_ev_uuid,
    //         material: material
    //     });

    //     if (aProjectIdhScenario.length > 0 && aProjectIdhScenario[0].phaseOutScenario === "Fasttrack") {
    //         isFasttrack = true;
    //     }
    // }

    // let idhPlantSalesAreas = await SELECT.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`, `sourceSystem`).where({
    //     l_ev_uuid: plantUuid
    // });

    // await new Promise(resolve => setTimeout(resolve, 2000));
    if (sourceSystem === "92") {
        data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${salesOrg}',Vtweg='${distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectID}"}\r\n\r\n\r\n`;
        flag92 = true;
    }
    else {
        data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${material}',Vkorg='${salesOrg}',Vtweg='${distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${projectID}"}\r\n\r\n\r\n`;
        flag93 = true;
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;


    if (flag92) {
        const matApi = await cds.connect.to("Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data92
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    if (flag93) {
        const matApi = await cds.connect.to("APAC_Materials");
        let sStatusUpdateResult = await matApi.send({
            method: 'POST',
            path: '/$batch',
            headers: {
                'Content-Type': 'multipart/mixed;boundary=batch'
            },
            data: data93
        });

        // batch response needs to be decoded to identify individual one's
        // so use regex to find out JSON outputs from the total batch response
        let regex = /\{.*\}/g,
            oEachResponseIterator = sStatusUpdateResult.matchAll(regex);

        // use JSON parse to parse the string to JSON
        for await (let response of oEachResponseIterator) {
            aFinalResponse.push(JSON.parse(response[0]));
        }
    }

    // check if every result is success
    const bAllSuccess = aFinalResponse.every((result) => result.Type === 'S');

    if (bAllSuccess) {

        await UPDATE(ProjectIDHSalesArea).with(
            {
                salesyStatus: yStatus,
                yStatusValidfrom: new Date().toISOString().split('T')[0],
                phaseOutStatus_uuid : "90f96838-33c1-4a4a-87ed-82f0337370f5"
            }
        ).where({
            uuid: uuid
        });

        // let aProjectUUID = await SELECT.from(ProjectHeaders).columns('uuid').where({ projectID: projectID });
        // let projectUuid = '';
        // if (aProjectUUID.length > 0) {
        //     projectUuid = aProjectUUID[0].uuid;
        // };
        // fetch current status code and identifier
        let oCurrentStatus = await SELECT.one.from(ProjectStatuses).columns(`code`, `uuid`).where({
            uuid: "90f96838-33c1-4a4a-87ed-82f0337370f5"
        });
        const salesRegionData = await SELECT.from(projectPlantSalesArea).where({
            uuid: uuid
        });
        const salesData = await SELECT.from(projectPlantSalesArea).where({
            projectID: projectID,
            material: material,
            phaseOutNEEDED: 'Yes',
            regionScope : salesRegionData[0].regionScope
        });
        let filteredProjectStatusUUID = salesData.map(item => item.salesPhaseOutStatus);

         if (filteredProjectStatusUUID.length > 0) {
            // fetch all plant status ordered by code ascending
            let aRegionStatus = await SELECT.from(ProjectStatuses).columns(`code`, `uuid`).where({
                uuid: {
                    in: filteredProjectStatusUUID
                }
            }).orderBy(`code`);

            // if received status is smaller then take the status identifier of received code
            // else take the status identifier of the index 0 (since it has min value in this index)
            let finalMinStatus = oCurrentStatus.code <= aRegionStatus[0].code ? oCurrentStatus.uuid : aRegionStatus[0].uuid;
            await UPDATE(ProjectIDHs).with({
                phaseOutStatus_uuid: finalMinStatus
            }).where({
                l_ev_uuid: salesData[0].projectUUID,
                material: material,
                regionScope : salesRegionData[0].regionScope
            });
        }
        return "Success";
    } else {

        // extract successful one's alone and update project transaction tables
        const aSuccessfulItems = [];
        aFinalResponse.forEach((result, index) => result.Type === 'S' ? aSuccessfulItems.push(index) : null);

        // let aIdhSalesAreaSuccess = aSuccessfulItems.map((item) => idhPlantSalesAreas[item].uuid);

        // if (aIdhSalesAreaSuccess.length > 0) {
        //     await UPDATE(ProjectIDHSalesArea).with({
        //         salesyStatus: yStatus,
        //         yStatusValidfrom: new Date().toISOString().split('T')[0]
        //     }).where({
        //         uuid: {
        //             in: aIdhSalesAreaSuccess
        //         }
        //     });
        // }

        // if atleast one is not successful write the message to the logs
        // the logs should have concatenated failed messages with a pipe (|) separator 
        // good to show the sales area also in the message (write now this is the quick and dirty solution)
        const aFailedItems = aFinalResponse.filter((result) => result.Type !== 'S');
        const sErrorMessages = aFailedItems.map((failedItem => `Material: ${failedItem.Material}, SalesOrg: ${failedItem.Vkorg}, DistributionChannel: ${failedItem.Vtweg},` +
            `MessageType: ${failedItem.Type}, Message: ${failedItem.Message}`)).join("|");
        cds.log("SalesAreaStatusUpdate").error(sErrorMessages);
        await INSERT.into(FailedUpdateLogs).entries(aFailedItems.map(failedItem => ({
            ID: cds.utils.uuid(),
            Material: failedItem.Material,
            SalesOrg: failedItem.SalesOrg,
            DistributionChannel: failedItem.DistributionChannel,
            MessageType: failedItem.Type,
            Message: failedItem.Message,
            Timestamp: new Date()
        })));
        return "Update failed";
    }
}
module.exports = {
    MaterialService,
    MatStrLocs,
    MaterialStocks,
    MatBomsService,
    ApoService,
    PlannersService,
    MatDepObjsService,
    MatX03Service
}
