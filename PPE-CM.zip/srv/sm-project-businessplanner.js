
const cds = require('@sap/cds');
const { Types } = require('@sap/xssec');
const { SELECT } = require("@sap/cds/lib/ql/cds-ql");

class BusinessPlannerService extends cds.ApplicationService {
    init() {
        const { IdhProjectPlantSalesInfo } = this.entities;
        this.before('*', checkForVulnerability);
        this.on("READ", "PastForecast", fetchPastForecast);
        this.on("READ", "FutureForecast", fetchFutureForecast);
        this.on('getSPPhaseOutDate', async (req) => {
            const projectID = req.data.projectId;
            const material = req.data.material;
            const { ProjectHeaders, ProjectIDHPlants } = cds.entities('ppe.cm.pd');
            var result;
            var projectID_UUID = await SELECT.columns(["uuid"]).from(ProjectHeaders).where({ projectID: projectID });
            if (projectID_UUID.length > 0) {
                let projectIDHPlant_CONFDATE = await SELECT.columns(["uuid", "l_ev_uuid", "confDatePerRegion"]).from(ProjectIDHPlants).where({ l_ev_uuid: projectID_UUID[0].uuid, material: material });
                if (projectIDHPlant_CONFDATE.length > 0) {
                    let latest_date = projectIDHPlant_CONFDATE.reduce((latestItem, currentItem) => {
                        return new Date(currentItem.confDatePerRegion) > new Date(latestItem.confDatePerRegion) ? currentItem : latestItem;
                    });
                    result = latest_date.confDatePerRegion;
                    return result;
                }
            } else {
                result = "";
                return result;
            }

        });
        this.on("getSubstMat", async(req) => {
            console.log(req.data.projectID);
            const substMatArray = await SELECT.one.from(IdhProjectPlantSalesInfo).columns('material', 'projectID', 'subsMaterial').where({'material' : req.data.material, 'projectID' : req.data.projectID});
            console.log(substMatArray);
            if(substMatArray){
                return substMatArray.subsMaterial;
            }else{
                return "";
            }
    
        });
        super.init();
    }
}

async function checkForVulnerability(req, res) {
    if (req.event === 'DELETE')
        req.reject(406, "Not accepted");

    if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
        const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
        const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
        let payload = JSON.stringify(req.data);

        sBlacklistExactTokens.forEach((token) => {
            const regex = new RegExp(`\\b${token}\\b`);
            if (payload.toLowerCase().match(regex))
                req.reject(406, "Not accepted");
        });
        sBlacklistIncludeTokens.forEach((token) => {
            if (payload.toLowerCase().includes(token))
                req.reject(406, "Not accepted");
        });

        Object.keys(req.data).forEach((key) => {
            if (key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")) {

                // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                if (!emailRegex.test(req.data[key]))
                    req.reject(406, "Not accepted - Invalid email format");
            }
        });
    }
}

async function fetchPastForecast(req, res) {
    const material = extractFilters(req, 'Material');
    const demandPlanner = extractFilters(req, 'DemandPlanner');

    if (!material || !demandPlanner) {
        return req.reject(400, 'Required Input data is missing.');
    }

    let apoApi = await cds.connect.to("Apo");
    const { GetData_ApoDp } = apoApi.entities;
    let response = await apoApi.run(SELECT.from(GetData_ApoDp).where({
        Material: material,
        DemandPlanner: demandPlanner,
        Keyfigure: {
            in: ['YA_HSTCL', 'YA_HSTCL_Y1_PB', 'YA_HSTCL_Y2_PB']
        },
        ApoLevel: {
            in: ['2', '3', '4']
        }
    }));

    const oDate = new Date();
    let month = oDate.getMonth() + 1;
    let year = oDate.getFullYear();
    let fourMonthList = [];
    let finalResponse = [];
    let mLevelInfo = new Map();

    for (let i = 4; i > 0; i--) {
        if (month === 0) {
            month = 12;
            year = year - 1;
            fourMonthList.push(year.toString() + month.toString().padStart(2, "0"));
        } else
            fourMonthList.push(year.toString() + month.toString().padStart(2, "0"));
        month = month - 1;
    }

    // reverse the fourMonthList variable so that it is in increasing order
    // this allows usage of the month<index> necessary for the ordered month in the UI
    fourMonthList = fourMonthList.reverse();

    response.sort((a, b) => {
        // Compare Keyfigure (string comparison)
        if (a.Keyfigure !== b.Keyfigure) {
            return a.Keyfigure.localeCompare(b.Keyfigure);
        }

        // Compare shipto_country (string comparison)
        if (a.ShiptoCountry !== b.ShiptoCountry) {
            return a.ShiptoCountry.localeCompare(b.ShiptoCountry);
        }

        // Compare soldto (string comparison)
        if (a.Soldto !== b.Soldto) {
            return a.Soldto.localeCompare(b.Soldto);
        }

        // Compare month (numeric comparison - assuming 'YYYYMM' format)
        return a.Month - b.Month;
    });


    response.forEach((item) => {

        let sLevel = '';
        item.ShiptoCountry = item.ShiptoCountry === "" ? "TOTAL" : item.ShiptoCountry;
        item.Soldto = item.Soldto === "" ? "TOTAL" : item.Soldto;

        if (item.Keyfigure === 'YA_HSTCL')
            sLevel = 'Cleansed Sales History';
        else if (item.Keyfigure === 'YA_HSTCL_Y1_PB')
            sLevel = 'Cleansed Sales History / Orders Y-1';
        else
            sLevel = 'Cleansed Sales History / Orders Y-2';

        if (mLevelInfo.has(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`)) {
            let currentInfo = mLevelInfo.get(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`);
            const forecastMonth = `month${fourMonthList.indexOf(item.Month) + 1}`;
            currentInfo[forecastMonth] = parseInt(item.Value);
            mLevelInfo.set(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`, currentInfo);
        } else {
            let oLevelInfo = {
                level: sLevel,
                ShiptoCountry: item.ShiptoCountry,
                Soldto: item.Soldto,
                Material: item.Material,
                BaseUom: item.BaseUom,
                DemandPlanner: item.DemandPlanner,
                Keyfigure: item.Keyfigure
            };

            fourMonthList.forEach((yearMonth, index) => {
                let forecastMonth = `month${index + 1}`;
                if (yearMonth === item.Month) {
                    oLevelInfo[forecastMonth] = parseInt(item.Value);
                } else {
                    oLevelInfo[forecastMonth] = 0;
                }
            });

            mLevelInfo.set(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`, oLevelInfo);
        }
    });

    for (let key of Array.from(mLevelInfo.keys())) {
        let keyResult = mLevelInfo.get(key);

        keyResult['nodeId'] = key;

        if (key.startsWith('2')) {
            keyResult['parentNodeId'] = null;
            keyResult['hierarchyLevel'] = 0;
            keyResult['drillState'] = "expanded";
        } else if (key.startsWith('3')) {
            keyResult['parentNodeId'] = '2' + keyResult.Keyfigure + "TOTALTOTAL";
            keyResult['hierarchyLevel'] = 1;
            keyResult['drillState'] = "collapsed";
        } else {
            keyResult['parentNodeId'] = '3' + keyResult.Keyfigure + keyResult.ShiptoCountry + "TOTAL";
            keyResult['hierarchyLevel'] = 2;
            keyResult['drillState'] = "leaf";
        }

        finalResponse.push(keyResult);
    }

    return finalResponse;

}

async function fetchFutureForecast(req, res, next) {

    const material = extractFilters(req, 'Material');
    const demandPlanner = extractFilters(req, 'DemandPlanner');

    if (!material || !demandPlanner) {
        return req.reject(400, 'Required Input data is missing.');
    }

    let apoApi = await cds.connect.to("Apo");
    const { GetData_ApoDp } = apoApi.entities;
    let response = await apoApi.run(SELECT.from(GetData_ApoDp).where({
        Material: material,
        DemandPlanner: demandPlanner,
        Keyfigure: {
            in: ['YA_FCBL', 'YA_EVENTS', 'YA_FCTF']
        },
        ApoLevel: {
            in: ['2', '3', '4']
        }
    }));

    response.sort((a, b) => {
        // Compare Keyfigure (string comparison)
        if (a.Keyfigure !== b.Keyfigure) {
            return a.Keyfigure.localeCompare(b.Keyfigure);
        }

        // Compare shipto_country (string comparison)
        if (a.ShiptoCountry !== b.ShiptoCountry) {
            return a.ShiptoCountry.localeCompare(b.ShiptoCountry);
        }

        // Compare soldto (string comparison)
        if (a.Soldto !== b.Soldto) {
            return a.Soldto.localeCompare(b.Soldto);
        }

        // Compare month (numeric comparison - assuming 'YYYYMM' format)
        return a.Month - b.Month;
    });

    const oDate = new Date();
    let month = oDate.getMonth() + 1;
    let year = oDate.getFullYear();
    let twelveMonthList = [];
    let finalResponse = [];
    let mLevelInfo = new Map();

    for (let i = 0; i < 12; i++) {
        if (month === 13) {
            month = 1;
            year = year + 1;
            twelveMonthList.push(year.toString() + month.toString().padStart(2, "0"));
        } else {
            twelveMonthList.push(year.toString() + month.toString().padStart(2, "0"));
        }
        month = month + 1;
    }

    response.forEach((item) => {
        let sLevel = '';
        item.ShiptoCountry = item.ShiptoCountry === "" ? "TOTAL" : item.ShiptoCountry;
        item.Soldto = item.Soldto === "" ? "TOTAL" : item.Soldto;

        if (item.Keyfigure === 'YA_EVENTS')
            sLevel = 'Events';
        else if (item.Keyfigure === 'YA_FCBL')
            sLevel = 'Baseline FC';
        else
            sLevel = 'Total FC';

        if (mLevelInfo.has(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`)) {
            let currentInfo = mLevelInfo.get(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`);
            const forecastMonth = `month${twelveMonthList.indexOf(item.Month) + 1}`;
            currentInfo[forecastMonth] = parseInt(item.Value);
            mLevelInfo.set(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`, currentInfo);
        } else {
            let oLevelInfo = {
                level: sLevel,
                ShiptoCountry: item.ShiptoCountry,
                Soldto: item.Soldto,
                Material: item.Material,
                BaseUom: item.BaseUom,
                DemandPlanner: item.DemandPlanner,
                Keyfigure: item.Keyfigure
            };

            twelveMonthList.forEach((yearMonth, index) => {
                let forecastMonth = `month${index + 1}`;
                if (yearMonth === item.Month) {
                    oLevelInfo[forecastMonth] = parseInt(item.Value);
                } else {
                    oLevelInfo[forecastMonth] = 0;
                }
            });

            mLevelInfo.set(`${item.ApoLevel}${item.Keyfigure}${item.ShiptoCountry}${item.Soldto}`, oLevelInfo);
        }
    });

    for (let key of Array.from(mLevelInfo.keys())) {
        let keyResult = mLevelInfo.get(key);

        keyResult['nodeId'] = key;

        if (key.startsWith('2')) {
            keyResult['parentNodeId'] = null;
            keyResult['hierarchyLevel'] = 0;
            keyResult['drillState'] = "expanded";
        } else if (key.startsWith('3')) {
            keyResult['parentNodeId'] = '2' + keyResult.Keyfigure + "TOTALTOTAL";
            keyResult['hierarchyLevel'] = 1;
            keyResult['drillState'] = "collapsed";
        } else {
            keyResult['parentNodeId'] = '3' + keyResult.Keyfigure + keyResult.ShiptoCountry + "TOTAL";
            keyResult['hierarchyLevel'] = 2;
            keyResult['drillState'] = "leaf";
        }

        finalResponse.push(keyResult);
    }

    return finalResponse;
}

// async function fetchPastForecast(req, res, next) {

//     // (Material eq '33000' and ( ApoLevel eq '2' or ApoLevel eq '3' or ApoLevel eq '4' ) and ( Keyfigure eq 'YA_HSTCL' ) and DemandPlanner eq 'L1XM4')&$orderby=Material desc
//     const material = extractFilters(req, 'idh');
//     const demandPlanner = extractFilters(req, 'demandPlanner');

//     // Build query with input parameters
//     const pastForecastQuery = SELECT.from('GetData_ApoDp')
//         .where({
//             Material: material,
//             DemandPlanner: demandPlanner,
//             Keyfigure: 'YA_HSTCL',
//             ApoLevel: ['2', '3', '4']
//         })
//         .orderBy('Material');

//     let response = await fetchData(pastForecastQuery, res, next);

//     return response;
// }

// async function fetchBaselineForecast(req, res, next) {

//     const material = extractFilters(req, 'idh');
//     const demandPlanner = extractFilters(req, 'demandPlanner');

//     if (!material || !demandPlanner) {
//         return req.reject(400, 'Required Input data is missing.');
//     }

//     // Build query with input parameters
//     const baselineForecastQuery = SELECT.from('GetData_ApoDp')
//         .where({
//             Material: material,
//             DemandPlanner: demandPlanner,
//             Keyfigure: ['YA_FCBL', 'YA_EVENTS'],
//             ApoLevel: ['2', '3', '4']
//         })
//         .orderBy('Material');

//     let baseline = await fetchData(baselineForecastQuery, res, next);
//     let baseline_new = [];

//     baseline.forEach(line => {
//         line_new = {};

//         line_new.nID = line.nodeID;
//         line_new.level = line.level;
//         line_new.idh = line.idh;
//         line_new.unit = line.unit;
//         line_new.shipToCountry = line.shipToCountry;
//         line_new.soldTo = line.soldTo;
//         line_new.parentId = line.parentNodeId;
//         line_new.hLevel = line.hierarchyLevel;
//         line_new.demandPlanner = line.demandPlanner;
//         line_new.dState = line.drillState;
//         line_new.month1 = line.month1;
//         line_new.month2 = line.month2;
//         line_new.month3 = line.month3;
//         line_new.month4 = line.month4;
//         line_new.month5 = line.month5;
//         line_new.month6 = line.month6;
//         line_new.month7 = line.month7;
//         line_new.month8 = line.month8;
//         line_new.month9 = line.month9;
//         line_new.month10 = line.month10;
//         line_new.month11 = line.month11;
//         line_new.month12 = line.month12;

//         baseline_new.push(line_new);
//     });

//     return baseline_new.filter(item => item.hLevel === hierarchyLevel);

// }

// async function fetchData(query, res, next) {

//     // read data via odata call into sap system
//     const apoApi = await cds.connect.to("Apo");
//     let apoData = await apoApi.run(query);

//     // sort the array
//     apoData.sort((a, b) => {
//         // Compare Keyfigure (string comparison)
//         if (a.Keyfigure !== b.Keyfigure) {
//             return a.Keyfigure.localeCompare(b.Keyfigure);
//         }

//         // Compare shipto_country (string comparison)
//         if (a.ShiptoCountry !== b.ShiptoCountry) {
//             return a.ShiptoCountry.localeCompare(b.ShiptoCountry);
//         }

//         // Compare soldto (string comparison)
//         if (a.Soldto !== b.Soldto) {
//             return a.Soldto.localeCompare(b.Soldto);
//         }

//         // Compare month (numeric comparison - assuming 'YYYYMM' format)
//         return a.Month - b.Month;
//     });


//     // initiate variable
//     let tree = [];
//     let lv_node_id_2 = 1;
//     let lv_node_id_3 = 100;
//     let lv_node_id_4 = 1000;
//     let lv_month_count_2 = 0;
//     let lv_month_count_3 = 0;
//     let lv_month_count_4 = 0;
//     let ls_level_2 = {};
//     let ls_level_3 = {};
//     let ls_level_4 = {};
//     let lv_new_grp_level_2 = true;
//     let lv_new_grp_level_3 = true;

//     apoData.filter(lt_data_level_2 => (lt_data_level_2.ApoLevel == '2')).forEach(
//         ls_data_level_2 => {

//             if (ls_data_level_2.Keyfigure != ls_level_2.level && ls_level_2.level != undefined) {
//                 tree.push(ls_level_2);
//                 ls_level_2 = ls_level_3 = ls_level_4 = {};
//                 lv_node_id_2 = lv_node_id_2 + 1;
//                 lv_new_grp_level_2 = true;
//                 lv_month_count_2 = 0;
//             }

//             lv_month_count_2 = lv_month_count_2 + 1.

//             ls_level_2.nodeID = lv_node_id_2;
//             ls_level_2.demandPlanner = ls_data_level_2.DemandPlanner;
//             ls_level_2.level = ls_data_level_2.Keyfigure;
//             ls_level_2.idh = ls_data_level_2.Material;
//             ls_level_2.unit = ls_data_level_2.BaseUom;
//             ls_level_2.shipToCountry = ls_data_level_2.ShiptoCountry;
//             ls_level_2.soldTo = ls_data_level_2.Soldto;
//             ls_level_2.parentNodeId = 0;
//             ls_level_2.hierarchyLevel = ls_data_level_2.ApoLevel - 2;
//             ls_level_2.drillState = 'expanded';

//             // Assign the value

//             ls_level_2[`month${lv_month_count_2}`] = ls_data_level_2.Value;

//             // Level 3
//             if (lv_new_grp_level_2) {
//                 lv_new_grp_level_2 = false;
//                 lv_node_id_3 = lv_node_id_2 * 100;

//                 apoData.filter(lt_data_level_3 => (lt_data_level_3.ApoLevel == '3')).forEach(
//                     ls_data_level_3 => {

//                         if ((ls_data_level_3.Keyfigure != ls_level_3.level || ls_data_level_3.ShiptoCountry != ls_level_3.shipToCountry) && ls_level_3.level != undefined) {
//                             tree.push(ls_level_3);
//                             ls_level_3 = ls_level_4 = {};
//                             lv_node_id_3 = lv_node_id_3 + 1;
//                             lv_new_grp_level_3 = true;
//                             lv_month_count_3 = 0;
//                         }

//                         lv_month_count_3 = lv_month_count_3 + 1.

//                         ls_level_3.nodeID = lv_node_id_3;
//                         ls_level_3.level = ls_data_level_3.Keyfigure;
//                         ls_level_3.idh = ls_data_level_3.Material;
//                         ls_level_3.unit = ls_data_level_3.BaseUom;
//                         ls_level_3.demandPlanner = ls_data_level_3.DemandPlanner;
//                         ls_level_3.shipToCountry = ls_data_level_3.ShiptoCountry;
//                         ls_level_3.soldTo = ls_data_level_3.Soldto;
//                         ls_level_3.parentNodeId = ls_level_2.nodeID;
//                         ls_level_3.hierarchyLevel = ls_data_level_3.ApoLevel - 2;
//                         ls_level_3.drillState = 'expanded';
//                         // Assign the value
//                         ls_level_3[`month${lv_month_count_3}`] = ls_data_level_3.Value;


//                         // Level 4
//                         if (lv_new_grp_level_3) {
//                             lv_new_grp_level_3 = false;
//                             lv_node_id_4 = lv_node_id_3 * 100;
//                             lv_month_count_4 = 0.


//                             apoData.filter(lt_data_level_4 => (lt_data_level_4.ApoLevel == '4')).forEach(
//                                 ls_data_level_4 => {

//                                     if ((ls_data_level_4.Keyfigure != ls_level_4.level || ls_data_level_4.ShiptoCountry != ls_level_4.shipToCountry || ls_data_level_4.Soldto != ls_level_4.soldTo) && ls_level_4.level != undefined) {
//                                         tree.push(ls_level_4);
//                                         ls_level_4 = {};
//                                         lv_node_id_4 = lv_node_id_4 + 1;
//                                         lv_new_grp_level_4 = true;
//                                         lv_month_count_4 = 0;
//                                     }

//                                     lv_month_count_4 = lv_month_count_4 + 1.

//                                     ls_level_4.nodeID = lv_node_id_4;
//                                     ls_level_4.level = ls_data_level_4.Keyfigure;
//                                     ls_level_4.idh = ls_data_level_4.Material;
//                                     ls_level_4.demandPlanner = ls_data_level_4.DemandPlanner;
//                                     ls_level_4.unit = ls_data_level_4.BaseUom;
//                                     ls_level_4.shipToCountry = ls_data_level_4.ShiptoCountry;
//                                     ls_level_4.soldTo = ls_data_level_4.Soldto;
//                                     ls_level_4.parentNodeId = ls_level_3.nodeID;
//                                     ls_level_4.hierarchyLevel = ls_data_level_4.ApoLevel - 2;
//                                     ls_level_4.drillState = 'expanded';
//                                     // Assign the value
//                                     ls_level_4[`month${lv_month_count_4}`] = ls_data_level_4.Value;

//                                 });
//                             tree.push(ls_level_4);
//                         };
//                     });
//                 tree.push(ls_level_3);
//             };
//         });
//     tree.push(ls_level_2);

//     return tree;
// }

/*
async function fetchBaselineForecast(req, res, next) {
    const apoSnp = await cds.connect.to("Apo");
    return apoSnp.run(req.query);
}
*/

module.exports = {
    BusinessPlannerService
}

function extractFilters(req, field) {

    const filters = req.query.SELECT.where;

    if (filters) {
        for (let i = 0; i < filters.length; i++) {

            if (filters[i].xpr) {
                for (let j = 0; j < filters[i].xpr.length; j++) {
                    if (filters[i].xpr[j].ref && filters[i].xpr[j].ref[0] === field) {
                        return filters[i].xpr[j + 2].val;
                    }
                }
            }
            else {
                if (filters[i].ref && filters[i].ref[0] === field) {
                    return filters[i + 2].val;
                }
            }
        }
    }
}