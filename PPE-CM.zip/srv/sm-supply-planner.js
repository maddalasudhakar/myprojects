
// aggregate APO SNP Data
function aggrApoSnp(apoSnpSet) {
    const apoSNPData = apoSnpSet.reduce((acc, item) => {
        const key = `${item.Material}-${item.Location}`;
        if (!acc[key]) {
            acc[key] = {
                material: item.Material,
                plant: item.Location,
                value: 0
            };
        }
        const itemValue = parseFloat(item.Value) || 0;
        acc[key].value += itemValue;
        return acc;
    }, {});
    // Convert to array and format values at the end
    return Object.values(apoSNPData).map(entry => ({
        ...entry,
        value: parseFloat(entry.value.toFixed(3)) // Format here for output
    }));
}

async function triggerApoFetch(materials, plants) {
    const apoSnpApi = await cds.connect.to("Apo");
    const apoQuery = SELECT.from('GetData_ApoSnp')
        .where({ ApoLevel: '2', Material: { in: materials }, Location: { in: plants } });
    try {
        return await apoSnpApi.run(apoQuery);
    } catch (error) {
        cds.log("APOFetchError").error(error);
        return [];
    }
}

async function triggerMatStocksFetch(materials, plants) {
    const matStocksApi = await cds.connect.to("MatStocks");

    // const stockQuery = SELECT.from('Stock')
    const stockQuery = SELECT.from('stock_cal')
        .where({ Material: { in: materials }, Plant: { in: plants } });
    try {
        return await matStocksApi.run(stockQuery);
    } catch (error) {
        cds.log("MatStocksError").error(error);
        return [];
    }
}

async function triggerAPACMatStocksFetch(materials, plants) {
    const matStocksApi = await cds.connect.to("APAC_MatStocks");

    // const stockQuery = SELECT.from('Stock')
    const stockQuery = SELECT.from('stock_cal')
        .where({ Material: { in: materials }, Plant: { in: plants } });
    try {
        return await matStocksApi.run(stockQuery);
    } catch (error) {
        cds.log("APACMatStocksError").error(error);
        return [];
    }
}

async function triggerMatTypesFetch(materials) {
    const matTypesApi = await cds.connect.to("MaterialsX03");

    // const stockQuery = SELECT.from('Stock')
    const matTypesQuery = SELECT.from('mat_typ')
        .where({ Material: { in: materials } });
    try {
        return await matTypesApi.run(matTypesQuery);
    } catch (error) {
        cds.log("MatTypesError").error(error);
        return [];
    }
}

async function triggerMatTypesFetch(materials) {
    const matTypesApi = await cds.connect.to("MaterialsX03");

    // const stockQuery = SELECT.from('Stock')
    const matTypesQuery = SELECT.from('mat_typ')
        .where({ Material: { in: materials } });
    try {
        return await matTypesApi.run(matTypesQuery);
    } catch (error) {
        cds.log("MatTypesError").error(error);
        return [];
    }
}

function extractFilters(req, field) {
    const filters = req.query.SELECT.where;

    if (filters) {
        for (let i = 0; i < filters.length; i++) {

            if (filters[i].xpr) {
                for (let j = 0; j < filters[i].xpr.length; j++) {
                    if (filters[i].xpr[j].ref && filters[i].xpr[j].ref[0] === field) {
                        return filters[i].xpr[j + 2].val;
                    }
                }
            }
            else {
                if (filters[i].ref && filters[i].ref[0] === field) {
                    return filters[i + 2].val;
                }
            }
        }
    }
}

/**
 * Processes filters to separate child filters and clean parent filters.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @param {Array} childFilterFields - List of fields belonging to child entity.
 * @returns {Object} - An object containing cleaned filters and child filters.
 */
function processFilters(filters, childFilterFields) {
    let childFilters = {};
    let cleanedFilters = [];

    let index = 0;
    while (index < filters.length) {
        const filter = filters[index];

        if (isSimpleFilter(filter, filters, index)) {
            const fieldName = filter.ref[0];
            const fieldValue = filters[index + 2].val;

            if (childFilterFields.includes(fieldName)) {
                // Add to child filters
                addToChildFilters(childFilters, fieldName, fieldValue);
            } else {
                // Add valid filter to cleanedFilters
                cleanedFilters.push(filter, '=', filters[index + 2]);
            }
            index += 3; // Skip operator and value
        } else if (filter?.xpr) {
            // Process nested xpr filters
            const { cleanedGroup, nestedChildFilters } = processNestedXpr(filter.xpr, childFilterFields);

            // Merge nested child filters
            mergeChildFilters(childFilters, nestedChildFilters);

            if (cleanedGroup.length > 0) {
                cleanedFilters.push({ xpr: cleanedGroup });
            }
            index += 1;
        } else if (isLogicalOperator(filter)) {
            // Validate logical operators
            if (
                cleanedFilters.length > 0 && // There is a filter before this operator
                index + 1 < filters.length && // There is something after the operator
                !isLogicalOperator(filters[index + 1]) // The next element is not another operator
            ) {
                cleanedFilters.push(filter);
            }
            index += 1;
        } else {
            // Add unexpected structures directly
            cleanedFilters.push(filter);
            index += 1;
        }
    }

    return { cleanedFilters, childFilters };
}

/**
 * Processes nested xpr filters recursively.
 * @param {Array} xprFilters - The nested xpr filters array.
 * @param {Array} childFilterFields - List of fields belonging to child entity.
 * @returns {Object} - An object containing cleaned nested filters and child filters.
 */
function processNestedXpr(xprFilters, childFilterFields) {
    let cleanedGroup = [];
    let nestedChildFilters = {};

    let index = 0;
    while (index < xprFilters.length) {
        const filter = xprFilters[index];

        if (isSimpleFilter(filter, xprFilters, index)) {
            const fieldName = filter.ref[0];
            const fieldValue = xprFilters[index + 2].val;

            if (childFilterFields.includes(fieldName)) {
                // Add to child filters
                addToChildFilters(nestedChildFilters, fieldName, fieldValue);
            } else {
                // Add valid filter to cleanedGroup
                cleanedGroup.push(filter, '=', xprFilters[index + 2]);
            }
            index += 3; // Skip operator and value
        } else if (filter?.xpr) {
            const { cleanedGroup: deeperGroup, nestedChildFilters: deeperChildFilters } = processNestedXpr(
                filter.xpr,
                childFilterFields
            );

            // Merge deeper child filters
            mergeChildFilters(nestedChildFilters, deeperChildFilters);

            if (deeperGroup.length > 0) {
                cleanedGroup.push({ xpr: deeperGroup });
            }
            index += 1;
        } else if (isLogicalOperator(filter)) {
            // Validate logical operators
            if (
                cleanedGroup.length > 0 && // There is a filter before this operator
                index + 1 < xprFilters.length && // There is something after the operator
                !isLogicalOperator(xprFilters[index + 1]) // The next element is not another operator
            ) {
                cleanedGroup.push(filter);
            }
            index += 1;
        } else {
            cleanedGroup.push(filter);
            index += 1;
        }
    }

    return { cleanedGroup, nestedChildFilters };
}

/**
 * Removes orphan logical operators ('and', 'or') from the filter array.
 * @param {Array} filters - The filters array to clean.
 * @returns {Array} - The cleaned filters array.
 */
function removeOrphanLogicalOperators(filters) {
    const cleanedFilters = [];
    for (let i = 0; i < filters.length; i++) {
        const filter = filters[i];

        if (filter?.xpr) {
            // Recursively clean the nested `xpr` array
            const cleanedXpr = removeOrphanLogicalOperators(filter.xpr);
            if (cleanedXpr.length > 0) {
                cleanedFilters.push({ xpr: cleanedXpr });
            }
        } else if (
            isLogicalOperator(filter) &&
            (i === 0 || i === filters.length - 1 || isLogicalOperator(filters[i + 1]))
        ) {
            // Skip orphan logical operators
            continue;
        } else {
            cleanedFilters.push(filter);
        }
    }

    return cleanedFilters;
}

/**
 * Adds a value to the child filters object.
 * @param {Object} childFilters - The child filters object.
 * @param {string} field - The field name.
 * @param {string} value - The field value.
 */
function addToChildFilters(childFilters, field, value) {
    if (!childFilters[field]) {
        childFilters[field] = [];
    }
    if (!childFilters[field].includes(value)) {
        childFilters[field].push(value);
    }
}

/**
 * Merges two child filters objects.
 * @param {Object} target - The target child filters object.
 * @param {Object} source - The source child filters object.
 */
function mergeChildFilters(target, source) {
    for (const [field, values] of Object.entries(source)) {
        if (!target[field]) {
            target[field] = [];
        }
        values.forEach((value) => {
            if (!target[field].includes(value)) {
                target[field].push(value);
            }
        });
    }
}

/**
 * Formats the child filters into an array of objects.
 * @param {Object} childFilters - The child filters object.
 * @returns {Array} - An array of formatted child filters.
 */
function formatChildFilters(childFilters) {
    return Object.entries(childFilters).map(([field, values]) => ({
        field,
        values,
    }));
}

/**
 * Determines if a filter is a simple { ref }, '=', { val } structure.
 * @param {Object} filter - The current filter.
 * @param {Array} filters - The filters array.
 * @param {number} index - The current index in the array.
 * @returns {boolean} - True if the filter is a simple structure.
 */
function isSimpleFilter(filter, filters, index) {
    return filter?.ref && filters[index + 1] === '=' && filters[index + 2]?.val;
}

/**
 * Determines if a filter is a logical operator ('and', 'or').
 * @param {string} filter - The current filter.
 * @returns {boolean} - True if the filter is a logical operator.
 */
function isLogicalOperator(filter) {
    return filter === 'and' || filter === 'or';
}

/**
 * Checks if the filters contain `hierarchyLevel = 1`.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @returns {boolean} - True if `hierarchyLevel = 1` is present, otherwise false.
 */
function hasHierarchyLevelZero(filters) {
    for (let i = 0; i < filters.length; i++) {
        if (
            filters[i]?.ref &&
            filters[i].ref[0] === 'hierarchyLevel' &&
            filters[i + 1] === '=' &&
            filters[i + 2]?.val === 0
        ) {
            return true;
        }
    }
    return false;
}

/**
 * Checks if the filters contain `hierarchyLevel = 1`.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @returns {boolean} - True if `hierarchyLevel = 1` is present, otherwise false.
 */
function hasHierarchyLevelOne(filters) {
    for (let i = 0; i < filters.length; i++) {
        if (
            filters[i]?.ref &&
            filters[i].ref[0] === 'hierarchyLevel' &&
            filters[i + 1] === '=' &&
            filters[i + 2]?.val === 1
        ) {
            return true;
        }
    }
    return false;
}

/**
 * Checks if the filters contain any of the specified child filter fields.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @param {Array} childFilterFields - List of fields belonging to the child entity.
 * @returns {boolean} - True if any of the child filter fields are present, otherwise false.
 */
function containsChildFilterFields(filters, childFilterFields) {
    for (const filter of filters) {
        if (filter?.ref && childFilterFields.includes(filter.ref[0])) {
            return true;
        }
        if (filter?.xpr && containsChildFilterFields(filter.xpr, childFilterFields)) {
            // Recursively check nested `xpr` filters
            return true;
        }
    }
    return false;
}

/**
 * Checks if the filters contain any of the specified parent filter fields.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @param {Array} parentFilterFields - List of fields belonging to the child entity.
 * @returns {boolean} - True if any of the parent filter fields are present, otherwise false.
 */
function containsParentFilterFields(filters, parentFilterFields) {
    for (const filter of filters) {
        if (filter?.ref && parentFilterFields.includes(filter.ref[0])) {
            return true;
        }
        if (filter?.xpr && containsParentFilterFields(filter.xpr, parentFilterFields)) {
            // Recursively check nested `xpr` filters
            return true;
        }
    }
    return false;
}

/**
 * Removes filters based on specified parent filter fields and cleans up orphan logical operators.
 * @param {Array} filters - The filters array from req.query.SELECT.where.
 * @param {Array} parentFilterFields - List of fields to remove from the filters.
 * @returns {Array} - The cleaned filters array.
 */
function removeParentFilterFields(filters, parentFilterFields) {
    let cleanedFilters = [];
    let index = 0;

    while (index < filters.length) {
        const filter = filters[index];

        if (isSimpleFilter(filter, filters, index)) {
            const fieldName = filter.ref[0];

            if (!parentFilterFields.includes(fieldName)) {
                // Keep filters not in parentFilterFields
                cleanedFilters.push(filter, '=', filters[index + 2]);
            }
            // Skip the operator and value
            index += 3;
        } else if (filter?.xpr) {
            // Recursively process nested xpr filters
            const cleanedXpr = removeParentFilterFields(filter.xpr, parentFilterFields);
            if (cleanedXpr.length > 0) {
                cleanedFilters.push({ xpr: cleanedXpr });
            }
            index += 1;
        } else if (isLogicalOperator(filter)) {
            // Add logical operators only if not orphaned
            if (
                cleanedFilters.length > 0 && // There is something before this operator
                index + 1 < filters.length && // There is something after the operator
                !isLogicalOperator(filters[index + 1]) // The next item is not another operator
            ) {
                cleanedFilters.push(filter);
            }
            index += 1;
        } else {
            // Add unexpected structures directly
            cleanedFilters.push(filter);
            index += 1;
        }
    }

    // Perform a final cleanup to remove orphan logical operators
    return removeOrphanLogicalOperators(cleanedFilters);
}

/**
 * Checks if a child row matches the given child filters.
 * @param {Object} row - The child row to check.
 * @param {Array} childFilters - Array of child filter objects.
 * @returns {boolean} - True if the row matches all child filter conditions, otherwise false.
 */
function matchesChildFilters(row, childFilters) {
    return childFilters.every(filter => {
        const { field, values } = filter;
        return values.includes(row[field]); // Check if the row's field value is in the allowed values
    });
}

async function updateStockSnpData(res) {
    try {
        const SupplyPlanItemsData = res;
        const materials = [...new Set(SupplyPlanItemsData.map(item => item.material))];
        const plants = SupplyPlanItemsData
            .filter(item => item.hierarchyLevel === 1 && item.sourceSystem === '92')
            .map(item => item.regionOrPlant);
        const plantsAPAC = SupplyPlanItemsData
            .filter(item => item.hierarchyLevel === 1 && item.sourceSystem === '93')
            .map(item => item.regionOrPlant);
        const combinedPlants = [...new Set([...plants, ...plantsAPAC])];

        let promises = [];
        promises.push(triggerApoFetch(materials, combinedPlants));
        if (plants && plants.length > 0) {
            promises.push(triggerMatStocksFetch(materials, plants));
        }

        if (plantsAPAC && plantsAPAC.length > 0) {
            promises.push(triggerAPACMatStocksFetch(materials, plantsAPAC));
        }

        await Promise.all(promises)
            .then((data) => {
                let apoSnpSet = data[0];
                let stockSet = [];
                let stockSetAPAC = [];

                if (plants.length > 0 && plantsAPAC.length > 0) {
                    stockSet = data[1];
                    stockSetAPAC = data[2];
                } else if (plants.length > 0) {
                    stockSet = data[1];
                } else {
                    stockSetAPAC = data[1];
                }
                const aggrSnpSet = aggrApoSnp(apoSnpSet);

                res = SupplyPlanItemsData.map(spsRow => {
                    let material = spsRow.material.replace(/^0+/, '');
                    let stockAPAC = null;
                    let stock = null;
                    let apoSNP = null;


                    if (stockSet && stockSet.length > 0) {
                        stock = stockSet.find(stockItem =>
                            stockItem.Material === material && stockItem.Plant === spsRow.regionOrPlant
                        );
                        if (stock) {
                            spsRow.totalStockBUOM = parseFloat(stock.TsQuant).toFixed(3);
                            spsRow.totalStockValue = parseFloat(stock.TsValueLoc).toFixed(3);
                            spsRow.totalStockValueEur = parseFloat(stock.TsValueEur).toFixed(3);
                            spsRow.dysfuncStockBUOM = parseFloat(stock.DfsQuant).toFixed(3);
                            spsRow.dysfuncStockValue = parseFloat(stock.DfsValueLoc).toFixed(3);
                            spsRow.dysfuncStockValueEur = parseFloat(stock.DfsValueEur).toFixed(3);
                            spsRow.totalSaleableInvBUOM = parseFloat(stock.TsiQuant).toFixed(3);
                            spsRow.totalSaleableInvVal = parseFloat(stock.TsiValueLoc).toFixed(3);
                            spsRow.totalSaleableInvValEur = parseFloat(stock.TsiValueEur).toFixed(3);
                            spsRow.fixedReceiptsBUOM = parseFloat(stock.FixedReceipts).toFixed(3);
                            spsRow.fixedIssuesBUOM = parseFloat(stock.FixedIssues).toFixed(3);
                            spsRow.buom = stock.BaseUom;
                            spsRow.localCurr = stock.CurrLocal;
                        }
                    }

                    if (stockSetAPAC && stockSetAPAC.length > 0) {
                        stockAPAC = stockSetAPAC.find(stockItem =>
                            stockItem.Material === material && stockItem.Plant === spsRow.regionOrPlant
                        );
                        if (stockAPAC) {
                            spsRow.totalStockBUOM = parseFloat(stockAPAC.TsQuant).toFixed(3);
                            spsRow.totalStockValue = parseFloat(stockAPAC.TsValueLoc).toFixed(3);
                            spsRow.totalStockValueEur = parseFloat(stockAPAC.TsValueEur).toFixed(3);
                            spsRow.dysfuncStockBUOM = parseFloat(stockAPAC.DfsQuant).toFixed(3);
                            spsRow.dysfuncStockValue = parseFloat(stockAPAC.DfsValueLoc).toFixed(3);
                            spsRow.dysfuncStockValueEur = parseFloat(stockAPAC.DfsValueEur).toFixed(3);
                            spsRow.totalSaleableInvBUOM = parseFloat(stockAPAC.TsiQuant).toFixed(3);
                            spsRow.totalSaleableInvVal = parseFloat(stockAPAC.TsiValueLoc).toFixed(3);
                            spsRow.totalSaleableInvValEur = parseFloat(stockAPAC.TsiValueEur).toFixed(3);
                            spsRow.fixedReceiptsBUOM = parseFloat(stockAPAC.FixedReceipts).toFixed(3);
                            spsRow.fixedIssuesBUOM = parseFloat(stockAPAC.FixedIssues).toFixed(3);
                            spsRow.buom = stockAPAC.BaseUom;
                            spsRow.localCurr = stockAPAC.CurrLocal;
                        }
                    }
                    if (aggrSnpSet && aggrSnpSet.length > 0) {
                        apoSNP = aggrSnpSet.find(snpItem =>
                            snpItem.material === material && snpItem.plant === spsRow.regionOrPlant
                        );
                        if (apoSNP && !isNaN(apoSNP.value)) {
                            spsRow.forecastSNP = parseFloat((apoSNP.value)).toFixed(3);
                        } else {
                            spsRow.forecastSNP = parseFloat(0).toFixed(3);
                        }
                    }

                    const totalSaleableInvBUOM = parseFloat(spsRow.totalSaleableInvBUOM) || 0;
                    const fixedReceiptsBUOM = parseFloat(spsRow.fixedReceiptsBUOM) || 0;
                    const additionalProd = parseInt(spsRow.additionalProd) || 0;
                    const fixedIssuesBUOM = parseFloat(spsRow.fixedIssuesBUOM) || 0;
                    const forecastSNP = parseFloat(spsRow.forecastSNP) || 0;

                    const denominator = (fixedIssuesBUOM + forecastSNP) / 365;

                    // Avoid division by zero
                    if (denominator > 0) {
                        if (spsRow.makeToStrategy === 'MTS') {
                            spsRow.invCoverageDays = Math.round((totalSaleableInvBUOM + fixedReceiptsBUOM + additionalProd) / denominator);
                        } else {
                            // spsRow.invCoverageDays = Math.round((totalSaleableInvBUOM + fixedReceiptsBUOM ) / denominator);                            
                            spsRow.invCoverageDays = 0; // Default or fallback value
                        }
                    } else {
                        spsRow.invCoverageDays = 0; // Default or fallback value
                    }

                    return spsRow;
                });
            });
        return res;
    } catch (error) {
        cds.log("spLog").error(error);
    }
}

function aggregateParents(parents, childrens) {
    // Aggregate child data and update parent data
    const aggrParents = parents.map(parent => {
        // Filter the child data based on projectID, material, and regionOrPlant
        const filteredChildren = childrens.filter(child =>
            child.projectID === parent.projectID &&
            child.material === parent.material &&
            child.regionScope === parent.regionScope
        );

        // Aggregate quantity and amount from the filtered child data
        const totalStockValue = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalStockValue), 0).toFixed(3);
        const totalStockValueEur = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalStockValueEur), 0).toFixed(3);
        const totalStockBUOM = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalStockBUOM), 0).toFixed(3);
        const dysfuncStockBUOM = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.dysfuncStockBUOM), 0).toFixed(3);
        const dysfuncStockValue = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.dysfuncStockValue), 0).toFixed(3);
        const dysfuncStockValueEur = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.dysfuncStockValueEur), 0).toFixed(3);
        const totalSaleableInvBUOM = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalSaleableInvBUOM), 0).toFixed(3);
        const totalSaleableInvVal = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalSaleableInvVal), 0).toFixed(3);
        const totalSaleableInvValEur = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.totalSaleableInvValEur), 0).toFixed(3);
        const fixedReceiptsBUOM = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.fixedReceiptsBUOM), 0).toFixed(3);
        const fixedIssuesBUOM = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.fixedIssuesBUOM), 0).toFixed(3);
        const forecastSNP = filteredChildren.reduce((sum, child) => parseFloat(sum) + parseFloat(child.forecastSNP), 0).toFixed(3);

        const confDatePerRegion = filteredChildren.reduce((latest, child) => {
            if (!latest || child.confDatePerRegion > latest) {
                return child.confDatePerRegion;
            }
            return latest;
        }, null);

        // Return the updated parent with aggregated values
        return {
            ...parent,
            confDatePerRegion,
            totalStockValue,
            totalStockValueEur,
            totalStockBUOM,
            dysfuncStockBUOM,
            dysfuncStockValue,
            dysfuncStockValueEur,
            totalSaleableInvBUOM,
            totalSaleableInvVal,
            totalSaleableInvValEur,
            fixedReceiptsBUOM,
            fixedIssuesBUOM,
            forecastSNP,
        };
    });
    return aggrParents;
}

function updResData(res, aggrParents, updchildrens) {
    let response = res.map(item => {
        if (aggrParents && aggrParents.length > 0) {
            const aggrParent = aggrParents.find(parent => parent.projectID === item.projectID && parent.material === item.material && parent.regionScope === item.regionScope && parent.hierarchyLevel === item.hierarchyLevel);
            if (aggrParent) {
                item = { ...item, ...aggrParent };
            }
        }
        if (updchildrens && updchildrens.length > 0) {
            const updChild = updchildrens.find(child => child.projectID === item.projectID && child.material === item.material && child.regionOrPlant === item.regionOrPlant && child.hierarchyLevel === item.hierarchyLevel);
            if (updChild) {
                item = { ...item, ...updChild };
            }
        }
        return item;
    });
    return response;
}

async function updAggrStockSnp(res, childFilters) {
    let childrens = [];
    let parentIds = [];
    let parents = [];

    if (childFilters && childFilters.length > 0) {
        // Step 1: Filter children based on `childFilters`- that is part of the UI filter criteria
        childrens = res.filter(row => row.hierarchyLevel === 1 && matchesChildFilters(row, childFilters));
        // Step 2: Map children to their parents
        parentIds = new Set(childrens.map(child => child.parentId));
    } else {
        childrens = res.filter(row => row.hierarchyLevel === 1);
    }
    if (parentIds && parentIds.size > 0) {
        parents = res.filter(row => row.hierarchyLevel === 0 && parentIds.has(row.nodeId));
    } else {
        parents = res.filter(row => row.hierarchyLevel === 0);
    }


    if (parents && parents.length > 0) {
        // Update children data with stock and SNP Data
        updChildrens = await updateStockSnpData(childrens);
        if (updChildrens && updChildrens.length > 0) {
            const aggrParents = aggregateParents(parents, updChildrens);
            if (aggrParents && aggrParents.length > 0) {
                updAggrData = await updResData(res, aggrParents, updChildrens)
            }
        }
    } else if (childrens && childrens.length > 0) {
        updAggrData = await updateStockSnpData(childrens);
    }
    return { updAggrData, parentIds };
}

const cds = require('@sap/cds');
const { SELECT } = require('@sap/cds/lib/ql/cds-ql');

// To be 
let updChildItems = [];
let afterHandlerCallCount = 0;
const parentFilterFields = ['regionScope'];
const childFilterFields = ['plant', 'mrpControllerEmail'];

module.exports = cds.service.impl(async function () {
    const { AllMatTypes, SupplyPlanItems, RpSupplyPlanner, IdhProjectPlantSalesInfo} = this.entities;
    //const entries = this.entities;
    this.before('*', async (req) => {
        let oIndex = req.req?.params[0]?.search("RpSupplyPlanner");
        if (req.event === 'DELETE' && oIndex != 1)
            req.reject(406, "Not accepted");

        if (process.env.ACTIVATE_VULNERABILITY_CHECK) {
            const sBlacklistExactTokens = ['select', 'insert', 'update', 'delete', 'drop'];
            const sBlacklistIncludeTokens = ['<', '</', 'http', 'href'];
            let payload = JSON.stringify(req.data);

            sBlacklistExactTokens.forEach((token) => {
                const regex = new RegExp(`\\b${token}\\b`);
                if (payload.toLowerCase().match(regex))
                    req.reject(406, "Not accepted");
            });
            sBlacklistIncludeTokens.forEach((token) => {
                if (payload.toLowerCase().includes(token))
                    req.reject(406, "Not accepted");
            });

            Object.keys(req.data).forEach((key) => {
                if(key.toLowerCase().includes("email") || key.toLowerCase().includes("mail")){

                    // email should allow characters, numbers, dots, @ and underscores and it should end with henkel.com
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@henkel\.com$/;
                    if (!emailRegex.test(req.data[key])) 
                        req.reject(406, "Not accepted - Invalid email format");
                }
            });
        }
    });

    this.on('READ', 'SupplyPlanFormItems', async (req, next) => {

        try {
            const SupplyPlanItemsData = await next();
            if (req.req.url.includes("/$count")) {
                return SupplyPlanItemsData;
            }
            const materials = [...new Set(SupplyPlanItemsData.map(item => item.material))];
            const plants = SupplyPlanItemsData
                .filter(item => item.hierarchyLevel === 1 && item.sourceSystem === '92')
                .map(item => item.regionOrPlant);
            const plantsAPAC = SupplyPlanItemsData
                .filter(item => item.hierarchyLevel === 1 && item.sourceSystem === '93')
                .map(item => item.regionOrPlant);

            const combinedPlants = [...new Set([...plants, ...plantsAPAC])];

            let promises = [];
            promises.push(triggerApoFetch(materials, combinedPlants));
            if (plants && plants.length > 0) {
                promises.push(triggerMatStocksFetch(materials, plants));
            }

            if (plantsAPAC && plantsAPAC.length > 0) {
                promises.push(triggerAPACMatStocksFetch(materials, plantsAPAC));
            }

            await Promise.all(promises)
                .then((data) => {
                    let apoSnpSet = data[0];
                    let stockSet = [];
                    let stockSetAPAC = [];

                    if (plants.length > 0 && plantsAPAC.length > 0) {
                        stockSet = data[1];
                        stockSetAPAC = data[2];
                    } else if (plants.length > 0) {
                        stockSet = data[1];
                    } else {
                        stockSetAPAC = data[1];
                    }

                    const aggrSnpSet = aggrApoSnp(apoSnpSet);

                    res = SupplyPlanItemsData.map(spsRow => {
                        let material = spsRow.material.replace(/^0+/, '');
                        let stockAPAC = null;
                        let stock = null;
                        let apoSNP = null;


                        if (stockSet && stockSet.length > 0) {
                            stock = stockSet.find(stockItem =>
                                stockItem.Material === material && stockItem.Plant === spsRow.regionOrPlant
                            );
                            if (stock) {
                                spsRow.totalStockBUOM = parseFloat(stock.TsQuant).toFixed(3);
                                spsRow.totalStockValue = parseFloat(stock.TsValueLoc).toFixed(3);
                                spsRow.totalStockValueEur = parseFloat(stock.TsValueEur).toFixed(3);
                                spsRow.dysfuncStockBUOM = parseFloat((stock.DfsQuant)).toFixed(3);
                                spsRow.dysfuncStockValue = parseFloat(stock.DfsValueLoc).toFixed(3);
                                spsRow.dysfuncStockValueEur = parseFloat(stock.DfsValueEur).toFixed(3);
                                spsRow.totalSaleableInvBUOM = parseFloat(stock.TsiQuant).toFixed(3);
                                spsRow.totalSaleableInvVal = parseFloat(stock.TsiValueLoc).toFixed(3);
                                spsRow.totalSaleableInvValEur = parseFloat(stock.TsiValueEur).toFixed(3);
                                spsRow.fixedReceiptsBUOM = parseFloat((stock.FixedReceipts)).toFixed(3);
                                spsRow.fixedIssuesBUOM = parseFloat((stock.FixedIssues)).toFixed(3);
                                spsRow.buom = stock.BaseUom;
                                spsRow.localCurr = stock.CurrLocal;
                            }
                        }

                        if (stockSetAPAC && stockSetAPAC.length > 0) {
                            stockAPAC = stockSetAPAC.find(stockItem =>
                                stockItem.Material === material && stockItem.Plant === spsRow.regionOrPlant
                            );
                            if (stockAPAC) {
                                spsRow.totalStockBUOM = parseFloat(stockAPAC.TsQuant).toFixed(3);
                                spsRow.totalStockValue = parseFloat(stockAPAC.TsValueLoc).toFixed(3);
                                spsRow.totalStockValueEur = parseFloat(stockAPAC.TsValueEur).toFixed(3);
                                spsRow.dysfuncStockBUOM = parseFloat(stockAPAC.DfsQuant).toFixed(3);
                                spsRow.dysfuncStockValue = parseFloat(stockAPAC.DfsValueLoc).toFixed(3);
                                spsRow.dysfuncStockValueEur = parseFloat(stockAPAC.DfsValueEur).toFixed(3);
                                spsRow.totalSaleableInvBUOM = parseFloat(stockAPAC.TsiQuant).toFixed(3);
                                spsRow.totalSaleableInvVal = parseFloat(stockAPAC.TsiValueLoc).toFixed(3);
                                spsRow.totalSaleableInvValEur = parseFloat(stockAPAC.TsiValueEur).toFixed(3);
                                spsRow.fixedReceiptsBUOM = parseFloat(stockAPAC.FixedReceipts).toFixed(3);
                                spsRow.fixedIssuesBUOM = parseFloat(stockAPAC.FixedIssues).toFixed(3);
                                spsRow.buom = stockAPAC.BaseUom;
                                spsRow.localCurr = stockAPAC.CurrLocal;
                            }
                        }
                        if (aggrSnpSet && aggrSnpSet.length > 0) {
                            apoSNP = aggrSnpSet.find(snpItem =>
                                snpItem.material === material && snpItem.plant === spsRow.regionOrPlant
                            );
                            if (apoSNP && !isNaN(apoSNP.value)) {
                                spsRow.forecastSNP = parseFloat((apoSNP.value)).toFixed(3);
                            } else {
                                spsRow.forecastSNP = parseFloat(0).toFixed(3);
                            }
                        }

                        const totalSaleableInvBUOM = parseFloat(spsRow.totalSaleableInvBUOM) || 0;
                        const fixedReceiptsBUOM = parseFloat(spsRow.fixedReceiptsBUOM) || 0;
                        const additionalProd = parseInt(spsRow.additionalProd) || 0;
                        const fixedIssuesBUOM = parseFloat(spsRow.fixedIssuesBUOM) || 0;
                        const forecastSNP = parseFloat(spsRow.forecastSNP) || 0;

                        const denominator = (fixedIssuesBUOM + forecastSNP) / 365;

                        // Avoid division by zero
                        if (denominator > 0) {
                            if (spsRow.makeToStrategy === 'MTS') {
                                spsRow.invCoverageDays = Math.round((totalSaleableInvBUOM + fixedReceiptsBUOM + additionalProd) / denominator);
                            } else {
                                // spsRow.invCoverageDays = Math.round((totalSaleableInvBUOM + fixedReceiptsBUOM ) / denominator);                            
                                spsRow.invCoverageDays = 0; // Default or fallback value
                            }
                        } else {
                            spsRow.invCoverageDays = 0; // Default or fallback value
                        }


                        if (parseFloat(spsRow.lbeL16FG).toFixed(3) === '0.000') {
                            spsRow.lbeL16FG = spsRow.dysfuncStockValue
                        }
                        return spsRow;
                    });

                });

            let aUniqueParents = [...new Set(res.map(item => item.parentId))];

            const { SupplyPlanFormItems } = cds.entities("SupplyPlannerSummaryService");
            let aRegionInfo = await SELECT.from(SupplyPlanFormItems).where({
                nodeId: {
                    in: aUniqueParents
                }
            });

            let aFinalResponse = [];

            for await (let parent of aUniqueParents) {
                let aPlantInfo = res.filter(item => item.parentId === parent);
                let oParent = aRegionInfo.filter(item => item.nodeId === parent)[0];

                for await (let child of aPlantInfo) {
                    oParent.fixedIssuesBUOM = (parseFloat(oParent.fixedIssuesBUOM) + parseFloat(child.fixedIssuesBUOM)).toFixed(3);
                    oParent.fixedReceiptsBUOM = (parseFloat(oParent.fixedReceiptsBUOM) + parseFloat(child.fixedReceiptsBUOM)).toFixed(3);
                    oParent.dysfuncStockBUOM = (parseFloat(oParent.dysfuncStockBUOM) + parseFloat(child.dysfuncStockBUOM)).toFixed(3);
                    oParent.dysfuncStockValue = (parseFloat(oParent.dysfuncStockValue) + parseFloat(child.dysfuncStockValue)).toFixed(3);
                    oParent.dysfuncStockValueEur = (parseFloat(oParent.dysfuncStockValueEur) + parseFloat(child.dysfuncStockValueEur)).toFixed(3);
                    oParent.totalSaleableInvBUOM = (parseFloat(oParent.totalSaleableInvBUOM) + parseFloat(child.totalSaleableInvBUOM)).toFixed(3);
                    oParent.totalSaleableInvVal = (parseFloat(oParent.totalSaleableInvVal) + parseFloat(child.totalSaleableInvVal)).toFixed(3);
                    oParent.totalSaleableInvValEur = (parseFloat(oParent.totalSaleableInvValEur) + parseFloat(child.totalSaleableInvValEur)).toFixed(3);
                    oParent.totalStockBUOM = (parseFloat(oParent.totalStockBUOM) + parseFloat(child.totalStockBUOM)).toFixed(3);
                    oParent.totalStockValue = (parseFloat(oParent.totalStockValue) + parseFloat(child.totalStockValue)).toFixed(3);
                    oParent.totalStockValueEur = (parseFloat(oParent.totalStockValueEur) + parseFloat(child.totalStockValueEur)).toFixed(3);
                    oParent.forecastSNP = (parseFloat(oParent.forecastSNP) + parseFloat(child.forecastSNP)).toFixed(3);
                    oParent.lbeL16FG = (parseFloat(oParent.lbeL16FG) + parseFloat(child.lbeL16FG)).toFixed(3);
                    oParent.lbeL16SFG = (parseFloat(oParent.lbeL16SFG) + parseFloat(child.lbeL16SFG)).toFixed(3);
                    oParent.lbeL16RNP = (parseFloat(oParent.lbeL16RNP) + parseFloat(child.lbeL16RNP)).toFixed(3);
                }

                aFinalResponse.push(oParent);
                aFinalResponse = aFinalResponse.concat(aPlantInfo);
            }

            return aFinalResponse;
        } catch (error) {
            cds.log("spLog").error(error);
            return;
        }
    });

    this.on('READ', 'SupplyPlanItems', async (req, next) => {
        const filters = req.query.SELECT.where || []; // Access the filters array
        if (hasHierarchyLevelZero(filters)) {
            if (containsChildFilterFields(filters, childFilterFields)) {
                // Process filters and get the results
                const { cleanedFilters, childFilters } = processFilters(filters, childFilterFields);

                // Add childFilters to the context for later usage
                req.context.childFilters = formatChildFilters(childFilters);

                // Perform a final pass to remove orphan logical operators
                req.query.SELECT.where = removeOrphanLogicalOperators(cleanedFilters);
            }
        } else {
            if (hasHierarchyLevelOne(filters)) {
                if (containsParentFilterFields(filters, parentFilterFields)) {
                    // Remove parent filters and orphan logical operators
                    req.query.SELECT.where = removeParentFilterFields(filters, parentFilterFields);
                }
            }
        }
        // Proceed with the modified request
        return next();
    });

    this.after('READ', 'SupplyPlanItems', async (res, req) => {

        let childFilters = req.context.childFilters;

        try {
            if (res.every(item => item.hierarchyLevel === 0)) {
                if (res.length > 0 && res[0]?.hierarchyLevel === 0) {
                    afterHandlerCallCount = res.length;
                    const projectIDs = [...new Set(res.map(item => item.projectID))];
                    if (projectIDs.length > 0) {
                        const spHelperData = await fetchAndFilterData(projectIDs);
                        if (spHelperData && spHelperData.length > 0) {
                            let { updAggrData, parentIds } = await updAggrStockSnp(spHelperData, childFilters);
                            // if (parentIds && parentIds.size > 0) {
                            //     res = res.filter(row => row.hierarchyLevel === 0 && parentIds.has(row.nodeId));                                    
                            // }
                            if (updAggrData && updAggrData.length > 0) {
                                updChildItems = updAggrData.filter(row => row.hierarchyLevel === 1);
                                const aggrParents = updAggrData.filter(row => row.hierarchyLevel === 0);
                                if (aggrParents && aggrParents.length > 0) {
                                    res.splice(0, res.length, ...await updResData(res, aggrParents, []));
                                }
                            }
                        }
                    }
                }
            } else if (res.every(item => item.hierarchyLevel === 1)) {
                afterHandlerCallCount -= 1;
                if (updChildItems && updChildItems.length > 0) {
                    res.splice(0, res.length, ...await updResData(res, [], updChildItems));
                } else {
                    res.splice(0, res.length, ...await updateStockSnpData(res));
                }
            } else {
                if (res.some(item => item.hierarchyLevel === 0) && res.some(item => item.hierarchyLevel === 1)) {
                    res.splice(0, res.length, ...await updAggrStockSnp(res));
                }
            }
            if (afterHandlerCallCount === 0) {
                updChildItems = [];
            }
            return res;
        } catch (error) {
            updChildItems = [];
            cds.log("spLog").error(error);
        }
    });

    async function fetchAndFilterData(projectIDs) {
        try {
            const spiData = await SELECT.from(SupplyPlanItems).where({ projectID: { in: projectIDs } });

            return spiData;

        } catch (error) {
            cds.log("FetchspHelperLog").error(error);
        }
    }

    this.on("READ", "BomTree", async (req) => {
        const { MatPlants } = cds.entities("ComplexityManagement");
        const { CompUsage } = cds.entities("MasterDataService");

        // const material = extractFilters(req, 'Material').replace(/^0+/, '');
        const material = extractFilters(req, 'Material');
        const plant = extractFilters(req, 'Plant');
        const projectID = req.headers['projectid'];
        let matTypeDescriptionMap = {};
        let plants = [];
        let stockSet = [];
        let matTypes = [];
        let materialIds = [];
        let exclusiveMats = [];
        let fgMat = [];
        let promises = [];
        plants.push(plant);

        let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
            matnr: material,
            werks: plant
        });

        let compUsage = await SELECT.from(CompUsage).where({
            projectID: projectID,
            fg_idh: material,
            plant: plant
        });

        let matBomItemsTreeApi = null;
        if (aSourceSystem[0].source_system === '92')
            matBomItemsTreeApi = await cds.connect.to("MatBoms");
        else
            matBomItemsTreeApi = await cds.connect.to("APAC_MatBoms");

        const bomTreeItems = await matBomItemsTreeApi.run(req.query);

        if (bomTreeItems && bomTreeItems.length > 0) {

            bomTreeItems.forEach(item => {
                // Get all unique material IDs from BOM tree items
                materialIds.push(item.Component);
                const usage = compUsage.find((comp) => comp.component_id === item.Component);
                if (usage) {
                    item.Exclusive = usage.unique
                };
                if (item.Exclusive === true) {
                    exclusiveMats.push(usage.component_id);
                }
            });

            const uniqueMaterialIds = [...new Set(materialIds)];
            const uniqueExMats = [...new Set(exclusiveMats)];

            promises.push(triggerMatTypesFetch(uniqueMaterialIds));
            if (uniqueExMats && uniqueExMats.length > 0) {
                if (aSourceSystem[0].source_system === '92')
                    promises.push(triggerMatStocksFetch(uniqueExMats, plants));
                else
                    promises.push(triggerAPACMatStocksFetch(uniqueExMats, plants));
                promises.push(triggerMatTypesFetch(uniqueExMats));
            }
            

            // if (uniqueMaterialIds && uniqueMaterialIds.length > 0) {
            //     // Fetch material type descriptions directly from the local entity
            //     const materialTypes = await cds.run(
            //         SELECT.from(AllMatTypes).where({ matnr: { in: uniqueMaterialIds } })
            //     );
            //     if (materialTypes && materialTypes.length > 0) {
            //         // Create a lookup map for material descriptions
            //         materialTypes.forEach(matType => {
            //             matTypeDescriptionMap[matType.matnr] = matType.mtart_descr;
            //         });
            //     }
            //     const fgMaterials = await cds.run(
            //         SELECT.from('PPE_CM_MD_FGMATCLS').where({ matnr: { in: uniqueMaterialIds } })
            //     );
            //     if (fgMaterials && fgMaterials.length > 0) {
            //         fgMat = fgMaterials.map(item => item.matnr);
            //     }
            // }

            await Promise.all(promises).then((data) => {

                matTypes = data[0];
                stockSet = data[1];

                // Update BOM tree items with material type descriptions
                bomTreeItems.forEach(item => {

                    if (matTypes && matTypes.length > 0) {
                        const matType = matTypes.find(matTypeItem =>
                            matTypeItem.Material === item.Component
                        );

                        if (matType) {
                            item.MaterialType = matType.MatTyp;
                        }
                    }

                    // item.MaterialType = matTypeDescriptionMap[item.Component] || "Unknown";
                    // if (item.MaterialType === "UnKnown" && fgMat.length > 0) {
                    //     item.MaterialType = fgMat.has(item.ParentMaterial) ? 'FG' : 'Unknown';
                    // }
                    if (compUsage && compUsage.length > 0) {
                        const usage = compUsage.find((comp) => comp.component_id === item.Component);
                        if (usage) {
                            item.Exclusive = usage.unique
                        };
                    }

                    if (stockSet && stockSet.length > 0) {
                        const stock = stockSet.find(stockItem =>
                            stockItem.Material === item.Component && stockItem.Plant === item.Plant
                        );
                        if (stock) {
                            item.TotalStockAmount = parseFloat(stock.TsValueLoc).toFixed(3);
                            item.TotalStock = parseFloat(stock.TsQuant).toFixed(3);
                        }
                    }
                });
            });
        }

        return bomTreeItems;
    });
    this.on("READ", "BomCompParents", async (req) => {
        const { AllMatTypePlants } = cds.entities("MasterDataService");

        const material = extractFilters(req, 'Material');
        const plant = extractFilters(req, 'Plant');
        let materialIds = [];
        let matTypeDescriptionMap = {};
        let bomCompParents = [];
        let matTypes = [];
        let promises = [];

        let aSourceSystem = await SELECT.from(AllMatTypePlants).columns(`source_system`).where({
            matnr: material,
            werks: plant
        });
        if (aSourceSystem && aSourceSystem.length > 0) {
            let bomCompParentsApi = null;
            if (aSourceSystem[0].source_system === '92')
                bomCompParentsApi = await cds.connect.to("MatBoms");
            else
                bomCompParentsApi = await cds.connect.to("APAC_MatBoms");

            bomCompParents = await bomCompParentsApi.run(req.query);

            if (bomCompParents && bomCompParents.length > 0) {
                bomCompParents = bomCompParents.filter(entry => entry.SUMFG !== '*');
                bomCompParents.forEach(item => {
                    // Get all unique material IDs from BOM tree items
                    materialIds.push(item.ParentMaterial);
                })

                const uniqueMaterialIds = [...new Set(materialIds)];

                if (uniqueMaterialIds && uniqueMaterialIds.length > 0) {

                    promises.push(triggerMatTypesFetch(uniqueMaterialIds));

                    // // Fetch material type descriptions directly from the local entity
                    // const materialTypes = await cds.run(
                    //     SELECT.from(AllMatTypes).where({ matnr: { in: uniqueMaterialIds } })
                    // );
                    // if (materialTypes && materialTypes.length > 0) {
                    //     // Create a lookup map for material descriptions
                    //     materialTypes.forEach(matType => {
                    //         matTypeDescriptionMap[matType.matnr] = matType.mtart_descr;
                    //     });
                    // }
                }

                // Update BOM tree items with material type descriptions
                await Promise.all(promises).then((data) => {
                    matTypes = data[0];
                });  
                bomCompParents.forEach(item => {
                    // item.MaterialType = matTypeDescriptionMap[item.ParentMaterial] || "Unknown";
                    
                    if (item.BillOfMaterial) {
                        item.BillOfMaterial = item.BillOfMaterial.replace(/^0+/, "");
                    }                    

                    if (matTypes && matTypes.length > 0) {
                        const matType = matTypes.find(matTypeItem =>
                            matTypeItem.Material === item.ParentMaterial
                        );

                        if (matType) {
                            item.MaterialType = matType.MatTyp;
                        }
                    }


                });                               

            }
        }
        return bomCompParents;
    });

    this.on("updateMaterialPlantDateStatus", async (req) => {

        let dDate = new Date(req.data.date);
        let formattedDate = dDate.getFullYear().toString() + (dDate.getMonth() + 1).toString().padStart(2, '0') + dDate.getDate().toString().padStart(2, '0');
        const MaterialService = await cds.connect.to('MaterialService');
        const resultDateChange = await MaterialService.tx(req).send('updateMaterialPlantDateStatus', {
            material: req.data.material,
            plant: req.data.plant,
            date: formattedDate,
            field: req.data.field
        });

        if (resultDateChange === "Success")
            return "Success";
        else
            return "Failed to update status";
    });

    this.on("getSubstMat", async(req) => {
        const substMatArray = await SELECT.one.from(IdhProjectPlantSalesInfo).columns('material', 'projectID', 'subsMaterial').where({'material' : req.data.material, 'projectID' : req.data.projectID});
        console.log(substMatArray);
        if(substMatArray){
            return substMatArray.subsMaterial;
        }else{
            return "";
        }
    });

});



