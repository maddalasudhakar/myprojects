namespace ppe.cm.pd;

using {managed} from '@sap/cds/common';
using { v_idhProjectPlantSales } from './views';

type User : String(255);

entity ProjectHeaders : managed {
    key uuid                 : UUID;
        projectID            : Integer @odata.Type   : 'Edm.String';
        projectDescription   : String(100);
        phaseOutManager      : String(100);
        phaseOutManagerEmail : String(100);
        phaseOutDate         : Date;
        projectStatus        : Association to one ProjectStatuses;
        createdFrom          : String(10);
        phaseOutScenario     : Association to one PhaseOutScenario default 'Scenario01';
        projectIDHs          : Composition of many ProjectIDHs
                                   on projectIDHs.l_ev = $self;
        projectIDHPlants     : Composition of many ProjectIDHPlants
                                   on projectIDHPlants.l_ev = $self;

        @UI.HiddenFilter: false
        createdBy            : User    @cds.on.insert: $user;
        Deletion             : Boolean default false;
        salesArea             : Association[1.. * ] to v_idhProjectPlantSales
                                          on salesArea.projectUUID = uuid;
}
entity PhaseOutScenario {
    key id : String(35);
    description : String(100);
}
entity ProjectIDHs : managed {
    key uuid             : UUID;
        l_ev             : Association to one ProjectHeaders;
        material         : String(18);
        regionScope      : String(6);
        materialText     : String(40);
        subsMaterial     : String(18);
        subsMaterialText : String(40);
        phaseOutNEEDED   : Boolean default false;
        phaseOutDate     : Date;
        phaseOutStatus   : Association to one ProjectStatuses;
        workflowFlag     : String(10) default 'No';
        phaseOutScenario : String(15);
        spConfirmedDate  : Date;
        accountingSBU    : String(4);
}

entity ProjectIDHPlants : managed {
    key uuid                 : UUID;
        l_ev                 : Association to one ProjectHeaders;
        material             : String(18);
        materialText         : String(40);
        regionScope          : String(6);
        plant                : String(10);
        plantYSTATUS         : String(10);
        pValidFrom           : Date;
        phaseOutNEEDED       : String(10) default 'No';
        phaseOutDate         : Date;
        phaseOutStatus       : Association to one ProjectStatuses;
        workflowFlag         : String(10) default 'No';
        openTransaction      : String(10);
        sourceSystem         : String(3);
        mrpController        : String(3);
        mrpControllerEmail   : String(254);
        ctPlanner            : String(3);
        ctPlannerEmail       : String(254);
        confDatePerRegion    : Date;
        futureY4Date         : Date;
        lbeL16FG             : Decimal(16, 3);
        lbeL16SFG            : Decimal(16, 3);
        lbeL16RNP            : Decimal(16, 3);
        additionalProd       : Integer;
        projectIDHSalesAreas : Composition of many ProjectIDHSalesArea
                                   on projectIDHSalesAreas.l_ev = $self;
}

entity ProjectStatuses : managed {
    key uuid          : UUID;
        code          : String(10);
        usedIn        : String(50);
        projectStatus : String(20);
        statusText    : String(100);

}

entity ProjectIDHSalesArea : managed {
    key uuid                 : UUID;
        l_ev                 : Association to one ProjectIDHPlants;
        salesOrg             : String(10);
        distChanel           : String(10);
        sourceSystem         : String(10);
        salesCountry         : String(10);
        salesCountryName     : String(50);
        salesOrgDescr        : String(40);
        salesyStatus         : String(10);
        yStatusValidfrom     : Date;
        demandPlanner        : String(20);
        demandPlannerEmail   : String(100);
        phaseOutStatus       : Association to one ProjectStatuses;
        phaseOutNEEDED       : String(10) default 'No';
        openTransactionSales : String(10);
}

entity phaseOutManager : managed {
    uuid      : UUID;
    firstname : String(30);
    lastname  : String(30);
    email     : String(100);
}

@cds.persistence.skip
entity DepObjRsns {
    key projectUuid   : UUID;
    key rsn           : String(18);
    key material      : String(18);
        rsnStatus     : String(10);
        otherMaterial : String(18);
        materialType  : String(10);
        isComponent   : String(1);
        isUnique      : String(1);
};

@cds.persistence.skip
entity DepObjMasterRecipePrdVersion {
    key projectUuid  : UUID;
        sourceSystem : String(10);
        material     : String(18);
        plant        : String(4);
        recipeGroup  : String(8);
        groupCounter : String(2);
        description  : String(40);
        recipeStatus : String(40);
        prodVersion  : String(4);
        usage        : String(40);
};

@cds.persistence.skip
entity DepObjBom {
    key projectUuid  : UUID;
        sourceSystem : String(10);
        material     : String(18);
        plant        : String(4);
        stlnr        : String(8);
        stlal        : String(2);
        stlan        : String(1);
        bom_stat     : String(40);
};

@cds.persistence.skip
entity DepObjIbProduct {
    key projectUuid         : UUID;
        projectId           : Integer @odata.Type   : 'Edm.String';
        material            : String(18);
        ibProduct           : String(10);
        materialDescription : String(40);
        ibName              : String(60);
        ibStatus            : String(3);
};

@cds.persistence.skip
entity DepObjPirSourceList {
    key projectUuid        : UUID;
        sourceSystem       : String(10);
        material           : String(18);
        plant              : String(4);
        vendor             : String(10);
        groupCounter       : String(4);
        infoRecordCategory : String(1);
        sourceList         : String(5);
        validFrom          : Date;
        validTo            : Date;
        fixedVendor        : String(1);
        eineLoekz          : String(1);
        einaLoekz          : String(1);
};

entity FailedUpdateLogs {
    key ID                  : UUID;
        Material            : String(18);
        Plant               : String(4);
        SalesOrg            : String(4);
        DistributionChannel : String(2);
        MessageType         : String(1);
        Message             : String;
        Timestamp           : Timestamp;
}

entity ReplaceEmailWorkflow {
    key uuid        : UUID;
        regionScope : String(6);
        mrp_email   : String(100);
        dp_email    : String(100);
}

entity WorkFlowLogs {
    key uuid           : UUID;
        createdAt      : Timestamp  @cds.on.insert: $now;
        modifiedAt     : Timestamp  @cds.on.insert: $now  @cds.on.update: $now;
        processStep    : String(50) @Common.FieldControl : #Inapplicable; // Businees Planner,Supply Planner etc
        status         : String(20) @Common.FieldControl : #Inapplicable; // Open and completed
        taskUniqueId   : String(10) @Common.FieldControl : #Inapplicable; // dp planner id,mrp ctr id,definition id	
        taskUserEmaiId : String(100) @Common.FieldControl : #Inapplicable; // dp planner. Email id,mrp ctr mail id,
        projectID      : Integer    @odata.Type   : 'Edm.String' @Common.FieldControl : #Inapplicable; // Header project id
        material       : String(18) @Common.FieldControl : #Inapplicable; 
        taskModifiedEmail : String(100);
        taskModificationFlag : Boolean default false not null;
        linkToProject : Association to one ProjectHeaders on linkToProject.projectID = projectID;
        plant : String(500);
        accountingSBU : String(150);
        regionScope : String(150);
        deletionFlag : String(10) default '';
}
entity Statuses {
   key text : String(20);
}

entity ProcessSteps {
    key text : String(50);
}

