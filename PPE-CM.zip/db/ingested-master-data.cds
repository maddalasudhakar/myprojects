namespace ppe.cm.md;
/* Legend
    -> ppe - Product Portfolio Excellence
    -> cm - Complexity Management
    -> md - Master Data
    -> ingested - Refers to Data being ingested from Azure HDP via Datasphere */

/* All Material Types */
entity AllMatTypes {
    key matnr       : String(18); // Material Number
        matkl       : String(9); // Material Group
        matkl_descr : String(20); // Material Group Description
        ersda       : Date; // Created Date
        mtart       : String(4); // Material Type
        mtart_descr : String(30); // Material Type Description
        meins       : String(3); // Base Unit Of Measure
        vpsta       : String(15); // Maintenance Status of Complete Material
        bstme       : String(3); // Purchase Order Unit of Measure
        ekwsl       : String(4); // Purchasing Value Key
        brgew       : Decimal(13, 3); // Gross Weight
        ntgew       : Decimal(13, 3); // Net Weight
        gewei       : String(3); // Unit of Weight
        spart       : String(2); // Division
        prdha       : String(18); // Product Hierarchy
        prdha_descr : String(40); // Product Hierarchy Description
        qmpur       : String(1); // QM in Procurement is Active
        mhdrz       : Decimal(4, 0); // Minimum Remaining Shelf Life
        mhdhb       : Decimal(4, 0); // Total Shelf Life
        mstae       : String(2);
        spras       : String(1); // Language
        maktx       : String(40); //Material Description
}

/* Finished Goods(FG) Material Portfolio Classification Header Data */
entity FGPfCls {
    key matnr            : type of AllMatTypes : matnr; // Material Number
        sample_for       : String(3); // AIP: Sample allowed for
        region_regpc     : String(5); // IDH Region
        maktx            : String(40); // Material Text
        cre_dat          : Date; // Created On
        cre_tim          : Time; // Created At
        cre_nam          : String(12); // Name of the person responsible for creation of the object
        upd_dat          : Date; // Updated On
        upd_tim          : Time; // Update At
        upd_nam          : String(12); // Updated By
        prd_clas_1       : String(1); // AIP: Product Class level 1 for material
        prd_clas_1_txt   : String(60); // AIP: Product Class level 1 Description
        prd_clas_2       : String(3); // AIP: Product Class level 2 for material
        prd_clas_2_txt   : String(60); // AIP: Product Class level 2 Description
        excl_clas_1      : String(3); // AIP: Exclusivity Class level 1 for material
        excl_clas_1_txt  : String(60); // AIP: Exclusivity Class level 1 Description
        excl_clas_2      : String(3); // AIP: Exclusivity Class level 2 for material
        excl_clas_2_txt  : String(60); // AIP: Exclusivity Class level 2 Description
        prd_func_1       : String(3); // AIP: Product Function level 1 for material
        prd_func_1_txt   : String(60); // AIP: Product Function level 1 Description
        prd_func_2       : String(3); // AIP: Product Function level 2 for material
        prd_func_2_txt   : String(60); // AIP: Product Function level 2 Description
        steer_deci_1     : String(3); // AIP: Steering Decision level 1 for material
        steer_deci_1_txt : String(60); // AIP: Steering Decision level 1 Description
        steer_deci_2     : String(3); // AIP: Steering Decision level 2 for material
        steer_deci_2_txt : String(60); // AIP: Steering Decision level 2 Description
        xwpdp            : String(1); // AIP: Marketplace
        xetds            : String(1); // AIP: eCatalog Public Channels
        xecomm           : String(1); // AIP: Public TDS web search
        xgat_tds_ws      : String(1); // AIP: Gated TDS web search
        xreg_split       : String(1); // Manual Region Split
        lead_sbu         : String(3); // T2M Leading SBU
        lead_reg         : String(5); // IDH Region
        fg_owner         : String(241); // FG Owner Email Address
        /* SAMPLE - Customizing */
        sample_text      : String(30); // Sample Text
        sample_region    : String(4); // Sample Region
        /* PRDMS - Product Master Sample Data Fields*/
        xfull_shu        : String(1); // AIP: Full Shipping Unit
        xbox_break       : String(1); // AIP: Box Break
        xrefill          : String(1); // AIP: Refill
        xcustomize       : String(1); // AIP: Customize
        upd_dat_prdms    : Date; // Date of Last Change
        upd_tim_prdms    : Time; // Time of Last Change
        upd_nam_prdms    : String(12); // Name of Person Who Changed Object
        upd_from_pf      : String(1); // Update from Portfolio
        /* region Spcific Product Classification */
        pcl_1_regpc      : String(1); // Region Specific Product Class 1 for Material
        pcl_2_regpc      : String(3); // Region Specific Product Class 2 for Material
        pcl_1_txt_regpc  : String(60); // Region Specific Product Class 1 Description
        pcl_2_txt_regpc  : String(60); // Region Specific Product Class 2 Description
        del_ind_regpc    : String(1); // Region Specific PC Deletion Indicator
        upd_dat_regpc    : Date; // Updated Date - Reg PC
        upd_tim_regpc    : Time; // Updated Time - Reg PC
        upd_nam_regpc    : String(12); // Updated By - Reg PC
}

/* All Material Classification Single value Characteristics
    All the fields that starts with "yidh" are single value classification characteristics*/
entity FGMatCls {
    @sql.append : 'FUZZY SEARCH INDEX ON'
    @Search.ranking : HIGH
    @Search.fuzzinessThreshold: 0.8
    key matnr                        : type of AllMatTypes : matnr; // Material Number
        matkl                        : String(9); // Material Group
        matkl_descr                  : String(20);
        mtart                        : String(4);
        ersda                        : Date;
        meins                        : String(3);
        vpsta                        : String(15);
        bstme                        : String(3);
        ekwsl                        : String(4);
        brgew                        : Decimal(13, 3);
        ntgew                        : Decimal(13, 3);
        gewei                        : String(3);
        spart                        : String(2);
        prdha                        : String(18);
        prdha_descr                  : String(40);
        qmpur                        : String(1);
        mhdrz                        : Decimal(4, 0);
        mhdhb                        : Decimal(4, 0);
        mstae                        : String(2);
        spras                        : String(1);
        @sql.append : 'FUZZY SEARCH INDEX ON'
        @Search.ranking : HIGH
        maktx                        : String(40);
        pack_mat                     : String(30);
        Pack_mat_txt                 : String(30);
        yidh_3p_management           : String(30);
        yidh_3p_management_desc      : String(30);
        yidh_3pm_identifier          : String(30);
        yidh_3pm_identifier_desc     : String(30);
        yidh_aip_prim_contr          : String(30);
        yidh_aip_prim_contr_desc     : String(30);
        yidh_aip_prim_proof          : String(30);
        yidh_aip_prim_proof_desc     : String(50);
        yidh_aip_prim_sust_cat       : String(30);
        yidh_aip_prim_sust_cat_desc  : String(50);
        yidh_aip_sec_cont_a          : String(30);
        yidh_aip_sec_cont_a_desc     : String(50);
        yidh_aip_sec_cont_b          : String(30);
        yidh_aip_sec_cont_b_desc     : String(50);
        yidh_aip_sec_proof_a         : String(30);
        yidh_aip_sec_proof_a_desc    : String(50);
        yidh_aip_sec_proof_b         : String(30);
        yidh_aip_sec_proof_b_desc    : String(50);
        yidh_aip_sec_sust_cata       : String(30);
        yidh_aip_sec_sust_cata_desc  : String(50);
        yidh_aip_sec_sust_catb       : String(30);
        yidh_aip_sec_sust_catb_desc  : String(50);
        yidh_aip_sust_maint_manual   : String(30);
        yidh_aip_sustain_class       : String(30);
        yidh_aip_sustain_class_desc  : String(50);
        yidh_aip_technology1         : String(30);
        yidh_aip_technology1_desc    : String(60);
        yidh_aip_technology2         : String(30);
        yidh_aip_technology2_desc    : String(60);
        yidh_aip_technology3         : String(30);
        yidh_aip_technology3_desc    : String(60);
        yidh_al_primary_brand        : String(30);
        yidh_al_primary_brand_desc   : String(40);
        yidh_al_private_label        : String(30);
        yidh_al_secondary_brand      : String(30);
        yidh_al_secondary_brand_desc : String(40);
        yidh_alpha_code              : String(30);
        yidh_basket                  : String(30);
        yidh_fg_manager              : String(30);
        yidh_fg_reg                  : String(30);
        yidh_fg_sbu                  : String(30);
        yidh_innovative_product      : String(30);
        yidh_iris_mother_real_sub_id : String(30);
        yidh_iris_real_sub_id        : String(30);
        yidh_launch_or_relaunch      : String(30);
        yidh_leading_plant           : String(30);
        yidh_leading_sales_area      : String(30);
        yidh_leading_sbu             : String(30);
        yidh_mat_basket              : String(30);
        yidh_max_pal_store           : String(30);
        yidh_max_pal_trans           : String(30);
        yidh_multiple_formulas       : String(30);
        yidh_navigator_1             : String(30);
        yidh_navigator_1_desc        : String(30);
        yidh_navigator_2             : String(30);
        yidh_navigator_2_desc        : String(30);
        yidh_npi_date                : String(30);
        yidh_packaging_status        : String(30);
        yidh_prem_brand              : String(30);
        yidh_prem_brand_desc         : String(30);
        yidh_puris_basket            : String(30);
        yidh_region                  : String(30);
        yidh_replaced_by             : String(30);
        yidh_replaces_material       : String(30);
        yidh_request_manager         : String(30);
        yidh_rsn_owner               : String(30);
        yidh_rsn_reg                 : String(30);
        yidh_rsn_sbu                 : String(30);
        yidh_rsn_sbu_description     : String(30);
        yidh_single_or_mixed         : String(30);
        yidh_single_or_mixed_desc    : String(30);
        yidh_standard_or_promotion   : String(30);
        yidh_steering_unit           : String(30);
        yidh_steering_unit_desc      : String(30);
        yidh_stor_limit_lower        : String(30);
        yidh_stor_limit_upper        : String(30);
        yidh_storage_conditions      : String(30);
        yidh_storage_conditions_desc : String(30);
        yidh_sub_descriptor          : String(30);
        prod_nbr                     : String(10);
        prod_txt                     : String(60);
        leading_sbu_sbi              : String(30);
        leading_region_SBI           : String(30);
}

/* Material Sales Org */

entity MatSorgs {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key vkorg         : String(4);
    key vtweg         : String(2);
        name          : String(40);
        country       : String(3);
        country_name  : String(50);
        aumng         : Decimal(13, 3);
        bonus         : String(2);
        bonus_text    : String(20); /* Volume Rebate Group Description */
        dwerk         : String(4);
        name_werk     : String(40);
        efmng         : Decimal(13, 3);
        kondm         : String(2);
        kondm_text    : String(40);
        ktgrm         : String(2);
        ktgrm_text    : String(40);
        mtpos         : String(4);
        mtpos_text    : String(25);
        mvgr1         : String(3);
        mvgr2         : String(3);
        mvgr3         : String(3);
        mvgr4         : String(3);
        mvgr5         : String(3);
        pbind         : String(1);
        prodh         : String(18);
        prodh_text    : String(40);
        sktof         : String(1);
        versg         : String(1);
        versg_text    : String(20);
        vmstb         : String(20);
        vmsta         : String(2);
        vmstd         : Date;
        vrkme         : String(3);
        zzcven        : String(4);
        zzgr1         : String(10);
        zzgr2         : String(10);
        zzgr3         : String(20);
        zzgr3_text    : String(40);
        zzgr5         : String(10);
        zzgr6         : String(10);
        zzgr7         : String(10);
        altds         : String(40);
        altid         : String(10);
        reade         : String(1);
        rmatn         : String(18);
        zreasonstat   : String(100);
        zvprdpot      : String(1);
}

/* All Material Type Plant */

entity AllMatTypePlants {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key werks         : String(4);
        maktx         : String(40);
        matkl         : String(9);
        matkl_desc    : String(20);
        mtart         : String(4);
        mtart_desc    : String(20);
        name1         : String(30);
        regio         : String(6);
        mmsta         : String(2);
        mmstd         : Date;
        stprs         : Decimal(15, 2);
        verpr         : Decimal(15, 2);
        vprsv         : String(1);
        lbkum         : Decimal(13, 3);
        dispo         : String(3);
        dsnam         : String(18);
}

/* Material Plants*/

entity MatPlants {
    key source_system         : String(3);
    key matnr                 : type of AllMatTypes : matnr;
    key werks                 : String(4);
        maktx                 : String(40);
        name1                 : String(30);
        regio                 : String(6);
        abcin                 : String(1);
        ausme                 : String(3);
        ausss                 : Decimal(5, 2);
        beskz                 : String(1);
        bstfe                 : Decimal(13, 3);
        bstma                 : Decimal(13, 3);
        bstmi                 : Decimal(13, 3);
        bstrf                 : Decimal(13, 3);
        bwesb                 : Decimal(13, 3);
        bwscl                 : String(1);
        disgr                 : String(4);
        disls                 : Decimal(13, 3);
        loslt                 : String(40);
        dismm                 : String(2);
        dibez                 : String(30);
        dispo                 : String(3);
        dsnam                 : String(18);
        dispr                 : String(4);
        dzeit                 : Decimal(3, 0);
        eisbe                 : Decimal(13, 3);
        eislo                 : Decimal(13, 3);
        ekgrp                 : String(3);
        eknam                 : String(18);
        eprio                 : String(4);
        expme                 : String(3);
        fevor                 : String(3);
        ffrei                 : String(1);
        fhori                 : String(3);
        fixls                 : Decimal(13, 3);
        fprfm                 : String(3);
        frtme                 : String(3);
        fvidk                 : String(4);
        fxhor                 : String(3);
        gi_pr_time            : Decimal(3, 0);
        herkl                 : String(3);
        landx                 : String(15);
        herkr                 : String(3);
        insmk                 : String(1);
        kautb                 : String(1);
        kordb                 : String(1);
        kzbed                 : String(1);
        kzdkz                 : String(1);
        ladgr                 : String(4);
        lgpro                 : String(4);
        losgr                 : Decimal(13, 3);
        lvorm                 : String(1);
        maabc                 : String(1);
        mabst                 : Decimal(13, 3);
        maxls                 : Decimal(13, 3);
        maxlz                 : Integer;
        mfrgr                 : String(8);
        minbe                 : Decimal(13, 3);
        minls                 : Decimal(13, 3);
        miskz                 : String(1);
        mmsta                 : String(2);
        mmstd                 : Date;
        mtver                 : String(4);
        mtvfp                 : String(2);
        nfmat                 : String(18);
        nf_flag               : String(1);
        plifz                 : Decimal(3, 0);
        plnty                 : String(1);
        prctr                 : String(10);
        pstat                 : String(15);
        qmata                 : String(6);
        qmatv                 : String(1);
        qssys                 : String(4);
        qzgtp                 : String(4);
        rdprf                 : String(4);
        rgekz                 : String(1);
        sernp                 : String(4);
        sfcpf                 : String(6);
        shflg                 : String(1);
        shzet                 : String(2);
        sobsk                 : String(2);
        sobsl                 : String(2);
        stawn                 : String(17);
        stdpd                 : String(18);
        steuc                 : String(16);
        stlal                 : String(2);
        stlan                 : String(1);
        strgr                 : String(2);
        ueetk                 : String(1);
        ueeto                 : Decimal(3, 1);
        umlmc                 : Decimal(13, 3);
        uneto                 : Decimal(3, 1);
        vint1                 : String(3);
        vint2                 : String(3);
        vrmod                 : String(1);
        vrvez                 : Timestamp;
        webaz                 : Integer;
        wzeit                 : Decimal(3, 0);
        xchpf                 : String(1);
        bklas                 : String(4);
        bwtar                 : String(10);
        bwtty                 : String(1);
        lbkum                 : Decimal(13, 3);
        peinh                 : Decimal(18, 2);
        stprs                 : Double;
        verpr                 : Double;
        vprsv                 : String(1);
        ya_abc_business       : String(1);
        ya_clre               : String(1);
        ya_cov                : Decimal(7, 4);
        yya_ct_d              : String(40);
        ya_default_wh         : String(4);
        yya_dprel             : String(1);
        ya_fc_split           : String(1);
        yya_flex              : Decimal(3, 0);
        yya_for_ac            : Decimal(5, 2);
        ya_g1g5               : String(2);
        yya_lc_y1             : Timestamp;
        yya_lc_y2             : Timestamp;
        yya_lc_y3             : Date;
        yya_lc_y4             : Date;
        yya_lc_y5             : Date;
        yya_lc_y6             : Timestamp;
        yya_lc_yk             : Timestamp;
        yya_lc_yo             : Timestamp;
        yya_lc_yq             : Timestamp;
        ya_maabc              : String(1);
        ya_mono_country       : String(1);
        ya_mono_region        : String(1);
        ya_mo_art             : String(1);
        yya_mto_sto           : String(1);
        yya_mt_str            : String(3);
        ya_nocosting          : String(1);
        ya_nsp                : String(3);
        ya_nsp_d              : String(40);
        yya_period            : Decimal(3, 0);
        yya_per_ind           : String(3);
        yya_plansys           : String(3);
        yya_plan_ct           : String(3);
        yya_prodh             : Decimal(3, 0);
        ya_prod_add_days      : Decimal(3, 0);
        yya_reason            : String(40);
        yya_sc_tag            : String(40);
        yya_source_loc        : String(40);
        yya_snp_rel_ind       : String(1);
        yya_ssimp             : String(1);
        yya_stop              : String(1);
        yya_stopro            : String(1);
        ya_stop_comment       : String(40);
        ya_stop_end           : Date;
        ya_stop_start         : Date;
        ya_strat_def_by_sales : String(3);
        yya_st_kp             : String(20);
        yya_st_kp_d           : String(40);
        yya_st_nt             : String(1);
        yya_trnsf_date        : Date;
        yya_trnsf_ldate       : Date;
}

/* Customer Master */

entity Customers {
    key source_system : String(3);
    key kunnr         : String(10);
        name1         : String(35);
        name2         : String(35);
        ort01         : String(35);
        pstlz         : String(10);
        regio         : String(3);
        adrnr         : String(10);
        ktokd         : String(4);
        ktokd_name    : String(30);
        land1         : String(3);
        land1_name    : String(15);
        cust_seg      : String(30);
        cust_seg_desc : String(50);
}

/* One BOM Header FG */

entity FG1Boms {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key werks         : String(4);
    key stlan         : String(1);
    key stlal         : String(2);
        maktx         : String(40);
        name1         : String(30);
        mmsta         : String(2);
        stlty         : String(1);
        stlnr         : String(8);
        stkoz         : String(8);
        bmein         : String(3);
        bmeng         : Decimal(13, 3);
        stlst         : String(2);
        bom_stat_desc : String(40);
}

/* One BOM Item FG */

entity FG1BomItems {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key werks         : String(4);
    key stlan         : String(1);
    key stlal         : String(2);
    key posnr         : String(4);
        stlty         : String(1);
        stlnr         : String(8);
        stlkn         : String(8);
        stpoz         : String(8);
        idnrk         : String(18);
        maktx         : String(40);
        postp         : String(1);
        sortf         : String(10);
        meins         : String(3);
        menge         : Decimal(13, 3);
        fmeng         : String(1);
        ausch         : Decimal(5, 2);
        avoau         : Decimal(5, 2);
        rekri         : String(1);
        rekrs         : String(1);
        lifzt         : Decimal(3, 0);
        preis         : Decimal(11, 2);
        peinh         : Decimal(5, 0);
        waers         : String(5);
        sakto         : String(10);
        matkl         : String(9);
        lgort         : String(4);
        stvkn         : String(8);
}


/* One BOM Header All Material Types*/

entity OneBoms {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key werks         : String(4);
    key stlan         : String(1);
    key stlal         : String(2);
        maktx         : String(40);
        name1         : String(30);
        mmsta         : String(2);
        stlty         : String(1);
        stlnr         : String(8);
        bmein         : String(3);
        bmeng         : Decimal(13, 3);
        stlst         : String(2);
        bom_stat_desc : String(40);
}

/* One BOM Items All Material Types*/

entity OneBomItems {
    key source_system : String(3);
    key matnr         : type of AllMatTypes : matnr;
    key werks         : String(4);
    key stlan         : String(1);
    key stlal         : String(2);
    key posnr         : String(4);
        maktx         : String(40);
        stlty         : String(1);
        stlnr         : String(8);
        stlkn         : String(8);
        stpoz         : String(8);
        idnrk         : String(18);
        idnrk_desc    : String(40);
        name1         : String(30);
        mmsta         : String(2);
        postp         : String(1);
        sortf         : String(10);
        meins         : String(3);
        menge         : Decimal(13, 3);
        fmeng         : String(1);
        ausch         : Decimal(5, 2);
        avoau         : Decimal(5, 2);
        rekri         : String(1);
        rekrs         : String(1);
        lifzt         : Decimal(3, 0);
        preis         : Decimal(11, 2);
        peinh         : Decimal(5, 0);
        waers         : String(5);
        sakto         : String(10);
        matkl         : String(9);
        stvkn         : String(8);
}

/* BOM Component Usage */

entity BomUsages {
    key source_system : String(3);
    key stlnr         : String(8);
        matnr         : type of AllMatTypes : matnr;
        maktx         : String(40);
        menge         : Decimal(13, 3);
        meins         : String(3);
        ausch         : Decimal(5, 2);
        datuv         : Date;
        stlst         : String(2);
}

/* IB Product */
entity IBProducts {
    key prod_nbr            : String(10);
        prod_sta            : String(3);
        @sql.append: 'FUZZY SEARCH INDEX ON'
        @Search.ranking:HIGH
        @Search.fuzzinessThreshold: 0.8
        prod_txt            : String(60);
        cre_dat             : Date;
        cre_tim             : Time;
        cre_nam             : String(12);
        upd_nam             : String(12);
        sbu                 : String(4);
        region              : String(3);
        pman                : String(4);
        pman_txt            : String(10);
        pman_txt_ln         : String(60);
        ib_pm               : String(50);
        ib_cm               : String(50);
        cntry               : String(3);
        landx               : String(15);
        prod_base_nbr       : String(10);
        innovation_yn       : String(1);
        innovation_date     : Date;
        sg_nbr              : String(13);
        ab_nbr              : String(13);
        mcat_l1             : String(3);
        mcat_l1_txt         : String(60);
        mcat_l2             : String(3);
        mcat_l2_txt         : String(60);
        mchem_l1            : String(3);
        mchem_l1_txt        : String(60);
        mchem_l2            : String(3);
        mchem_l2_txt        : String(60);
        media_car           : String(3);
        media_car_txt       : String(60);
        nbr_comp            : String(3);
        cure_mec            : String(3);
        cure_mec_txt        : String(60);
        tech_l1             : String(3);
        tech_l2             : String(3);
        sustain_class       : String(30);
        sustain_class_desc  : String(50);
        prim_contr          : String(30);
        prim_contr_desc     : String(30);
        prim_proof          : String(30);
        prim_proof_desc     : String(50);
        prim_sust_cat       : String(30);
        prim_sust_cat_desc  : String(50);
        sec_cont_a          : String(30);
        sec_cont_a_desc     : String(50);
        sec_cont_b          : String(30);
        sec_cont_b_desc     : String(50);
        sec_proof_a         : String(30);
        sec_proof_a_desc    : String(50);
        sec_proof_b         : String(30);
        sec_proof_b_desc    : String(50);
        sec_sust_cata       : String(30);
        sec_sust_cata_desc  : String(50);
        sec_sust_catb       : String(30);
        sec_sust_catb_desc  : String(50);
        upd_dat_pcl         : Date;
        upd_tim_pcl         : Time;
        upd_nam_pcl         : String(12);
        crs_sell_status     : String(3);
        crs_sell_status_txt : String(60);
        geo_level           : String(3);
        geo_level_txt       : String(60);
        excl_clas_1         : String(3);
        excl_clas_1_txt     : String(60);
        excl_clas_2         : String(3);
        excl_clas_2_txt     : String(60);
        life_cycle          : String(3);
        life_cycle_txt      : String(60);
        prd_clas_1          : String(1);
        prd_clas_1_txt      : String(60);
        prd_clas_2          : String(3);
        prd_clas_2_txt      : String(60);
        pre_level_2         : String(3);
        prd_clas_txt        : String(60);
        prd_func_1          : String(3);
        prd_func_1_txt      : String(60);
        prd_func_2          : String(3);
        prd_func_2_txt      : String(60);
        steer_deci_1        : String(3);
        steer_deci_1_txt    : String(60);
        steer_deci_2        : String(3);
        steer_deci_2_txt    : String(60);
        val_strat           : String(3);
        val_strat_txt       : String(60);
        xwpdp               : String(1);
        xetds               : String(1);
        xecomm              : String(1);
        xgat_tds_ws         : String(1);
        xsplit_by_sbu       : String(1);
        comments            : String(40);
        desc_of_benefit     : String(250);
        comm_on_prof_doc    : String(250);
        mod_usr             : String(12);
        mod_dat             : Date;
        appr_by             : String(12);
        init_upload_ind     : Boolean;
        scl_neg_case_com    : String(250);
        reason_for_scl_chg  : String(250);
        is_risks_in_vc      : String(3);
        risks_in_vc         : String(3);
        na_risk_case_comm   : String(250);
        prod_base_ty        : String(3);
        grade               : String(6);
        subid               : String(12);
        text                : String(60);
        BU_DESCRIPTION      : String(100);
        STAGE_GATE_DSC      : String(100);
        TECH_L1_DSC         : String(50);
        EXT1                : String(50);
        EXT2                : String(50);
        SBU_DESCRIPTION     : String(100);
        region_text         : String(10);
        APP_LEVEL_1         : String(3);
        @sql.append: 'FUZZY SEARCH INDEX ON'
        @Search.ranking:HIGH
        @Search.fuzzinessThreshold: 0.8
        APP_LEVEL_1_TEXT    : String(60);
        APP_LEVEL_2         : String(3);
        @sql.append: 'FUZZY SEARCH INDEX ON'
        @Search.ranking:HIGH
        @Search.fuzzinessThreshold: 0.8
        APP_LEVEL_2_TEXT    : String(60);
        APP_LEVEL_3         : String(3);
        @sql.append: 'FUZZY SEARCH INDEX ON'
        @Search.ranking:HIGH
        @Search.fuzzinessThreshold: 0.8
        APP_LEVEL_3_TEXT    : String(60);
}

/* Chemicals Under Discussion */

entity ChemUnderDis {
    key recn       : String(20);
    key actn       : String(20);
        valfr      : Date;
        valto      : Date;
        aennr      : String(12);
        delflg     : String(1);
        parkflg    : String(1);
        crdat      : Date;
        crnam      : String(12);
        upddat     : Date;
        updnam     : String(12);
        srsid      : String(10);
        ownid      : String(10);
        recnroot   : String(20);
        upddats    : Date;
        updnams    : String(12);
        subid      : String(12);
        subcat     : String(10);
        authgrp    : String(10);
        rem        : String(60);
        subchar    : String(10);
        estcat     : String(30);
        recntva    : String(20);
        compcat    : String(10);
        recncmp    : String(20);
        precl      : String(5);
        complow    : Decimal(10, 4);
        precu      : String(5);
        compupp    : Decimal(10, 4);
        compavg    : Decimal(10, 4);
        compexp    : String(3);
        complowdec : Integer;
        compuppdec : Integer;
        compavgdec : Integer;
        compexcval : String(2);
        upd_cmp    : Date;
        grpid      : String(15);
        ord        : String(4);
        limit      : Decimal(13, 9);
        uom_rds    : String(3);
        relevant   : String(1);
        name       : String(50);
        grptext    : String(50);
}

/* Material RSN Link */

entity MatRsnLinks {
    key subid     : String(12);
    key matnr     : type of AllMatTypes : matnr;
        subsName  : String(60);
        maktx     : String(40);
        rsnStatus : String(60);
}

/* RSN Relation */

entity Relations {
    key recn            : String(20);
    key actn            : String(20);
        valfr           : Date;
        valto           : Date;
        aennr           : String(12);
        delflg          : String(1);
        parkflg         : String(1);
        crdat           : Date;
        crnam           : String(12);
        upddat          : Date;
        updnam          : String(12);
        srsid           : String(10);
        ownid           : String(10);
        recnroot        : String(20);
        upddats         : Date;
        updnams         : String(12);
        subid           : String(12);
        subcat          : String(10);
        authgrp         : String(10);
        rem             : String(60);
        subchar         : String(10);
        flg_srcdest_req : String(1);
        apprv_stat      : String(1);
        cons_stat       : String(1);
        flg_inh         : String(1);
        job_req_tim     : Time;
        job_req_dat     : Date;
        flg_subcpy      : String(1);
        recnroot_src    : String(20);
        recnroot_dst    : String(20);
        recn_tplh       : String(20);
        esntflg         : String(1);
}

entity ActivePlants {
    key werks              : String(4);
        xsystem            : String(3);
        regio              : String(6);
        plant_type         : String(2);
        active             : String(1);
        busi_unit          : String(1);
        project            : String(20);
        madame_dv_01       : String(2);
        madame_dv_06       : String(2);
        madame_dv_uk       : String(2);
        madame_dv_uw       : String(2);
        xraw               : String(1);
        sfg                : String(1);
        fg_asp             : String(1);
        sfg_pac            : String(1);
        vkorg              : String(4);
        vu_code            : String(30);
        sbu_ai             : String(1);
        sbu_ag             : String(1);
        sbu_ac             : String(1);
        sbu_at             : String(1);
        sbu_ae             : String(1);
        m_active           : String(1);
        sbu_retail         : String(1);
        sbu_prof           : String(1);
        prodecesor_pl_code : String(30);
        activation_date    : Date;
        deactivation_date  : Date;
        validation         : Date;
        remarks            : String(100);
}

entity PEWorkflowHeaders {
    key sysid_orig          : String(8);
    key appl_id             : String(3);
    key req_id              : String(9);
    key proc_id             : String(10);
    key proc_instance       : String(2);
    key sysid_exec          : String(8);
        req_ty_orig         : String(3);
        req_id_orig         : String(32);
        wf_status           : String(4);
        wf_start_usr        : String(12);
        wf_start_dat        : Date;
        wf_start_tim        : Time;
        wf_fin_usr          : String(12);
        wf_fin_dat          : Date;
        wf_fin_tim          : Time;
        wf_can_usr          : String(12);
        wf_can_dat          : Date;
        wf_can_tim          : Time;
        duration_gross      : String(8);
        versi_cust          : String(4);
        clas_nam_wpe        : String(30);
        fnam_wi_fin         : String(30);
        fnam_apl            : String(30);
        fnam_bpl            : String(30);
        xpre_prop           : String(1);
        appl_clogs          : String(6);
        proc_id_orig        : String(10);
        obj_ty              : String(1);
        obj_id              : String(20);
        sbu                 : String(3);
        spart               : String(2);
        send_dat_sta        : Date;
        send_tim_sta        : Time;
        send_dat_fin        : Date;
        send_tim_fin        : Time;
        reason_code         : String(8);
        reason_code_chg_dat : Date;
        reason_code_chg_tim : Time;
        relevant_systems    : String(3);
        proj_id             : String(20);
        xno_moni            : String(1);
        xbws                : String(1);
        xarq_11_cre         : String(1);
        xarq_22_cre         : String(1);
        xarq_33_cre         : String(1);
        versi_proc          : String(4);
        wf_park_usr         : String(12);
        wf_park_fr_dat      : Date;
        wf_park_fr_tim      : Time;
        wf_park_status_bef  : String(4);
        wf_park_clog_id     : String(18);
        wf_duration_net1    : String(8);
}

entity PlantRegions {
    key werks         : String(4);
    key subregion     : String(3);
    key region        : String(3);
        name1         : String(30);
        land1         : String(3);
        landx         : String(15);
        subregion_txt : String(20);
        region_txt    : String(20);
        plant_bu      : String(4);
        plant_bu_txt  : String(30);
        plant_sbu     : String(4);
        plant_sbu_txt : String(30);
        inactive      : String(1);
        plntstat_dat  : Date;
        remarks       : String(60);

}

entity RFHeaders {
    key appl_id            : String(3);
    key proc_id            : String(10);
    key req_id             : String(9);
    key proc_instance      : String(2);
        proc_case          : String(4);
        cre_dat            : Date;
        cre_tim            : Time;
        cre_usr            : String(12);
        chg_dat            : Date;
        chg_tim            : Time;
        chg_usr            : String(12);
        org_unit           : String(10);
        spart              : String(2);
        new_spart          : String(2);
        sbu                : String(3);
        new_sbu            : String(3);
        region_of_req      : String(4);
        country            : String(3);
        status             : String(4);
        req_title          : String(50);
        bu                 : String(1);
        product_brief_num  : String(20);
        region_sub         : String(4);
        pkg_init_typ       : String(2);
        idh_number         : String(18);
        pc_chg_type        : String(4);
        cpy_of_req_id      : String(9);
        chklist_ind        : String(1);
        pre_sys            : String(8);
        pre_sysid          : String(40);
        pre_stat           : String(2);
        resp_prod_manager  : String(80);
        pre_sys_proj_id    : String(20);
        pre_sys_var_numb   : String(5);
        pre_sys_proj_name  : String(100);
        ssc_local_mkt      : String(3);
        sfg_req_case       : String(2);
        distrib_stat       : String(1);
        distrib_dat        : Date;
        distrib_tim        : Time;
        trigger_from       : String(40);
        review_user_id     : String(12);
        pi_req_case        : String(3);
        pi_use_case        : String(3);
        pi_multi_case      : String(3);
        pi_run_proj        : String(1);
        pi_run_proj_reason : String(200);
        pi_fin_exp_date    : Date;
        mmd_req_case       : String(2);
        mmd_proc_case      : String(2);
        aip_prod_numb      : String(10);
        cre_for            : String(12);
}

entity RFBasRecords {
    key appl_id       : String(3);
    key proc_id       : String(10);
    key req_id        : String(9);
    key proc_instance : String(2);
    key fld_grp       : String(10);
    key fld_nam       : String(30);
    key seqno         : String(5);
        fld_val       : String(72);
}

entity TechNavBrandRelations {
    key bu         : String(1);
    key tech_cb    : String(12);
    key nav1       : String(28);
    key nav2       : String(12);
    key prem_brand : String(20);
        pri_brand  : String(60);
        sec_brand  : String(60);
}

entity RSNOwners {
    key tech_lev1  : String(3);
    key tech_lev2  : String(3);
    key tech_lev3  : String(3);
    key sbu        : String(3);
    key region     : String(5);
        subs_owner : String(21);
}

entity IBPManagers {
    key app_l1    : String(3);
    key app_l2    : String(3);
    key app_l3    : String(3);
    key sbu       : String(10);
    key region    : String(10);
        pm_email  : String(241);
        cm_email  : String(241);
        fgo_email : String(241);
}

entity SalesAreas {
    key vkorg   : String(4);
    key vtweg   : String(2);
    key spart   : String(2);
        sa_desc : String(40);
        sa_ctry : String(40);
}

entity EstDueDatePred {
    key sysid_orig          : String(8);
    key req_id              : String(9);
    key proc_id             : String(10);
    key proc_instance       : String(2);
    key sysid_exec          : String(8);
        wf_status           : String(4);
        wf_start_usr        : String(12);
        wf_start_dat        : Date;
        wf_start_tim        : Time;
        wf_fin_usr          : String(12);
        wf_fin_dat          : Date;
        wf_fin_tim          : Time;
        duration_gross      : String(8);
        obj_id              : String(20);
        sbu                 : String(3);
        spart               : String(2);
        reason_code         : String(8);
        relevant_systems    : String(3);
        wf_duration_net1    : String(8);
        bow_id              : String(12);
        kpi_date            : Date;
        kpi_time            : Time;
        root_id             : String(12);
        type                : String(8);
        region              : String(4);
        country             : String(200);
        plant               : String(4);
        division            : String(2);
        sales_org           : String(4);
        tech_lev1           : String(3);
        scenario            : String(2);
        tech_lev2           : String(3);
        seal_needed         : String(1);
        leading_procurement : String(6);
        adp_number          : String(30);
        req_case            : String(3);
        use_case            : String(3);
        long_run_proj       : String(1);
        real_subid          : String(12);
        prio_wf             : String(1);
}

entity AllowedValPred {
    key sysid_orig          : String(8);
    key req_id              : String(9);
    key proc_id             : String(10);
    key proc_instance       : String(2);
    key step_id             : String(10);
    key pre_prop            : String(1);
    key wi_instance         : String(3);
    key org_ele_ty          : String(3);
    key org_ele_id          : String(20);
    key sysid_exec          : String(8);
        obj_id              : String(20);
        event_val_usr       : String(10);
        event_val_fin       : String(10);
        wi_status           : String(4);
        trig_cnt_down       : String(5);
        var_nam_max_trig    : String(30);
        duration_gross      : String(8);
        duration_net1       : String(8);
        duration_net2       : String(8);
        reserve_usr         : String(12);
        reserve_fr_dat      : Date;
        reserve_fr_tim      : Time;
        reserve_to_dat      : Date;
        reserve_to_tim      : Time;
        wi_timestampl       : String(21);
        wi_cre_usr          : String(12);
        wi_cre_dat          : Date;
        wi_cre_tim          : Time;
        wi_start_usr        : String(12);
        wi_start_dat        : Date;
        wi_start_tim        : Time;
        wi_fin_usr          : String(12);
        wi_fin_dat          : Date;
        wi_fin_tim          : Time;
        dlist_id            : String(5);
        responsible_1       : String(12);
        responsible_2       : String(12);
        xusr_action         : String(1);
        reason_code         : String(8);
        xdqval_mandatory    : String(1);
        xdqval_ok           : String(1);
        xdqval_override     : String(1);
        xauto_fin           : String(1);
        xrejected           : String(1);
        skipped_by          : String(1);
        region              : String(4);
        country             : String(200);
        plant               : String(4);
        division            : String(2);
        sap_division        : String(2);
        sbu                 : String(3);
        sales_org           : String(4);
        tech_lev1           : String(3);
        scenario            : String(2);
        tech_lev2           : String(3);
        seal_needed         : String(1);
        leading_procurement : String(6);
        adp_number          : String(30);
        req_case            : String(3);
        use_case            : String(3);
        long_run_proj       : String(1);
        real_subid          : String(12);
        prio_wf             : String(1);
}

entity MatAipProd {
    key prod_nbr : String(10);
    key matnr    : String(18);
}

entity UsrHenkl {
    key uname         : String(12);
        name_last     : String(40);
        name_first    : String(40);
        bukrs         : String(4);
        area          : String(15);
        department    : String(30);
        building      : String(10);
        room          : String(10);
        corp_group    : String(4);
        company_name  : String(50);
        name_last_up  : String(40);
        name_first_up : String(40);
        email         : String(241);
        molga         : String(3);
}

entity CompUsage {
    key projectID      : Integer @odata.type: 'Edm.String';
    key fg_idh         : String(18);
    key plant          : String(4);
    key component_id   : String(18);
        unique         : Boolean default false;
        material_type  : String(4);
        component_buom : String(3);
}

entity CompUsageJobInfo {
    key projectID : Integer @odata.Type: 'Edm.String';
        jobStatus : String(30);
        error     : String(300);
}
// It is maintained in BTP Hana DB( It is not ingested from anywhere)

entity RpSupplyPlanner {
    key plant            : String(4);
    key mrpController        : String(3);
    region               : String(8);
    email                : String(254);
    mrpControllerText    : String(254);
    responsible          : String(100);
    remarks              : String(100);
    IsActiveEntity       : Boolean default true;
    HasActiveEntity      : Boolean default false;
    HasDraftEntity       : Boolean default false;
}

entity MD_CM_Dossier {
    key MaterialKey                      : String(255);
        MaterialKeyOffZeros              : String(255);
        MaterialDsc                      : String(255);
        SalesOrganizationCode            : String(255);
        DistributionChannelCode          : String(255);
        Sales_Country                    : String(255);
        Sales_Region                     : String(255);
        Sales_SBU                        : String(255);
        BusinessCode                     : String(255);
        PlantKey_Delivery                : String(255);
        PlantDsc_Delivery                : String(255);
        MaterialKey_BulkOffZeros         : Integer;
        bulkDescription                  : String(255);
        MaterialKey_ReplacedBy           : String(255);
        AIPTechnologyLevel1Dsc           : String(255);
        AIPTechnologyLevel2Dsc           : String(255);
        AIPTechnologyLevel3Dsc           : String(255);
        APrimaryBrandDsc                 : String(255);
        ASecondaryBrandDsc               : String(255);
        ATLPrivateLabelCFlag             : String(255);
        InnovativeProductCFlag           : String(255);
        InnovationDate                   : Date;
        CreatedDate                      : Date;
        PlantKey_MaterialLeading         : String(255);
        XPlantStatusCode                 : String(255);
        PackagingTypeDsc                 : String(255);
        MaterialOfPackagingDsc           : String(255);
        LeadingSBUSBI                    : String(255);
        LeadingRegionSBI                 : String(255);
        LeadingSBUCode                   : String(255);
        SampleFlag                       : String(255);
        AIProductKey                     : String(255);
        AIProductKeyOffZeros             : String(255);
        AIProductDsc                     : String(255);
        AIPSBUDsc                        : String(255);
        AIPRegionDsc                     : String(255);
        AIPStatusCode                    : String(255);
        StatusChangedDate                : Date;
        AIPIBProductManagerDsc           : String(255);
        AIPIBCommManagerDsc              : String(255);
        ib_ProductClassLevel1CFlag       : String(255);
        ib_ProductClassLevel1Dsc         : String(255);
        ib_ProductClassLevel2Code        : String(255);
        CrossSellingFlag                 : Integer;
        CrossSellingStatusDsc            : String(255);
        ib_InnovativeProductCFlag        : String(255);
        ib_InnovationDate                : Date;
        SteeringDecisionLevel1Dsc        : String(255);
        ib_ExclusivityClassLevel1Dsc     : String(255);
        AIPSustainabilityClassDsc        : String(255);
        A_AIPApplicationLevel1Dsc        : String(255);
        A_AIPApplicationLevel2Dsc        : String(255);
        A_AIPApplicationLevel3Dsc        : String(255);
        A_AIPApplicationLevel3RespSBUDsc : String(255);
        RSNKeyOffZeros                   : String(255);
        Identifier                       : String(255);
        SubstanceOwner                   : String(255);
        RSNStatus                        : String(255);
        ProductionPlants                 : String(255);
        BOM                              : String(255);
        CustomerSegmentCounts            : String(255);
        TotalShelfLifeCnt                : Decimal(5,0);
        PackagingSizeDsc                 : String(255);
        MaxAvgCovCountry                 : Decimal(19,6);
        MaxMedCovCountryDsc              : Decimal(15,2);
        MaxAvgCovMaterialKey             : Decimal(19,6);
        MaxAvgDevPctCountry              : Double;
        MaxSlowMovingCountry             : String(255);
        MaxSlowMovingMat                 : String(255);
        StockQtyBUoM_NotBlocked          : Decimal(23,3);
        StockQtyBUoM_Dysfunctional       : Decimal(23,3);
        BUoM                             : String(255);
        StockMatPriceEURX_NotBlocked     : Double;
        StockMatPriceEUX_Dysfunctional   : Double;
        LastGoodsIssueDate               : Date;
        DaysSinceLastGoodsIssue          : Integer;
        ScrapPrice_EURX_PPY              : Double;
        ScrapPrice_EURX_PY               : Double;
        ScrapPrice_EURX_CY               : Double;
        ScrapPrice_EURXTotal             : Double;
        NES_SD_YTD                       : Double;
        NES_SD_R24M                      : Double;
        NES_M_YTD                        : Double;
        NES_M_R24M                       : Double;
        MCA_M_YTD                        : Double;
        MCA_M_R24M                       : Double;
        PCperNES_M_YTD                   : Double;
        PCperNES_M_R24M                  : Double;
        NES_MC_YTD                       : Double;
        NES_MC_R24M                      : Double;
        NES_IB_YTD                       : Double;
        NES_IB_R24M                      : Double;
        MCA_IB_YTD                       : Double;
        MCA_IB_R24M                      : Double;
        PCperNES_IB_YTD                  : Double;
        PCperNES_IB_R24M                 : Double;
        FilterCriteria                   : Integer;
        ABCClass_NES                     : String(255);
        NoMovement_CY_2                  : String(255);
        NoMovement_CY                    : String(255);
        PC_Threshold                     : String(255);
        NegativePC_12M                   : String(255);
        NoStockNoMovement                : String(255);
}