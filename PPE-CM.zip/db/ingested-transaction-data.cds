namespace ppe.cm.td;
/* Legend
    -> ppe - Product Portfolio Excellence
    -> cm - Complexity Management
    -> td - Transactional Data Data
    -> ingested - Refers to Data being ingested from Azure HDP via Datasphere */

using {
    ppe.cm.md.AllMatTypes as AllMatTypes,
    ppe.cm.md.Customers as Customers
} from './ingested-master-data';

/* Purchasing Contracts */

entity PurContracts {
    key source_system : String(3);
    key ebeln         : String(10);
        bukrs         : String(4);
        bstyp         : String(1);
        bsart         : String(4);
        bsakz         : String(1);
        statu         : String(1);
        lifnr         : String(10);
        spras         : String(1);
        ekorg         : String(4);
        ekgrp         : String(3);
        waers         : String(5);
        wkurs         : String(9);
        bedat         : Date;
        kdatb         : Date;
        kdate         : Date;
        kunnr         : type of Customers : kunnr;
        zvsbed        : String(2);
        zvsart        : String(2);
        zzuser        : String(12);
        plc           : String(1);
        smb           : String(6);
        top           : String(2);
        sus           : String(5);
        pcy           : String(3);
}


/* Customer Contracts */

entity CustContracts {
    key source_system : String(3);
    key vbeln         : String(10);
        vbtyp         : String(1);
        auart         : String(4);
        lifsk         : String(2);
        faksk         : String(2);
        waerk         : String(5);
        vkorg         : String(4);
        vtweg         : String(2);
        spart         : String(2);
        vkgrp         : String(3);
        vkbur         : String(4);
        kunnr         : type of Customers : kunnr;
        kvgr5         : String(3);
}

/* Customer Material Info Record */

entity CustMatInfoRecords {
    key source_system : String(3);
    key kunnr         : type of Customers : kunnr;
    key vkorg         : String(4);
    key vtweg         : String(2);
    key matnr         : type of AllMatTypes : matnr;
        antlf         : Decimal(1, 0);
        chspl         : String(1);
        erdat         : Date;
        ernam         : String(12);
        guid          : UUID;
        j_1btxsdc     : String(2);
        kdmat         : String(35);
        kztlf         : String(1);
        lprio         : String(2);
        megru         : String(4);
        meins         : String(3);
        minlf         : Decimal(13, 3);
        postx         : String(40);
        rdprf         : String(4);
        sortl         : String(10);
        uebtk         : String(1);
        uebto         : Decimal(3, 1);
        umvkn_t       : Decimal(5, 0);
        umvkz_t       : Decimal(5, 0);
        untto         : Decimal(3, 1);
        vrkme_t       : String(3);
        vwpos         : String(4);
        werks         : String(4);
        addpostx      : String(40);
        guidKnmta     : UUID;
}

/* Claims Customer Complaints */

entity ClaimsCustComplaints {
    key source_system   : String(3);
    key qmnum           : String(12);
        qmart           : String(2);
        qmtxt           : String(40);
        artpr           : String(2);
        priok           : String(1);
        mzeit           : Time;
        qmdat           : Date;
        qmnam           : String(12);
        waers           : String(5);
        aufnr           : String(12);
        verid           : String(4);
        rm_matnr        : String(18);
        rm_werks        : String(4);
        matnr           : type of AllMatTypes : matnr;
        revlv           : String(2);
        matkl           : String(9);
        prdha           : String(18);
        kunum           : String(10);
        objnr           : String(22);
        lifnum          : String(10);
        vbeln           : String(10);
        bstnk           : String(35);
        bstdk           : Date;
        spart           : String(2);
        vkorg           : String(4);
        vtweg           : String(2);
        adrnr           : String(10);
        prueflos        : String(12);
        charg           : String(10);
        lgortcharg      : String(4);
        ekorg           : String(4);
        bkgrp           : String(3);
        ebeln           : String(10);
        ebelp           : String(5);
        ls_kdauf        : String(10);
        ls_kdpos        : String(6);
        arbpl           : String(8);
        arbplwerk       : String(4);
        rkmng           : Decimal(13, 3);
        rgmng           : Decimal(13, 3);
        rkdat           : Date;
        coaufnr         : String(12);
        vkbur           : String(4);
        vkgrp           : String(3);
        estimated_costs : Decimal(13, 2);
        claimed_costs   : Decimal(13, 2);
        result_costs    : Decimal(13, 2);
        chance          : String(2);
        opponent        : String(2);
}

entity SalesBoms {
    key source_system : String(3); // Source System
    key matnr         : type of AllMatTypes : matnr; // Material Number
    key werks         : String(4); // Plant
    key stlan         : String(1); // BOM Usage
    key stlal         : String(2); // Alternative BOM
        stlty         : String(1); // BOM Category
        maktx         : String(40); // Material Text
        name1         : String(30); // Plant Name
        stlnr         : String(8); // Bill Of Material - BOM
        mmsta         : String(2); // Plant Specific Material Status
        lkenz_stko    : String(1); // BOM Deletion Indicator
        idnrk         : String(18); // BOM Component Material - STPO
        idnrk_txt     : String(40); // BOM Component Material Description
        stlst         : String(2); // BOM Status
        lkenz_stpo    : String(1); // BOM Item or Component Deletion Indicator
}
