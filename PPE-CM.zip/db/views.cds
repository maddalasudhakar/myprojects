using {ppe.cm.md as md} from './ingested-master-data';
using {ppe.cm.pd as pd} from './project-dashboard';

view V_RegionValList as
    select distinct regionScope from pd.ProjectIDHs as pdm
    inner join pd.ProjectHeaders as ph
        on ph.uuid = pdm.l_ev.uuid
    where
        pdm.regionScope is not null;

view V_MRPEmailValList as
    select distinct mrpControllerEmail from pd.ProjectIDHPlants as pdmp
    inner join pd.ProjectHeaders as ph
        on ph.uuid = pdmp.l_ev.uuid
    where
        pdmp.mrpControllerEmail is not null;

view V_CTPlannerValList as
    select distinct ctPlannerEmail from pd.ProjectIDHPlants as pdmp
    inner join pd.ProjectHeaders as ph
        on ph.uuid = pdmp.l_ev.uuid
    where
        pdmp.ctPlannerEmail is not null;

// view V_ProjMatSummary as
//     select from pd.ProjectHeaders as pdh
//     inner join pd.ProjectIDHPlants as pdmp
//         on pdmp.l_ev.uuid = pdh.uuid
//     inner join pd.ProjectIDHs as pdm
//         on pdm.l_ev.uuid = pdh.uuid
//     inner join pd.ProjectIDHSalesArea as pdms
//         on pdms.l_ev.uuid = pdmp.uuid
//     left join md.AllMatTypes as mt
//         on mt.matnr = pdm.material
//     left join md.FGMatCls as fgcl
//         on fgcl.matnr = pdm.material
//     left join md.MatPlants as mp
//         on  mp.matnr = pdm.material
//         and mp.werks = pdmp.plant
//     left join md.MatSorgs as ms
//         on  ms.matnr = pdm.material
//         and ms.vkorg = pdms.salesOrg
//         and ms.vtweg = pdms.distChanel
//     {
//         key pdh.projectID,
//         key pdm.material,
//         key pdmp.plant,
//             pdh.projectDescription,
//             pdh.phaseOutDate,
//             pdmp.mrpController,
//             pdmp.mrpControllerEmail,
//             pdmp.ctPlanner,
//             pdmp.ctPlannerEmail,
//             pdmp.plantYSTATUS            as plantStatus,
//             pdmp.materialText            as materialText,
//             fgcl.yidh_steering_unit_desc as steeringUnitDesc,
//             //mp.mmsta                     as plantStatus,
//             mp.mmstd                     as pValidFrom,
//             mp.yya_mt_str                as makeToStrategy,
//             //ms.vmsta                     as salesOrgStatus,
//             ms.vmstd                     as sValidFrom,
//             pdmp.sourceSystem as sourceSystem,
//             pdms.salesOrg as salesOrg,
//             pdms.distChanel as distChannel,
//             pdms.salesyStatus as salesOrgStatus
//     };

view V_ProjMatSummary as
    select distinct  
        pdh.projectID,
        LTRIM(pdmp.material, '0')  as material : String(18),
        pdmp.plant,
        pdh.projectDescription,
        pdm.subsMaterial             as subsMaterial,
        pdm.subsMaterialText         as subsMaterialText,
        pdmp.sourceSystem            as sourceSystem,
        pdmp.mrpController,
        pdmp.mrpControllerEmail,
        pdmp.ctPlanner,
        pdmp.ctPlannerEmail,
        pdmp.materialText            as materialText,
        pdmp.plantYSTATUS            as plantStatus,
        fgcl.yidh_steering_unit_desc as steeringUnitDesc,
        fgcl.meins                   as buom,
        mp.name1                     as plantName,
        mp.mmstd                     as pValidFrom,
        //mp.name1                   as plantName,
        mp.yya_mt_str                as makeToStrategy,
        pdms.yStatusValidfrom        as sValidFrom,
        pdms.salesOrg                as salesOrg,
        pdms.distChanel              as distChannel,
        pdms.salesyStatus            as salesOrgStatus
    
    from pd.ProjectHeaders as pdh
    inner join pd.ProjectIDHPlants as pdmp
        on pdmp.l_ev.uuid = pdh.uuid
    inner join pd.ProjectIDHs as pdm
        on  pdm.l_ev.uuid    = pdh.uuid
        and pdmp.regionScope = pdm.regionScope
    inner join pd.ProjectIDHSalesArea as pdms
        on pdms.l_ev.uuid = pdmp.uuid
    left join md.AllMatTypes as mt
        on mt.matnr = pdmp.material
    left join md.FGMatCls as fgcl
        on fgcl.matnr = pdmp.material
    left join md.MatPlants as mp
        on  mp.matnr         = pdmp.material
        and mp.werks         = pdmp.plant
        and mp.source_system = pdmp.sourceSystem
    
    where
        pdmp.phaseOutNEEDED = 'Yes';

view V_MatValList as
    select distinct
        ph.projectID,
        pdm.material,
        pdm.materialText
    from pd.ProjectIDHs as pdm
    inner join pd.ProjectHeaders as ph
        on ph.uuid = pdm.l_ev.uuid;

define view v_supplyplanneritems as
        select
            *,
            0  as totalStockValue                                          : Decimal(13, 2),
            0  as totalStockBUOM                                           : Decimal(13, 3),
            0  as dysfuncStockBUOM                                         : Decimal(13, 3),
            0  as dysfuncStockValue                                        : Decimal(13, 2),
            0  as totalSaleableInvBUOM                                     : Decimal(13, 3),
            0  as totalSaleableInvVal                                      : Decimal(13, 2),
            0  as forecastSNP                                              : Decimal(13, 3),
            0  as fixedReceiptsBUOM                                        : Decimal(13, 3),
            0  as fixedIssuesBUOM                                          : Decimal(13, 3),
            0  as invCoverageDays                                          : Integer,
            0  as totalStockValueEur                                       : Decimal(13, 2),
            0  as dysfuncStockValueEur                                     : Decimal(13, 2),
            0  as totalSaleableInvValEur                                   : Decimal(13, 2),
            '' as localCurr                                                : String(5)
        from (
            select
                l_ev.uuid || material || regionScope as nodeId             : String(50),
                l_ev.projectID,
                l_ev.projectDescription,
                null                                 as parentId           : String(50),
                material,
                subsMaterial,
                // LTRIM(
                //     material, '0'
                // )                                    as convMaterial       : String(18),
                materialText,
                ''                                   as mrpController      : String(3),
                ''                                   as mrpControllerEmail : String(254),
                ''                                   as ctPlanner          : String(3),
                ''                                   as ctPlannerEmail     : String(254),
                null                                 as confDatePerRegion  : Date,
                null                                 as futureY4Date       : Date,
                0                                    as lbeL16FG           : Decimal(16, 3),
                0                                    as lbeL16SFG          : Decimal(16, 3),
                0                                    as lbeL16RNP          : Decimal(16, 3),
                0                                    as additionalProd     : Integer,
                ''                                   as scTag              : String(40),
                ''                                   as sourcePlant        : String(40),
                ''                                   as plantYStatus       : String(2),
                null                                 as pValidFrom         : Date,
                ''                                   as makeToStrategy     : String(3),
                regionScope                          as regionOrPlant,
                regionScope,
                ''                                   as sourceSystem       : String(3),
                0                                    as hierarchyLevel     : Integer,
                l_ev.uuid                            as projectUuid,
                l_ev.phaseOutDate,
                phaseOutNEEDED                                             : Boolean,
                'expanded'                           as drillState         : String(20),
                (
                    select case count( * )
                               when
                                   0
                               then
                                   ''
                               else
                                   'Active'
                           end as activeSalesOrg from pd.ProjectIDHSalesArea
                    where
                            l_ev.material =      idhRegion.material
                        and salesyStatus  not in (
                            'Y5', 'Y6'
                        )
                )                                    as activeSalesOrg     : String(6),
                false                                as bomExists          : Boolean,
                ''                                   as compDetails        : String(3),
                ''                                   as buom               : String(3),
                accountingSBU                        as accSBU             : String(4)
            from pd.ProjectIDHs as idhRegion union select
                uuid                                 as nodeId             : String(50),
                l_ev.projectID,
                l_ev.projectDescription,
                l_ev.uuid || material || regionScope as parentId           : String(50),
                material,
                '' as subsMaterial : String(18),
                // LTRIM(
                //     material, '0'
                // )                                    as convMaterial       : String(18),
                materialText,
                mrpController                                              : String(3),
                mrpControllerEmail                                         : String(254),
                ctPlanner                                                  : String(3),
                ctPlannerEmail                                             : String(254),
                confDatePerRegion,
                futureY4Date,
                IFNULL(
                    lbeL16FG, 0
                )                                    as lbeL16FG           : Decimal(16, 3),
                IFNULL(
                    lbeL16SFG, 0
                )                                    as lbeL16SFG          : Decimal(16, 3),
                IFNULL(
                    lbeL16RNP, 0
                )                                    as lbeL16RNP          : Decimal(16, 3),
                IFNULL(
                    additionalProd, 0
                )                                    as additionalProd     : Decimal(13, 3),
                (
                    select yya_sc_tag from md.MatPlants
                    where
                            matnr         = idhPlant.material
                        and werks         = idhPlant.plant
                        and source_system = idhPlant.sourceSystem
                )                                    as scTag              : String(40),
                (
                    select yya_source_loc from md.MatPlants
                    where
                            matnr         = idhPlant.material
                        and werks         = idhPlant.plant
                        and source_system = idhPlant.sourceSystem
                )                                    as sourcePlant        : String(40),
                plantYSTATUS,
                pValidFrom,
                (
                    select yya_mt_str from md.MatPlants
                    where
                            matnr         = idhPlant.material
                        and werks         = idhPlant.plant
                        and source_system = idhPlant.sourceSystem
                )                                    as makeToStrategy     : String(3),
                plant                                as regionOrPlant,
                regionScope,
                sourceSystem,
                1                                    as hierarchyLevel     : Integer,
                l_ev.uuid                            as projectUuid,
                l_ev.phaseOutDate,
                case
                    when
                        phaseOutNEEDED = 'Yes'
                    then
                        true
                    else
                        false
                end                                  as phaseOutNEEDED     : Boolean,
                'leaf'                               as drillState         : String(20),
                (
                    select case count( * )
                               when
                                   0
                               then
                                   ''
                               else
                                   'Yes'
                           end as activeSalesOrg from pd.ProjectIDHSalesArea
                    where
                            l_ev.material =      idhPlant.material
                        and l_ev.plant    =      idhPlant.plant
                        and salesyStatus  not in (
                            'Y5', 'Y6'
                        )

                )                                    as activeSalesOrg     : String(6),
                (
                    select case count( * )
                               when
                                   0
                               then
                                   false
                               else
                                   true
                           end as bomExists from md.FG1Boms
                    where
                            source_system = idhPlant.sourceSystem
                        and matnr         = idhPlant.material
                        and werks         = idhPlant.plant
                        and stlan         = '1'
                        and stlal         = '01'
                )                                    as bomExists          : Boolean,
                ''                                   as compDetails        : String(3),
                ''                                   as buom               : String(3),
                ''  as accSBU : String(4)
            from pd.ProjectIDHPlants as idhPlant
        ) as allitems
        where
            phaseOutNEEDED = true
        order by
            projectUuid,
            hierarchyLevel;

// used for project age filter KPI visualization
define view v_projectstatusbyagerange as
    select
        projectStatus                   : String(50),
        openDays                        : String(50),
        sum(statusCount) as statusCount : Integer
    from (
        select
            projectStatus.projectStatus as projectStatus,
            case
                when
                    DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) < 5
                then
                    '0 - 5 days'
                when
                    DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) > 5
                    and DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) < 10
                then
                    '6 - 10 days'
                when
                    DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) > 10
                    and DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) < 20
                then
                    '11 - 20 days'
                when
                    DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) > 20
                    and DAYS_BETWEEN(
                        createdAt, CURRENT_DATE
                    ) < 30
                then
                    '21 - 30 days'
                else
                    '> 30 days'
            end                         as openDays,
            1                           as statusCount
        from pd.ProjectHeaders
    )
    group by
        projectStatus,
        openDays;

// used for project material plant planned phase out KPI visualization
define view v_materialplantsplannedphasedout as
    select
        TO_VARCHAR(mpWeek) || '.' || TO_VARCHAR(mpYear) as mpWeek  : String(10),
        count(mpWeek)                                   as mpCount : Integer
    from (
        select
            WEEK(phaseOutDate) as mpWeek                           : Integer,
            YEAR(phaseOutDate) as mpYear                           : Integer
        from pd.ProjectIDHPlants
        where
                l_ev.projectStatus.projectStatus =      'Submitted'
            and phaseOutDate                     is not null
    ) as mpWeekYear
    group by
        mpWeekYear.mpWeek,
        mpWeekYear.mpYear
    order by
        mpWeekYear.mpYear,
        mpWeekYear.mpWeek;

define view v_idhDepObjLinkedRsn as
    select from pd.ProjectHeaders as header
    inner join pd.ProjectIDHs as idh
        on header.uuid = idh.l_ev.uuid
    inner join md.MatRsnLinks as rsn
        on idh.material = rsn.matnr
    {
        key header.uuid      as projectUuid,
        key header.projectID as projectId,
        key idh.material     as material,
        key rsn.subid        as rsn,
            rsn.rsnStatus    as rsnStatus
    };

// view which conatains the combition of 4 tables projectheaders/projectidhs/projectidhplants/projectidhsalesarea
   define view v_idhProjectPlantSalesInfo as
    select
        plants.material,
        plants.materialText,
        idh.subsMaterial,
        idh.l_ev.createdAt,
        idh.subsMaterialText,
        plants.phaseOutDate,
        plants.phaseOutNEEDED,
        idh.spConfirmedDate,
        idh.l_ev.uuid,
        idh.l_ev.projectID,
        idh.l_ev.projectDescription,
        idh.l_ev.phaseOutManager,
        idh.l_ev.phaseOutManagerEmail,
        idh.l_ev.projectStatus.statusText,
         idh.l_ev.phaseOutScenario.id  as ProjectPhaseOutScenario,
        idh.phaseOutScenario,
        idh.accountingSBU,
        plants.plant,
        plants.regionScope,
        plants.plantYSTATUS,
        plants.openTransaction,
        plants.mrpController,
        plants.mrpControllerEmail,
        plants.futureY4Date,
        plants.pValidFrom,
        salesarea.salesOrg,
        salesarea.salesCountryName,
        salesarea.distChanel,
        salesarea.sourceSystem,
        salesarea.salesCountry,
        salesarea.salesyStatus,
        salesarea.salesOrgDescr,
        salesarea.phaseOutNEEDED as salesPhaseOutneeded,
        salesarea.phaseOutStatus.uuid as salesPhaseOutUUID,
        salesarea.phaseOutStatus.statusText as salesPhaseOutText,
        plants.lbeL16FG,
        plants.lbeL16SFG,
        plants.lbeL16RNP,
        plants.phaseOutStatus.uuid as plant_status_uuid
        from pd.ProjectIDHs as idh
    join pd.ProjectIDHPlants as plants
    on idh.material = plants.material and idh.l_ev.uuid = plants.l_ev.uuid
    left join pd.ProjectIDHSalesArea as salesarea
    on salesarea.l_ev.uuid = plants.uuid
    where idh.regionScope = plants.regionScope;
    
// only one status  like Y5,Y6 or Cancel of plant
define view projectPlantStatusView(statusProject : UUID, statusPlant : UUID) as
    select A.uuid as PROJUUID from pd.ProjectHeaders as A
    left join pd.ProjectIDHPlants as B
        on A.uuid = B.l_ev.uuid
    where
        A.projectStatus.uuid != :statusProject and B.phaseOutNEEDED = 'Yes'
    group by
        A.uuid
    having
        COUNT(
            case
                when
                    B.phaseOutStatus.uuid = :statusPlant
                then
                    1
            end
        ) = COUNT( * );
// check if plant with status Y6 got crossed one year for project which is on phase out completed for header 
define view projectidhY5 as
    select
        uuid                as UUID,
        l_ev.uuid           as L_EV_UUID,
        phaseOutStatus.uuid as PHASEOUTSTATUS_UUID,
        phaseOutScenario    as PHASEOUTSCENARIO,
        material            as MATERIAL
    from pd.ProjectIDHs
    where
            DAYS_BETWEEN(
            modifiedAt, CURRENT_DATE
        )                       >= 365
        and phaseOutStatus.uuid =  '1c290c86-d4ee-44e0-98df-87de0a09c945'
        and l_ev.uuid           in (
            select uuid from pd.ProjectHeaders
            where
                projectStatus.uuid = 'd9c4e3c7-6a15-4a92-a50a-27473a4e99ae'
        );
// check if Idh region  with status Y6 got crossed one year for project which is on phase out completed for header 
define view projectPlantidhY5 as
    select
        uuid                as UUID,
        l_ev.uuid           as L_EV_UUID,
        phaseOutStatus.uuid as PHASEOUTSTATUS_UUID,
        plant               as PLANT,
        material            as MATERIAL
    from pd.ProjectIDHPlants
    where
            DAYS_BETWEEN(
            modifiedAt, CURRENT_DATE
        )                       >= 365
        and phaseOutStatus.uuid =  '1c290c86-d4ee-44e0-98df-87de0a09c945'
        and l_ev.uuid           in (
            select uuid from pd.ProjectHeaders
            where
                projectStatus.uuid = 'd9c4e3c7-6a15-4a92-a50a-27473a4e99ae'
        ) and phaseOutNEEDED = 'Yes';

define view v_FGMatClsStd as select from md.FGMatCls {
    *
} where mtart='STD';

// will accept two  status either of  Y5 and  Cancel  Or ,Y6 and Cancel
define view projectPlantStatusAllView(statusProject : UUID, statusPlantY : UUID, statusPlantCancel : UUID) as
    select A.uuid as PROJUUID from pd.ProjectHeaders as A
    left join pd.ProjectIDHPlants as B
        on A.uuid = B.l_ev.uuid
    where
        A.projectStatus.uuid != :statusProject
        and B.phaseOutNEEDED = 'Yes'
    group by
        A.uuid
    having
        COUNT(
            case
                when
                    B.phaseOutStatus.uuid = :statusPlantY or
                    B.phaseOutStatus.uuid = :statusPlantCancel

                then
                    1
            end
        ) = COUNT( * );

     // view which conatains the combition of 2 tables projectidhplants/projectidhsalesarea


     // will accept two  status either of  Y5 and   Or ,Y6 and 
define view projectIDHStatusAllView(statusProject : UUID, statusIDHY5 : UUID) as
    select A.uuid as PROJUUID from pd.ProjectHeaders as A
    left join pd.ProjectIDHs as B
        on A.uuid = B.l_ev.uuid
    where
        A.projectStatus.uuid != :statusProject
        and A.phaseOutScenario.id = 'Scenario03'
        and B.phaseOutNEEDED = true
    group by
        A.uuid
    having
        COUNT(
            case
                when
                    B.phaseOutStatus.uuid = :statusIDHY5

                then
                    1
            end
        ) = COUNT( * );

define view projectIDHStatusView(statusProject : UUID, statusIDHY5 : UUID, ststusIDHY6 : UUID) as
    select A.uuid as PROJUUID from pd.ProjectHeaders as A
    left join pd.ProjectIDHs as B
        on A.uuid = B.l_ev.uuid
    where
        A.projectStatus.uuid != :statusProject
        and A.phaseOutScenario.id = 'Scenario03'
        and B.phaseOutNEEDED = true
    group by
        A.uuid
    having
        COUNT(
            case
                when
                    B.phaseOutStatus.uuid = :statusIDHY5 or
                    B.phaseOutStatus.uuid = :ststusIDHY6

                then
                    1
            end
        ) = COUNT( * );

// calculating all sales area table which has status consumed and modified date greater or equal to 365
define view projectidhSalesY5 as
    select
        uuid                as UUID,
        phaseOutStatus.uuid as PHASEOUTSTATUS_UUID
    from pd.ProjectIDHSalesArea
    where
            DAYS_BETWEEN(
            modifiedAt, CURRENT_DATE
        )                       >= 365
        and phaseOutStatus.uuid =  '1c290c86-d4ee-44e0-98df-87de0a09c945'
        and phaseOutNEEDED      =  'Yes';

define view v_idhProjectPlantSales as
    select
        key plants.material                 as material,
            plants.plant                    as plant,
        key plants.l_ev.uuid                as projectUUID,
        key plants.uuid                     as plantUUID,
            plants.l_ev.phaseOutScenario.id as projectScenario,
            plants.l_ev.projectStatus.code  as projectStatusCode,
            plants.l_ev.projectID           as projectID,
            plants.regionScope              as regionScope,
        key salesarea.uuid                  as uuid,
            salesarea.salesOrg              as salesOrg,
            salesarea.salesCountryName      as salesCountryName,
            salesarea.distChanel            as distChanel,
            salesarea.sourceSystem          as sourceSystem,
            salesarea.salesCountry          as salesCountry,
            salesarea.salesyStatus          as salesyStatus,
            salesarea.salesOrgDescr         as salesOrgDescr,
            salesarea.phaseOutNEEDED        as phaseOutNEEDED,
            salesarea.phaseOutStatus.uuid   as salesPhaseOutStatus,
            salesarea.phaseOutStatus.code   as salesPhaseoutStCode,
            salesarea.yStatusValidfrom      as yStatusValidfrom : Date,
            salesarea.openTransactionSales  as openTransactionSales

    from pd.ProjectIDHPlants as plants
    inner join pd.ProjectIDHSalesArea as salesarea
        on plants.uuid = salesarea.l_ev.uuid
    where
        plants.phaseOutNEEDED                        = (
            case
                when plants.l_ev.phaseOutScenario.id = 'Scenario01'
                     then 'Yes'
                when plants.l_ev.phaseOutScenario.id = 'Scenario03'
                     then 'No'
            end
        );
