sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/base/security/encodeURL",
    "sap/m/BusyDialog"
  ],
  function (BaseController, JSONModel, encodeURL, BusyDialog) {
    "use strict";

    return BaseController.extend("bpnspc.workflowuimodule.controller.App", {
      onInit: function () {

        // find current year and month so that the column headings
        // for past and present forecast can be adjusted
        const currentDate = new Date();
        const currentMonth = currentDate.getMonth() + 1; // JavaScript months are 0-indexed, so add 1const currentYear = currentDate.getFullYear();
        const currentYear = currentDate.getFullYear();
        let structure = {};

        // prepare for another JSON model to have the real months shown in the table column headers
        let month = currentMonth;
        let year = currentYear;
        for (let i = 4; i > 0; i--) {
          if (month === 0) {
            month = 12;
            year = year - 1;
            structure[`month${i}`] = `M ${String(month).padStart(2, '0')}.${year}`;
          } else
            structure[`month${i}`] = `M ${String(month).padStart(2, '0')}.${year}`;
          month = month - 1;
        }

        let busy = new BusyDialog();
        busy.open();

        // proceed only after context is available
        this.getView().getModel("context").dataLoaded().then(async () => {

          // fetch the context information and update the form
          let projectId = this.getView().getModel("context").getData().startEvent.projectHeader.projectID;
          let projectDescription = this.getView().getModel("context").getData().startEvent.projectHeader.projectDescription;
          let phaseOutDate = this.getView().getModel("context").getData().startEvent.projectHeader.phaseOutDate;
          let demandPlannerId = this.getView().getModel("context").getData().custom.demandplannerid;
          let demandPlanner = this.getView().getModel("context").getData().custom.demandplanner;
          let sMaterial = this.getView().getModel("context").getData().startEvent.material;
          const substMaterial = await this.getSubstMatFun(projectId, sMaterial);
          structure.projectID = projectId;
          structure.projectDescription = projectDescription;
          structure.demandplannerid = demandPlannerId;
          structure.phaseOutDate = phaseOutDate;
          structure.demandPlanner = demandPlanner;
          structure.subsMaterial = substMaterial;
          
          var oModelPf1 = new JSONModel(structure);

          this.getView().setModel(oModelPf1, "oCustompast");

          for (let i = 0; i < 12; i++) {
            const monthIndex = currentMonth + i;
            const month = (monthIndex <= 12) ? monthIndex : monthIndex - 12;
            const year = (monthIndex <= 12) ? currentYear : currentYear + 1;

            structure[`month${i + 1}`] = `M ${String(month).padStart(2, '0')}.${year}`;
          }

          var oModelPf2 = new JSONModel(structure);
          this.getView().setModel(oModelPf2, "oCustomfuture");

          busy.close();
        });

        // attach updatefinished event to fire the autoresize of all columns
        // so that it fits to content

        let oFFTable = this.getView().byId('idSmartTableFFTreeTable');
        let oPFTable = this.getView().byId('idSmartTablePFTreeTable');

        oFFTable.attachRowsUpdated((_) => {

          // resize columns to fit to content
          oFFTable.getColumns().forEach(column => column.getVisible() ? column.autoResize() : column);

          // add style classes for totals
          oFFTable.getRows().forEach((row) => {
            const hLevel = row.getBindingContext().getObject().hierarchyLevel;
            if (hLevel === 0) {
              row.getCells()[3].addStyleClass("styleShiptoSoldto");
              row.getCells()[4].addStyleClass("styleShiptoSoldto");
              row.getCells().forEach((cell, index) => {
                if (index > 4) {
                  cell.addStyleClass("styleMonthTotals")
                }
              });
            } else if (hLevel === 1) {
              row.getCells()[3].addStyleClass("styleShiptoSoldto");
              row.getCells()[4].addStyleClass("styleShiptoSoldto");
              row.getCells().forEach((cell, index) => {
                if (index > 4) {
                  cell.addStyleClass("styleShipToMonthTotals")
                }
              });
            }
          });
        });

        oPFTable.attachRowsUpdated((_) => {

          // resize columns to fit to content
          oPFTable.getColumns().forEach(column => column.getVisible() ? column.autoResize() : column);

          // add style classes for totals
          oPFTable.getRows().forEach((row) => {
            const hLevel = row.getBindingContext().getObject().hierarchyLevel;
            if (hLevel === 0) {
              row.getCells()[3].addStyleClass("styleShiptoSoldto");
              row.getCells()[4].addStyleClass("styleShiptoSoldto");
              row.getCells().forEach((cell, index) => {
                if (index > 4) {
                  cell.addStyleClass("styleMonthTotals")
                }
              });
            } else if (hLevel === 1) {
              row.getCells()[3].addStyleClass("styleShiptoSoldto");
              row.getCells()[4].addStyleClass("styleShiptoSoldto");
              row.getCells().forEach((cell, index) => {
                if (index > 4) {
                  cell.addStyleClass("styleShipToMonthTotals")
                }
              });
            }
          });

        });

      },

      onInitializeSmartTable: function (oEvent) {
        this.getView().getModel("context").dataLoaded().then((_) => {
          oEvent.getSource().rebindTable(true);
        });
      },

      onBeforeRebindFFTable: async function (oEvent) {
        let oBindingParams = oEvent.getParameter("bindingParams");
        let material = this.getView().getModel("context").getData().startEvent.material;
        let demandPlanner = this.getView().getModel("context").getData().custom.demandplanner;

        // overwrite function createCustomParams() of oDataModel V2 due to it would remove the $filter request
        // in custom parameters
        this._overWriteCreateCustomParams('idFutureForecastSmartTable');

        oBindingParams.parameters.select = "Material,Keyfigure,ApoLevel,ShiptoCountry,Soldto,BaseUom,nodeId,drillState,parentNodeId,hierarchyLevel";
        oBindingParams.parameters.operationMode = 'Client';
        oBindingParams.parameters.countMode = 'Inline';
        oBindingParams.parameters.treeAnnotationProperties = {
          hierarchyLevelFor: 'hierarchyLevel',
          hierarchyNodeFor: 'nodeId',
          hierarchyParentNodeFor: 'parentNodeId',
          hierarchyDrillStateFor: 'drillState'
        };

        oBindingParams.parameters.custom = {
          $filter: `Material eq '${material}' and DemandPlanner eq '${demandPlanner}'`
        };

        let that = this;

        oBindingParams.events = {
          dataReceived: (oEvent) => {
            // Restore the original function createCustomParams of oDataModel to make sure this has no side effects to other parts of the app
            that._restoreCreateCustomParams('idFutureForecastSmartTable');
          },
        };
      },

      onBeforeRebindPFTable: async function (oEvent) {
        let oBindingParams = oEvent.getParameter("bindingParams");
        let material = this.getView().getModel("context").getData().startEvent.material;
        let demandPlanner = this.getView().getModel("context").getData().custom.demandplanner;

        // overwrite function createCustomParams() of oDataModel V2 due to it would remove the $filter request
        // in custom parameters
        this._overWriteCreateCustomParams('idPastForecastSmartTable');

        oBindingParams.parameters.select = "Material,Keyfigure,ApoLevel,ShiptoCountry,Soldto,BaseUom,nodeId,drillState,parentNodeId,hierarchyLevel";
        oBindingParams.parameters.operationMode = 'Client';
        oBindingParams.parameters.countMode = 'Inline';
        oBindingParams.parameters.treeAnnotationProperties = {
          hierarchyLevelFor: 'hierarchyLevel',
          hierarchyNodeFor: 'nodeId',
          hierarchyParentNodeFor: 'parentNodeId',
          hierarchyDrillStateFor: 'drillState'
        };

        oBindingParams.parameters.custom = {
          $filter: `Material eq '${material}' and DemandPlanner eq '${demandPlanner}'`
        };

        let that = this;

        oBindingParams.events = {
          dataReceived: (oEvent) => {
            // Restore the original function createCustomParams of oDataModel to make sure this has no side effects to other parts of the app
            that._restoreCreateCustomParams('idPastForecastSmartTable');
          },
        };
      },

      _overWriteCreateCustomParams: function (tableId) {
        // store the original function as private attribute
        this._createCustomParams = this.getView().byId(tableId).getModel().createCustomParams;
        // overwrite original function to prevent it from deleting custom parameters beginning with "$"
        this.getView().byId(tableId).getModel().createCustomParams = function (mParameters) {
          var aCustomParams = [],
            mCustomQueryOptions,
            mSupportedParams = {
              expand: true,
              select: true,
            };
          for (var sName in mParameters) {
            if (sName in mSupportedParams) {
              aCustomParams.push("$" + sName + "=" + encodeURL(mParameters[sName]));
            }
            if (sName === "custom") {
              mCustomQueryOptions = mParameters[sName];
              for (sName in mCustomQueryOptions) {
                if (typeof mCustomQueryOptions[sName] === "string") {
                  aCustomParams.push(sName + "=" + encodeURL(mCustomQueryOptions[sName]));
                } else {
                  aCustomParams.push(sName);
                }
              }
            }
          }
          return aCustomParams.join("&");
        };
      },

      _restoreCreateCustomParams: function (tableId) {
        if (this._createCustomParams) this.getView().byId(tableId).getModel().createCustomParams = this._createCustomParams;
      },
      getSubstMatFun: async function (projectId, material) {
        return new Promise((resolve, reject) => {
          this.getView().getModel().callFunction("/getSubstMat", {
            method: "POST",
            urlParameters: {
              projectID: projectId,
              material: material
            },
            success: function (oData) {
              resolve(oData.getSubstMat);
            },
            error: function (oError) {
              reject(oError);
            }
          });
        }).catch((error) => {
          console.log(error.message);
        });
      }
    });
  }
);
