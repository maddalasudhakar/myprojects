/* global QUnit */

sap.ui.require(["bpnspc/workflowuimodule/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
