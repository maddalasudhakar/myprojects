sap.ui.define([
	"bpnspc/workflow-ui-module/test/unit/controller/businessplannerform.controller"
], function () {
	"use strict";
});
