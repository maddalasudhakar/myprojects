/*global QUnit*/

sap.ui.define([
	"bpnspc/workflow-ui-module/controller/businessplannerform.controller"
], function (Controller) {
	"use strict";

	QUnit.module("businessplannerform Controller");

	QUnit.test("I should test the businessplannerform controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
