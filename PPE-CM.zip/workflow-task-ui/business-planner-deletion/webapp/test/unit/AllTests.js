sap.ui.define([
	"bpdnspcworkflowuimodule/workflow-ui-module/test/unit/controller/App.controller"
], function () {
	"use strict";
});
