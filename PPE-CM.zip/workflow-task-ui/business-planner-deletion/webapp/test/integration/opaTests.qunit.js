/* global QUnit */

sap.ui.require(["bpdnspc/workflowuimodule/workflowuimodule/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
