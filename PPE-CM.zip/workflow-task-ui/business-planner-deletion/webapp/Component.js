sap.ui.define(
  [
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "bpdnspc/workflowuimodule/workflowuimodule/model/models",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/BusyDialog"
  ],
  function (UIComponent, Device, models, JSONModel, MessageBox, ODataModel, BusyDialog) {
    "use strict";

    return UIComponent.extend(
      "bpdnspc.workflowuimodule.workflowuimodule.Component",
      {
        metadata: {
          manifest: "json",
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
          // call the base component's init function
          UIComponent.prototype.init.apply(this, arguments);

          // enable routing
          // this.getRouter().initialize();

          // set the device model
          this.setModel(models.createDeviceModel(), "device");

          var jsonModel = new JSONModel();
          this.setModel(jsonModel, "tableModel");

          this.setTaskModels();

          this.getInboxAPI().addAction(
            {
              action: "SUBMIT",
              label: "Finalize",
              type: "accept", // (Optional property) Define for positive appearance
            },
            function () {
              // this.completeTask(true);
              let that = this;
              MessageBox.show("Do you confirm to finalize the task?", {
                icon: MessageBox.Icon.WARNING,
                title: "Confirm Business Planner Deletion",
                actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                emphasizedAction: MessageBox.Action.YES,
                onClose: function (oAction) {
                  if (oAction === 'YES') {
                    let busy = new BusyDialog();

                    // show user that action is happening behind
                    busy.open();

                    let bFcExist = true;

                    // fetch the data from json model of future forecast to write validation on months property
                    let futuredata = that.getModel("tableModel").getData().FutureForecastData;
                    for (var i = 0; i < futuredata.length; i++) {
                      if(futuredata[i].month1 == 0 && futuredata[i].month2 == 0 && futuredata[i].month3 == 0 && futuredata[i].month4 == 0 && futuredata[i].month5 == 0 && futuredata[i].month6 == 0 && futuredata[i].month7 == 0 && futuredata[i].month8 == 0 && futuredata[i].month9 == 0 && futuredata[i].month10 == 0 && futuredata[i].month11 == 0 && futuredata[i].month12 == 0) {
                        bFcExist = false;
                      } else {
                        bFcExist = true;
                        break;
                      }
                    }

                    if (!bFcExist) {
                      that.completeTask(true, 'submit');
                      busy.close();
                    } else {
                      busy.close();
                      MessageBox.error("Please delete the forecasts before finalizing this task");
                    }
                  }
                }
              });
            },
            this
          );
        },

        setTaskModels: function () {
          // set the task model
          var startupParameters = this.getComponentData().startupParameters;
          this.setModel(startupParameters.taskModel, "task");

          // set the task context model
          var taskContextModel = new sap.ui.model.json.JSONModel(
            this._getTaskInstancesBaseURL() + "/context"
          );
          this.setModel(taskContextModel, "context");
        },

        _getTaskInstancesBaseURL: function () {
          return (
            this._getWorkflowRuntimeBaseURL() +
            "/task-instances/" +
            this.getTaskInstanceID()
          );
        },

        _getWorkflowRuntimeBaseURL: function () {
          var appId = this.getManifestEntry("/sap.app/id");
          var appPath = appId.replaceAll(".", "/");
          var appModulePath = jQuery.sap.getModulePath(appPath);

          return appModulePath + "/bpmworkflowruntime/v1";
        },

        getTaskInstanceID: function () {
          return this.getModel("task").getData().InstanceID;
        },

        getInboxAPI: function () {
          var startupParameters = this.getComponentData().startupParameters;
          return startupParameters.inboxAPI;
        },

        completeTask: function (approvalStatus,outcomeId) {
          this.getModel("context").setProperty("/approved", approvalStatus);
          this._patchTaskInstance(outcomeId);
          this._refreshTaskList();
        },

        _patchTaskInstance: function (outcomeId) {
          var data = {
            status: "COMPLETED",
            decision: outcomeId,
            context: this.getModel("context").getData(),
          };

          jQuery.ajax({
            url: this._getTaskInstancesBaseURL(),
            method: "PATCH",
            contentType: "application/json",
            async: false,
            data: JSON.stringify(data),
            headers: {
              "X-CSRF-Token": this._fetchToken(),
            },
          });
        },

        _fetchToken: function () {
          var fetchedToken;

          jQuery.ajax({
            url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
            method: "GET",
            async: false,
            headers: {
              "X-CSRF-Token": "Fetch",
            },
            success(result, xhr, data) {
              fetchedToken = data.getResponseHeader("X-CSRF-Token");
            },
          });
          return fetchedToken;
        },

        _refreshTaskList: function () {
          this.getInboxAPI().updateTask("NA", this.getTaskInstanceID());
        },
      }
    );
  }
);
