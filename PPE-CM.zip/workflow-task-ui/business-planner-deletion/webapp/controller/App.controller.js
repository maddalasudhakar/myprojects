sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/m/BusyDialog",
    "sap/ui/model/Filter"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageToast, MessageBox, BusyDialog, Filter) {
        "use strict";

        return Controller.extend("bpdnspc.workflowuimodule.workflowuimodule.controller.App", {
            onInit: function () {

                let structure = {};
                // this is busy indicator
                let busy = new BusyDialog();
                busy.open();

                // proceed only after context is available
                this.getView().getModel("context").dataLoaded().then(async () => {

                    // fetch the context information and update the form
                    let projectId = this.getView().getModel("context").getData().startEvent.projectHeader.projectID;
                    let projectDescription = this.getView().getModel("context").getData().startEvent.projectHeader.projectDescription;
                    let phaseOutDate = this.getView().getModel("context").getData().startEvent.projectHeader.phaseOutDate;
                    let demandPlannerId = this.getView().getModel("context").getData().custom.demandplannerid;
                    let demandPlanner = this.getView().getModel("context").getData().custom.demandplanner;
                    let material = this.getView().getModel("context").getData().startEvent.projectIdh[0].material;
                    let materialText = this.getView().getModel("context").getData().startEvent.projectIdh[0].materialText;
                    let regionScope = this.getView().getModel("context").getData().startEvent.projectIdh[0].regionScope;
                    // let spConfirmedDate = this.getView().getModel("context").getData().startEvent.projectIdh[0].spConfirmedDate;

                    structure.projectID = projectId;
                    structure.projectDescription = projectDescription;
                    structure.demandplannerid = demandPlannerId;
                    structure.phaseOutDate = phaseOutDate;
                    structure.demandPlanner = demandPlanner;

                    var spDate = await this.getSpConfirmDate(projectId,material);
                    if(spDate != undefined){
                        this.getView().getModel("tableModel").setProperty("/spDateValue", spDate.getSPPhaseOutDate);
                    }else{
                        this.getView().getModel("tableModel").setProperty("/spDateValue", "-");
                    }
                    
                    // spDate.then(function (data) {
                    //     this.getView().getModel("tableModel").setProperty("/spDateValue", data.value);
                    // }.bind(this)).catch(function (oError) {
                    //     MessageToast.show(oError);
                    // }.bind(this));

                    let spConfirmedDate = this.getView().getModel("tableModel").getData().spDateValue;

                    let listItems = { data: [{
                        material: material,
                        materialText: materialText,
                        regionScope: regionScope,
                        phaseOutDate: phaseOutDate,
                        spConfirmedDate: spConfirmedDate
                    }]};

                    var oModelPf1 = new JSONModel(structure);

                    this.getView().setModel(oModelPf1, "oCustompast");

                    oModelPf1 = new JSONModel(listItems);
                    this.getView().setModel(oModelPf1, "tableInfo");

                    this.oDataCallforFutureForecast(material,demandPlannerId);

                    busy.close();
                });
            },
            getSpConfirmDate: async function (projectId,material) {
                return new Promise((resolve, reject) => {
                    this.getView().getModel().callFunction("/getSPPhaseOutDate", {
                        method: "POST",
                        urlParameters: {
                            projectId: projectId,
                            material: material
                        },
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                }).catch((error) => {
                    MessageToast.show(error.message);
                });
            },
            oDataCallforFutureForecast: function (material, demandPlannerId) {
                let aFilters = [];

                aFilters.push(new Filter("Material", "EQ", material));
                aFilters.push(new Filter("DemandPlanner", "EQ", demandPlannerId));
                this.getView().getModel().read(`/FutureForecast`, {
                    filters: aFilters,
                    success: function (oData) {
                        // In odata response we are getting data like tree table parent child combination. 
                        // We are doing filter because we want only parent data for validation on property month1 ......month12.
                        let filteredOData = oData.results.filter(data => data.hierarchyLevel === 0);
                        // "tableModel" model i have defiend in component.js file because we want globally JSOM MODEL.
                        // filtered data we are storing in json model and using in component.js for validation.
                        this.getView().getModel("tableModel").setProperty("/FutureForecastData", filteredOData);
                    }.bind(this),
                    error: function (oError) {
                        sap.m.MessageToast.show("Error for fetching future forecast data");
                    }
                })
            }
        });
    });
