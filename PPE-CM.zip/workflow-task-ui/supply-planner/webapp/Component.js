sap.ui.define(
  [
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "spnspc/workflowuimodule/model/models",
    "sap/m/MessageBox",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/BusyDialog"
  ],
  function (UIComponent, Device, models, MessageBox, ODataModel, BusyDialog) {
    "use strict";

    return UIComponent.extend(
      "spnspc.workflowuimodule.Component",
      {
        metadata: {
          manifest: "json",
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
          // call the base component's init function
          UIComponent.prototype.init.apply(this, arguments);

          // // enable routing
          // this.getRouter().initialize();

          // set the device model
          this.setModel(models.createDeviceModel(), "device");

          this.setTaskModels();

          this.getInboxAPI().addAction(
            {
              action: "SUBMIT",
              label: "Finalize",
              type: "accept", // (Optional property) Define for positive appearance
            },
            function () {
              let that = this;
              MessageBox.show("Do you confirm to finalize the task?", {
                icon: MessageBox.Icon.WARNING,
                title: "Confirm Supply Planner task",
                actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                emphasizedAction: MessageBox.Action.YES,
                onClose: async function (oAction) {
                  if (oAction === 'YES') {
                    let busy = new BusyDialog();

                    // show user that action is happening behind
                    busy.open();

                    // fetch user inputs from table and update the table via service
                    // this information will not be in the model and that is not the service
                    // to update the data back to the backend
                    let oTable = that.getRootControl().byId('idSupplyPlanItemsGridTable');
                    let aItemsToUpdate = [];

                    // fetch the odata v2 model attached to the default model in manifest
                    let oModel = that.getRootControl().getModel();
                    let bError = true;

                    await Promise.all([new Promise(async (resolve, reject) => {

                      for await (let row of oTable.getRows()) {
                        if (row.getCells()[0].getText() === "" || row.getBindingContext().getObject().hierarchyLevel === 0)
                          continue;

                        let oItemToUpdate = {
                          uuid: "",
                          confDate: "",
                          futureY4Date: "",
                          lbeL16FG: "0",
                          lbeL16SFG: "0",
                          lbeL16RNP: "0",
                          additionalProd: "0",
                          material: "",
                          regionOrPlant: ""
                        };

                        for await (let column of oTable.getColumns()) {

                          let index = row.getCells().findIndex(cell => cell.getFieldHelpDisplay() === column.getId());

                          if (!['confDatePerRegion', 'futureY4Date', 'lbeL16FG', 'lbeL16SFG', 'lbeL16RNP', 'additionalProd', 'material', 'regionOrPlant'].includes(column.getCustomData()[0].getValue().columnKey)) {
                            continue;
                          }

                          if (column.getCustomData()[0].getValue().columnKey === 'confDatePerRegion') {
                            if (!row.getCells()[index].getDateValue())
                              resolve(true);
                            else {
                              oItemToUpdate.confDate = row.getCells()[index].getDateValue();
                            }
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'futureY4Date') {
                            if (!row.getCells()[index].getDateValue())
                              resolve(true);
                            else
                              oItemToUpdate.futureY4Date = row.getCells()[index].getDateValue();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'lbeL16FG') {
                            if (!row.getCells()[index].getValue())
                              resolve(true);
                            else
                              oItemToUpdate.lbeL16FG = row.getCells()[index].getValue();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'lbeL16SFG') {
                            if (!row.getCells()[index].getValue())
                              resolve(true);
                            else
                              oItemToUpdate.lbeL16SFG = row.getCells()[index].getValue();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'lbeL16RNP') {
                            if (!row.getCells()[index].getValue())
                              resolve(true);
                            else
                              oItemToUpdate.lbeL16RNP = row.getCells()[index].getValue();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'additionalProd') {
                            if (!row.getCells()[index].getValue())
                              resolve(true);
                            else
                              oItemToUpdate.additionalProd = row.getCells()[index].getValue();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'material') {
                            if (!row.getCells()[index].getText())
                              resolve(true);
                            else
                              oItemToUpdate.material = row.getCells()[index].getText();
                          }
                          else if (column.getCustomData()[0].getValue().columnKey === 'regionOrPlant') {
                            if (!row.getCells()[index].getText())
                              resolve(true);
                            else
                              oItemToUpdate.sourcePlant = row.getCells()[index].getText();
                          }
                        }

                        oItemToUpdate.uuid = row.getBindingContext().getObject().nodeId;
                        aItemsToUpdate.push(oItemToUpdate);
                      };

                      resolve(false);
                    })
                    ]).then((data) => {
                      bError = data[0];
                      if (!bError) {
                        aItemsToUpdate.forEach((item) => {
                          oModel.update(`/ProjectIDHPlants(${item.uuid})`, {
                            confDatePerRegion: item.confDate,
                            futureY4Date: item.futureY4Date,
                            lbeL16FG: item.lbeL16FG,
                            lbeL16SFG: item.lbeL16SFG,
                            lbeL16RNP: item.lbeL16RNP,
                            additionalProd: item.additionalProd
                          }, {
                            success: (oData, response) => {
                              that.completeTask(true, 'submit');
                              busy.close();
                            },
                            error: (error) => {
                              busy.close();
                              MessageBox.error(`Could not update the manual input: ${error}`);
                            }
                          });

                          new Promise((resolve, reject) => {
                            oModel.callFunction("/updateMaterialPlantDateStatus", {
                              method: 'POST',
                              urlParameters: {
                                material: item.material,
                                plant: item.sourcePlant,
                                date: item.confDate,
                                field: "YYA_LC_Y4"
                              },
                              success: $.proxy(function (oData) {
                                //
                              }, this),
                              error: (error) => reject(error)
                            });
                          }).catch((error) => {
                            MessageBox.error(`Could not update the date: ${error}`);
                          });

                          new Promise((resolve, reject) => {
                            oModel.callFunction("/updateMaterialPlantDateStatus", {
                              method: 'POST',
                              urlParameters: {
                                material: item.material,
                                plant: item.sourcePlant,
                                date: item.futureY4Date,
                                field: "YYA_LC_SP_PHO_DATE"
                              },
                              success: $.proxy(function (oData) {
                                //
                              }, this),
                              error: (error) => reject(error)
                            });
                          }).catch((error) => {
                            MessageBox.error(`Could not update the date: ${error}`);
                          });

                        });

                        oModel.submitChanges();
                      } else {
                        busy.close();
                        MessageBox.error("Mandatory fields cannot be empty");
                      }
                    });
                  }
                }
              });
            },
            this
          );
        },

        setTaskModels: function () {
          // set the task model
          var startupParameters = this.getComponentData().startupParameters;
          this.setModel(startupParameters.taskModel, "task");

          // set the task context model
          var taskContextModel = new sap.ui.model.json.JSONModel(
            this._getTaskInstancesBaseURL() + "/context"
          );
          this.setModel(taskContextModel, "context");
        },

        _getTaskInstancesBaseURL: function () {
          return (
            this._getWorkflowRuntimeBaseURL() +
            "/task-instances/" +
            this.getTaskInstanceID()
          );
        },

        _getWorkflowRuntimeBaseURL: function () {
          var appId = this.getManifestEntry("/sap.app/id");
          var appPath = appId.replaceAll(".", "/");
          var appModulePath = jQuery.sap.getModulePath(appPath);

          return appModulePath + "/bpmworkflowruntime/v1";
        },

        getTaskInstanceID: function () {
          return this.getModel("task").getData().InstanceID;
        },

        getInboxAPI: function () {
          var startupParameters = this.getComponentData().startupParameters;
          return startupParameters.inboxAPI;
        },

        completeTask: function (approvalStatus, outcomeId) {
          this.getModel("context").setProperty("/approved", approvalStatus);
          this._patchTaskInstance(outcomeId);
          this._refreshTaskList();
        },

        _patchTaskInstance: function (outcomeId) {
          var data = {
            status: "COMPLETED",
            decision: outcomeId,
            context: this.getModel("context").getData(),
          };

          jQuery.ajax({
            url: this._getTaskInstancesBaseURL(),
            method: "PATCH",
            contentType: "application/json",
            async: false,
            data: JSON.stringify(data),
            headers: {
              "X-CSRF-Token": this._fetchToken(),
            },
          });
        },

        _fetchToken: function () {
          var fetchedToken;

          jQuery.ajax({
            url: this._getWorkflowRuntimeBaseURL() + "/xsrf-token",
            method: "GET",
            async: false,
            headers: {
              "X-CSRF-Token": "Fetch",
            },
            success(result, xhr, data) {
              fetchedToken = data.getResponseHeader("X-CSRF-Token");
            },
          });
          return fetchedToken;
        },

        _refreshTaskList: function () {
          this.getInboxAPI().updateTask("NA", this.getTaskInstanceID());
        },
      }
    );
  }
);
