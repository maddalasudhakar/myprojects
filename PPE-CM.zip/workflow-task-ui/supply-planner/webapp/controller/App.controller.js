sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/MessageBox",
    "sap/base/security/encodeURL",
    "sap/ui/core/Fragment",
    "sap/m/BusyDialog"
  ],
  function (BaseController, JSONModel, Filter, MessageBox, encodeURL, Fragment, BusyDialog) {
    "use strict";

    return BaseController.extend("spnspc.workflowuimodule.controller.App", {
      onInit: function () {

        let busy = new BusyDialog();
        busy.open();

        // proceed only after task context is available
        this.getView().getModel("context").dataLoaded().then(async (_) => {
          //fetch the context information and update the form
          let projectId = this.getView().getModel("context").getData().startEvent.projectHeader.projectID;
          let projectDescription = this.getView().getModel("context").getData().startEvent.projectHeader.projectDescription;
          let phaseOutDate = this.getView().getModel("context").getData().startEvent.projectHeader.phaseOutDate;
          let mrpId = this.getView().getModel("context").getData().custom.mrpId;
          let mrpEmail = this.getView().getModel("context").getData().custom.mrpEmail;
          let sMaterial = this.getView().getModel("context").getData().startEvent.material;
          const substMaterial = await this.getSubstMatFun(projectId, sMaterial);

          let oData = {
            projectId: projectId,
            projectDescription: projectDescription,
            phaseOutDate: phaseOutDate,
            mrpEmail: mrpEmail,
            mrp: mrpId,
            minDate: new Date(),
            subsMaterial : substMaterial
          };

          this.getView().setModel(new JSONModel(oData), "oSPProjectInfo");
          busy.close();

          // let oSmartTable = this.getView().byId('idSupplyPlanItemsSmartTable');
          // oSmartTable.rebindTable(true);

          // attach rowsUpdated event of the Grid table
          // here we can use this for aggregated totals
          // dirty way but we will look at optimization later
          let oSPTable = this.getView().byId("idSupplyPlanItemsGridTable");
          oSPTable.attachRowsUpdated(async (oEvent) => {

            // resize columns to fit to content
            oSPTable.getColumns().forEach((column) => {
              if (column.getVisible()) {
                column.autoResize();
              }
            });

            oSPTable.getRows().forEach((row) => {
              if (row.getCells()[0].getText() !== "") {
                const hLevel = row.getBindingContext().getObject().hierarchyLevel;
                if (hLevel === 0) {
                  row.addStyleClass("styleRegions");
                }
              }
            });
          });
        }, this);
      },

      onInitializeSmartTable: function (oEvent) {
        this.getView().getModel("context").dataLoaded().then((_) => {
          oEvent.getSource().rebindTable(true);
        });
      },

      onBeforeRebindTable: async function (oEvent) {
        let oBindingParams = oEvent.getParameter("bindingParams");
        let material = this.getView().getModel("context").getData().startEvent.material;
        let mrpId = this.getView().getModel("context").getData().custom.mrpId;
        let projectId = this.getView().getModel("context").getData().startEvent.projectHeader.projectID;

        // add some more fields to $select which are not visible to user (including in the personalization settings)
        // but these are useful technically. eg: nodeId is the UUID of the IDHPlant table and needed during table update
        oBindingParams.parameters.select += ',nodeId,parentId,hierarchyLevel,drillState,bomExists,sourceSystem,mrpController,mrpControllerEmail';


        // overwrite function createCustomParams() of oDataModel V2 due to it would remove the $filter request
        // in custom parameters
        this._overWriteCreateCustomParams('idSupplyPlanItemsSmartTable');

        oBindingParams.parameters.custom = {
          $filter: `projectID eq '${projectId}' and material eq '${material}' and mrpController eq '${mrpId}' and plantYStatus ne 'Y5'`
        };

        let that = this;

        oBindingParams.events = {
          dataReceived: (oEvent) => {
            // Restore the original function createCustomParams of oDataModel to make sure this has no side effects to other parts of the app
            that._restoreCreateCustomParams('idSupplyPlanItemsSmartTable');
          },
        };

      },
      _overWriteCreateCustomParams: function (tableId) {
        // store the original function as private attribute
        this._createCustomParams = this.getView().byId(tableId).getModel().createCustomParams;
        // overwrite original function to prevent it from deleting custom parameters beginning with "$"
        this.getView().byId(tableId).getModel().createCustomParams = function (mParameters) {
          var aCustomParams = [],
            mCustomQueryOptions,
            mSupportedParams = {
              expand: true,
              select: true,
            };
          for (var sName in mParameters) {
            if (sName in mSupportedParams) {
              aCustomParams.push("$" + sName + "=" + encodeURL(mParameters[sName]));
            }
            if (sName === "custom") {
              mCustomQueryOptions = mParameters[sName];
              for (sName in mCustomQueryOptions) {
                if (typeof mCustomQueryOptions[sName] === "string") {
                  aCustomParams.push(sName + "=" + encodeURL(mCustomQueryOptions[sName]));
                } else {
                  aCustomParams.push(sName);
                }
              }
            }
          }
          return aCustomParams.join("&");
        };
      },

      _restoreCreateCustomParams: function (tableId) {
        if (this._createCustomParams) this.getView().byId(tableId).getModel().createCustomParams = this._createCustomParams;
      },

      formatDate: function (date) {

        if (!date)
          return "";

        // Create a date object from a date string
        const oDate = new Date(date);

        // Get year, month, and day part from the date
        const year = oDate.toLocaleString("default", { year: "numeric" });
        const month = oDate.toLocaleString("default", { month: "2-digit" });
        const day = oDate.toLocaleString("default", { day: "2-digit" });

        return `${year}-${month}-${day}`;
      },

      validateDate: function (oEvent) {
        if (!oEvent.getParameter("valid")) {
          oEvent.getSource().setDateValue(null);
          MessageBox.error("Please select valid date for confirmed date and future Y4");
          return;
        }
      },

      onBomCompParentsPress: async function (oEvent) {
        let component = oEvent.getSource().getBindingContext().getObject("Component");
        let plant = oEvent.getSource().getBindingContext().getObject("Plant");
        let oComponent = oEvent.getSource().getParent();
        oComponent.setBusy(true);

        if (!this._oBCPDialog) {
          this._oBCPDialog = await Fragment.load({
            id: "BomCompParents",
            name: "spnspc.workflowuimodule.fragments.BomCompParentDetails",
            controller: this
          }).then(function (oDialog) {
            oEvent.getSource().getParent().addDependent(oDialog);
            return oDialog;
          }.bind(this));
        }
        const filters = [
          new Filter({
            path: 'Material',
            operator: 'EQ',
            value1: component
          }),
          new Filter({
            path: 'Plant',
            operator: 'EQ',
            value1: plant
          })
        ];

        const combinedFilter = new Filter({
          filters: filters,
          and: true
        });

        if (combinedFilter) {
          this._oBCPDialog.getContent()[0].getBinding("items").filter(new Filter(combinedFilter));
        }

        let that = this;
        this._oBCPDialog.getContent()[0].getModel().attachEventOnce("batchRequestCompleted", null, () => {
          oComponent.setBusy(false);
          that._oBCPDialog.open();
        }, this);
      },

      onCompDetailsPress: async function (oEvent) {

        let material = oEvent.getSource().getBindingContext().getObject("material");
        let plant = oEvent.getSource().getBindingContext().getObject("regionOrPlant");
        let projectID = oEvent.getSource().getBindingContext().getObject("projectID");

        let oComponent = oEvent.getSource();
        oComponent.setBusy(true);

        let oView = oEvent.getSource().getParent();

        // Create the Dialog and Load the Fragment with Promises
        if (!this._oDialog) {
          this._oDialog = await Fragment.load({
            id: oView.getId(),
            name: "spnspc.workflowuimodule.fragments.BomCompDetails",
            controller: this
          })
            .then(async (oDialog) => {
              oView.addDependent(oDialog);
              return oDialog;
            })
            .catch((error) => {
              MessageBox.error("Error loading dialog fragment:", error);
            });
        }

        const filters = [
          new Filter({
            path: 'Material',
            operator: 'EQ',
            value1: material
          }),
          new Filter({
            path: 'Plant',
            operator: 'EQ',
            value1: plant
          })
        ];

        const combinedFilter = new Filter({
          filters: filters,
          and: true
        });
        // this._oDialog.getContent()[0].getBinding("rows").filter(new Filter(combinedFilter));

        let oBomTreeTable = this._oDialog.getContent()[0];
        if (oBomTreeTable) {
          oBomTreeTable.attachEvent("rowsUpdated", this._updateBomTreeRowColors.bind(this));
          oBomTreeTable.attachEvent("expand", this._updateBomTreeRowColors.bind(this));  // Update color on expand
          oBomTreeTable.attachEvent("collapse", this._updateBomTreeRowColors.bind(this)); // Update color on collapse                
        }

        this._oDialog.getContent()[0].bindAggregation("rows", {
          path: '/BomTree',
          filters: combinedFilter,
          parameters: {
            countMode: 'Inline',
            treeAnnotationProperties: {
              hierarchyLevelFor: 'Level',
              hierarchyNodeFor: 'NodeId',
              hierarchyParentNodeFor: 'ParentNodeId',
              hierarchyDrillStateFor: 'Drillstate'
            }
          }
        });

        const oModel = this._oDialog.getContent()[0].getModel();
        if (oModel) {
          oModel.setHeaders({
            projectID: projectID
          });
        }

        let that = this;
        this._oDialog.getContent()[0].getModel().attachEventOnce("batchRequestCompleted", null, () => {
          oComponent.setBusy(false);
          that._oDialog.open();
        }, this);
      },
      _updateBomTreeRowColors: function () {
        let oTreeTable = this._oDialog.getContent()[0];
        if (oTreeTable) {
          var aRows = oTreeTable.getRows(); // Get all rows (visible and hidden)

          // Loop through each row to check the hierarchy level and apply colors
          aRows.forEach(function (oRow) {
            var oContext = oRow.getBindingContext();

            // Always reset colors before applying new color logic
            oRow.removeStyleClass("parentBomTreeRowColor");

            if (oContext) {
              var iHierarchyLevel = oContext.getProperty("Level");

              // Apply CSS class for parent rows (hierarchy level 0)
              if (iHierarchyLevel === 0) { // Parent row
                oRow.addStyleClass("parentBomTreeRowColor");
              }
            }
          });
        }
      },
      onBomTreeDialogAfterOpen: function (oEvent) {
        // Get the Tree Table inside the Dialog
        let oTreeTable = this._oDialog.getContent()[0];
        if (oTreeTable) {
          oTreeTable.expandToLevel(3);
        }
      },
      onToggleFullScreen: function (oEvent) {
        let oDialog = this._oDialog;
        let bIsFullScreen = oDialog.hasStyleClass("fullScreen");
        let oTreeTable = this._oDialog.getContent()[0];

        if (bIsFullScreen) {
          // Exit full-screen mode
          oDialog.removeStyleClass("fullScreen");
          oDialog.setProperty("draggable", true);
          oDialog.setProperty("resizable", true);
          oEvent.getSource().setIcon("sap-icon://full-screen");

          oTreeTable.setVisibleRowCount(10); // Adjust to your original value
        } else {
          // Enter full-screen mode
          oDialog.addStyleClass("fullScreen");
          oDialog.setProperty("draggable", false);
          oDialog.setProperty("resizable", false);
          oEvent.getSource().setIcon("sap-icon://exit-full-screen");

          var iRowCount = oTreeTable.getBinding("rows").getLength();
          oTreeTable.setVisibleRowCount(iRowCount);
        }
      },
      onClosePress: function (oEvent) {
        oEvent.getSource().getParent().close();
      },
      onAddProdChange: function (oEvent) {
        // Get the source input field and its binding context
        const oInput = oEvent.getSource();
        const oContext = oInput.getBindingContext();
        const sValue = oEvent.getParameter("value");
        const sPath = oContext.getPath();
        
        if (!oContext) {
          return;
        }
        let makeToStrategy = oContext.getObject("makeToStrategy");
        if (makeToStrategy === 'MTS') {
          let additionalProd = parseInt(sValue) || 0;
          let totalSaleableInvBUOM = parseFloat(oContext.getObject("totalSaleableInvBUOM")) || 0;
          let fixedReceiptsBUOM = parseFloat(oContext.getObject("fixedReceiptsBUOM")) || 0;
          let fixedIssuesBUOM = parseFloat(oContext.getObject("fixedIssuesBUOM")) || 0;
          let forecastSNP = parseFloat(oContext.getObject("forecastSNP")) || 0;
          let invCoverageDays = parseFloat(oContext.getObject("invCoverageDays")) || 0;
          const oModel = this.getView().getModel();
          const denominator = (fixedIssuesBUOM + forecastSNP) / 365;
  
          if (denominator > 0) {
            invCoverageDays = Math.round((totalSaleableInvBUOM + fixedReceiptsBUOM + additionalProd) / denominator);
          } else {
            invCoverageDays = 0;
          }
          oModel.setProperty(`${sPath}/additionalProd`, sValue);
          // Update the invCoverage field in the OData model
          oModel.setProperty(`${sPath}/invCoverageDays`, invCoverageDays);       
        }
      },
      getSubstMatFun: async function (projectId, material) {
        return new Promise((resolve, reject) => {
          this.getView().getModel().callFunction("/getSubstMat", {
            method: "POST",
            urlParameters: {
              projectID: projectId,
              material: material
            },
            success: function (oData) {
              resolve(oData.getSubstMat);
            },
            error: function (oError) {
              reject(oError);
            }
          });
        }).catch((error) => {
          console.log(error.message);
        });
      }
    });
  }
);
