
@impl: 'srv/job-services.js'
service JobServices @(path: '/ppe/cm/job-services', requires: 'authenticated-user') {

    @restrict: [{
        grant: ['CREATE','UPDATE'],
        to: 'CMJobScheduler'
    }]
    action receiveBomJob(projectId: Integer) returns String;

    event receivedJob: {
        projectId: Integer;
        projectUuid: UUID;
    };
        @restrict: [{
        grant: ['READ','CREATE','UPDATE'],
        to: 'CMJobScheduler'
    }]
    function statusChangeWithOneYearJob() returns String;
    
    @restrict: [{
        grant: ['READ','CREATE','UPDATE'],
        to: 'CMJobScheduler'
    }]
    function statusHdiUpdateAfterManuallyChangeInSapJob() returns String;
    @restrict: [{
        grant: ['READ','CREATE','UPDATE'],
        to: 'CMJobScheduler'
    }]
    function updateAccountingSBUForProjectIDH() returns String;
    @restrict: [{
        grant: ['READ','CREATE','UPDATE'],
        to: 'CMJobScheduler'
    }]
    action deleteCanceledWorkflowLog() returns String;
    action JobToUpdateBPRegion () returns String;
}