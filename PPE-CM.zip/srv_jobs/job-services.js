const cds = require("@sap/cds");
const { SELECT } = require("@sap/cds/lib/ql/cds-ql");

module.exports = class JobServices extends cds.ApplicationService {
    init() {
        this.on("receiveBomJob", receiveJob);
        this.after("receiveBomJob", afterReceiveJob);
        this.on("receivedJob", triggerJobAndFetchData);
        this.on("statusChangeWithOneYearJob", statusChangeWithOneYearJobOn)
        this.on("statusHdiUpdateAfterManuallyChangeInSapJob", statusHdiUpdateAfterManuallyChangeInSapJobOn)
        this.on("updateAccountingSBUForProjectIDH", updateAccountingSBUForProjectIDH);
        this.on("deleteCanceledWorkflowLog", async(req) => {
                    const { ProjectIDHPlants, ProjectIDHs } = cds.entities('ComplexityManagement');
                    const { WorkFlowLogs } = cds.entities('ProcessAutomation');
                    try {
                        const idhData = await SELECT.from(ProjectIDHs, item => {
                            item.material,
                            item.phaseOutStatus_uuid,
                            item.l_ev_uuid,
                            item.l_ev.projectID.as('projectID'),
                            item.l_ev.projectStatus_uuid.as('projectStatus')
                        }).where({
                            'l_ev.projectStatus_uuid' : 'dae19016-c2da-47f4-9813-692f4b8d94d7'
                        });
                        if(idhData.length > 0){
                            for(let j in idhData){
                                await UPDATE(WorkFlowLogs).with({
                                    deletionFlag : "x"
                                }).where({
                                    projectID: idhData[j].projectID,
                                    material : idhData[j].material
                                });
                            }
                        }
                        
                        const salesData = await SELECT.from(ProjectIDHPlants, item => {
                            item.material,
                            item.plant,
                            item.mrpController,
                            item.phaseOutStatus_uuid,
                            item.l_ev_uuid,
                            item.l_ev.projectID.as('projectID')
                        }).where({
                            phaseOutStatus_uuid : 'a3549a6e-fd81-4b82-8caa-c19c93b431b8',
                            mrpController : {'!=' : ''},
                            'l_ev.projectID' : { '!=': null }
                        });
                        console.log(salesData);
                        for(let i in salesData){
                            let plant = salesData[i].plant;
                            const filteredWorkflow = await SELECT.from(WorkFlowLogs)
                                .where({
                                    taskUniqueId: salesData[i].mrpController,
                                    projectID: salesData[i].projectID,
                                    material : salesData[i].material,
                                    processStep : 'SP'
                                });
    
                            if(filteredWorkflow.length > 0){
    
                                let plantArray = filteredWorkflow[0].plant.split(',');
                                let filteredWrkflPlant = plantArray.filter(p => p.trim() !== plant);
                                console.log(filteredWrkflPlant);
                                // let arrayofPlant = filteredWorkflow[0].plant.split(',');
                                // let searchRes = arrayofPlant.find(elm => elm === plant);
                                // console.log(searchRes)
                                if(filteredWrkflPlant.length > 0){
                                    await cds.run(UPDATE(WorkFlowLogs).set({
                                    plant : filteredWrkflPlant.join(',')
                                    }).where({ 
                                        taskUniqueId: salesData[i].mrpController,
                                        projectID: salesData[i].projectID,
                                        material : salesData[i].material,
                                        processStep : 'SP'
                                    }));
                                }
    
                                if(filteredWrkflPlant.length == 0){
                                    await UPDATE(WorkFlowLogs).with({
                                        plant : "",
                                        deletionFlag : "x"
                                    }).where({
                                        taskUniqueId: salesData[i].mrpController,
                                        projectID: salesData[i].projectID,
                                        material : salesData[i].material,
                                        processStep : 'SP'
                                    });
                                    console.log(deleteWorkflow);
                                }
                            
                            }
                            console.log(filteredWorkflow);
                           
                        }

                        return 'job successfully run!';
                    }catch(err){
                        return err;
                    }
        });
        this.on("JobToUpdateBPRegion", async(req) => {
            const { WorkFlowLogs } = cds.entities('ProcessAutomation');
            let workflowLogBPData = await cds.run(SELECT(WorkFlowLogs).where({  processStep: 'BP', regionScope: { '=': null } }));
            for(let i in workflowLogBPData){
                let sFilter = `Material eq '${workflowLogBPData[i].material}' and DemandPlanner eq '${workflowLogBPData[i].taskUniqueId}'`;
                const apoDemandPlannerApi = await cds.connect.to("ApoDp");
                let aDemandPlanners = await apoDemandPlannerApi.get(`/DpData?$filter=${sFilter}`);
                let sRegionScope = aDemandPlanners[0]?.Region;
                if(sRegionScope){
                    await UPDATE(WorkFlowLogs).with(
                    {
                        regionScope : sRegionScope
                    }
                    ).where({
                        uuid : workflowLogBPData[i].uuid
                    });
                }
            }
        });
        return super.init();
    }
};

async function receiveJob(req, _) {

    // Project ID
    const projectId = req.data.projectId;
    const { CompUsageJobInfo } = cds.entities("ppe.cm.md");

    let oJobStatus = {};

    if (!projectId) {
        oJobStatus = {
            projectID: projectId,
            jobStatus: "Error",
            error: "Project ID is mandatory to start the job"
        };
        await UPSERT(oJobStatus).into(CompUsageJobInfo);
        return req.reject(400, 'Required Input data is missing.');
    }

    // Read relevant material plant combination
    const { ProjectHeaders } = cds.entities('ComplexityManagement');

    let idhProject = await SELECT.one.from(ProjectHeaders)
        .columns(`uuid`)
        .where({
            projectID: projectId
        });
    if (!idhProject) return req.reject(400, 'Project-ID not existing');

    oJobStatus = {
        projectID: projectId,
        jobStatus: "In Progress",
        error: null
    };

    await UPSERT(oJobStatus).into(CompUsageJobInfo);

    req.res.status(202);
    return `Job accepted with job id: ${req.headers["x-sap-job-id"]}`;
}

async function afterReceiveJob(res, req) {
    // Project ID
    const projectId = req.data.projectId;

    // Read relevant material plant combination
    const { ProjectHeaders } = cds.entities('ComplexityManagement');

    let idhProject = await SELECT.one.from(ProjectHeaders)
        .columns(`uuid`)
        .where({
            projectID: projectId
        });

    cds.spawn(null, async (tx) => {
        await this.emit("receivedJob", { projectId, idhProject });
    });

}

async function triggerJobAndFetchData(msg) {

    const { projectId, idhProject } = msg.data;
    // Read relevant material plant combination
    const { ProjectIDHPlants, AllMatTypes } = cds.entities('ComplexityManagement');

    let idhPlants = await SELECT.from(ProjectIDHPlants)
        .columns(`material`, `plant`, `sourceSystem`)
        .where({
            l_ev_uuid: idhProject.uuid,
            phaseOutNEEDED: 'Yes'
        });


    let data92 = ``, data93 = ``, oJobStatus = {};

    for await (let idhPlant of idhPlants) {
        if (idhPlant.sourceSystem === "92") {
            data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET BomItemTree?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27%20and%20WithExclusive%20eq%20true HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
        } else {
            data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nGET BomItemTree?$filter=Material%20eq%20%27${idhPlant.material}%27%20and%20Plant%20eq%20%27${idhPlant.plant}%27%20and%20WithExclusive%20eq%20true HTTP/1.1\r\nAccept: application/json\r\n\r\n\r\n`;
        }
    }

    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;

    let aFinalResponse = [];
    let error92 = false, error93 = false;

    const aPromises = [];

    if (data92) {
        // connect to odata
        aPromises.push(new Promise(async (resolve, reject) => {
            const bomApi = await cds.connect.to("MatBoms");
            try {
                const response = await bomApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data92
                });
                resolve(response);
            } catch (error) {
                reject(error);
            }
        }));
    }

    if (data93) {
        // connect to odata
        aPromises.push(new Promise(async (resolve, reject) => {
            const bomApi = await cds.connect.to("APAC_MatBoms");
            try {
                const response = await bomApi.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data93
                });
                resolve(response);
            } catch (error) {
                reject(error);
            }
        }));
    }

    await Promise.allSettled(aPromises).then(async (aResponses) => {
        for (let response of aResponses) {
            if (response.status === 'fulfilled') {
                // batch response needs to be decoded to identify individual one's
                // so use regex to find out JSON outputs from the total batch response
                let regex = /\{.*\}/g,
                    oEachResponseIterator = response.value.matchAll(regex);

                // use JSON parse to parse the string to JSON
                for await (let response of oEachResponseIterator) {
                    const finalResponse = JSON.parse(response[0]).value;
                    aFinalResponse = finalResponse.length > 0 ? aFinalResponse.concat(finalResponse) : aFinalResponse;
                }
            } else {
                if (response.reason.message.includes('92')) {
                    error92 = true;
                    cds.log("92failed").error(response.reason.message);
                } else if (response.reason.message.includes('93')) {
                    error93 = true;
                    cds.log("93failed").error(response.reason.message);
                }
            }
        }
    });

    let aComponents = aFinalResponse.map(item => item.Component);
    let aNewEntries = [];

    if (aComponents.length > 0) {
        let aMatType = await SELECT.from(AllMatTypes).columns(`matnr`, `mtart`).where({
            matnr: {
                in: aComponents
            }
        });

        aNewEntries = aFinalResponse.map((item) => {
            let oMatType = aMatType.filter(matType => matType.matnr === item.Component);
            return {
                projectID: parseInt(projectId),
                fg_idh: item.Material,
                plant: item.Plant,
                component_id: item.Component,
                unique: item.Exclusive === 'N' ? false : true,
                material_type: oMatType.length > 0 ? oMatType[0].mtart : null,
                component_buom: item.Unit
            };
        });

        if (error92 && error93) {
            oJobStatus = {
                projectID: projectId,
                jobStatus: "Error",
                error: `Failed to fetch data from both 92 and 93. Please check application logs`
            };
        } else if (error92) {
            oJobStatus = {
                projectID: projectId,
                jobStatus: "Partial Completion",
                error: `Failed to fetch data from system 92.Please check application logs`
            };
        } else if (error93) {
            oJobStatus = {
                projectID: projectId,
                jobStatus: "Partial Completion",
                error: `Failed to fetch data from system 93.Please check application logs`
            };
        } else {
            oJobStatus = {
                projectID: projectId,
                jobStatus: "Completed",
                error: null
            };
        }
    } else {
        oJobStatus = {
            projectID: projectId,
            jobStatus: "Completed",
            error: "No Components found"
        };
    }

    const { CompUsage, CompUsageJobInfo } = cds.entities("ppe.cm.md");

    await UPSERT(oJobStatus).into(CompUsageJobInfo);

    if (aNewEntries.length > 0)
        await UPSERT(aNewEntries).into(CompUsage);

    cds.log("jobcompletion").info("====BOM component exclusive determination Job Completed====");
}
async function statusChangeWithOneYearJobOn(req, _) {
    cds.spawn(null, async (tx) => {
        await statusChangeWithOneYearJobAfter();
    });
    req.res.status(202);
    return `Job accepted with job id: ${req.headers["x-sap-job-id"]}`;
}
async function statusChangeWithOneYearJobAfter() {
    //a3549a6e-fd81-4b82-8caa-c19c93b431b8 :cancel status for plant and idh table
    //1c290c86-d4ee-44e0-98df-87de0a09c945:Y5 status for plant and idh as stock consumed
    //c5e9ac07-609b-4e0c-838c-26a586b47960 :Y6 status for plant and idh as  Phase out completed

    //dae19016-c2da-47f4-9813-692f4b8d94d7 :cancel status for Project Header
    //dc18e443-c22b-4a0f-9b95-9ce796daffb9 :phase out execution of Header after just submmit
    //d9c4e3c7-6a15-4a92-a50a-27473a4e99ae :phase out completed of Header after just cross from dc18e443-c22b-4a0f-9b95-9ce796daffb9 phase out execution
    //dba70db3-2b4b-41d1-9b56-a09a635ca91d :Y6 status for Project Header as  Closed (previously (Phase-Out Completed)


    const { ProjectHeaders, ProjectIDHs, ProjectIDHPlants, ProjectIDHSalesArea } = cds.entities('ppe.cm.pd');
    const { MatPlants } = cds.entities('ppe.cm.md');
    const { projectPlantSalesArea } = cds.entities("ComplexityManagement");

    const submittedStatusResult = await SELECT.from(ProjectHeaders).columns('projectID', 'uuid', 'modifiedAt', 'projectStatus_uuid').
        where({
            projectStatus_uuid: {
                "in": ["dc18e443-c22b-4a0f-9b95-9ce796daffb9", "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae"]
            },
            phaseOutScenario_id: {
                "in": ["Scenario01", "Scenario02"]
            }

        });
    //const submittedStatusResult = await SELECT.from(ProjectHeaders).columns('projectID', 'uuid', 'modifiedAt', 'projectStatus_uuid').where({ projectStatus_uuid: "dc18e443-c22b-4a0f-9b95-9ce796daffb9",uuid:'60d05d43-4fdfdfa8-4c7b-baa6-07d3ce53238c'});
    //console.log("hi"+submittedStatusResult.length);
    if (submittedStatusResult.length == 0) {
        return "";
    }
    //For new status  phase put completed
    // const projectIdY5withCancel = await cds.run(`SELECT A.UUID as PROJUUID FROM PPE_CM_PD_PROJECTHEADERS A Left JOIN PPE_CM_PD_PROJECTIDHPLANTS B ON A.UUID = B.L_EV_UUID
    //     where A.PROJECTSTATUS_UUID !='d9c4e3c7-6a15-4a92-a50a-27473a4e99ae' GROUP BY A.UUID 
    //     HAVING COUNT(CASE WHEN B.PHASEOUTSTATUS_UUID = '1c290c86-d4ee-44e0-98df-87de0a09c945' OR
    //      B.PHASEOUTSTATUS_UUID = 'a3549a6e-fd81-4b82-8caa-c19c93b431b8' THEN 1 END) = COUNT(*)`)
    // const projectIdOnlyCancel =  await cds.run(`SELECT A.UUID as PROJUUID FROM PPE_CM_PD_PROJECTHEADERS A Left JOIN PPE_CM_PD_PROJECTIDHPLANTS B ON A.UUID = B.L_EV_UUID
    //     where A.PROJECTSTATUS_UUID !='d9c4e3c7-6a15-4a92-a50a-27473a4e99ae' GROUP BY A.UUID 
    //     HAVING COUNT(CASE WHEN B.PHASEOUTSTATUS_UUID = 'a3549a6e-fd81-4b82-8caa-c19c93b431b8' THEN 1 END) = COUNT(*)`)
/* Start this will set the project status to pahse out commpleted  for plant status Y5* or Y5 + cancel*/
    //this belwo query is fetting if plnt status is y5 along with any of the plant cancel 
   const projectIdY5withCancel = await SELECT.from(`projectPlantStatusAllView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusPlantY:'1c290c86-d4ee-44e0-98df-87de0a09c945',statusPlantCancel:'a3549a6e-fd81-4b82-8caa-c19c93b431b8')`);
  // only one status  like Y5,Y6 or Cancel of plant
   const projectIdOnlyCancel = await SELECT.from(`projectPlantStatusView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusPlant:'a3549a6e-fd81-4b82-8caa-c19c93b431b8')`);
    let  projectIdY5 =  projectIdY5withCancel.filter(item => !new Set(projectIdOnlyCancel.map(item => item.PROJUUID)).has(item.PROJUUID)) 
    if (projectIdY5.length > 0) {
        await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae" }).where({
            uuid: {
                "in": projectIdY5?.map(item => item.PROJUUID)
            }
        });
    }
  /* End this will set the project status to pahse out commpleted  for plant status Y5*/      
   
  /* Start  this will set the project status to pahse out commpleted  for plant status Y5* or Y5 + Y6*/
   const projectIdY5withY6 = await SELECT.from(`projectPlantStatusAllView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusPlantY:'1c290c86-d4ee-44e0-98df-87de0a09c945',statusPlantCancel:'c5e9ac07-609b-4e0c-838c-26a586b47960')`);
   const projectIdOnlyY6 = await SELECT.from(`projectPlantStatusView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusPlant:'c5e9ac07-609b-4e0c-838c-26a586b47960')`);
    let  projectIdY5alsoY6 =  projectIdY5withY6.filter(item => !new Set(projectIdOnlyY6.map(item => item.PROJUUID)).has(item.PROJUUID)) 
    if (projectIdY5alsoY6.length > 0) {
        await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae" }).where({
            uuid: {
                "in": projectIdY5alsoY6?.map(item => item.PROJUUID)
            }
        });
    }
  /* End this will set the project status to pahse out commpleted  for plant status Y5* or Y5 + Y6*/ 
    
    /* Start make the plnt and idh region to Y6  if Y5 status crosss one year*/   
    const idhResult = await SELECT.from('projectidhY5').columns('UUID', 'L_EV_UUID', 'PHASEOUTSTATUS_UUID', 'PHASEOUTSCENARIO', 'MATERIAL');
    const idhPlantsResults = await SELECT.from('projectPlantidhY5').columns('UUID', 'L_EV_UUID', 'PHASEOUTSTATUS_UUID', 'PLANT', 'MATERIAL');

    if (idhResult.length > 0) {
        await UPDATE(ProjectIDHs).data({ phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960" }).where({
            uuid: {
                "in": idhResult?.map(item => item.UUID)
            }
        });
    }
    if (idhPlantsResults.length > 0) {


        let data92 = ``, data93 = ``, flag92 = false, flag93 = false;


        for await (const data of idhPlantsResults) {
            // collect data for batch call
            // determine source system
            let aSourceSystem = await SELECT.from(MatPlants).columns(`source_system`).where({
                matnr: data.MATERIAL,
                werks: data.PLANT
            });
            //to  find the projectID for backend:
            let projectheader = submittedStatusResult.filter(item => item.uuid === data.L_EV_UUID);
            // determine fasttrack
            let isFasttrack = false;
            let aIdhResultScenario = idhResult.filter(item => item.MATERIAL === data.MATERIAL && item.L_EV_UUID === data.L_EV_UUID);
            if (aIdhResultScenario.length > 0 && aIdhResultScenario[0].PHASEOUTSCENARIO === "Fasttrack") {
                isFasttrack = true;
            }
            if (aSourceSystem.length > 0) {

                if (aSourceSystem[0].source_system === "92") {
                    data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST marc(Material='${data.MATERIAL}',Plant='${data.PLANT}')/SAP__self.chg_status_plant HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_plant": "Y6", "is_fasttrack": ${isFasttrack}, "project_id": "${projectheader[0].projectID}"}\r\n\r\n\r\n`;
                    flag92 = true;
                } else {
                    data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST marc(Material='${data.MATERIAL}',Plant='${data.PLANT}')/SAP__self.chg_status_plant HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_plant": "Y6", "is_fasttrack": ${isFasttrack}, "project_id": "${projectheader[0].projectID}"}\r\n\r\n\r\n`;
                    flag93 = true;
                }
            }

        }
        // Trigger odata via batch if necessary
        data92 = data92 + `--batch--`;
        data93 = data93 + `--batch--`;

        const aPromises = [];

        if (flag92) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const matApi = await cds.connect.to("Materials");
                try {
                    const response = await matApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data92
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        if (flag93) {
            // connect to odata
            aPromises.push(new Promise(async (resolve, reject) => {
                const matApi = await cds.connect.to("APAC_Materials");
                try {
                    const response = await matApi.send({
                        method: 'POST',
                        path: '/$batch',
                        headers: {
                            'Content-Type': 'multipart/mixed;boundary=batch'
                        },
                        data: data93
                    });
                    resolve(response);
                } catch (error) {
                    reject(error);
                }
            }));
        }

        await Promise.allSettled(aPromises).then(async (aResponses) => {
        });
        await UPDATE(ProjectIDHPlants).data({ phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960", plantYSTATUS: "Y6" }).where({
            uuid: {
                "in": idhPlantsResults?.map(item => item.UUID)
            }
        });
        //update sales area
        await UPDATE(ProjectIDHSalesArea).with(
            {
                salesyStatus: "Y6"
            }
        ).where
            ({
                l_ev_uuid: {
                    "in": idhPlantsResults?.map(item => item.UUID)
                }
            });
    
    }
    /* End make the plnt and idh region to Y6  if Y5 status crosss one year*/  


   /*. Start  this block is updating the project to closed  if project is not closed  wiht the condition that their plant is Y6 or Y6 +Cancel  and then  */
   const projectIdntCpmtAndCanel = await SELECT.from(`projectPlantStatusAllView(statusProject:'dba70db3-2b4b-41d1-9b56-a09a635ca91d',statusPlantY:'c5e9ac07-609b-4e0c-838c-26a586b47960',statusPlantCancel:'a3549a6e-fd81-4b82-8caa-c19c93b431b8')`);
   const projectIdCancel = await SELECT.from(`projectPlantStatusView(statusProject:'dae19016-c2da-47f4-9813-692f4b8d94d7',statusPlant:'a3549a6e-fd81-4b82-8caa-c19c93b431b8')`);
   let  projectIdComplete =  projectIdntCpmtAndCanel.filter(item => !new Set(projectIdOnlyCancel.map(item => item.PROJUUID)).has(item.PROJUUID)) 
   cds.log("jobcompletion").info(projectIdComplete.length)
   if (projectIdComplete.length > 0) {
        await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "dba70db3-2b4b-41d1-9b56-a09a635ca91d" }).where({
            uuid: {
                "in": projectIdComplete?.map(item => item.PROJUUID)
            }
        });
    }
    /*. End this block is updating the project to closed  if project is not closed  wiht the condition that their plant is Y6 or Y6 +Cancel  and then  */
    /*. Start  this below is updating if all the plant for corrspning project is cacnel */
    if (projectIdCancel.length > 0) {
        await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "dae19016-c2da-47f4-9813-692f4b8d94d7" }).where({
            uuid: {
                "in": projectIdCancel?.map(item => item.PROJUUID)
            }
        });
    }
    // calculating for sales area scenario 03 for only scenario 3
    const submittedStatusResultScenario03 = await SELECT.from(ProjectHeaders).columns('projectID', 'uuid', 'modifiedAt', 'projectStatus_uuid').
        where({
            projectStatus_uuid: {
                "in": ["dc18e443-c22b-4a0f-9b95-9ce796daffb9", "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae"]
            },
            phaseOutScenario_id: {
                "in": ["Scenario03"]
            }

        });
    // if length is greater then 0 for scenario 03 then only it will go inside and check all the logic and calculate and update
    if (submittedStatusResultScenario03.length > 0) {
        // const salesData = await SELECT.from(projectPlantSalesArea).where({
        //     projectUUID: {
        //         "in": submittedStatusResultScenario03?.map(item => item.uuid)
        //     }
        // });

        // from this view we are calculating or finding which project does not have phase-out completed of header and  idh has stocked consumed y5  
        const projectIdhY5Scenari03 = await SELECT.from(`projectIDHStatusAllView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusIDHY5:'1c290c86-d4ee-44e0-98df-87de0a09c945')`);

        if (projectIdhY5Scenari03.length > 0) {
            await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae" }).where({
                uuid: {
                    "in": projectIdhY5Scenari03?.map(item => item.PROJUUID)
                }
            });
        }


        /* Start  this will set the project status to pahse out commpleted  for plant status Y5* or Y5 + Y6*/
        const projectIdhY5withY6 = await SELECT.from(`projectIDHStatusView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusIDHY5:'1c290c86-d4ee-44e0-98df-87de0a09c945',ststusIDHY6:'c5e9ac07-609b-4e0c-838c-26a586b47960')`);
        const projectIdhOnlyY6 = await SELECT.from(`projectIDHStatusAllView(statusProject:'d9c4e3c7-6a15-4a92-a50a-27473a4e99ae',statusIDHY5:'c5e9ac07-609b-4e0c-838c-26a586b47960')`);
        let projectIdhY5alsoY6 = projectIdhY5withY6.filter(item => !new Set(projectIdhOnlyY6.map(item => item.PROJUUID)).has(item.PROJUUID))
        if (projectIdhY5alsoY6.length > 0) {
            await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae" }).where({
                uuid: {
                    "in": projectIdhY5alsoY6?.map(item => item.PROJUUID)
                }
            });
        }
        // from this view we are calculating idh which modified date is grater than 365 days for those IDH  we are updating ProjectIDh table with phase out completed
        const idhResultScenario03 = await SELECT.from('projectidhY5').columns('UUID', 'L_EV_UUID', 'PHASEOUTSTATUS_UUID', 'PHASEOUTSCENARIO', 'MATERIAL');
        if (idhResultScenario03.length > 0) {
            await UPDATE(ProjectIDHs).data({ phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960" }).where({
                uuid: {
                    "in": idhResultScenario03?.map(item => item.UUID)
                }
            });
        }
        // we have created 1 more view to calculate or find which sales area already in stocked consymed y5 and it is more than 365 days to update in phase out completed and status in y6
        const projectResultSalesScenario03 = await SELECT.from('projectidhSalesY5').columns('UUID', 'PHASEOUTSTATUS_UUID');
        if (projectResultSalesScenario03.length > 0) {
            let idhPlantSalesAreas = await SELECT.from(projectPlantSalesArea).columns('uuid','material','salesOrg','distChanel','sourceSystem','projectID').where({
                uuid: {
                    "in": projectResultSalesScenario03?.map(item => item.UUID)
                }
            });
             cds.log("jobcompletion").info("============Started: Backend status has been changed y6 for Sales Area=======");   

            let data92 = ``, data93 = ``, flag92 = false, flag93 = false, aFinalResponse = [];
            let isFasttrack = true;
            let yStatus = "Y6";
            let projectId = '';

            for await (let idhPlantSalesArea of idhPlantSalesAreas) {
                if (idhPlantSalesArea.sourceSystem === "92") {
                    data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectId}"}\r\n\r\n\r\n`;
                    flag92 = true;
                }
                else {
                    data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST mvke(Material='${idhPlantSalesArea.material}',Vkorg='${idhPlantSalesArea.salesOrg}',Vtweg='${idhPlantSalesArea.distChanel}')/SAP__self.chg_status_sa HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{"status_sa": "${yStatus}", "is_fasttrack": ${isFasttrack}, "project_id": "${idhPlantSalesArea.projectId}"}\r\n\r\n\r\n`;
                    flag93 = true;
                }
            }

            data92 = data92 + `--batch--`;
            data93 = data93 + `--batch--`;

            const aPromisesSales = [];

            if (flag92) {
                // connect to odata
                aPromisesSales.push(new Promise(async (resolve, reject) => {
                    const matApis = await cds.connect.to("Materials");
                    try {
                        let sStatusUpdateResult = await matApis.send({
                            method: 'POST',
                            path: '/$batch',
                            headers: {
                                'Content-Type': 'multipart/mixed;boundary=batch'
                            },
                            data: data92
                        });
                        resolve(sStatusUpdateResult);
                    } catch (error) {
                        reject(error);
                    }
                }));
            }

            if (flag93) {
                // connect to odata
                aPromisesSales.push(new Promise(async (resolve, reject) => {
                    const matApis = await cds.connect.to("APAC_Materials");
                    try {
                        let sStatusUpdateResult = await matApis.send({
                            method: 'POST',
                            path: '/$batch',
                            headers: {
                                'Content-Type': 'multipart/mixed;boundary=batch'
                            },
                            data: data93
                        });
                        resolve(sStatusUpdateResult);
                    } catch (error) {
                        reject(error);
                    }
                }));
            }

            await Promise.allSettled(aPromisesSales).then(async (aResponses) => {
                cds.log("jobcompletion").info("============Completed: Backend status has been changed y6 for Sales Area=======");   

            });
            //update sales area
            await UPDATE(ProjectIDHSalesArea).with(
                {
                    salesyStatus: "Y6",
                    phaseOutStatus_uuid: "c5e9ac07-609b-4e0c-838c-26a586b47960"
                }
            ).where
                ({
                    uuid: {
                        "in": projectResultSalesScenario03?.map(item => item.UUID)
                    }
                });

        }
        // here from this view we are calculating or finding all the idh for project which is already in y6 so we are calculating and updating header table to closed
        // And in scenario 03 we do not have any cancel so we are checking only y6 status and on the basis of this we are updating
        const projectCompletedScenari03 = await SELECT.from(`projectIDHStatusAllView(statusProject:'dba70db3-2b4b-41d1-9b56-a09a635ca91d',statusIDHY5:'c5e9ac07-609b-4e0c-838c-26a586b47960')`);
        if (projectCompletedScenari03.length > 0) {
            await UPDATE(ProjectHeaders).data({ projectStatus_uuid: "dba70db3-2b4b-41d1-9b56-a09a635ca91d" }).where({
                uuid: {
                    "in": projectCompletedScenari03?.map(item => item.PROJUUID)
                }
            });
        }

    }
     /*. End this below is updating if all the plant for corrspning project is cacnel */
    cds.log("jobcompletion").info("====Status Job change based on the  last modified date has been Completed====");   
   }

async function statusHdiUpdateAfterManuallyChangeInSapJobOn(req, _) {
    cds.spawn(null, async (tx) => {
        await statusHdiUpdateAfterManuallyChangeInSapJobAfter(req);
    });
    req.res.status(202);
    return `Job accepted with job id: ${req.headers["x-sap-job-id"]}`;
}
async function statusHdiUpdateAfterManuallyChangeInSapJobAfter(req) {

    const { ProjectHeaders, ProjectIDHPlants, ProjectIDHSalesArea } = cds.entities('ppe.cm.pd')
    const ApoService = await cds.connect.to('ApoService');

    // 1. Read data from X92
    const matApiX92 = await cds.connect.to("Materials");
    let aStatusToUpdateX92 = await matApiX92.get(`/status_for_hdi_upd?`);

    // 2. Read data from X93
    const matApiX93 = await cds.connect.to("APAC_Materials");
    let aStatusToUpdateX93 = await matApiX93.get(`/status_for_hdi_upd?`);

    // 3. Update HDI for all data
    for (let statusToUpdateX92 of aStatusToUpdateX92) {
        if (statusToUpdateX92.Service === 'CHG_STATUS_PLANT') {

            // Update plant
            await UPDATE(ProjectIDHPlants).data({
                plantYSTATUS: statusToUpdateX92.StatusPlant,
                pValidFrom: statusToUpdateX92.ValidFrom
            }).where({
                material: statusToUpdateX92.Matnr,
                plant: statusToUpdateX92.Plant
            });

            if (statusToUpdateX92.StatusPlant == `Y5`) {

                await updateStatusCluster2Obs( statusToUpdateX92.Matnr, statusToUpdateX92.Plant );
            }
        }
        else if (statusToUpdateX92.Service === 'CHG_STATUS_SALES_AREA') {

            let idhProjectUuid = await SELECT.one.from(ProjectHeaders).columns(`uuid`).where({ projectID: statusToUpdateX92.ProjectId });

            let idhPlantUuid = await SELECT.from(ProjectIDHPlants).columns(`uuid`).where({
                l_ev_uuid: idhProjectUuid.uuid,
                material: statusToUpdateX92.Matnr,
                phaseOutNEEDED: `Yes`
            });
        
            let aIdhPlantUuids = idhPlantUuid.map(idhPlant => idhPlant.uuid);
        
            let idhPlantSalesAreas = await SELECT.one.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`).where({
                l_ev_uuid: {
                    in: aIdhPlantUuids
                },
                salesOrg: statusToUpdateX92.Vkorg,
                distChanel: statusToUpdateX92.Vtweg
            });

            //update sales area
            await UPDATE(ProjectIDHSalesArea).with({
                salesyStatus: statusToUpdateX92.StatusSa,
                yStatusValidfrom: statusToUpdateX92.ValidFrom
            }).where({
                uuid: idhPlantSalesAreas.uuid
            }); 
        } 
            
    }

    for (let statusToUpdateX93 of aStatusToUpdateX93) {
        if (statusToUpdateX93.Service === 'CHG_STATUS_PLANT') {

            // Update plant
            await UPDATE(ProjectIDHPlants).data({
                plantYSTATUS: statusToUpdateX93.StatusPlant,
                pValidFrom: statusToUpdateX93.ValidFrom
            }).where({
                material: statusToUpdateX93.Matnr,
                plant: statusToUpdateX93.Plant
            });

            if (statusToUpdateX93.StatusPlant == `Y5`) {
                await updateStatusCluster2Obs( statusToUpdateX93.Matnr, statusToUpdateX93.Plant );
            }
        }
        else if (statusToUpdateX93.Service === 'CHG_STATUS_SALES_AREA') {
            let idhProjectUuid = await SELECT.one.from(ProjectHeaders).columns(`uuid`).where({ projectID: statusToUpdateX93.ProjectId });

            let idhPlantUuid = await SELECT.from(ProjectIDHPlants).columns(`uuid`).where({
                l_ev_uuid: idhProjectUuid.uuid,
                material: statusToUpdateX93.Matnr,
                phaseOutNEEDED: `Yes`
            });
        
            let aIdhPlantUuids = idhPlantUuid.map(idhPlant => idhPlant.uuid);
        
            let idhPlantSalesAreas = await SELECT.one.from(ProjectIDHSalesArea).columns(`uuid`, `salesOrg`, `distChanel`).where({
                l_ev_uuid: {
                    in: aIdhPlantUuids
                },
                salesOrg: statusToUpdateX93.Vkorg,
                distChanel: statusToUpdateX93.Vtweg
            });

            //update sales area
            await UPDATE(ProjectIDHSalesArea).with({
                salesyStatus: statusToUpdateX93.StatusSa,
                yStatusValidfrom: statusToUpdateX93.ValidFrom
            }).where({
                uuid: idhPlantSalesAreas.uuid
            }); 
        }
    }

    // 4. Set HDI-update to done via Odata
    let data92 = ``, data93 = ``, flag92 = false, flag93 = false;

    for await (let statusToUpdateX92 of aStatusToUpdateX92) {
        data92 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST status_for_hdi_upd(DbKey=${statusToUpdateX92.DbKey})/SAP__self.set_elog_hdi_upd HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{}\r\n\r\n\r\n`;
        flag92 = true;
    }
    for await (let statusToUpdateX93 of aStatusToUpdateX93) {
        data93 += `--batch\r\nContent-Type: application/http\r\nContent-Transfer-Encoding: binary\r\n\r\nPOST status_for_hdi_upd(DbKey=${statusToUpdateX93.DbKey})/SAP__self.set_elog_hdi_upd HTTP/1.1\r\nContent-Type: application/json\r\n\r\n{}\r\n\r\n\r\n`;
        flag93 = true;
    }
    // Trigger odata via batch if necessary
    data92 = data92 + `--batch--`;
    data93 = data93 + `--batch--`;

    const aPromises = [];

    if (flag92) {
        // connect to odata
        aPromises.push(new Promise(async (resolve, reject) => {
            try {
                const response = await matApiX92.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data92
                });
                resolve(response);
            } catch (error) {
                reject(error);
            }
        }));
    }

    if (flag93) {
        // connect to odata
        aPromises.push(new Promise(async (resolve, reject) => {
            try {
                const response = await matApiX93.send({
                    method: 'POST',
                    path: '/$batch',
                    headers: {
                        'Content-Type': 'multipart/mixed;boundary=batch'
                    },
                    data: data93
                });
                resolve(response);
            } catch (error) {
                reject(error);
            }
        }));
    }

    await Promise.allSettled(aPromises).then(async (aResponses) => { });

    cds.log("jobcompletion").info("====Job status update in HDI after manually changed status in SAP (material and sales area) has been Completed====");
}
async function updateAccountingSBUForProjectIDH(req, _) {
    cds.spawn(null, async (tx) => {
        await updateAccountingSBUForProjectIDHAfter();
    });
    req.res.status(202);
    return `Job accepted with job id: ${req.headers["x-sap-job-id"]}`;
}

async function updateAccountingSBUForProjectIDHAfter() {
    const { ProjectIDHs } = cds.entities('ppe.cm.pd');
    const { FGMatCls } = cds.entities('ppe.cm.md');
    const accountingSBUBlankData = await SELECT.from(ProjectIDHs).where({ accountingSBU: null });
    if(accountingSBUBlankData.length == 0){
        retrun;
    }
    var uniqueMaterialRecords = accountingSBUBlankData.filter((item, index, self) => {
        return (
            index ===
            self.findIndex(
                (data) => data.material === item.material
            )
        );
    });
    cds.log("jobprogress").info(accountingSBUBlankData.length);
    var uniqueMaterialRecordsWithActualMaterial = uniqueMaterialRecords.map((item) => item['material'].replace(/^0+/, ""));
    var AccountsbuResults = await SELECT.columns(['matnr', 'leading_sbu_sbi', 'yidh_leading_sbu']).from(FGMatCls).where({ matnr: { "in": uniqueMaterialRecordsWithActualMaterial?.map(item => item) } });
    for await (let item of uniqueMaterialRecords) {
        let item_material = item.material.replace(/^0+/, "");
        let filterMaterialRecords = AccountsbuResults.filter(material => material.matnr === item_material);
        if(filterMaterialRecords[0]!= undefined)
            {
        let forUpdateValueAccSBU = filterMaterialRecords[0].leading_sbu_sbi || filterMaterialRecords[0].yidh_leading_sbu;
        //cds.log("jobprogress_Value").info(forUpdateValueAccSBU.length);
        if (forUpdateValueAccSBU.length > 0) {
            await
                UPDATE(ProjectIDHs)
                    .data({ accountingSBU: forUpdateValueAccSBU })
                    .where({ material: item.material });
        }
     }
    }
    cds.log("jobcompletion").info("====Job has been Completed for AccountSBU update====");
}

async function updateStatusCluster2Obs(material, plant) {

    return "Success"; // no longer necessary

    const { ProjectIDHPlants, ProjectIDHs } = cds.entities('ppe.cm.pd');

    let regionScope = '';

    let aProjectUuid = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`, `regionScope`).where({
        material: material,
        plant: plant,
        phaseOutNEEDED: `Yes`,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectUuid.length <= 0) {
        return "Failed";
    }
    // determine regionScope
    regionScope = aProjectUuid[0].regionScope;

    // check fasttrack
    let aProjectIdhScenario = await SELECT.from(ProjectIDHs).columns(`phaseOutScenario`).where({
        l_ev_uuid: aProjectUuid[0].l_ev_uuid,
        regionScope: regionScope,
        material: material
    });

    if (aProjectIdhScenario.length > 0 && aProjectIdhScenario[0].phaseOutScenario === "Fasttrack")
        return "Success";
    else
        reasonCode = "RC2";

    // Check if all material plants of region are in status Y5
    let aProjectIdhPlants = await SELECT.from(ProjectIDHPlants).columns(`l_ev_uuid`, `plant`, `plantYSTATUS`).where({
        material: material,
        regionScope: regionScope,
        phaseOutNEEDED: `Yes`,
        phaseOutStatus_uuid: { 'not in': ['a3549a6e-fd81-4b82-8caa-c19c93b431b8'] }
    });

    if (aProjectIdhPlants.some(entry => entry.plantYSTATUS !== 'Y5')) {
        // Not all plants in status Y5
        return "Success";
    }

    // Update cluster OBS in APO
    const apoApi = await cds.connect.to("ApoDp");
    let sStatusUpdateResult = await apoApi.send({
        method: 'POST',
        path: `/EncCluster`,
        data: {
            Material: material,
            Region: regionScope,
            Cluster: `OBS`,
            ReasonCode: reasonCode
        }
    });

    return "Success";
}