sap.ui.define([
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/m/MessageBox",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/json/JSONModel",
    "sap/ui/comp/smarttable/SmartTable",
    "sap/ui/model/Sorter"
], function (Fragment, Filter, MessageBox, ODataModel, JSONModel, SmartTable, Sorter) {

    return {
        onInit: function () {
            var oView = this.getView();
            var oTreeTable = oView.byId("supplyplanner::sap.suite.ui.generic.template.ListReport.view.ListReport::SupplyPlanItems--TreeTable");

            if (oTreeTable) {
                // Event listener for when rows are updated (initial load)
                oTreeTable.attachEvent("rowsUpdated", this._updateRowColors.bind(this));

                // Event listener for expand/collapse events
                oTreeTable.attachEvent("expand", this._updateRowColors.bind(this));  // Update color on expand
                oTreeTable.attachEvent("collapse", this._updateRowColors.bind(this)); // Update color on collapse
            }
        },
        _updateRowColors: function () {
            var oTreeTable = this.getView().byId("supplyplanner::sap.suite.ui.generic.template.ListReport.view.ListReport::SupplyPlanItems--TreeTable");
            if (oTreeTable) {
                var aRows = oTreeTable.getRows(); // Get all rows (visible and hidden)

                // Loop through each row to check the hierarchy level and apply colors
                aRows.forEach(function (oRow) {
                    var oContext = oRow.getBindingContext();

                    // Always reset colors before applying new color logic
                    oRow.removeStyleClass("parentRowColor");

                    if (oContext) {
                        var iHierarchyLevel = oContext.getProperty("hierarchyLevel");

                        // Apply CSS class for parent rows (hierarchy level 0)
                        if (iHierarchyLevel === 0) { // Parent row
                            oRow.addStyleClass("parentRowColor");
                        }
                    }
                });
            }
        },

        onBeforeRebindTableExtension: function (oEvent) {
            oEvent.getSource().getTable().setEnableColumnFreeze(true);
            oEvent.getSource().getTable().setFixedColumnCount(3);

            let oBindingParams = oEvent.getParameters().bindingParams;
            oBindingParams.parameters.select = oBindingParams.parameters.select + ',sourceSystem,regionScope,activeSalesOrg,bomExists,compDetails,material,projectUuid,projectDescription,phaseOutDate,confDatePerRegion,futureY4Date,invCoverageDays,mrpController,plantYStatus,pValidFrom,sourcePlant,hierarchyLevel,buom,totalStockValue,totalSaleableInvVal,dysfuncStockValue';

        },
        onActiveSalesOrgLinkPress: async function (oEvent) {
            let material = oEvent.getSource().getBindingContext().getObject("material");
            let plant = oEvent.getSource().getBindingContext().getObject("regionOrPlant");
            let hLevel = oEvent.getSource().getBindingContext().getObject("hierarchyLevel");
            let oComponent = oEvent.getSource();
            oComponent.setBusy(true);

            if (!this._oSADialog) {
                this._oSADialog = await Fragment.load({
                    id: "activesalesorgs",
                    name: "supplyplanner.ext.fragments.ActiveSalesOrgs",
                    controller: this
                }).then(function (oDialog) {
                    oEvent.getSource().getParent().addDependent(oDialog);
                    return oDialog;
                }.bind(this));
            }

            if (hLevel === 1) {

                const filters = [
                    new Filter({
                        path: 'matnr',
                        operator: 'EQ',
                        value1: material
                    }),
                    new Filter({
                        path: 'dwerk',
                        operator: 'EQ',
                        value1: plant
                    })
                ];

                const combinedFilter = new Filter({
                    filters: filters,
                    and: true
                });

                if (combinedFilter) {
                    this._oSADialog.getContent()[0].getBinding("items").filter(new Filter(combinedFilter));
                }

            } else {
                this._oSADialog.getContent()[0].getBinding("items").filter(new Filter({
                    path: 'matnr',
                    operator: 'EQ',
                    value1: material
                }));
            }

            let that = this;
            this._oSADialog.getContent()[0].getModel().attachEventOnce("batchRequestCompleted", null, () => {
                oComponent.setBusy(false);
                that._oSADialog.open();
            }, this);
        },

        onBomCompParentsPress: async function (oEvent) {
            let component = oEvent.getSource().getBindingContext().getObject("Component");
            let plant = oEvent.getSource().getBindingContext().getObject("Plant");
            let oComponent = oEvent.getSource().getParent();
            oComponent.setBusy(true);

            if (!this._oBCPDialog) {
                this._oBCPDialog = await Fragment.load({
                    id: "BomCompParents",
                    name: "supplyplanner.ext.fragments.BomCompParentDetails",
                    controller: this
                }).then(function (oDialog) {
                    oEvent.getSource().getParent().addDependent(oDialog);
                    return oDialog;
                }.bind(this));
            }
            const filters = [
                new Filter({
                    path: 'Material',
                    operator: 'EQ',
                    value1: component
                }),
                new Filter({
                    path: 'Plant',
                    operator: 'EQ',
                    value1: plant
                })
            ];

            const combinedFilter = new Filter({
                filters: filters,
                and: true
            });

            // if (combinedFilter) {
            //     this._oBCPDialog.getContent()[0].getBinding("items").filter(new Filter(combinedFilter));
            // }

            // Define sorters for grouping by BillOfMaterial and BomAlter
            const groupByBillOfMaterial = new Sorter({
                path: "BillOfMaterial",
                group: true // Enable grouping
            });

            const groupByBomAlter = new Sorter({
                path: "BomAlter",
                group: true // Enable grouping
            });

            // Apply filters and sorters to the table binding
            const oTable = this._oBCPDialog.getContent()[0];
            const oBinding = oTable.getBinding("items");

            if (combinedFilter) {
                oBinding.filter(combinedFilter);
            }

            // Apply the sorters for grouping
            oBinding.sort([groupByBillOfMaterial, groupByBomAlter]);

            let that = this;
            this._oBCPDialog.getContent()[0].getModel().attachEventOnce("batchRequestCompleted", null, () => {
                oComponent.setBusy(false);
                that._oBCPDialog.open();
            }, this);
        },

        onCompDetailsPress: async function (oEvent) {

            let material = oEvent.getSource().getBindingContext().getObject("material");
            let plant = oEvent.getSource().getBindingContext().getObject("regionOrPlant");
            let projectID = oEvent.getSource().getBindingContext().getObject("projectID");
            let oComponent = oEvent.getSource();
            oComponent.setBusy(true);

            let oView = oEvent.getSource().getParent();

            // Create the Dialog and Load the Fragment with Promises
            if (!this._oDialog) {
                this._oDialog = await Fragment.load({
                    id: oView.getId(),
                    name: "supplyplanner.ext.fragments.BomCompDetails",
                    controller: this
                })
                    .then(async (oDialog) => {
                        oView.addDependent(oDialog);
                        return oDialog;
                    })
                    .catch((error) => {
                        MessageBox.error("Error loading dialog fragment:", error);
                    });
            }

            const filters = [
                new Filter({
                    path: 'Material',
                    operator: 'EQ',
                    value1: material
                }),
                new Filter({
                    path: 'Plant',
                    operator: 'EQ',
                    value1: plant
                })
            ];

            const combinedFilter = new Filter({
                filters: filters,
                and: true
            });

            let oBomTreeTable = this._oDialog.getContent()[0];
            if (oBomTreeTable) {
                oBomTreeTable.attachEvent("rowsUpdated", this._updateBomTreeRowColors.bind(this));
                oBomTreeTable.attachEvent("expand", this._updateBomTreeRowColors.bind(this));  // Update color on expand
                oBomTreeTable.attachEvent("collapse", this._updateBomTreeRowColors.bind(this)); // Update color on collapse                
            }

            this._oDialog.getContent()[0].bindAggregation("rows", {
                path: '/BomTree',
                filters: combinedFilter,
                parameters: {
                    countMode: 'Inline',
                    treeAnnotationProperties: {
                        hierarchyLevelFor: 'Level',
                        hierarchyNodeFor: 'NodeId',
                        hierarchyParentNodeFor: 'ParentNodeId',
                        hierarchyDrillStateFor: 'Drillstate'
                    }
                }
            });

            const oModel = this._oDialog.getContent()[0].getModel();
            if (oModel) {
                oModel.setHeaders({
                    projectID: projectID
                });
            }

            let that = this;
            this._oDialog.getContent()[0].getModel().attachEventOnce("batchRequestCompleted", null, () => {
                oComponent.setBusy(false);
                that._oDialog.open();
            }, this);
        },
        _updateBomTreeRowColors: function () {
            let oTreeTable = this._oDialog.getContent()[0];
            if (oTreeTable) {
                var aRows = oTreeTable.getRows(); // Get all rows (visible and hidden)

                // Loop through each row to check the hierarchy level and apply colors
                aRows.forEach(function (oRow) {
                    var oContext = oRow.getBindingContext();

                    // Always reset colors before applying new color logic
                    oRow.removeStyleClass("parentBomTreeRowColor");

                    if (oContext) {
                        var iHierarchyLevel = oContext.getProperty("Level");

                        // Apply CSS class for parent rows (hierarchy level 0)
                        if (iHierarchyLevel === 0) { // Parent row
                            oRow.addStyleClass("parentBomTreeRowColor");
                        }
                    }
                });
            }
        },
        onBomTreeDialogAfterOpen: function (oEvent) {
            // Get the Tree Table inside the Dialog
            let oTreeTable = this._oDialog.getContent()[0];
            if (oTreeTable) {
                oTreeTable.expandToLevel(3);
            }
        },
        onToggleFullScreen: function (oEvent) {
            let oDialog = this._oDialog;
            let bIsFullScreen = oDialog.hasStyleClass("fullScreen");
            let oTreeTable = this._oDialog.getContent()[0];

            if (bIsFullScreen) {
                // Exit full-screen mode
                oDialog.removeStyleClass("fullScreen");
                oDialog.setProperty("draggable", true);
                oDialog.setProperty("resizable", true);
                oEvent.getSource().setIcon("sap-icon://full-screen");

                oTreeTable.setVisibleRowCount(10); // Adjust to your original value
            } else {
                // Enter full-screen mode
                oDialog.addStyleClass("fullScreen");
                oDialog.setProperty("draggable", false);
                oDialog.setProperty("resizable", false);
                oEvent.getSource().setIcon("sap-icon://exit-full-screen");

                var iRowCount = oTreeTable.getBinding("rows").getLength();
                oTreeTable.setVisibleRowCount(iRowCount);
            }
        },
        onClosePress: function (oEvent) {
            // oEvent.getSource().getParent().getContent()[0].getModel().detachBatchRequestCompleted(this.onBomParentDialogOpen, this);
            oEvent.getSource().getParent().close();
        },
        onPressSpecificSearch: function () {
            
            const view = this.getView();
            this._sDialog = null;
            if (!this._sDialog) {
              sap.ui.core.Fragment.load({
                name: "supplyplanner.ext.fragments.IdhSalesProjectMat",
                controller: this
              }).then(function (oDialog) {
                view.addDependent(oDialog);
                oDialog.open();
                this._sDialog = oDialog;
              }.bind(this));
            } else {
              this._sDialog.open();
            }
          },
      
          onCloseIdhSalesDialog : function () {
            this._sDialog.close();
            this._sDialog.destroy();
          },
          onAfterDialogClose : function(){
            this._sDialog.destroy();
          },
          onAfterOpenDialog : function(){
                const oSmartFilterBar = sap.ui.getCore().byId("idSalesProjFb");

                if (oSmartFilterBar) {
                    oSmartFilterBar.setFilterData({
                        phaseOutNEEDED : "Yes"
                    });
                    oSmartFilterBar.search();
                }
          },
          onRowSelection : function(e){
            let nIndex = e.getSource().getSelectedIndex();
            let oObject = sap.ui.getCore().byId("customScopeTable").getContextByIndex(nIndex).getObject();
            let {projectID} = oObject;
           
            let oSmartFilterBar = this.getView().byId("listReportFilter");
            if (oSmartFilterBar) {
                    oSmartFilterBar.setFilterData({projectID : projectID});      
            }
            this.onCloseIdhSalesDialog();
            
          }
    };
});