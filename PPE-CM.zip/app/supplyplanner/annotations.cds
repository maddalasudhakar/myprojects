using SupplyPlannerSummaryService as service from '../../srv/sm-supply-planner';

annotate service.SupplyPlanItems with @(

    Capabilities.FilterRestrictions: {
        $Type : 'Capabilities.FilterRestrictionsType',
        RequiredProperties: [
            projectID
        ],
        FilterExpressionRestrictions: [
            {
                $Type : 'Capabilities.FilterExpressionRestrictionType',
                AllowedExpressions : 'SingleValue',
                Property : 'projectID',
            },
        ],
        NonFilterableProperties: ['makeToStrategy', 'scTag', 'regionOrPlant', 'materialText', 'lbeL16FG', 'lbeL16RNP', 'lbeL16SFG', 'totalSaleableInvBUOM',
                                'totalSaleableInvVal', 'totalSaleableInvValEur', 'totalStockBUOM', 'totalStockValue', 'totalStockValueEur', 'dysfuncStockBUOM',
                                'dysfuncStockValue', 'dysfuncStockValueEur', 'invCoverageDays', 'additionalProd', 'forecastSNP', 'pValidFrom', 'activeSalesOrg',
                                'bomExists', 'buom', 'compDetails', 'confDatePerRegion', 'ctPlanner', 'ctPlannerEmail', 'drillState', 'fixedIssuesBUOM',
                                'fixedReceiptsBUOM', 'futureY4Date', 'mrpController', 'nodeId', 'parentId', 'phaseOutNEEDED', 'plantYStatus', 'projectDescription',
                                'projectUuid', 'sourcePlant', 'sourceSystem', 'localCurr']
    },

    UI.SelectionFields: [
        projectID,
        material,
        mrpControllerEmail
    ],
    
    UI.HeaderInfo: {
        $Type : 'UI.HeaderInfoType',
        TypeName : '{i18n>snpTypeName}',
        TypeNamePlural : '{i18n>snpTypeNamePlural}',
    },

    UI.LineItem: [  
        {
            $Type : 'UI.DataField',
            Value : material,
            Label: '{i18n>matnr}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : materialText,
            Label: '{i18n>maktx}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : regionOrPlant,
            Label: '{i18n>regionOrPlant}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : accSBU,
            Label: '{i18n>accountingSBU}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : makeToStrategy,
            Label: '{i18n>makeToStrategy}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : scTag,
            Label: '{i18n>scTag}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },        
        {
            $Type : 'UI.DataField',
            Value : mrpControllerEmail,
            Label: '{i18n>MRPControllerEmail}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : lbeL16FG,
            Label: '{i18n>LbeFG}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : lbeL16SFG,
            Label: '{i18n>LbeSFG}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : lbeL16RNP,
            Label: '{i18n>LbeRNP}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : buom,
            Label: '{i18n>buom}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },        
        {
            $Type : 'UI.DataField',
            Value : dysfuncStockBUOM,
            Label: '{i18n>DysFuncStockBUOM}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : dysfuncStockValueEur,
            Label: '{i18n>DysFuncStockValueEur}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : totalSaleableInvBUOM,
            Label: '{i18n>TotalSaleableInventoryBUOM}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },        
        {
            $Type : 'UI.DataField',
            Value : totalSaleableInvValEur,
            Label: '{i18n>TotalSaleableInventoryValEur}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },  
        {
            $Type : 'UI.DataField',
            Value : totalStockBUOM,
            Label: '{i18n>TotalStockBUOM}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },    
        {
            $Type : 'UI.DataField',
            Value : totalStockValueEur,
            Label: '{i18n>TotalStockValueEur}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },                   
        {
            $Type : 'UI.DataField',
            Value : fixedIssuesBUOM,
            Label: '{i18n>FixedIssues}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : fixedReceiptsBUOM,
            Label: '{i18n>FixedReceipts}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : forecastSNP,
            Label: '{i18n>ForeCastSNP}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : additionalProd,
            Label: '{i18n>additionalProd}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },        
        {
            $Type : 'UI.DataField',
            Value : invCoverageDays,
            Label: '{i18n>InvCoverage}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
        {
            $Type : 'UI.DataField',
            Value : subsMaterial,
            Label: '{i18n>Substitute}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        }                      
    ]
) {
    nodeId @sap.hierarchy.node.for @UI.Hidden;
    parentId @sap.hierarchy.parent.node.for @UI.Hidden;
    hierarchyLevel @sap.hierarchy.level.for @UI.Hidden;
    drillState @sap.hierarchy.drill.state.for @UI.Hidden;
    makeToStrategy @UI.HiddenFilter;
    regionOrPlant @UI.HiddenFilter;
    dysfuncStockBUOM @UI.HiddenFilter;
    dysfuncStockValue @UI.HiddenFilter @Common.Label: '{i18n>DysFuncStockValue}';
    dysfuncStockValueEur @UI.HiddenFilter;
    fixedIssuesBUOM @UI.HiddenFilter;
    fixedReceiptsBUOM @UI.HiddenFilter;
    forecastSNP @UI.HiddenFilter;
    invCoverageDays @UI.HiddenFilter;
    additionalProd @UI.HiddenFilter;
    lbeL16FG @UI.HiddenFilter;
    lbeL16RNP @UI.HiddenFilter;
    lbeL16SFG @UI.HiddenFilter;
    materialText @UI.HiddenFilter;
    mrpController @UI.HiddenFilter;
    plantYStatus @UI.HiddenFilter;
    pValidFrom @UI.HiddenFilter;
    projectDescription @UI.HiddenFilter;
    totalSaleableInvBUOM @UI.HiddenFilter;
    totalSaleableInvVal @UI.HiddenFilter @Common.Label: '{i18n>TotalSalableInventoryVal}';
    totalSaleableInvValEur @UI.HiddenFilter;
    totalStockBUOM @UI.HiddenFilter;
    totalStockValue @UI.HiddenFilter @Common.Label: '{i18n>TotalStockValue}';
    totalStockValueEur @UI.HiddenFilter @Common.Label: '{i18n>TotalStockValueEur}';
    sourceSystem @UI.Hidden;
    activeSalesOrg @UI.Hidden;
    bomExists @UI.Hidden;
    compDetails @UI.Hidden;
    projectUuid @UI.Hidden;
    ctPlanner @UI.Hidden;
    ctPlannerEmail @UI.Hidden;
    confDatePerRegion @Common.Label: '{i18n>ConfDatePerRegion}';
    ctPlanner @Common.Label: '{i18n>ctPlanner}';
    ctPlannerEmail @Common.Label: '{i18n>ctPlannerEmail}';
    futureY4Date @Common.Label: '{i18n>futureY4Date}' @UI.HiddenFilter;
    invCoverageDays @Common.Label: '{i18n>InvCoverage}';
    mrpController @Common.Label: '{i18n>MRPController}';
    phaseOutDate @Common.Label: '{i18n>phaseOutDate}';
    plantYStatus @Common.Label: '{i18n>plantYStatus}';
    projectDescription @Common.Label: '{i18n>projectDescription}';
    projectUuid @Common.Label: '{i18n>projectUUID}';
    pValidFrom @Common.Label: '{i18n>pValidFrom}';
    sourcePlant @Common.Label: '{i18n>sourcePlant}' @UI.HiddenFilter;
    scTag @UI.HiddenFilter;
    phaseOutNEEDED @UI.Hidden @UI.HiddenFilter;
    regionScope @UI.Hidden @UI.HiddenFilter;
    buom @UI.HiddenFilter @Common.Label: '{i18n>buom}';
    localCurr @UI.HiddenFilter @Common.Label: '{i18n>localCurr}';
    
    projectID @(
        Common: {
        Label    : '{i18n>ProjectID}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'ProjectHeaders',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: projectID,
                    ValueListProperty: 'projectID'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'projectDescription'
                }
            ]
        },
    });
    material           @(Common: {
        Label    : '{i18n>Material}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'MatValList',
            DistinctValuesSupported : true,
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: projectID,
                    ValueListProperty: 'projectID'
                },                
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: material,
                    ValueListProperty: 'material'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'materialText'
                }
            ]
        },
    });   
    mrpControllerEmail @(Common: {
        Label    : '{i18n>MRPControllerEmail}',
        ValueListWithFixedValues,
        ValueList: {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'MRPEmailValList',
            DistinctValuesSupported: true,
            Parameters    : [{
                $Type            : 'Common.ValueListParameterInOut',
                LocalDataProperty: mrpControllerEmail,
                ValueListProperty: 'mrpControllerEmail'
            }]
        },
    });
    subsMaterial @Common.Label : '{i18n>Substitute}'
};
// Combination of 4 tables Project Header/Project IDH/ Plant/Sales Area
annotate service.IdhProjectPlantSalesInfo with @(
    UI : {
            SelectionFields: [
                mrpController,
                material,
                subsMaterial,
                plant,
                phaseOutDate,
                plantYSTATUS,
                spConfirmedDate,
                futureY4Date,
                pValidFrom,
                regionScope,
                salesOrg,
                statusText,
                phaseOutNEEDED
            ],
        LineItem  : [
            {
                $Type                : 'UI.DataField',
                Value                : material,
                Label                : '{i18n>material}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : materialText,
                Label                : '{i18n>materialText}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : subsMaterial,
                Label                : '{i18n>subsMaterial}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : subsMaterialText,
                Label                : '{i18n>subsMaterialText}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutManager,
                Label                : '{i18n>phaseOutManager}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutManagerEmail,
                Label                : '{i18n>phaseOutManagerEmail}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutDate,
                Label                : '{i18n>phaseOutDate}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                 $Type                : 'UI.DataField',
                Value                : phaseOutScenario,
                Label                : '{i18n>phaseOutScenario}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutNEEDED,
                Label                : '{i18n>phaseOutNEEDED}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : statusText,
                Label                : '{i18n>ProjectStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : createdAt,
                Label                : '{i18n>createdAt}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : plant,
                Label                : '{i18n>plant}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : plantYSTATUS,
                Label                : '{i18n>plantYStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : openTransaction,
                Label                : '{i18n>openTransaction}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : mrpController,
                Label                : '{i18n>mrpController}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : mrpControllerEmail,
                Label                : '{i18n>mrpControllerEmail}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesOrg,
                Label                : '{i18n>salesOrg}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesOrgDescr,
                Label                : '{i18n>salesOrgDescr}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesCountryName,
                Label                : '{i18n>salesCountryName}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : distChanel,
                Label                : '{i18n>distChanel}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : sourceSystem,
                Label                : '{i18n>sourceSystem}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesCountry,
                Label                : '{i18n>salesCountry}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesyStatus,
                Label                : '{i18n>salesyStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : regionScope,
                Label                : '{i18n>regionScope}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : projectID,
                Label                : '{i18n>projectID}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : projectDescription,
                Label                : '{i18n>projectDescription}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
            $Type                : 'UI.DataField',
            Value                : lbeL16FG,
            Label                : '{i18n>lbeL16FG}',
            ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : lbeL16SFG,
                Label                : '{i18n>lbeL16SFG}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : lbeL16RNP,
                Label                : '{i18n>lbeL16RNP}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Value : accountingSBU,
                Label: '{i18n>accountingSBU}',
                ![@HTML5.CssDefaults]: {width: 'auto'}
            } 
        ]
}){
    mrpController @Common.Label: '{i18n>MRPController}';
    phaseOutDate @Common.Label: '{i18n>phaseOutDate}';
    plantYSTATUS @Common.Label: '{i18n>plantYStatus}';
    projectDescription @Common.Label: '{i18n>projectDescription}';
    material @Common.Label : '{i18n>material}';
    subsMaterial @Common.Label : '{i18n>subsMaterial}';
    plant @Common.Label : '{i18n>plant}';
    regionScope @Common.Label : '{i18n>regionScope}';
    salesOrg @Common.Label : '{i18n>salesOrg}';
    statusText @Common.Label : '{i18n>statusText}';
    phaseOutManager @Common.Label : '{i18n>phaseOutManager}';
    materialText @Common.Label : '{i18n>maktx}';
    phaseOutNEEDED @Common.Label : '{i18n>phaseOutNEEDED}';
    phaseOutScenario @Common.Label : '{i18n>phaseOutScenario}';
    salesyStatus @Common.Label : '{i18n>salesyStatus}';
    salesCountry @Common.Label : '{i18n>salesCountry}';
    sourceSystem @Common.Label : '{i18n>sourceSystem}';
    distChanel @Common.Label : '{i18n>distChanel}';
    subsMaterialText @Common.Label : '{i18n>subsMaterialText}';
    mrpControllerEmail @Common.Label : '{i18n>mrpControllerEmail}';
    salesCountryName @Common.Label : '{i18n>salesCountryName}';
    projectID @Common.Label : '{i18n>projectID}';
    salesOrgDescr @Common.Label : '{i18n>salesOrgDescr}';
    phaseOutManagerEmail @Common.Label : '{i18n>phaseOutManagerEmail}';
    futureY4Date @Common.Label : '{i18n>futureY4Date}';
    pValidFrom @Common.Label : '{i18n>pValidFrom}';
    spConfirmedDate @Common.Label : '{i18n>spConfirmedDate}';
    openTransaction @Common.Label : '{i18n>openTransaction}';
    lbeL16FG @Common.Label : '{i18n>lbeL16FG}';
    lbeL16SFG @Common.Label : '{i18n>lbeL16SFG}';
    lbeL16RNP @Common.Label : '{i18n>lbeL16RNP}';
    uuid @UI.Hidden;
    pValidFrom @UI.HiddenFilter;
    spConfirmedDate @UI.HiddenFilter;
    openTransaction @UI.HiddenFilter;
    futureY4Date @UI.HiddenFilter;

};

annotate service.BomTree {
    NodeId @sap.hierarchy.node.for @UI.Hidden @Core.Computed;
    ParentNodeId @sap.hierarchy.parent.node.for @UI.Hidden @Core.Computed;
    Level @sap.hierarchy.level.for @UI.Hidden @Core.Computed;
    Drillstate @sap.hierarchy.drill.state.for @UI.Hidden @Core.Computed;
}
