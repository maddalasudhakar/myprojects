## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Thu Oct 31 2024 13:44:33 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori-elements|
|**App Generator Version**<br>1.12.2|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>List Report Page V2|
|**Service Type**<br>File|
|**Metadata File**<br>sps-v2-metadata.xml
|**Module Name**<br>supplyplanner|
|**Application Title**<br>Supply Planner View|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon|
|**UI5 Version**<br>1.130.0|
|**Enable Code Assist Libraries**<br>True|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/eslint-plugin-fiori-custom for the eslint rules.|
|**Main Entity**<br>SupplyPlanItems|

## supplyplanner

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

- It is also possible to run the application using mock data that reflects the OData Service URL supplied during application generation.  In order to run the application with Mock Data, run the following from the generated app root folder:

```
    npm run start-mock
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


