using ProcessAutomation as service from '../../srv/process-automation';
annotate service.WorkFlowLogs with @(
    Capabilities.DeleteRestrictions.Deletable : false,
    Capabilities.UpdateRestrictions.Updatable : true,
    Capabilities.InsertRestrictions.Insertable : false,
    UI.SelectionFields : [
        status,
        processStep,
        taskUserEmaiId,
        projectID,
        material
    ],
    UI.FieldGroup #GeneratedGroup : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>processStep}',
                Value : processStep,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>status}',
                Value : status,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskUniqueId}',
                Value : taskUniqueId,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskUserEmaiId}',
                Value : taskUserEmaiId,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskModifiedEmail}',
                Value : taskModifiedEmail,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>projectID}',
                Value : projectID,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>material}',
                Value : material,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>modifiedAt}',
                Value : modifiedAt,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
        ],
    },
    UI.FieldGroup #FieldForMassEdit : {
        $Type : 'UI.FieldGroupType',
        Data : [
            {
               $Type : 'UI.DataField',
                Label : '{i18n>taskModifiedEmail}',
                Value : taskModifiedEmail 
            }
        ]
    },
    UI.Facets : [
        {
            $Type : 'UI.ReferenceFacet',
            ID : 'GeneratedFacet1',
            Label : 'General Information',
            Target : '@UI.FieldGroup#GeneratedGroup',
        },
    ],
    UI.LineItem : [
        {
                $Type : 'UI.DataField',
                Label : '{i18n>processStep}',
                Value : processStep,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>status}',
                Value : status,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskUniqueId}',
                Value : taskUniqueId,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskUserEmaiId}',
                Value : taskUserEmaiId,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>taskModifiedEmail}',
                Value : taskModifiedEmail,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>projectID}',
                Value : projectID,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>material}',
                Value : material,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>deletionFlag}',
                Value : deletionFlag,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>createdAt}',
                Value : createdAt,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>modifiedAt}',
                Value : modifiedAt,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>submittedBy}',
                Value : submittedBy,
                ![@HTML5.CssDefaults]: {width: '100%'}
            }
    ],
){
    IsActiveEntity  @UI.HiddenFilter;
    HasActiveEntity @UI.HiddenFilter;
    HasDraftEntity @UI.HiddenFilter;
    deletionFlag @Common.Label : '{i18n>deletionFlag}';
    modifiedAt @Common.Label : '{i18n>modifiedAt}';
    createdAt @Common.Label : '{i18n>createdAt}';
    material @Common.Label : '{i18n>material}';
    projectID @Common.Label : '{i18n>projectID}';
    taskModifiedEmail @Common.Label : '{i18n>taskModifiedEmail}';
    taskUserEmaiId @Common.Label : '{i18n>taskUserEmaiId}';
    taskModificationFlag @Common.Label : '{i18n>reassignStatus}';
    taskUniqueId @Common.Label : '{i18n>taskUniqueId}';
    submittedBy @Common.Label : '{i18n>submittedBy}';
    taskModificationFlag @UI.UpdateHidden: '{= ${user.role} !== "CMAdmin" }';
    submittedBy @Common.FieldControl : #Inapplicable;
    status    @(Common: {
        Label    : '{i18n>status}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'Statuses',
            Parameters     : [
                 {
                    $Type              : 'Common.ValueListParameterInOut',
                    LocalDataProperty  : status,
                    ValueListProperty  : 'text'
                }
            ]
        },
        ValueListWithFixedValues : true,
    });
    processStep    @(Common: {
        Label    : '{i18n>processStep}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'ProcessSteps',
            Parameters     : [
                 {
                    $Type              : 'Common.ValueListParameterInOut',
                    LocalDataProperty  : processStep,
                    ValueListProperty  : 'text'
                }
            ]
        },
        ValueListWithFixedValues : true,
    });
};

annotate service.WorkFlowLogs with @(
Capabilities: {
   NavigationRestrictions : {
       $Type : 'Capabilities.NavigationRestrictionsType',
       RestrictedProperties : [
           {
               $Type : 'Capabilities.NavigationPropertyRestriction',
               NavigationProperty : DraftAdministrativeData,
               FilterRestrictions : {
                   $Type : 'Capabilities.FilterRestrictionsType',
                   Filterable : false,
               },
           },
       ],
   },
});



annotate service.WorkFlowLogs with {
    deletionFlag @UI.SelectionField;
    deletionFlag @Common.FilterDefaultValue: '';
};

