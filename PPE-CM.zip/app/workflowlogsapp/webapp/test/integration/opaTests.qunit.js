sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'workflowlogsapp/test/integration/FirstJourney',
		'workflowlogsapp/test/integration/pages/WorkFlowLogsList',
		'workflowlogsapp/test/integration/pages/WorkFlowLogsObjectPage'
    ],
    function(JourneyRunner, opaJourney, WorkFlowLogsList, WorkFlowLogsObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('workflowlogsapp') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheWorkFlowLogsList: WorkFlowLogsList,
					onTheWorkFlowLogsObjectPage: WorkFlowLogsObjectPage
                }
            },
            opaJourney.run
        );
    }
);