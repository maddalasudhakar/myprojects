
sap.ui.define([
  "sap/ui/core/mvc/ControllerExtension",
  "sap/m/MessageToast",
  "sap/ui/model/json/JSONModel",
  "sap/ui/core/Core"
], function (ControllerExtension, MessageToast, JSONModel, Core) {
  "use strict";
  return ControllerExtension.extend("workflowlogsapp.ext.controller.ListReportExtension", {
    override: {
      onInit: async function () {
        const oView = this.base.getView();

      },
      onAfterRendering: async function () {
        const oJsonModel = new JSONModel();
        this.getView().setModel(oJsonModel, "LocalDataModel");
        const localModel = this.getView().getModel("LocalDataModel");

        const oModel = this.getView().getModel();
        const oContext = await oModel.bindContext("/getUserRole(...)");
        oContext.execute().then(() => {
          let result = oContext.getBoundContext().getObject("value");
          localModel.setProperty("/userRole", result);
          if (result === "validUser") {
            localModel.setProperty("/userRoleVisible", true);
          } else {
            localModel.setProperty("/userRoleVisible", false);
          }
        });
      },
      editFlow: {
        customMassEditSave: async function (aParameters) {

          // aParameters.aContexts: array containing the selected contexts for the mass edit
          // aParameters.oUpdateData: a dictionary containing the propertyPath and its updated value

          //Retrieve the control within the custom fragment
          const localModelRole = this.getView().getModel("LocalDataModel").getProperty("/userRole");
          const isSelected = Core.byId("customMassEdit--idAssignmentStatus").getSelectedKey();
          const oModel = this.getView().getModel();
          let SelectedUUID = aParameters.aContexts.map(elm => elm.sPath.split("uuid=")[1].split(",")[0]);

          let ModifiedObj = {
            uuid: SelectedUUID,
            taskModifiedEmail: aParameters.oUpdateData.taskModifiedEmail
          }
          //Execute the custom save action if selected
          if(isSelected || aParameters.oUpdateData.taskModifiedEmail){
            if (isSelected === "true") {
              ModifiedObj.taskModificationFlag = true;

            } else if(localModelRole !== "validUser") {
              ModifiedObj.taskModificationFlag = false;
            }else if(isSelected === "false"){
              ModifiedObj.taskModificationFlag = false;
            }
            const oContext = await oModel.bindContext("/customUpdateAction(...)");
            oContext.setParameter("params", ModifiedObj);
            oContext.execute().then(() => {
              oContext.getBoundContext().getObject("value");
             // oContext.refresh(true);
             MessageToast.show("Changes saved successfully");
              oModel.refresh(true);
              //Core.byId("workflowlogsapp::WorkFlowLogsList--fe::table::WorkFlowLogs::LineItem-innerTable").getBinding("items").refresh();
            });
          }
          
          //Do not execute the default mass-edit if custom save was selected
          return  isSelected;
        }
      }
    }

  });

});