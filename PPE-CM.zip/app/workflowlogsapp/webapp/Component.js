sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("workflowlogsapp.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);