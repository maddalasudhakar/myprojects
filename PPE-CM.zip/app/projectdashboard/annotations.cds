using ComplexityManagement from '../../srv/sm-project-dashboard';


annotate ComplexityManagement.ProjectHeaders with @(UI: {
    SelectionFields: [
        projectID,
        projectStatus_uuid,
        phaseOutDate,
        phaseOutManager,
        createdBy,
        createdAt
    ],
    LineItem       : [

        {
            $Type                : 'UI.DataField',
            Value                : projectDescription,
            Label                : '{i18n>projectDescription}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutManager,
            Label                : '{i18n>phaseOutManager}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutManagerEmail,
            Label                : '{i18n>phaseOutManagerEmail}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutDate,
            Label                : '{i18n>phaseOutDate}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : projectStatus.projectStatus,
            Label                : '{i18n>projectStatus}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        }

    ]
}) {
    createdFrom          @(Common: {Label: '{i18n>createdFrom}'});
    phaseOutDate         @(Common: {Label: '{i18n>phaseOutDate}'});
    projectStatus        @(Common: {
        Label     : '{i18n>phaseOutStatus}',
        Text: projectStatus.projectStatus,
        TextArrangement : #TextOnly,
        // ValueListWithFixedValues: true,
        ValueList : {
            $Type         : 'Common.ValueListType',
            CollectionPath: 'ProjectStatuses',
            Parameters    : [
                {
                    $Type            : 'Common.ValueListParameterOut',
                    LocalDataProperty: projectStatus_uuid,
                    ValueListProperty: 'uuid'
                },
                {
                    $Type : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'projectStatus'
                }
            ]
        },
    });
    uuid                 @UI.Hidden;
    phaseOutManager      @(Common: {Label: '{i18n>phaseOutManager}'})  ;
    createdBy      @(Common: {Label: '{i18n>createdBy}'})  ;
    phaseOutManagerEmail @(Common: {Label: '{i18n>phaseOutManagerEmail}'});
    projectDescription   @(Common: {Label: '{i18n>projectDescription}'});
    projectID            @(Common: {
        Label    : '{i18n>projectID}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'ProjectHeaders',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: projectID,
                    ValueListProperty: 'projectID'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'projectDescription'
                }
            ]
        },
    });
    phaseOutScenario @Common.Label : '{i18n>phaseOutScenario}';
}

annotate ComplexityManagement.ProjectIDHs with @(UI: {
    SelectionFields: [
        l_ev.projectID,
        material,
        regionScope
    ],
    LineItem       : [

        {
            $Type                : 'UI.DataField',
            Value                : material,
            Label                : '{i18n>material}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : materialText,
            Label                : '{i18n>materialText}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : subsMaterial,
            Label                : '{i18n>subsMaterial}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : subsMaterialText,
            Label                : '{i18n>subsMaterialText}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : regionScope,
            Label                : '{i18n>regionScope}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : accountingSBU,
            Label                : '{i18n>accountingSBU}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutNEEDED,
            Label                : '{i18n>phaseOutNEEDED}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutDate,
            Label                : '{i18n>phaseOutDate}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        },
        {
            $Type                : 'UI.DataField',
            Value                : phaseOutScenario,
            Label                : '{i18n>phaseOutScenario}',
            ![@HTML5.CssDefaults]: {width: '100%'}
        }


    ]
}) {
    uuid            @UI.Hidden;
    l_ev            @UI.Hidden;
    workflowFlag    @UI.Hidden;
    spConfirmedDate @UI.Hidden;
    phaseOutStatus  @UI.Hidden;

};

annotate ComplexityManagement.ProjectIDHPlants with @(UI: {LineItem: [

    {
        $Type                : 'UI.DataField',
        Value                : material,
        Label                : '{i18n>material}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : materialText,
        Label                : '{i18n>materialText}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : plant,
        Label                : '{i18n>plant}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : plantYSTATUS,
        Label                : '{i18n>plantYStatus}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : phaseOutNEEDED,
        Label                : '{i18n>phaseOutNEEDED}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : phaseOutDate,
        Label                : '{i18n>phaseOutDate}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    }


]}) {
    uuid                 @UI.Hidden;
    l_ev                 @UI.Hidden;
    regionScope          @UI.Hidden;
    pValidFrom           @UI.Hidden;
    workflowFlag         @UI.Hidden;
    openTransaction      @UI.Hidden;
    sourceSystem         @UI.Hidden;
    mrpController        @UI.Hidden;
    mrpControllerEmail   @UI.Hidden;
    ctPlanner            @UI.Hidden;
    ctPlannerEmail       @UI.Hidden;
    confDatePerRegion    @UI.Hidden;
    lbeL16FG             @UI.Hidden;
    lbeL16SFG            @UI.Hidden;
    lbeL16RNP            @UI.Hidden;
    projectIDHSalesAreas @UI.Hidden;
    phaseOutStatus       @UI.Hidden;
};

annotate ComplexityManagement.ProjectIDHSalesArea with @(UI: {LineItem: [

    {
        $Type                : 'UI.DataField',
        Value                : salesOrg,
        Label                : '{i18n>salesOrg}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : salesOrgDescr,
        Label                : '{i18n>salesOrgDescr}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : distChanel,
        Label                : '{i18n>distChanel}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : salesCountry,
        Label                : '{i18n>salesCountry}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    },
    {
        $Type                : 'UI.DataField',
        Value                : salesyStatus,
        Label                : '{i18n>salesyStatus}',
        ![@HTML5.CssDefaults]: {width: '100%'}
    }

]});

annotate ComplexityManagement.ProjectStatuses with @(
    UI.PresentationVariant #ProjectStatusHeader: {
    $Type    : 'UI.PresentationVariantType',
    SortOrder: [{
        $Type   : 'Common.SortOrderType',
        Property: code,
    }, ],
}, ) {
    uuid          @UI.HiddenFilter @Common.Label: '{i18n>phaseOutStatus}' @Common.Text: projectStatus @Common.TextArrangement: #TextOnly;
    code          @UI.Hidden;
    usedIn        @UI.Hidden @Common.FilterDefaultValue: 'header';
    statusText    @UI.Hidden;
    projectStatus @(Common: {Label: '{i18n>phaseOutStatus}'}) @UI.HiddenFilter
};

//  Combination of 4 tables Project Header/Project IDH/ Plant/Sales Area

annotate ComplexityManagement.IdhProjectPlantSalesInfo with @(
    UI : {
        SelectionFields: [
            phaseOutManager,
            material,
            materialText,
            subsMaterial,
            plant,
            regionScope,
            salesOrg,
            statusText,
            phaseOutNEEDED 
        ],
        LineItem  : [
            {
                $Type                : 'UI.DataField',
                Value                : material,
                Label                : '{i18n>material}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : materialText,
                Label                : '{i18n>maktx}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : subsMaterial,
                Label                : '{i18n>subsMaterial}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : subsMaterialText,
                Label                : '{i18n>subsMaterialText}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutNEEDED,
                Label                : '{i18n>phaseOutNEEDED}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : statusText,
                Label                : '{i18n>ProjectStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : createdAt,
                Label                : '{i18n>createdAt}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutManager,
                Label                : '{i18n>phaseOutManager}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutManagerEmail,
                Label                : '{i18n>phaseOutManagerEmail}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : phaseOutDate,
                Label                : '{i18n>phaseOutDate}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                 $Type                : 'UI.DataField',
                Value                : phaseOutScenario,
                Label                : '{i18n>phaseOutScenario}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : plant,
                Label                : '{i18n>plant}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : plantYSTATUS,
                Label                : '{i18n>plantYStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : openTransaction,
                Label                : '{i18n>openTransaction}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : mrpController,
                Label                : '{i18n>mrpController}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : mrpControllerEmail,
                Label                : '{i18n>mrpControllerEmail}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesOrg,
                Label                : '{i18n>salesOrg}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesOrgDescr,
                Label                : '{i18n>salesOrgDescr}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesCountryName,
                Label                : '{i18n>salesCountryName}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : distChanel,
                Label                : '{i18n>distChanel}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : sourceSystem,
                Label                : '{i18n>sourceSystem}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesCountry,
                Label                : '{i18n>salesCountry}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : salesyStatus,
                Label                : '{i18n>salesyStatus}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : regionScope,
                Label                : '{i18n>regionScope}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : projectID,
                Label                : '{i18n>projectID}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : projectDescription,
                Label                : '{i18n>projectDescription}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : lbeL16FG,
                Label                : '{i18n>lbeL16FG}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : lbeL16SFG,
                Label                : '{i18n>lbeL16SFG}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type                : 'UI.DataField',
                Value                : lbeL16RNP,
                Label                : '{i18n>lbeL16RNP}',
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Value : accountingSBU,
                Label: '{i18n>accountingSBU}',
                ![@HTML5.CssDefaults]: {width: 'auto'}
            } 
        ]
}){
    mrpController @Common.Label: '{i18n>MRPController}';
    phaseOutDate @Common.Label: '{i18n>phaseOutDate}';
    plantYSTATUS @Common.Label: '{i18n>plantYStatus}';
    projectDescription @Common.Label: '{i18n>projectDescription}';
    material @Common.Label : '{i18n>material}';
    subsMaterial @Common.Label : '{i18n>subsMaterial}';
    plant @Common.Label : '{i18n>plant}';
    regionScope @Common.Label : '{i18n>regionScope}';
    salesOrg @Common.Label : '{i18n>salesOrg}';
    statusText @Common.Label : '{i18n>statusText}';
    phaseOutManager @Common.Label : '{i18n>phaseOutManager}';
    materialText @Common.Label : '{i18n>maktx}';
    phaseOutNEEDED @Common.Label : '{i18n>phaseOutNEEDED}';
    phaseOutScenario @Common.Label : '{i18n>phaseOutScenario}';
    salesyStatus @Common.Label : '{i18n>salesyStatus}';
    salesCountry @Common.Label : '{i18n>salesCountry}';
    sourceSystem @Common.Label : '{i18n>sourceSystem}';
    distChanel @Common.Label : '{i18n>distChanel}';
    subsMaterialText @Common.Label : '{i18n>subsMaterialText}';
    mrpControllerEmail @Common.Label : '{i18n>mrpControllerEmail}';
    salesCountryName @Common.Label : '{i18n>salesCountryName}';
    projectID @Common.Label : '{i18n>projectID}';
    salesOrgDescr @Common.Label : '{i18n>salesOrgDescr}';
    phaseOutManagerEmail @Common.Label : '{i18n>phaseOutManagerEmail}';
    futureY4Date @Common.Label : '{i18n>futureY4Date}';
    pValidFrom @Common.Label : '{i18n>pValidFrom}';
    spConfirmedDate @Common.Label : '{i18n>spConfirmedDate}';
    openTransaction @Common.Label : '{i18n>openTransaction}';
    lbeL16FG @Common.Label : '{i18n>lbeL16FG}';
    lbeL16SFG @Common.Label : '{i18n>lbeL16SFG}';
    lbeL16RNP @Common.Label : '{i18n>lbeL16RNP}';
    uuid @UI.Hidden;
    pValidFrom @UI.HiddenFilter;
    spConfirmedDate @UI.HiddenFilter;
    openTransaction @UI.HiddenFilter;
    futureY4Date @UI.HiddenFilter;
};

