sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("projectdashboard.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  