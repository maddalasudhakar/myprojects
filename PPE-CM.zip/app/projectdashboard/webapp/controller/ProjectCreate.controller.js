jQuery.sap.require("projectdashboard/utils/lib/xlsx");
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    'sap/m/SearchField',
    'sap/ui/model/type/String',
    'sap/ui/table/Column',
    'sap/m/Column',
    'sap/m/Text',
    'sap/m/ColumnListItem',
    'sap/m/Label',
    'sap/ui/export/library',
    "sap/ui/core/routing/History",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    'sap/ui/model/FilterOperator',
    "projectdashboard/utils/Formatter",
    'sap/m/Token',
    'sap/ui/model/Filter'
],
    function (Controller, JSONModel, SearchField, TypeString, UIColumn, MColumn, Text, ColumnListItem, Label, exportLibrary, History, MessageToast, MessageBox, FilterOperator, Formatter, Token, Filter) {
        "use strict";
        var EdmType = exportLibrary.EdmType, oView;

        return Controller.extend("projectdashboard.controller.ProjectCreate", {

            Formatter: Formatter,

            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteProjectCreate").attachMatched(this._onRouteMatched, this);
                oView = this.getView();
                var oUserModel = new JSONModel();
                this.getOwnerComponent().setModel(oUserModel, "userInfo");
                if (sap.ushell.Container) {
                    this.getOwnerComponent().getModel("userInfo").setProperty("/useremail", sap.ushell.Container.getService("UserInfo").getEmail());
                    this.getOwnerComponent().getModel("userInfo").setProperty("/userfirstname", sap.ushell.Container.getService("UserInfo").getFirstName() + " " + sap.ushell.Container.getService("UserInfo").getLastName());
                } else {
                    this.getOwnerComponent().getModel("userInfo").setProperty("/useremail", "anonymus");
                    this.getOwnerComponent().getModel("userInfo").setProperty("/userfirstname", "anonymus");
                }
                var data = {
                    "minDate": new Date()
                }
                var jsonModel = new JSONModel(data);
                this.getView().setModel(jsonModel, "viewModel");
                this._oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },
            _onRouteMatched: async function (oEvent) {

                var oArgs, oView, that = this;
                oArgs = oEvent.getParameter("arguments");
                this.projectID = oArgs.uuid;
                this.scenario = oArgs.scenario;
                oView = this.getView();
                var oModel = this.getView().getModel();

                var jsonModel1 = new JSONModel(
                    {
                        "deleteButton" : []
                    }
                );
                this.getView().setModel(jsonModel1, "DeleteModel");
                let scenarioText = this.getOwnerComponent().getModel("i18n").getResourceBundle().getText(this.scenario);
                this.getOwnerComponent().getModel("LocalDataModel").setProperty("/scenario", this.scenario);
                if (this.projectID !== "0") {

                    var sEntitySetPath = "/ProjectHeaders('" + this.projectID + "')";
                    oModel.read(sEntitySetPath, {
                        urlParameters: {
                            "$expand": "projectIDHs,phaseOutScenario,projectIDHPlants/projectIDHSalesAreas"
                        },
                        success: function (oData, response) {
                            var idhSalesData;
                            if (that.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario03") {
                                oData.projectIDHPlants.results = oData.projectIDHPlants.results.map(plant => ({
                                    ...plant,
                                    projectIDHSalesAreas: plant.projectIDHSalesAreas.results.map(sales => ({
                                        ...sales,
                                        material: plant.material,
                                        plant: plant.plant,
                                        region: plant.regionScope
                                    }))
                                }));
                                idhSalesData = oData.projectIDHPlants.results.flatMap(obj => obj.projectIDHSalesAreas);
                            }else {
                                idhSalesData = oData.projectIDHPlants.results.flatMap(obj => obj.projectIDHSalesAreas.results);
                            }
                            var jsonModel = new JSONModel(
                                {
                                    "IDHRegion": oData.projectIDHs.results,
                                    "IDHPlant": oData.projectIDHPlants.results,
                                    "IDHSales" :  idhSalesData
                                }
                            );
                            that.getView().setModel(jsonModel, "IDHModel");
                            that.getView().getModel("IDHModel").refresh();
                            let oContext = oModel.createEntry("/ProjectHeaders", {
                                properties: {
                                    projectID: oData.projectID,
                                    projectDescription: oData.projectDescription,
                                    projectStatus: "Draft",
                                    phaseOutDate: oData.phaseOutDate,
                                    phaseOutManager: that.getOwnerComponent().getModel("userInfo").getData().userfirstname,
                                    phaseOutManagerEmail: that.getOwnerComponent().getModel("userInfo").getData().useremail,
                                    createdBy: oData.createdBy,
                                    createdAt: oData.createdAt,
                                    phaseOutScenario : scenarioText
                                }
                            });
                            that.getView().setBindingContext(oContext);
                            that.getView().byId("smartFormCr").setBindingContext(oContext);
                            that.getView().byId("ObjectPageLayoutCr").setBindingContext(oContext);

                        },
                        error: function (oError) {
                            // Handle errors
                            MessageToast.show(that._oBundle.getText("create_fetching_error"), oError);
                        }
                    });

                } else {
                    this.clearProjectDesc();
                    var oContext = oModel.createEntry("/ProjectHeaders", {
                        properties: {
                            projectID: "-",
                            projectDescription: "",
                            projectStatus_uuid: "21c74e08-b4d6-4632-89b8-f6f33bb6cdb8",
                            phaseOutDate: null,
                            phaseOutManager: this.getOwnerComponent().getModel("userInfo").getData().userfirstname,
                            phaseOutManagerEmail: this.getOwnerComponent().getModel("userInfo").getData().useremail,
                            phaseOutScenario : scenarioText
                        }
                    });
                    this.getView().setBindingContext(oContext);
                    this.getView().byId("smartFormCr").setBindingContext(oContext);
                    this.getView().byId("ObjectPageLayoutCr").setBindingContext(oContext);
                    var jsonModel = new JSONModel(
                        {
                            "IDHRegion": [],
                            "IDHPlant": [],
                            "IDHSales":[]
                        }
                    );
                    this.getView().setModel(jsonModel, "IDHModel");
                    this.getView().getModel("IDHModel").refresh();
                }
                var sDataPath = {
                    "lanes": [
                        {
                            "id": "0",
                            "icon": "sap-icon://task",
                            "label": "Draft",
                            "position": 0,
                            "state": [
                                {
                                    "state": "Positive",
                                    "value": 10
                                }
                            ]
                        }, {
                            "id": "1",
                            "icon": "sap-icon://task",
                            "label": "Submitted",
                            "position": 1,
                            "state": [
                                {
                                    "state": "Neutral",
                                    "value": 10
                                }
                            ]
                        }, {
                            "id": "2",
                            "icon": "sap-icon://task",
                            "label": "SBU Approval",
                            "position": 2,
                            "state": [
                                {
                                    "state": "Neutral",
                                    "value": 10
                                }
                            ]
                        }, {
                            "id": "3",
                            "icon": "sap-icon://task",
                            "label": "Phase-Out Execution",
                            "position": 3,
                            "state": [
                                {
                                    "state": "Neutral",
                                    "value": 10
                                }
                            ]
                        },
                        {
                            "id": "4",
                            "icon": "sap-icon://task",
                            "label": "Phase-Out Completed",
                            "position": 4,
                            "state": [
                                {
                                    "state": "Neutral",
                                    "value": 10
                                }
                            ]
                        },
                        {
                            "id": "5",
                            "icon": "sap-icon://task",
                            "label": "Closed",
                            "position": 5,
                            "state": [
                                {
                                    "state": "Neutral",
                                    "value": 10
                                }
                            ]
                        }
                    ]
                };
                this.oProcessFlow1 = oView.byId("processflow1");
                var oModelPf1 = new JSONModel(sDataPath);
                oView.setModel(oModelPf1, "viewModel");
            },
            onVHRequested: function () {
                var oTextTemplate = new Text({ text: { path: 'matnr' }, renderWhitespace: true });
                var aMaterials = this.getAllMaterials();
                this._oBasicSearchField = new SearchField({
                    search: function () {
                        this.oIDHDialog.getFilterBar().search();
                    }.bind(this)
                });

                this.oIDHDialog = this.loadFragment({
                    name: "projectdashboard.fragments.IDHValueHelpDialog"
                }).then(function (oIDHDialog) {
                    var oFilterBar = oIDHDialog.getFilterBar(), oColumnProductCode, oColumnProductName;
                    this.oIDHDialog = oIDHDialog;

                    this.getView().addDependent(oIDHDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oIDHDialog.setRangeKeyFields([{
                        label: "IDH",
                        key: "matnr",
                        type: "string",
                        typeInstance: new TypeString({}, {
                            maxLength: 18
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(this._oBasicSearchField);

                    // Re-map whitespaces
                    oFilterBar.determineFilterItemByName("matnr").getControl().setTextFormatter(this._inputTextFormatter);

                    // Set Tokens (pre-selected materials in IDHValueHelpDialog)
                    oIDHDialog.setTokens(this.createTokensForVH(aMaterials));

                    oIDHDialog.getTableAsync().then(function (oTable) {
                        oTable.setModel(this.oModel);

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            oColumnProductCode = new UIColumn({ label: new Label({ text: "IDH" }), template: oTextTemplate });
                            oColumnProductCode.data({
                                fieldName: "matnr"
                            });
                            oTable.addColumn(oColumnProductCode);

                            oColumnProductName = new UIColumn({ label: new Label({ text: "IDH Description" }), template: new Text({ wrapping: false, text: "{maktx}" }) });
                            oColumnProductName.data({
                                fieldName: "maktx"
                            });
                            oTable.addColumn(oColumnProductName);
                            oTable.bindAggregation("rows", {
                                // path: "/Mat1Classifs",
                                path: "/FGMatClsStd",
                                events: {
                                    dataReceived: function () {
                                        oIDHDialog.update();
                                    }
                                }
                            });
                        }

                        // For Mobile the default table is sap.m.Table
                        if (oTable.bindItems) {
                            oTable.addColumn(new MColumn({ header: new Label({ text: "IDH" }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: "IDH Description" }) }));
                            oTable.bindItems({
                                path: "/FGMatClsStd",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{matnr}" }), new Label({ text: "{maktx}" })]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oIDHDialog.update();
                                    }
                                }
                            });
                        }

                        oIDHDialog.update();
                    }.bind(this));
                    // oIDHDialog.setTokens(this._oWhiteSpacesInput.getTokens());
                    oIDHDialog.open();
                }.bind(this));
            },
            getAllMaterials: function () {
                var oTable = this.byId("myTable");
                var aItems = oTable.getItems();
                var aMaterials = [];

                aItems.forEach(function (oItem) {
                    var oContext = oItem.getBindingContext("IDHModel");
                    var sMaterial = oContext.getProperty("material");
                    aMaterials.push(sMaterial);
                });
                return aMaterials;
            },
            createTokensForVH: function (aMaterials) {
                var aTokens = [];
                aMaterials.forEach(function (sMaterial) {
                    var oToken = new Token({
                        key: sMaterial,
                        text: sMaterial
                    });
                    aTokens.push(oToken);
                });
                return aTokens;
            },
            onDeletePress: function (oEvent) {
                var oTable = this.byId("myTable");
                var oModel = this.getView().getModel("IDHModel");
                var oContext = oEvent.getSource().getBindingContext("IDHModel");
                var materialId = oContext.getProperty("material");
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                MessageBox.warning(
                    "Do you want to delete the following material: " + materialId + "?",
                    {
                        actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                        onClose: function (oAction) {
                            if (oAction === MessageBox.Action.OK) {
                                var oData = oModel.getData();
                                oData.IDHRegion = oData.IDHRegion.filter(function (item) {
                                    return item.material !== materialId;
                                });
                                oData.IDHPlant = oData.IDHPlant.filter(function (item){
                                    return item.material !== materialId;
                                })
                                oData.IDHSales = oData.IDHPlant.flatMap(obj => obj.projectIDHSalesAreas);
                                oModel.setData(oData);
                                oTable.removeSelections();
                                MessageToast.show("IDH: " + materialId + " deleted successfully");
                            }
                        }
                    }
                );

            },
            onVHSubRequested: function (oEvent) {
                this._sDataPathSub = oEvent.getSource().getBindingContext("IDHModel").sPath;
                // var oTextTemplate = new Text({ text: { path: 'matnr' }, renderWhitespace: true });
                this._oBasicSearchFieldSub = new SearchField({
                    search: function () {
                        this.oSubDialog.getFilterBar().search();
                    }.bind(this)
                });

                this.oSubDialog = this.loadFragment({
                    name: "projectdashboard.fragments.IDHSubsValueHelpDialog"
                }).then(function (oSubDialog) {
                    var oSubFilterBar = oSubDialog.getFilterBar(), oColumnProductCode, oColumnProductName;
                    this.oSubDialog = oSubDialog;

                    this.getView().addDependent(oSubDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oSubDialog.setRangeKeyFields([{
                        label: "IDH",
                        key: "matnr",
                        type: "string",
                        typeInstance: new TypeString({}, {
                            maxLength: 18
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oSubFilterBar.setFilterBarExpanded(false);
                    oSubFilterBar.setBasicSearch(this._oBasicSearchFieldSub);

                    // Re-map whitespaces
                    oSubFilterBar.determineFilterItemByName("matnr").getControl().setTextFormatter(this._inputTextFormatter);

                    oSubDialog.getTableAsync().then(function (oTable) {
                        oTable.setModel(this.oModel);

                        // For Desktop and tabled the default table is sap.ui.table.Table
                        if (oTable.bindRows) {
                            oColumnProductCode = new UIColumn({ label: new Label({ text: "IDH" }), template: new Text({ wrapping: false, text: "{matnr}"}) });
                            oColumnProductCode.data({
                                fieldName: "matnr"
                            });
                            oTable.addColumn(oColumnProductCode);

                            oColumnProductName = new UIColumn({ label: new Label({ text: "IDH Description" }), template: new Text({ wrapping: false, text: "{maktx}" }) });
                            oColumnProductName.data({
                                fieldName: "maktx"
                            });
                            oTable.addColumn(oColumnProductName);
                            oTable.bindAggregation("rows", {
                                // path: "/Mat1Classifs",
                                path: "/FGMatClsStd",
                                events: {
                                    dataReceived: function () {
                                        oSubDialog.update();
                                    }
                                }
                            });
                        }

                        // For Mobile the default table is sap.m.Table
                        if (oTable.bindItems) {
                            oTable.addColumn(new MColumn({ header: new Label({ text: "IDH" }) }));
                            oTable.addColumn(new MColumn({ header: new Label({ text: "IDH Description" }) }));
                            oTable.bindItems({
                                path: "/FGMatClsStd",
                                template: new ColumnListItem({
                                    cells: [new Label({ text: "{matnr}" }), new Label({ text: "{maktx}" })]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oSubDialog.update();
                                    }
                                }
                            });
                        }
                        oSubDialog.update();
                    }.bind(this));

                    oSubDialog.open();
                }.bind(this));
            },
            // onSubstituteChange: function (oEvent) {
            //     var oModel = this.getView().getModel("IDHModel");
            //     var sSubs = oEvent.getSource().getValue();
            //     var oBindingContext = oEvent.getSource().getBindingContext("IDHModel");

            //     if (!sSubs) {
            //         var sPath = oBindingContext.getPath();
            //         oModel.setProperty(sPath + "/subsMaterialText", "");
            //         oModel.refresh();
            //     }
            // },
            onResetPress: async function (oEvent) {
                var oModel = this.getView().getModel("IDHModel");
                oModel.setProperty(this._sDataPathSub + "/subsMaterial", "");
                oModel.setProperty(this._sDataPathSub + "/subsMaterialText", "");
                this.oSubDialog.close();
                this.oSubDialog.destroy();
            },
            onOkSubPress: async function (oEvent) {
                var that = this;
                var aTokens = oEvent.getParameter("tokens");
                const subs = aTokens[0].getKey();
                var substxt = aTokens[0].getProperty("text");
                substxt = substxt.replace(" (" + subs + ")", "");
                var oModel = this.getView().getModel("IDHModel");
                if ((oModel.getProperty(this._sDataPathSub + "/material")) !== subs) {
                    oModel.setProperty(this._sDataPathSub + "/subsMaterial", subs);
                    oModel.setProperty(this._sDataPathSub + "/subsMaterialText", substxt);
                } else {
                    MessageBox.error(that._oBundle.getText("create_subIDH_error"));

                }
                this.oSubDialog.close();
                this.oSubDialog.destroy();
            },
            onOkPress: async function (oEvent) {
                var oBusyDialog = this.byId("busyDialog");
                oBusyDialog.open();
                var aTokens = oEvent.getParameter("tokens");
                var oModel = this.getView().getModel();
                var that = this, aList = [], aPlant = [], aReg = [], aModel = [], Scenario = "";
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                aTokens.forEach(function (e) {
                    aList.push(e.getKey())
                });

                var mat = that.getView().getModel("IDHModel").getData().IDHRegion;
                mat = [...new Set(mat.map(item => item.material))];
                mat.forEach(function (i) {
                    aList.push(i)
                });

                // if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario02") {
                //     Scenario = "S2";
                // } else if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario03") {
                //     Scenario = "S3";
                // } else {
                //     Scenario = "S1";
                // }
                if(aList.length > 200){
                      MessageToast.show(that._oBundle.getText("ErrorUploadData"));
                      oBusyDialog.close();
                      return;
                }
                await oModel.callFunction("/getIDHDetails", {
                    method: "GET",
                    urlParameters: {
                        material: aList,
                        projectSec : this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario")
                    },
                    success: function (oData) {
                        oBusyDialog.close();
                        aModel.IDHRegion = oData.getIDHDetails.ProjectIDHs;
                        aModel.IDHPlant = oData.getIDHDetails.ProjectIDHPlants;
                        aModel.IDHSales =  aModel.IDHPlant.flatMap(obj => obj.projectIDHSalesAreas);
                        that.getView().getModel("IDHModel").setData(aModel);
                        that.getView().getModel("IDHModel").refresh();
                        if(oData.getIDHDetails.ProjectIDHs.length === 0 && oData.getIDHDetails.ProjectIDHPlants.length === 0){
                            MessageToast.show("No Active Plants without linked sales areas are found this material");
                        }
                        // that.addDeleteButtons();
                    },
                    error: function (oError) {
                        oBusyDialog.close();
                        if(oError.responseText)
                        {
                            MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                        }
                        else
                        {
                            MessageToast.show(that._oBundle.getText("create_OT_error"));
                        }
                        
                    }
                });
                this.oIDHDialog.close();
            },
            // addDeleteButtons: function() {
            //     var oTable = this.byId("myTable");
            //     var oItems = oTable.getItems();

            //     oItems.forEach(function(oItem) {
            //         var oDeleteButton = new sap.m.Button({
            //             icon: "sap-icon://delete",
            //             press: function(oEvent) {
            //                 this.onDeletePress(oEvent);
            //             }.bind(this)
            //         });
            //         var oCell = oItem.getCells()[0];
            //         oCell.addItem(oDeleteButton);
            //     });
            // },
            onCancelSubPress: function () {
                this.oSubDialog.close();
                this.oSubDialog.destroy();
            },
            onAfterSubClose: function () {
                this.oSubDialog.destroy();
            },
            onCancelPress: function () {
                this.oIDHDialog.close();
            },
            onAfterClose: function () {
                this.oIDHDialog.destroy();
            },
            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                        if (oControl.getValue()) {
                            aResult.push(new sap.ui.model.Filter({
                                path: oControl.getName(),
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        }

                        return aResult;
                    }, []);

                aFilters.push(new sap.ui.model.Filter({
                    filters: [
                        new sap.ui.model.Filter({ path: "matnr", operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false }),
                        new sap.ui.model.Filter({ path: "maktx", operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false })
                    ],
                    and: false
                }));
                this._filterTable(new sap.ui.model.Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            _filterTable: function (oFilter) {
                var oIDHDialog = this.oIDHDialog;

                oIDHDialog.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oIDHDialog.update();
                });
            },
            onFilterBarSearchSub: function (oEvent) {
                var sSearchQuery = this._oBasicSearchFieldSub.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                        if (oControl.getValue()) {
                            aResult.push(new sap.ui.model.Filter({
                                path: oControl.getName(),
                                operator: FilterOperator.Contains,
                                value1: oControl.getValue()
                            }));
                        }

                        return aResult;
                    }, []);

                aFilters.push(new sap.ui.model.Filter({
                    filters: [
                        new sap.ui.model.Filter({ path: "matnr", operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false }),
                        new sap.ui.model.Filter({ path: "maktx", operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false })
                    ],
                    and: false
                }));
                this._filterTableSub(new sap.ui.model.Filter({
                    filters: aFilters,
                    and: true
                }));
            },
            _filterTableSub: function (oFilter) {
                var oVHD = this.oSubDialog;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },
            onUpload: function () {
                //  var oView = this.getView();
                var that = this;
                if (!this._pIDHUpload) {
                    this._pIDHUpload = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.IDHUploadDialog",
                        controller: this
                    }).then(function (oDialog) {
                        oView.addDependent(oDialog);
                        return oDialog;
                    });
                }
                this._pIDHUpload.then(function (oDialog) {
                    oDialog.open();
                    that.getView().byId("fileUploader").setBusy(false);
                });
            },
            handleUploadComplete: function (oEvent) {
                var sResponse = oEvent.getParameter("response"),
                    aRegexResult = /\d{4}/.exec(sResponse),
                    iHttpStatusCode = aRegexResult && parseInt(aRegexResult[0]),
                    sMessage;

                if (sResponse) {
                    sMessage = iHttpStatusCode === 200 ? sResponse + " (Upload Success)" : sResponse + " (Upload Error)";
                    MessageToast.show(sMessage);
                }
                this.byId("fileUplaoder").clear();
                this.byId("fileUploader").setBusy(false);
            },
            handleUploadPress: async function () {
                this.getView().byId("fileUploader").setBusy(true);
                var that = this;
                let oFile = this.oFile;
                if (oFile == null || oFile == undefined) {
                    this.getView().byId("fileUploader").setBusy(false);
                    MessageBox.error(that._oBundle.getText("create_upload_error"));
                    return;
                }
                if (oFile && window.FileReader) {
                    var reader = new FileReader();

                    reader.onload = async (e) => {
                        var arrayBuffer = e.target.result;
                        var workbook = XLSX.read(arrayBuffer, { type: 'array' });

                        // Convert the first sheet data to JSON
                        var firstSheetName = workbook.SheetNames[0];
                        var worksheet = workbook.Sheets[firstSheetName];
                        var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

                        // Display or process the data

                        if(jsonData.length < 202){
                            await this.processExcelData(jsonData);
                        }else{
                            MessageToast.show(that._oBundle.getText("ErrorUploadData"));
                            this._pIDHUpload.then(function (oDialog) {
                                oDialog.close();
                            });
                        }
                       
                    };

                    reader.readAsArrayBuffer(oFile); // Read the file as an ArrayBuffer
                }
                this.oFile = null;
                // this.getView().byId("fileUploader").setBusy(false);
                this.getView().byId("fileUploader").clear();

            },
            onSelectFileUpload: function (oEvent) {
                var oFileUploader = oEvent.getSource();
                this.oFile = oFileUploader.oFileUpload.files[0]; // Get the file object
            },
            _excelDateToJSDate : function(serial) {
                const excelEpoch = Date.UTC(1900, 0, 1); // Jan 1, 1900
                const jsDate = new Date(excelEpoch + (serial - 2) * 24 * 60 * 60 * 1000);
                return jsDate;
            },
            processExcelData: async function (jsonData) {

                var oModel = this.getView().getModel();
                var that = this, aList = [], aSubs = [], aPlant = [], aphaseoutDate = [], aModel = [], aRegCollection = [], aSubMaterial = [];

                jsonData.forEach(function (e, index) {
                    if (index !== 0 && e[0] !== undefined) {
                        const paddedValueRegions = (e[0].toString().padStart(18, '0')).replace(/^0+/, '');
                        aList.push(paddedValueRegions);
                        if (e[1] !== undefined) {
                            const paddedValueSubs = e[1].toString().padStart(18, '0').replace(/^0+/, '');
                            aSubs[paddedValueRegions] = paddedValueSubs;
                            aSubMaterial.push(paddedValueSubs);
                        }
                        if (e[2] === 'x' || e[2] === 'X') {
                            const euVal = 'EU';
                            aRegCollection.push(`${paddedValueRegions}|${euVal}`);
                            
                        }
                        if (e[3] === 'x' || e[3] === 'X') {
                            const apacVal = 'APAC';
                            aRegCollection.push(`${paddedValueRegions}|${apacVal}`);
                        }
                        if (e[4] === 'x' || e[4] === 'X') {
                            const imeaVal = 'IMEA';
                            aRegCollection.push(`${paddedValueRegions}|${imeaVal}`);
                        }
                        if (e[5] === 'x' || e[5] === 'X') {
                            const latamVal = 'LA';
                            aRegCollection.push(`${paddedValueRegions}|${latamVal}`);
                        }
                        if (e[6] === 'x' || e[6] === 'X') {
                            const naVal = 'NA';
                            aRegCollection.push(`${paddedValueRegions}|${naVal}`);
                        }
                        if (e[7]) {
                            const datVal = that._excelDateToJSDate(e[7]);
                            aphaseoutDate[paddedValueRegions] = datVal;
                        }
                    }
                });
                let aMatList = decodeURIComponent(aList).split(",").filter((item) => item.trim() != '');
                let aSubMaterialTrim = aSubMaterial.filter((item) => item.trim() !== '');
                const aValidMatSubmat = await this.getMatSubstMatFun(aMatList, aSubMaterialTrim);
                const astdMaterial = aValidMatSubmat.getStdMaterial.aMaterial;
                const astdsubMaterial = aValidMatSubmat.getStdMaterial.aSubMaterial;
                await oModel.callFunction("/getIDHDetails", {
                    method: "GET",
                    urlParameters: {
                        material: astdMaterial,
                        projectSec : this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario")
                    },
                    success: function (oData) {
                        aModel.IDHRegion = oData.getIDHDetails.ProjectIDHs;
                        aModel.IDHPlant = oData.getIDHDetails.ProjectIDHPlants;
                        aModel.IDHSales =  aModel.IDHPlant.flatMap(obj => obj.projectIDHSalesAreas);
                        const materialRegionSet = new Set(aRegCollection);
                        const materialFilter =  aModel.IDHRegion.filter(obj =>
                            materialRegionSet.has(`${obj.material}|${obj.regionScope}`)
                        );  

                        const plantFilter =  aModel.IDHPlant.filter(obj =>
                            materialRegionSet.has(`${obj.material}|${obj.regionScope}`)
                        );
                       
                        aModel.IDHRegion =  materialFilter;
                        aModel.IDHPlant = plantFilter;
                        aModel.IDHRegion.forEach(function (element) {
                            var idh = element.material;
                            if(astdsubMaterial.length > 0){
                                if (aSubs[idh]) {
                                    let nIndex = astdsubMaterial.findIndex(item => item === aSubs[idh]);
                                    if(nIndex > -1) element.subsMaterial = aSubs[idh]; 
                                }
                            }
                           
                            if(aphaseoutDate[idh]){
                                let aDate = aphaseoutDate[idh];
                                if((new Date(aDate).getUTCFullYear() === new Date().getUTCFullYear() && new Date(aDate).getUTCMonth() === new Date().getUTCMonth() && new Date(aDate).getUTCDate() === new Date().getUTCDate()) || new Date(aDate) > new Date()){
                                    element.phaseOutDate = new Date(Date.UTC(
                                        aDate.getFullYear(),
                                        aDate.getMonth(),
                                        aDate.getDate()
                                    ));
                                }
                            }
                            return element;
                        });

                        aModel.IDHPlant.forEach((elem) => {
                            let idh = elem.material;
                            if(aphaseoutDate[idh]){
                                let aDate = aphaseoutDate[idh];
                                if((new Date(aDate).getUTCFullYear() === new Date().getUTCFullYear() && new Date(aDate).getUTCMonth() === new Date().getUTCMonth() && new Date(aDate).getUTCDate() === new Date().getUTCDate()) || new Date(aDate) > new Date()){
                                    elem.phaseOutDate = new Date(Date.UTC(
                                        aDate.getFullYear(),
                                        aDate.getMonth(),
                                        aDate.getDate()
                                    ));
                                }
                            }
                            return elem;
                        });
                        that.getView().getModel("IDHModel").setData(aModel);
                        that.getView().getModel("IDHModel").refresh();
                        that._pIDHUpload.then(function (oDialog) {
                            oDialog.close();
                            that.getView().byId("fileUploader").setBusy(false);
                        });
                    },
                    error: function (oError) {
                        if(oError.responseText)
                            {
                                MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                            }
                            else
                            {
                                MessageToast.show(that._oBundle.getText("create_OT_error"))
                            }
                            that._pIDHUpload.then((oDialog) => oDialog.close());
                    }
                });
            },
            getMatSubstMatFun: async function (aMatList, aSubMaterialTrim) {
                let that = this;
                return new Promise((resolve, reject) => {
                  this.getView().getModel().callFunction("/getStdMaterial", {
                    method : "POST",
                    urlParameters : {
                        material : aMatList,
                        subMaterial : aSubMaterialTrim
                    },
                    success: function(oData){
                        resolve(oData);
                    },
                    error: function (oError) {
                        if(oError.responseText)
                            {
                                MessageToast.show(JSON.parse(oError.responseText).error.message.value);
                            }
                            else
                            {
                                MessageToast.show(that._oBundle.getText("create_OT_error"))
                            }
                            that._pIDHUpload.then((oDialog) => oDialog.close());
                    }
                });
                }).catch((error) => {
                  console.log(error.message);
                });
            },
            handleUploadCancel: function () {
                this._pIDHUpload.then(function (oDialog) {
                    oDialog.close();
                });
            },
            onDownloadTemplate: function () {

                var styleHeader = {
                    font: {
                        name: "Calibri",
                        sz: 12,
                        bold: true,
                        color: { rgb: "FFFFFF" }
                    },
                    fill: { fgColor: { rgb: "C00000" } },
                    border: {
                        top: "thin",
                        bottom: "thin",
                        left: "thin",
                        right: "thin"
                    },
                    alignment: {
                        horizontal: "center",
                        wrapText: true
                    }

                };

                var styleHeader2 = {
                    font: {
                        name: "Calibri",
                        sz: 14,
                        bold: true,
                        color: { rgb: "FFFFFF" }
                    },
                    fill: { fgColor: { rgb: "C00000" } },
                    border: {
                        top: "thin",
                        bottom: "thin",
                        left: "thin",
                        right: "thin"
                    },
                    alignment: {
                        horizontal: "center",
                        wrapText: true
                    }

                };

                var styleNormal = {
                    font: {
                        name: "Calibri",
                        sz: 12,
                        bold: false
                    },
                    border: {
                        top: "thin",
                        bottom: "thin",
                        left: "thin",
                        right: "thin"
                    },
                    alignment: {
                        vertical: "center",
                        wrapText: true
                    }
                };

                var styleBold = {
                    font: {
                        name: "Calibri",
                        sz: 12,
                        color : { rgb: "C00000" },
                        bold: true
                    },
                    border: {
                        top: "thin",
                        bottom: "thin",
                        left: "thin",
                        right: "thin"
                    },
                    alignment: {
                        vertical: "center",
                        wrapText: true
                    }
                };
                let workBook = XLSX.utils.book_new();
                let dataRecipients = [
                    { col0: { s: styleHeader, v: "IDH Code" }, col1: { s: styleHeader, v: "Substitute IDH Code" }, col2: { s: styleHeader, v: "EU" }, col3: { s: styleHeader, v: "APAC" }, col4: { s: styleHeader, v: "IMEA" }, col5: { s: styleHeader, v: "LATAM" },col6: { s: styleHeader, v: "NA" }, col7: { s: styleHeader, v: "Phaseout Date", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: "", v: "" }},
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" },  col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "",  z: "YYYY-MM-DD"}, col8: { s: "", v: "" }, col9: { s: styleHeader2, v: "Instructions Area : Please complete this template as follows:" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleHeader2, v: "Column" }, col10: { s: styleHeader2, v: "Information to be entered" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "IDH Code" }, col10: { s: styleNormal, v: "Please enter the IDH.Note: Only valid IDH numbers and Material type should be 'STD' from SAP will be considered and the rest will be excluded.Please input valid IDH numbers only" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "IDH Code" }, col10: { s: styleNormal, v: "Please enter the IDH.Note: Only valid IDH numbers and Material type should be 'STD' from SAP will be considered and the rest will be excluded. Please input valid IDH numbers only" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "Substitute IDH Code" }, col10: { s: styleNormal, v: "Please enter the Substitute IDH if Available and Material type should be 'STD' " } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "EU" }, col10: { s: styleNormal, v: "Mark with an 'x' if you want to consider this region for phasing out" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "APAC" }, col10: { s: styleNormal, v: "Mark with an 'x' if you want to consider this region for phasing out" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "IMEA" }, col10: { s: styleNormal, v: "Mark with an 'x' if you want to consider this region for phasing out" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "LATAM" }, col10: { s: styleNormal, v: "Mark with an 'x' if you want to consider this region for phasing out" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleNormal, v: "NA" }, col10: { s: styleNormal, v: "Mark with an 'x' if you want to consider this region for phasing out" } },
                    { col0: { s: "", v: "" }, col1: { s: "", v: "" }, col2: { s: "", v: "" }, col3: { s: "", v: "" },  col4: { s: "", v: "" }, col5: { s: "", v: "" }, col6: { s: "", v: "" }, col7: { s: "", v: "", z: "YYYY-MM-DD" }, col8: { s: "", v: "" }, col9: { s: styleBold, v: "Phaseout Date" }, col10: { s: styleBold, v: "Enter the date in the format 'YYYY-MM-DD' (please ensure it�s ONLY entered and saved like this!!!)" } }
        
                ];
        
        
                let sheetIDH = XLSX.utils.json_to_sheet(dataRecipients, { skipHeader: true });
                sheetIDH['!cols'] = [{ wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 20 },{ wch: 20 }, { wch: 20 }, { wch: 80 }, { wch: 80 }];
                const merge = [
                    { s: { r: 1, c: 9 }, e: { r: 1, c: 10 } },
                    { s: { r: 3, c: 9 }, e: { r: 4, c: 9 } },
                    { s: { r: 3, c: 10 }, e: { r: 4, c: 10 } },
                    { s: { r: 4, c: 11 }, e: { r: 5, c: 11 } },
                    { s: { r: 4, c: 12 }, e: { r: 5, c: 12 } },
                ];
                sheetIDH["!merges"] = merge;

                const maxRows = 200;
                for (let i = 2; i <= maxRows + 1; i++) {
                    sheetIDH[`A${i}`] = { s: "", v: "" };
                    sheetIDH[`B${i}`] = { s: "", v: "" };
                    sheetIDH[`C${i}`] = { s: "", v: "" };
                    sheetIDH[`D${i}`] = { s: "", v: "" };
                    sheetIDH[`E${i}`] = { s: "", v: "" };
                    sheetIDH[`F${i}`] = { s: "", v: "" };
                    sheetIDH[`G${i}`] = { s: "", v: "" };
                    sheetIDH[`H${i}`] = {
                        s: "",  
                        v: "", 
                        z: "YYYY-MM-DD"
                    };
                }
                sheetIDH["!ref"] = `A1:K${maxRows + 1}`;
                
                XLSX.utils.book_append_sheet(workBook, sheetIDH, "Recipient Details");

                XLSX.writeFile(workBook, "Template for IDH Upload.xlsx");

            },
            clearProjectDesc: function () {
                var oView = this.getView();
                var oModel = this.getView().getModel();
                var oContext = oModel.createEntry("/ProjectHeaders", {
                    properties: {
                        projectDescription: " "
                    }
                });
                oView.setBindingContext(oContext);
                oView.byId("smartFormCr").setBindingContext(oContext);
                oView.byId("ObjectPageLayoutCr").setBindingContext(oContext);
            },
            onPressCancel: function () {
                this.clearProjectDesc();
                this.onNavback();
            },
            onPressSave: async function () {
                var oBusyDialog = this.byId("busyDialog");
                oBusyDialog.open();
                var that = this;
                var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                if(this.getView().getModel("IDHModel").getData().IDHRegion.length==0)
                    {
                        oBusyDialog.close();
                        MessageBox.error(that._oBundle.getText("create_Mat_error"));
                        return;
                    }
                const maxDate = this.getView().getModel("IDHModel").getData().IDHRegion.reduce((max, current) => {
                    return (current.phaseOutDate) > (max.phaseOutDate) ? current : max;
                });
                if (maxDate.phaseOutDate) {
                    maxDate.phaseOutDate = new Date(Date.UTC(
                        maxDate.phaseOutDate.getFullYear(),
                        maxDate.phaseOutDate.getMonth(),
                        maxDate.phaseOutDate.getDate()
                    ));
                }
                var idhPlants;
                if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario01") {
                var idhPlants = this.getView().getModel("IDHModel").getData().IDHPlant.map((idhPlant) => {
                    var region = this.getView().getModel("IDHModel").getData().IDHRegion.find((region) => {
                        return region.regionScope === idhPlant.regionScope && region.material === idhPlant.material;
                    });

                    if (region) {
                        if (region.phaseOutDate === "") {
                            idhPlant.phaseOutDate = null;
                        } else if (region.phaseOutDate) {
                            let parsedDate = new Date(region.phaseOutDate);
                            if (!isNaN(parsedDate.getTime())) {
                                idhPlant.phaseOutDate = parsedDate;
                            } else {
                                idhPlant.phaseOutDate = null;
                            }
                        }
                    }

                    return idhPlant;
                });
                } else if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario02") {
                    idhPlants = this.getView().getModel("IDHModel").getData().IDHPlant;
                }else if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario03") {
                    // idhPlants = this.getView().getModel("IDHModel").getData().IDHPlant;
                    var plantsDataForSales = this.getView().getModel("IDHModel").getData().IDHPlant;
                    const actualKeySalesData = plantsDataForSales.map(plant => ({
                       ...plant,
                       projectIDHSalesAreas:plant.projectIDHSalesAreas.map(({distChanel,phaseOutNEEDED,salesCountry,salesCountryName,salesOrg,salesOrgDescr,salesyStatus,sourceSystem,yStatusValidfrom,phaseOutStatus_uuid,openTransactionSales}) => ({distChanel,phaseOutNEEDED,salesCountry,salesCountryName,salesOrg,salesOrgDescr,salesyStatus,sourceSystem,yStatusValidfrom,phaseOutStatus_uuid,openTransactionSales})) 
                    }));
                  idhPlants = actualKeySalesData;
                }

                var oProjectHeader = {
                    projectDescription: this.getView().byId("idProjectDescription").getValue(),
                    phaseOutManager: this.getView().byId("idphaseoutManager").getValue(),
                    phaseOutManagerEmail: this.getOwnerComponent().getModel("userInfo").getData().useremail,
                    phaseOutDate: maxDate.phaseOutDate,
                    projectStatus_uuid: "21c74e08-b4d6-4632-89b8-f6f33bb6cdb8",
                    createdFrom: "BTP",
                    projectIDHs: this.getView().getModel("IDHModel").getData().IDHRegion,
                    projectIDHPlants: idhPlants,
                    phaseOutScenario_id : this.scenario
                };

                var oModel = this.getView().getModel();

                if (this.projectID === "0") {
                    oModel.create("/ProjectHeaders", oProjectHeader, {
                        success: function (oData, response) {
                            oBusyDialog.close();
                            MessageToast.show("Project created successfully!");
                            var uuid = oData.uuid;
                            var projectStatus = oData.projectStatus_uuid;
                            oRouter.navTo("RouteProjectIDHDetails", {
                                uuid: uuid,
                                projectStatus: projectStatus
                            }, true);
                        },
                        error: function (oError) {
                            oBusyDialog.close();
                            // console.log(oError);
                            MessageToast.show(that._oBundle.getText("create_project_error"));
                        }
                    });
                } else {
                    oModel.update("/ProjectHeaders('" + this.projectID + "')", oProjectHeader, {
                        success: function (oData, response) {
                            oBusyDialog.close();
                            MessageToast.show("Order updated successfully!");
                            var uuid = oData.uuid;
                            var projectStatus = oData.projectStatus_uuid;
                            oRouter.navTo("RouteProjectIDHDetails", {
                                uuid: uuid,
                                projectStatus: projectStatus
                            }, true);
                        },
                        error: function (oError) {
                            oBusyDialog.close();
                            // console.log(oError);
                            MessageToast.show(that._oBundle.getText("create_upd_error"));
                        }
                    });
                }
            },
            onPressSubmit: async function () {
                var oBusyDialog = this.byId("busyDialog");
                oBusyDialog.open();
                var that = this;
                if(this.getView().getModel("IDHModel").getData().IDHRegion.length==0)
                    {
                        oBusyDialog.close();
                        MessageBox.error(that._oBundle.getText("create_mat_error"));
                        return;
                    }
                const maxDate = this.getView().getModel("IDHModel").getData().IDHRegion.reduce((max, current) => {
                    return (current.phaseOutDate) > (max.phaseOutDate) ? current : max;
                });
                var bValid = await this.validateFields();
                var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
                var idhPlantData;
                if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") !== "Scenario03") {
                    if (this.getView().getModel("IDHModel").getData().IDHPlant.length == 0) {
                        MessageBox.error("No Plant for phase-out");
                        return;
                    }
                }
                
                if (bValid.error === false) {
                    oBusyDialog.close();
                    MessageBox.error(bValid.sMsg);
                    return;
                }
                else if (bValid.error === true) {
                    if (this.projectID === "0") {
                        if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario03") {
                            var plantsDataForSalesSubmit = this.getView().getModel("IDHModel").getData().IDHPlant;
                            const actualKeySalesDataSubmit = plantsDataForSalesSubmit.map(plant => ({
                                ...plant,
                                projectIDHSalesAreas: plant.projectIDHSalesAreas.map(({ distChanel, phaseOutNEEDED, salesCountry, salesCountryName, salesOrg, salesOrgDescr, salesyStatus, sourceSystem, yStatusValidfrom, phaseOutStatus_uuid, openTransactionSales }) => ({ distChanel, phaseOutNEEDED, salesCountry, salesCountryName, salesOrg, salesOrgDescr, salesyStatus, sourceSystem, yStatusValidfrom, phaseOutStatus_uuid, openTransactionSales }))
                            }));
                            idhPlantData = actualKeySalesDataSubmit;
                        } else {
                            idhPlantData = this.getView().getModel("IDHModel").getData().IDHPlant;
                        }
                        var oProjectHeader = {
                            projectDescription: this.getView().byId("idProjectDescription").getValue(),
                            phaseOutManager: this.getView().byId("idphaseoutManager").getValue(),
                            phaseOutManagerEmail: this.getOwnerComponent().getModel("userInfo").getData().useremail,
                            phaseOutDate: maxDate.phaseOutDate,
                            projectStatus_uuid: "dc18e443-c22b-4a0f-9b95-9ce796daffb9",
                            createdFrom: "BTP",
                            projectIDHs: this.getView().getModel("IDHModel").getData().IDHRegion,
                            projectIDHPlants: idhPlantData,
                            phaseOutScenario_id : this.scenario
                        };

                        var oModel = this.getView().getModel(); // ODataModel
                        oModel.create("/ProjectHeaders", oProjectHeader, {
                            success: function (oData, response) {
                                oBusyDialog.close();
                                MessageToast.show("Project created successfully!");
                                var uuid = oData.uuid;
                                var projectStatus = oData.projectStatus_uuid;
                                oRouter.navTo("RouteProjectIDHDetails", {
                                    uuid: uuid,
                                    projectStatus: projectStatus
                                }, true);
                            },
                            error: function (oError) {
                                oBusyDialog.close();
                                MessageBox.error(JSON.parse(oError.responseText).error.message.value)
                                //MessageToast.error(JSON.parse(oError.responseText).error.message.value);
                            }
                        });
                    }
                    else {
                      if (this.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") === "Scenario03") {
                            var plantsDataForSalesSubmitExit = this.getView().getModel("IDHModel").getData().IDHPlant;
                            const actualKeySalesDataSubmitExit = plantsDataForSalesSubmitExit.map(plant => ({
                                ...plant,
                                projectIDHSalesAreas: plant.projectIDHSalesAreas.map(data => {
                                    const {material, plant, region, ...rest} = data; // remove these keys
                                    return rest; // return everything else
                                })
                            }));
                            idhPlantData = actualKeySalesDataSubmitExit;
                        } else {
                            idhPlantData = this.getView().getModel("IDHModel").getData().IDHPlant;
                        }
                        var oProjectHeader = {
                            projectDescription: this.getView().byId("idProjectDescription").getValue(),
                            phaseOutManager: this.getView().byId("idphaseoutManager").getValue(),
                            phaseOutManagerEmail: this.getOwnerComponent().getModel("userInfo").getData().useremail,
                            phaseOutDate: maxDate.phaseOutDate,
                            projectStatus_uuid: "dc18e443-c22b-4a0f-9b95-9ce796daffb9",
                            createdFrom: "BTP",
                            projectIDHs: this.getView().getModel("IDHModel").getData().IDHRegion,
                            projectIDHPlants: idhPlantData,
                            phaseOutScenario_id : this.scenario
                        };

                        var oModel = this.getView().getModel(); // ODataModel
                        oModel.update("/ProjectHeaders('" + this.projectID + "')", oProjectHeader, {
                            success: function (oData, response) {
                                oBusyDialog.close();
                                MessageToast.show("Project created successfully!");
                                var uuid = oData.uuid;
                                var projectStatus = oData.projectStatus_uuid;
                                oRouter.navTo("RouteProjectIDHDetails", {
                                    uuid: uuid,
                                    projectStatus: projectStatus
                                }, true);
                            },
                            error: function (oError) {
                                oBusyDialog.close();
                                MessageBox.error(JSON.parse(oError.responseText).error.message.value)
                                //MessageToast.error(JSON.parse(oError.responseText).error.message.value);
                            }
                        });
                    }
                }
            },
            onNavback: function () {

                var sPreviousHash = History.getInstance().getPreviousHash();
                if (sPreviousHash !== undefined) {
                    // eslint-disable-next-line sap-no-history-manipulation
                    history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteProjectDetails", {}, true);
                }
            },
            onCheckRegion: function (oEvent) {
                 // this is done to refresh the delete button in project idh table 
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                // end this is done to refresh the delete button in project idh table
                var aSelected = oEvent.getParameters().selected;
                var aRow = oEvent.getSource().getBindingContext("IDHModel").getObject();
                var IDHPlant = this.getView().getModel("IDHModel").getData().IDHPlant;
                var oModel = this.getView().getModel();
                var aFilters = [], that = this;
                aFilters.push(new sap.ui.model.Filter("matnr", "EQ", aRow.material));
                aFilters.push(new sap.ui.model.Filter("regio", "EQ", aRow.regionScope));
                oModel.read("/MatPlants", {
                    filters: aFilters,
                    success: function (oData) {
                        const uniqueplants = oData.results.map(item => item.werks);
                        IDHPlant.forEach(element => {
                            if ((uniqueplants.indexOf(element.plant) !== -1) && aRow.material.indexOf(element.material) !== -1) {
                                if (aSelected === false) {
                                    element.phaseOutNEEDED = "No";

                                } else {
                                    element.phaseOutNEEDED = "Yes";

                                }
                            }
                        });
                        that.getView().getModel("IDHModel").setProperty("/IDHPlant", IDHPlant);

                    }.bind(this),
                    error: function (oError) {
                        sap.m.MessageToast.show(that._oBundle.getText("create_plant_error"));
                    }
                });
            },
            handleChangeDate: function (oEvent) {
                // this is done to refresh the delete button in project idh table 
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                // end this is done to refresh the delete button in project idh table 
                const oDate = new Date();
                var that = this;
                var pODate = oEvent.getSource().getBindingContext("IDHModel").getObject();
                if (oEvent.getParameters().value < oDate.getFullYear() + "-" + (oDate.getMonth() + 1).toString().padStart(2, '0') + "-" + oDate.getDate().toString().padStart(2, '0')) {
                    MessageBox.error(that._oBundle.getText("create_date_error"), {
                        onClose: function () {
                            pODate.phaseOutDate = null;
                            var regionScope = pODate.regionScope;
                            var material = pODate.material;
                            var IDHPlant = this.getView().getModel("IDHModel").getData().IDHPlant;
                            IDHPlant.forEach(element => {
                                if (element.regionScope === regionScope && element.material === material) {
                                    element.phaseOutDate = null;
                                }
                            });
                            this.getView().getModel("IDHModel").setProperty(oEvent.getSource().getBindingContext("IDHModel").getPath(), pODate);
                        }.bind(this)
                    });
                }

                var aDate = oEvent.getSource().getDateValue();
                var aRow = oEvent.getSource().getBindingContext("IDHModel").getObject();
                var IDHPlant = this.getView().getModel("IDHModel").getData().IDHPlant;
                var IDHRegion = this.getView().getModel("IDHModel").getData().IDHRegion;
                var oModel = this.getView().getModel();
                var aFilters = [], that = this;
                aFilters.push(new sap.ui.model.Filter("matnr", "EQ", aRow.material));
                aFilters.push(new sap.ui.model.Filter("regio", "EQ", aRow.regionScope));
                oModel.read("/MatPlants", {
                    filters: aFilters,
                    success: function (oData) {
                        const uniqueplants = oData.results.map(item => item.werks);
                        IDHPlant.forEach(element => {
                            if ((uniqueplants.indexOf(element.plant) !== -1) && (aRow.material.indexOf(element.material) !== -1)) {
                                element.phaseOutDate = new Date(Date.UTC(
                                    aDate.getFullYear(),
                                    aDate.getMonth(),
                                    aDate.getDate()
                                ))
                            } else if ((element.plant === "NAN") && (aRow.material.indexOf(element.material) !== -1)) {
                                element.phaseOutDate = new Date(Date.UTC(
                                    aDate.getFullYear(),
                                    aDate.getMonth(),
                                    aDate.getDate()
                                ))
                            }
                        });
                        that.getView().getModel("IDHModel").setProperty("/IDHPlant", IDHPlant);

                    }.bind(this),
                    // error: function (oError) {
                    //     sap.m.MessageToast.show("Error fetching plants for the Region");
                    // }
                });
                // var material = aRow.material;
                // var regionScope = aRow.regionScope;
                // var oPlantTable = this.byId("tablePlantCr");
                // var aPlantItems = oPlantTable.getItems();

                // for (var i = 0; i < aPlantItems.length; i++) {
                //     var oPlantItem = aPlantItems[i];
                //     var oPlantContext = oPlantItem.getBindingContext("IDHModel");
                //     if (oPlantContext.getProperty("material") === material && oPlantContext.getProperty("regionScope") === regionScope) {
                //         var oPhaseOutDateInput = oPlantItem.getCells()[6];
                //         oPhaseOutDateInput.setValue(aDate);
                //     }
                // }
            },
            onDisplaySalesArea: function (oEvent) {
                var oButton = oEvent.getSource(),
                    oView = this.getView(),
                    salesAreas = oEvent.getSource().getBindingContext("IDHModel").getObject().projectIDHSalesAreas,
                    that = this;
                var oJSONModel = new JSONModel();

                if(salesAreas.hasOwnProperty("results"))
                    salesAreas = salesAreas.results;

                // format date to display
                salesAreas.forEach((salesArea, index) => {
                    if(new Date(salesArea.yStatusValidfrom) != "Invalid Date")
                        return;
                    salesAreas[index].yStatusValidfrom = new Date(parseInt(salesArea.yStatusValidfrom.substr(6)));
                });

                oJSONModel.setData(salesAreas);
                that.getView().setModel(oJSONModel, "ProjectIDHSalesAreas");

                // create popover
                if (!this._pPopover) {
                    this._pPopover = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.IDHSalesAreaDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopover.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });
            },
            validateFields: async function (oEvent) {
                var bValid = {};
                bValid.error = true;
                bValid.sMsg = "Select/Enter mandatory fields:";
                var oIDH = this.getView().getModel("IDHModel").getData();
                var Desc = this.getView().byId("idProjectDescription").getValue();
                var phaseOutDate = this.getView().byId("idphaseoutDate").getValue();
                var oTable = this.getView().byId("myTable");
                var aItems = oTable.getItems();
                var that = this;
                aItems.forEach(function (oItem) {
                    var oContext = oItem.getBindingContext("IDHModel");
                    var oData = oContext.getObject();
                    if (oData.phaseOutNEEDED) {
                        if (that.getOwnerComponent().getModel("LocalDataModel").getProperty("/scenario") !== "Scenario03") {
                            if (!oData.phaseOutDate || oData.phaseOutDate === "") {
                                bValid.error = false;
                                bValid.sMsg = bValid.sMsg + "\n- Phase-out Date for IDH " + oData.material + " and region " + oData.regionScope;
                            }
                        }
                    }
                });
                /* if (oIDH !== undefined) {
                    if (oIDH.IDHRegion.length === 0) {
                        bValid.error = false;
                        bValid.sMsg = bValid.sMsg + "\n- IDH List";
                    }
                    else {
                        oIDH.IDHRegion.forEach(element => {
                            if (element.phaseOutNEEDED && (!element.phaseOutDate || element.phaseOutDate === "")) {
                                bValid.error = false;
                                bValid.sMsg = bValid.sMsg + "\n- Phase-out Date for IDH " + element.material + " and region " + element.regionScope;
                            }
                        });
                    }
                }*/
                if (Desc === "") {
                    bValid.error = false;
                    bValid.sMsg = bValid.sMsg + "\n- Project Description";
                }
                /*  if (phaseOutDate === "") {
                      bValid.error = false;
                      bValid.sMsg = bValid.sMsg + "\n- Phase-out Date";
                  }*/
                return bValid;
            },

            handleOTAfterClose: function (oEvent) {
                oEvent.getSource().getParent().setModel(new JSONModel({}), "OpenTransactionModel");
            },
            onDisplayOpenTransactions: function (oEvent) {

                var oBusyDialog = this.byId("busyDialog");
                var oButton = oEvent.getSource(),
                    oView = this.getView();
                var that = this,
                    material = oEvent.getSource().getBindingContext("IDHModel").getObject().material,
                    plant = oEvent.getSource().getBindingContext("IDHModel").getObject().plant,
                    source = oEvent.getSource().getBindingContext("IDHModel").getObject().sourceSystem;

                oView.getModel().callFunction("/getOpenTransactions", {
                    method: "GET",
                    urlParameters: {
                        material: material,
                        plant: plant,
                        source: source
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData.getOpenTransactions);
                        oView.setModel(jsonModel, "OpenTransactionModel");
                        oView.byId('myPopoverOpenTransactionCreate').setBusy(false);
                    },
                    error: function (oError) {
                        MessageToast.show(that._oBundle.getText("create_OT_error"));
                    }
                });

                if (!this._pPopOpen) {
                    this._pPopOpen = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.IDHOpenTransactionsDialogCreate",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }

                this._pPopOpen.then((oPopover) => {                    
                     // Open the popover
                     oPopover.openBy(oButton);
                });    

            },
            onCheckRegionPlant: function (oEvent) {
                 // this is done to refresh the delete button in project idh table 
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                // end this is done to refresh the delete button in project idh table
                var aSelectedplant = oEvent.getParameters().selected;
                var aRowplant = oEvent.getSource().getBindingContext("IDHModel").getObject();
                var IDHPlantplant = this.getView().getModel("IDHModel").getData().IDHPlant;
                if (aSelectedplant) {
                    IDHPlantplant.forEach(item => {
                        if (item.material === aRowplant.material && item.plant === aRowplant.plant && item.regionScope === aRowplant.regionScope) {
                            item.phaseOutNEEDED = 'Yes';
                        }
                    });
                } else {
                    IDHPlantplant.forEach(item => {
                        if (item.material === aRowplant.material && item.plant === aRowplant.plant && item.regionScope === aRowplant.regionScope) {
                            item.phaseOutNEEDED = 'No';
                        }
                    });
                }
                var IDHPlantRegionSec02 = this.getView().getModel("IDHModel").getData().IDHRegion;
                var checkAllMatAndPlantofSel = IDHPlantplant.filter((plant) => plant.material === aRowplant.material && plant.regionScope === aRowplant.regionScope);
                var toCheckAllPlantPhaseout = checkAllMatAndPlantofSel.filter(items => items.phaseOutNEEDED === 'No');
                if (checkAllMatAndPlantofSel.length === toCheckAllPlantPhaseout.length) {
                     IDHPlantRegionSec02.forEach(element => {
                        if (element.material === aRowplant.material  && element.regionScope === aRowplant.regionScope) {
                            element.phaseOutNEEDED = false;
                        }
                    });

                    this.getView().getModel("IDHModel").setProperty("/IDHRegion", IDHPlantRegionSec02);
                } else {
                    IDHPlantRegionSec02.forEach(element => {
                        if (element.material === aRowplant.material &&  element.regionScope === aRowplant.regionScope) {
                            element.phaseOutNEEDED = true;
                        }
                    });

                    this.getView().getModel("IDHModel").setProperty("/IDHRegion", IDHPlantRegionSec02);
                }
                // var oModelplant = this.getView().getModel();
                // var aFiltersplant = [], that = this;
                this.getView().getModel("IDHModel").setProperty("/IDHPlant", IDHPlantplant);
            },
            handleChangeDatePlant: function (oEvent) {
                // this is done to refresh the delete button in project idh table 
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                // end this is done to refresh the delete button in project idh table
                const oDate = new Date();
                var that = this;
                var pODate = oEvent.getSource().getBindingContext("IDHModel").getObject();
                if (oEvent.getParameters().value < oDate.getFullYear() + "-" + (oDate.getMonth() + 1).toString().padStart(2, '0') + "-" + oDate.getDate().toString().padStart(2, '0')) {
                    MessageBox.error(that._oBundle.getText("create_date_error"), {
                        onClose: function () {
                            pODate.phaseOutDate = null;
                            var regionScopePlant = pODate.regionScope;
                            var materialPlant = pODate.material;
                            var plantPlant = pODate.plant;
                            var IDHPlantvalue = this.getView().getModel("IDHModel").getData().IDHPlant;
                            var idhplantdata = IDHPlantvalue.filter((item) => item.material === pODate.material && item.regionScope === pODate.regionScope);
                            var filterDateCheck = idhplantdata.filter((item) => item.phaseOutDate !== null);
                            var IDHRegion = this.getView().getModel("IDHModel").getData().IDHRegion;
                            if (filterDateCheck.length === 0) {
                                IDHRegion.forEach(element => {
                                    if (element.regionScope === regionScopePlant && element.material === materialPlant) {
                                        element.phaseOutDate = null;
                                    }
                                });
                            }
                            this.getView().getModel("IDHModel").setProperty(oEvent.getSource().getBindingContext("IDHModel").getPath(), pODate);
                        }.bind(this)
                    });
                }

                let aDate = oEvent.getSource().getDateValue();
                let IDHPlant = this.getView().getModel("IDHModel").getData().IDHPlant;
                var IDHRegion = this.getView().getModel("IDHModel").getData().IDHRegion;

                var filterPlantDataForDate = IDHPlant.filter((item) => item.material === pODate.material && item.regionScope === pODate.regionScope);
                var filterPlantDataForDateValue = filterPlantDataForDate.filter((item) => item.phaseOutDate !== null);

                if (filterPlantDataForDateValue.length > 0) {
                    var maxPlantDate = filterPlantDataForDateValue.reduce((max, current) => {
                        return (current.phaseOutDate) > (max.phaseOutDate) ? current : max;
                    });
                    IDHRegion.forEach(element => {
                        if (element.regionScope === pODate.regionScope && element.material === pODate.material) {
                            element.phaseOutDate = new Date(Date.UTC(
                                maxPlantDate.phaseOutDate.getFullYear(),
                                maxPlantDate.phaseOutDate.getMonth(),
                                maxPlantDate.phaseOutDate.getDate()
                            ))
                        }
                    });
                    that.getView().getModel("IDHModel").setProperty("/IDHRegion", IDHRegion);
                } else {
                    IDHRegion.forEach(element => {
                        if (element.regionScope === pODate.regionScope && element.material === pODate.material) {
                            element.phaseOutDate = null;
                        }
                    });
                }
            },
             onSearchRegionCr: function (oEvent) {
                // add filter for search
                var aFilters = [];
                var sQuery = oEvent.getSource().getValue();
                // var sQuery = oEvent.getParameter("query");
                var oList = this.byId("myTable");
                var oBinding = oList.getBinding("items");
                if (sQuery) {
                    aFilters.push(
                        new sap.ui.model.Filter("material", sap.ui.model.FilterOperator.Contains, sQuery)
                    );
                    aFilters.push(
                        new sap.ui.model.Filter("regionScope", sap.ui.model.FilterOperator.Contains, sQuery)
                    );
                    // var filter = new Filter("material", FilterOperator.Contains, sQuery);
                    // aFilters.push(filter);
                    // update list binding
                    oBinding.filter(new sap.ui.model.Filter({
                        filters: aFilters,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBinding.filter([]);
                }
            },
            onSearchPlantCr: function (oEvent) {
                // add filter for search
                var aFiltersplant = [];
                var sQueryplant = oEvent.getSource().getValue();
                var oListplant = this.byId("tablePlantCr");
                var oBindingplant = oListplant.getBinding("items");
                if (sQueryplant) {
                    aFiltersplant.push(
                        new sap.ui.model.Filter("material", sap.ui.model.FilterOperator.Contains, sQueryplant)
                    );
                    aFiltersplant.push(
                        new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.Contains, sQueryplant)
                    );
                    // update list binding
                    oBindingplant.filter(new sap.ui.model.Filter({
                        filters: aFiltersplant,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBindingplant.filter([]);
                }
            },
            onSearchSalesCr: function (oEvent) {
                // add filter for search
                var aFiltersSales = [];
                var sQuerySales = oEvent.getSource().getValue();
                var oListSales = this.byId("tableSalescreate");
                var oBindingSales = oListSales.getBinding("items");
                if (sQuerySales) {
                    aFiltersSales.push(
                        new sap.ui.model.Filter("salesOrg", sap.ui.model.FilterOperator.Contains, sQuerySales)
                    );
                    aFiltersSales.push(
                        new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.Contains, sQuerySales)
                    );
                    // update list binding

                    oBindingSales.filter(new sap.ui.model.Filter({
                        filters: aFiltersSales,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBindingSales.filter([]);
                }

            },
             onCheckRegionPlantSales: function (oEvent) {
                // this is done to refresh the delete button in project idh table 
                this.getView().getModel("DeleteModel").getData().deleteButton = [];
                // end this is done to refresh the delete button in project idh table
                var aSelectedplantSales = oEvent.getParameters().selected;
                var aRowplantSales = oEvent.getSource().getBindingContext("IDHModel").getObject();
                var IDHPlantplantSales = this.getView().getModel("IDHModel").getData().IDHPlant;
                var scenario03SalesData = this.getView().getModel("IDHModel").getData().IDHSales;
                if (aSelectedplantSales) {
                    scenario03SalesData.forEach(data => {
                        if(data.material === aRowplantSales.material && data.plant === aRowplantSales.plant && data.region === aRowplantSales.region && data.distChanel === aRowplantSales.distChanel && data.salesCountryName === aRowplantSales.salesCountryName){
                                data.phaseOutNEEDED = 'Yes';
                            }
                        // item.projectIDHSalesAreas.forEach(data => {
                        //     if(data.material === aRowplantSales.material && data.plant === aRowplantSales.plant && data.region === aRowplantSales.region && data.distChanel === aRowplantSales.distChanel){
                        //         data.phaseOutNEEDED = 'Yes';
                        //     }
                        // });
                    });
                } else {
                    scenario03SalesData.forEach(data => {
                        if(data.material === aRowplantSales.material && data.plant === aRowplantSales.plant && data.region === aRowplantSales.region && data.distChanel === aRowplantSales.distChanel && data.salesCountryName === aRowplantSales.salesCountryName){
                                data.phaseOutNEEDED = 'No';
                            }
                        //  item.projectIDHSalesAreas.forEach(data => {
                        //     if(data.material === aRowplantSales.material && data.plant === aRowplantSales.plant && data.region === aRowplantSales.region && data.distChanel === aRowplantSales.distChanel){
                        //         data.phaseOutNEEDED = 'No';
                        //     }
                        // });
                    });
                }
                var IDHPlantRegionSec03 = this.getView().getModel("IDHModel").getData().IDHRegion;
                var checkAllMatAndPlantofSales = scenario03SalesData.filter((plant) => plant.material === aRowplantSales.material && plant.region === aRowplantSales.region);
                var toCheckAllSalesPhaseout = checkAllMatAndPlantofSales.filter(items => items.phaseOutNEEDED === 'No');
                if (checkAllMatAndPlantofSales.length === toCheckAllSalesPhaseout.length) {
                     IDHPlantRegionSec03.forEach(element => {
                        if (element.material === aRowplantSales.material  && element.regionScope === aRowplantSales.region) {
                            element.phaseOutNEEDED = false;
                        }
                    });

                    this.getView().getModel("IDHModel").setProperty("/IDHRegion", IDHPlantRegionSec03);
                } else {
                    IDHPlantRegionSec03.forEach(element => {
                        if (element.material === aRowplantSales.material &&  element.regionScope === aRowplantSales.region) {
                            element.phaseOutNEEDED = true;
                        }
                    });

                    this.getView().getModel("IDHModel").setProperty("/IDHRegion", IDHPlantRegionSec03);
                }
                // var oModelplant = this.getView().getModel();
                // var aFiltersplant = [], that = this;
                this.getView().getModel("IDHModel").setProperty("/IDHPlant", IDHPlantplantSales);
                this.getView().getModel("IDHModel").setProperty("/IDHSales", scenario03SalesData);
            }     
        });
    });