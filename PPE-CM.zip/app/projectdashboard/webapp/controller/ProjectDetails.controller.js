sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
],
    function (Controller,MessageBox,MessageToast) {
        "use strict";

        return Controller.extend("projectdashboard.controller.ProjectDetails", {
            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteProjectDetails").attachPatternMatched(this._onRouteMatched, this);
                this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.oGlobalBusyDialog = new sap.m.BusyDialog();
                this.getOwnerComponent().getModel("LocalDataModel").setProperty("/scenarioError", false);
            },
            _onRouteMatched: function (oEvent) {
                this.getView().byId("smartTableProjectHdr").rebindTable();
            },
            onNavToDetails: function (oEvent) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                var selectedprojectID = oEvent.getSource().getBindingContext().getProperty("uuid");
                var selectedprojectStatus = oEvent.getSource().getBindingContext().getProperty("projectStatus");
                // if (selectedprojectStatus.projectStatus === "Draft") {
                var selectedprojectID = oEvent.getSource().getBindingContext().getProperty("uuid");
                //   oRouter.navTo("RouteProjectCreate", {
                //       uuid: selectedprojectID
                //   });
                // } else {
                oRouter.navTo("RouteProjectIDHDetails", {
                    uuid: selectedprojectID,
                    projectStatus: selectedprojectStatus.uuid
                });
                //  }
            },
            onNavToCreate: function (oEvent) {
                let view = this.getView();
                
                this._scDialog = null;
                if (!this._scDialog) {
                  sap.ui.core.Fragment.load({
                    name: "projectdashboard.fragments.ScenarioDialog",
                    controller: this
                  }).then(function (oDialog) {
                    
                    view.addDependent(oDialog);
                    oDialog.open();
                    this._scDialog = oDialog;
                  }.bind(this));
                  
                } else {
                  this._scDialog.open();
                }

                // let oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                // let selectedprojectID = "0";
                // oRouter.navTo("RouteProjectCreate", {
                //     uuid: selectedprojectID,
                //     scenario : "Scenario01"
                // });
                    
                
            },
            onCloseScDialog : function(){
                this.getOwnerComponent().getModel("LocalDataModel").setProperty("/scenarioError", false);
                this._scDialog.close();
            },
            onAfterScDialogClose : function(){
                this._scDialog.close();
                this._scDialog.destroy();
            },
            onCloseScOkDialog : function(){
               
                let scenarioID = sap.ui.getCore().byId("ProductList")?.getSelectedItem()?.getDescription();
                let oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                let selectedprojectID = "0";
                if(scenarioID != undefined){
                    oRouter.navTo("RouteProjectCreate", {
                        uuid: selectedprojectID,
                        scenario : scenarioID
                    });
                    
                     this._scDialog.close();
                }else{
                    this.getOwnerComponent().getModel("LocalDataModel").setProperty("/scenarioError", true);
                }
               
            },
            onNavToDelete: function (oEvent) {
                var that = this;
                let oTable = this.getView().byId("idForProjectHeader")
                let oSelectedItem = oTable.getSelectedItem();
                if (!oSelectedItem) {
                    MessageBox.error(that.oBundle.getText("ErrorReqDeletion"));
                    return;
                }
                if(oSelectedItem.getBindingContext().getProperty("projectStatus").uuid == '21c74e08-b4d6-4632-89b8-f6f33bb6cdb8') 
                {
                    this.getOwnerComponent().getModel().update(oSelectedItem.getBindingContextPath(), {Deletion:true}, {
                        success: function (oData, response) {
                            this.oGlobalBusyDialog.close();
                            oTable.getBinding("items").refresh(true)
                            MessageToast.show(that.oBundle.getText("ProjectDeleted"));
                        
                        }.bind(this),
                        error: function (oError) {
                            oGlobalBusyDialog.close();
                            MessageToast.show(that.oBundle.getText("ProjectErrordeleted"));
                        }
                    });
                }
                else {
                    MessageBox.error(that.oBundle.getText("projectIsNoDraft"));
                    return;
                }
            },
            onSpecificSearch: function () {
                const view = this.getView();
                this._pDialog = null;
                if (!this._pDialog) {
                  sap.ui.core.Fragment.load({
                    name: "projectdashboard.fragments.IdhSalesProjectMat",
                    controller: this
                  }).then(function (oDialog) {
                    
                    view.addDependent(oDialog);
                    oDialog.open();
                    this._pDialog = oDialog;
                  }.bind(this));
                  
                } else {
                  this._pDialog.open();
                }

               
            },
            onAfterOpenDialog : function(){
                const oSmartFilterBar = sap.ui.getCore().byId("idSalesProjFb");

                if (oSmartFilterBar) {
                oSmartFilterBar.setFilterData({
                    phaseOutNEEDED : "Yes"
                });
                oSmartFilterBar.search();
                }
            },
            onCloseIdhSalesDialog : function () {
            this._pDialog.close();
            this._pDialog.destroy();
            },
            onAfterDialogClose : function(){
            this._pDialog.destroy();
            },
            onSelectScenario : function(evt){
               this.getOwnerComponent().getModel("LocalDataModel").setProperty("/scenarioError", false);
            }

        });
    });
