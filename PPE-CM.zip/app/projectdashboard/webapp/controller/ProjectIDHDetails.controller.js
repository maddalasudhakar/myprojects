sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Sorter",
    "projectdashboard/utils/Formatter",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "sap/ui/model/Filter"
],
    function (Controller, JSONModel, Sorter, Formatter, MessageToast, MessageBox, BusyIndicator,Filter) {
        "use strict";
        return Controller.extend("projectdashboard.controller.ProjectIDHDetails", {
            Formatter: Formatter,
            onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteProjectIDHDetails").attachPatternMatched(this._onRouteMatched, this);
                // this.getView().setModel(new JSONModel({projectstatus:""}), "statusCalulate");
                this.oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },
            _onRouteMatched:async function (oEvent) {
                var oArgs, oView;
                oArgs = oEvent.getParameter("arguments");
                this.projectID = oArgs.uuid;
                this.projectStatus = oArgs.projectStatus;
                var projectStatus = oArgs.projectStatus;
                oView = this.getView();

                var sContextPath = "/ProjectHeaders('" + this.projectID + "')";
                this.getView().byId("ObjectPageLayoutDtls").bindElement({
                    path: sContextPath,
                    parameters: {
                        expand: "projectStatus,projectIDHs,projectIDHPlants,salesArea,phaseOutScenario" // optional if needed        
                        },
                    events: {
                        dataReceived: function (oEvent) {
                            // let createdBy = oEvent.getSource().getBoundContext().getObject().createdBy;
                            // let userAuthData = this.getView().getModel("userAuth").getData();

                            // if(createdBy === userAuthData.userEmail && userAuthData.create === true){
                            //     userAuthData.edit = true;
                            // }else{
                            //     userAuthData.edit = false;
                            // }
                            // this.getView().getModel("userAuth").refresh();
                            this.salesTableScenario03(oEvent.getSource().getBoundContext().getObject());
                        }.bind(this),
                        dataRequested: function (oEvent) {
                            // Handle data requested event (optional)
                        }
                    }
                    });
                this.getView().byId("ObjectPageLayoutDtls").setBusy(true);
                this.getView().byId("smartTableProjectIDH").rebindTable();
                this.getView().byId("smartTableProjectIDHPlant").rebindTable();
                this.getView().byId("smartTableProjectIDHDepObj").rebindTable();
                var sDataPath = this.getStatusDataPath(projectStatus);
                this.getView().byId("ObjectPageLayoutDtls").setBusy(false);
                this.oProcessFlow1 = oView.byId("processflow");
                var oModelPf1 = new JSONModel(sDataPath);
                oView.setModel(oModelPf1, "viewModel");
            },
            getProjectIDHData :  function (projectId){
                let aFilters = [];
                aFilters.push(new Filter("l_ev_uuid", "EQ", projectId));
                var that = this;
                return new Promise(function(resolve,reject){
                    that.getView().getModel().read(`/ProjectIDHs`, {
                    filters: aFilters,
                    success: function (oData) {
                        var filteredStatusY5 = oData.results.filter(item => item.phaseOutStatus_uuid == "1c290c86-d4ee-44e0-98df-87de0a09c945");
                        if(oData.results.length == filteredStatusY5.length){
                            var statusdata =  "1c290c86-d4ee-44e0-98df-87de0a09c945";
                            that.getView().getModel("statusCalulate").setProperty("/projectstatus",statusdata)
                        }else{
                            var statusdata = that.projectStatus;
                            that.getView().getModel("statusCalulate").setProperty("/projectstatus","")
                        }
                       resolve(statusdata);
                    }.bind(this),
                    error: function (oError) {
                        sap.m.MessageToast.show(that.oBundle.getText("ErrorFutureData"));
                    }
                })
            })
            },
            handleNavButtonPress: function (evt) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteProjectDetails");
            },
            onBeforeRebindPlant: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                if (!oBindingParams.sorter.length) {
                    oBindingParams.sorter.push(new sap.ui.model.Sorter("material", false))
                }
                oBindingParams.parameters["expand"] = "phaseOutStatus,l_ev";
                oBindingParams.filters.push(new sap.ui.model.Filter("l_ev_uuid", "EQ", this.projectID));
                oBindingParams.filters.push(new sap.ui.model.Filter("phaseOutNEEDED", "EQ", "Yes"));
            },

            onBeforeRebindIDHDepObj: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                oBindingParams.filters.push(new sap.ui.model.Filter("project_uuid", "EQ", this.projectID));
            },

            onBeforeRebindIDH: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");
                if (!oBindingParams.sorter.length) {
                    oBindingParams.sorter.push(new sap.ui.model.Sorter("material", false))
                }
                oBindingParams.parameters["expand"] = "phaseOutStatus,l_ev";
                oBindingParams.filters.push(new sap.ui.model.Filter("l_ev_uuid", "EQ", this.projectID));
                oBindingParams.filters.push(new sap.ui.model.Filter("phaseOutNEEDED", "EQ", true));
            },
            onEdit: function (oEvent) {
                var that = this;
                if (this.projectStatus === "21c74e08-b4d6-4632-89b8-f6f33bb6cdb8") {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteProjectCreate", {
                        uuid: this.projectID,
                        scenario : this.getView().byId("idPhaseoutScenario1").getTextLabel()
                    });
                }
                else {
                    MessageBox.error(that.oBundle.getText("ErrorDraftStatus"));
                }
            },
            onNavSupplyPlanner: function (oEvent) {
                let projectId = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().projectID;
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "supplyplanner",
                        action: "display"
                    },
                    params: {
                        projectID: projectId
                    }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },
            onNavcontrolTower: function (oEvent) {
                let projectId = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().projectID;
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "ControlTower",
                        action: "display"
                    },
                    params: {
                        "projectID": projectId
                    }
                })) || "";
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                });
            },
            onDisplaySalesArea: function (oEvent) {
                var oButton = oEvent.getSource(),
                    oView = this.getView(),
                    uuid = oEvent.getSource().getBindingContext().getProperty("uuid"),
                    that = this;
                var oModel = this.getView().getModel();
                var aFilters = [];
                aFilters.push(new sap.ui.model.Filter("l_ev_uuid", "EQ", uuid));

                // create popover
                if (!this._pPopover) {
                    this._pPopover = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.IDHSalesAreaDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopover.then(function (oPopover) {
                    oPopover.openBy(oButton);
                    oModel.read("/ProjectIDHSalesArea", {
                        filters: aFilters,
                        success: function (oData) {
                            var oJSONModel = new JSONModel();
                            oJSONModel.setData(oData.results);
                            that.getView().setModel(oJSONModel, "ProjectIDHSalesAreas");

                            var oTable = that.getView().byId("salesTable");
                            oTable.setModel(oJSONModel, "ProjectIDHSalesAreas");
                        }.bind(this),
                        error: function (oError) {
                            sap.m.MessageToast.show(that.oBundle.getText("ErrorFilteredData"));
                        }
                    });
                });
            },
            onDisplayOpenTransactions: function (oEvent) {
                var oButton = oEvent.getSource(),
                    oView = this.getView();
                var that = this,
                    material = oEvent.getSource().getBindingContext().getProperty("material"),
                    plant = oEvent.getSource().getBindingContext().getProperty("plant"),
                    source = "";

                oView.getModel().callFunction("/getOpenTransactions", {
                    method: "GET",
                    urlParameters: {
                        material: material,
                        plant: plant,
                        source: source
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData.getOpenTransactions);
                        oView.setModel(jsonModel, "OpenTransactionModel");
                        oView.byId('myPopoverOpenTransaction').setBusy(false);
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("create_OT_error"));
                    }
                });
                // create popover
                if (!this._pPopOpen) {
                    this._pPopOpen = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.IDHOpenTransactionsDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }

                this._pPopOpen.then((oPopover) => {
                    let oExclusiveCompTable = oPopover.getContent()[0].getItems()[1];

                    // Clear previous filters on the items binding
                    let oBinding = oExclusiveCompTable.getBinding("items");
                    if (oBinding) {
                        let aFilters = [];
                        aFilters.push(new sap.ui.model.Filter("fg_idh", "EQ", oEvent.getSource().getBindingContext().getObject("material")));
                        aFilters.push(new sap.ui.model.Filter("projectID", "EQ", this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().projectID));
                        aFilters.push(new sap.ui.model.Filter("plant", "EQ", oEvent.getSource().getBindingContext().getObject("plant")));
                        oBinding.filter(aFilters); // This clears any previous filters
                    } else {
                        MessageBox.error(that.oBundle.getText("ErrorItemFound"));
                        return; // Exit if binding is not found
                    }

                    // Open the popover
                    oPopover.openBy(oButton);
                });

            },

            handleOTAfterClose: function (oEvent) {
                oEvent.getSource().getParent().setModel(new JSONModel({}), "OpenTransactionModel");
            },

            getStatusDataPath: function (oStatus) {
                var sDataPath = {};
                // Phase-Out Execution
                if (oStatus === "dc18e443-c22b-4a0f-9b95-9ce796daffb9") {
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://task",
                                "label": "Draft",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "1",
                                "icon": "sap-icon://task",
                                "label": "Submitted",
                                "position": 1,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "2",
                                "icon": "sap-icon://task",
                                "label": "SBU Approval",
                                "position": 2,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "3",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Execution",
                                "position": 3,
                                "state": [
                                    {
                                        "state": "Critical",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "4",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Completed",
                                "position": 4,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "5",
                                "icon": "sap-icon://task",
                                "label": "Closed",
                                "position": 5,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };

                }
                // Closed 
                else if (oStatus === "dba70db3-2b4b-41d1-9b56-a09a635ca91d") {
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://task",
                                "label": "Draft",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "1",
                                "icon": "sap-icon://task",
                                "label": "Submitted",
                                "position": 1,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "2",
                                "icon": "sap-icon://task",
                                "label": "SBU Approval",
                                "position": 2,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "3",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Execution",
                                "position": 3,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "4",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Completed",
                                "position": 4,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "5",
                                "icon": "sap-icon://task",
                                "label": "Closed",
                                "position": 5,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };
                }
                // Draft
                else if (oStatus === "21c74e08-b4d6-4632-89b8-f6f33bb6cdb8") {
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://task",
                                "label": "Draft",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "1",
                                "icon": "sap-icon://task",
                                "label": "Submitted",
                                "position": 1,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "2",
                                "icon": "sap-icon://task",
                                "label": "SBU Approval",
                                "position": 2,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "3",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Execution",
                                "position": 3,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            },{
                                "id": "4",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Completed",
                                "position": 4,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "5",
                                "icon": "sap-icon://task",
                                "label": "Closed",
                                "position": 5,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };

                }
                // Cancelled 
                else if (oStatus === "dae19016-c2da-47f4-9813-692f4b8d94d7") {
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://sys-cancel",
                                "label": "Phase-Out Cancelled",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Negative",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };

                }
              // 
                else if(oStatus === "1c290c86-d4ee-44e0-98df-87de0a09c945"){
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://task",
                                "label": "Draft",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "1",
                                "icon": "sap-icon://task",
                                "label": "Submitted",
                                "position": 1,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "2",
                                "icon": "sap-icon://task",
                                "label": "SBU Approval",
                                "position": 2,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "3",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Execution",
                                "position": 3,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "4",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Completed",
                                "position": 4,
                                "state": [
                                    {
                                        "state": "Critical",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "5",
                                "icon": "sap-icon://task",
                                "label": "Closed",
                                "position": 5,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };
                }
                // Phase-Out Completed
                else if(oStatus === "d9c4e3c7-6a15-4a92-a50a-27473a4e99ae"){
                    sDataPath = {
                        "lanes": [
                            {
                                "id": "0",
                                "icon": "sap-icon://task",
                                "label": "Draft",
                                "position": 0,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "1",
                                "icon": "sap-icon://task",
                                "label": "Submitted",
                                "position": 1,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "2",
                                "icon": "sap-icon://task",
                                "label": "SBU Approval",
                                "position": 2,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            }, {
                                "id": "3",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Execution",
                                "position": 3,
                                "state": [
                                    {
                                        "state": "Positive",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "4",
                                "icon": "sap-icon://task",
                                "label": "Phase-Out Completed",
                                "position": 4,
                                "state": [
                                    {
                                        "state": "Critical",
                                        "value": 10
                                    }
                                ]
                            },
                            {
                                "id": "5",
                                "icon": "sap-icon://task",
                                "label": "Closed",
                                "position": 5,
                                "state": [
                                    {
                                        "state": "Neutral",
                                        "value": 10
                                    }
                                ]
                            }
                        ]
                    };
                }

                return sDataPath;

            },

            onDisplayDepObjIbProduct: function (oEvent) {

                const projectUuid = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().uuid;
                var that = this;
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                oView.getModel().callFunction("/getDepObjIbProducts", {
                    method: "GET",
                    urlParameters: {
                        uuid: projectUuid
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData);
                        oView.setModel(jsonModel, "DepObjIbProductModel");
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("ErrorLoadingData"));
                    }
                });

                // create popover
                if (!this._pPopOpenIbProduct) {
                    this._pPopOpenIbProduct = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.DepObjIbProductsDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    })
                };

                this._pPopOpenIbProduct.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });

            },

            onDisplayDepObjRsn: function (oEvent) {

                const projectUuid = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().uuid;
                var that = this;
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                oView.getModel().callFunction("/getDepObjRsns", {
                    method: "GET",
                    urlParameters: {
                        uuid: projectUuid
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData);
                        oView.setModel(jsonModel, "DepObjRsnModel");
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("ErrorLoadingData"));
                    }
                });

                // create popover
                if (!this._pPopOpenRsn) {
                    this._pPopOpenRsn = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.DepObjRsnsDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }

                this._pPopOpenRsn.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });

            },

            onDisplayDepObjBom: function (oEvent) {

                const projectUuid = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().uuid;
                var that = this;
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                oView.getModel().callFunction("/getDepObjBoms", {
                    method: "GET",
                    urlParameters: {
                        uuid: projectUuid
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData);
                        oView.setModel(jsonModel, "DepObjBomModel");
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("ErrorLoadingData"));
                    }
                });

                // create popover
                if (!this._pPopOpenBom) {
                    this._pPopOpenBom = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.DepObjBomsDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopOpenBom.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });

            },

            onDisplayDepObjMasterRecipePrdVersion: function (oEvent) {

                const projectUuid = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().uuid;
                var that = this;
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                oView.getModel().callFunction("/getDepObjMasterRecipePrdVersion", {
                    method: "GET",
                    urlParameters: {
                        uuid: projectUuid
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData);
                        oView.setModel(jsonModel, "DepObjMasterRecipePrdVersionModel");
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("ErrorLoadingData"));
                    }
                });

                // create popover
                if (!this._pPopOpenMasterRecipe) {
                    this._pPopOpenMasterRecipe = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.DepObjMasterRecipePrdVersionDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopOpenMasterRecipe.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });

            },

            onDisplayDepObjPirSourceList: function (oEvent) {

                const projectUuid = this.getView().byId("ObjectPageLayoutDtls").getBindingContext().getObject().uuid;
                var that = this;
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                oView.getModel().callFunction("/getDepObjDepObjPirSourceList", {
                    method: "GET",
                    urlParameters: {
                        uuid: projectUuid
                    },
                    success: function (oData) {
                        var jsonModel = new sap.ui.model.json.JSONModel(oData);
                        oView.setModel(jsonModel, "DepObjPirSourceListModel");
                    },
                    error: function (oError) {
                        MessageToast.show(that.oBundle.getText("ErrorLoadingData"));
                    }
                });

                // create popover
                if (!this._pPopOpenPir) {
                    this._pPopOpenPir = sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "projectdashboard.fragments.DepObjPirSourceListDialog",
                        controller: this
                    }).then(function (oPopover) {
                        oView.addDependent(oPopover);
                        return oPopover;
                    });
                }
                this._pPopOpenPir.then(function (oPopover) {
                    oPopover.openBy(oButton);
                });

            },
            onSearch: function (oEvent) {
                // add filter for search
                var aFilters = [];
                var sQuery = oEvent.getSource().getValue();
                // var sQuery = oEvent.getParameter("query");
                var oList = this.byId("table");
                var oBinding = oList.getBinding("items");
                if (sQuery) {
                    aFilters.push(
                        new sap.ui.model.Filter({ path: "material", operator: sap.ui.model.FilterOperator.Contains, value1: sQuery, caseSensitive: false })
                    );
                    aFilters.push(
                        new sap.ui.model.Filter({ path: "regionScope", operator: sap.ui.model.FilterOperator.Contains, value1: sQuery, caseSensitive: false })
                    );
                    // var filter = new Filter("material", FilterOperator.Contains, sQuery);
                    // aFilters.push(filter);
                    // update list binding
                    oBinding.filter(new sap.ui.model.Filter({
                        filters: aFilters,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBinding.filter([]);
                }
            },
            onSearchPlant: function (oEvent) {
                // add filter for search
                var aFiltersplant = [];
                var sQueryplant = oEvent.getSource().getValue();
                var oListplant = this.byId("tablePlant");
                var oBindingplant = oListplant.getBinding("items");
                if (sQueryplant) {
                     aFiltersplant.push(
                        new sap.ui.model.Filter({ path: "material", operator: sap.ui.model.FilterOperator.Contains, value1: sQueryplant, caseSensitive: false })
                    );
                    aFiltersplant.push(
                        new sap.ui.model.Filter({ path: "plant", operator: sap.ui.model.FilterOperator.Contains, value1: sQueryplant, caseSensitive: false })
                    );
                    // update list binding
                    oBindingplant.filter(new sap.ui.model.Filter({
                        filters: aFiltersplant,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBindingplant.filter([]);
                }
            },
            onSearchSales: function (oEvent) {
                // add filter for search
                var aFiltersSales = [];
                var sQuerySales = oEvent.getSource().getValue();
                var oListSales = this.byId("tableSales");
                var oBindingSales = oListSales.getBinding("items");
                if (sQuerySales) {
                    aFiltersSales.push(
                        new sap.ui.model.Filter({ path: "salesOrg", operator: sap.ui.model.FilterOperator.Contains, value1: sQuerySales, caseSensitive: false })
                    );
                    aFiltersSales.push(
                        new sap.ui.model.Filter({ path: "plant", operator: sap.ui.model.FilterOperator.Contains, value1: sQuerySales, caseSensitive: false })
                    );
                    // update list binding

                    oBindingSales.filter(new sap.ui.model.Filter({
                        filters: aFiltersSales,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBindingSales.filter([]);
                }

            },
            salesTableScenario03:function(value){
              // add filter for search
                var aFiltersSalesDisplay = [];
                var sQuerySalesDisplay = value.phaseOutScenario_id;
                var oListSalesDisplay = this.byId("tableSales");
                var oBindingSalesDisplay = oListSalesDisplay.getBinding("items");
                if (sQuerySalesDisplay === "Scenario03") {
                    // aFiltersSales.push(
                    //     new sap.ui.model.Filter({ path: "salesOrg", operator: sap.ui.model.FilterOperator.Contains, value1: sQuerySales, caseSensitive: false })
                    // );
                    aFiltersSalesDisplay.push(
                        new sap.ui.model.Filter({ path: "phaseOutNEEDED", operator: sap.ui.model.FilterOperator.Contains, value1: 'Yes', caseSensitive: false })
                    );
                    // update list binding

                    oBindingSalesDisplay.filter(new sap.ui.model.Filter({
                        filters: aFiltersSalesDisplay,
                        and: false
                    }));
                } else {
                    // update list binding
                    oBindingSalesDisplay.filter([]);
                }

            }

        });
    });
