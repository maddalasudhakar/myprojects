/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "projectdashboard/model/models",
    "sap/ui/model/json/JSONModel"
],
function (UIComponent, Device, models,JSONModel) {
    "use strict";

    return UIComponent.extend("projectdashboard.Component", {
        metadata: {
            manifest: "json"
        },

        /**
         * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
         * @public
         * @override
         */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);

            // enable routing
            this.getRouter().initialize();
            this.getModel().callFunction("/userAuth",{
                success: function(odata)
                {
                    this.setModel(new JSONModel(odata.userAuth),"userAuth");
                }.bind(this),
                error: function(oError)
                {
                  sap.m.MessageBox.error(oError);
                }.bind(this)
            });
            // set the device model
            this.setModel(models.createDeviceModel(), "device");
            // set local model
            this.setModel(models.createLocalModel(), "LocalDataModel");
        }
    });
}
);