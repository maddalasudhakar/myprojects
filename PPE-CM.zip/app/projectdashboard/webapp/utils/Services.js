/**
 * Services file
 *
 */
sap.ui.define([
    "jquery.sap.global"
],
    function (jquery) {
        "use strict";
        return {

            getRequest: function (that, entity, resolve) {
                var sServiceURL = that.getOwnerComponent().getModel().sServiceUrl;

                $.ajax({
                    type: "GET",
                    url: sServiceURL + "/" + entity,
                    success: function (response, status, xhr) {
                        if (response.d) {
                            var data = response.d.results;

                            resolve(data);
                        } else {
                            var data = response;
                            resolve(data);
                        }
                    },
                    error: function (error) {
                        var err = JSON.parse(error.responseText);
                        resolve(err)

                    }
                });

            }

        };

    });