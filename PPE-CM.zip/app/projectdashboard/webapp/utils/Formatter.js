/**
 * Formatter
 *
 */

// @ts-ignore
sap.ui.define([], function () {
    "use strict";

    const Formatter = {
        /**
         * Formatter to remove leading zeros
         * @param {string} sValue - The input value to format
         * @returns {string} - The formatted value with no leading zeros
         */
        removeLeadingZeros: function (sValue) {
            if (!sValue) {
                return sValue;
            }
            // Use regular expression to remove leading zeros
            return sValue.replace(/^0+/, '');
        },
        formatDate: function (sDate) {
          if (!sDate) return null;
            if(typeof(sDate) != 'object'){
                let timestamp = sDate.replace('/Date(', '').replace(')/', '');
                let date = new Date(parseInt(timestamp, 10));
                let oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "yyyy-MM-dd"
                });
                return oDateFormat.format(date);
            }else{
                let oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                    pattern: "yyyy-MM-dd"
                });
                return oDateFormat.format(sDate);
            }
        },     
        isDeleteButtonVisible: function (material) {
            // let oList = this.getView().byId("myTable").getItems();

            // let oList = this.getView().byId("myTable").getModel("IDHModel").getData().IDHRegion;

            // // let materialSet = new Set();

            // for (let i = 0; i < oList.length; i++) {
            //     let itemMaterial = this.getView().byId("myTable").getModel("IDHModel").getData().IDHRegion[i].material;
            //     if (itemMaterial == material && this.getView().getModel("DeleteModel").getData().deleteButton.includes(itemMaterial)) {
            //         return false;
            //     } else {
            //         // materialSet.add(itemMaterial);

            //         this.getView().getModel("DeleteModel").getData().deleteButton.push(itemMaterial);
            //     }
            // }
            // return true;

            if( this.getView().getModel("DeleteModel").getData().deleteButton.includes(material)) {
                return false;
            } else {
                this.getView().getModel("DeleteModel").getData().deleteButton.push(material);
                return true;
            }
        }        
    };

    return Formatter;

}, true);