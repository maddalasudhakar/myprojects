using SupplyPlannerSummaryService as service from '../../srv/sm-supply-planner';
//annotate service.RpSupplyPlanner with@odata.draft.bypass;
annotate service.RpSupplyPlanner with @(
    UI: {
        SelectionFields : [
            plant,
            mrpController,
            email
        ],
        LineItem : [
            {
                $Type : 'UI.DataField',
                Label : '{i18n>plant}',
                Value : plant,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>mrpController}',
                Value : mrpController,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>mrpControllerText}',
                Value : mrpControllerText,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>email}',
                Value : email,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>responsible}',
                Value : responsible,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>region}',
                Value : region,
                ![@HTML5.CssDefaults]: {width: '100%'}
            },
            {
                $Type : 'UI.DataField',
                Label : '{i18n>remarks}',
                Value : remarks,
                ![@HTML5.CssDefaults]: {width: '100%'}
            }
        ],
    }
){
    plant @Common.Label : '{i18n>plant}';
    mrpController @Common.Label : '{i18n>mrpController}';
    mrpControllerText @Common.Label : '{i18n>mrpControllerText}';
    email @Common.Label : '{i18n>email}';
    responsible @Common.Label : '{i18n>responsible}';
    region @Common.Label : '{i18n>region}';
    remarks @Common.Label : '{i18n>remarks}';
    IsActiveEntity @UI.HiddenFilter;
    HasActiveEntity @UI.HiddenFilter;
    HasDraftEntity @UI.HiddenFilter;
    IsActiveEntity @UI.Hidden;
    HasActiveEntity @UI.Hidden;
    HasDraftEntity @UI.Hidden;
};

