sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";
        sap.ui.loader.config({
            paths: {
              "cc/spreadsheetimporter/v2_1_0": "https://cdn.jsdelivr.net/npm/ui5-cc-spreadsheetimporter@1.7.3/dist"
            }
          });        
        return Component.extend("mrpcmatrix.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);