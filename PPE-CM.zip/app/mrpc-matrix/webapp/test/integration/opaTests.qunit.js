sap.ui.require(
    [
        'sap/fe/test/JourneyRunner',
        'mrpcmatrix/test/integration/FirstJourney',
		'mrpcmatrix/test/integration/pages/RpSupplyPlannerList',
		'mrpcmatrix/test/integration/pages/RpSupplyPlannerObjectPage'
    ],
    function(JourneyRunner, opaJourney, RpSupplyPlannerList, RpSupplyPlannerObjectPage) {
        'use strict';
        var JourneyRunner = new JourneyRunner({
            // start index.html in web folder
            launchUrl: sap.ui.require.toUrl('mrpcmatrix') + '/index.html'
        });

       
        JourneyRunner.run(
            {
                pages: { 
					onTheRpSupplyPlannerList: RpSupplyPlannerList,
					onTheRpSupplyPlannerObjectPage: RpSupplyPlannerObjectPage
                }
            },
            opaJourney.run
        );
    }
);