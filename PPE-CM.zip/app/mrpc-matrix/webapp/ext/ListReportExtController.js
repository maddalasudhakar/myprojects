sap.ui.define(["sap/m/MessageToast"], function (MessageToast) {
	"use strict";
	return {
		/**
		 * Create Dialog to Upload Spreadsheet and open it
		 * @param {*} oEvent
		 */
        openSpreadsheetUploadDialog : async function(){
            this.editFlow.getView().setBusyIndicatorDelay(0);
            this.editFlow.getView().setBusy(true);
            this.spreadsheetUpload = await this.editFlow.getView()
              .getController()
              .getAppComponent()
              .createComponent({
                usage: "spreadsheetImporter",
                async: true,
                componentData: {
                  context: this,
                  tableId: "mrpcmatrix::RpSupplyPlannerList--fe::table::RpSupplyPlanner::LineItem-innerTable"
                },
                url: "/sap/bc/ui5_ui5/sap/Z_XUP_v0_33_2",
                name: "cc.spreadsheetimporter.v2_1_0"
              });
            this.spreadsheetUpload.openSpreadsheetUploadDialog();
            this.editFlow.getView().setBusy(false);
        },

        openSpreadsheetUploadDialogTableUpdate: async function (oEvent) {
          this.spreadsheetUploadUpdate = await this.editFlow.getView().getController().getAppComponent()
          .createComponent({
            usage: "spreadsheetImporter",
            async: true,
            componentData: {
              context: this,
              tableId: "mrpcmatrix::RpSupplyPlannerList--fe::table::RpSupplyPlanner::LineItem-innerTable",
              action: "UPDATE",
              updateConfig: {
                fullUpdate: false
              },
              deepDownloadConfig: {
                addKeysToExport: true,
                showOptions: false
              },
              showDownloadButton: true,
              tableId: "mrpcmatrix::RpSupplyPlannerList--fe::table::RpSupplyPlanner::LineItem-innerTable",
              columns: ["plant", "mrpController","mrpControllerText","email","responsible","region","remarks"],
              mandatoryFields: ["plant", "mrpController"]
            }
          });
          this.spreadsheetUploadUpdate.openSpreadsheetUploadDialog();
        },
        openSpreadsheetUpdateDialog: async function (oEvent) {
          this.spreadsheetUpload = await this.editFlow.getView().getController().getAppComponent()
          .createComponent({
            usage: "spreadsheetImporter",
            async: true,
            componentData: {
              context: this,
              tableId: "mrpcmatrix::RpSupplyPlannerList--fe::table::RpSupplyPlanner::LineItem-innerTable",
              action: "UPDATE",
              updateConfig: {
                fullUpdate: false
              },
            }
          });
          this.spreadsheetUpload.openSpreadsheetUploadDialog();
        }
    
    }
});

