sap.ui.define([
	"supportplugin/test/unit/controller/App.controller"
], function () {
	"use strict";
});
