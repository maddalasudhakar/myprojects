sap.ui.define([
    "sap/ui/core/UIComponent",
    "supportplugin/model/models",
	"sap/m/Button",
	"sap/ushell/Container"
], (UIComponent, models, Button, Container) => {
    "use strict";

    return UIComponent.extend("supportplugin.Component", {
        metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: async function () {
			UIComponent.prototype.init.apply(this, arguments);
			// Inject custom CSS manually
			jQuery.sap.includeStyleSheet(
				sap.ui.require.toUrl("supportplugin/css/style.css")
			);
			// Get the i18n resource bundle
			let oResourceBundle = this.getModel("i18n").getResourceBundle();
			const Extension = await Container.getServiceAsync("Extension");
			let rendererPromise = await Extension.createHeaderItem({
					icon: "sap-icon://headset",
					ariaHaspopup : "dialog",
					text : oResourceBundle.getText("Support"),
					tooltip : oResourceBundle.getText("Support"),
					press: (e) => {
						let oSharepointLink = new sap.m.Link({
							text: oResourceBundle.getText("PromptManual"),
							icon : "sap-icon://excel-attachment",
							href: oResourceBundle.getText("sharePointLink"),
							target: "_blank" // Opens in new tab
						});

						let oLinkTeams = new sap.m.Link({
							text: oResourceBundle.getText("PromptTeams"),
							icon : "sap-icon://meeting-room",
							href: oResourceBundle.getText("teamsLink"),
							target: "_blank" // Opens in new tab
						});
						oLinkTeams.addStyleClass("sapUiTinyMarginBottom");

						let oMailButton = new sap.m.Link({
							text: oResourceBundle.getText("promptContact"),
							icon : "sap-icon://email",
							press : this.onSendEmail
						});
						oMailButton.addStyleClass("sapUiTinyMarginBottom");
						
						let oVBox = new sap.m.VBox({
							items: [oMailButton, oLinkTeams, oSharepointLink],
							layoutData: new sap.m.FlexItemData({
								growFactor: 3, // Allows it to expand
								shrinkFactor: 0, // Prevents shrinking
								baseSize: "300px" // Minimum width
							})
						});

						oVBox.addStyleClass("sapUiSmallMargin");

						let oContentLayout = new sap.m.FlexBox({
							width: "100%",
							direction: "Row",
							items: [oVBox]
						});
						let oDialog = new sap.m.Dialog({
							id: "dialogID",
							title: oResourceBundle.getText("promptTitle"),
							contentWidth: "30%",
							contentHeight: "130px",
							resizable: true,
							draggable: true,
							content: [oContentLayout],
							beginButton: new Button({
								text: "Close",
								press: function () {
									oDialog.close();
								}
							}),
							afterClose: function () {
								oDialog.destroy();
							}
						});
						oDialog.open();
					}
			}, {
				position : "end"
			});
			rendererPromise.showForAllApps();
			rendererPromise.showOnHome();
			
            const FrameBoundExtension = await Container.getServiceAsync("FrameBoundExtension");

           

			this.getModel().callFunction("/statusCheckForBackendSystem",{
                success: async function(odata){
                    if(odata.statusCheckForBackendSystem){
						const SubHeader = await FrameBoundExtension.createSubHeader({
							id: "subheader1",
							contentMiddle: [
								new sap.m.HBox({
									class: "myMarquee",
									width:"100%",
									items: [
									  new sap.ui.core.Icon({
										src: "sap-icon://alert", // use any icon name
										size: "1.2rem",
										color: "#ff7a00"
									  }).addStyleClass("clIconStyle"),
									  new sap.m.Text({
										text: odata.statusCheckForBackendSystem,
										wrapping: false,
										class : "clTextStyle"
									  }).addStyleClass("clTextStyle"),
									],
									alignItems: "Center",
									spacing: "0.5rem"
								}).addStyleClass("myMarquee")
							]
							
						}, {
							controlType: "sap.m.Bar"
						});
						SubHeader.showOnHome();
					}
                }.bind(this),
                error: function(oError)
                {
                  sap.m.MessageBox.error(oError);
                }.bind(this)
            });
            
		},
		onSendEmail : function(){
			sap.m.URLHelper.triggerEmail("PROMPT-SUPPORT@henkel.com", "", "");
		}
	});
});