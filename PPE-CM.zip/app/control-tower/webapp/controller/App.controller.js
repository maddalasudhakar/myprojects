sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("control-tower.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  