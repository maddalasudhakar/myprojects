sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
],

    function (Controller, ODataModel, Filter, FilterOperator) {
        "use strict";

        return Controller.extend("control-tower.controller.ControlTower", {
            onInit: function () {
    
            },

            onSmartTableInitialized: function() {
                this.getView().byId("smartTable").rebindTable();
            },
            onSmartFilterInitialized: function () {
                let startupParams = this.getOwnerComponent().getComponentData().startupParameters;
                if ((startupParams.projectID && startupParams.projectID[0])) {
                    const oSmartFilterBar = this.getView().byId("smartFilterBar");
                    let oFilterData = {};
                    oFilterData.projectID = startupParams.projectID[0];
                    oSmartFilterBar.setFilterData(oFilterData, true);
                }
            },
            onBeforeRebindTable: function (oEvent) {
                var oBindingParams = oEvent.getParameter("bindingParams");

                if(oBindingParams.filters.length === 0)
                    oBindingParams.preventTableBind = true;
                else
                    oBindingParams.preventTableBind = false;

                if (!oBindingParams.sorter.length) {
                    oBindingParams.sorter.push(new sap.ui.model.Sorter("material", false));
                }
            }
        });
    });
