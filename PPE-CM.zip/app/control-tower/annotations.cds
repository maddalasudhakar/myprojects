using ControlTower as ct from '../../srv/sm-control-tower';

//Project ID Mandatory
annotate ct.ControlTower with @(
    Capabilities.FilterRestrictions: {
        $Type                       : 'Capabilities.FilterRestrictionsType',
        RequiredProperties          : [projectID],
        FilterExpressionRestrictions: [{
            $Type             : 'Capabilities.FilterExpressionRestrictionType',
            AllowedExpressions: 'SingleValue',
            Property          : 'projectID',
        }, ]
    },

    //Selection fields
    UI.SelectionFields             : [
        projectID,
        material,
    ],

    //Table fields
    UI.LineItem                    : [
        {
            $Type                : 'UI.DataField',
            Value                : projectID,
            Label                : '{i18n>projectID}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : projectDescription,
            Label                : '{i18n>projectDescription}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : material,
            Label                : '{i18n>material}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : materialText,
            Label                : '{i18n>materialText}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : subsMaterial,
            Label                : '{i18n>subsMaterial}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : subsMaterialText,
            Label                : '{i18n>subsMaterialText}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : plant,
            Label                : '{i18n>plant}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : plantName,
            Label                : '{i18n>plantName}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : plantStatus,
            Label                : '{i18n>plantStatus}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : pValidFrom,
            Label                : '{i18n>pValidFrom}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : salesOrg,
            Label                : '{i18n>salesOrg}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : distChannel,
            Label                : '{i18n>distChannel}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : salesOrgStatus,
            Label                : '{i18n>salesOrgStatus}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : sValidFrom,
            Label                : '{i18n>sValidFrom}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : makeToStrategy,
            Label                : '{i18n>makeToStrategy}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : mrpController,
            Label                : '{i18n>mrpController}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : mrpControllerEmail,
            Label                : '{i18n>mrpControllerEmail}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : ctPlanner,
            Label                : '{i18n>ctPlanner}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

             {
            $Type                : 'UI.DataField',
            Value                : ctPlannerEmail,
            Label                : '{i18n>ctPlannerEmail}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : steeringUnitDesc,
            Label                : '{i18n>steeringUnitDesc}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        // {
        //     $Type                : 'UI.DataField',
        //     Value                : totalActiveValue,
        //     Label                : '{i18n>totalActiveValue}',
        //     ![@HTML5.CssDefaults]: {width: 'auto'}
        // },

        {
            $Type                : 'UI.DataField',
            Value                : buom,
            Label                : '{i18n>buom}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : sellableStock,
            Label                : '{i18n>sellableStock}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : openOrderQuantity,
            Label                : '{i18n>openOrderQuantity}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : openPoQuantity,
            Label                : '{i18n>openPoQuantity}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : openPoQuantityBuom,
            Label                : '{i18n>openPoQuantityBuom}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },

        {
            $Type                : 'UI.DataField',
            Value                : balanceOpenOrder,
            Label                : '{i18n>balanceOpenOrder}',
            ![@HTML5.CssDefaults]: {width: 'auto'}
        },
    ],
) {
    projectID    @(Common: {
        Label    : '{i18n>projectID}',
        ValueList: {
            SearchSupported: true,
            CollectionPath : 'ProjectHeaders',
            Parameters     : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: projectID,
                    ValueListProperty: 'projectID'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'projectDescription'
                }
            ]
        },
    });

    material     @(Common: {
        Label    : '{i18n>material}',
        ValueList: {
            SearchSupported        : true,
            CollectionPath         : 'MatValList',
            DistinctValuesSupported: true,
            Parameters             : [
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: projectID,
                    ValueListProperty: 'projectID'
                },
                {
                    $Type            : 'Common.ValueListParameterInOut',
                    LocalDataProperty: material,
                    ValueListProperty: 'material'
                },
                {
                    $Type            : 'Common.ValueListParameterDisplayOnly',
                    ValueListProperty: 'materialText'
                }
            ]
        },
    });
    sourceSystem @UI.Hidden;
}
