## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Sat Apr 12 2025 09:48:10 GMT+0530 (India Standard Time)|
|**App Generator**<br>@sap/generator-fiori-freestyle|
|**App Generator Version**<br>1.12.2|
|**Generation Platform**<br>Visual Studio Code|
|**Template Used**<br>simple|
|**Service Type**<br>None|
|**Service URL**<br>N/A
|**Module Name**<br>agent-ui|
|**Application Title**<br>ReMaP Agent|
|**Namespace**<br>|
|**UI5 Theme**<br>sap_horizon_dark|
|**UI5 Version**<br>1.134.1|
|**Enable Code Assist Libraries**<br>True|
|**Enable TypeScript**<br>False|
|**Add Eslint configuration**<br>True, see https://www.npmjs.com/package/eslint-plugin-fiori-custom for the eslint rules.|

## agent-ui

An SAP Fiori application.

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```

#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


