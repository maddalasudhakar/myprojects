sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ushell/Container",
    "sap/ushell/services/UserInfo",
    "sap/m/Dialog",
    "sap/m/Toolbar",
    "sap/m/FeedInput",
    "sap/m/CustomListItem",
    "sap/m/Label",
    "sap/m/LabelDesign",
    "sap/m/Bar",
    "sap/m/Button",
    "sap/ui/core/Icon",
    "sap/m/VBox",
    "sap/m/MessageBox",
    "sap/m/List",
    "sap/m/HBox",
    "sap/ui/core/HTML",
    "sap/m/Text",
    "sap/m/Panel",
    "sap/m/Link",
    "sap/f/Card",
    "chart.js/auto"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, Container, UserInfo, Dialog, Toolbar, FeedInput, CustomListItem, Label, LabelDesign, Bar, Button, Icon, VBox, MessageBox, List, HBox, HTML, Text, Panel, Link, Card, Chart) {
        "use strict";

        return Controller.extend("agentui.controller.AgentUi", {

            agentPlugin: async function (oComponent, oManifest) {

                const oExtension = await Container.getServiceAsync("Extension");
                const that = this;

                const oHeader = await oExtension.createHeaderItem({
                    id: "agentBtn",
                    ariaHaspopup: "dialog",
                    icon: "sap-icon://da-2",
                    tooltip: "ReMaP Agent",
                    press: () => {

                        new Dialog({
                            draggable: true,
                            contentWidth: "90%",
                            contentHeight: "80%",
                            resizable: true,
                            content: [
                                new VBox({
                                    items: [
                                        new List({
                                            showSeparators: "Inner",
                                            items: {
                                                path: "/conversations",
                                                template: new CustomListItem({
                                                    content: [
                                                        new HBox({
                                                            items: [
                                                                new HBox({
                                                                    items: [
                                                                        new Icon({
                                                                            src: "{= ${role} === 'assistant' ? 'sap-icon://da-2' : 'sap-icon://user-edit'}"
                                                                        }).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTopBottom"),
                                                                        new Link({
                                                                            accessibleRole: 'Button',
                                                                            emphasized: true,
                                                                            text: "{= ${role} === 'assistant' ? 'ReMaP Agent:' : 'me:'}"
                                                                        }).addStyleClass("sapUiSmallMarginBegin").addStyleClass("sapUiSmallMarginTopBottom"),
                                                                        new VBox({
                                                                            items: [
                                                                                new Text({
                                                                                    visible: "{= ${sresult} !== '' ? true : false}",
                                                                                    text: "{sresult}"
                                                                                }),
                                                                                new Panel({
                                                                                    headerText: "Sources / Reasoning",
                                                                                    width: "100%",
                                                                                    backgroundDesign: "Solid",
                                                                                    visible: "{= ${spanelresult} !== '' ? true : false}",
                                                                                    expandable: true,
                                                                                    content: [
                                                                                        new Text({
                                                                                            text: "{spanelresult}"
                                                                                        })
                                                                                    ]
                                                                                }).addStyleClass("sapUiResponsiveMargin"),
                                                                                new Card({
                                                                                    visible: "{= ${htmlresult} !== '' ? true : false}",
                                                                                    content: [
                                                                                        new HTML({
                                                                                            content: "{htmlresult}"
                                                                                        })
                                                                                    ]
                                                                                })
                                                                            ]
                                                                        }).addStyleClass("sapUiSmallMarginTopBottom").addStyleClass("sapUiSmallMarginBegin")
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                templateShareable: false
                                            }
                                        }
                                        )]
                                })
                            ],
                            footer: [
                                new Toolbar({
                                    height: "100px",
                                    content: [
                                        new FeedInput({
                                            icon: "sap-icon://user-edit",
                                            placeholder: "Type here, if you want to find answers to your CQT analytical queries or create a new CQT request",
                                        }).attachPost({ oComponent, oManifest }, that.startAgent, that)
                                    ]
                                })
                            ],
                            customHeader: new Bar({
                                contentLeft: [
                                    new Icon({
                                        src: "sap-icon://da-2"
                                    }).addStyleClass("size3"),
                                    new Label({
                                        design: LabelDesign.Bold,
                                        text: "ReMaP Agent"
                                    })
                                ],
                                contentRight: [
                                    new Button({
                                        icon: "sap-icon://decline",
                                        press: (oEvent) => {
                                            oEvent.getSource().getParent().getParent().close();
                                        }
                                    })
                                ]
                            })
                        }).setModel(oComponent.getModel()).open();
                    }
                }, {
                    position: "end"
                });

                oHeader.showOnHome();
            },

            startAgent: async function (oEvent, oArgs) {

                let sValue = oEvent.getParameters().value;

                oArgs.oComponent.getModel().getData().conversations.push({
                    role: "user",
                    sresult: sValue,
                    spanelresult: "",
                    htmlresult: ""
                });

                oArgs.oComponent.getModel().refresh();

                oEvent.getSource().getParent().getParent().getContent()[0].getItems()[0].setBusy(true);
                const sPingUrl = oArgs.oManifest.resolveUri("remapagent/ping");
                const sUrl = oArgs.oManifest.resolveUri("remapagent/startAgent");
                const oPayload = {
                    userPrompt: sValue
                };

                let oResponse = await fetch(sPingUrl, {
                    method: "GET",
                    headers: {
                        "X-CSRF-Token": "Fetch"
                    }
                });

                $.ajax({
                    url: sUrl,
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-Token": oResponse.headers.get("X-CSRF-Token")
                    },
                    data: JSON.stringify(oPayload),
                    success: (oData) => {
                        let sResult = "", sHtmlResult = "";

                        // pull the last content from history for html visualization or the creation html link
                        if (Object.keys(oData).includes("history")) {
                            if (oData.history.at(-1).parts[0].text.indexOf("<!DOCTYPE html>") >= 0) {
                                const iHtmlStart = oData.history.at(-1).parts[0].text.indexOf("<!DOCTYPE html>");
                                const iHtmlEnd = oData.history.at(-1).parts[0].text.indexOf("</html>");
                                sHtmlResult = `${oData.history.at(-1).parts[0].text.substring(iHtmlStart, iHtmlEnd + 7)}`;
                                if (oData.history.length > 2) {
                                    oData.history.forEach((result, index) => {

                                        if (index > 0) {
                                            sResult += result.parts[0].text + "\n";
                                        }
                                    });
                                } else {
                                    sResult += oData.history.at(-1).parts[0].text;
                                }
                            } else if (oData.history.at(-1).parts[0].text.indexOf("<html>") >= 0) {
                                const iHtmlStart = oData.history.at(-1).parts[0].text.indexOf("<html>");
                                const iHtmlEnd = oData.history.at(-1).parts[0].text.indexOf("</html>");
                                sHtmlResult = `${oData.history.at(-1).parts[0].text.substring(iHtmlStart, iHtmlEnd + 7)}`;
                                if (oData.history.length > 2) {
                                    oData.history.forEach((result, index) => {

                                        if (index > 0) {
                                            sResult += result.parts[0].text + "\n";
                                        }
                                    });
                                } else {
                                    sResult += oData.history.at(-1).parts[0].text;
                                }
                            } else if (oData.history.at(-1).parts[0].text.indexOf("<html lang=\"en\">") >= 0) {
                                const iHtmlStart = oData.history.at(-1).parts[0].text.indexOf("<html lang=\"en\">");
                                const iHtmlEnd = oData.history.at(-1).parts[0].text.indexOf("</html>");
                                sHtmlResult = `${oData.history.at(-1).parts[0].text.substring(iHtmlStart, iHtmlEnd + 7)}`;
                                if (oData.history.length > 2) {
                                    oData.history.forEach((result, index) => {
                                        if (index > 0) {
                                            sResult += result.parts[0].text + "\n";
                                        }
                                    });
                                } else {
                                    sResult += oData.history.at(-1).parts[0].text;
                                }
                            } else {
                                sResult += oData.history.at(-1).parts[0].text;
                                sHtmlResult = oData.history.at(-1).parts[0].text;
                            }
                        } else {
                            sResult += oData.summary;
                            sHtmlResult += oData.summary;
                        }


                        // does body contains script?
                        if (sHtmlResult.indexOf("<body>") >= 0) {
                            const iBodyStart = sHtmlResult.indexOf("<body>");
                            const iBodyEnd = sHtmlResult.indexOf("</body>");
                            let sHtmlBody = sHtmlResult.substring(iBodyStart + 6, iBodyEnd);
                            let sHtmlScript = "";

                            if(sHtmlBody.includes("<script")) {
                                const iScriptStart = sHtmlBody.indexOf("<script");
                                const iScriptEnd = sHtmlBody.indexOf("</script>");
                                sHtmlScript = sHtmlBody.substring(iScriptStart, iScriptEnd + 9);
                                sHtmlBody = sHtmlBody.substring(0, iScriptStart) + sHtmlBody.substring(iScriptEnd + 9);
                            } else {
                                const iHeadStart = sHtmlResult.indexOf("<head>");
                                const iHeadEnd = sHtmlResult.indexOf("</head>");
                                let sHtmlHead = sHtmlResult.substring(iHeadStart + 6, iHeadEnd);

                                if(sHtmlHead.includes("<script")) {
                                    const iScriptStart = sHtmlHead.indexOf("<script");
                                    const iScriptEnd = sHtmlHead.indexOf("</script>");
                                    sHtmlScript = sHtmlHead.substring(iScriptStart, iScriptEnd + 9);
                                }
                            }

                            sHtmlResult = `<div>${sHtmlBody}</div>${sHtmlScript}`;
                        } else {
                            sHtmlResult = `<div><p>${sHtmlResult}</p></div>`;
                        }

                        // package script inside a function to be compliant with async loading and also same variable names
                        if (sHtmlResult.indexOf("<script") >= 0) {
                            const iScriptStart = sHtmlResult.indexOf("<script");
                            const iScriptEnd = sHtmlResult.indexOf("</script>");
                            sHtmlResult = sHtmlResult.substring(0, iScriptStart) + "<script>(function(){" + sHtmlResult.substring(iScriptStart + 9, iScriptEnd) + "})();" + sHtmlResult.substring(iScriptEnd);
                        }

                        oArgs.oComponent.getModel().getData().conversations.push({
                            role: oData.role,
                            sresult: "",
                            spanelresult: sResult,
                            htmlresult: sHtmlResult
                        });

                        oArgs.oComponent.getModel().refresh();

                        oEvent.getSource().getParent().getParent().getContent()[0].getItems()[0].setBusy(false);
                    },
                    error: (error) => {
                        oEvent.getSource().getParent().getParent().getContent()[0].getItems()[0].setBusy(false);
                        MessageBox.error(error);
                    }
                });
            }
        });
    });
