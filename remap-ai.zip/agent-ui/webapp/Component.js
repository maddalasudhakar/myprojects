/**
 * eslint-disable @sap/ui5-jsdocs/no-jsdoc
 */

sap.ui.define([
        "sap/ui/core/UIComponent",
        "sap/ui/Device",
        "agentui/model/models",
        "agentui/controller/AgentUi.controller",
        "sap/ui/model/json/JSONModel",
        "chart.js/auto",
        "d3",
        "plotly.js-dist-min/plotly.min"
    ],
    function (UIComponent, Device, models, AgentController, JSONModel, Chart, d3, Plotly) {
        "use strict";

        return UIComponent.extend("agentui.Component", {
            metadata: {
                manifest: "json"
            },

            /**
             * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
             * @public
             * @override
             */
            init: async function () {

                window.Chart = Chart;
                window.d3 = d3;
                window.Plotly = Plotly;

                // call the base component's init function
                UIComponent.prototype.init.apply(this, arguments);

                let conversations = [];

                conversations.push({
                    role: "assistant",
                    sresult: `Hello, I am ready to perform any ReMaP related tasks.
                                
                                Currently supported tasks:
                                - Answering CQT analytical questions with a sutiable visual wherever possible
                                - Search any CQT request with specific conditions and find out status
                                - Creating a CQT request
                                
                                Upcoming capabilities:
                                - Answering any ReMaP analytical question
                                - Creating or Updating any ReMaP request
                                - Search any ReMaP request
                                
                                How can I help you now?`
                                ,
                    spanelresult: "",
                    htmlresult: ""
                });
                
                let oModel = new JSONModel({conversations: conversations});

                this.setModel(oModel);

                await new AgentController().agentPlugin(this,this.getManifestObject());

                // enable routing
                this.getRouter().initialize();

                // set the device model
                this.setModel(models.createDeviceModel(), "device");
            }
        });
    }
);