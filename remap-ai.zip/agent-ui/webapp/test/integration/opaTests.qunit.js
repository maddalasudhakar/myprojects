/* global QUnit */

sap.ui.require(["agentui/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
