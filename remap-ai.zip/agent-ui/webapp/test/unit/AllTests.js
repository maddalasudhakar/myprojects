sap.ui.define([
	"agent-ui/test/unit/controller/AgentUi.controller"
], function () {
	"use strict";
});
