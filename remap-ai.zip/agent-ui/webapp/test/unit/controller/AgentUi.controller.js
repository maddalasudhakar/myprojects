/*global QUnit*/

sap.ui.define([
	"agent-ui/controller/AgentUi.controller"
], function (Controller) {
	"use strict";

	QUnit.module("AgentUi Controller");

	QUnit.test("I should test the AgentUi controller", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
