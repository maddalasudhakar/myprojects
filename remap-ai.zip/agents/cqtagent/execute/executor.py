from a2a.server.agent_execution import AgentExecutor, RequestContext
from a2a.server.events import EventQueue
from a2a.server.tasks import TaskUpdater
from a2a.utils import new_task, new_agent_text_message
from a2a.utils.errors import ServerError
from a2a.types import (
    UnsupportedOperationError, 
    InvalidParamsError, 
    InternalError, 
    Part, 
    TextPart,
    TaskState
)
from define.agent import CqtAgent
from cfenv import AppEnv
from sap import xssec
import logging

logger = logging.getLogger(__name__)
class CqtExecutor(AgentExecutor):
    """ Customer Request or Customer Query tool Agent for analyzing historical requests/queries for driving data based decisions or 
        creating new customer requests """
    
    def __init__(self):
        self.agent = CqtAgent()

    async def execute(self, context: RequestContext, event_queue: EventQueue):
        error = self._validate_request(context)
        if error:
            raise ServerError(error=InvalidParamsError())

        query = context.get_user_input()
        task = context.current_task
        accessToken = context.call_context.state["headers"]["authorization"][7:]

        env = AppEnv()
        uaaService = env.get_service(name='remap-xsuaa-service').credentials
        securityContext = xssec.create_security_context(accessToken, uaaService)

        if not task:
            task = new_task(context.message)
            await event_queue.enqueue_event(task)
        
        updater = TaskUpdater(event_queue, task.id, task.context_id)
        try:
            async for item in self.agent.stream(query, task.context_id, securityContext.get_email()):
                is_task_complete = item['is_task_complete']
                require_user_input = item['require_user_input']

                if not is_task_complete and not require_user_input:
                    await updater.update_status(
                        TaskState.working,
                        new_agent_text_message(
                            item['content'],
                            task.context_id,
                            task.id,
                        ),
                    )
                elif require_user_input:
                    await updater.update_status(
                        TaskState.input_required,
                        new_agent_text_message(
                            item['content'],
                            task.context_id,
                            task.id,
                        ),
                        final=True,
                    )
                    break
                else:
                    await updater.add_artifact(
                        [Part(root=TextPart(text=item['content']))],
                        name='conversion_result',
                    )
                    await updater.complete()
                    break

        except Exception as e:
            logger.error(f'An error occurred while streaming the response: {e}')
            raise ServerError(error=InternalError()) from e
    
    def _validate_request(self, context: RequestContext) -> bool:
        # validation logic based on the received user context
        return False
    
    async def cancel():
        raise ServerError(error=UnsupportedOperationError())