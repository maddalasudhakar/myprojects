from starlette.applications import Starlette
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse
from cfenv import AppEnv
from sap import xssec
from a2a.types import AgentCard


class RemapHTTPAuthMiddleware(BaseHTTPMiddleware):
    def __init__(self, app:Starlette, agent_card:AgentCard = None, public_paths: list[str] = None):
        super().__init__(app)

        self._agent_card = agent_card
        self._public_paths = set(public_paths or [])
        self._req = None

    async def dispatch(self, request:Request, call_next):
        self._req = request

        # Allow public paths and anonymous access
        if self._req.url.path in self._public_paths or self._agent_card is None or not hasattr(self._agent_card, "securitySchemes"):
            return await call_next(self._req)
        
        if self._req.headers.get("Authorization") is None or not self._req.headers.get("Authorization").startswith("Bearer "):
            return self._unauthorized("You are not authorized to access")

        env = AppEnv()
        uaaService = env.get_service(name='remap-xsuaa-service').credentials
        accessToken = self._req.headers.get("Authorization").replace("Bearer ", "")
        securityContext = xssec.create_security_context(accessToken, uaaService)

        if(not self._req.headers.get("Authorization").startswith("Bearer ") or securityContext.get_clientid() != uaaService["clientid"]):
            return self._unauthorized("You are not authorized to access")
        
        if(not securityContext.check_scope(uaaService["xsappname"] + ".remap-user") and not securityContext.check_scope(uaaService["xsappname"] + ".CQTAgent")):
            return self._forbidden("You are not authorized to access")

        return await call_next(self._req)
    
    def _forbidden(self, reason:str):
        return JSONResponse(
            {'error': 'forbidden', 'reason': reason}, status_code=403
        )

    def _unauthorized(self, reason:str):
        return JSONResponse(
            {'error': 'unauthorized', 'reason': reason}, status_code=401
        )


        
