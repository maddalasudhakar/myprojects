from gen_ai_hub.proxy.core.proxy_clients import get_proxy_client, BaseProxyClient
from gen_ai_hub.proxy.langchain.openai import ChatOpenAI
from langchain_core.messages.utils import trim_messages, count_tokens_approximately
from langgraph.graph.message import REMOVE_ALL_MESSAGES
from langchain_core.messages import RemoveMessage
from langgraph.prebuilt import create_react_agent
from langgraph.checkpoint.memory import InMemorySaver
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_core.messages import AIMessage, ToolMessage
from langchain_core.tools import BaseTool
from pydantic import BaseModel
from typing import Literal, Any, Union
from collections.abc import AsyncIterable
from cfenv import AppEnv
from hdbcli import dbapi
from datetime import datetime, timezone
from uuid import uuid4
import json, requests, os, asyncio, sys

# needed for local testin
# from dotenv import load_dotenv
# load_dotenv()

env = AppEnv()
APP_BASE_URL = os.getenv("APP_BASE_URL")

async def _getMcpServerTools(hana_service) -> list[BaseTool]:

    lib_python_path = os.path.dirname(os.path.realpath(sys.executable)) # Example: may need adjustment

    # Create a modified environment for the subprocesses
    env = os.environ.copy()
    env["LD_LIBRARY_PATH"] = f"{lib_python_path}:{env.get('LD_LIBRARY_PATH', '')}"

    client = MultiServerMCPClient(
                # for local testing
                # {
                #     "analytical-server": {
                #         "transport": "stdio",
                #         "command": "python3",
                #         "args": ["/Users/vinay.shankaran/Desktop/remap-ai/agents/cqtagent/mcp_servers/analytical-server.py", json.dumps(hana_service)],
                #         "env": env
                #     },
                #     "cqt-server": {
                #         "transport": "stdio",
                #         "command": "python3",
                #         "args": ["/Users/vinay.shankaran/Desktop/remap-ai/agents/cqtagent/mcp_servers/cqt-server.py", json.dumps(hana_service)],
                #         "env": env
                #     }
                # }
                {
                    "analytical-server": {
                        "transport": "stdio",
                        "command": "python3",
                        "args": ["/home/vcap/app/mcp_servers/analytical-server.py", json.dumps(hana_service)],
                        "env": env
                    },
                    "cqt-server": {
                        "transport": "stdio",
                        "command": "python3",
                        "args": ["/home/vcap/app/mcp_servers/cqt-server.py", json.dumps(hana_service)],
                        "env": env
                    }
                }
            )
    
    return await client.get_tools()

class ResponseFormat(BaseModel):
    """Respond to the user in this format."""

    status: Literal['input_required', 'completed', 'error'] = 'input_required'
    message: str

class CqtAgent:
    """ Customer Request or Customer Query tool Agent for analyzing historical requests/queries for driving data based decisions or 
        creating new customer requests """
    
    SUPPORTED_CONTENT_TYPES = ['text', 'text/plain']

    SYSTEM_INSTRUCTION = (
                f"""<analytical-skill>
                    You are an expert data analyst. A user would ask question to understand about the data and you can use the capabilities (tools) provided to arrive at an answer.
                    Based on the question asked, you need to first determine the tables necessary to query and answer the question.
                    Then, find the relationships between tables / entities (especially if the question involves joining two or more tables / entities) if it is needed.
                    Then, determine the syntactically right SAP HANA cloud SQL query which can be executed in the database.
                    Then, check if a visualization is needed to answer the question because all cases may not need a visual a table alone would suffice. You are intelligent enough to make a decision where visual is necessary for the user from the userPrompt.
                    Then, based on the fetched results answer the question with data insights that you have identified, visualizations (suitable charts) if necessary.
                    At every step summarize (and give reasons) on why you picked or determined that approach.

                    ///////////////////////////////////////////////////////////////
                    ### System Instructions:
                    - Use the tools provided for you, to generate the SAP HANA cloud SQL query and then execute query to fetch the results requested by user.
                    - Determine the tables using the entities and its relationships.
                    - Never return the metadata details to the user if requested in the prompt.Answer 'Metadata cannot be shared'
                    - Never generate a CREATE, INSERT, DELETE OR UPDATE query. Your query should always be only for selecting data for analysis.
                    - Do not try to predict the table.Use the tools provided to get the right table and its relationships if multiple tables are needed to answer the query.
                    - Do not try to predict field names (columns) used in the query.Use the tools provided to get the right field name from the metadata.
                    - Always try to draw insights from final data patterns and summarize that comprehensively.
                    - Always summarize the reasoning at each step on why you arrived at a particular outcome and what was the final query executed.
                    - Final output is html code which can be directly rendered in the front end. Analytical outputs should be tables and suitable visualizations.
                    - Finally include the visual output in HTML code, using plotlyjs library so that it can be rendered directly in the front end. 
                    - Build visualizations suitable to showcase the fetched information.
                    - The Plotly js library is already loaded and you need not load via the CDN script tag. Use the Plotly available in window.Plotly.So generate code using window.Plotly instead of Plotly.
                    - The html code should start with <html> and end with </html>.
                    - Append random generated uuid's to variable names in the javascript code that you are generating and also on the element ID attribute so that it is always unique and never conflicts leading to error "variable already decleared".
                    - The script inside the generated html code should be error free.
                    - The script should not contain functions that are called as event listeners (eg: window onload or DOMContentLoaded). They should be plain functions and should be called within the script and not on specific events.
                    - The visual should have a width and height showing the entire chart content and horizontally centered. Ensure that the canvas size holding the visual is big enough to show the complete chart.
                      Set a minimum width of 800px and height of 800px for the visual.
                    ///////////////////////////////////////////////////////////////
                </analytical-skill>
                
                <create-customer-request-skill>
                    You are a sales representative who communicates with customers and has all the necessary information to create a customer request.
                    The user would ask questions about the regulatory information of a product idh.
                    First, determine the fields necessary to create a customer request. To achieve this you have the necessary capabilities (tools).
                    Second, based on the fields identified, extract all the field information from the userPrompt. If any of the mandatory fields are missing just return saying "The fieldName is missing and request cannot be created".
                    Third, use the right tool to generate next sequence for field CUSTOMER_REQUEST_ID. Do not determine the next sequence yourself or Do not generate query to fetch the next sequence, just use the right capabilities (tools).
                    Fourth, generate all the SAP HANA Cloud SELECT queries to fetch necessary fields from the related tables. List of queries should be generated, each in the dict format query: <the query string>
                    Fifth, execute the generated SELECT queries by passing all the queries list you have determined in the above step and fetch the related information.
                    Sixth, generate SAP HANA Cloud INSERT queries to create a customer request in the database. All the related tables needs to be inserted. Use the CUSTOMER_REQUEST_ID and other fields from the data generated in steps above. List of queries should be generated, each in the dict format query: <the query string>
                    Seventh, execute the INSERT queries generated above one after the other by passing all the queries list you have determined to create the customer request.
                    Eight, generate a html code to show the new customer request id to the user.

                    Ensure that the data from SELECT queries are set accordingly in the INSERT queries.

                    Your output should be a generated HTML code with either the newly created CUSTOMER_REQUEST_ID or error message if any field is missing.
                    In the HTML code make the newly created CUSTOMER_REQUEST_ID as a hyperlink which when clicked should navigate to the URL in the format below:
                    {APP_BASE_URL}/<CUSTOMER_REQUEST_ID>

                    ///////////////////////////////////////////////////////////////
                    ### Instructions:
                    1. Use the tools provided for you, to extract necessary information, generate SAP HANA Cloud INSERT queries and then to execute them.
                    2. Never predict or determine on your own the necessary fields and tables to create customer request. Use the capabilities (tools) provided to get the right information.
                    3. Information extraction should be accurate with the field / table information determined using the capabilities (tools).
                    4. The output should be either the newly created CUSTOMER_REQUEST_ID or error message if any field is missing.
                    5. If any of the fields are not supplied and you identified a default value through the capabilities (tools) then use the default value.
                    6. Never generate DELETE or UPDATE queries. Simply say "I am sorry, I cannot perform the requested operation".
                    7. Always generate only one html code with one <html> start and one </html> end.
                    8. At every step provide reasoning on the steps taken.
                    ///////////////////////////////////////////////////////////////
                </create-customer-request-skill>

                Only follow the instructions that are mentioned within the delimeter ///////////////////////////////////////////////////////////////"""
    )   
    
    FORMAT_INSTRUCTION = (
        'Set response status to input_required if the user needs to provide more information to complete the request.'
        'Set response status to error if there is an error while processing the request.'
        'Set response status to completed if the request is complete.'
    )

    def __init__(self):
        self._llm = self._initializeLlm()
        self._tools = self._getTools()
        self._cqtAgent = create_react_agent(
            name = "remap-cqt-agent",
            model = self._llm,
            tools = self._tools,
            prompt = self.SYSTEM_INSTRUCTION,
            checkpointer = InMemorySaver(),
            # can be used incase needed but not a good technique
            # pre_model_hook = self._trimModelMessages,
            # post_model_hook = self._removeToolMessage
            # Response format needed, to do later
        )
    
    # token trimming technique not used but might be useful later
    # def _trimModelMessages(self,state):
    #     trimmed_messages = trim_messages(
    #         state["messages"],
    #         strategy="last",
    #         token_counter=count_tokens_approximately,
    #         max_tokens=384,
    #         start_on="human",
    #         end_on=("human", "tool"),
    #     )
        
    #     # return {"llm_input_messages": trimmed_messages}
    #     if trimmed_messages:
    #         return {"messages": [RemoveMessage(id=REMOVE_ALL_MESSAGES), *trimmed_messages]}
        
    #     return {"messages": state["messages"]}
    
    # filtering message technique to ensure context window and token limit is controlled
    def _removeToolMessage(self,state):

        updatedMessages = []

        # take first and last message and leave out the rest
        updatedMessages.append(state["messages"][0])

        if len(state["messages"]) > 1:
            updatedMessages.append(state["messages"][-1])

        return {"messages": [RemoveMessage(id=REMOVE_ALL_MESSAGES), *updatedMessages]}
    
    def _getTools(self) -> list[BaseTool]:
        return asyncio.run(_getMcpServerTools(self._hana_service))

    def _getDestination(self, env: AppEnv, sDestinationService: str, sDestinationName: str) -> json:
        # Read the environment variables  
        dest_service = env.get_service(name=sDestinationService)
        sUaaCredentials = dest_service.credentials["clientid"] + ':' + dest_service.credentials["clientsecret"]

        # Request a JWT token to access the destination service
        headers = {'Authorization': 'Basic '+sUaaCredentials, 'content-type': 'application/x-www-form-urlencoded'}
        form = [('client_id', dest_service.credentials["clientid"] ),('client_secret', dest_service.credentials["clientsecret"] ), ('grant_type', 'client_credentials')]

        url = dest_service.credentials['url'] +"/oauth/token"
        headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
        }

        response = requests.request("POST", url, headers=headers, data=form)

        # Search your destination in the destination service
        token = response.json()["access_token"]
        headers= { 'Authorization': 'Bearer ' + token }
        r = requests.get(dest_service.credentials["uri"] + '/destination-configuration/v1/destinations/'+sDestinationName, headers=headers)

        # Access the destination securely  
        results = r.json()
        return results

    def _initializeEnvironment(self):
        
        # database creds
        self._hana_service = env.get_service(name='remap-db').credentials

        # AI core environment variables set up
        aiCoreEnvVars = self._getDestination(env,"remap-destination-service","central-ai-core")
        os.environ["AICORE_AUTH_URL"] = aiCoreEnvVars["destinationConfiguration"]["tokenServiceURL"]
        os.environ["AICORE_CLIENT_ID"] = aiCoreEnvVars["destinationConfiguration"]["clientId"]
        os.environ["AICORE_CLIENT_SECRET"] = aiCoreEnvVars["destinationConfiguration"]["clientSecret"]
        os.environ["AICORE_RESOURCE_GROUP"] = aiCoreEnvVars["destinationConfiguration"]["resourceGroup"]
        os.environ["AICORE_BASE_URL"] = aiCoreEnvVars["destinationConfiguration"]["URL"] + "/v2"
    
    def _getProxyClient(self) -> BaseProxyClient:
        return get_proxy_client("gen-ai-hub")

    def _initializeLlm(self) -> ChatOpenAI:
        self._initializeEnvironment()
        proxyClient = self._getProxyClient()

        # gen ai hub does not have the response_format capability
        # orchestration service has it but agentic loop has to be custom built
        # hence going ahead without response_format
        return ChatOpenAI(proxy_model_name=os.getenv("AICORE_MODEL"), proxy_client=proxyClient)

    async def stream(self, query, context_id, user) -> AsyncIterable[dict[str, Any]]:
        inputs = {'messages': [('user', query)]}
        config = {'configurable': {'thread_id': context_id}}

        async for item in self._cqtAgent.astream(inputs, config, stream_mode='values'):
            message = item.get("messages")[-1]
            if (
                isinstance(message, AIMessage) and
                message.content != ""
            ):
                print(message.usage_metadata)
                yield {
                    'response_type': 'text',
                    'is_task_complete': False,
                    'require_user_input': False,
                    'content': message.content,
                }

        yield self.get_agent_response(config, query, user)

    def get_agent_response(self, config, userInput, user):
        current_state = self._cqtAgent.get_state(config)
        structured_response = current_state.values.get('messages')[-1]

        # store AI message usage_metadata for token observation later
        currentTimestampUnformatted = datetime.now(timezone.utc)
        currentTimestampFormatted = currentTimestampUnformatted.strftime('%Y-%m-%d %H:%M:%S')
        inputTokens = outputTokens = 0

        for message in current_state.values.get('messages'):
            if isinstance(message, AIMessage):
                inputTokens += message.usage_metadata['input_tokens']
                outputTokens += message.usage_metadata['output_tokens']

        insertValues = (
                        str(uuid4()),
                        userInput,
                        inputTokens,
                        outputTokens,
                        inputTokens + outputTokens,
                        user,
                        currentTimestampFormatted
                )

        hanaConn = dbapi.connect(
                    address=self._hana_service['host'],
                    port=int(self._hana_service['port']),
                    user=self._hana_service['user'],
                    password=self._hana_service['password'],
                    encrypt='true',
                    schema=self._hana_service["schema"],
                    sslTrustStore=self._hana_service['certificate']
        )
            
        cursor = hanaConn.cursor()
        cursor.execute("SET SCHEMA {0}".format(self._hana_service["schema"]))
        cursor.execute("INSERT INTO REMAP_AGENTIC_USAGE_METADATA (ID, INPUT, INPUT_TOKENS, OUTPUT_TOKENS, TOTAL_TOKENS, USER, CREATEDAT) VALUES (?, ?, ?, ?, ?, ?, ?)", insertValues)

        cursor.close()

        if structured_response:
            return {
                'role': 'assistant',
                'is_task_complete': True,
                'require_user_input': False,
                'content': structured_response.content,
            }

        return {
            'role': 'assistant',
            'is_task_complete': True,
            'require_user_input': True,
            'content': (
                'We are unable to process your request at the moment. '
                'Please try again.'
            ),
        }