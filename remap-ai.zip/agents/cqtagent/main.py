from define.agent import CqtAgent
from execute.executor import CqtExecutor
from authmiddleware.middleware import RemapHTTPAuthMiddleware
from a2a.types import AgentCapabilities, AgentSkill, AgentCard, HTTPAuthSecurityScheme
from a2a.server.request_handlers import DefaultRequestHandler
from a2a.server.apps import A2AStarletteApplication
from a2a.server.tasks import InMemoryTaskStore
from cfenv import AppEnv
import uvicorn, asyncio

async def start_server(app, host, port, log_level):
    await uvicorn.Server(config=uvicorn.Config(app, host=host, port=port, log_level=log_level)).serve()
def main() -> None:
    capabilities = AgentCapabilities(
        stateTransitionHistory=True
    )

    createSkill = AgentSkill(
        id="create_customer_query",
        name="Create ReMaP Customer requests (CQT tool)",
        description="Create ReMaP Customer Requests / Queries in draft",
        tags=[
            "cqt", 
            "customer requests create", 
            "customer queries create"
        ],
        examples=[
            "create a customer request for customer idh 1118105, product idh's are 000000000000027317 and 000000000000027293. The customer PSRA contact idh is 9003820071, SBU is ACM. The request type description to be used should be Allergens. Add in additional info that 'this is a test request created through an AI agent'"
        ]
    )

    analyticalSkill = AgentSkill(
        id="analyze_customer_queries",
        name="Analyse or Search ReMaP Customer requests (CQT tool)",
        description="Analyse / Search ReMaP Customer Requests / Queries for making data driven decisions",
        tags=[
            "cqt analyse", 
            "customer requests analyse", 
            "customer queries analyse",
            "customer queries search",
        ],
        examples=[
            "What is the % distribution of the customer requests created during last 12 months across different allocated psra teams?"
        ]
    )

    cqtCard = AgentCard(
        id="cqt_agent",
        name="CQT Agent",
        description="Create Customer Requests / Queries in draft or Draw insights for data driven decisions from the historical customer requests",
        defaultInputModes=CqtAgent.SUPPORTED_CONTENT_TYPES,
        defaultOutputModes=CqtAgent.SUPPORTED_CONTENT_TYPES,
        version="1.0.0",
        url= "https://" + AppEnv().uris[0], #"https://" + AppEnv().uris[0], #"http://localhost:8080"
        capabilities=capabilities,
        skills=[createSkill, analyticalSkill],
        securitySchemes= {
            "remap": HTTPAuthSecurityScheme(
                description="Remap authentication scheme",
                type="http",
                scheme="bearer",
                bearerFormat="JWT"
            )
        },
        security= [{
            "remap": []
        }]
    )

    request_handler = DefaultRequestHandler(
        agent_executor=CqtExecutor(),
        task_store=InMemoryTaskStore()
    )

    server = A2AStarletteApplication(
        agent_card=cqtCard, 
        http_handler=request_handler
    )

    app = server.build()
    app.add_middleware(RemapHTTPAuthMiddleware, agent_card=cqtCard, public_paths=[])
    asyncio.run(start_server(app, host="0.0.0.0", port=8080, log_level="debug"))

if __name__ == '__main__':
    main()