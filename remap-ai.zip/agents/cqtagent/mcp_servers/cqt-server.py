from mcp.server.fastmcp import FastMCP
from hdbcli import dbapi
import json, sys


hana_service = {}

# Initialize FastMCP server
mcp = FastMCP("cqt-server")

@mcp.tool()
def input_fields_for_create_customer_request() -> dict:

    """ 
    The tool should be used only with cqt agent.
    The tool can be used to 
        (1) understand all the fields required to create customer request, 
        (2) validate if all input is provided in the userPrompt, 
        (3) set default values wherever applicable
    """

    return {"fields_optional_or_mandatory":[{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_REQUEST_ID","mandatory":"true","description":"Sequence number for the customer request","comment":"fetch the next sequence using the SAP HANA cloud sequence CUSTOMER_REQUEST_HEADER_ID"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_IDH","mandatory":"true","description":"Customer Account or Customer IDH","comment":"based on this customer IDH you need to fetch all the customer details from the table REMAP_ACCOUNT. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"INTERNAL_REFERENCE_CODE","mandatory":"false","description":"Specific customer reference","comment":"takes 32 character length and used in email subject when responding to the customer"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_NAME","mandatory":"true","description":"Customer name","comment":"should be fetched based on CUSTOMER_IDH from the table REMAP_ACCOUNT. Do not expect it from user. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_COUNTRY","mandatory":"true","description":"Customer Country","comment":"should be fetched based on CUSTOMER_IDH from the table REMAP_ACCOUNT. Do not expect it from user. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"TOP_LEVEL_PARENT","mandatory":"true","description":"Top most parent in the customer hierarchy","comment":"should be fetched based on CUSTOMER_IDH from the table REMAP_ACCOUNT. Do not expect it from user. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"TOP_ACCOUNT_NAME","mandatory":"true","description":"Top most parent name in the customer hierarchy","comment":"should be fetched based on CUSTOMER_IDH from the table REMAP_ACCOUNT. Do not expect it from user. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"REGION_SCOPE","mandatory":"false","default":"false","description":"if region is sent in the userPrompt then fill this one as true else false","comment":""},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"REGIONS","mandatory":"false","default":"WE","description":"if region is sent in the userPrompt then fill all the regions separated by comma else userPrompt should contain COUNTRIES and fetch REGIONS from the REMAP_COUNTRIES table","comment":"fill it as comma separated region values if multiple regions exist"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"COUNTRIES","mandatory":"false","default":"DE","description":"if region is sent in userPrompt then determine COUNTRIES from region using table REMAP_COUNTRIES. If COUNTRIES are sent in the userPrompt then take them directly and update REGIONS","comment":"fill it as comma separated country values if multiple countries exist"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"SBU","mandatory":"true","description":"SBU","comment":"should be one of ACB, ACC, ACM, AMC, AME, AMI, AMO, APC, APP. If it is not one of these close with error that SBU is incorrect"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"HISTORY_CRTD_DATE","mandatory":"true","default":"fill with current date only","description":"current date when customer request is being created","comment":"determine current date and fill it with that value"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"HISTORY_CRTD_BY","mandatory":"true","default":"remap_agent","description":"constant value remap_agent always","comment":"always fill it with the default value remap_agent"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_FROM_ACE","mandatory":"true","default":"false","description":"this is a boolean. fetch from field FROM_ACE in table REMAP_ACCOUNT","comment":"this is a boolean and it can have either true or false. whatever is the value of FROM_ACE in the table REMAP_ACCOUNT that should be here"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"CUSTOMER_FROM_ACE4R","mandatory":"true","default":"false","description":"this is a boolean. fetch from field FROM_ACE4R in table REMAP_ACCOUNT","comment":"this is a boolean and it can have either true or false. whatever is the value of FROM_ACE4R in the table REMAP_ACCOUNT that should be here"},{"tableName":"REMAP_CUSTOMER_REQUEST_HEADERS","fieldName":"OVERALL_STATUS","mandatory":"false","default":19,"description":"Create default status 19 which means created","comment":""},{"tableName":"REMAP_SELECTED_CUSTOMER_REQUEST_TYPES","fieldName":"CUSTOMER_REQUEST_ID","mandatory":"true","description":"Sequence number for the customer request","comment":"Use the same one as in the table REMAP_CUSTOMER_REQUEST_HEADERS"},{"tableName":"REMAP_SELECTED_CUSTOMER_REQUEST_TYPES","fieldName":"TYPE_INDEX_CODE","mandatory":"true","description":"The request type index code is fetched from INDEX_CODE in table REMAP_C_CUSTOMER_REQUEST_TYPES","comment":"The INDEX_CODE should be fetched based on the request type description DESCRIPTION_V2 or short code TYPE_L1 in table REMAP_C_CUSTOMER_REQUEST_TYPES"},{"tableName":"REMAP_CUSTOMER_REQUEST_SELECTED_PSRA","fieldName":"CUSTOMER_REQUEST_ID","mandatory":"true","description":"Sequence number for the customer request","comment":"Use the same one as in the table REMAP_CUSTOMER_REQUEST_HEADERS"},{"tableName":"REMAP_CUSTOMER_REQUEST_SELECTED_PSRA","fieldName":"CONTACT_IDH","mandatory":"true","description":"Contact person IDH","comment":""},{"tableName":"REMAP_CUSTOMER_REQUEST_SELECTED_PSRA","fieldName":"ACCOUNT_IDH","mandatory":"true","description":"CUSTOMER_IDH entered above. Both CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used","comment":""},{"tableName":"REMAP_CUSTOMER_REQUEST_SELECTED_PSRA","fieldName":"CUSTOMER_REQUEST_ID","mandatory":"true","description":"Sequence number for the customer request","comment":"Use the same one as in the table REMAP_CUSTOMER_REQUEST_HEADERS"},{"tableName":"REMAP_CUSTOMER_REQUEST_ITEMS","fieldName":"ITEM","mandatory":"true","description":"Item number as there will be multiple product idh's","comment":"start with number 1 and increment by 1 each time a new item is inserted"},{"tableName":"REMAP_CUSTOMER_REQUEST_ITEMS","fieldName":"PRODUCT_IDH","mandatory":"true","description":"Product IDH selected in the userPrompt","comment":"Product IDH should exist in the table VIEWS_CUSTOMER_REQUEST_MATERIALS"},{"tableName":"REMAP_ACCOUNT","fieldName":"ACCOUNT_IDH","mandatory":"false","description":"The table is a master data table to fetch all customer or account details","comment":"CUSTOMER_IDH or ACCOUNT_IDH are interchangeably used"},{"tableName":"REMAP_ACCOUNT","fieldName":"NAME","mandatory":"false","description":"The table is a master data table to fetch all customer or account details","comment":"name of the customer in the master data table"},{"tableName":"REMAP_ACCOUNT","fieldName":"TOP_LEVEL_PARENT","mandatory":"false","description":"The table is a master data table to fetch all customer or account details","comment":"IDH of the top level parent in the master data table"},{"tableName":"REMAP_ACCOUNT","fieldName":"TOP_ACCOUNT_NAME","mandatory":"false","description":"The table is a master data table to fetch all customer or account details","comment":"name of the top level parent in the master data table"},{"tableName":"REMAP_ACCOUNT","fieldName":"FROM_ACE","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE or not"},{"tableName":"REMAP_ACCOUNT","fieldName":"FROM_ACE4R","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE4R or not"},{"tableName":"REMAP_CONTACT","fieldName":"CONTACT_IDH","mandatory":"true","description":"The table is a master data table to fetch all customer or account contact details","comment":"contact idh is the contact unique identifier"},{"tableName":"REMAP_CONTACT","fieldName":"FROM_ACE","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account contact details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE or not"},{"tableName":"REMAP_CONTACT","fieldName":"FROM_ACE4R","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account contact details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE4R or not"},{"tableName":"REMAP_ACCOUNT_CONTACT","fieldName":"CONTACT_IDH","mandatory":"true","description":"The table is a mapping table for customer or account and contact information per customer or account","comment":"contact idh is the contact unique identifier"},{"tableName":"REMAP_ACCOUNT_CONTACT","fieldName":"ACCOUNT_IDH","mandatory":"true","description":"The table is a mapping table for customer or account and contact information per customer or account","comment":"account idh is the account or customer unique identifier. Customer or Account are interchangeably used"},{"tableName":"REMAP_ACCOUNT_CONTACT","fieldName":"FROM_ACE","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account contact details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE or not"},{"tableName":"REMAP_ACCOUNT_CONTACT","fieldName":"FROM_ACE4R","mandatory":"true","description":"this is a boolean. The table is a master data table to fetch all customer or account contact details","comment":"this is a boolean and it can have either true or false. the field is stating if it is ACE4R or not"},{"tableName":"REMAP_COUNTRIES","fieldName":"CODE","mandatory":"false","description":"The table is a master data table to fetch country name, region_code","comment":"this is the country code which can be passed to fetch regions"},{"tableName":"REMAP_COUNTRIES","fieldName":"REGION_CODE","mandatory":"false","description":"The table is a master data table to fetch country name, region_code","comment":"this is the region code which can be passed to fetch countries"},{"tableName":"REMAP_C_CUSTOMER_REQUEST_TYPES","fieldName":"INDEX_CODE","mandatory":"false","description":"Request type codes to be filled in INITIAL_TYPES","comment":""},{"tableName":"REMAP_C_CUSTOMER_REQUEST_TYPES","fieldName":"TYPE_L1","mandatory":"false","description":"short code to identify the request type level-1","comment":"use this one to match whatever is mentioned in the userPrompt. User can pass full description of the request type or only the short code"},{"tableName":"REMAP_C_CUSTOMER_REQUEST_TYPES","fieldName":"INACTIVE","mandatory":"false","description":"only false records should be considered","comment":"if it is true that row cannot be used"},{"tableName":"REMAP_C_CUSTOMER_REQUEST_TYPES","fieldName":"DESCRIPTION_V2","mandatory":"false","description":"Full description of the request type","comment":"use this one to match whatever is mentioned in the userPrompt. User can pass full description of the request type or only the short code"}]}

@mcp.tool()
def run_queries_to_create_customer_request(queries: list) -> str:
    """
        The tool should be used only with cqt agent. The tool to create customer request

        Args:
        queries : list of queries to execute to ensure creation of the customer request including deep inserts on related tables
    """

    hanaConn = dbapi.connect(
        address=hana_service['host'],
        port=int(hana_service['port']),
        user=hana_service['user'],
        password=hana_service['password'],
        encrypt='true',
        schema=hana_service["schema"],
        sslTrustStore=hana_service['certificate']
    )

    cursor = hanaConn.cursor()
    cursor.execute("SET SCHEMA {0}".format(hana_service["schema"]))

    for each in queries:
        try:
            cursor.execute(each["query"])
        except Exception as e:
            cursor.execute("ROLLBACK")
            cursor.close()
            return "Error {1} in executing query: {0}".format(each["query"], e)

    cursor.close()
    return "Success"

@mcp.tool()
def get_next_customer_request_id() -> int:

    """
        The tool should be used only with cqt agent. Generate next sequence number using SAP HANA cloud sequence CUSTOMER_REQUEST_HEADER_ID for field CUSTOMER_REQUEST_ID
    """

    hanaConn = dbapi.connect(
        address=hana_service['host'],
        port=int(hana_service['port']),
        user=hana_service['user'],
        password=hana_service['password'],
        encrypt='true',
        schema=hana_service["schema"],
        sslTrustStore=hana_service['certificate']
    )

    cursor = hanaConn.cursor()
    cursor.execute("SET SCHEMA {0}".format(hana_service["schema"]))

    cursor.execute('SELECT "db.functions::nextValSeq"(\'CUSTOMER_REQUEST_HEADER_ID\') AS RESULT FROM DUMMY')
    requestId = cursor.fetchall()[0]
    cursor.close()
    hanaConn.close()
    return requestId[0]


@mcp.tool()
def run_select_queries_to_fetch_necessary_data(queries: list) -> list | str:
    """
        The tool should be used only with cqt agent. Run SELECT queries to fetch necessary information (example: CUSTOMER_NAME and others)

        Args
            queries: list of queries to execute to fetch necessary information to create customer request from related tables.
    """
    hanaConn = dbapi.connect(
        address=hana_service['host'],
        port=int(hana_service['port']),
        user=hana_service['user'],
        password=hana_service['password'],
        encrypt='true',
        schema=hana_service["schema"],
        sslTrustStore=hana_service['certificate']
    )

    cursor = hanaConn.cursor()
    cursor.execute("SET SCHEMA {0}".format(hana_service["schema"]))

    result = []

    for each in queries:
        try:
            cursor.execute(each["query"])
            queryOutcome = cursor.fetchall()
            result.append(dict(list(zip(queryOutcome[0].column_names, queryOutcome[0].column_values))))
        except Exception as e:
            cursor.close()
            hanaConn.close()
            return "Error {1} in executing query: {0}".format(each["query"], e)

    cursor.close()
    hanaConn.close()
    return result


if __name__ == "__main__":
    
    hana_service = json.loads(sys.argv[1])

    # Initialize and run the server
    mcp.run(transport='stdio')