from define.agent import RemapOrchestratorAgent
from flask import Flask, request, abort
from waitress import serve
from sap import xssec
from cfenv import AppEnv
import json

# needed for local testin
# from dotenv import load_dotenv
# load_dotenv()

env = AppEnv()
app = Flask(__name__)
uaa_service = env.get_service(name='remap-xsuaa-service').credentials
agent = None

@app.get("/ping")
def ping() -> str:
    if 'authorization' not in request.headers:
        abort(401)

    access_token = request.headers.get('authorization')[7:]
    security_context = xssec.create_security_context(access_token, uaa_service)

    xsappname = uaa_service["xsappname"]
    isAuthorized = security_context.check_scope(xsappname + '.remap-user')

    if not isAuthorized:
        abort(403)

    return "ok"

@app.post("/startAgent")
async def startAgent() -> json:
    if 'authorization' not in request.headers :
        abort(401)

    access_token = request.headers.get('authorization')[7:]
    security_context = xssec.create_security_context(access_token, uaa_service)

    xsappname = uaa_service["xsappname"]
    isAuthenticated = security_context.get_clientid() == uaa_service.get("clientid")

    if not isAuthenticated:
        abort(401)

    isAuthorized = security_context.check_scope(xsappname + '.remap-user')

    if not isAuthorized:
        abort(403)

    data = request.json
    userPrompt = data["userPrompt"]
    
    global agent
    response = await agent.agentInvoke(userPrompt, request)
    return response

def main():
    global agent
    agent = RemapOrchestratorAgent()
    serve(app, host="0.0.0.0", port=8080, threads=2)



if __name__ == '__main__':
    main()