from a2a.client import A2ACardResolver, A2AClient
from a2a.types import AgentCard
from a2a.types import SendMessageRequest, MessageSendParams
from typing import Union
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig
from pydantic import BaseModel, Field
from uuid import uuid4
import os, httpx

class CallAgentSchema(BaseModel):
    """
        Parameters for calling an agent discovered in the previous step
    """
    agent_name: str = Field(description='Name of the agent to call')
    message: str = Field(description='Message to send to the agent')
    agentCards: list[AgentCard] = Field(description='AgentCard details discovered in the previous step. This should always be list of length one with one AgentCard instance identified')
    config: RunnableConfig

@tool(parse_docstring=True)
async def list_agents(config: RunnableConfig) -> list[AgentCard]:
    """
        Returns a list of available agents

        Args:
            config: The config object
    """

    remapAgentUrls: str = os.getenv("AGENT_URLS")

    cards: list[AgentCard] = []
    async with httpx.AsyncClient(headers={"Authorization": config["configurable"].get("authorization")}) as client:
        for url in remapAgentUrls.split(","):
            resolver = A2ACardResolver(
                httpx_client = client,
                base_url = url.rstrip("/")
            )

            cards.append(await resolver.get_agent_card())

    return cards

@tool(parse_docstring=True,args_schema=CallAgentSchema)
async def call_agent(agent_name: str, message: str, agentCards: Union[AgentCard, list[AgentCard], list], config: RunnableConfig) -> str:

    """
        Calls an agent and returns the response

        Args:
            agent_name: The name of the agent to call
            message: The message to send to the agent
            agentCards: AgentCard details discovered in the previous step. This should always be list of length one with one AgentCard instance identified
            config: The config object
    """
    
    try:
        if(isinstance(agentCards, list)):

            if len(agentCards) > 0:
                for card in agentCards:
                    if card.name == agent_name:
                        agentToAction = card
            
            if agentToAction == None:
                raise Exception("Agent not found")
        else:
            if agentCards.name != agent_name:
                raise Exception("Agent not found")
            else:
                agentToAction = agentCards

        client = A2AClient(
            httpx_client = httpx.AsyncClient(headers={"Authorization": config["configurable"].get("authorization")},timeout=300.0),
            agent_card = agentToAction
        )
        
        payload = {
            "message": {
                "messageId": uuid4().hex,
                "role": "user",
                "parts": [
                    {
                        "kind": "text",
                        "text": message
                    }
                ]
            }
        }

        request = SendMessageRequest(id=str(uuid4()), params=MessageSendParams(**payload))

        response = await client.send_message(request)
        responseModel = response.model_dump(mode="json", exclude_none=True)
    
    except Exception as e:
        responseModel = {
            "role": "assistant",
            "summary": str(e)
        }

    return responseModel