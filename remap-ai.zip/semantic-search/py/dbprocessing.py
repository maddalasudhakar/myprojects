
from collections import defaultdict
def semanticEmbeddingProcess(connection_remap, embedding_model):

    try:
            cursor = connection_remap.cursor()
            sql_command = '''SELECT 
                CUSTOMER_REQUEST_ID, 
                RSN, 
                DESCRIPTION
                RECORD_INT, 
                TEXT 
            FROM 
                VIEWS_CUSTOMER_REQUEST_RSN_PRODDESC AS oview
            JOIN 
                REMAP_COMMENTS AS otable
            ON 
                oview.CUSTOMER_REQUEST_ID = otable.RECORD_INT;'''
            cursor.execute(sql_command)
            results = cursor.fetchall()
            finalData = []
            for i in range(len(results)):
                payload = {
                                "RequestID": results[i][0],
                                "RSN": results[i][1],
                                "Description": results[i][2],
                                "Comments" : results[i][3]

                        }
                finalData.append(payload)


            # Create a dictionary to group by reqID
            grouped_data = defaultdict(lambda: {"RequestID": None, "Products": [], "Comments": []})

            # Populate the dictionary
            for item in finalData:
                reqID = item["RequestID"]
                if grouped_data[reqID]["RequestID"] is None:
                    grouped_data[reqID]["RequestID"] = reqID
                grouped_data[reqID]["Products"].append({
                    "RSN": item["RSN"],
                    "Description": item["Description"]
                })
                grouped_data[reqID]["Comments"].append(item["Comments"])

            # Convert grouped data to the desired array format
            output_array = list(grouped_data.values())

            import json
            import datetime


            # Function to split the string into chunks of max_length
            def split_string(s, max_length):
                chunks = []
                for i in range(0, len(s), max_length):
                    chunks.append(s[i:i + max_length])
                return chunks

            # Maximum length for each chunk
            max_length = 8192

            # List to hold the output chunks
            output_chunks = []

            # Process each object in the input array
            for item in output_array:
                # Convert the item to a JSON string
                json_string = json.dumps(item)
                
                # Split the JSON string into chunks if it exceeds the max_length
                if len(json_string) > max_length:
                    chunks = split_string(json_string, max_length)
                    for i, chunk in enumerate(chunks):
                        chunk_obj = {
                            "RequestID": item["RequestID"],
                            "ChunkID": i + 1,
                            "Data": chunk,
                            "Datetime": datetime.datetime.now().isoformat(),

                        }
                        output_chunks.append(chunk_obj)
                else:
                    # If the string length is within the limit, add it as a single chunk
                    chunk_obj = {
                        "RequestID": item["RequestID"],
                        "ChunkID": 1,
                        "Data": json_string,
                        "Datetime": datetime.datetime.now().isoformat(),

                    }
                    output_chunks.append(chunk_obj)
            cur = connection_remap.cursor()
            query = f'''INSERT INTO REMAP_SEMANTIC_SEARCH  (REQUESTID, CHUNKID, CONTENT, DATETIME, EMBEDDINGS)  VALUES (?,?,?,?,TO_REAL_VECTOR(?))'''
            for doc in output_chunks:
                        cur.execute(query, (
                            doc["RequestID"],
                            doc["ChunkID"],
                            str(doc["Data"]),
                            doc["Datetime"],
                            #str(""),
                            str(embedding_model.embed_query(doc["Data"]))
                        ))
            cur.close()
            return "Success"
    except Exception as e:
        return str(e)