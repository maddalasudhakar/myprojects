import os
from flask import Flask, jsonify, request
from hdbcli import dbapi
import json
import pandas as pd 
from cfenv import AppEnv
from gen_ai_hub.proxy.langchain.openai import OpenAIEmbeddings
from langchain_core.documents import Document
from langchain_community.vectorstores.hanavector import HanaDB
import connectionSetup
import dbprocessing
app = Flask(__name__)
env = AppEnv()

hana_service = 'hana'
hana = env.get_service(label=hana_service)

from typing import (
    List,
    Optional,
    Tuple,
)
import importlib.util
from langchain_core.embeddings import Embeddings
from langchain_community.vectorstores.hanavector import default_distance_strategy, default_table_name, default_content_column, default_metadata_column, default_vector_column, default_vector_column_length, HANA_DISTANCE_FUNCTION

from langchain_community.vectorstores.utils import (
    DistanceStrategy,
    maximal_marginal_relevance,
)

class HanaDBWithOutMetaDataColumn(HanaDB):

    def __init__(
        self,
        connection: dbapi.Connection,
        embedding: Embeddings,
        distance_strategy: DistanceStrategy = default_distance_strategy,
        table_name: str = default_table_name,
        content_column: str = default_content_column,
        vector_column: str = default_vector_column,
        vector_column_length: int = default_vector_column_length,
        *,
        specific_metadata_columns: Optional[List[str]] = None,
    ):
        # Check if the hdbcli package is installed
        if importlib.util.find_spec("hdbcli") is None:
            raise ImportError(
                "Could not import hdbcli python package. "
                "Please install it with `pip install hdbcli`."
            )
        valid_distance = False
        for key in HANA_DISTANCE_FUNCTION.keys():
            if key is distance_strategy:
                valid_distance = True
        if not valid_distance:
            raise ValueError(
                "Unsupported distance_strategy: {}".format(distance_strategy)
            )

        self.connection = connection
        self.embedding = embedding
        self.distance_strategy = distance_strategy
        self.table_name = HanaDB._sanitize_name(table_name)
        self.content_column = HanaDB._sanitize_name(content_column)
        self.vector_column = HanaDB._sanitize_name(vector_column)
        self.vector_column_length = HanaDB._sanitize_int(vector_column_length)
        self.specific_metadata_columns = HanaDB._sanitize_specific_metadata_columns(
            specific_metadata_columns or []
        )

        # Check if the needed columns exist and have the correct type
        self._check_column(self.table_name, self.content_column, ["NCLOB", "NVARCHAR"])
        self._check_column(
            self.table_name,
            self.vector_column,
            ["REAL_VECTOR"],
            self.vector_column_length,
        )
        for column_name in self.specific_metadata_columns:
            self._check_column(self.table_name, column_name)

    def similarity_search_with_score_and_vector_by_vector(
            self, embedding: List[float], k: int = 4, filter: Optional[dict] = None
        ) -> List[Tuple[Document, float, List[float]]]:
            """Return docs most similar to the given embedding.

            Args:
                query: Text to look up documents similar to.
                k: Number of Documents to return. Defaults to 4.
                filter: A dictionary of metadata fields and values to filter by.
                        Defaults to None.

            Returns:
                List of Documents most similar to the query and
                score and the document's embedding vector for each
            """
            result = []
            k = HanaDB._sanitize_int(k)
            embedding = HanaDB._sanitize_list_float(embedding)
            distance_func_name = HANA_DISTANCE_FUNCTION[self.distance_strategy][0]
            embedding_as_str = ",".join(map(str, embedding))
            metadata_columns_str = ', '.join(f'"{col}"' for col in self.specific_metadata_columns)
                 
            sql_str = (
                f"SELECT TOP {k}"
                f'  "{self.content_column}", '  # row[0]
                f'  {metadata_columns_str}, '  # row[...]
                f'  TO_NVARCHAR("{self.vector_column}"), '  # row[-2]
                f'  {distance_func_name}("{self.vector_column}", TO_REAL_VECTOR '
                f"     (ARRAY({embedding_as_str}))) AS CS "  # row[-1]
                f'FROM "{self.table_name}"'
            )
                
            order_str = f" order by CS {HANA_DISTANCE_FUNCTION[self.distance_strategy][1]}"
            where_str, query_tuple = self._create_where_by_filter(filter)
            sql_str = sql_str + where_str
            sql_str = sql_str + order_str
            try:
                cur = self.connection.cursor()
                cur.execute(sql_str, query_tuple)
                if cur.has_result_set():
                    rows = cur.fetchall()
                    for row in rows:
                        js={}
                        for idx, field_name in enumerate(self.specific_metadata_columns):
                            js[field_name] = row[idx+1]
                       
                        doc = Document(page_content=row[0], metadata=js)
                        result_vector = HanaDB._parse_float_array_from_string(row[-2])
                        result.append((doc, row[-1], result_vector))
            finally:
                cur.close()
            return result

try:
    get_AI_Core_param = connectionSetup.getDestination("semantic-search-destination","remap-henkel-ai-foundation")
    os.environ["AICORE_AUTH_URL"] = get_AI_Core_param['destinationConfiguration']['AICORE_AUTH_URL']
    os.environ["AICORE_CLIENT_ID"] = get_AI_Core_param['destinationConfiguration']['clientId']
    os.environ["AICORE_CLIENT_SECRET"] = get_AI_Core_param['destinationConfiguration']['clientSecret']
    os.environ["AICORE_RESOURCE_GROUP"] = get_AI_Core_param['destinationConfiguration']['AICORE_RESOURCE_GROUP']
    os.environ["AICORE_BASE_URL"] = get_AI_Core_param['destinationConfiguration']['URL'] + '/v2'

    embedding_model = OpenAIEmbeddings(proxy_model_name='text-embedding-ada-002')
    connection_remap  = connectionSetup.getremap_conn()

except Exception as e:
            raise ValueError(str(e))

port = int(os.environ.get('PORT', 8000))
@app.route("/api/customerResquestData", methods=["GET"])
def customerResquestData():
    cursor = connection_remap.cursor()
    sqlquery = f"SELECT REQUESTID, CONTENT FROM REMAP_SEMANTIC_SEARCH"
    cursor.execute(sqlquery)
    supplierData = cursor.fetchall()
    results = pd.DataFrame(supplierData, columns=['REQUESTID', 'CONTENT'])
    return jsonify(results.to_json())

@app.route("/api/semanticSearchDBprocessing", methods=["GET"])
def semanticSearchDBprocessing():
    results = dbprocessing.semanticEmbeddingProcess(connection_remap, embedding_model)
    return  str(results)

@app.route("/api/semanticsearch", methods=["POST"])
def semanticsearch():
    queryparameters = json.loads(request.data)
    query = queryparameters['query']
    db = HanaDBWithOutMetaDataColumn(
        connection=connection_remap,
        embedding=embedding_model,
        table_name="REMAP_SEMANTIC_SEARCH",
        content_column="CONTENT",
        vector_column="EMBEDDINGS",
        specific_metadata_columns=[
            "REQUESTID",
            "CHUNKID",
            "DATETIME"
        ]
        )
    
    advanced_filter = {}
    result_docs = db.similarity_search(query, k=2, filter=advanced_filter)
    finalData = []
    for doc in result_docs:
        finalData.append(doc.page_content)
    results = pd.DataFrame(finalData, columns=['RequestID'])
    return jsonify(results.to_json())
if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0', port=port)