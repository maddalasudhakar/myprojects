from os import name
from hdbcli import dbapi
from cfenv import AppEnv

env = AppEnv()
import requests



def getremap_conn():
    hana_service = 'remap-db'
    hana = env.get_service(name=hana_service)
    connection_remap = dbapi.connect(
                            address=hana.credentials['host'],
                            port=int(hana.credentials['port']),
                            user=hana.credentials['user'],
                            password=hana.credentials['password'],
                            currentSchema=hana.credentials['schema'],
                            encrypt='true',
                            sslTrustStore=hana.credentials['certificate']
    )
    return connection_remap

def getDestination(sDestinationService, sDestinationName):
# Read the environment variables  
# -----------------------------------------------------------------------------------------------------
  dest_service = env.get_service(name=sDestinationService)
  sUaaCredentials = dest_service.credentials["clientid"] + ':' + dest_service.credentials["clientsecret"]
# Request a JWT token to access the destination service
# -----------------------------------------------------------------------------------------------------
  
  headers = {'Authorization': 'Basic '+sUaaCredentials, 'content-type': 'application/x-www-form-urlencoded'}
  form = [('client_id', dest_service.credentials["clientid"] ),('client_secret', dest_service.credentials["clientsecret"] ), ('grant_type', 'client_credentials')]
  
  url = dest_service.credentials['url'] +"/oauth/token"
  headers = {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
  response = requests.request("POST", url, headers=headers, data=form)
# Search your destination in the destination service
# -----------------------------------------------------------------------------------------------------
  token = response.json()["access_token"]
  headers= { 'Authorization': 'Bearer ' + token }
  r = requests.get(dest_service.credentials["uri"] + '/destination-configuration/v1/destinations/'+sDestinationName, headers=headers)
# Access the destination securely  
# -----------------------------------------------------------------------------------------------------  
  results = r.json() 
  return results