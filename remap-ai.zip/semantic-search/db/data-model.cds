namespace REMAP;
//using { cuid } from '@sap/cds/common';

entity SEMANTIC_SEARCH 
{
  REQUESTID  : Integer;
  CHUNKID : Integer;
  CONTENT: LargeString;
  DTAETIME: DateTime;
  METADATA : LargeString;
  TEAMS: LargeString;
  COLUMNS: LargeString;
  EMBEDDINGS  : cds.Vector;
}
