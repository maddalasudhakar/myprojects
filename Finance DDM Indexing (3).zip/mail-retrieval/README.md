# Mail-retrieval service
It's responsible for retrieving the emails from the mailbox and saving them in the database/object store.

## Deployment on Cloud

Use following scripts to build and deploy the mta archive to Cloud Foundry:
```bash
npm install
npm run mta:build
# npm run mta:build:mtls # Deployment with mTLS enabled

# Deploy the mta archive
cf login # Login to your Cloud Foundry account
npm run mta:deploy
```

## ODATA services exposed
### MailboxProcessingService (mail-retrieval)
Service exposing actions for mailbox processing in regards to email retrieval process.
These actions are triggered periodically by the `JOB Scheduling` service:

- `processDocumentsFromMailbox` to retrieve emails from the mailbox and save them in the database/object store,
- `processFailedMessagesAndDocuments` to retry failed messages and documents that were not processed correctly in the previous attempts.

**Actions (HTTP POST):**
- `POST https://service_hostname:port/odata/v4/mailbox-processing/processDocumentsFromMailbox()`
- `POST https://service_hostname:port/odata/v4/mailbox-processing/processFailedMessagesAndDocuments()`

## Processes flow description
### processDocumentsFromMailbox
1. Retrieve Messages from Mailbox
- Messages that have been received in the last 5 minutes are fetched from the mailbox.
2. Check for Messages
- If no messages are found, the process logs this and ends early.
3. Process Each Message
- For every message:
    - The system checks if the message has already been processed (to avoid duplicates).
    - If not processed, it proceeds to handle the message.
4. Handle Attachments for Each Message
- If the message has attachments:
    - The system retrieves all attachments for the message.
    - For each attachment:
        - It checks if the attachment has already been processed.
        - If not, it fetches the attachment content.
        - The attachment and its content are stored as a document in the database/object store.
        - The company code is extracted from the message subject if available.
        - If an error occurs while fetching the attachment content, the error is logged and the document is created with an error status.
- If the message has no attachments:
    - The message is recorded in the database with a status indicating that no attachments were found.
6. After processing, the Job Run Log is updated with the number of processed messages and documents.

### processFailedMessagesAndDocuments
1. Process Failed Message Jobs
- The system retrieves all failed message jobs from the database.
- For each failed message job:
    - The system attempts to reprocess the messages from the mailbox related to this job (using the same logic as the normal message processing).
    - The results are collected for reporting.
2. Process Failed Messages
- The system retrieves all failed messages from the database.
- For each failed message:
    - The system attempts to reprocess the attachments of that message.
    - If attachments are found, they are processed and stored as documents.
    - The results are collected for reporting.
3. Process Failed Documents
- The system retrieves all failed documents from the database.
 - For each failed document:
    - The system attempts to fetch the corresponding attachment content from the mailbox.
    - If successful, the document is updated with the attachment content.
    - The results are collected for reporting.
4. Aggregate Results
- The results from processing failed message jobs, failed messages, and failed documents are aggregated into a single summary object.
5. The Job Run Log is updated with the summary of processed messages and documents.