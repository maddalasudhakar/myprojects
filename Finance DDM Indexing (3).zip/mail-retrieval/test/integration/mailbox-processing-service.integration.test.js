import { StatusCodes } from 'http-status-codes';
import { TEST_USERS, MESSAGE_PROCESSING_STATUS, DOCUMENT_PROCESSING_STATUS, FAILED_MESSAGE_JOB_STATUS, CDS_ENTITIES } from '../utils/constants.js';
import MailboxHelper from '../utils/mailbox-helper.js';
import utils from '../utils/utils.js';
const { data, expect, POST } = cds.test.in(__dirname + '/../..').run('.', '--in-memory');

import MailboxClient from '../../srv/lib/clients/mailbox-client.js';
jest.mock('../../srv/lib/clients/mailbox-client.js');

const baseUrl = '/odata/v4/mailbox-processing';

describe('Mailbox Processing Service', () => {
  describe('Process Documents from Mailbox', () => {
    beforeAll(async () => {
      const mailboxHelper = new MailboxHelper('MESSAGES');
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation(async (currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
        return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages and created documents - processingStatus == "DONE"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
    });
  });

  describe('Process Documents from Mailbox - No attachments found for messages', () => {
    beforeAll(async () => {
      const mailboxHelper = new MailboxHelper('MESSAGES');
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation(() => {
        return Promise.resolve([]);
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages and created documents - processingStatus == "NO_ATTACHMENTS_FOUND"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.NO_ATTACHMENTS_FOUND);
      expect(message1.errorReason).to.contain('No attachments found for this message.');

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.NO_ATTACHMENTS_FOUND);
      expect(message2.errorReason).to.contain('No attachments found for this message.');

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(0);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(0);
    });
  });

  describe('Process Documents from Mailbox - Messages with invalid Company', () => {
    beforeAll(async () => {
      const mailboxHelper = new MailboxHelper('MESSAGES_WITH_INVALID_COMPANY');
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
        return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages and created documents - processingStatus == "INVALID_MAIL"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(1);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse.length).to.equal(1);

      const document = documentsResponse[0];
      expect(document.name).to.not.equal(null);
      expect(document.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.INVALID_MAIL);
      expect(document.errorReason).to.contain(`Extracted company code ${document.companyCode} from email subject is not found`);
    });
  });

  describe('Process Documents from Mailbox - Messages with invalid attachment', () => {
    beforeAll(async () => {
      const mailboxHelper = new MailboxHelper('MESSAGES_WITH_INVALID_ATTACHMENT');
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
        return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages and created documents - processingStatus == "INVALID_MAIL"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(1);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse.length).to.equal(1);

      const document = documentsResponse[0];
      expect(document.name).to.not.equal(null);
      expect(document.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.INVALID_MAIL);
      expect(document.errorReason).to.contain('Invalid content type');
    });
  });

  describe('Process Documents from Mailbox - Error when fetching attachments', () => {
    const mailboxHelper = new MailboxHelper('MESSAGES');

    beforeAll(async () => {
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        throw new Error('Error fetching attachments');
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages - processingStatus == "ATTACHMENTS_FETCH_ERROR"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.ATTACHMENTS_FETCH_ERROR);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.ATTACHMENTS_FETCH_ERROR);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(0);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(0);
    });

    it(
      'Should process failed messages with processingStatus == "ATTACHMENTS_FETCH_ERROR"',
      async () => {
        MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
          return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
        });
        MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
          return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
        });
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processFailedMessagesAndDocuments`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages - processingStatus == "DONE"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);
      expect(documentsResponse1[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
      expect(documentsResponse2[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
    });
  });

  describe('Process Documents from Mailbox - Error when fetching content of attachment', () => {
    const mailboxHelper = new MailboxHelper('MESSAGES');

    beforeAll(async () => {
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(() => {
        throw new Error('Error fetching content of attachment');
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages - processingStatus == "CONTENT_FETCH_ERROR"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);

      const document1 = documentsResponse1[0];
      expect(document1.name).to.not.equal(null);
      expect(document1.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.CONTENT_FETCH_ERROR);
      expect(document1.errorReason).to.contain('Error fetching attachment content');

      const document2 = documentsResponse1[1];
      expect(document2.name).to.not.equal(null);
      expect(document2.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.CONTENT_FETCH_ERROR);
      expect(document2.errorReason).to.contain('Error fetching attachment content');

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);

      const document3 = documentsResponse2[0];
      expect(document3.name).to.not.equal(null);
      expect(document3.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.CONTENT_FETCH_ERROR);
      expect(document3.errorReason).to.contain('Error fetching attachment content');

      const document4 = documentsResponse2[1];
      expect(document4.name).to.not.equal(null);
      expect(document4.processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.CONTENT_FETCH_ERROR);
      expect(document4.errorReason).to.contain('Error fetching attachment content');
    });

    it(
      'Should process failed documents with processingStatus == "CONTENT_FETCH_ERROR"',
      async () => {
        MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
          return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
        });
        MailboxClient.prototype.getAttachment.mockImplementation((messageId, attachmentId) => {
          return Promise.resolve(mailboxHelper.getAttachment(messageId, attachmentId));
        });
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processFailedMessagesAndDocuments`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 10 seconds to allow the processing to complete
        await utils.delay(10000);
      },
      30 * 1000
    );

    it('Should have processed document - processingStatus == "UNPROCESSED"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));

      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(
        SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS)
          .columns((document) => {
            document`.*`, document.attachments('*');
          })
          .where({ message_ID: message1.ID })
      );
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);
      expect(documentsResponse1[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse1[0].attachments.length).to.equal(1);
      expect(documentsResponse1[1].name).to.not.equal(null);
      expect(documentsResponse1[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse1[1].attachments.length).to.equal(1);

      const documentsResponse2 = await db.run(
        SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS)
          .columns((document) => {
            document`.*`, document.attachments('*');
          })
          .where({ message_ID: message2.ID })
      );
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
      expect(documentsResponse2[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse2[0].attachments.length).to.equal(1);
      expect(documentsResponse2[1].name).to.not.equal(null);
      expect(documentsResponse2[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse2[1].attachments.length).to.equal(1);
    });
  });

  describe('Process Documents from Mailbox - Error when fetching messages', () => {
    beforeAll(async () => {
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation(() => {
        throw new Error('Error fetching messages');
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);
        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have created a failed message job in the database - processingStatus == "UNPROCESSED"', async () => {
      // Check for failed message jobs
      const db = await cds.connect.to('db');
      const failedMessageJobs = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS));
      expect(failedMessageJobs.length).to.equal(1);

      const failedMessageJob = failedMessageJobs[0];
      expect(failedMessageJob.processingStatus).to.equal(FAILED_MESSAGE_JOB_STATUS.UNPROCESSED);
      expect(failedMessageJob.retryCount).to.equal(0);
    });

    it('Should have no messages/documents created in the database', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);

      const documents = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS));
      expect(documents.length).to.equal(0);
    });

    it(
      'Should process failed messages jobs - Retry count should be incremented',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processFailedMessagesAndDocuments`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);

        // Check for failed message jobs
        const db = await cds.connect.to('db');
        const failedMessageJobs = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS));
        expect(failedMessageJobs.length).to.equal(1);

        const failedMessageJob = failedMessageJobs[0];
        expect(failedMessageJob.processingStatus).to.equal(FAILED_MESSAGE_JOB_STATUS.UNPROCESSED);
        expect(failedMessageJob.retryCount).to.equal(1);

        const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
        expect(messages.length).to.equal(0);

        const documents = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS));
        expect(documents.length).to.equal(0);
      },
      30 * 1000
    );

    it('Should process failed messages jobs - processingStatus == "PROCESSED"', async () => {
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(new MailboxHelper('MESSAGES').getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(new MailboxHelper('MESSAGES').getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
        return Promise.resolve(await new MailboxHelper('MESSAGES').getAttachmentContent(messageId, attachmentId));
      });

      // Call the endpoint to process failed message jobs
      const response = await POST(`${baseUrl}/processFailedMessagesAndDocuments`, {}, { auth: TEST_USERS.USER });
      expect(response.status).to.equal(StatusCodes.ACCEPTED);

      // Wait for 6 seconds to allow the processing to complete
      await utils.delay(6000);

      // Check for failed message jobs
      const db = await cds.connect.to('db');
      const failedMessageJobs = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS));
      expect(failedMessageJobs.length).to.equal(1);
      const failedMessageJob = failedMessageJobs[0];
      expect(failedMessageJob.processingStatus).to.equal(FAILED_MESSAGE_JOB_STATUS.PROCESSED);
      expect(failedMessageJob.retryCount).to.equal(1);

      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);
      expect(documentsResponse1[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse1[1].name).to.not.equal(null);
      expect(documentsResponse1[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
      expect(documentsResponse2[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse2[1].name).to.not.equal(null);
      expect(documentsResponse2[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
    });
  });

  describe('Process Documents from Mailbox - Duplicates are not created if the action is triggered multiple times', () => {
    beforeAll(async () => {
      const mailboxHelper = new MailboxHelper('MESSAGES');
      // Mock the mailbox client to return a specific set of messages
      MailboxClient.prototype.getMessagesFromMailbox.mockImplementation((currentDate, page) => {
        return Promise.resolve(mailboxHelper.getMessages(currentDate, page));
      });
      MailboxClient.prototype.getAttachmentsFromMessage.mockImplementation((messageId) => {
        return Promise.resolve(mailboxHelper.getAttachmentsForMessage(messageId));
      });
      MailboxClient.prototype.getAttachmentContent.mockImplementation(async (messageId, attachmentId) => {
        return Promise.resolve(await mailboxHelper.getAttachmentContent(messageId, attachmentId));
      });
    });

    afterAll(async () => {
      jest.clearAllMocks();
      await data.reset();
    });

    it('No Messages should be available in the database', async () => {
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(0);
    });

    it(
      'Should process documents from mailbox successfully',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('Should have processed messages and created documents - processingStatus == "DONE"', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);
      expect(documentsResponse1[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse1[1].name).to.not.equal(null);
      expect(documentsResponse1[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
      expect(documentsResponse2[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse2[1].name).to.not.equal(null);
      expect(documentsResponse2[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
    });

    it(
      'Should not create duplicate messages or documents when processing again',
      async () => {
        // Call the endpoint to process documents from mailbox
        const response = await POST(`${baseUrl}/processDocumentsFromMailbox`, {}, { auth: TEST_USERS.USER });
        expect(response.status).to.equal(StatusCodes.ACCEPTED);

        // Wait for 6 seconds to allow the processing to complete
        await utils.delay(6000);
      },
      30 * 1000
    );

    it('No duplicate messages or documents should have been created', async () => {
      // Check the messages
      const db = await cds.connect.to('db');
      const messages = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES));
      expect(messages.length).to.equal(2);

      const message1 = messages[0];
      expect(message1.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      const message2 = messages[1];
      expect(message2.processingStatus).to.equal(MESSAGE_PROCESSING_STATUS.DONE);

      // Check the documents
      const documentsResponse1 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message1.ID }));
      expect(documentsResponse1.length).to.equal(2);
      expect(documentsResponse1[0].name).to.not.equal(null);
      expect(documentsResponse1[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse1[1].name).to.not.equal(null);
      expect(documentsResponse1[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);

      const documentsResponse2 = await db.run(SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ message_ID: message2.ID }));
      expect(documentsResponse2.length).to.equal(2);
      expect(documentsResponse2[0].name).to.not.equal(null);
      expect(documentsResponse2[0].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
      expect(documentsResponse2[1].name).to.not.equal(null);
      expect(documentsResponse2[1].processingStatus).to.equal(DOCUMENT_PROCESSING_STATUS.UNPROCESSED);
    });
  });
});
