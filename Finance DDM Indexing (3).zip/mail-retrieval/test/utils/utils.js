import { Readable } from 'stream';

export default {
  _convertToBuffer: async (content) => {
    if (content instanceof Readable) {
      const chunks = [];
      try {
        for await (const chunk of content) {
          chunks.push(chunk);
        }
        if (chunks.length === 0) {
          throw new Error('LOB stream is empty.');
        }
        return Buffer.concat(chunks);
      } catch (error) {
        this.log.error('Error reading LOB stream:', error);
        throw new Error('Failed to read LOB stream');
      }
    } else if (Buffer.isBuffer(content)) {
      return content;
    } else if (typeof content === 'string') {
      return Buffer.from(content);
    }
    throw new Error('Unsupported content type for Buffer conversion.');
  },
  
  delay: (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
  },
};
