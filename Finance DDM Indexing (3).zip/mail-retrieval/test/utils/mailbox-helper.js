import { join } from 'path';
import { createReadStream, existsSync } from 'fs';
import utils from './utils.js';
import messagesData from '../mock-data/messages.json' with { type: 'json' };

export default class MailboxHelper {
  constructor(variable) {
    this.variable = variable;
  }

  getMessages(currentDate, page){
    if (page === 0) {
      return messagesData[this.variable].map((message) => ({
        id: message.id,
        receivedDateTime: message.receivedDateTime,
        sentDateTime: message.sentDateTime,
        hasAttachments: message.hasAttachments,
        subject: message.subject
      }));
    } else {
      return [];
    }
  }

  getAttachmentsForMessage(messageId) {
    const message = messagesData[this.variable].find((msg) => msg.id === messageId);
    return message ? message.attachments : [];
  }

  async getAttachmentContent(messageId, attachmentId) {
    const message = messagesData[this.variable].find((msg) => msg.id === messageId);
    const attachment = message?.attachments.find((att) => att.id === attachmentId);

    const filePath = join(__dirname, '../mock-data/files', attachment.name);

    if (!existsSync(filePath)) {
      return null;
    }
    const file = createReadStream(filePath);
    const fileBuffer = await utils._convertToBuffer(file);
    return fileBuffer;
  }

  getAttachment(messageId, attachmentId) {
    const message = messagesData[this.variable].find((msg) => msg.id === messageId);
    const attachment = message?.attachments.find((att) => att.id === attachmentId);

    return attachment;
  }
}