import { StatusCodes } from 'http-status-codes';

jest.mock('@sap/cds', () => ({
  connect: { to: jest.fn() },
  log: jest.fn()
}));
jest.mock('../../../srv/lib/handlers/mailbox-document-handler.js', () => jest.fn());
jest.mock('../../../srv/common-lib/managers/job-scheduler-manager.js', () => ({ handleActionTriggeredByJobScheduler: jest.fn() }));
jest.mock('../../../srv/common-lib/utils/utilities.js', () => ({ handleHttpError: jest.fn() }));

const cds = require('@sap/cds');
const MailboxDocumentHandler = require('../../../srv/lib/handlers/mailbox-document-handler.js');
const { handleActionTriggeredByJobScheduler } = require('../../../srv/common-lib/managers/job-scheduler-manager.js');
const Utilities = require('../../../srv/common-lib/utils/utilities.js');
const mailboxProcessingService = require('../../../srv/mailbox-processing-service/mailbox-processing-service.js').default;

describe('mailbox-processing-service', () => {
  let srv;
  let db;
  let log;
  let mailboxDocumentHandlerInstance;
  let attachmentsService;

  beforeEach(() => {
    db = {};
    attachmentsService = { get: jest.fn() };
    log = { info: jest.fn(), error: jest.fn(), debug: jest.fn() };
    cds.connect.to.mockImplementation((name) => {
      if (name === 'db') return db;
      if (name === 'attachments') return attachmentsService;
      return null;
    });
    cds.log.mockReturnValue(log);
    mailboxDocumentHandlerInstance = {
      onProcessDocumentsFromMailbox: jest.fn(),
      onProcessFailedMessagesAndDocuments: jest.fn(),
      onDeleteAllDocuments: jest.fn(),
      onGetMessage: jest.fn(),
      onGetAttachmentsFromMessage: jest.fn(),
      onGetAttachmentContent: jest.fn()
    };
    MailboxDocumentHandler.mockImplementation(() => mailboxDocumentHandlerInstance);
    handleActionTriggeredByJobScheduler.mockClear();
    Utilities.handleHttpError.mockClear();
    srv = { on: jest.fn(), after: jest.fn() };
  });

  it('registers processDocumentsFromMailbox handler and handles success', async () => {
    await mailboxProcessingService(srv);
    const [event, handler] = srv.on.mock.calls.find(([e]) => e === 'processDocumentsFromMailbox');
    const req = {};
    await handler(req);
    expect(log.info).toHaveBeenCalledWith('Action: processDocumentsFromMailbox triggered');
    expect(handleActionTriggeredByJobScheduler).toHaveBeenCalledWith(req, expect.any(Function));
  });

  it('handles error in processDocumentsFromMailbox', async () => {
    await mailboxProcessingService(srv);
    const [event, handler] = srv.on.mock.calls.find(([e]) => e === 'processDocumentsFromMailbox');
    const req = {};
    const error = new Error('fail');
    handleActionTriggeredByJobScheduler.mockImplementation(() => {
      throw error;
    });
    await handler(req);
    expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'processDocumentsFromMailbox');
  });

  it('registers processFailedMessagesAndDocuments handler and handles error', async () => {
    await mailboxProcessingService(srv);
    const [event, handler] = srv.on.mock.calls.find(([e]) => e === 'processFailedMessagesAndDocuments');
    const req = {};
    const error = new Error('fail');
    handleActionTriggeredByJobScheduler.mockImplementation(() => {
      throw error;
    });
    await handler(req);
    expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'processFailedMessagesAndDocuments');
  });
});
