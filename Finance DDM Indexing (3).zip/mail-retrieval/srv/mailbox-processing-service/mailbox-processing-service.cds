using dispute.management as db from '../../../central-db/schema';

@title : 'Mailbox Processing Service'
@Core.Description : 'Mailbox Processing Service'
@requires: ['JOBSCHEDULER']
service MailboxProcessingService {
    action   processDocumentsFromMailbox();
    action   processFailedMessagesAndDocuments();
}
