import cds from '@sap/cds';
import MailboxDocumentHandler from '../lib/handlers/mailbox-document-handler.js';
import { handleActionTriggeredByJobScheduler } from '../common-lib/managers/job-scheduler-manager.js';
import Utilities from '../common-lib/utils/utilities.js';

export default async (srv) => {
  const db = await cds.connect.to('db');
  const log = cds.log('mailbox-document-service');
  const mailboxDocumentHandler = new MailboxDocumentHandler(db);

  srv.on('processDocumentsFromMailbox', async (req) => {
    try {
      log.info('Action: processDocumentsFromMailbox triggered');
      const boundHandler = mailboxDocumentHandler.onProcessDocumentsFromMailbox.bind(mailboxDocumentHandler);
      await handleActionTriggeredByJobScheduler(req, boundHandler);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'processDocumentsFromMailbox');
    }
  });

  srv.on('processFailedMessagesAndDocuments', async (req) => {
    try {
      log.info('Action: processFailedMessagesAndDocuments triggered');
      const boundHandler = mailboxDocumentHandler.onProcessFailedMessagesAndDocuments.bind(mailboxDocumentHandler);
      await handleActionTriggeredByJobScheduler(req, boundHandler);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'processFailedMessagesAndDocuments');
    }
  });
};
