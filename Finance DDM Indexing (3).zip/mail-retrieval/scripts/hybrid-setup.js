import { spawnSync } from 'child_process';
import fs from 'fs';

const SERVICE_BINDINGS = ['ddm-hana-hdi', 'ddm-auth', 'ddm-destination-service', { service: 'ddm-objectstore', serviceArg: 'objectstore' }];

SERVICE_BINDINGS.forEach((serviceBinding) => {
  if (typeof serviceBinding === 'object') {
    spawnSync('cf', ['create-service-key', serviceBinding.service, `${serviceBinding.service}-key`, '-w'], { stdio: 'inherit' });
  } else {
    spawnSync('cf', ['create-service-key', serviceBinding, `${serviceBinding}-key`, '-w'], { stdio: 'inherit' });
  }
});

SERVICE_BINDINGS.forEach((serviceBinding) => {
  if (typeof serviceBinding === 'object') {
    spawnSync('cds', ['bind', serviceBinding.serviceArg, '--to', serviceBinding.service], { stdio: 'inherit' });
  } else {
    spawnSync('cds', ['bind', '--to', serviceBinding], { stdio: 'inherit' });
  }
});

const hybridConfig = await import('../.cdsrc-private.json', { with: { type: 'json' } });

hybridConfig.default.requires['[hybrid]'].db.impl = '@cap-js/hana';

fs.writeFileSync('.cdsrc-private.json', JSON.stringify(hybridConfig.default, null, 2));
