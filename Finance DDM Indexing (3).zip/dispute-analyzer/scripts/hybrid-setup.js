import { spawnSync } from 'child_process';

const SERVICE_BINDINGS = ['ddm-hana-hdi', 'ddm-destination-service', 'ddm-objectstore', 'ddm-job-scheduler'];

SERVICE_BINDINGS.forEach((serviceBinding) => {
  spawnSync('cf', ['create-service-key', serviceBinding, `${serviceBinding}-key`, '-w'], { stdio: 'inherit' });
});

SERVICE_BINDINGS.forEach((serviceBinding) => {
  spawnSync('cds', ['bind', '--to', serviceBinding], { stdio: 'inherit' });
});