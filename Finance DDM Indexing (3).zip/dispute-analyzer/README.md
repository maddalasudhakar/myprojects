# Dispute-analyzer service
It's responsible for sending and getting documents to LLM and to ERP for information extraction and saving them in the database.

## ODATA services exposed

### LLMProcessingService (send-to-llmjob)
Service exposing actions for llm processing in regards to dispute analyzer service information extraction process.
These actions are triggered periodically by the `JOB Scheduling` service:
- `sendDocumentsForLLMProcessing` to send documents in status DOX_DONE (documents processed by DOX with success) to LLM for data extraction,
- `sendDocumentsToOCRForLLMProcessing` to send documents in status DOX_PARTIALLY_DONE (documents processed by DOX with success but information only partially  extracted) to LLM for data extraction,
- `resendDocumentsForLLMProcessing` to resend to LLM documents blocked in SEND_TO_LLM status,
- `sendDocumentsCorrectedForLLMProcessing` to send documents in status DOX_CORRECTION_DONE (documents that were corrected by user) to LLM for data extraction. This job exists so that corrected documents will be processed separately from the ones in DOX_DONE so that the user will not have to wait too much for the corrected documents.

All these jobs take the oldest documents from the queue.

**Actions (HTTP POST):**
- `POST https://service_hostname:port/odata/v4/send-to-llmjob/sendDocumentsForLLMProcessing()`
- `POST https://service_hostname:port/odata/v4/send-to-llmjob/sendDocumentsToOCRForLLMProcessing()`
- `POST https://service_hostname:port/odata/v4/send-to-llmjob/resendDocumentsForLLMProcessing()`
- `POST https://service_hostname:port/odata/v4/send-to-llmjob/sendDocumentsCorrectedForLLMProcessing()`

## Processes flow description

All the HTTP POST actions follow the same flow with a different status (see SEND_TO_LLM_diagram.png process flow diagram).

When any of the actions is triggered the following process is started:
A configurable number of documents with status {status_according_to_type_of_job} is taken from the database. If no documents are found the process stops. If documents are found, process continues with updating the processingStatus. This is only done when required (done for all jobs except the one that takes and sends documents blocked in SENDING_TO_LLM state to the LLM). The rule books are fetched from the database for all documents and put in the processing details that will be sent, together with the documents, for processing in batches.
There are 2 flows for processing documents batches:
- the OCR process and LLM processing
- the LLM processing, that can include OCR fallback when response contains `not specified`

LLM processing:
Validation and update of the documents data with the customer master data is done, but only if shipTo, soldTo or customerNumber are null. The processing details will contain the rule book data associated to the selected document. A connection to the AI model is initialized and the prompt information is fetched based on the rule book data. The data is sent to the LLM (done in parallel for the configured number of documents in batch processing). In case of error a retry is done and if an error still occurs then a check for TOO_MANY_REQUESTS error is performed and a retry process after a configurable time and with a configurable number of retries. In any other error case the processing status LLM_FAILED, status INVALID and the error reason are returned. In case of success, the response from the LLM is parsed. If the parsing is done with error a retry process for sending to the LLM and and a retrial for parsing again is done. If an error still occurs then the processing status LLM_FAILED, status INVALID and the error reason are returned. In case the parsing was done successfully, the llm response will be checked for containing `not specified`. If `not specified` does not occur the LLM response will be returned together with the processing status LLM_DONE ,and the status NEW. If `not specified` occurs OCR process is triggered before returning any final response (OCR porcessing can only be triggered once and can be deactivated using the configurable environment variable).

User-provided configurable variables used in the described process:
OCR_FALLBACK_ENABLED - can be `true` or `false` depending on the needs of the users
MAX_RETRIES - a number, the maximum number of retries
RETRY_DELAY_MINUTES - a number, the delay in minutes after which the retry is done
THRESHOLD_TIME_MINUTES - a number, used for taking the documents that were not modified in the last THRESHOLD_TIME_MINUTES, to take only the oldest documents 
MAX_DOCUMENTS - the maximum number of documents to be fetched from the database - maximum number of documents that can be processed by the LLM at once is 100
MAX_BATCHES_TO_PROCESS - the maximum number of batches to be processed in parallel
MAX_ROWS_IN_BATCH - the maximum number of documents to be processed in a batch


OCR process:

In case OCR is triggered, processing details for document will be enriched with the document in text format. The processing details will already contain the rule book for the document. For getting the text of the document a call will be done to the doc-retrieval that will return the needed text content. The fields that are extracted using DOX are now extracted based on the document text directly by the LLM model. If the data extraction result is invalid or inexistent the flow stops. If data is extracted successfully then new header fields and line item fields will be updated in the database and the normal LLM processing will be started.


### DisputeAnalyzerService (dispute-analyzer)
This service exposes documents entity for READ and UPDATE since these are the actions that the users can trigger from the UI.
The action `sendDocumentsToERP` is used to send documents processed by LLM to ERP if the data is valid to be sent,
The action `rejectDocument` is triggered when a user is rejecting a document, the document will change to the status REJECTED.

**Actions (HTTP requests):**
- `POST https://service_hostname:port/odata/v4/dispute-analyzer/sendDocumentsToERP()` with body {"documentIds":["id_string1", "id_string2"]}
- `POST https://service_hostname:port/odata/v4/dispute-analyzer/rejectDocument()` with body {"documentId": "id_string", reason: "reason"}
- `GET https://service_hostname:port/odata/v4/dispute-analyzer/Documents`
- `PATCH https://service_hostname:port/odata/v4/dispute-analyzer/Documents(ID='id',IsActiveEntity=false)` with body {....} -> patch request is done when entity is inactive (when in draft mode); the body can contain any of the document fields

## Processes flow description

Send documents to ERP process:
Documents are sent to ERP if processing status is LLM_DONE or if status is ERP_FAILED. If status is PROCESSED the  documents will be skipped. The documents are processed in batches.

User-provided configurable variables used in the described process:
MAX_BATCHES_TO_PROCESS - the maximum number of batches to be processed in parallel
MAX_ROWS_IN_BATCH - the maximum number of documents to be processed in a batch

 Reject process - document will be rejected if not already rejected


Edit process:
working as shown in diagram EDIT_diagram.png


### MasterdataSynchService (masterdata-synch)
This service exposes an action for synchronizing the master data from the customer database in our database

**Actions (HTTP requests):**
- `POST https://service_hostname:port/odata/v4/dispute-analyzer/synchronizeMasterdata()` 


## Processes flow description
When triggering synchronizeMasterdata() a deletion and insertion with all the master data from the customer system is done in the database

## Additional Resources

![Process Flow - LLMProcessingService](readme-resources/OCR_diagram.png)
![Process Flow - LLMProcessingService](readme-resources/SEND_TO_LLM_diagram.png)
![Process Flow - DisputeAnalyzerService](readme-resources/EDIT_diagram.png)