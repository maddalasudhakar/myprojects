using dispute.management as db from '../../../central-db/schema';

@title               : 'Dispute Analyzer Service'
@Core.LongDescription: 'Service to manage documents'
@Core.Description    : 'Dispute analyzer service'
service DisputeAnalyzerService {
  @(restrict: [{
    grant: [
      'READ',
      'UPDATE'
    ],
    to   : ['BusinessUser']
  }])
    entity Documents as
    projection on db.Documents {
      *,
      currentTimeLineInHoursVsNow              @readonly,
      timeDurationInHours                      @readonly,
      message.subject as emailSubject : String @Core.Computed
    };

  @(restrict: [{
    grant: ['READ'],
    to   : ['BusinessUser']
  }])
  entity Companies as
    select from db.Companies as companies {
      *,
      case
        when
          ruleBook.ID is not null
          and exists(
            select reasonCodeMappings.ID from db.ReasonCodeMappings as reasonCodeMappings
            where
              reasonCodeMappings.ruleBook.ID = companies.ruleBook.ID
          )
          and exists(
            select businessAreaCodeMappings.ID from db.BusinessAreaCodeMappings as businessAreaCodeMappings
            where
              businessAreaCodeMappings.ruleBook.ID = companies.ruleBook.ID
          )
        then
          'Yes'
        else
          'No'
      end as hasRuleBook : String @Core.Computed
    };

      @(restrict: [{
    grant: 'EXECUTE',
    to   : 'BusinessUser'
  }])
  action sendDocumentsToERP(documentIds: array of String);

  @(restrict: [{
    grant: 'EXECUTE',
    to   : 'BusinessUser'
  }])
  action rejectDocument(documentId: UUID, reason: String) returns Boolean;
}

annotate DisputeAnalyzerService.Documents with  @odata.draft.enabled  @odata.draft.bypass;
