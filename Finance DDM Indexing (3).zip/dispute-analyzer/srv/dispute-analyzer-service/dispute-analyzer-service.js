import cds from '@sap/cds';
import { StatusCodes } from 'http-status-codes';
import { handleRejectDocument } from '../lib/handlers/reject-handler.js';
import Utilities from '../common-lib/utils/utilities.js';
import DocumentsRepository from '../common-lib/repository/documents-repository.js';
const log = cds.log('dispute-analyzer-service');
import SendToERPHandler from '../lib/handlers/send-to-erp-handler.js';
import { LLM_EXTRACTION_STATUS, PROCESSING_STATUS, ERP_PROCESSING_STATUS } from '../common-lib/utils/constants.js';

const sendToERPHandler = new SendToERPHandler();

// Helper function for validation
const validateRejectDocumentInput = (documentId, reason, req) => {
  if (!documentId || !reason) {
    req.error(StatusCodes.BAD_REQUEST, 'Both documentId and reason are required.');
    return false;
  }
  if (!Utilities.isValidUUID(documentId)) {
    log.error(`Invalid document ID: ${documentId}`);
    req.error(StatusCodes.BAD_REQUEST, 'Invalid document ID. It must be a valid UUID.');
    return false;
  }
  if (typeof reason !== 'string' || reason.length > 255) {
    log.error(`Invalid rejection reason: ${reason}`);
    req.error(StatusCodes.BAD_REQUEST, 'Invalid rejection reason. It must be a string with a maximum length of 255 characters.');
    return false;
  }
  return true;
};

// Helper function to calculate time difference in hours and minutes between two timestamps
const calculateTimeDifference = (startTime, endTime) => {
  if (!(startTime instanceof Date) || isNaN(startTime.getTime()) || !(endTime instanceof Date) || isNaN(endTime.getTime())) {
    log.error('Invalid timestamps provided for time difference calculation:', { startTime, endTime });
    return 'Invalid time difference';
  }

  
 const diffInMs = endTime - startTime;
 const diffInHours = Math.floor(diffInMs / 36e5);
 const diffInMinutes = Math.floor((diffInMs % 36e5) / 60000);
 return `${diffInHours} h : ${diffInMinutes} min`;
};

const validateRequestData = (req) => {
  if (!req.data?.ID) {
    log.error('Invalid request data for SAVE operation:', req.data);
    req.error(StatusCodes.BAD_REQUEST, 'Invalid request data. Document ID is required for SAVE operation.');
    return false;
  }
  return true;
};

const fetchDocuments = async (documentId) => {
  const documentsRepository = new DocumentsRepository();
  const [document, draftDocument] = await Promise.all([
    documentsRepository.getDocumentById(documentId),
    documentsRepository.getDraftDocumentById(documentId)
  ]);
  log.info(`Fetched document and draft document for ID ${documentId}.`);
  return { document, draftDocument };
};

const processDocument = (document, draftDocument, documentId, req) => {
  let keysToCheck = [
      'henkelInvoice',
      'customerExternalReference',
      'amount',
      'soldTo',
      'shipTo',
      'customerNumber',
      'debitNoteDate',
      'taxReportingDate',
      'netDueDate'
  ];
  if (
    document.processingStatus !== LLM_EXTRACTION_STATUS.DONE &&
    document.processingStatus !== ERP_PROCESSING_STATUS.ERP_DONE &&
    document.processingStatus !== ERP_PROCESSING_STATUS.ERP_FAILED
  ) {
    log.info(`Processing document with ID ${documentId} for SAVE operation if document is invalid.`);

    const checkFieldValid = (field) => {
      return draftDocument[field] && draftDocument[field] !== 'not specified' ? true : false;
    };

    const isBusinessAreaCodeValid = checkFieldValid('businessAreaCode');
    const isReasonCodeValid = checkFieldValid('reasonCode');

    const otherFieldsChanged = keysToCheck.some((key) => {
      return draftDocument[key] !== document[key];
    });

    log.info(`Draft document with ID ${documentId} has changes:`, {
      isBusinessAreaCodeValid,
      isReasonCodeValid,
      otherFieldsChanged
    });

    if (otherFieldsChanged && !(isBusinessAreaCodeValid && isReasonCodeValid)) {
      log.info(`Draft document with ID ${documentId} has other fields updated. Updating status to DOX_CORRECTION_DONE.`);
      req.data.processingStatus = PROCESSING_STATUS.DOX_CORRECTION_DONE;
      req.data.isModifiedByUser = 'Yes'; 
    }

    if (isBusinessAreaCodeValid && isReasonCodeValid) {
      log.info(`Draft document with ID ${documentId} has valid business area and reason code. Updating status to LLM_DONE.`);
      req.data.processingStatus = LLM_EXTRACTION_STATUS.DONE;
      req.data.isModifiedByUser = 'Yes'; 
    }
  } else {
    keysToCheck.push('businessAreaCode','reasonCode');
    const fieldsChanged = keysToCheck.some((key) => {
      return draftDocument[key] !== document[key];
    });
    if (fieldsChanged) {
      req.data.isModifiedByUser = 'Yes'; 
    }
    log.info(`Document with ID ${documentId} is already processed or in a state that does not require further processing.`);
  }
  return req;
};

export default async (srv) => {

  
  srv.before('READ', "Documents.attachments", async (req) => {
    console.log("inside document attachments before");
    req.req.url = decodeURIComponent(req.req.url);
  });


  srv.on('READ', 'Documents', async (req, next) => {
    try {
      const documents = await next();
      const now = new Date();

      // Ensure documents is always an array
      const documentsArray = Array.isArray(documents) ? documents : [documents];

      // Filter documents that require computation
      const docsToProcess = documentsArray.filter(
        (doc) => doc.mailReceivedTimestamp || (doc.mailReceivedTimestamp && doc.documentSentToErpOrRejected)
      );

      for (const doc of docsToProcess) {
        if (!doc.mailReceivedTimestamp) {
            continue; // Skip if mailReceivedTimestamp is not available
        }
        const mailReceivedTime = new Date(doc.mailReceivedTimestamp);
        const documentSentTime = doc.documentSentToErpOrRejected ? new Date(doc.documentSentToErpOrRejected) : null;

        doc.currentTimeLineInHoursVsNow = calculateTimeDifference(mailReceivedTime, now);

        if (documentSentTime) {
            doc.timeDurationInHours = calculateTimeDifference(mailReceivedTime, documentSentTime);
        }
      }
      return documents;
    } catch (error) {
      log.error('Error reading documents:', error);
      req.error(StatusCodes.INTERNAL_SERVER_ERROR, `An error occurred while fetching documents: ${error.message}`);
    }
  });

  srv.before('SAVE', 'Documents', async (req) => {
    if (!validateRequestData(req)) {
      return;
    }

    const documentId = req.data.ID;
    try {
      const { document, draftDocument } = await fetchDocuments(documentId);

      if (!document || !draftDocument) {
        const missingEntity = !document ? 'Document' : 'Draft document';
        log.error(`${missingEntity} with ID ${documentId} not found for SAVE operation.`);
        req.error(StatusCodes.NOT_FOUND, `${missingEntity} with ID ${documentId} not found.`);
        return;
      }

      req = processDocument(document, draftDocument, documentId, req);
    } catch (error) {
      log.error('Error in before SAVE handler for Documents:', error);
      req.error(StatusCodes.INTERNAL_SERVER_ERROR, `An error occurred while processing documents: ${error.message}`);
    }
  });

  srv.on('SAVE', 'Documents', async (req, next) => {
    try {
      log.info('Action: SAVE triggered for Documents with data:', req.data);
      await next();
      if (req.data?.processingStatus && req.data?.ID) {
        log.info(`Processing status for document with ID ${req.data.ID} updating to ${req.data.processingStatus}.`);
        const documentsRepository = new DocumentsRepository();
        await documentsRepository.updateDocumentProcessingStatus(req.data.ID, req.data.processingStatus);
      }
    } catch (error) {
      log.error('Error in SAVE handler for Documents:', error);
      req.error(StatusCodes.INTERNAL_SERVER_ERROR, `An error occurred while saving documents: ${error.message}`);
    }
  });

  srv.on('rejectDocument', async (req) => {
    try {
      log.info('Action: rejectDocument triggered');
      const { documentId, reason } = req.data;

      // Use helper function for validation
      if (!validateRejectDocumentInput(documentId, reason, req)) {
        return;
      }
      return await handleRejectDocument(documentId, reason);
    } catch (error) {
      log.error('Error rejecting document:', error);
      if (error.message.includes('not found')) {
        req.error(StatusCodes.BAD_REQUEST, `Document with ID ${req.data.documentId} not found.`);
      } else if (error.message.includes('already rejected')) {
        req.error(StatusCodes.CONFLICT, `Document with ID ${req.data.documentId} is already rejected.`);
      } else {
        req.error(
          StatusCodes.INTERNAL_SERVER_ERROR,
          `An error occurred while rejecting the document: ${error.message}. Please check the server logs for more details.`
        );
      }
    }
  });

  srv.on('sendDocumentsToERP', async (req) => {
    try {
      log.info('Triggering action sendDocumentsToERP in background');
      const documentIds = req.data.documentIds;
      if (!documentIds || !documentIds.length) {
        req.error(StatusCodes.BAD_REQUEST, 'No documents provided for processing.');
        return;
      }

      // Filter out invalid UUIDs
      const validDocumentIds = documentIds.filter((id) => Utilities.isValidUUID(id));
      if (validDocumentIds.length !== documentIds.length) {
        req.error(StatusCodes.BAD_REQUEST, 'Some document IDs are invalid UUIDs.');
        return;
      }

      log.info('Starting ERP processing for documents...');

      cds.spawn({ user: req.user }, async () => {
        await sendToERPHandler.sendToERP(validDocumentIds);
      });

      log.info('Action sendDocumentsToERP triggered to run in the background successfully.');
      req.res.status(StatusCodes.ACCEPTED);
    } catch (error) {
      log.error('Error sending documents to ERP:', error);
      req.res.status(StatusCodes.INTERNAL_SERVER_ERROR);
    }
  });

  srv.before('EDIT', 'Documents', async (req) => {
    console.log('triggered draftedit');
    // First check the status
    if (req.data.status === 'processed') {
      return req.error('Not accepted for processed case');
    }

    // Then check the scope for Business user. req.user.is('admin')
    if (!req.user.is('BusinessUser') && !req.user.is('Administrator')) {
      return req.error(403, 'Not authorized to create draft');
    }
  });

  srv.before('CREATE', 'Documents.drafts', async (req) => {
    console.log('triggered draftedit');
    // First check the status
    if (req.data.status === 'processed') {
      return req.error('Not accepted for processed case');
    }

    // Then check the scope for Business user
    if (!req.user.is('BusinessUser') && !req.user.is('Administrator')) {
      return req.error(403, 'Not authorized to create draft');
    }
  }); 
};
