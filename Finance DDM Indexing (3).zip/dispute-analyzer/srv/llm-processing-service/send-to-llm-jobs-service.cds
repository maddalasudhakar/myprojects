@title : 'Send Documents To LLM Job Service'
@Core.LongDescription : 'Service to manage documents sending to LLM'
@Core.Description : 'Send documents to LLM job service'
@requires: ['JOBSCHEDULER']
 service SendToLLMJobService {
   action sendDocumentsForLLMProcessing();
   action sendDocumentsToOCRForLLMProcessing();
   action resendDocumentsForLLMProcessing();
   action sendDocumentsCorrectedForLLMProcessing();
 }