import cds from '@sap/cds';
import RetryHandler from '../common-lib/handlers/retry-handler.js';
import { handleActionTriggeredByJobScheduler } from '../common-lib/managers/job-scheduler-manager.js';
import CommonLLMProcessingHandler from '../lib/handlers/common-llm-processing-handler.js';
import { PROCESSING_STATUS, LLM_PROCESSING_STATUS } from '../common-lib/utils/constants.js';
import { MAX_RETRIES, RETRY_DELAY_MINUTES, THRESHOLD_TIME_MINUTES } from '../lib/utils/constants.js';
import Utilities from '../common-lib/utils/utilities.js';

const log = cds.log('send-to-llm-job-service');

export default async (srv) => {
  srv.on('sendDocumentsForLLMProcessing', async (req) => {
    try {
      log.info('Action: sendDocumentsForLLMProcessing triggered');
      await handleActionTriggeredByJobScheduler(req, CommonLLMProcessingHandler.sendDoxDoneDocumentsForLLMProcessing);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'sendDocumentsForLLMProcessing');
    }
  });

  srv.on('sendDocumentsToOCRForLLMProcessing', async (req) => {
    try {
      log.info('Action: sendDocumentsToOCRForLLMProcessing triggered');
      await handleActionTriggeredByJobScheduler(req, CommonLLMProcessingHandler.sendDoxPartiallyDoneDocumentsForLLMProcessing);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'sendDocumentsToOCRForLLMProcessing');
    }
  });

  srv.on('resendDocumentsForLLMProcessing', async (req) => {
    try {
      log.info('Action: resendDocumentsForLLMProcessing triggered');
      await handleActionTriggeredByJobScheduler(req, CommonLLMProcessingHandler.resendDocumentsForLLMProcessing);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'resendDocumentsForLLMProcessing');
    }
  });

  srv.on('sendDocumentsCorrectedForLLMProcessing', async (req) => {
    try {
      log.info('Action: sendDocumentsCorrectedForLLMProcessing triggered');
      await handleActionTriggeredByJobScheduler(req, CommonLLMProcessingHandler.sendDocumentsCorrectedForLLMProcessing);
    } catch (error) {
      Utilities.handleHttpError(req, error, 'sendDocumentsCorrectedForLLMProcessing');
    }
  });
};
