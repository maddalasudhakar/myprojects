@title : 'Masterdata Synchronization Service'
@Core.LongDescription : 'Service exposing actions for masterdata synchronization'
@Core.Description : 'Masterdata Synchronization Service'
@requires: ['JOBSCHEDULER']
service MasterdataSynchService  {
    action synchronizeMasterdata();
}
