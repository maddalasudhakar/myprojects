import cds from '@sap/cds';
import MasterDataHandler from '../lib/handlers/masterdata-handler.js';
import { handleActionTriggeredByJobScheduler } from '../common-lib/managers/job-scheduler-manager.js';
import Utilities from '../common-lib/utils/utilities.js';

const log = cds.log('masterdata-synch-service');

export default async (srv) => {
    srv.on('synchronizeMasterdata', async (req) => {
        try {
            log.info('Action: synchronizeMasterdata triggered');
            await handleActionTriggeredByJobScheduler(req, MasterDataHandler.synchronizeMasterdata);
        } catch (error) {
            Utilities.handleHttpError(req, error, 'synchronizeMasterdata');
        }
    });
};
