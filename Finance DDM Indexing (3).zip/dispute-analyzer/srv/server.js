import cds from '@sap/cds';
import helmet from "helmet";


cds.on('bootstrap', (app) => {
    app.use(
      helmet({
        contentSecurityPolicy: {
          directives: {
            defaultSrc: ["'self'"],
            connectSrc: ["sapui5.hana.ondemand.com", "'self'"],
            scriptSrc: ["sapui5.hana.ondemand.com", "'self'", "'unsafe-eval'", "'unsafe-inline'"],
            styleSrc: ["sapui5.hana.ondemand.com", "'self'", "'unsafe-inline'"],
            fontSrc: ["sapui5.hana.ondemand.com", "'self'", "data:"],
            imgSrc: ["sapui5.hana.ondemand.com", "'self'", "data:"]
          },
        },
      }),
    );
});

export default cds.server;
