## dispute-analyzer-ui (Document Inbound Processing)

**dispute-analyzer-ui** is an SAP UI5 application for Henkel DDM Indexing, focused on document inbound processing and dispute analysis. It provides a Fiori-based interface for users to manage, analyze, and process business documents and disputes. It connects to a dispute-analyzer-srv CAP backend and is designed for easy extension and integration with other business processes.

### Features

- SAP Fiori UI5 interface
- Connects to CAP service for dispute analysis
- Easily extendable and customizable

### Getting Started

1. **Install dependencies:**
   ```sh
   npm install
   ```
2. **Start the CAP backend:**
   ```sh
   cds watch
   ```
3. **Start the UI5 application:**
   ```sh
   npm run start
   ```
   or for local development with a different port:
   ```sh
   npm run start:local
   ```
4. **Open the application in your browser:**
   [http://localhost:4004/dispute-analyzer-ui/webapp/index.html](http://localhost:4004/dispute-analyzer-ui/webapp/index.html)

### Available Commands

| Command                          | Description                                                                              |
| -------------------------------- | ---------------------------------------------------------------------------------------- |
| `npm run unit-tests`             | Run unit tests and open the unit test QUnit page in the browser                          |
| `npm run int-tests`              | Run integration (OPA) tests and open the integration test QUnit page in the browser      |
| `npm run build`                  | Build the UI5 application with preload and deployment configuration                      |
| `npm run start`                  | Serve the UI5 app using the deployment configuration                                     |
| `npm run start:local`            | Serve the UI5 app locally on port 4013 with local configuration                          |
| `npm run start:test`             | Serve the UI5 app for testing on port 8765, accepting remote connections                 |
| `npm run test:ci`                | Run tests in CI mode: start test server, then run unit tests with coverage and reporting |
| `npm run test-runner:unit-tests` | Run unit tests using ui5-test-runner with coverage and report generation                 |

### Prerequisites

- Node.js LTS (see [nodejs.org](https://nodejs.org))
- npm (comes with Node.js)
- SAP Fiori tools (optional, for development)

### Development Notes

- The app was generated using SAP Fiori tools - App Generator.
- Source code is located in the `webapp` directory.
- To modify the UI, edit files in `webapp/view` and `webapp/controller`.

### Additional Resources

- [SAP Fiori Tools Documentation](https://help.sap.com/docs/fiori-tools)
- [UI5 Documentation](https://ui5.sap.com/)

## Application Details

|                                                                                                    |
| -------------------------------------------------------------------------------------------------- |
| **Generation Date and Time**<br>Tue Mar 04 2025 16:31:49 GMT+0200 (Eastern European Standard Time) |
| **App Generator**<br>@sap/generator-fiori-freestyle                                                |
| **App Generator Version**<br>1.16.5                                                                |
| **Generation Platform**<br>Visual Studio Code                                                      |
| **Template Used**<br>simple                                                                        |
| **Service Type**<br>Local Cap                                                                      |
| **Service URL**<br>http://localhost:4004/odata/v4/dispute-analyzer/                                |
| **Module Name**<br>dispute-analyzer-ui                                                             |
| **Application Title**<br>Document Inbound Processing                                               |
| **Namespace**<br>                                                                                  |
| **UI5 Theme**<br>sap_horizon                                                                       |
| **UI5 Version**<br>1.133.0                                                                         |
| **Enable Code Assist Libraries**<br>True                                                           |
| **Enable TypeScript**<br>False                                                                     |
| **Add Eslint configuration**<br>False                                                              |
