sap.ui.define(['sap/ui/core/UIComponent', './model/models'], (UIComponent, models) => {
  'use strict';

  return UIComponent.extend('disputeanalyzerui.Component', {
    metadata: {
      manifest: 'json',
      interfaces: ['sap.ui.core.IAsyncContentCreation']
    },

    init() {
      // call the base component's init function
      UIComponent.prototype.init.apply(this, arguments);

      // set the device model
      this.setModel(models.createDeviceModel(), 'device');

      // enable routing
      this.getRouter().initialize();

      (function () {
        const originalOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url) {
          if (url.startsWith('blob:') && method.toUpperCase() === 'HEAD') {
            method = 'GET';
          }
          return originalOpen.call(this, method, url, ...Array.prototype.slice.call(arguments, 2));
        };
      })();
    }
  });
});
