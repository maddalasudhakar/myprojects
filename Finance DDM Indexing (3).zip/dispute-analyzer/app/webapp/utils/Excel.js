sap.ui.define(['sap/ui/export/Spreadsheet'], function (Spreadsheet) {
  'use strict';

  return {
    export: function (oTable, sFileName) {
      const { oDataSource, aColumns } = this._generateExportDataFromTable(oTable);

      const oSettings = {
        workbook: {
          columns: aColumns,
          hierarchyLevel: 'Level'
        },
        dataSource: oDataSource,
        fileName: sFileName
      };
      if (oDataSource) {
        const oSheet = new Spreadsheet(oSettings);
        oSheet.build().finally(function () {
          oSheet.destroy();
        });
      }
    },

    _generateExportDataFromTable: function (oTable) {
      const oDataSource = oTable.getBinding('rows');
      const aColumns = this._generateColumns(oTable, oDataSource);
      return { oDataSource, aColumns };
    },

    _generateColumns: function (oTable, oRowsBinding) {
      const aTableColumns = oTable.getColumns();
      const sODataEntitySetPath = oRowsBinding?.getPath();
      const oMetaModel = oRowsBinding?.getModel()?.getMetaModel();

      return aTableColumns.map((oColumn) => {
        const sLabel = oColumn.getLabel().getText();
        const oBindingInfo = oColumn.getTemplate().getBindingInfo('text') || oColumn.getTemplate().getBindingInfo('selected');
        const sProperty = oBindingInfo?.parts[0]?.path;
        const oPropertyMetaModel = oMetaModel?.getObject(sODataEntitySetPath + '/' + sProperty);
        const sType = this._determinePropertyType(oPropertyMetaModel);

        return {
          label: sLabel,
          property: sProperty,
          type: sType
        };
      });
    },

    _determinePropertyType: function (oPropertyMetaModel) {
      const sEdmType = (oPropertyMetaModel && oPropertyMetaModel.$Type) || 'Edm.String';

      switch (sEdmType) {
        case 'Edm.Int32':
        case 'Edm.Int64':
        case 'Edm.Double':
        case 'Edm.Decimal':
          return 'Number';
        case 'Edm.Boolean':
          return 'Boolean';
        case 'Edm.DateTime':
        case 'Edm.Date':
        default:
          return 'String';
      }
    }
  };
});
