sap.ui.define(['sap/ui/model/FilterOperator'], function (FilterOperator) {
  'use strict';

  const FILTER_TYPE = {
    INPUT_EQUAL: {
      type: 'input',
      operator: FilterOperator.EQ
    },
    INPUT_CONTAINS: {
      type: 'input',
      operator: FilterOperator.Contains
    },
    MULTI_COMBOBOX: {
      type: 'multi-combo',
      operator: FilterOperator.EQ
    },
    INPUT_FROM: {
      type: 'input',
      operator: FilterOperator.GE
    },
    INPUT_TO: {
      type: 'input',
      operator: FilterOperator.LE
    },
    DATE_RANGE: {
      type: 'date-range',
      operator: FilterOperator.BT
    },
    COMBOBOX: {
      type: 'combo',
      operator: FilterOperator.EQ
    }
  };

  const COMMON_SORT = [
    {
      key: 'customerNumber'
    },
    {
      key: 'customerName'
    },
    {
      key: 'businessAreaCode',
      text: 'businessArea'
    },
    {
      key: 'customerExternalReference'
    },
    {
      key: 'henkelInvoice'
    },
    {
      key: 'amount'
    },
    {
      key: 'reasonCode'
    },
    {
      key: 'debitNoteDate'
    },
    {
      key: 'llmCodeExplanation',
      text: 'codeExplanation'
    },
    {
      key: 'status'
    },
    {
      key: 'emailSubject'
    },
    {
      key: 'mailReceivedTimestamp'
    }
  ];

  const INVALID_DOCUMENTS_SORT = [
    {
      key: 'errorReason',
      text: 'validationError'
    },
    {
      key: 'notSendingToERPReason',
      text: 'reasonErpDecline'
    }
  ];

  const PROCESSED_DOCUMENTS_SORT = [
    { key: 'confidenceLevel' },
    {
      key: 'mailReceivedTimestamp',
      text: 'currentTimelineHours'
    },
    {
      key: 'documentSentToErpOrRejected',
      text: 'documentProccessedSentToErp'
    },
    {
      key: 'documentSentToErpOrRejected',
      text: 'timeDurationHours'
    },
    {
      key: 'taxReportingDate'
    },
    {
      key: 'netDueDate'
    },
    {
      key: 'shipTo'
    },
    {
      key: 'soldTo'
    }
  ];

  return {
    DISPUTE_ANALYZER: {
      PATH: 'odata/v4/dispute-analyzer',
      TABLE_CONTAINER_ID: 'disputeAnalyzerTableContainer',
      PAGE_ID: 'disputeAnalyzerPage'
    },

    API: {
      DOCUMENTS: {
        PATH: 'Documents',
        DEFAULT_FILTER_COLUMN: 'processingStatus'
      }
    },

    INVALID_DOCUMENTS: {
      TABLE_ID: 'invalidDocumentsTable',
      TITLE_KEY: 'invalidDocumentsTitle',
      COUNT_KEY: 'invalidDocuments.title.count',
      FILTER_VALUES: ['DOX_FAILED', 'VALIDATION_FAILED', 'LLM_FAILED', 'INVALID_MAIL'],
      SORT: [...COMMON_SORT, ...INVALID_DOCUMENTS_SORT]
    },

    PROCESSED_DOCUMENTS: {
      TABLE_ID: 'processedDocumentsTable',
      TITLE_KEY: 'processedDocumentsTitle',
      COUNT_KEY: 'processedDocuments.title.count',
      FILTER_VALUES: ['LLM_DONE', 'ERP_FAILED', 'ERP_DONE'],
      SORT: [...COMMON_SORT, ...PROCESSED_DOCUMENTS_SORT]
    },

    FILTERS: {
      companyCode: FILTER_TYPE.INPUT_CONTAINS,
      customerNumber: FILTER_TYPE.INPUT_CONTAINS,
      customerName: FILTER_TYPE.INPUT_CONTAINS,
      businessArea: {
        ...FILTER_TYPE.INPUT_CONTAINS,
        filterPath: 'businessAreaCode'
      },
      customerExternalReference: FILTER_TYPE.INPUT_CONTAINS,
      henkelInvoice: FILTER_TYPE.INPUT_CONTAINS,
      amountFrom: {
        ...FILTER_TYPE.INPUT_FROM,
        filterPath: 'amount'
      },
      amountTo: {
        ...FILTER_TYPE.INPUT_TO,
        filterPath: 'amount'
      },
      reasonCode: FILTER_TYPE.INPUT_CONTAINS,
      debitNoteDate: FILTER_TYPE.DATE_RANGE,
      confidenceLevel: FILTER_TYPE.MULTI_COMBOBOX,
      status: FILTER_TYPE.MULTI_COMBOBOX,
      mailReceivedTimestamp: FILTER_TYPE.DATE_RANGE,
      documentSentToErpOrRejected: FILTER_TYPE.DATE_RANGE,
      emailSubject: FILTER_TYPE.INPUT_CONTAINS,
      isModifiedByUser: FILTER_TYPE.COMBOBOX
    },

    STATUS_MAP: {
      NEW: 'new',
      PROCESSED: 'processed',
      REJECTED: 'rejected',
      INVALID: 'invalid'
    },

    CONFIDENCE_LEVEL_MAP: {
      LOW: 'low',
      MEDIUM: 'medium',
      HIGH: 'high'
    },

    CONFIDENCE_LEVEL_STATE_MAP: {
      LOW: 'Error',
      MEDIUM: 'Warning',
      HIGH: 'Success'
    }
  };
});
