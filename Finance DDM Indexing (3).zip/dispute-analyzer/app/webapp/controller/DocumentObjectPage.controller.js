sap.ui.define(
  [
    'disputeanalyzerui/controller/App.controller',
    'sap/ui/core/UIComponent',
    'disputeanalyzerui/utils/Constants',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/core/Fragment',
    'sap/m/MessageBox',
    'sap/m/PDFViewer',
    'sap/base/security/URLListValidator',
    'sap/m/Image',
    'sap/ui/model/json/JSONModel',
    'sap/m/Text'
  ],
  (Controller, UIComponent, Constants, Filter, FilterOperator, Fragment, MessageBox, PDFViewer, URLListValidator, Image, JSONModel, Text) => {
    'use strict';

    return Controller.extend('disputeanalyzerui.controller.DocumentObjectPage', {
      onInit: function () {
        Controller.prototype.onInit.apply(this, arguments);

        this.oObjectPage = this.byId('documentObjectPage');
        this.oRouter = UIComponent.getRouterFor(this);

        this.oContentViewerContainer = this.getView().byId('pdfViewerContainer');

        this.oRouter.getRoute('RouteDocumentObjectPage').attachPatternMatched(this._onPatternMatched, this);
      },

      /**
       * Binds the view to the document object page
       */
      _onPatternMatched: function (oEvent) {
        this.sDocumentId = oEvent.getParameter('arguments').documentId;
        this._bindObjectPage(true);
      },

      _bindObjectPage: async function (bIsActiveEntity) {
        this.oContentViewerContainer.destroyItems();

        const oBinding = this.oModel.bindList(
          `/${Constants.API.DOCUMENTS.PATH}`,
          undefined,
          [],
          [new Filter('ID', FilterOperator.EQ, this.sDocumentId), new Filter('IsActiveEntity', FilterOperator.EQ, bIsActiveEntity)],
          {
            $expand: 'DraftAdministrativeData,attachments',
            $select: '*'
          }
        );
        const oContexts = await oBinding.requestContexts();
        const oContext = oContexts[0];

        const oData = oContext.getObject();
        if (bIsActiveEntity && oData.IsActiveEntity && oData.DraftAdministrativeData?.DraftIsCreatedByMe) {
          this._bindObjectPage(false);
          return;
        }

        this.oObjectPage.setBindingContext(oContext);

        this.getView()
          .byId('erpErrorStatus')
          .setVisible(Boolean(oData.sendingToERPError && oData.sendingToERPError.length > 0));

        const oAttachment = oData.attachments?.[0];
        if (oAttachment) {
          const oResponse = await fetch(
            `${this.oModel.sServiceUrl}${Constants.API.DOCUMENTS.PATH}(ID=${this.sDocumentId},IsActiveEntity=${bIsActiveEntity})/attachments(ID=${oAttachment.ID})/content`
          );
          const oContent = await oResponse.blob();
          const sBlobUrl = URL.createObjectURL(oContent);
          URLListValidator.add('blob');

          const sMimeType = oAttachment.mimeType;

          if (sMimeType === 'application/pdf') {
            this._createPDFViewer(sBlobUrl, oAttachment.filename);
          } else if (sMimeType === 'image/png' || sMimeType === 'image/jpeg') {
            this._addViewer(sBlobUrl, oAttachment.filename, true);
          } else {
            this._addViewer(sBlobUrl, oAttachment.filename, false);
          }
        } else {
          this._addNoDocumentAvailableViewer();
        }
      },

      _addNoDocumentAvailableViewer: function () {
        this.oContentViewerContainer.addItem(
          new Text({
            text: this._getI18nText('noDocumentAvailable'),
            textAlign: 'Center',
            class: 'sapUiSmallMargin',
            width: '100%',
            wrapping: true,
            visible: true
          })
        );
      },

      _addViewer: function (sBlobUrl, sFilename, bDisplayFile) {
        Fragment.load({
          id: this.getView().getId(),
          name: 'disputeanalyzerui.view.fragments.FileViewer',
          controller: this
        }).then(
          function (oViewer) {
            const oModel = new JSONModel({
              imageUrl: sBlobUrl,
              filename: sFilename,
              displayFile: bDisplayFile
            });
            oViewer.setModel(oModel);
            this.oContentViewerContainer.addItem(oViewer);

            return oViewer;
          }.bind(this)
        );
      },

      onDownloadImage: function (oEvent) {
        const oImageViewer = oEvent.getSource().getParent().getParent();
        const oData = oImageViewer.getModel().getData();
        this._onDownloadFile(oData.imageUrl, oData.filename);
      },

      _onDownloadFile: function (sImageUrl, sFilename) {
        const a = document.createElement('a');
        a.href = sImageUrl;
        a.download = sFilename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      },

      _createPDFViewer: function (sBlobUrl, sFilename) {
        const oPdfViewer = new PDFViewer({
          source: sBlobUrl,
          title: sFilename,
          width: '100%',
          height: '70vh',
          isTrustedSource: true,
          showDownloadButton: true
        });
        oPdfViewer.downloadPDF = function () {
          this._onDownloadFile(sBlobUrl, sFilename);
        }.bind(this);
        oPdfViewer.attachEventOnce('destroy', () => {
          URL.revokeObjectURL(sBlobUrl);
        });
        this.oContentViewerContainer.addItem(oPdfViewer);
      },

      /**
       * Draft Handling
       */
      onEdit: function () {
        const oActiveContext = this.oObjectPage.getBindingContext();

        const oDraftAdministrativeData = oActiveContext?.getObject()?.DraftAdministrativeData;

        if (oDraftAdministrativeData && oDraftAdministrativeData.DraftIsCreatedByMe) {
          this._bindObjectPage(false);
          return;
        }

        if (oDraftAdministrativeData && !oDraftAdministrativeData.DraftIsCreatedByMe) {
          const { InProcessByUser } = oDraftAdministrativeData;

          if (InProcessByUser.length > 0) {
            MessageBox.error(this._getI18nText('documentIsLocked'));
            return;
          } else {
            const sEditText = this._getI18nText('edit');
            const sCancelText = this._getI18nText('cancel');
            MessageBox.warning(this._getI18nText('editOverwriteMessage'), {
              title: this._getI18nText('documentIsLocked'),
              actions: [sEditText, sCancelText],
              emphasizedAction: sEditText,
              contentWidth: '425px',
              onClose: function (sAction) {
                if (sAction === sEditText) {
                  this._sendOdataDraftAction('draftEdit');
                }
              }.bind(this)
            });
            return;
          }
        }

        this._sendOdataDraftAction('draftEdit');
      },

      onCancel: function () {
        const oDraftContext = this.oObjectPage.getBindingContext();

        oDraftContext.delete('$auto', true);

        this._bindObjectPage(true);
      },

      onSave: function () {
        this._sendOdataDraftAction('draftActivate');
      },

      _sendOdataDraftAction: function (sAction) {
        const oContext = this.oObjectPage.getBindingContext();

        oContext
          .getModel()
          .bindContext(`DisputeAnalyzerService.${sAction}(...)`, oContext, { $$inheritExpandSelect: true })
          .invoke('$auto', false, null, true)
          .then(
            function (oContext) {
              this.oObjectPage.setBindingContext(oContext);
            }.bind(this)
          );
      },

      /*
       * Visibility formatter functions
       */
      isProcessedDocumentActiveEntityFormatter: function (bIsActiveEntity, sProcessingStatus) {
        const { FILTER_VALUES: processedStatuses } = Constants.PROCESSED_DOCUMENTS;
        return Boolean(bIsActiveEntity && sProcessingStatus && processedStatuses.includes(sProcessingStatus));
      },

      isLockedByAnotherUserFormatter: function (oDraftAdministrativeData) {
        return Boolean(oDraftAdministrativeData && oDraftAdministrativeData.DraftIsCreatedByMe === false);
      },

      isProcessedDocumentFormatter: function (sProcessingStatus) {
        const {
          PROCESSED_DOCUMENTS: { FILTER_VALUES: processedStatuses }
        } = Constants;
        return Boolean(sProcessingStatus && processedStatuses.includes(sProcessingStatus));
      },

      isInvalidDocumentFormatter: function (sProcessingStatus) {
        const {
          INVALID_DOCUMENTS: { FILTER_VALUES: invalidStatuses }
        } = Constants;
        return Boolean(sProcessingStatus && invalidStatuses.includes(sProcessingStatus));
      },

      /*
       * Lock Mark
       */
      _getResponsivePopoverLock: function () {
        if (!this._oPopoverLock) {
          this._oPopoverLock = Fragment.load({
            id: this.getView().getId(),
            name: 'disputeanalyzerui.view.fragments.PopoverLock',
            controller: this
          }).then(
            function (oPopover) {
              this.getView().addDependent(oPopover);
              return oPopover;
            }.bind(this)
          );
        }
        return this._oPopoverLock;
      },

      handleMarkLockedPress: function (oEvent) {
        this._getResponsivePopoverLock().then(function (oPopoverLock) {
          oPopoverLock.openBy(oEvent.getParameter('domRef'));
          oPopoverLock.setModel(oEvent.getSource().getModel());
        });
      },

      /**
       * Make Correction in DOX
       */
      onMakeCorrectionInDox: async function () {
        try {
          await this._refreshData();
          if (this._isCorrectionInProgress()) return;
          this._openDoxPage();
        } catch (_) {
          // We do nothing here. Error is handled separately in the oModel message change handler
        }
      },

      _refreshData: function () {
        const oBinding = this.oObjectPage.getBindingContext();

        return new Promise((resolve, reject) => {
          const fnDataReceived = (oEvent) => {
            if (oEvent.getParameter('error')) {
              reject(oEvent);
            } else {
              resolve(oEvent);
            }
          };

          this.oModel.attachDataReceived(fnDataReceived);

          oBinding.refresh();
          this.oModel.submitBatch('$auto');
        });
      },

      _isCorrectionInProgress: function () {
        const oContext = this.oObjectPage.getBindingContext();
        const sProcessingStatus = oContext.getProperty('processingStatus');
        const sStatus = oContext.getProperty('status');
        if (sProcessingStatus === 'DOX_CORRECTION_IN_PROGRESS') {
          MessageBox.error(this._getI18nText('errorMessageDoxCorrectionInProgress'));
          return true;
        }

        if (sStatus === 'PROCESSED') {
          MessageBox.error(this._getI18nText('errorMessageDocumentProcessed'));
          return true;
        }

        return false;
      },

      _setEditMode: async function () {
        this._sendOdataDraftAction('draftEdit');
        await this.oModel.submitBatch('$auto');
      },

      _activateDraft: async function () {
        this._sendOdataDraftAction('draftActivate');
        await this.oModel.submitBatch('$auto');
      },

      _setDoxCorrectionInProgress: async function () {
        await this._setEditMode();

        const oContext = this.oObjectPage.getBindingContext();
        oContext.setProperty('processingStatus', 'DOX_CORRECTION_IN_PROGRESS');
        oContext.setProperty('isModifiedByUser', 'Yes');
        await this.oModel.submitBatch('$auto');

        await this._activateDraft();
      },

      _openDoxPage: function () {
        const oContext = this.oObjectPage.getBindingContext();
        const { doxUILink } = oContext.getObject();
        const sOpenText = this._getI18nText('open');
        const sCancelText = this._getI18nText('cancel');
        if (doxUILink) {
          MessageBox.confirm(this._getI18nText('confirmOpenDox'), {
            actions: [sOpenText, sCancelText],
            emphasizedAction: sOpenText,
            onClose: function (oAction) {
              if (oAction === sOpenText) {
                const oWindow = window.open();
                oWindow.opener = null;
                oWindow.location.href = doxUILink;
                oWindow.target = 'DOX_UI';
                this._setDoxCorrectionInProgress();
              }
            }.bind(this)
          });
        } else {
          MessageBox.error(this._getI18nText('errorMessageDoxLinkNotFound'));
        }
      },

      /**
       * Discard Document
       */
      _getDiscardDocument: function () {
        return { ID: this.sDocumentId };
      },

      /**
       * Approve Document
       */
      onApproveSelectedItemPress: function () {
        const sApproveText = this._getI18nText('approve');
        const sCancelText = this._getI18nText('cancel');
        MessageBox.confirm(this._getI18nText('confirmApproveItemForErpMessage'), {
          title: this._getI18nText('confirmApproveItemForErp'),
          actions: [sApproveText, sCancelText],
          emphasizedAction: sApproveText,
          contentWidth: '425px',
          onClose: function (sAction) {
            if (sAction === sApproveText) {
              this._sendApproveSelectedItems([this.sDocumentId], () => {
                this._bindObjectPage(true);
              });
            }
          }.bind(this)
        });
      },
            onBusinessAreaLiveChange: function (oEvent) {
        var oInput = oEvent.getSource();
        var sValue = oEvent.getParameter("value");

        // Remove any non-numeric characters
        var sCleanValue = sValue.replace(/[^0-9]/g, "");

        // Truncate to 4 digits
        if (sCleanValue.length > 4) {
          sCleanValue = sCleanValue.substring(0, 4);
        }

        // If value changed, show error and update
        if (sValue !== sCleanValue) {
          MessageBox.error(
            "Business Area must contain only numeric values (max 4 digits).",
            {
              title: "Invalid Input"
            }
          );
          oInput.setValueState("Error");
          oInput.setValueStateText("Only numeric values allowed (max 4 digits)");
        } else {
          oInput.setValueState("None");
        }

        // Always update to clean value
        if (sValue !== sCleanValue) {
          oInput.setValue(sCleanValue);
        }
      },

      onReasonCodeLiveChange: function (oEvent) {
        var oInput = oEvent.getSource();
        var sValue = oEvent.getParameter("value");

        // Remove any non-alphanumeric characters
        var sCleanValue = sValue.replace(/[^a-zA-Z0-9]/g, "");

        // Convert to uppercase
        sCleanValue = sCleanValue.toUpperCase();

        // Truncate to 3 characters
        if (sCleanValue.length > 3) {
          sCleanValue = sCleanValue.substring(0, 3);
        }

        // Only show error for invalid characters or length, not for case conversion
        var bHadInvalidChars = sValue.replace(/[^a-zA-Z0-9]/g, "") !== sValue;
        var bTooLong = sValue.length > 3;

        if (bHadInvalidChars || bTooLong) {
          MessageBox.error(
            "Reason Code must contain only alphanumeric values (max 3 characters).",
            {
              title: "Invalid Input"
            }
          );
          oInput.setValueState("Error");
          oInput.setValueStateText("Only alphanumeric values allowed (max 3 characters)");
        } else {
          oInput.setValueState("None");
        }

        // Always update to clean value
        if (sValue !== sCleanValue) {
          oInput.setValue(sCleanValue);
        }
      },

      onHenkelInvoiceLiveChange: function (oEvent) {
        var oInput = oEvent.getSource();
        var sValue = oEvent.getParameter("value");

        // Remove any non-numeric characters
        var sCleanValue = sValue.replace(/[^0-9]/g, "");

        // Truncate to 10 digits
        if (sCleanValue.length > 10) {
          sCleanValue = sCleanValue.substring(0, 10);
        }

        // If value changed, show error and update
        if (sValue !== sCleanValue) {
          MessageBox.error(
            "Henkel Invoice must contain only numeric values (max 10 digits).",
            {
              title: "Invalid Input"
            }
          );
          oInput.setValueState("Error");
          oInput.setValueStateText("Only numeric values allowed (max 10 digits)");
        } else {
          oInput.setValueState("None");
        }

        // Always update to clean value
        if (sValue !== sCleanValue) {
          oInput.setValue(sCleanValue);
        }
      }
    });
  }
);
