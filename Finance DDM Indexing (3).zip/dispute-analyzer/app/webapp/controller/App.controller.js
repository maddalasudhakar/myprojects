sap.ui.define(
  [
    'sap/ui/core/mvc/Controller',
    'sap/m/MessageBox',
    'sap/ui/core/Fragment',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageToast',
    'disputeanalyzerui/utils/Constants'
  ],
  (BaseController, MessageBox, Fragment, JSONModel, MessageToast, Constants) => {
    'use strict';

    return BaseController.extend('disputeanalyzerui.controller.App', {
      onInit() {
        this.oModel = this.getOwnerComponent().getModel();
        this.oModel.attachEvent('messageChange', this._oModelErrorHandler.bind(this));
      },

      /*
       * Discard Document
       */
      onOpenDiscardDocumentDialog: function (oEvent) {
        const oDocument = this._getDiscardDocument(oEvent);
        if (oDocument.status) {
          const bIsProcessedOrRejected = !this.isStatusNotProcessedFormatter(oDocument.status);
          if (bIsProcessedOrRejected) {
            MessageBox.error(this._getI18nText('discardDocumentAlreadyProcessedOrRejectedMessage'));
            return;
          }
        }

        if (!this._oDiscardDocumentDialog) {
          this._oDiscardDocumentDialog = Fragment.load({
            id: this.getView().getId(),
            name: 'disputeanalyzerui.view.fragments.DiscardDocumentDialog',
            controller: this
          }).then(
            function (oDialog) {
              this.getView().addDependent(oDialog);
              this._oDiscardDocumentDialog = oDialog;
              const oDialogModel = new JSONModel({
                documentId: oDocument.ID
              });
              this._oDiscardDocumentDialog.setModel(oDialogModel, 'dialogModel');
              this._oDiscardDocumentDialog.open();
              return oDialog;
            }.bind(this)
          );
        }
      },

      onDiscardDocumentCancelPress: function () {
        this._oDiscardDocumentDialog.close();
      },

      onDiscardDocumentDialogAfterClose: function (oEvent) {
        const oDialog = oEvent.getSource();
        oDialog.destroy();
        this._oDiscardDocumentDialog = null;
      },

      onReasonInputLiveChange: function (oEvent) {
        const sValue = oEvent.getParameter('value');
        const oButton = this.getView().byId('discardDocumentButton');
        oButton.setEnabled(sValue.trim().length > 0);
      },

      onDiscardDocumentPress: async function (oEvent) {
        const sReason = oEvent.getSource().getParent().getContent()[0].getItems()[2].getValue();

        const sDocumentId = this._oDiscardDocumentDialog.getModel('dialogModel').getProperty('/documentId');

        const oActionBinding = this.oModel.bindContext('/DisputeAnalyzerService.rejectDocument(...)', null);

        oActionBinding.setParameter('documentId', sDocumentId);
        oActionBinding.setParameter('reason', sReason);
        oActionBinding.execute().then(() => {
          this._oDiscardDocumentDialog.close();
          MessageToast.show(this._getI18nText('discardDocumentSuccessMessage'));
          this.getOwnerComponent().getRouter().navTo('RouteDisputeAnalyzer');
          this.oModel.refresh();
        });
      },

      /**
       * Helpers
       */
      _getI18nText: function (sKey, aArgs) {
        return this.getOwnerComponent().getModel('i18n').getResourceBundle().getText(sKey, aArgs);
      },

      /**
       * Formatters
       */
      confidenceLevelTableCellFormatter: function (sConfidenceLevel) {
        return this._getI18nText(Constants.CONFIDENCE_LEVEL_MAP[sConfidenceLevel]);
      },

      confidenceLevelStateFormatter: function (sConfidenceLevel) {
        return Constants.CONFIDENCE_LEVEL_STATE_MAP[sConfidenceLevel];
      },

      isStatusNotProcessedFormatter: function (sStatus) {
        return !(sStatus === 'PROCESSED' || sStatus === 'REJECTED');
      },

      statusTableCellFormatter: function (sStatus) {
        return this._getI18nText(Constants.STATUS_MAP[sStatus]);
      },

      /**
       * Approve Items for ERP
       */
      _sendApproveSelectedItems: function (aIds, fnRefresh, fnOnFinally, iSentCount, iTotalCount) {
        if (!aIds || aIds.length === 0) return;

        const oActionBinding = this.oModel.bindContext('/DisputeAnalyzerService.sendDocumentsToERP(...)', null);

        oActionBinding.setParameter('documentIds', aIds);
        oActionBinding
          .execute()
          .then(() => {
            let sConfirmationMessage;
            if (iSentCount && iTotalCount && iSentCount !== iTotalCount) {
              sConfirmationMessage = this._getI18nText('approveDocumentsSuccessMessageWithCount', [iSentCount, iTotalCount]);
            } else {
              sConfirmationMessage = this._getI18nText(aIds.length === 1 ? 'approveDocumentSuccessMessage' : 'approveDocumentsSuccessMessage');
            }
            MessageToast.show(sConfirmationMessage);
            fnRefresh();
          })
          .finally(() => {
            if (fnOnFinally) {
              fnOnFinally();
            }
          });
      },

      /**
       *  Error Handling
       */
      _oModelErrorHandler: function (oEvent) {
        const aNewMessages = oEvent.getParameter('newMessages');
        aNewMessages.forEach((oMessage) => {
          const sMessage = oMessage.getMessage();
          const sMessageType = oMessage.getType();
          const iCode = oMessage.getTechnicalDetails().httpStatus;

          const oDialogSetting = {
            id: 'modelMessageBoxError',
            contentWidth: '425px',
            dependentOn: this.getView()
          };

          if (sMessageType === 'Error') {
            if (iCode >= 400 && iCode < 500) {
              MessageBox.error(sMessage, oDialogSetting);
            } else if (iCode >= 500 && iCode < 600) {
              MessageBox.error(this._getI18nText('errorMessage'), {
                details: sMessage,
                ...oDialogSetting
              });
            }
          }
        });
      }
    });
  }
);
