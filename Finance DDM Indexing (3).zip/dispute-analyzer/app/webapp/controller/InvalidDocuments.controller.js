sap.ui.define(
  ['disputeanalyzerui/controller/DisputeAnalyzer.controller', 'disputeanalyzerui/utils/Constants'],
  function (DisputeAnalyzerController, Constants) {
    'use strict';

    return DisputeAnalyzerController.extend('disputeanalyzerui.controller.InvalidDocuments', {
      onInit: function () {
        DisputeAnalyzerController.prototype.onInit.apply(this, arguments);

        this.oTable = this.byId(Constants.INVALID_DOCUMENTS.TABLE_ID);

        this._bindInvalidDocumentsTable();

        this._initializeFilterBar();
      },

      _initializeFilterBar: function () {
        const oFilterBar = this.byId('invalidDocumentsFilterBar');
        const aFilterItems = oFilterBar.getFilterGroupItems('FilterGroup');
        aFilterItems.forEach((oFilterItem) => {
          const sName = oFilterItem.getName();
          if (sName !== 'companyCode' && sName !== 'status') {
            oFilterItem.setVisibleInFilterBar(false);
          }
        });
      },

      /**
       * Table binding for invalid documents
       */
      _bindInvalidDocumentsTable: function () {
        const {
          INVALID_DOCUMENTS: { TABLE_ID, FILTER_VALUES, TITLE_KEY, COUNT_KEY }
        } = Constants;

        this._bindTable({
          sTableId: TABLE_ID,
          aFilterValues: FILTER_VALUES,
          sTitleKey: TITLE_KEY,
          sCountKey: COUNT_KEY
        });
      },

      /**
       * Sort
       */
      onSortButtonPress: function () {
        this.onSort(this.oTable, Constants.INVALID_DOCUMENTS.SORT);
      }
    });
  }
);
