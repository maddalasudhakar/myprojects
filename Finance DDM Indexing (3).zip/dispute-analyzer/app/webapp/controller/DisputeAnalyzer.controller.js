sap.ui.define(
  [
    'disputeanalyzerui/controller/App.controller',
    'disputeanalyzerui/utils/Constants',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/m/SearchField',
    'sap/m/ViewSettingsDialog',
    'sap/m/ViewSettingsItem',
    'sap/ui/model/Sorter'
  ],
  (Controller, Constants, Filter, FilterOperator, SearchField, ViewSettingDialog, ViewSettingsItem, Sorter) => {
    'use strict';

    return Controller.extend('disputeanalyzerui.controller.DisputeAnalyzer', {
      onInit() {
        Controller.prototype.onInit.apply(this, arguments);
      },

      /**
       * Side navigation
       */
      onSideNavigationItemSelect: function (oEvent) {
        const oItem = oEvent.getParameter('item');
        this.byId(Constants.DISPUTE_ANALYZER.TABLE_CONTAINER_ID).to(this.getView().createId(oItem.getKey()));
      },

      onCollapseExpandPress: function () {
        const oPage = this.byId(Constants.DISPUTE_ANALYZER.PAGE_ID);
        oPage.setSideExpanded(!oPage.getSideExpanded());
      },

      /**
       * Table binding
       */
      _getProcessingStatusFilters: function (aFilterValues) {
        const aFilters = aFilterValues.map((sValue) => {
          return new Filter(Constants.API.DOCUMENTS.DEFAULT_FILTER_COLUMN, FilterOperator.EQ, sValue);
        });

        return new Filter({
          filters: aFilters,
          and: false
        });
      },

      _bindTable: function ({ sTableId, aFilterValues, sTitleKey, sCountKey }) {
        this.getView()
          .byId(sTableId)
          .bindRows({
            path: `/${Constants.API.DOCUMENTS.PATH}`,
            parameters: {
              $select: '*',
              $count: true,
              $orderby: 'mailReceivedTimestamp'
            },
            filters: [this._getProcessingStatusFilters(aFilterValues)],
            events: {
              dataReceived: function (oEvent) {
                const iCount = oEvent.getSource().getCount() || 0;
                this.getView()
                  .byId(sTitleKey)
                  .setText(this._getI18nText(sCountKey, [iCount]));
              }.bind(this)
            }
          });
      },

      /**
       * Filter Bar
       */
      onFilterBarGoPress: function (oEvent) {
        const oFilterBar = oEvent.getSource();
        const oTable = oFilterBar.getParent().getParent().getContent();

        const oFilterGroupItems = oFilterBar.getFilterGroupItems();

        const aFilterItems = oFilterGroupItems.reduce((oResult, oItem) => {
          const sPath = oItem.getName();
          const oControl = oItem.getControl();

          const oFilterConfig = Constants.FILTERS[sPath];

          // We handle the amount separately as they should be a combined filter
          if (sPath === 'amountFrom' || sPath === 'amountTo') {
            return oResult;
          }

          if (oFilterConfig) {
            const sType = oFilterConfig.type;
            const sOperator = oFilterConfig.operator;
            const sFilterPath = oFilterConfig.filterPath || sPath;

            if (sType === 'input') {
              const sValue = oControl.getValue();
              if (sValue) {
                oResult.push(
                  new Filter({
                    path: sFilterPath,
                    operator: sOperator,
                    value1: sValue,
                    caseSensitive: false
                  })
                );
              }
            } else if (sType === 'multi-combo') {
              const aSelectedKeys = oControl.getSelectedKeys();
              if (aSelectedKeys.length > 0) {
                const aFilters = aSelectedKeys.map((sKey) => {
                  return new Filter(sFilterPath, sOperator, sKey);
                });

                oResult.push(new Filter({ filters: aFilters, and: false }));
              }
            } else if (sType === 'date-range') {
              const oDateRange = oControl.getDateValue();
              const oDateRangeTo = oControl.getSecondDateValue();

              if (oDateRange && oDateRangeTo) {
                const oFilter = new Filter(
                  [
                    new Filter(sFilterPath, 'GE', new Date(oDateRange).toISOString()),
                    new Filter(sFilterPath, 'LE', new Date(oDateRangeTo).toISOString())
                  ],
                  true
                );
                oResult.push(oFilter);
              }
            } else if (sType === 'combo') {
              const sValue = oControl.getValue();
              if (sValue) {
                oResult.push(
                  new Filter({
                    path: sFilterPath,
                    operator: sOperator,
                    value1: sValue
                  })
                );
              }
            }
          }

          return oResult;
        }, []);

        // Add the amount filter
        const aAmountFilter = [];
        const oFrom = oFilterGroupItems.find((oItem) => oItem.getName() === 'amountFrom');
        const oTo = oFilterGroupItems.find((oItem) => oItem.getName() === 'amountTo');
        const sFromValue = oFrom.getControl().getValue();
        const sToValue = oTo.getControl().getValue();
        if (sFromValue) {
          aAmountFilter.push(new Filter('amount', 'GE', parseFloat(sFromValue)));
        }
        if (sToValue) {
          aAmountFilter.push(new Filter('amount', 'LE', parseFloat(sToValue)));
        }

        if (aAmountFilter.length > 0) {
          aFilterItems.push(new Filter({ filters: aAmountFilter, and: true }));
        }

        // Add the processing status filter for each page
        const FILTER_VALUES = this._getTableFilterValueById(oTable);
        const oFilter = this._getProcessingStatusFilters(FILTER_VALUES);
        aFilterItems.push(oFilter);

        const oBinding = oTable.getBinding('rows');
        const aOldFilters = oBinding.aApplicationFilters || [];

        const bSame = this._compareOldAndNewFilters(aOldFilters, aFilterItems);

        if (bSame) {
          oBinding.refresh();
        } else {
          oBinding.filter(aFilterItems);
        }
      },

      _compareOldAndNewFilters: function (aOldFilters, aNewFilters) {
        return aOldFilters.length === aNewFilters.length && aOldFilters.every((oOldFilter, i) => this._compareFilter(oOldFilter, aNewFilters[i]));
      },

      _compareValues: (v1, v2) => (v1 != null && v2 != null ? v1 === v2 : true),

      _compareFilter: function (oFilter1, oFilter2) {
        const bPath = oFilter1.sPath === oFilter2.sPath;
        const bVal1 = this._compareValues(oFilter1.oValue1, oFilter2.oValue1);
        const bVal2 = this._compareValues(oFilter1.oValue2, oFilter2.oValue2);
        if (!bPath || !bVal1 || !bVal2) return false;

        if (Array.isArray(oFilter1.aFilters) && Array.isArray(oFilter2.aFilters)) {
          if (oFilter1.aFilters.length !== oFilter2.aFilters.length) return false;
          return oFilter1.aFilters.every((oSubFilter, j) => this._compareFilter(oSubFilter, oFilter2.aFilters[j]));
        }

        return true;
      },

      _getTableFilterValueById: function (oTable) {
        return oTable.getId().indexOf(Constants.INVALID_DOCUMENTS.TABLE_ID) > -1
          ? Constants.INVALID_DOCUMENTS.FILTER_VALUES
          : Constants.PROCESSED_DOCUMENTS.FILTER_VALUES;
      },

      validateAmount: function () {
        const oFrom = this.getView().byId('amountFromInput');
        const oTo = this.getView().byId('amountToInput');
        const sFromValue = oFrom.getValue();
        const sToValue = oTo.getValue();

        const bHasBothValues = sFromValue.length >= 0 && sToValue.length > 0;
        const bIsInvalidRange = bHasBothValues && sFromValue > sToValue;

        if (bIsInvalidRange) {
          oFrom.setValueState('Error');
          oFrom.setValueStateText(this._getI18nText('amountRangeError.from'));

          oTo.setValueState('Error');
          oTo.setValueStateText(this._getI18nText('amountRangeError.to'));
        } else {
          oFrom.setValueState('None');
          oTo.setValueState('None');
        }
      },

      onCompanyCodeValueHelpRequest: function () {
        this.loadFragment({
          name: 'disputeanalyzerui.view.fragments.CompanyCodeValueHelpDialog'
        }).then(
          function (oDialog) {
            this.sCompanyCodeValueHelpDialog = oDialog;
            this.getView().addDependent(oDialog);
            const oFilterBar = this.getView().byId('companyCodeValueHelpFilterBar');

            this._oBasicSearchField = new SearchField();
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            this._oBasicSearchField.attachSearch(this.onCompanyCodeValueHelpGo.bind(this));

            oDialog.open();
          }.bind(this)
        );
      },

      onCompanyCodeValueHelpAfterClose: function () {
        this.sCompanyCodeValueHelpDialog.destroy();
        this.sCompanyCodeValueHelpDialog = null;
      },

      onCompanyCodeValueHelpCancelPress: function () {
        this.sCompanyCodeValueHelpDialog.close();
      },

      onCompanyCodeValueHelpOkPress: function () {
        const oTable = this.getView().byId('companyCodeValueHelpTable');
        const aSelectedValue = oTable.getSelectedContexts()?.[0]?.getObject()?.companyCode || '';

        const oInput = this.getView().byId('companyCodeInput');
        oInput.setValue(aSelectedValue);

        oTable.removeSelections();
        this.sCompanyCodeValueHelpDialog.close();
      },

      onCompanyCodeValueHelpGo: function () {
        const oTable = this.getView().byId('companyCodeValueHelpTable');
        const oBinding = oTable.getBinding('items');

        const oCompanyCodeInput = this.getView().byId('inputCompanyCode');
        const oCountryNameInput = this.getView().byId('inputCountryName');

        const sSearchValue = this._oBasicSearchField.getValue();
        const sCompanyCodeValue = oCompanyCodeInput.getValue();
        const sCountryNameValue = oCountryNameInput.getValue();

        const aFilters = [];

        if (sCompanyCodeValue) {
          aFilters.push(
            new Filter({
              path: 'companyCode',
              operator: FilterOperator.Contains,
              value1: sCompanyCodeValue,
              caseSensitive: false
            })
          );
        }
        if (sCountryNameValue) {
          aFilters.push(
            new Filter({
              path: 'countryName',
              operator: FilterOperator.Contains,
              value1: sCountryNameValue,
              caseSensitive: false
            })
          );
        }
        if (sSearchValue) {
          aFilters.push(
            new Filter({
              filters: [
                new Filter({
                  path: 'companyCode',
                  operator: FilterOperator.Contains,
                  value1: sSearchValue,
                  caseSensitive: false
                }),
                new Filter({
                  path: 'countryName',
                  operator: FilterOperator.Contains,
                  value1: sSearchValue,
                  caseSensitive: false
                })
              ],
              and: false
            })
          );
        }

        const oFilter = new Filter({
          filters: aFilters,
          and: true
        });
        oBinding.filter(oFilter);
      },

      onFilterBarClearPress: function (oEvent) {
        const oFilterBar = oEvent.getSource();
        const oTable = oFilterBar.getParent().getParent().getContent();

        const aFilterGroupItems = oFilterBar.getFilterGroupItems();

        aFilterGroupItems.forEach((oItem) => {
          const oControl = oItem.getControl();
          if (oControl && oControl.setValue) {
            oControl.setValue('');
          }
          if (oControl && oControl.setSelectedKey) {
            oControl.setSelectedKey('');
          }
          if (oControl && oControl.setSelectedKeys) {
            oControl.setSelectedKeys([]);
          }
        });

        oFilterBar.search();
      },
      /**
       * Table row action
       */ onNavigateToObjectPage: function (oEvent) {
        this.getOwnerComponent()
          .getRouter()
          .navTo('RouteDocumentObjectPage', {
            documentId: oEvent.getParameter('row').getBindingContext().getObject().ID
          });
      },

      /**
       * Highlight error rows
       */
      setHighlight: function (sSendingToERPError) {
        return sSendingToERPError?.length > 0 ? 'Error' : 'None';
      },

      /**
       * Discard Document
       */
      _getDiscardDocument: function (oEvent) {
        return oEvent.getSource().getParent().getParent().getBindingContext().getObject();
      },

      /**
       * Sort
       */
      onSort: function (oTable, aSortConfig) {
        const oSortDialog = new ViewSettingDialog({
          title: this._getI18nText('sortDialog.title'),
          sortItems: this._buildSortItems(aSortConfig),
          confirm: (oEvent) => this._sortConfirmHandler(oEvent, oTable)
        });
        oSortDialog.open();
      },

      _buildSortItems: function (aSortConfig) {
        return aSortConfig.map(
          (oSortItem) =>
            new ViewSettingsItem({
              text: this._getI18nText(oSortItem.text || oSortItem.key),
              key: oSortItem.key
            })
        );
      },
      _sortConfirmHandler: function (oEvent, oTable) {
        const sSortKey = oEvent.getParameter('sortItem').getKey();
        const bDescending = oEvent.getParameter('sortDescending');
        const oSorter = new Sorter(sSortKey, bDescending);
        const oBinding = oTable.getBinding('rows');
        oBinding.sort(oSorter);
      }
    });
  }
);
