sap.ui.define(
  [
    'disputeanalyzerui/controller/DisputeAnalyzer.controller',
    'disputeanalyzerui/utils/Constants',
    'disputeanalyzerui/utils/Excel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox'
  ],
  function (DisputeAnalyzerController, Constants, Excel, JSONModel, MessageBox) {
    'use strict';

    return DisputeAnalyzerController.extend('disputeanalyzerui.controller.ProcessedDocuments', {
      onInit: function () {
        DisputeAnalyzerController.prototype.onInit.apply(this, arguments);

        this._bindProcessedDocumentsTable();

        this.oTable = this.byId(Constants.PROCESSED_DOCUMENTS.TABLE_ID);

        const oViewModel = new JSONModel({
          isApproveButtonEnabled: false
        });

        this.getView().setModel(oViewModel, 'viewModel');
      },

      /**
       * Table binding for invalid documents
       */
      _bindProcessedDocumentsTable: function () {
        const {
          PROCESSED_DOCUMENTS: { TABLE_ID, FILTER_VALUES, TITLE_KEY, COUNT_KEY }
        } = Constants;

        this._bindTable({
          sTableId: TABLE_ID,
          aFilterValues: FILTER_VALUES,
          sTitleKey: TITLE_KEY,
          sCountKey: COUNT_KEY
        });
      },

      /**
       * Sort
       */
      onSortButtonPress: function () {
        this.onSort(this.oTable, Constants.PROCESSED_DOCUMENTS.SORT);
      },

      /*
       * Export
       */
      onExport: function () {
        const sFileName = this._getI18nText('exportFileName', [new Date().toISOString()]);

        Excel.export(this.oTable, sFileName);
      },

      /**
       * Approve Items for ERP
       */
      onApproveSelectedItemsPress: function () {
        const sApproveText = this._getI18nText('approve');
        const sCancelText = this._getI18nText('cancel');
        MessageBox.confirm(this._getI18nText('confirmApproveItemsForErpMessage'), {
          title: this._getI18nText('confirmApproveItemsForErp'),
          actions: [sApproveText, sCancelText],
          emphasizedAction: sApproveText,
          contentWidth: '425px',
          onClose: function (sAction) {
            if (sAction === sApproveText) {
              this._onApprove();
            } else if (sAction === sCancelText) {
              this.oTable.clearSelection();
              this.getView().getModel('viewModel').setProperty('/isApproveButtonEnabled', false);
            }
          }.bind(this)
        });
      },

      _onApprove: function () {
        const [aIds, iTotalCount, iSentCount] = this.getTableSelectedItemIds();
        this._sendApproveSelectedItems(
          aIds,
          () => this.oModel.refresh(),
          () => {
            this.oTable.clearSelection();
            this.getView().getModel('viewModel').setProperty('/isApproveButtonEnabled', false);
          },
          iSentCount,
          iTotalCount
        );
      },

      getTableSelectedItemIds: function () {
        const aSelectedIndices = this.oTable.getSelectedIndices();
        const iSelectedItemsCount = aSelectedIndices.length;
        const aFilteredSelectedIndices = aSelectedIndices
          .map((iIndex) => this.oTable.getContextByIndex(iIndex).getObject())
          .filter((oObject) => oObject.status !== 'PROCESSED' && oObject.status !== 'REJECTED')
          .map((oObject) => oObject.ID);
        const iRemainingSelectedItemsCount = aFilteredSelectedIndices.length;
        return [aFilteredSelectedIndices, iSelectedItemsCount, iRemainingSelectedItemsCount];
      },

      onRowSelectionChange: function () {
        const aSelectedIndices = this.oTable.getSelectedIndices();
        const iSelectedItemsCount = aSelectedIndices
          .map((iIndex) => this.oTable.getContextByIndex(iIndex).getObject())
          .filter((oObject) => oObject.status !== 'PROCESSED' && oObject.status !== 'REJECTED').length;

        this.getView()
          .getModel('viewModel')
          .setProperty('/isApproveButtonEnabled', iSelectedItemsCount > 0);
      }
    });
  }
);
