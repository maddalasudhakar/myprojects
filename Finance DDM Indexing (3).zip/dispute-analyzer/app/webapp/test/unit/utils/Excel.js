sap.ui.define(['disputeanalyzerui/utils/Excel'], function (Excel) {
  QUnit.module('Excel Tests', {
    before: function () {
      if (!window.Library) {
        window.Library = {
          EdmType: {
            Number: 'Number',
            Boolean: 'Boolean',
            String: 'String'
          }
        };
      }
    },
    beforeEach: function () {
      this.oExcel = Excel;
    },
    afterEach: function () {
      sinon.restore();
    }
  });

  QUnit.test('_generateColumns returns correct columns', function (assert) {
    const fakeColumn = {
      getLabel: function () {
        return {
          getText: function () {
            return 'Label1';
          }
        };
      },
      getTemplate: function () {
        return {
          getBindingInfo: function (prop) {
            if (prop === 'text') {
              return { parts: [{ path: 'Property1' }] };
            }
            return null;
          },
          getItems: function () {
            return [];
          }
        };
      }
    };
    const fakeTable = {
      getColumns: function () {
        return [fakeColumn];
      }
    };
    const fakeRowsBinding = {
      getPath: function () {
        return '/EntitySet';
      },
      getModel: function () {
        return {
          getMetaModel: function () {
            return {
              getObject: function (path) {
                if (path === '/EntitySet/Property1') {
                  return { $Type: 'Edm.Int32' };
                }
                return null;
              }
            };
          }
        };
      }
    };
    const result = this.oExcel._generateColumns(fakeTable, fakeRowsBinding);
    assert.deepEqual(result, [
      {
        label: 'Label1',
        property: 'Property1',
        type: 'Number'
      }
    ]);
  });

  QUnit.test('_determinePropertyType returns Number for numeric types', function (assert) {
    const result = this.oExcel._determinePropertyType({
      $Type: 'Edm.Int32'
    });
    assert.equal(result, Library.EdmType.Number);
  });

  QUnit.test('_determinePropertyType returns Boolean for boolean type', function (assert) {
    const result = this.oExcel._determinePropertyType({
      $Type: 'Edm.Boolean'
    });
    assert.equal(result, Library.EdmType.Boolean);
  });

  QUnit.test('_determinePropertyType returns String for date types', function (assert) {
    const result = this.oExcel._determinePropertyType({
      $Type: 'Edm.DateTime'
    });
    assert.equal(result, Library.EdmType.String);
  });

  QUnit.test('_determinePropertyType returns String when meta info is missing', function (assert) {
    const result = this.oExcel._determinePropertyType(null);
    assert.equal(result, Library.EdmType.String);
  });

  QUnit.test('_generateExportDataFromTable returns correct data', function (assert) {
    const fakeBinding = { test: 'binding' };
    const fakeTable = {
      getBinding: function (sName) {
        if (sName === 'rows') {
          return fakeBinding;
        }
      }
    };
    const generateColumnsStub = sinon.stub(this.oExcel, '_generateColumns').returns(['colA', 'colB']);
    const result = this.oExcel._generateExportDataFromTable(fakeTable);
    assert.deepEqual(result.oDataSource, fakeBinding);
    assert.deepEqual(result.aColumns, ['colA', 'colB']);
    generateColumnsStub.restore();
  });

  QUnit.test('export builds and destroys spreadsheet using instance spies', function (assert) {
    if (!window.Spreadsheet) {
      window.Spreadsheet = {
        constructor: (oSettings) => {
          this.oSettings = oSettings;
        }
      };
    }
    sinon.stub(this.oExcel, '_generateExportDataFromTable').returns({ oDataSource: true, aColumns: ['col1', 'col2'] });

    this.oExcel.export({}, 'filename');
    assert.ok(this.oExcel._generateExportDataFromTable.calledOnce);
    assert.ok(this.oExcel._generateExportDataFromTable.calledWith({}));
  });
});
