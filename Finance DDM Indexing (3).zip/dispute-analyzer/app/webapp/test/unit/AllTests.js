sap.ui.define(
  [
    'disputeanalyzerui/test/unit/controller/App.controller',
    'disputeanalyzerui/test/unit/controller/DisputeAnalyzer.controller',
    'disputeanalyzerui/test/unit/controller/DocumentObjectPage.controller',
    'disputeanalyzerui/test/unit/controller/InvalidDocuments.controller',
    'disputeanalyzerui/test/unit/controller/ProcessedDocuments.controller',
    'disputeanalyzerui/test/unit/utils/Excel'
  ],
  function () {
    'use strict';
  }
);
