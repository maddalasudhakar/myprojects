sap.ui.define(
  [
    'disputeanalyzerui/controller/ProcessedDocuments.controller',
    'disputeanalyzerui/controller/DisputeAnalyzer.controller',
    'disputeanalyzerui/utils/Constants',
    'disputeanalyzerui/utils/Excel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/thirdparty/sinon'
  ],
  function (Controller, DisputeAnalyzerController, Constants, Excel, JSONModel, MessageBox, sinon) {
    'use strict';

    QUnit.module('ProcessedDocuments Controller', {
      beforeEach: function () {
        this.oBaseOnInitStub = sinon.stub(DisputeAnalyzerController.prototype, 'onInit');

        this.oController = new Controller();

        this.oTableStub = {
          clearSelection: sinon.stub(),
          getSelectedIndices: sinon.stub(),
          getContextByIndex: sinon.stub(),
          bindRows: sinon.stub()
        };
        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub(),
          addDependent: sinon.stub()
        };
        this.oViewStub.byId.withArgs(Constants.PROCESSED_DOCUMENTS.TABLE_ID).returns(this.oTableStub);
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
      },
      afterEach: function () {
        this.oBaseOnInitStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('onInit calls base onInit, binds processed table, sets oTable and viewModel', function (assert) {
      const oBindProcessedSpy = sinon.stub(this.oController, '_bindProcessedDocumentsTable');

      this.oController.onInit();

      assert.ok(this.oBaseOnInitStub.calledOnce, 'Base DisputeAnalyzerController.onInit should be called');
      assert.ok(oBindProcessedSpy.calledOnce, '_bindProcessedDocumentsTable should be called once');
      assert.ok(this.oViewStub.setModel.calledOnce, 'setModel should be called to attach viewModel');
      const oArgs = this.oViewStub.setModel.firstCall.args;
      assert.ok(oArgs[0] instanceof JSONModel, 'setModel should receive a JSONModel instance');
      assert.deepEqual(oArgs[0].getData(), { isApproveButtonEnabled: false }, 'viewModel initial data should have isApproveButtonEnabled false');
      assert.strictEqual(oArgs[1], 'viewModel', "model name should be 'viewModel'");
      oBindProcessedSpy.restore();
    });

    QUnit.test('_bindProcessedDocumentsTable calls _bindTable with correct parameters', function (assert) {
      const oBindTableSpy = sinon.spy(this.oController, '_bindTable');

      this.oController._bindProcessedDocumentsTable();

      assert.ok(oBindTableSpy.calledOnce, '_bindTable should be called once');
      const oParams = oBindTableSpy.firstCall.args[0];
      assert.strictEqual(oParams.sTableId, Constants.PROCESSED_DOCUMENTS.TABLE_ID, 'sTableId matches Constants.PROCESSED_DOCUMENTS.TABLE_ID');
      assert.deepEqual(
        oParams.aFilterValues,
        Constants.PROCESSED_DOCUMENTS.FILTER_VALUES,
        'aFilterValues matches Constants.PROCESSED_DOCUMENTS.FILTER_VALUES'
      );
      assert.strictEqual(oParams.sTitleKey, Constants.PROCESSED_DOCUMENTS.TITLE_KEY, 'sTitleKey matches Constants.PROCESSED_DOCUMENTS.TITLE_KEY');
      assert.strictEqual(oParams.sCountKey, Constants.PROCESSED_DOCUMENTS.COUNT_KEY, 'sCountKey matches Constants.PROCESSED_DOCUMENTS.COUNT_KEY');
      oBindTableSpy.restore();
    });

    QUnit.test('onSortButtonPress calls onSort with oTable and sort settings', function (assert) {
      this.oController.oTable = this.oTableStub;
      const oSortStub = sinon.stub(this.oController, 'onSort');

      this.oController.onSortButtonPress();

      assert.ok(oSortStub.calledOnce, 'onSort should be called once');
      assert.ok(
        oSortStub.calledWith(this.oTableStub, Constants.PROCESSED_DOCUMENTS.SORT),
        'onSort should be called with oTable and Constants.PROCESSED_DOCUMENTS.SORT'
      );
    });

    QUnit.test('onExport calls Excel.export with correct params', function (assert) {
      this.oController.oTable = this.oTableStub;
      const sFakeFileName = 'report.xlsx';
      sinon.stub(this.oController, '_getI18nText').returns(sFakeFileName);
      const oExcelStub = sinon.stub(Excel, 'export');

      this.oController.onExport();

      assert.ok(oExcelStub.calledOnce, 'Excel.export should be called once');
      assert.ok(oExcelStub.calledWith(this.oTableStub, sFakeFileName), 'Excel.export should be called with oTable and localized file name');
    });

    QUnit.test('onApproveSelectedItemsPress invokes MessageBox.confirm with correct options and onClose behavior', function (assert) {
      const sApprove = 'Yes';
      const sCancel = 'No';
      const sMsg = 'Proceed?';
      const sTitle = 'Confirm';
      sinon
        .stub(this.oController, '_getI18nText')
        .withArgs('approve')
        .returns(sApprove)
        .withArgs('cancel')
        .returns(sCancel)
        .withArgs('confirmApproveItemsForErpMessage')
        .returns(sMsg)
        .withArgs('confirmApproveItemsForErp')
        .returns(sTitle);
      this.oController.oTable = this.oTableStub;
      const oViewModel = { setProperty: sinon.stub() };
      this.oViewStub.getModel.withArgs('viewModel').returns(oViewModel);

      const confirmSpy = sinon.stub(MessageBox, 'confirm');

      this.oController.onApproveSelectedItemsPress();

      assert.ok(confirmSpy.calledOnce, 'MessageBox.confirm should be called once');
      const aArgs = confirmSpy.firstCall.args;
      assert.strictEqual(aArgs[0], sMsg, 'confirm message text should match');
      const oOpts = aArgs[1];
      assert.strictEqual(oOpts.title, sTitle, 'title should be localized');
      assert.deepEqual(oOpts.actions, [sApprove, sCancel], 'actions array should match approve and cancel');
      assert.strictEqual(oOpts.emphasizedAction, sApprove, 'emphasizedAction should be approve');
      assert.strictEqual(oOpts.contentWidth, '425px', 'contentWidth should be 425px');

      const onClose = oOpts.onClose;
      const onApproveStub = sinon.stub(this.oController, '_onApprove');
      onClose(sApprove);
      assert.ok(onApproveStub.calledOnce, '_onApprove should be called when approve action chosen');

      onClose(sCancel);
      assert.ok(this.oTableStub.clearSelection.calledOnce, 'clearSelection should be called on cancel');
      assert.ok(
        oViewModel.setProperty.calledWith('/isApproveButtonEnabled', false),
        'viewModel isApproveButtonEnabled should be reset to false on cancel'
      );
      confirmSpy.restore();
    });

    QUnit.test('_onApprove calls _sendApproveSelectedItems with IDs and clearSelection callback', function (assert) {
      const aIds = ['ID1', 'ID2'];
      sinon.stub(this.oController, 'getTableSelectedItemIds').returns(aIds);
      const sendSpy = sinon.stub(this.oController, '_sendApproveSelectedItems');
      this.oController.oTable = { clearSelection: sinon.stub() };

      this.oController._onApprove();

      assert.ok(sendSpy.calledOnce, '_sendApproveSelectedItems should be called once');
    });

    QUnit.test('getTableSelectedItemIds returns array of IDs from selected indices', function (assert) {
      this.oController.oTable = this.oTableStub;
      this.oTableStub.getSelectedIndices.returns([0, 1]);
      const oContext0 = { getObject: sinon.stub().returns({ ID: 'A' }) };
      const oContext1 = { getObject: sinon.stub().returns({ ID: 'B' }) };
      this.oTableStub.getContextByIndex.withArgs(0).returns(oContext0);
      this.oTableStub.getContextByIndex.withArgs(1).returns(oContext1);

      const aResult = this.oController.getTableSelectedItemIds();

      assert.deepEqual(aResult, [['A', 'B'], 2, 2], 'Should return array of IDs matching context objects');
    });

    QUnit.test('onRowSelectionChange updates viewModel selectedItemsCount correctly', function (assert) {
      this.oController.oTable = this.oTableStub;
      this.oTableStub.getSelectedIndices.returns([0, 1]);
      const oContext0 = { getObject: sinon.stub().returns({ status: 'PROCESSED' }) };
      const oContext1 = { getObject: sinon.stub().returns({ ID: 'NEW' }) };
      this.oTableStub.getContextByIndex.withArgs(0).returns(oContext0);
      this.oTableStub.getContextByIndex.withArgs(1).returns(oContext1);
      const oViewModel = { setProperty: sinon.stub() };
      this.oViewStub.getModel.withArgs('viewModel').returns(oViewModel);

      this.oController.onRowSelectionChange();

      assert.ok(oViewModel.setProperty.calledOnce, 'viewModel.setProperty should be called once');
      assert.ok(
        oViewModel.setProperty.calledWith('/isApproveButtonEnabled', true),
        'isApproveButtonEnabled property should be updated to number of selected indices'
      );
    });
  }
);
