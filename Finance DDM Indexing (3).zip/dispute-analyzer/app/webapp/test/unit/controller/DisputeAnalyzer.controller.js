sap.ui.define(
  [
    'disputeanalyzerui/controller/DisputeAnalyzer.controller',
    'sap/ui/model/odata/v4/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/thirdparty/sinon',
    'disputeanalyzerui/utils/Constants',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator'
  ],
  function (Controller, ODataModel, JSONModel, MessageBox, sinon, Constants, Filter, FilterOperator) {
    ('use strict');

    QUnit.module('DisputeAnalyzer Controller', {
      beforeEach: function () {
        this.oController = new Controller();

        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub(),
          createId: function (sId) {
            return 'viewId--' + sId;
          },
          addDependent: sinon.stub()
        };

        this.oContainerStub = { to: sinon.stub() };
        this.oPageStub = {
          getSideExpanded: sinon.stub(),
          setSideExpanded: sinon.stub()
        };

        this.oViewStub.byId.withArgs(Constants.DISPUTE_ANALYZER.TABLE_CONTAINER_ID).returns(this.oContainerStub);
        this.oViewStub.byId.withArgs(Constants.DISPUTE_ANALYZER.PAGE_ID).returns(this.oPageStub);

        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        this.oController.byId = this.oViewStub.byId.bind(this.oViewStub);

        this.oTableStub = {
          getSelectedContexts: sinon.stub(),
          removeSelections: sinon.stub(),
          getBinding: sinon.stub()
        };
        this.oBindingStub = { filter: sinon.stub(), attachEventOnce: sinon.stub() };
        this.oTableStub.getBinding.withArgs('rows').returns(this.oBindingStub);

        const oParent2 = { getContent: sinon.stub().returns(this.oTableStub) };
        const oParent1 = { getParent: sinon.stub().returns(oParent2) };
        this.oFilterBarStub = {
          getParent: sinon.stub().returns(oParent1),
          getFilterGroupItems: sinon.stub(),
          setBasicSearch: sinon.stub()
        };

        this.oFromStub = {
          getValue: sinon.stub(),
          setValueState: sinon.stub(),
          setValueStateText: sinon.stub()
        };
        this.oToStub = {
          getValue: sinon.stub(),
          setValueState: sinon.stub(),
          setValueStateText: sinon.stub()
        };

        this.oViewStub.byId.withArgs('amountFromInput').returns(this.oFromStub);
        this.oViewStub.byId.withArgs('amountToInput').returns(this.oToStub);

        this.oDialogStub = {
          open: sinon.stub(),
          destroy: sinon.stub(),
          close: sinon.stub()
        };
        sinon.stub(this.oController, 'loadFragment').returns(Promise.resolve(this.oDialogStub));

        this.oViewStub.byId.withArgs('companyCodeValueHelpFilterBar').returns(this.oFilterBarStub);

        this.oBasicSearchStub = { attachSearch: sinon.stub(), getValue: sinon.stub() };
        this.oSearchFieldStub = sinon.stub(sap.m, 'SearchField').returns(this.oBasicSearchStub);

        this.oViewStub.byId.withArgs('companyCodeValueHelpTable').returns(this.oTableStub);
        this.oTableStub.getBinding.withArgs('items').returns(this.oBindingStub);

        this.oInputStub = { setValue: sinon.stub(), getValue: sinon.stub() };
        this.oViewStub.byId.withArgs('companyCodeInput').returns(this.oInputStub);
        this.oViewStub.byId.withArgs('inputCompanyCode').returns(this.oInputStub);
        this.oViewStub.byId.withArgs('inputCountryName').returns(this.oInputStub);

        this.oRouterStub = { navTo: sinon.stub() };
        const oComponentStub = { getRouter: () => this.oRouterStub };
        sinon.stub(this.oController, 'getOwnerComponent').returns(oComponentStub);
      },

      afterEach: function () {
        this.oSearchFieldStub.restore();
        sinon.restore();
      }
    });
    QUnit.test('onSideNavigationItemSelect navigates to selected section', function (assert) {
      const oItemStub = { getKey: sinon.stub().returns('SectionA') };
      const oEventStub = { getParameter: sinon.stub().withArgs('item').returns(oItemStub) };
      this.oController.onSideNavigationItemSelect(oEventStub);
      assert.ok(this.oContainerStub.to.calledWith('viewId--SectionA'));
    });

    QUnit.test('onCollapseExpandPress collapses when expanded', function (assert) {
      this.oPageStub.getSideExpanded.returns(true);
      this.oController.onCollapseExpandPress();
      assert.ok(this.oPageStub.setSideExpanded.calledWith(false));
    });

    QUnit.test('onCollapseExpandPress expands when collapsed', function (assert) {
      this.oPageStub.getSideExpanded.returns(false);
      this.oController.onCollapseExpandPress();
      assert.ok(this.oPageStub.setSideExpanded.calledWith(true));
    });

    QUnit.test('_getProcessingStatusFilters returns OR filter with expected sub-filters', function (assert) {
      const aValues = ['VAL1', 'VAL2', 'VAL3'];
      const oFilter = this.oController._getProcessingStatusFilters(aValues);
      assert.ok(oFilter instanceof Filter);
      const aFilters = oFilter.getFilters();
      assert.strictEqual(aFilters.length, aValues.length);
      aFilters.forEach(function (oSubFilter, i) {
        assert.strictEqual(oSubFilter.getPath(), Constants.API.DOCUMENTS.DEFAULT_FILTER_COLUMN);
        assert.strictEqual(oSubFilter.getOperator(), FilterOperator.EQ);
        assert.strictEqual(oSubFilter.getValue1(), aValues[i]);
      });
    });

    QUnit.test('onFilterBarGoPress builds amount and processing filters and applies them', function (assert) {
      const oControlFrom = { getValue: sinon.stub().returns('10') };
      const oControlTo = { getValue: sinon.stub().returns('20') };
      const oItemFrom = { getName: sinon.stub().returns('amountFrom'), getControl: sinon.stub().returns(oControlFrom) };
      const oItemTo = { getName: sinon.stub().returns('amountTo'), getControl: sinon.stub().returns(oControlTo) };
      this.oFilterBarStub.getFilterGroupItems.returns([oItemFrom, oItemTo]);

      this.oController._getTableFilterValueById = sinon.stub().returns(['X']);
      this.oController._getProcessingStatusFilters = sinon.stub().returns('PFILTER');

      const oEvent = { getSource: sinon.stub().returns(this.oFilterBarStub) };
      this.oController.onFilterBarGoPress(oEvent);

      assert.ok(this.oBindingStub.filter.calledOnce);
      const aFilters = this.oBindingStub.filter.firstCall.args[0];
      assert.strictEqual(aFilters.length, 2);
      assert.strictEqual(aFilters[1], 'PFILTER');
    });

    QUnit.test('onFilterBarGoPress applies input and processing filters, skipping amount range', function (assert) {
      const oControl = { getValue: sinon.stub().returns('foo') };
      const oItem = {
        getName: sinon.stub().returns('field1'),
        getControl: sinon.stub().returns(oControl)
      };
      const oFromItem = {
        getName: sinon.stub().returns('amountFrom'),
        getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') })
      };
      const oToItem = {
        getName: sinon.stub().returns('amountTo'),
        getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') })
      };
      this.oFilterBarStub.getFilterGroupItems.returns([oItem, oFromItem, oToItem]);

      Constants.FILTERS = {
        field1: { type: 'input', operator: FilterOperator.EQ, filterPath: 'field1' }
      };

      this.oController._getTableFilterValueById = sinon.stub().returns([]);
      this.oController._getProcessingStatusFilters = sinon.stub().returns('PFILTER');

      const oEvent = { getSource: () => this.oFilterBarStub };
      this.oController.onFilterBarGoPress(oEvent);

      assert.ok(this.oBindingStub.filter.calledOnce);
      const aFilters = this.oBindingStub.filter.firstCall.args[0];
      assert.strictEqual(aFilters.length, 2);

      const oInputFilter = aFilters[0];
      assert.strictEqual(oInputFilter.getPath(), 'field1');
      assert.strictEqual(oInputFilter.getOperator(), FilterOperator.EQ);
      assert.strictEqual(oInputFilter.getValue1(), 'foo');

      assert.strictEqual(aFilters[1], 'PFILTER');
    });

    QUnit.test('onFilterBarGoPress applies multi-combo filter and processing filters, skipping amount fields', function (assert) {
      const oControl = { getSelectedKeys: sinon.stub().returns(['A', 'B']) };
      const oItem = { getName: sinon.stub().returns('fieldMC'), getControl: sinon.stub().returns(oControl) };
      const oFromItem = { getName: sinon.stub().returns('amountFrom'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      const oToItem = { getName: sinon.stub().returns('amountTo'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      this.oFilterBarStub.getFilterGroupItems.returns([oItem, oFromItem, oToItem]);

      Constants.FILTERS = {
        fieldMC: { type: 'multi-combo', operator: FilterOperator.EQ, filterPath: 'fieldMC' }
      };

      const processingStub = {};
      sinon.stub(this.oController, '_getTableFilterValueById').returns([]);
      sinon.stub(this.oController, '_getProcessingStatusFilters').returns(processingStub);

      this.oController.onFilterBarGoPress({ getSource: () => this.oFilterBarStub });

      assert.ok(this.oBindingStub.filter.calledOnce);
      const aFilters = this.oBindingStub.filter.firstCall.args[0];
      assert.strictEqual(aFilters.length, 2);

      const oGroup = aFilters[0];
      const aSubs = oGroup.getFilters();
      assert.strictEqual(aSubs.length, 2);
      assert.strictEqual(aSubs[0].getValue1(), 'A');
      assert.strictEqual(aSubs[1].getValue1(), 'B');

      assert.strictEqual(aFilters[1], processingStub);
    });

    QUnit.test('onFilterBarGoPress applies date-range filter and processing filters, skipping amount fields', function (assert) {
      const date1 = new Date('2021-06-01'),
        date2 = new Date('2021-06-30');
      const oControl = {
        getDateValue: sinon.stub().returns(date1),
        getSecondDateValue: sinon.stub().returns(date2)
      };
      const oItem = { getName: sinon.stub().returns('fieldDR'), getControl: sinon.stub().returns(oControl) };
      const oFromItem = { getName: sinon.stub().returns('amountFrom'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      const oToItem = { getName: sinon.stub().returns('amountTo'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      this.oFilterBarStub.getFilterGroupItems.returns([oItem, oFromItem, oToItem]);

      Constants.FILTERS = {
        fieldDR: { type: 'date-range', operator: null, filterPath: 'fieldDR' }
      };

      const processingStub = {};
      sinon.stub(this.oController, '_getTableFilterValueById').returns([]);
      sinon.stub(this.oController, '_getProcessingStatusFilters').returns(processingStub);

      this.oController.onFilterBarGoPress({ getSource: () => this.oFilterBarStub });

      assert.ok(this.oBindingStub.filter.calledOnce);
      const aFilters = this.oBindingStub.filter.firstCall.args[0];
      assert.strictEqual(aFilters.length, 2);

      const oRange = aFilters[0];
      const aSubs = oRange.getFilters();
      assert.strictEqual(aSubs.length, 2);
      assert.strictEqual(aSubs[0].getOperator(), 'GE');
      assert.strictEqual(aSubs[1].getOperator(), 'LE');

      assert.strictEqual(aFilters[1], processingStub);
    });

    QUnit.test('onFilterBarGoPress applies combo filter and processing filters, skipping amount fields', function (assert) {
      const oControl = { getValue: sinon.stub().returns('Yes') };
      const oItem = { getName: sinon.stub().returns('isModifiedByUser'), getControl: sinon.stub().returns(oControl) };
      const oFromItem = { getName: sinon.stub().returns('amountFrom'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      const oToItem = { getName: sinon.stub().returns('amountTo'), getControl: sinon.stub().returns({ getValue: sinon.stub().returns('') }) };
      this.oFilterBarStub.getFilterGroupItems.returns([oItem, oFromItem, oToItem]);

      Constants.FILTERS = {
        isModifiedByUser: { type: 'combo', operator: FilterOperator.EQ, filterPath: 'isModifiedByUser' }
      };

      const processingStub = {};
      sinon.stub(this.oController, '_getTableFilterValueById').returns([]);
      sinon.stub(this.oController, '_getProcessingStatusFilters').returns(processingStub);

      this.oController.onFilterBarGoPress({ getSource: () => this.oFilterBarStub });

      assert.ok(this.oBindingStub.filter.calledOnce);
      const aFilters = this.oBindingStub.filter.firstCall.args[0];
      assert.strictEqual(aFilters.length, 2);

      const oComboFilter = aFilters[0];
      assert.strictEqual(oComboFilter.getPath(), 'isModifiedByUser');
      assert.strictEqual(oComboFilter.getOperator(), FilterOperator.EQ);
      assert.strictEqual(oComboFilter.getValue1(), 'Yes');

      assert.strictEqual(aFilters[1], processingStub);
    });

    QUnit.test('_getTableFilterValueById returns invalid filter values when table id matches INVALID_DOCUMENTS', function (assert) {
      const oTableStub = { getId: () => 'some-' + Constants.INVALID_DOCUMENTS.TABLE_ID + '-table' };
      const result = this.oController._getTableFilterValueById(oTableStub);
      assert.deepEqual(result, Constants.INVALID_DOCUMENTS.FILTER_VALUES);
    });

    QUnit.test('_getTableFilterValueById returns processed filter values when table id does not match INVALID_DOCUMENTS', function (assert) {
      const oTableStub = { getId: () => 'some-other-table' };
      const result = this.oController._getTableFilterValueById(oTableStub);
      assert.deepEqual(result, Constants.PROCESSED_DOCUMENTS.FILTER_VALUES);
    });

    QUnit.test('validateAmount sets no error when from ≤ to', function (assert) {
      this.oFromStub.getValue.returns('10');
      this.oToStub.getValue.returns('20');
      this.oController.validateAmount();
      assert.ok(this.oFromStub.setValueState.calledWith('None'));
      assert.ok(this.oToStub.setValueState.calledWith('None'));
      assert.notOk(this.oFromStub.setValueStateText.called);
      assert.notOk(this.oToStub.setValueStateText.called);
    });

    QUnit.test('validateAmount sets error state and texts when from > to', function (assert) {
      this.oFromStub.getValue.returns('30');
      this.oToStub.getValue.returns('20');
      sinon
        .stub(this.oController, '_getI18nText')
        .withArgs('amountRangeError.from')
        .returns('From error')
        .withArgs('amountRangeError.to')
        .returns('To error');
      this.oController.validateAmount();
      assert.ok(this.oFromStub.setValueState.calledWith('Error'));
      assert.ok(this.oFromStub.setValueStateText.calledWith('From error'));
      assert.ok(this.oToStub.setValueState.calledWith('Error'));
      assert.ok(this.oToStub.setValueStateText.calledWith('To error'));
    });

    QUnit.test('onCompanyCodeValueHelpRequest loads fragment, adds dependent, sets up search, and opens dialog', function (assert) {
      const done = assert.async();
      this.oController.onCompanyCodeValueHelpRequest();
      assert.ok(this.oController.loadFragment.calledWith({ name: 'disputeanalyzerui.view.fragments.CompanyCodeValueHelpDialog' }));
      this.oController.loadFragment().then((oDialog) => {
        assert.strictEqual(this.oController.sCompanyCodeValueHelpDialog, oDialog);
        assert.ok(this.oViewStub.addDependent.calledWith(oDialog));
        assert.ok(oDialog.open.calledOnce);
        done();
      });
    });

    QUnit.test('onCompanyCodeValueHelpAfterClose destroys dialog and nullifies reference', function (assert) {
      this.oController.sCompanyCodeValueHelpDialog = this.oDialogStub;
      this.oController.onCompanyCodeValueHelpAfterClose();
      assert.ok(this.oDialogStub.destroy.calledOnce);
      assert.strictEqual(this.oController.sCompanyCodeValueHelpDialog, null);
    });

    QUnit.test('onCompanyCodeValueHelpCancelPress closes the dialog', function (assert) {
      this.oController.sCompanyCodeValueHelpDialog = this.oDialogStub;
      this.oController.onCompanyCodeValueHelpCancelPress();
      assert.ok(this.oDialogStub.close.calledOnce);
    });

    QUnit.test('onCompanyCodeValueHelpOkPress sets input value, clears selections, and closes dialog', function (assert) {
      const oContext = { getObject: sinon.stub().returns({ companyCode: 'C123' }) };
      this.oTableStub.getSelectedContexts.returns([oContext]);
      this.oController.sCompanyCodeValueHelpDialog = this.oDialogStub;
      this.oController.onCompanyCodeValueHelpOkPress();
      assert.ok(this.oInputStub.setValue.calledWith('C123'));
      assert.ok(this.oTableStub.removeSelections.calledOnce);
      assert.ok(this.oDialogStub.close.calledOnce);
    });

    QUnit.test('onCompanyCodeValueHelpGo builds filters and applies them to table binding', function (assert) {
      this.oController._oBasicSearchField = { getValue: sinon.stub().returns('searchVal') };

      const oCompanyInput = { getValue: sinon.stub().returns('compVal') };
      const oCountryInput = { getValue: sinon.stub().returns('') };
      this.oViewStub.byId.withArgs('inputCompanyCode').returns(oCompanyInput);
      this.oViewStub.byId.withArgs('inputCountryName').returns(oCountryInput);

      this.oController.onCompanyCodeValueHelpGo();

      assert.ok(this.oBindingStub.filter.calledOnce);
      const oFilter = this.oBindingStub.filter.firstCall.args[0];
      assert.ok(oFilter instanceof Filter);
    });

    QUnit.test('onFilterBarClearPress resets all filter control values', function (assert) {
      const oControl1 = { setValue: sinon.stub(), setSelectedKey: sinon.stub(), setSelectedKeys: sinon.stub() };
      const oControl2 = { setValue: sinon.stub() };
      const oItem1 = { getControl: sinon.stub().returns(oControl1) };
      const oItem2 = { getControl: sinon.stub().returns(oControl2) };
      const oParent2 = { getContent: sinon.stub().returns(this.oTableStub) };
      const oParent1 = { getParent: sinon.stub().returns(oParent2) };
      const oFilterBar = {
        getFilterGroupItems: sinon.stub().returns([oItem1, oItem2]),
        getParent: sinon.stub().returns(oParent1),
        search: sinon.stub()
      };
      const oEvent = { getSource: sinon.stub().returns(oFilterBar) };

      this.oController.onFilterBarClearPress(oEvent);
      assert.ok(oControl1.setValue.calledWith(''));
      assert.ok(oControl1.setSelectedKey.calledWith(''));
      assert.ok(oControl1.setSelectedKeys.calledWith([]));
      assert.ok(oControl2.setValue.calledWith(''));
    });

    QUnit.test('onNavigateToObjectPage navigates to object page with correct ID', function (assert) {
      const oContextStub = { getObject: () => ({ ID: 'DOC123' }) };
      const oRowStub = { getBindingContext: sinon.stub().returns(oContextStub) };
      const oEventStub = { getParameter: sinon.stub().withArgs('row').returns(oRowStub) };

      this.oController.onNavigateToObjectPage(oEventStub);

      assert.ok(this.oRouterStub.navTo.calledWith('RouteDocumentObjectPage', { documentId: 'DOC123' }));
    });

    QUnit.test("setHighlight returns 'Error' when error string is non-empty", function (assert) {
      assert.strictEqual(this.oController.setHighlight('err'), 'Error');
      assert.strictEqual(this.oController.setHighlight(''), 'None');
      assert.strictEqual(this.oController.setHighlight(null), 'None');
    });

    QUnit.test('statusTableCellFormatter returns localized status text', function (assert) {
      const sKey = Constants.STATUS_MAP['OPEN'];
      sinon.stub(this.oController, '_getI18nText').withArgs(sKey).returns('Open Status');
      const result = this.oController.statusTableCellFormatter('OPEN');
      assert.strictEqual(result, 'Open Status');
    });

    QUnit.test('_getDiscardDocument extracts ID from event', function (assert) {
      const oObject = { ID: 'D456' };
      const oBindingContextStub = { getObject: sinon.stub().returns(oObject) };
      const oParent2 = { getBindingContext: sinon.stub().returns(oBindingContextStub) };
      const oParent1 = { getParent: sinon.stub().returns(oParent2) };
      const oSourceStub = { getParent: sinon.stub().returns(oParent1) };
      const oEventStub = { getSource: () => oSourceStub };
      const document = this.oController._getDiscardDocument(oEventStub);
      assert.strictEqual(document, oObject);
    });

    QUnit.test('onSort opens a ViewSettingsDialog', function (assert) {
      const VSD = sap.ui.requireSync('sap/m/ViewSettingsDialog');
      sinon.stub(VSD.prototype, 'open');
      sinon.stub(this.oController, '_getI18nText').withArgs('sortDialog.title').returns('Sort Title');
      const VSI = sap.ui.requireSync('sap/m/ViewSettingsItem');
      sinon
        .stub(this.oController, '_buildSortItems')
        .withArgs(['cfg'])
        .returns([new VSI({ text: 'Label', key: 'Key' })]);

      this.oController.onSort({}, ['cfg']);

      assert.ok(VSD.prototype.open.calledOnce);

      VSD.prototype.open.restore();
    });

    QUnit.test('_buildSortItems returns ViewSettingsItems with localized text and key', function (assert) {
      sinon.stub(this.oController, '_getI18nText').withArgs('Text1').returns('Label1').withArgs('Key2').returns('Label2');

      const items = this.oController._buildSortItems([{ text: 'Text1', key: 'Key1' }, { key: 'Key2' }]);

      assert.strictEqual(items.length, 2);
      assert.ok(items[0] instanceof sap.m.ViewSettingsItem);
      assert.strictEqual(items[0].getKey(), 'Key1');
      assert.strictEqual(items[0].getText(), 'Label1');
      assert.ok(items[1] instanceof sap.m.ViewSettingsItem);
      assert.strictEqual(items[1].getKey(), 'Key2');
      assert.strictEqual(items[1].getText(), 'Label2');
    });

    QUnit.test('_sortConfirmHandler applies a Sorter to the table binding', function (assert) {
      const Sorter = sap.ui.requireSync('sap/ui/model/Sorter');
      const bindingStub = { sort: sinon.stub() };
      const tableStub = { getBinding: sinon.stub().withArgs('rows').returns(bindingStub) };
      const sortItemStub = { getKey: () => 'col1' };
      const eventStub = {
        getParameter: (param) => (param === 'sortItem' ? sortItemStub : param === 'sortDescending' ? true : undefined)
      };

      this.oController._sortConfirmHandler(eventStub, tableStub);

      assert.ok(bindingStub.sort.calledOnce);
      const sorter = bindingStub.sort.firstCall.args[0];
      assert.ok(sorter instanceof Sorter);
      assert.strictEqual(sorter.sPath, 'col1');
      assert.strictEqual(sorter.bDescending, true);
    });
  }
);
