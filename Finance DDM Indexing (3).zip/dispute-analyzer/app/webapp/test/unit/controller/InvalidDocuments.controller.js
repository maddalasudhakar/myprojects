sap.ui.define(
  [
    'disputeanalyzerui/controller/InvalidDocuments.controller',
    'disputeanalyzerui/controller/DisputeAnalyzer.controller',
    'disputeanalyzerui/utils/Constants',
    'sap/ui/model/odata/v4/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/thirdparty/sinon'
  ],
  function (Controller, DisputeAnalyzerController, Constants, ODataModel, JSONModel, MessageBox, sinon) {
    'use strict';

    QUnit.module('InvalidDocuments Controller', {
      beforeEach: function () {
        this.oBaseOnInitStub = sinon.stub(DisputeAnalyzerController.prototype, 'onInit');

        this.oController = new Controller();

        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub().returns({
            bindRows: sinon.stub()
          }),
          addDependent: sinon.stub()
        };
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        sinon.stub(this.oController, 'byId').returns({
          getFilterGroupItems: sinon.stub().returns([])
        });
      },
      afterEach: function () {
        this.oBaseOnInitStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('onInit calls base onInit, sets oTable and binds invalid documents table', function (assert) {
      const oTableStub = {};
      this.oViewStub.byId.withArgs(Constants.INVALID_DOCUMENTS.TABLE_ID).returns(oTableStub);
      const oBindSpy = sinon.stub(this.oController, '_bindInvalidDocumentsTable');
      this.oController.onInit();

      assert.ok(this.oBaseOnInitStub.calledOnce, 'Base DisputeAnalyzerController.onInit must be called');
      assert.ok(oBindSpy.calledOnce, '_bindInvalidDocumentsTable is invoked once');
      oBindSpy.restore();
    });

    QUnit.test('_bindInvalidDocumentsTable calls _bindTable with correct parameters', function (assert) {
      const oBindTableSpy = sinon.spy(this.oController, '_bindTable');
      this.oController._bindInvalidDocumentsTable();
      assert.ok(oBindTableSpy.calledOnce, '_bindTable should be called once');

      const oArgs = oBindTableSpy.firstCall.args[0];
      assert.strictEqual(oArgs.sTableId, Constants.INVALID_DOCUMENTS.TABLE_ID, 'sTableId is set from Constants.INVALID_DOCUMENTS.TABLE_ID');
      assert.deepEqual(
        oArgs.aFilterValues,
        Constants.INVALID_DOCUMENTS.FILTER_VALUES,
        'aFilterValues is set from Constants.INVALID_DOCUMENTS.FILTER_VALUES'
      );
      assert.strictEqual(oArgs.sTitleKey, Constants.INVALID_DOCUMENTS.TITLE_KEY, 'sTitleKey is set from Constants.INVALID_DOCUMENTS.TITLE_KEY');
      assert.strictEqual(oArgs.sCountKey, Constants.INVALID_DOCUMENTS.COUNT_KEY, 'sCountKey is set from Constants.INVALID_DOCUMENTS.COUNT_KEY');
      oBindTableSpy.restore();
    });

    QUnit.test('onSortButtonPress calls onSort with the table and sort settings', function (assert) {
      const oFakeTable = {};
      this.oController.oTable = oFakeTable;
      const oSortStub = sinon.stub(this.oController, 'onSort');

      this.oController.onSortButtonPress();

      assert.ok(oSortStub.calledOnce, 'onSort should be called once');
      assert.ok(
        oSortStub.calledWith(oFakeTable, Constants.INVALID_DOCUMENTS.SORT),
        'onSort should be called with the table and Constants.INVALID_DOCUMENTS.SORT'
      );
    });
  }
);
