sap.ui.define(
  [
    'disputeanalyzerui/controller/App.controller',
    'sap/ui/model/json/JSONModel',
    'sap/ui/core/Fragment',
    'sap/m/MessageToast',
    'sap/ui/thirdparty/sinon',
    'disputeanalyzerui/utils/Constants',
    'sap/m/MessageBox'
  ],
  function (Controller, JSONModel, Fragment, MessageToast, sinon, Constants, MessageBox) {
    'use strict';

    QUnit.module('App Controller', {
      beforeEach: function () {
        this.oController = new Controller();
        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub(),
          addDependent: sinon.stub(),
          getId: sinon.stub().returns('viewId')
        };
        this.oGetViewStub = sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        this.oBundleStub = { getText: sinon.stub() };
        this.oRouterStub = { navTo: sinon.stub() };
        this.oModelStub = {
          bindContext: sinon.stub(),
          refresh: sinon.stub(),
          attachEvent: sinon.stub(),
          getResourceBundle: sinon.stub().returns(this.oBundleStub)
        };
        this.oGetOwnerComponentStub = sinon.stub(this.oController, 'getOwnerComponent').returns({
          getRouter: () => this.oRouterStub,
          getModel: sinon.stub().returns(this.oModelStub)
        });
        this.oController.oModel = this.oModelStub;
        this.oDiscardButtonStub = { setEnabled: sinon.stub() };
        this.oViewStub.byId.withArgs('discardDocumentButton').returns(this.oDiscardButtonStub);
        this.oMessageBoxStub = sinon.stub(MessageBox, 'error');
      },
      afterEach: function () {
        this.oGetViewStub.restore();
        this.oGetOwnerComponentStub.restore();
        this.oMessageBoxStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('onInit sets oModel and attaches messageChange handler', function (assert) {
      this.oController.onInit();
      assert.strictEqual(this.oController.oModel, this.oModelStub);
      assert.ok(this.oModelStub.attachEvent.calledOnce);
      assert.strictEqual(this.oModelStub.attachEvent.firstCall.args[0], 'messageChange');
      assert.strictEqual(typeof this.oModelStub.attachEvent.firstCall.args[1], 'function');
    });

    QUnit.test('onDiscardDocumentCancelPress closes the discard-dialog', function (assert) {
      const oDialogStub = { close: sinon.stub() };
      this.oController._oDiscardDocumentDialog = oDialogStub;
      this.oController.onDiscardDocumentCancelPress();
      assert.ok(oDialogStub.close.calledOnce);
    });

    QUnit.test('onDiscardDocumentDialogAfterClose destroys dialog and resets reference', function (assert) {
      const oDialogStub = { destroy: sinon.stub() };
      this.oController._oDiscardDocumentDialog = oDialogStub;
      this.oController.onDiscardDocumentDialogAfterClose({ getSource: () => oDialogStub });
      assert.ok(oDialogStub.destroy.calledOnce);
      assert.strictEqual(this.oController._oDiscardDocumentDialog, null);
    });

    QUnit.test('onReasonInputLiveChange toggles the discard button enablement', function (assert) {
      this.oController.onReasonInputLiveChange({ getParameter: (p) => (p === 'value' ? 'foo' : undefined) });
      assert.ok(this.oDiscardButtonStub.setEnabled.calledWith(true));

      this.oController.onReasonInputLiveChange({ getParameter: (p) => (p === 'value' ? '   ' : undefined) });
      assert.ok(this.oDiscardButtonStub.setEnabled.calledWith(false));
    });

    QUnit.test('onOpenDiscardDocumentDialog loads fragment once, sets model, adds dependent, opens dialog', function (assert) {
      const done = assert.async();
      delete this.oController._oDiscardDocumentDialog;
      this.oController._getDiscardDocument = () => ({
        ID: 'DOC42',
        status: 'NEW'
      });

      const oDialogStub = { setModel: sinon.stub(), open: sinon.stub() };
      const oFragmentStub = sinon.stub(Fragment, 'load').returns(Promise.resolve(oDialogStub));

      this.oController.onOpenDiscardDocumentDialog({});
      assert.ok(Fragment.load.calledOnce);

      this.oController._oDiscardDocumentDialog.then((oDialog) => {
        assert.ok(this.oViewStub.addDependent.calledWith(oDialog));

        const [oModel, sAlias] = oDialog.setModel.firstCall.args;
        assert.ok(oModel instanceof JSONModel);
        assert.strictEqual(oModel.getData().documentId, 'DOC42');
        assert.strictEqual(sAlias, 'dialogModel');

        assert.ok(oDialog.open.calledOnce);

        this.oController.onOpenDiscardDocumentDialog({});
        oFragmentStub.restore();

        done();
      });
    });

    QUnit.test('onDiscardDocumentPress triggers reject action and subsequent UI updates', function (assert) {
      const done = assert.async();
      sinon.stub(MessageToast, 'show');

      const oValueStub = { getValue: sinon.stub().returns('User reason') };
      const oContentStub = { getItems: sinon.stub().returns([null, null, oValueStub]) };
      const oParentStub = { getContent: sinon.stub().returns([oContentStub]) };
      const oSourceStub = { getParent: sinon.stub().returns(oParentStub) };
      const oEventStub = { getSource: () => oSourceStub };

      const oDialogModelStub = { getProperty: sinon.stub().withArgs('/documentId').returns('DOC789') };
      this.oController._oDiscardDocumentDialog = {
        getModel: sinon.stub().withArgs('dialogModel').returns(oDialogModelStub),
        close: sinon.stub()
      };

      const oActionBindingStub = {
        setParameter: sinon.stub(),
        execute: sinon.stub().returns(Promise.resolve())
      };
      this.oModelStub.bindContext.returns(oActionBindingStub);

      this.oController._getI18nText = () => 'Success message';

      this.oController.onDiscardDocumentPress(oEventStub);

      assert.ok(this.oModelStub.bindContext.calledWith('/DisputeAnalyzerService.rejectDocument(...)', null));

      oActionBindingStub.execute().then(() => {
        assert.ok(this.oController._oDiscardDocumentDialog.close.calledOnce);
        assert.ok(MessageToast.show.calledWith('Success message'));
        assert.ok(this.oRouterStub.navTo.calledWith('RouteDisputeAnalyzer'));
        assert.ok(this.oModelStub.refresh.calledOnce);
        done();
      });
    });

    QUnit.test('_getI18nText returns localized text', function (assert) {
      this.oBundleStub.getText.withArgs('MY_KEY', ['arg']).returns('Translated');
      const result = this.oController._getI18nText('MY_KEY', ['arg']);
      assert.strictEqual(result, 'Translated');
    });

    QUnit.test('confidenceLevelTableCellFormatter returns i18n label', function (assert) {
      const sKey = Constants.CONFIDENCE_LEVEL_MAP['MEDIUM'];
      sinon.stub(this.oController, '_getI18nText').withArgs(sKey).returns('Medium Confidence');
      const result = this.oController.confidenceLevelTableCellFormatter('MEDIUM');
      assert.strictEqual(result, 'Medium Confidence');
    });

    QUnit.test('confidenceLevelStateFormatter returns UI5 state', function (assert) {
      const result = this.oController.confidenceLevelStateFormatter('LOW');
      assert.strictEqual(result, Constants.CONFIDENCE_LEVEL_STATE_MAP['LOW']);
    });

    QUnit.test('_sendApproveSelectedItems with null array does nothing', function (assert) {
      this.oController._sendApproveSelectedItems(null);
      assert.notOk(this.oModelStub.bindContext.called);
    }),
      QUnit.test('_sendApproveSelectedItems with empty array does nothing', function (assert) {
        this.oController._sendApproveSelectedItems([]);
        assert.notOk(this.oModelStub.bindContext.called);
      }),
      QUnit.test('_sendApproveSelectedItems single id', function (assert) {
        const done = assert.async();
        const oActionBinding = { setParameter: sinon.stub(), execute: sinon.stub().returns(Promise.resolve()) };
        this.oModelStub.bindContext.returns(oActionBinding);
        sinon.stub(this.oController, '_getI18nText').withArgs('approveDocumentSuccessMessage').returns('Approved one');
        const fnFinally = sinon.spy();
        const fnRefresh = sinon.spy();
        this.oController._sendApproveSelectedItems(['ID1'], fnRefresh, fnFinally);
        assert.ok(this.oModelStub.bindContext.calledWith('/DisputeAnalyzerService.sendDocumentsToERP(...)', null));
        assert.ok(oActionBinding.setParameter.calledWith('documentIds', ['ID1']));
        oActionBinding
          .execute()
          .then(() => {
            assert.ok(MessageToast.show.calledWith('Approved one'));
            assert.ok(fnRefresh.calledOnce);
          })
          .finally(() => {
            assert.ok(fnFinally.calledOnce);
            done();
          });
      }),
      QUnit.test('_sendApproveSelectedItems multiple ids', function (assert) {
        const done = assert.async();
        const oActionBinding = { setParameter: sinon.stub(), execute: sinon.stub().returns(Promise.resolve()) };
        this.oModelStub.bindContext.returns(oActionBinding);
        sinon.stub(this.oController, '_getI18nText').withArgs('approveDocumentsSuccessMessage').returns('Approved many');
        const fnFinally = sinon.spy();
        const fnRefresh = sinon.spy();
        this.oController._sendApproveSelectedItems(['ID1', 'ID2'], fnRefresh, fnFinally);
        assert.ok(oActionBinding.setParameter.calledWith('documentIds', ['ID1', 'ID2']));
        oActionBinding
          .execute()
          .then(() => {
            assert.ok(MessageToast.show.calledWith('Approved many'));
            assert.ok(fnRefresh.calledOnce);
          })
          .finally(() => {
            assert.ok(fnFinally.calledOnce);
            done();
          });
      });

    QUnit.test('_oModelErrorHandler skips non-error messages', function (assert) {
      const oMsg = {
        getType: sinon.stub().returns('Warning'),
        getMessage: sinon.stub().returns('Warn'),
        getTechnicalDetails: sinon.stub().returns({ httpStatus: 400 })
      };
      const oEvent = { getParameter: (p) => (p === 'newMessages' ? [oMsg] : undefined) };
      this.oController._oModelErrorHandler(oEvent);
      assert.notOk(MessageBox.error.called);
    });

    QUnit.test('_oModelErrorHandler shows original message for 4xx errors', function (assert) {
      const oMsg = {
        getType: sinon.stub().returns('Error'),
        getMessage: sinon.stub().returns('Client error'),
        getTechnicalDetails: sinon.stub().returns({ httpStatus: 404 })
      };
      const oEvent = { getParameter: (p) => (p === 'newMessages' ? [oMsg] : undefined) };
      this.oController._oModelErrorHandler(oEvent);
      assert.ok(MessageBox.error.calledWith('Client error', { id: 'modelMessageBoxError', contentWidth: '425px', dependentOn: this.oViewStub }));
    });

    QUnit.test('_oModelErrorHandler shows localized message with details for 5xx errors', function (assert) {
      const oMsg = {
        getType: sinon.stub().returns('Error'),
        getMessage: sinon.stub().returns('Server fail'),
        getTechnicalDetails: sinon.stub().returns({ httpStatus: 500 })
      };
      this.oController._getI18nText = sinon.stub().withArgs('errorMessage').returns('Localized error');
      const oEvent = { getParameter: (p) => (p === 'newMessages' ? [oMsg] : undefined) };
      this.oController._oModelErrorHandler(oEvent);
      assert.ok(
        MessageBox.error.calledWith('Localized error', {
          details: 'Server fail',
          id: 'modelMessageBoxError',
          contentWidth: '425px',
          dependentOn: this.oViewStub
        })
      );
    });
  }
);
