sap.ui.define(
  [
    'disputeanalyzerui/controller/DocumentObjectPage.controller',
    'sap/ui/model/odata/v4/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/thirdparty/sinon',
    'sap/ui/core/UIComponent',
    'disputeanalyzerui/utils/Constants',
    'sap/ui/core/Fragment'
  ],
  function (Controller, ODataModel, JSONModel, MessageBox, sinon, UIComponent, Constants, Fragment) {
    ('use strict');

    QUnit.module('DocumentObjectPage Controller', {
      beforeEach: function () {
        this.oController = new Controller();

        this.oViewStub = { byId: sinon.stub(), getId: sinon.stub() };
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        this.oController.byId = this.oViewStub.byId;

        this.oRouteStub = { attachPatternMatched: sinon.stub() };
        this.oRouterStub = {
          getRoute: sinon.stub().withArgs('RouteDocumentObjectPage').returns(this.oRouteStub)
        };
        sinon.stub(UIComponent, 'getRouterFor').withArgs(this.oController).returns(this.oRouterStub);

        sinon.stub(this.oController, 'getOwnerComponent').returns({
          getModel: sinon.stub().withArgs('i18n').returns({
            attachEvent: sinon.stub()
          })
        });

        sinon.stub(this.oController, '_bindObjectPage');

        this.oModelStub = { bindList: sinon.stub() };
        this.oController.oModel = this.oModelStub;
        this.oController.sDocumentId = 'DOC1';

        this.oObjectPageStub = { setBindingContext: sinon.stub(), getBindingContext: sinon.stub() };
        this.oViewStub.byId.withArgs('documentObjectPage').returns(this.oObjectPageStub);
        this.oController.oObjectPage = this.oObjectPageStub;

        this.oErpStatusStub = { setVisible: sinon.stub() };
        this.oViewStub.byId.withArgs('erpErrorStatus').returns(this.oErpStatusStub);

        this.oFetchStub = sinon.stub(window, 'fetch');
        this.oUrlStub = sinon.stub(window.URL, 'createObjectURL').returns('blob:url');

        this.oContentViewerContainerStub = { destroyItems: sinon.stub(), addItem: sinon.stub() };
        this.oViewStub.byId.withArgs('pdfViewerContainer').returns(this.oContentViewerContainerStub);
        this.oController.oContentViewerContainer = this.oContentViewerContainerStub;
      },

      afterEach: function () {
        UIComponent.getRouterFor.restore();
        this.oFetchStub.restore();
        this.oUrlStub.restore();
        sinon.restore();
      }
    });
    QUnit.test('onInit sets oObjectPage, oRouter, and attaches patternMatched handler', function (assert) {
      this.oController.onInit();
      assert.strictEqual(this.oController.oObjectPage, this.oObjectPageStub);
      assert.strictEqual(this.oController.oRouter, this.oRouterStub);
      assert.ok(this.oRouteStub.attachPatternMatched.calledOnce);
      const [fn, ctx] = this.oRouteStub.attachPatternMatched.firstCall.args;
      assert.strictEqual(typeof fn, 'function');
      assert.strictEqual(ctx, this.oController);
    });

    QUnit.test('_onPatternMatched sets sDocumentId and calls _bindObjectPage(true)', function (assert) {
      const oEvent = { getParameter: sinon.stub().withArgs('arguments').returns({ documentId: 'D789' }) };
      this.oController._onPatternMatched(oEvent);
      assert.strictEqual(this.oController.sDocumentId, 'D789');
      assert.ok(this.oController._bindObjectPage.calledWith(true));
    });
    QUnit.test('_createPDFViewer creates PDFViewer with correct settings and hooks', function (assert) {
      const sUrl = 'blob:url';
      const sFilename = 'doc.pdf';

      function FakePDFViewer(settings) {
        this.settings = settings;
        this.attachEventOnce = sinon.stub();
      }
      sap.m.PDFViewer = FakePDFViewer;

      this.oController._createPDFViewer(sUrl, sFilename);

      assert.ok(this.oContentViewerContainerStub.addItem.calledOnce);
    });

    QUnit.test('onEdit calls _bindObjectPage(false) when draft created by me', function (assert) {
      this.oObjectPageStub.getBindingContext.returns({
        getObject: () => ({ DraftAdministrativeData: { DraftIsCreatedByMe: true } })
      });
      this.oController.onEdit();
      assert.ok(this.oController._bindObjectPage.calledWith(false));
    });

    QUnit.test('onEdit does nothing when draft exists but not by me', function (assert) {
      sinon.stub(this.oController, '_sendOdataDraftAction');
      sinon.stub(this.oController, '_getI18nText');
      this.oObjectPageStub.getBindingContext.returns({
        getObject: () => ({ DraftAdministrativeData: { DraftIsCreatedByMe: false, InProcessByUser: '' } })
      });
      this.oController.onEdit();
      assert.notOk(this.oController._bindObjectPage.called);
      assert.notOk(this.oController._sendOdataDraftAction.called);
    });

    QUnit.test('onEdit does nothing when draft exists but not by me', function (assert) {
      this.oMessageBoxStub = sinon.stub(MessageBox, 'error');

      sinon.stub(this.oController, '_sendOdataDraftAction');
      sinon.stub(this.oController, '_getI18nText').returns('Draft not created by me');
      this.oObjectPageStub.getBindingContext.returns({
        getObject: () => ({ DraftAdministrativeData: { DraftIsCreatedByMe: false, InProcessByUser: 'User' } })
      });
      this.oController.onEdit();
      assert.notOk(this.oController._bindObjectPage.called);
      assert.notOk(this.oController._sendOdataDraftAction.called);
      assert.ok(this.oMessageBoxStub.calledWith('Draft not created by me'));
      this.oMessageBoxStub.restore();
    });

    QUnit.test("onEdit calls _sendOdataDraftAction('draftEdit') when no draft", function (assert) {
      sinon.stub(this.oController, '_sendOdataDraftAction');
      this.oObjectPageStub.getBindingContext.returns({
        getObject: () => ({})
      });
      this.oController.onEdit();
      assert.ok(this.oController._sendOdataDraftAction.calledWith('draftEdit'));
    });

    QUnit.test('onCancel deletes draft and calls _bindObjectPage(true)', function (assert) {
      const ctx = { delete: sinon.stub() };
      this.oObjectPageStub.getBindingContext.returns(ctx);
      this.oController.onCancel();
      assert.ok(ctx.delete.calledWith('$auto', true));
      assert.ok(this.oController._bindObjectPage.calledWith(true));
    });

    QUnit.test("onSave calls _sendOdataDraftAction('draftActivate')", function (assert) {
      sinon.stub(this.oController, '_sendOdataDraftAction');
      this.oController.onSave();
      assert.ok(this.oController._sendOdataDraftAction.calledWith('draftActivate'));
    });

    QUnit.test('isProcessedDocumentActiveEntityFormatter returns true when active entity and status not invalid', function (assert) {
      Constants.PROCESSED_DOCUMENTS = { FILTER_VALUES: ['OK'] };
      const result = this.oController.isProcessedDocumentActiveEntityFormatter(true, 'OK');
      assert.strictEqual(result, true);
    });

    QUnit.test('isProcessedDocumentActiveEntityFormatter returns false when not active entity', function (assert) {
      Constants.PROCESSED_DOCUMENTS = { FILTER_VALUES: ['INV'] };
      const result = this.oController.isProcessedDocumentActiveEntityFormatter(false, 'OK');
      assert.strictEqual(result, false);
    });

    QUnit.test('isProcessedDocumentActiveEntityFormatter returns false when status is invalid', function (assert) {
      Constants.PROCESSED_DOCUMENTS = { FILTER_VALUES: ['OK'] };
      const result = this.oController.isProcessedDocumentActiveEntityFormatter(true, 'BAD');
      assert.strictEqual(result, false);
    });

    QUnit.test('isLockedByAnotherUserFormatter returns true when draft exists and not created by me', function (assert) {
      const draft = { DraftIsCreatedByMe: false };
      const result = this.oController.isLockedByAnotherUserFormatter(draft);
      assert.strictEqual(result, true);
    });

    QUnit.test('isLockedByAnotherUserFormatter returns false when draft is created by me or missing', function (assert) {
      assert.strictEqual(this.oController.isLockedByAnotherUserFormatter({ DraftIsCreatedByMe: true }), false);
      assert.strictEqual(this.oController.isLockedByAnotherUserFormatter(null), false);
    });

    QUnit.test('_getResponsivePopoverLock loads fragment once and caches promise', function (assert) {
      // const done = assert.async();
      delete this.oController._oPopoverLock;
      const popoverStub = {};
      const oFragmentStub = sinon.stub(Fragment, 'load').returns(Promise.resolve(popoverStub));

      const p1 = this.oController._getResponsivePopoverLock();
      const p2 = this.oController._getResponsivePopoverLock();

      assert.strictEqual(p1, p2, 'Same promise returned on second call');
      assert.ok(Fragment.load.calledOnce);
      oFragmentStub.restore();
    });

    QUnit.module('DocumentObjectPage Controller – onMakeCorrectionInDox', {
      beforeEach: function () {
        this.oController = new Controller();
        sinon.stub(this.oController, '_refreshData');
        sinon.stub(this.oController, '_isCorrectionInProgress');
        sinon.stub(this.oController, '_openDoxPage');
      },
      afterEach: function () {
        sinon.restore();
      }
    });

    QUnit.test('onMakeCorrectionInDox calls open when refresh succeeds and no correction in progress', function (assert) {
      const done = assert.async();
      this.oController._refreshData.returns(Promise.resolve());
      this.oController._isCorrectionInProgress.returns(false);
      this.oController.onMakeCorrectionInDox().then(() => {
        assert.ok(this.oController._openDoxPage.calledOnce);
        done();
      });
    });

    QUnit.test('onMakeCorrectionInDox does not open when correction in progress', function (assert) {
      const done = assert.async();
      this.oController._refreshData.returns(Promise.resolve());
      this.oController._isCorrectionInProgress.returns(true);
      this.oController.onMakeCorrectionInDox().then(() => {
        assert.notOk(this.oController._openDoxPage.called);
        done();
      });
    });

    QUnit.test('onMakeCorrectionInDox swallows errors and does not open', function (assert) {
      const done = assert.async();
      this.oController._refreshData.returns(Promise.reject(new Error('fail')));
      this.oController.onMakeCorrectionInDox().then(() => {
        assert.notOk(this.oController._openDoxPage.called);
        done();
      });
    });

    QUnit.module('DocumentObjectPage Controller – _refreshData', {
      beforeEach: function () {
        this.oController = new Controller();
        this.ctx = { refresh: sinon.stub() };
        this.oController.oObjectPage = { getBindingContext: () => this.ctx };
        this.model = { attachDataReceived: null, submitBatch: sinon.stub().returns(Promise.resolve()) };
        this.oController.oModel = this.model;
      },
      afterEach: function () {
        sinon.restore();
      }
    });

    QUnit.test('_refreshData resolves on dataReceived without error', function (assert) {
      const done = assert.async();
      const event = { getParameter: (p) => false };
      this.model.attachDataReceived = (fn) => fn(event);
      const p = this.oController._refreshData();
      assert.ok(this.ctx.refresh.calledOnce);
      assert.ok(this.model.submitBatch.calledOnce);
      p.then((e) => {
        assert.strictEqual(e, event);
        done();
      });
    });

    QUnit.test('_refreshData rejects on dataReceived with error', function (assert) {
      const done = assert.async();
      const event = { getParameter: (p) => p === 'error' };
      this.model.attachDataReceived = (fn) => fn(event);
      this.oController._refreshData().catch((e) => {
        assert.strictEqual(e, event);
        done();
      });
    });

    QUnit.module('DocumentObjectPage Controller – _isCorrectionInProgress', {
      beforeEach: function () {
        this.oController = new Controller();
        this.oContext = { getProperty: sinon.stub() };
        this.oController.oObjectPage = { getBindingContext: () => this.oContext };
        this.oMessageBoxStub = sinon.stub(MessageBox, 'error');
        sinon.stub(this.oController, '_getI18nText');
      },
      afterEach: function () {
        this.oMessageBoxStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('_isCorrectionInProgress shows error and returns true for DOX_CORRECTION_IN_PROGRESS', function (assert) {
      this.oContext.getProperty.withArgs('processingStatus').returns('DOX_CORRECTION_IN_PROGRESS');
      this.oController._getI18nText.withArgs('errorMessageDoxCorrectionInProgress').returns('E1');
      const result = this.oController._isCorrectionInProgress();
      assert.ok(MessageBox.error.calledWith('E1'));
      assert.strictEqual(result, true);
    });

    QUnit.test('_isCorrectionInProgress shows error and returns true for PROCESSED status', function (assert) {
      this.oContext.getProperty.withArgs('processingStatus').returns('OTHER');
      this.oContext.getProperty.withArgs('status').returns('PROCESSED');
      this.oController._getI18nText.withArgs('errorMessageDocumentProcessed').returns('E2');
      const result = this.oController._isCorrectionInProgress();
      assert.ok(MessageBox.error.calledWith('E2'));
      assert.strictEqual(result, true);
    });

    QUnit.test('_isCorrectionInProgress returns false otherwise', function (assert) {
      this.oContext.getProperty.returns('X');
      const result = this.oController._isCorrectionInProgress();
      assert.strictEqual(result, false);
    });

    QUnit.module('DocumentObjectPage Controller – Draft Actions', {
      beforeEach: function () {
        this.oController = new Controller();
        this.oController.oModel = { submitBatch: sinon.stub().returns(Promise.resolve()) };
        sinon.stub(this.oController, '_sendOdataDraftAction');
      },
      afterEach: function () {
        sinon.restore();
      }
    });

    QUnit.test('_setEditMode calls draftEdit action then submitBatch', function (assert) {
      const done = assert.async();
      this.oController._setEditMode().then(() => {
        assert.ok(this.oController._sendOdataDraftAction.calledWith('draftEdit'));
        assert.ok(this.oController.oModel.submitBatch.calledOnce);
        done();
      });
    });

    QUnit.test('_activateDraft calls draftActivate action then submitBatch', function (assert) {
      const done = assert.async();
      this.oController._activateDraft().then(() => {
        assert.ok(this.oController._sendOdataDraftAction.calledWith('draftActivate'));
        assert.ok(this.oController.oModel.submitBatch.calledOnce);
        done();
      });
    });

    QUnit.test('_setDoxCorrectionInProgress sequences edit, setProperty, submitBatch, activate', function (assert) {
      const done = assert.async();
      this.oController.oObjectPage = { getBindingContext: () => ({ setProperty: sinon.stub() }) };
      sinon.stub(this.oController, '_setEditMode').returns(Promise.resolve());
      sinon.stub(this.oController, '_activateDraft').returns(Promise.resolve());
      this.oController._setDoxCorrectionInProgress().then(() => {
        assert.ok(this.oController._setEditMode.calledOnce);
        assert.ok(this.oController.oModel.submitBatch.calledOnce);
        assert.ok(this.oController._activateDraft.calledOnce);
        done();
      });
    });

    QUnit.module('DocumentObjectPage Controller – _openDoxPage', {
      beforeEach: function () {
        this.oController = new Controller();
        this.ctx = { getObject: sinon.stub() };
        this.oController.oObjectPage = { getBindingContext: () => this.ctx };
        sinon.stub(this.oController, '_getI18nText');
        this.oConfirmStub = sinon.stub(MessageBox, 'confirm');
        this.oErrorStub = sinon.stub(MessageBox, 'error');
      },
      afterEach: function () {
        this.oConfirmStub.restore();
        this.oErrorStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('_openDoxPage shows confirm and opens window when link present', function (assert) {
      const doxUrl = 'http://dox';
      this.ctx.getObject.returns({ doxUILink: doxUrl });
      this.oController._getI18nText.withArgs('open').returns('O');
      this.oController._getI18nText.withArgs('cancel').returns('C');
      this.oController._getI18nText.withArgs('confirmOpenDox').returns('Sure?');
      window.open = sinon.stub().returns({ opener: null, location: {}, target: '' });
      const onClose = MessageBox.confirm.firstCall?.args[1].onClose || function () {};
      this.oController._openDoxPage();
      assert.ok(MessageBox.confirm.calledWith('Sure?', sinon.match.object));
      // simulate user clicks "O"
      MessageBox.confirm.firstCall.args[1].onClose('O');
      assert.ok(window.open.calledOnce);
      // cleanup
    });

    QUnit.test('_openDoxPage shows error when no link', function (assert) {
      this.ctx.getObject.returns({});
      this.oController._getI18nText.withArgs('errorMessageDoxLinkNotFound').returns('No link');
      this.oController._openDoxPage();
      assert.ok(MessageBox.error.calledWith('No link'));
    });

    QUnit.module('DocumentObjectPage Controller – Draft Actions', {
      beforeEach: function () {
        this.oController = new Controller();
        this.oController.sDocumentId = 'DOC99';
        sinon.stub(this.oController, '_getI18nText');
        this.oConfirmStub = sinon.stub(MessageBox, 'confirm');
        sinon.stub(this.oController, '_sendApproveSelectedItems');
      },
      afterEach: function () {
        this.oConfirmStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('_getDiscardDocument returns the current document ID', function (assert) {
      const result = this.oController._getDiscardDocument();
      assert.strictEqual(result.ID, 'DOC99');
    });

    QUnit.test('onApproveSelectedItemPress shows confirm dialog and sends approve when confirmed', function (assert) {
      const approve = 'Yes',
        cancel = 'No';
      this.oController._getI18nText.withArgs('approve').returns(approve);
      this.oController._getI18nText.withArgs('cancel').returns(cancel);
      this.oController._getI18nText.withArgs('confirmApproveItemForErpMessage').returns('Confirm this?');
      this.oController._getI18nText.withArgs('confirmApproveItemForErp').returns('Approve Title');

      this.oController.onApproveSelectedItemPress();

      assert.ok(MessageBox.confirm.calledOnce);
      const [msg, opts] = MessageBox.confirm.firstCall.args;
      assert.strictEqual(msg, 'Confirm this?');
      assert.strictEqual(opts.title, 'Approve Title');
      assert.deepEqual(opts.actions, [approve, cancel]);
      assert.strictEqual(opts.emphasizedAction, approve);
      assert.strictEqual(opts.contentWidth, '425px');
      assert.strictEqual(typeof opts.onClose, 'function');

      opts.onClose(approve);
      assert.ok(this.oController._sendApproveSelectedItems.calledWith(['DOC99']));
    });

    QUnit.module('DocumentObjectPage Controller – _bindObjectPage', {
      beforeEach: function () {
        this.oController = new Controller();
        this.oController.sDocumentId = 'DOC1';
        this.oModelStub = { bindList: sinon.stub() };
        this.oController.oModel = this.oModelStub;
        this.oObjectPageStub = { setBindingContext: sinon.stub() };
        this.oController.oObjectPage = this.oObjectPageStub;

        this.oViewStub = { byId: sinon.stub(), addDependant: sinon.stub(), getId: sinon.stub() };
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        this.oErpStatusStub = { setVisible: sinon.stub() };
        this.oViewStub.byId.withArgs('erpErrorStatus').returns(this.oErpStatusStub);
        this.fetchStub = sinon.stub(window, 'fetch');
        this.createURLStub = sinon.stub(URL, 'createObjectURL').returns('blob:url');
        sinon.stub(this.oController, '_createPDFViewer');
        sinon.stub(this.oController, '_addViewer');
        sinon.stub(this.oController, '_addNoDocumentAvailableViewer');
        this.oContentViewerContainerStub = { destroyItems: sinon.stub(), addItem: sinon.stub() };
        this.oController.oContentViewerContainer = this.oContentViewerContainerStub;
      },
      afterEach: function () {
        this.createURLStub.restore();
        this.fetchStub.restore();
        sinon.restore();
      }
    });

    QUnit.test('binds context, sets visibility false, no attachments', function (assert) {
      const done = assert.async();
      const data = { IsActiveEntity: false, sendingToERPError: '', attachments: [] };
      const contextStub = { getObject: () => data, getModel: () => this.oModelStub };
      this.oModelStub.bindList.returns({ requestContexts: () => Promise.resolve([contextStub]) });

      this.oController._bindObjectPage(false).then(() => {
        assert.ok(this.oObjectPageStub.setBindingContext.calledWith(contextStub));
        assert.ok(this.oErpStatusStub.setVisible.calledWith(false));
        assert.notOk(window.fetch.called);
        assert.notOk(this.oController._createPDFViewer.called);
        done();
      });
    });

    QUnit.test('binds context, sets visibility true, loads attachment, and creates PDF viewer', function (assert) {
      const done = assert.async();
      const attachment = { ID: 'A1', filename: 'file.pdf', mimeType: 'application/pdf' };
      const data = { IsActiveEntity: false, sendingToERPError: 'err', attachments: [attachment] };
      const contextStub = { getObject: () => data };
      this.oModelStub.bindList.returns({ requestContexts: () => Promise.resolve([contextStub]) });

      const url = `${this.oModelStub.sServiceUrl}${Constants.API.DOCUMENTS.PATH}(ID=DOC1,IsActiveEntity=false)/attachments(ID=A1)/content`;
      this.fetchStub.withArgs(url).returns(Promise.resolve({ blob: () => Promise.resolve('blobdata') }));

      this.oController._bindObjectPage(false).then(() => {
        assert.ok(this.oObjectPageStub.setBindingContext.calledWith(contextStub));
        assert.ok(this.oErpStatusStub.setVisible.calledWith(true));
        assert.ok(this.fetchStub.calledWith(url));
        assert.ok(this.createURLStub.calledWith('blobdata'));
        assert.ok(this.oController._createPDFViewer.calledWith('blob:url', 'file.pdf'));
        done();
      });
    });

    QUnit.test('binds context, sets visibility true, loads attachment, and creates img viewer', function (assert) {
      const done = assert.async();
      const attachment = { ID: 'A1', filename: 'file.png', mimeType: 'image/png' };
      const data = { IsActiveEntity: false, sendingToERPError: 'err', attachments: [attachment] };
      const contextStub = { getObject: () => data };
      this.oModelStub.bindList.returns({ requestContexts: () => Promise.resolve([contextStub]) });

      const url = `${this.oModelStub.sServiceUrl}${Constants.API.DOCUMENTS.PATH}(ID=DOC1,IsActiveEntity=false)/attachments(ID=A1)/content`;
      this.fetchStub.withArgs(url).returns(Promise.resolve({ blob: () => Promise.resolve('blobdata') }));

      this.oController._bindObjectPage(false).then(() => {
        assert.ok(this.oObjectPageStub.setBindingContext.calledWith(contextStub));
        assert.ok(this.oErpStatusStub.setVisible.calledWith(true));
        assert.ok(this.fetchStub.calledWith(url));
        assert.ok(this.createURLStub.calledWith('blobdata'));
        assert.ok(this.oController._addViewer.calledWith('blob:url', 'file.png', true));

        done();
      });
    });

    QUnit.test('binds context, sets visibility true, loads attachment, and creates XLSX downloader', function (assert) {
      const done = assert.async();
      const attachment = { ID: 'A1', filename: 'file.xlsx', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' };
      const data = { IsActiveEntity: false, sendingToERPError: 'err', attachments: [attachment] };
      const contextStub = { getObject: () => data };
      this.oModelStub.bindList.returns({ requestContexts: () => Promise.resolve([contextStub]) });

      const url = `${this.oModelStub.sServiceUrl}${Constants.API.DOCUMENTS.PATH}(ID=DOC1,IsActiveEntity=false)/attachments(ID=A1)/content`;
      this.fetchStub.withArgs(url).returns(Promise.resolve({ blob: () => Promise.resolve('blobdata') }));

      this.oController._bindObjectPage(false).then(() => {
        assert.ok(this.oObjectPageStub.setBindingContext.calledWith(contextStub));
        assert.ok(this.oErpStatusStub.setVisible.calledWith(true));
        assert.ok(this.fetchStub.calledWith(url));
        assert.ok(this.createURLStub.calledWith('blobdata'));
        assert.ok(this.oController._addViewer.calledWith('blob:url', 'file.xlsx', false));

        done();
      });
    });

    QUnit.test('onDownloadImage calls _onDownloadFile with correct URL and filename', function (assert) {
      const sUrl = 'https://example.com/image.png';
      const sFilename = 'myImage.png';
      const oData = { imageUrl: sUrl, filename: sFilename };
      const oImageViewerStub = {
        getModel: sinon.stub().returns({ getData: sinon.stub().returns(oData) })
      };
      const oParentStub = { getParent: sinon.stub().returns(oImageViewerStub) };
      const oSourceStub = { getParent: sinon.stub().returns(oParentStub) };
      const oEventStub = { getSource: sinon.stub().returns(oSourceStub) };

      const onDownloadFileStub = sinon.stub(this.oController, '_onDownloadFile');

      this.oController.onDownloadImage(oEventStub);

      assert.ok(onDownloadFileStub.calledOnce, '_onDownloadFile should be called exactly once');
      assert.ok(onDownloadFileStub.calledWith(sUrl, sFilename), '_onDownloadFile should be invoked with URL and filename from the model');
      onDownloadFileStub.restore();
    });
  }
);
