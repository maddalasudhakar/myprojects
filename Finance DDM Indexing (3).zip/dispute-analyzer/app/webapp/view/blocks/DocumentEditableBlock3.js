sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentEditableBlock3 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentEditableBlock3', {
    metadata: {}
  });

  return DocumentEditableBlock3;
});
