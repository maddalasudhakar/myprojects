sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentBlock2 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentBlock2', {
    metadata: {}
  });

  return DocumentBlock2;
});
