sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentBlock1 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentBlock1', {
    metadata: {}
  });

  return DocumentBlock1;
});
