sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentEditableBlock2 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentEditableBlock2', {
    metadata: {}
  });

  return DocumentEditableBlock2;
});
