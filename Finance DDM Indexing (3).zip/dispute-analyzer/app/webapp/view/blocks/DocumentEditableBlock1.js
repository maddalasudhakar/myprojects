sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentEditableBlock1 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentEditableBlock1', {
    metadata: {}
  });

  return DocumentEditableBlock1;
});
