sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentEditableBlock = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentEditableBlock', {
    metadata: {}
  });

  return DocumentEditableBlock;
});
