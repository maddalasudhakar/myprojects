sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
  'use strict';

  const DocumentBlock3 = BlockBase.extend('disputeanalyzerui.view.blocks.DocumentBlock3', {
    metadata: {}
  });

  return DocumentBlock3;
});
