import cds from '@sap/cds';

const { expect } = cds.test.in(__dirname + '/../..').run();
describe('DisputeAnalyzerService', () => {
  it('bootstrapped the database successfully', () => {
    const { DisputeAnalyzerService } = cds.services;
    expect(DisputeAnalyzerService).to.exist;
  });
});
