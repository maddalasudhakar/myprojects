import sendToLLMJobsService from '../../../srv/llm-processing-service/send-to-llm-jobs-service';
jest.mock('@sap/xsenv', () => ({
    serviceCredentials: jest.fn(() => ({
      url: 'https://mock-jobscheduler-url',
      uaa: {
        clientid: 'mock-client-id',
        clientsecret: 'mock-client-secret',
        url: 'https://mock-uaa-url',
      },
    })),
  }));
  jest.mock('../../../srv/lib/handlers/common-llm-processing-handler', () => ({
    __esModule: true,
    default: {
      processDocuments: jest.fn(),
      sendDoxDoneDocumentsForLLMProcessing: jest.fn(),
      sendDoxPartiallyDoneDocumentsForLLMProcessing: jest.fn(),
      resendDocumentsForLLMProcessing: jest.fn(),
      sendDocumentsCorrectedForLLMProcessing: jest.fn(),
    },
  }));
  jest.mock('@sap/cds', () => ({
    log: jest.fn(() => ({
      info: jest.fn(),
      warn: jest.fn(),
      error: jest.fn(),
    })),
    connect: {
      to: jest.fn(() => ({
        send: jest.fn(),
      })),
    },
    spawn: jest.fn((_, callback) => callback()),
    env: {
        requires: {},
      },
  }));

describe('send-to-llm-jobs-service', () => {
  let srv;

  beforeEach(() => {
    srv = {
        after: jest.fn(),
        on: jest.fn()
      };
  });
  beforeAll(() => {
    global.cds = {
      log: jest.fn(() => ({
        info: jest.fn(),
        error: jest.fn(),
        warn: jest.fn(),
      })),
      spawn: jest.fn((_, callback) => callback()),
    };
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  afterAll(() => {
    delete global.cds;
    jest.restoreAllMocks();
  });

  it('should register all event handlers', async () => {
    await sendToLLMJobsService(srv);
    expect(srv.on).toHaveBeenCalledWith('sendDocumentsForLLMProcessing', expect.any(Function));
    expect(srv.on).toHaveBeenCalledWith('sendDocumentsToOCRForLLMProcessing', expect.any(Function));
    expect(srv.on).toHaveBeenCalledWith('resendDocumentsForLLMProcessing', expect.any(Function));
    expect(srv.on).toHaveBeenCalledWith('sendDocumentsCorrectedForLLMProcessing', expect.any(Function));
  });

  it('should handle sendDocumentsForLLMProcessing action', async () => {
    let req = {headers: {}, jobSchedulerClient: {}, error: jest.fn(), http: { res: {} }};
    const headers = {
      'x-sap-job-id': 'test-job-id',
      'x-sap-job-schedule-id': 'test-schedule-id',
      'x-sap-job-run-id': 'test-run-id',
      'x-sap-scheduler-host': 'test-host',
      'x-sap-run-at': 'test-run-at',
    };
    req.headers = headers;
    req.user = { id: 'test-user' };
    req.http.res = {
      status: jest.fn(() => ({
        send: jest.fn(),
        end: jest.fn(),
      })),
    };

    const srv = {
        on: jest.fn((event, handler) => {
          if (event === 'sendDocumentsForLLMProcessing') {
            handler(req);
          }
        }),
      };

      await sendToLLMJobsService(srv);

      expect(srv.on).toHaveBeenCalledWith('sendDocumentsForLLMProcessing', expect.any(Function));
      expect(req.http.res.status).toHaveBeenCalledWith(202);
  });

  it('should handle errors in sendDocumentsForLLMProcessing action', async () => {
    const req = {http: { res: { status : jest.fn(() => ({ end: jest.fn() }))}}};

    const srv = {
      on: jest.fn((event, handler) => {
        if (event === 'sendDocumentsForLLMProcessing') {
          handler(req);
        }
      }),
    };

    await sendToLLMJobsService(srv);

    expect(req.http.res.status).toHaveBeenCalledWith(500);
  });

  it('should handle sendDocumentsToOCRForLLMProcessing action', async () => {
    let req = {headers: {}, jobSchedulerClient: {}, error: jest.fn(), http: { res: {} }};
    const headers = {
      'x-sap-job-id': 'test-job-id',
      'x-sap-job-schedule-id': 'test-schedule-id',
      'x-sap-job-run-id': 'test-run-id',
      'x-sap-scheduler-host': 'test-host',
      'x-sap-run-at': 'test-run-at',
    };
    req.headers = headers;
    req.user = { id: 'test-user' };
    req.http.res = {
      status: jest.fn(() => ({
        send: jest.fn(),
        end: jest.fn(),
      })),
    };

    const srv = {
        on: jest.fn((event, handler) => {
          if (event === 'sendDocumentsToOCRForLLMProcessing') {
            handler(req);
          }
        }),
      };

      await sendToLLMJobsService(srv);

      expect(srv.on).toHaveBeenCalledWith('sendDocumentsToOCRForLLMProcessing', expect.any(Function));
      expect(req.http.res.status).toHaveBeenCalledWith(202);
  });

  it('should handle errors in sendDocumentsToOCRForLLMProcessing action', async () => {
    const req = {http: { res: { status : jest.fn(() => ({ end: jest.fn() }))}}};

    const srv = {
      on: jest.fn((event, handler) => {
        if (event === 'sendDocumentsToOCRForLLMProcessing') {
          handler(req);
        }
      }),
    };

    await sendToLLMJobsService(srv);

    expect(req.http.res.status).toHaveBeenCalledWith(500);
  });

  it('should handle resendDocumentsForLLMProcessing action', async () => {
    let req = {headers: {}, jobSchedulerClient: {}, error: jest.fn(), http: { res: {} }};
    const headers = {
      'x-sap-job-id': 'test-job-id',
      'x-sap-job-schedule-id': 'test-schedule-id',
      'x-sap-job-run-id': 'test-run-id',
      'x-sap-scheduler-host': 'test-host',
      'x-sap-run-at': 'test-run-at',
    };
    req.headers = headers;
    req.user = { id: 'test-user' };
    req.http.res = {
      status: jest.fn(() => ({
        send: jest.fn(),
        end: jest.fn(),
      })),
    };

    const srv = {
        on: jest.fn((event, handler) => {
          if (event === 'resendDocumentsForLLMProcessing') {
            handler(req);
          }
        }),
      };

      await sendToLLMJobsService(srv);

      expect(srv.on).toHaveBeenCalledWith('resendDocumentsForLLMProcessing', expect.any(Function));
      expect(req.http.res.status).toHaveBeenCalledWith(202);
  });

  it('should handle errors in resendDocumentsForLLMProcessing action', async () => {
    const req = {http: { res: { status : jest.fn(() => ({ end: jest.fn() }))}}};

    const srv = {
      on: jest.fn((event, handler) => {
        if (event === 'resendDocumentsForLLMProcessing') {
          handler(req);
        }
      }),
    };

    await sendToLLMJobsService(srv);

    expect(req.http.res.status).toHaveBeenCalledWith(500);
  });

  it('should handle sendDocumentsCorrectedForLLMProcessing action', async () => {
    let req = {headers: {}, jobSchedulerClient: {}, error: jest.fn(), http: { res: {} }};
    const headers = {
      'x-sap-job-id': 'test-job-id',
      'x-sap-job-schedule-id': 'test-schedule-id',
      'x-sap-job-run-id': 'test-run-id',
      'x-sap-scheduler-host': 'test-host',
      'x-sap-run-at': 'test-run-at',
    };
    req.headers = headers;
    req.user = { id: 'test-user' };
    req.http.res = {
      status: jest.fn(() => ({
        send: jest.fn(),
        end: jest.fn(),
      })),
    };

    const srv = {
        on: jest.fn((event, handler) => {
          if (event === 'sendDocumentsCorrectedForLLMProcessing') {
            handler(req);
          }
        }),
      };

      await sendToLLMJobsService(srv);

      expect(srv.on).toHaveBeenCalledWith('sendDocumentsCorrectedForLLMProcessing', expect.any(Function));
      expect(req.http.res.status).toHaveBeenCalledWith(202);
  });

  it('should handle errors in sendDocumentsCorrectedForLLMProcessing action', async () => {
    const req = {http: { res: { status : jest.fn(() => ({ end: jest.fn() }))}}};

    const srv = {
      on: jest.fn((event, handler) => {
        if (event === 'sendDocumentsCorrectedForLLMProcessing') {
          handler(req);
        }
      }),
    };

    await sendToLLMJobsService(srv);

    expect(req.http.res.status).toHaveBeenCalledWith(500);
  });
});