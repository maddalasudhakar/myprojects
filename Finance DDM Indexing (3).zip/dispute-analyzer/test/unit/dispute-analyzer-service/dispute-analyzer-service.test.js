import disputeAnalyzerService from '../../../srv/dispute-analyzer-service/dispute-analyzer-service';
import DocumentsRepository from '../../../srv/common-lib/repository/documents-repository';
import { StatusCodes } from 'http-status-codes';
import cds from '@sap/cds';
jest.mock('@sap/cds', () => {
  return {
    env: {
      MAX_RETRIES: '3',
      MAX_RETRY_DELAY_MINUTES: '3',
      MAX_THRESHOLD_TIME_MINUTES: '30',
    },
    log: jest.fn(() => ({
      info: jest.fn(),
      error: jest.fn(),
      warn: jest.fn()
    })),
    Service: jest.fn(() => ({
      tx: jest.fn(() => ({ commit: jest.fn(), rollback: jest.fn() }))
    })),
    tx: jest.fn(() => ({ commit: jest.fn(), rollback: jest.fn() })),
    spawn: jest.fn(() => ({
      emit: jest.fn(),
      on: jest.fn(),
      before: jest.fn()
    }))
  };
});

jest.mock('../../../srv/lib/handlers/reject-handler', () => ({ handleRejectDocument: jest.fn() }));
jest.mock('../../../srv/common-lib/utils/utilities', () => ({
  isValidUUID: jest.fn(() => true),
  handleHttpError: jest.fn()
}));
jest.mock('../../../srv/common-lib/managers/job-scheduler-manager', () => ({
  handleActionTriggeredByJobScheduler: jest.fn().mockImplementation((req, fn) => fn())
}));

jest.mock('../../../srv/lib/repository/documents-repository', () =>
  jest.fn().mockImplementation(() => ({
    sendToERP: jest.fn(),
    updateDocumentsProcessingStatus: jest.fn().mockResolvedValue()
  }))
);
jest.mock('../../../srv/common-lib/managers/job-scheduler-manager', () => ({ handleActionTriggeredByJobScheduler: jest.fn((req, fn) => fn()) }));

afterEach(() => {
  jest.clearAllMocks();
});

describe('disputeAnalyzerService - READ handler', () => {
  let srv;
  beforeEach(() => {
    jest.clearAllMocks();
    srv = { on: jest.fn(), before: jest.fn() };
  });

  it('should register all event handlers', async () => {
    await disputeAnalyzerService(srv);
    expect(srv.on).toHaveBeenCalledWith('READ', 'Documents', expect.any(Function));
    expect(srv.on).toHaveBeenCalledWith('rejectDocument', expect.any(Function));
    expect(srv.on).toHaveBeenCalledWith('sendDocumentsToERP', expect.any(Function));
  });

  it('should handle errors and call req.error for READ', async () => {
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'READ' && handler.length === 2) {
          const req = { error: jest.fn() };
          handler(req, () => {
            throw new Error('fail');
          });
          expect(req.error).toHaveBeenCalledWith(StatusCodes.INTERNAL_SERVER_ERROR, expect.stringContaining('fail'));
        }
      },
      before: () => jest.fn()
    });
  });

  it('should calculate time difference for documents in READ handler', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc1',
        mailReceivedTimestamp: '2025-05-10T10:00:00Z',
        documentSentToErpOrRejected: '2025-05-10T12:30:00Z'
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result[0].currentTimeLineInHoursVsNow).toMatch(/\d+ h : \d+ min/);
    expect(result[0].timeDurationInHours).toBe('2 h : 30 min');
  });

  it('should skip entries with missing timestamps in READ handler', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc2',
        mailReceivedTimestamp: null,
        documentSentToErpOrRejected: null
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result).toEqual([
      {
        ID: 'doc2',
        mailReceivedTimestamp: null,
        documentSentToErpOrRejected: null
      }
    ]);
  });

  it('should skip entries with invalid timestamps in READ handler', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc2',
        mailReceivedTimestamp: 'test',
        documentSentToErpOrRejected: 'test'
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result).toEqual([
      {
        ID: 'doc2',
        currentTimeLineInHoursVsNow: "Invalid time difference",
        mailReceivedTimestamp: 'test',
        documentSentToErpOrRejected: 'test',
        timeDurationInHours: "Invalid time difference"
      }
    ]);
  });

  it('should skip processing if mailReceivedTimestamp is missing', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc1',
        mailReceivedTimestamp: null,
        documentSentToErpOrRejected: '2025-05-10T12:30:00Z'
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result[0].currentTimeLineInHoursVsNow).toBeUndefined();
    expect(result[0].timeDurationInHours).toBeUndefined();
  });

  it('should calculate time difference when timestamps are valid', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc2',
        mailReceivedTimestamp: '2025-05-10T10:00:00Z',
        documentSentToErpOrRejected: '2025-05-10T12:30:00Z'
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result[0].currentTimeLineInHoursVsNow).toMatch(/\d+ h : \d+ min/);
    expect(result[0].timeDurationInHours).toBe('2 h : 30 min');
  });

  it('should handle missing documentSentToErpOrRejected timestamp', async () => {
    const req = {};
    const next = jest.fn().mockResolvedValue([
      {
        ID: 'doc3',
        mailReceivedTimestamp: '2025-05-10T10:00:00Z',
        documentSentToErpOrRejected: null
      }
    ]);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'READ' && call[1] === 'Documents')[2];
    const result = await handler(req, next);

    expect(result[0].currentTimeLineInHoursVsNow).toMatch(/\d+ h : \d+ min/);
    expect(result[0].timeDurationInHours).toBeUndefined();
  });
});

describe('disputeAnalyzerService - rejectDocument handler', () => {
  it('should handle errors and call req.error for rejectDocument', async () => {
    const utilities = require('../../../srv/common-lib/utils/utilities');
    jest.spyOn(utilities, 'isValidUUID').mockReturnValue(true);
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'rejectDocument') {
          const req = { data: { documentId: 'id', reason: 'reason' }, error: jest.fn() };
          handler(req);
          expect(req.error).not.toHaveBeenCalled();
        }
      },
      before: () => jest.fn()
    });
  });

  it('should throw error if documentId is not provided in rejectDocument', async () => {
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'rejectDocument') {
          const req = { data: {}, error: jest.fn() };
          handler(req);
          expect(req.error).toHaveBeenCalledWith(StatusCodes.BAD_REQUEST, 'Both documentId and reason are required.');
        }
      },
      before: () => jest.fn()
    });
  });

  it('should throw error if documentId is invalid in rejectDocument', async () => {
    const utilities = require('../../../srv/common-lib/utils/utilities');
    jest.spyOn(utilities, 'isValidUUID').mockReturnValue(false);
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'rejectDocument') {
          const req = { data: { documentId: 'invalid-id', reason: 'reason' }, error: jest.fn() };
          handler(req);
          expect(req.error).toHaveBeenCalledWith(StatusCodes.BAD_REQUEST, 'Invalid document ID. It must be a valid UUID.');
        }
      },
      before: () => jest.fn()
    });
  });

  it('should throw error if reason is number in rejectDocument', async () => {
    const utilities = require('../../../srv/common-lib/utils/utilities');
    jest.spyOn(utilities, 'isValidUUID').mockReturnValue(true);
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'rejectDocument') {
          const req = { data: { documentId: 'id', reason: 1234 }, error: jest.fn() };
          handler(req);
          expect(req.error).toHaveBeenCalledWith(StatusCodes.BAD_REQUEST, 'Invalid rejection reason. It must be a string with a maximum length of 255 characters.');
        }
      },
      before: () => jest.fn()
    });
  });
});

describe('disputeAnalyzerService - sendDocumentsToERP handler', () => {
  let srv;
  beforeEach(() => {
    jest.clearAllMocks();
    srv = { on: jest.fn(), before: jest.fn() };
  });

  it('should handle errors and call req.error for sendDocumentsToERP', async () => {
    const utilities = require('../../../srv/common-lib/utils/utilities');
    jest.spyOn(utilities, 'isValidUUID').mockReturnValue(true);
    await disputeAnalyzerService({
      on: (event, handler) => {
        if (event === 'sendDocumentsToERP') {
          const req = { data: { documentIds: ['id'] }, error: jest.fn(), res: { status: jest.fn() } };
          handler(req);
          expect(req.error).not.toHaveBeenCalled();
        }
      },
      before: () => jest.fn()
    });
  });

  it('should validate document IDs and trigger ERP processing', async () => {
    const req = {
      data: { documentIds: ['valid-uuid-1', 'valid-uuid-2'] },
      error: jest.fn(),
      res: { status: jest.fn() }
    };

    const updateStatusSpy = jest.spyOn(DocumentsRepository.prototype, 'updateDocumentsProcessingStatus').mockResolvedValue();

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'sendDocumentsToERP')[1];
    await handler(req);

    expect(req.error).not.toHaveBeenCalled();
    expect(req.res.status).toHaveBeenCalledWith(StatusCodes.ACCEPTED);
  });

  it('should handle invalid document IDs', async () => {
    const req = {
      data: { documentIds: ['invalid-uuid'] },
      error: jest.fn(),
      res: { status: jest.fn() }
    };

    const utilities = require('../../../srv/common-lib/utils/utilities');
    jest.spyOn(utilities, 'isValidUUID').mockReturnValue(false);

    await disputeAnalyzerService(srv);

    const handler = srv.on.mock.calls.find((call) => call[0] === 'sendDocumentsToERP')[1];
    await handler(req);

    expect(req.error).toHaveBeenCalledWith(StatusCodes.BAD_REQUEST, 'Some document IDs are invalid UUIDs.');
    expect(req.res.status).not.toHaveBeenCalled();
  });
});

describe('disputeAnalyzerService - before SAVE Documents handler', () => {
  let srv;
  beforeEach(() => {
    jest.clearAllMocks();
    srv = { on: jest.fn(), before: jest.fn() };
  });

  it('should call req.error with BAD_REQUEST if ID is missing', async () => {
    const req = { data: {}, error: jest.fn() };
    await disputeAnalyzerService({
      before: (event, entity, handler) => {
        if (event === 'SAVE' && entity === 'Documents') {
          handler(req);
          expect(req.error).toHaveBeenCalledWith(StatusCodes.BAD_REQUEST, expect.stringContaining('Document ID is required'));
        }
      },
      on: jest.fn()
    });
  });

  it('should call req.error with NOT_FOUND if document is missing', async () => {
    const req = { data: { ID: 'doc1' }, error: jest.fn() };
    // Mock DocumentsRepository to return null for document
    DocumentsRepository.prototype.getDocumentById = jest.fn().mockResolvedValue(null);
    DocumentsRepository.prototype.getDraftDocumentById = jest.fn().mockResolvedValue({});
    await disputeAnalyzerService({
      before: (event, entity, handler) => {
        if (event === 'SAVE' && entity === 'Documents') {
          handler(req).then(() => {
            expect(req.error).toHaveBeenCalledWith(StatusCodes.NOT_FOUND, expect.stringContaining('Document with ID doc1 not found.'));
          });
        }
      },
      on: jest.fn()
    });
  });

  it('should call req.error with NOT_FOUND if draftDocument is missing', async () => {
    const req = { data: { ID: 'doc2' }, error: jest.fn() };
    // Mock DocumentsRepository to return null for draftDocument
    DocumentsRepository.prototype.getDocumentById = jest.fn().mockResolvedValue({});
    DocumentsRepository.prototype.getDraftDocumentById = jest.fn().mockResolvedValue(null);
    await disputeAnalyzerService({
      before: (event, entity, handler) => {
        if (event === 'SAVE' && entity === 'Documents') {
          handler(req).then(() => {
            expect(req.error).toHaveBeenCalledWith(StatusCodes.NOT_FOUND, expect.stringContaining('Draft document with ID doc2 not found.'));
          });
        }
      },
      on: jest.fn()
    });
  });

  it('should not call req.error on success', async () => {
    const req = { data: { ID: 'doc3' }, error: jest.fn() };
    // Mock DocumentsRepository to return valid document and draftDocument
    DocumentsRepository.prototype.getDocumentById = jest.fn().mockResolvedValue({ processingStatus: 'SOME_STATUS' });
    DocumentsRepository.prototype.getDraftDocumentById = jest.fn().mockResolvedValue({});
    await disputeAnalyzerService({
      before: (event, entity, handler) => {
        if (event === 'SAVE' && entity === 'Documents') {
          handler(req).then(() => {
            expect(req.error).not.toHaveBeenCalled();
          });
        }
      },
      on: jest.fn()
    });
  });

  it('should call req.error with INTERNAL_SERVER_ERROR if fetchDocuments throws', async () => {
    const req = { data: { ID: 'doc4' }, error: jest.fn() };
    // Mock DocumentsRepository to throw error
    DocumentsRepository.prototype.getDocumentById = jest.fn().mockRejectedValue(new Error('fetch error'));
    DocumentsRepository.prototype.getDraftDocumentById = jest.fn().mockResolvedValue({});
    await disputeAnalyzerService({
      before: (event, entity, handler) => {
        if (event === 'SAVE' && entity === 'Documents') {
          handler(req).then(() => {
            expect(req.error).toHaveBeenCalledWith(StatusCodes.INTERNAL_SERVER_ERROR, expect.stringContaining('An error occurred while processing documents'));
          });
        }
      },
      on: jest.fn()
    });
  });
});

describe('disputeAnalyzerService - SAVE Documents handler', () => {
  let srv;
  beforeEach(() => {
    jest.clearAllMocks();
    srv = { on: jest.fn(), before: jest.fn() };
  });

  it('should call next and update processing status if processingStatus and ID are present', async () => {
    const req = { data: { ID: 'doc1', processingStatus: 'SOME_STATUS' }, error: jest.fn() };
    const next = jest.fn();
    const updateSpy = jest.spyOn(DocumentsRepository.prototype, 'updateDocumentProcessingStatus').mockResolvedValue();
    await disputeAnalyzerService(srv);
    const handler = srv.on.mock.calls.find((call) => call[0] === 'SAVE' && call[1] === 'Documents')[2];
    await handler(req, next);
    expect(next).toHaveBeenCalled();
    expect(updateSpy).toHaveBeenCalledWith('doc1', 'SOME_STATUS');
    expect(req.error).not.toHaveBeenCalled();
  });

  it('should call next and not update processing status if processingStatus or ID is missing', async () => {
    const req = { data: { ID: 'doc1' }, error: jest.fn() };
    const next = jest.fn();
    const updateSpy = jest.spyOn(DocumentsRepository.prototype, 'updateDocumentProcessingStatus').mockResolvedValue();
    await disputeAnalyzerService(srv);
    const handler = srv.on.mock.calls.find((call) => call[0] === 'SAVE' && call[1] === 'Documents')[2];
    await handler(req, next);
    expect(next).toHaveBeenCalled();
    expect(updateSpy).not.toHaveBeenCalled();
    expect(req.error).not.toHaveBeenCalled();
  });

  it('should call req.error with INTERNAL_SERVER_ERROR if an error is thrown', async () => {
    const req = { data: { ID: 'doc1', processingStatus: 'SOME_STATUS' }, error: jest.fn() };
    const next = jest.fn().mockImplementation(() => { throw new Error('save error'); });
    await disputeAnalyzerService(srv);
    const handler = srv.on.mock.calls.find((call) => call[0] === 'SAVE' && call[1] === 'Documents')[2];
    await handler(req, next);
    expect(req.error).toHaveBeenCalledWith(StatusCodes.INTERNAL_SERVER_ERROR, expect.stringContaining('An error occurred while saving documents'));
  });
});
