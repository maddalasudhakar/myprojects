import masterdataSynchService from '../../../srv/masterdata-synch-service/masterdata-synch-service.js';
import MasterDataHandler from '../../../srv/lib/handlers/masterdata-handler.js';
import { handleActionTriggeredByJobScheduler } from '../../../srv/common-lib/managers/job-scheduler-manager.js';
import Utilities from '../../../srv/common-lib/utils/utilities.js';
import cds from '@sap/cds';

describe('masterdata-synch-service', () => {
  let srv;
  let onHandler;
  let logInfoSpy;

  beforeEach(() => {
    onHandler = jest.fn();
    srv = { on: onHandler };
    logInfoSpy = jest.spyOn(cds.log('masterdata-synch-service'), 'info').mockImplementation(() => {});
    jest.spyOn(Utilities, 'handleHttpError').mockImplementation(() => {});
    jest.spyOn(MasterDataHandler, 'synchronizeMasterdata').mockResolvedValue();
    jest.spyOn(handleActionTriggeredByJobScheduler, 'bind').mockReturnValue(handleActionTriggeredByJobScheduler);
    jest.spyOn(handleActionTriggeredByJobScheduler, 'call').mockResolvedValue();
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('registers synchronizeMasterdata handler and calls job scheduler on success', async () => {
    const req = {};
    onHandler.mockImplementation((event, handler) => {
      expect(event).toBe('synchronizeMasterdata');
      // Simulate calling the handler
      return handler(req);
    });
    const jobSchedulerSpy = jest.spyOn(require('../../../srv/common-lib/managers/job-scheduler-manager.js'), 'handleActionTriggeredByJobScheduler').mockResolvedValue();
    await masterdataSynchService(srv);
    expect(onHandler).toHaveBeenCalledWith('synchronizeMasterdata', expect.any(Function));
    expect(logInfoSpy).toHaveBeenCalledWith('Action: synchronizeMasterdata triggered');
    expect(jobSchedulerSpy).toHaveBeenCalledWith(req, MasterDataHandler.synchronizeMasterdata);
  });

  it('calls handleHttpError on error', async () => {
    const req = {};
    const error = new Error('fail!');
    onHandler.mockImplementation((event, handler) => {
      expect(event).toBe('synchronizeMasterdata');
      // Simulate calling the handler and throw error
      return handler(req);
    });
    jest.spyOn(require('../../../srv/common-lib/managers/job-scheduler-manager.js'), 'handleActionTriggeredByJobScheduler').mockRejectedValue(error);
    await masterdataSynchService(srv);
    expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'synchronizeMasterdata');
  });
});
