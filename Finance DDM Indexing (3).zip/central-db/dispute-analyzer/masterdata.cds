namespace dispute.masterdata;

entity Customer2 @cds.persistence.exists {
    key CustomerKey        : String;
        CustomerName       : String;
        Customer1Name      : String;
        StreetName         : String;
        PostalCode         : String;
        CityName           : String;
        VATRegistrationCNo : String;
}

entity Customerpartnerrole @cds.persistence.exists {
    key CustomerKey             : String;
        SalesOrganizationCode   : String;
        DistributionChannelCode : String;
        DivisionCode            : String;
        PartnerFunctionCode     : String;
        CustomerKeyPartner      : String;
        SourceSystemKey        : String;
}

entity CustomerSnapshot {
    key ID                     : UUID;
        CustomerName           : String;
        NormalizedCustomerName : String;
        CustomerKey            : String;
        Customer1Name          : String;
        StreetName             : String;
        PostalCode             : String;
        EscapedPostalCode      : String;
        CityName               : String;
        VATRegistrationCNo     : String;
        PartnerFunctionCode    : String;
        CustomerKeyPartner     : String;
        SourceSystemKey        : String;
}