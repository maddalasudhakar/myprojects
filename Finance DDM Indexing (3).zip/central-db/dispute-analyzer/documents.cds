namespace dispute.management;

using {cuid} from '@sap/cds/common';
using {sap.attachments.Attachments} from '@cap-js/attachments';

entity Documents : cuid {
    externalAttachmentId        : String;
    name                        : String;
    createdAt                   : Timestamp @cds.on.insert: $now;
    lastModifiedAt              : Timestamp @cds.on.update: $now @cds.on.insert: $now;
    companyCode                 : String(30); //Avoid association with Companies to prevent joins during document filtering. Ensure company code validation before document creation.
    doxJobId                    : String;
    attachments                 : Composition of many Attachments;
    processingStatus            : String enum {
        NEW;
        UNPROCESSED;
        INVALID_MAIL;
        CONTENT_FETCH_ERROR;
        SENDING_TO_DOX;
        DOX_CORRECTION_IN_PROGRESS;
        DOX_IN_PROGRESS;
        DOX_DONE;
        DOX_CORRECTION_DONE;
        DOX_FAILED;
        DOX_PARTIALLY_DONE;
        SENDING_TO_LLM;
        VALIDATION_FAILED;
        LLM_DONE;
        LLM_FAILED;
        SENDING_TO_ERP;
        ERP_DONE;
        ERP_FAILED;
    } default 'NEW';
    errorReason                 : String;
    status                      : String enum {
        NEW; // processed by LLM
        PROCESSED; // sent by user to ERP
        REJECTED; // rejected by user
        ERP_FAILED;
        INVALID;
    };
    confidenceLevel             : String enum {
        HIGH;
        MEDIUM;
        LOW;
    };
    notSendingToERPReason       : String;
    sendingToERPError           : String;
    claimCaseNumber             : String;
    mailReceivedTimestamp       : Timestamp;
    llmCodeExplanation          : String;
    reasonCode                  : String;
    businessAreaCode            : String;
    customerNumber              : String;
    customerName                : String;
    customerPostalCode          : String;
    customerCity                : String;
    customerExternalReference   : String;
    henkelInvoice               : String;
    amount                      : Double;
    debitNoteDate               : String;
    taxReportingDate            : String;
    netDueDate                  : String;
    currentTimeLineInHoursVsNow : String    @readonly; // Time difference between the current time and the time when the email was received
    documentSentToErpOrRejected : Timestamp; // Time when the document was sent to ERP or it was rejected by user
    timeDurationInHours         : String    @readonly; // Time duration between the time when the email was received and the time when it was sent to ERP
    headerFieldsString          : LargeString;
    lineItemsFieldsString       : LargeString;
    soldTo                      : String;
    shipTo                      : String;
    doxUILink                   : String;
    message                     : Association to one Messages;
    isModifiedByUser            : String enum {
        Yes;
        No;
    } default 'No';
}

entity Messages : cuid {
    externalMessageId     : String;
    subject               : String;
    createdAt             : Timestamp @cds.on.insert: $now;
    lastModifiedAt        : Timestamp @cds.on.update: $now;
    mailReceivedTimestamp : Timestamp;
    processingStatus      : String enum {
        DONE;
        PARTIALLY_DONE;
        NO_ATTACHMENTS_FOUND;
        ATTACHMENTS_FETCH_ERROR;
    } default 'DONE';
    errorReason           : String;
    documents             : Composition of many Documents
                                on documents.message = $self;
}

entity FailedMessageJobs : cuid {
    timestamp        : Timestamp;
    retryCount       : Integer default 0;
    processingStatus : String enum {
        UNPROCESSED;
        PROCESSED
    } default 'UNPROCESSED';
}
