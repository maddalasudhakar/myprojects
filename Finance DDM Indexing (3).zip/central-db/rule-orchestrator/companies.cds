namespace dispute.management;

using {cuid} from '@sap/cds/common';
using {dispute.management.RuleBooks} from './rulebooks';

entity Companies : cuid {
    companyCode : String(30);
    countryName : String(60);
    ruleBook    : Composition of one RuleBooks
                      on ruleBook.company = $self;
    currencyCode : String(3);
}
