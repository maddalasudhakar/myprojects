namespace dispute.management;

using {cuid} from '@sap/cds/common';
using {dispute.management.RuleBooks} from './rulebooks';

entity ReasonCodeMappings : cuid {
    reasonCode : String(15); // this corresponds to key in UI
    keywords   : LargeString; // this corresponds to value in UI
    ruleBook   : Association to one RuleBooks;
}
