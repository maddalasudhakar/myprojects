namespace dispute.management;

using {cuid} from '@sap/cds/common';
using {dispute.management.ReasonCodeMappings} from './reason-code-mappings';
using {dispute.management.BusinessAreaCodeMappings} from './ba-code-mappings';
using {dispute.management.Companies} from './companies';

@assert.unique: {company: [company]}
entity RuleBooks : cuid {
    lastModifiedAt                : Timestamp  @cds.on.insert: $now  @cds.on.update: $now;
    llmName                       : String;
    additionalInfo                : String;
    reasonCodeMappingPrompt       : LargeString;
    businessAreaCodeMappingPrompt : LargeString;
    reasonCodeMappings            : Composition of many ReasonCodeMappings
                                        on reasonCodeMappings.ruleBook = $self;
    businessAreaCodeMappings      : Composition of many BusinessAreaCodeMappings
                                        on businessAreaCodeMappings.ruleBook = $self;
    company                       : Association to one Companies;
}
