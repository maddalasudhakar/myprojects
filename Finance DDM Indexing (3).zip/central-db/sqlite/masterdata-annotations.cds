using {
    dispute.masterdata.Customer2,
    dispute.masterdata.Customerpartnerrole,
    dispute.masterdata.CustomerSnapshot,
} from '../dispute-analyzer/masterdata';

annotate Customer2 with  @cds.persistence.exists: false  @cds.persistence.skip: false;
annotate Customerpartnerrole with  @cds.persistence.exists: false  @cds.persistence.skip: false;
annotate CustomerSnapshot with  @cds.persistence.exists: false  @cds.persistence.skip: false;
