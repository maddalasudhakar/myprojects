// Mock cds.log before any imports that use it
jest.mock('@sap/cds', () => ({
  log: () => ({ info: jest.fn(), error: jest.fn(), warn: jest.fn() }),
  env: { requires: { LLM_MODELS: ['gpt-4', 'gpt-4o'] } }
}));

import cds from '@sap/cds';
import { defaultAITemplate } from '../../../srv/lib/utils/ai-prompt-templating.js';

describe('rule-orchestrator-service', () => {
  let srv;
  beforeEach(() => {
    srv = {
      after: jest.fn(),
      on: jest.fn()
    };
    Object.defineProperty(cds, 'env', { value: { requires: { LLM_MODELS: ['gpt-4', 'gpt-4o'] } }, configurable: true });
  });

  it('should register on getLLMModels handler', async () => {
    const handler = (await import('../../../srv/rule-orchestrator-service/rule-orchestrator-service.js')).default;
    await handler(srv);
    expect(srv.on).toHaveBeenCalledWith('getLLMModels', expect.any(Function));
  });

  it('should register on getDefaultRuleBook handler', async () => {
    const handler = (await import('../../../srv/rule-orchestrator-service/rule-orchestrator-service.js')).default;
    await handler(srv);
    expect(srv.on).toHaveBeenCalledWith('getDefaultRuleBook', expect.any(Function));
  });

  it('should return LLM models from env', async () => {
    let llmHandler;
    const handler = (await import('../../../srv/rule-orchestrator-service/rule-orchestrator-service.js')).default;
    srv.on.mockImplementation((event, fn) => {
      if (event === 'getLLMModels') llmHandler = fn;
    });
    await handler(srv);
    const result = await llmHandler();
    expect(result).toEqual(['gpt-4', 'gpt-4o']);
  });

  it('should return empty array if LLM models are not defined in env', async () => {
    Object.defineProperty(cds, 'env', { value: { requires: {} }, configurable: true });
    let llmHandler;
    const handler = (await import('../../../srv/rule-orchestrator-service/rule-orchestrator-service.js')).default;
    srv.on.mockImplementation((event, fn) => {
      if (event === 'getLLMModels') llmHandler = fn;
    });
    await handler(srv);
    const result = await llmHandler();
    expect(result).toEqual([]);
  });

  it('should return default AI template', async () => {
    let defaultHandler;
    const handler = (await import('../../../srv/rule-orchestrator-service/rule-orchestrator-service.js')).default;
    srv.on.mockImplementation((event, fn) => {
      if (event === 'getDefaultRuleBook') defaultHandler = fn;
    });
    await handler(srv);
    const result = await defaultHandler();
    expect(result).toEqual(defaultAITemplate());
  });
});
