jest.mock('helmet', () => () => (req, res, next) => next(), { virtual: true });

import cds from '@sap/cds';

const { expect } = cds.test.in(__dirname + '/../..').run();
describe('RuleOrchestratorService', () => {
  it('bootstrapped the database successfully', () => {
    const { RuleOrchestratorService } = cds.services;
    const { Companies } = RuleOrchestratorService.entities;
    expect(RuleOrchestratorService).to.exist;
    expect(Companies).to.exist;
  });
});
