sap.ui.define(
  [
    'sap/ui/core/mvc/Controller',
    'sap/ui/model/odata/v4/ODataModel',
    'sap/m/SearchField',
    'sap/ui/model/Filter',
    'sap/ui/model/FilterOperator',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/core/format/DateFormat'
  ],
  function (Controller, ODataModel, SearchField, Filter, FilterOperator, JSONModel, MessageBox, DateFormat) {
    'use strict';

    return Controller.extend('ruleorchestratorui.controller.RuleOrchestrator', {
      onInit: function () {
        this.oModel = this.getOwnerComponent().getModel();
        this.getView().setModel(this.oModel);

        this.oModel.attachDataReceived(function (oEvent) {
          if (oEvent.getParameters().error) {
            MessageBox.error('An error occurred while communicating with the service');
          }
        });

        this.oViewModel = new JSONModel({
          selectedCompany: ''
        });
        this.getView().setModel(this.oViewModel, 'viewModel');
      },

      onTableDataReceived: function () {
        const oResourceBundle = this.getView().getModel('i18n').getResourceBundle();
        const iItemCount = this.byId('idCompanySelectionTable').getBinding('items').getCount();
        const sHeaderText = oResourceBundle.getText('valueHelpDialog.tableTitle', [iItemCount]);
        this.byId('idCompanySelectionTable').setHeaderText(sHeaderText);
      },

      onValueHelpRequested: function () {
        this._oBasicSearchField = new SearchField();
        this.loadFragment({
          name: 'ruleorchestratorui.view.fragments.ValueHelpDialog'
        }).then(
          function (oDialog) {
            this._oVHD = oDialog;
            this.getView().addDependent(oDialog);
            const oFilterBar = this.getView().byId('fbSelectCompany');

            //Set Basic Search for FilterBar
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchField.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.open();
          }.bind(this)
        );
      },

      onSelectionChange: function () {
        const oFilterBar = this.getView().byId('fbSelectCompany');
        oFilterBar.search();
      },

      onValueHelpOKPress: async function () {
        let oTable = this.getView().byId('idCompanySelectionTable');
        const selectedItems = oTable.getSelectedItems();

        if (selectedItems?.length === 0) {
          MessageBox.error('Please select one company to proceed.');
          return;
        }

        const sSelectedValue = selectedItems[0].getBindingContext().getObject();
        this.oViewModel.setProperty('/selectedCompany', sSelectedValue);

        try {
          const aRuleBookContext = await this._getRuleBookByCompanyID(sSelectedValue.ID);
          const oObjectPage = this.getView().byId('companySelectionObjectPageLayout');
          if (aRuleBookContext?.length === 0) {
            const defaultRuleBookContext = await this._getDefaultRuleBook();
            const defaultRuleBook = defaultRuleBookContext.getObject();
            const newRuleBook = this.oModel
              .bindList('/RuleBooks', undefined, [], [], { $expand: 'reasonCodeMappings,businessAreaCodeMappings,DraftAdministrativeData' })
              .create({
                ...defaultRuleBook,
                company_ID: sSelectedValue.ID,
                IsActiveEntity: true
              });
            oObjectPage.setBusy(true);
            newRuleBook.created().then(() => {
              oObjectPage.setBindingContext(newRuleBook);
              oObjectPage.setBusy(false);
            });
            return;
          }
          const aRuleBookDraftAdministrativeData = aRuleBookContext[0].getObject().DraftAdministrativeData;
          if (aRuleBookDraftAdministrativeData && aRuleBookDraftAdministrativeData.DraftIsProcessedByMe) {
            const draftRuleBook = await this._getRuleBookByCompanyID(sSelectedValue.ID, false);
            oObjectPage.setBindingContext(draftRuleBook[0]);
            return;
          }
          oObjectPage.setBindingContext(aRuleBookContext[0]);
        } catch (oError) {
          MessageBox.error('Error fetching the selected rule book:', oError);
        } finally {
          this._oVHD.close();
        }
      },
      _getDefaultRuleBook: async function () {
        const oModel = this.getView().getModel();
        const oAction = oModel.bindContext('/getDefaultRuleBook(...)');
        try {
          await oAction.execute();
          return oAction.getBoundContext();
        } catch (oError) {
          MessageBox.error('Error fetching default rule book:', oError);
        }
      },

      _getRuleBookByCompanyID: async function (sCompanyID, bIsActiveEntity = true) {
        const oRuleBookBinding = this.oModel.bindList(
          '/RuleBooks',
          undefined,
          [],
          [new Filter('company_ID', FilterOperator.EQ, sCompanyID), new Filter('IsActiveEntity', FilterOperator.EQ, bIsActiveEntity)],
          {
            $expand: 'businessAreaCodeMappings,reasonCodeMappings,DraftAdministrativeData'
          }
        );
        try {
          const aRuleBookContext = await oRuleBookBinding.requestContexts();
          return aRuleBookContext;
        } catch (oError) {
          MessageBox.error('Error fetching rule book:', oError);
        }
      },

      onValueHelpCancelPress: function () {
        this._oVHD.close();
      },

      onValueHelpAfterClose: function () {
        this._oVHD.destroy();
      },

      onClickRestoreDefaultRuleBook: function () {
        MessageBox.confirm('This action will overwrite and restore the current rulebook. Are you sure you want to proceed?', {
          title: 'Restore Default Rulebook',
          onClose: function (sAction) {
            if (sAction === MessageBox.Action.OK) {
              this.onRestoreDefaultRuleBook();
            }
          }.bind(this)
        });
      },

      onRestoreDefaultRuleBook: async function () {
        let oObjectPage = this.byId('companySelectionObjectPageLayout');
        const oBindingContext = oObjectPage.getBindingContext();

        this._deleteAllMappings('idReasonCodeTable');
        this._deleteAllMappings('idBusinessAreaCodeTable');

        try {
          const oDefaultRuleBook = await this._getDefaultRuleBook();
          if (oDefaultRuleBook) {
            oBindingContext.setProperty('llmName', oDefaultRuleBook.getObject().llmName);
            oBindingContext.setProperty('reasonCodeMappingPrompt', oDefaultRuleBook.getObject().reasonCodeMappingPrompt);
            oBindingContext.setProperty('businessAreaCodeMappingPrompt', oDefaultRuleBook.getObject().businessAreaCodeMappingPrompt);
            oBindingContext.setProperty('additionalInfo', oDefaultRuleBook.getObject().additionalInfo);
          }
        } catch (oError) {
          MessageBox.error('Error restoring the default rule book:', oError);
        }
      },

      _deleteAllMappings: function (sTableId) {
        const oTable = this.byId(sTableId);
        const aItems = oTable.getItems();

        if (aItems) {
          aItems.forEach((oItem) => {
            const oContext = oItem.getBindingContext();
            if (oContext) {
              oContext.delete().catch(function (oError) {
                if (!oError.canceled) {
                  MessageBox.error('Error deleting all mappings:', oError);
                }
              });
            }
          });
        }
      },

      onImportRuleBook: function () {
        this.loadFragment({
          name: 'ruleorchestratorui.view.fragments.ImportRulebookDialog'
        }).then(
          function (oDialog) {
            this._oImportRuleBookDialog = oDialog;
            this.getView().addDependent(oDialog);
            oDialog.open();
          }.bind(this)
        );
      },

      onRuleBookToImportPress: async function () {
        const oObjectPage = this.byId('companySelectionObjectPageLayout');
        const oBindingContext = oObjectPage.getBindingContext();
        const sSelectedCompanyID = this.getView().byId('cbCompanyCodeToImport').getSelectedKey();

        if (!sSelectedCompanyID) {
          MessageBox.error('Please select a company to import the rulebook.');
          return;
        }
        try {
          const oRuleBook = await this._getRuleBookByCompanyID(sSelectedCompanyID, true);
          if (oRuleBook) {
            const oRuleBookData = oRuleBook[0].getObject();
            oBindingContext.setProperty('llmName', oRuleBookData.llmName);
            oBindingContext.setProperty('reasonCodeMappingPrompt', oRuleBookData.reasonCodeMappingPrompt);
            oBindingContext.setProperty('businessAreaCodeMappingPrompt', oRuleBookData.businessAreaCodeMappingPrompt);
            oBindingContext.setProperty('additionalInfo', oRuleBookData.additionalInfo);

            this._deleteAllMappings('idReasonCodeTable');
            this._deleteAllMappings('idBusinessAreaCodeTable');

            const aReasonCodeMappings = oRuleBook[0].getObject().reasonCodeMappings;
            const aBusinessAreaCodeMappings = oRuleBook[0].getObject().businessAreaCodeMappings;

            aReasonCodeMappings.forEach((oItem) => {
              this.onAddRowReasonCodeMapping(oItem);
            });

            aBusinessAreaCodeMappings.forEach((oItem) => {
              this.onAddRowBusinessAreaCodeMapping(oItem);
            });
          }
        } catch (oError) {
          MessageBox.error('Error importing rule book:', oError);
        }

        this._oImportRuleBookDialog.close();
      },

      onImportRuleBookCancelPress: function () {
        this._oImportRuleBookDialog.close();
      },

      onImportRuleBookAfterClose: function () {
        this._oImportRuleBookDialog.destroy();
      },

      onFilterBarSearch: function (oEvent) {
        let sSearchQuery = this._oBasicSearchField.getValue();
        let aSelectionSet = oEvent.getParameter('selectionSet');

        let aFilters = aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(
              new Filter({
                path: oControl.getName(),
                operator: FilterOperator.Contains,
                value1: oControl.getValue(),
                caseSensitive: false
              })
            );
          }
          return aResult;
        }, []);

        aFilters.push(
          new Filter({
            filters: [
              new Filter({ path: 'companyCode', operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false }),
              new Filter({ path: 'countryName', operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false }),
              new Filter({ path: 'hasRuleBook', operator: FilterOperator.Contains, value1: sSearchQuery, caseSensitive: false })
            ],
            and: false
          })
        );

        this._filterTable(
          new Filter({
            filters: aFilters,
            and: true
          })
        );
      },

      _filterTable: function (oFilter) {
        let oTable = this.getView().byId('idCompanySelectionTable');
        oTable.getBinding('items').filter(oFilter);
      },

      formatHasRuleBook: function (hasRuleBook) {
        return hasRuleBook === 'Yes' ? 'Success' : 'Error';
      },

      formatDate: function (sDate) {
        if (!sDate) return '';

        const oDateFormat = DateFormat.getDateTimeInstance({
          pattern: 'dd/MM/yyyy hh:mm a'
        });

        return oDateFormat.format(new Date(sDate));
      },

      onEdit: async function () {
        const oObjectPage = this.getView().byId('companySelectionObjectPageLayout');
        const oSelectedCompany = this.oViewModel.getProperty('/selectedCompany');

        try {
          const aRuleBookContext = await this._getRuleBookByCompanyID(oSelectedCompany.ID, true);
          if (aRuleBookContext && aRuleBookContext.length > 0) {
            oObjectPage.setBindingContext(aRuleBookContext[0]);
          } else {
            MessageBox.error('No rulebook found for the selected company.');
            return;
          }
        } catch (oError) {
          MessageBox.error('Error fetching the latest rulebook data: ' + oError.message);
          return;
        }

        const oActiveContext = oObjectPage.getBindingContext();
        const oDraftAdministrativeData = oActiveContext?.getObject()?.DraftAdministrativeData;

        if (oDraftAdministrativeData) {
          if (oDraftAdministrativeData.InProcessByUser) {
            const sLastModifiedAt = oDraftAdministrativeData.LastChangeDateTime;
            MessageBox.alert('Draft is progress by another user. Please try again later.\n Last Modified At: ' + this.formatDate(sLastModifiedAt));
            return;
          }
          MessageBox.confirm('This action will delete the already created draft. Are you sure you want to proceed?', {
            title: 'Edit Rulebook',
            onClose: (sAction) => {
              if (sAction === MessageBox.Action.OK) {
                this._createDraftEntity(oObjectPage, oActiveContext);
              }
            }
          });
        } else {
          this._createDraftEntity(oObjectPage, oActiveContext);
        }
        await this.setLLMModelSelectionItems();
        this._setMappingsTableMode('idReasonCodeTable', 'Delete');
        this._setMappingsTableMode('idBusinessAreaCodeTable', 'Delete');
      },

      _createDraftEntity: function (oObjectPage, oActiveContext) {
        return oActiveContext
          .getModel()
          .bindContext('RuleOrchestratorService.draftEdit(...)', oActiveContext, { $$inheritExpandSelect: true })
          .invoke('$auto', false, null, true)
          .then(function (oDraftContext) {
            oObjectPage.setBindingContext(oDraftContext);
          });
      },

      onSave: async function () {
        const bReasonCodePromptValid = this._validateTextField('reasonCodeMappingPrompt');
        const bBusinessAreaCodePromptValid = this._validateTextField('businessAreaCodeMappingPrompt');
        const bReasonCodeValid = this._validateTableInputMappings('idReasonCodeTable', ['reasonCode', 'keywords']);
        const bBusinessAreaCodeValid = this._validateTableInputMappings('idBusinessAreaCodeTable', ['businessAreaCode', 'keywords']);
        if (!bReasonCodeValid || !bBusinessAreaCodeValid || !bReasonCodePromptValid || !bBusinessAreaCodePromptValid) {
          MessageBox.error('Please fill all mandatory fields before saving.');
          return;
        }

        let oObjectPage = this.getView().byId('companySelectionObjectPageLayout'),
          oContext = oObjectPage.getBindingContext();

        await this.oModel.submitBatch('$auto');

        oContext
          .getModel()
          .bindContext('RuleOrchestratorService.draftActivate(...)', oContext, { $$inheritExpandSelect: true })
          .invoke('$auto', false, null, true)
          .then(function (oContext) {
            oObjectPage.setBindingContext(oContext);
          });

        this._setMappingsTableMode('idReasonCodeTable', 'None');
        this._setMappingsTableMode('idBusinessAreaCodeTable', 'None');
      },

      _validateTableInputMappings: function (sTableId, aFields) {
        let oTable = this.getView().byId(sTableId);
        let aItems = oTable.getItems();
        let bValid = true;

        aItems.forEach((oItem) => {
          const cells = oItem.getCells();
          aFields.forEach((field, index) => {
            const value = cells[index].getValue();
            const state = value ? 'None' : 'Error';
            cells[index].setValueState(state);
            cells[index].setValueStateText('Required value missing');
            if (!value) bValid = false;
          });
        });
        return bValid;
      },

      _validateTextField: function (oTextFieldId) {
        let oTextField = this.getView().byId(oTextFieldId);
        let bValid = true;

        const value = oTextField.getValue();
        const state = value ? 'None' : 'Error';
        oTextField.setValueState(state);
        oTextField.setValueStateText('Required value missing');
        if (!value) bValid = false;
        return bValid;
      },

      onCancel: async function () {
        let oObjectPage = this.getView().byId('companySelectionObjectPageLayout'),
          oDraftContext = oObjectPage.getBindingContext();

        oDraftContext.delete('$auto', /*bDoNotRequestCount*/ true).catch(function (oError) {
          if (!oError.canceled) {
            MessageBox.error('Error deleting draft entity:', oError);
          }
        });
        try {
          const oRuleBookActiveContext = await this._getRuleBookByCompanyID(this.oViewModel.getProperty('/selectedCompany').ID, true);
          oObjectPage.setBindingContext(oRuleBookActiveContext[0]);
        } catch (oError) {
          MessageBox.error('Error fetching rule book:', oError);
        }

        this._setMappingsTableMode('idReasonCodeTable', 'None');
        this._setMappingsTableMode('idBusinessAreaCodeTable', 'None');
      },

      onAddRowReasonCodeMapping: function (oItem = { reasonCode: null, keywords: null, IsActiveEntity: false }) {
        let oReasonCodeMappingsTable = this.getView().byId('idReasonCodeTable').getBinding('items');
        oReasonCodeMappingsTable
          .create(
            {
              reasonCode: oItem.reasonCode,
              keywords: oItem.keywords,
              IsActiveEntity: oItem.IsActiveEntity
            },
            undefined,
            true
          )
          .created()
          .catch(function (oError) {
            if (!oError.canceled) {
              MessageBox.error('Error creating reason code mapping:', oError);
            }
          });
      },

      onAddRowBusinessAreaCodeMapping: function (oItem = { businessAreaCode: null, keywords: null, IsActiveEntity: false }) {
        let oBusinessAreaCodeMappingsTable = this.getView().byId('idBusinessAreaCodeTable').getBinding('items');

        oBusinessAreaCodeMappingsTable
          .create(
            {
              businessAreaCode: oItem.businessAreaCode,
              keywords: oItem.keywords,
              IsActiveEntity: oItem.IsActiveEntity
            },
            undefined,
            true
          )
          .created()
          .catch(function (oError) {
            if (!oError.canceled) {
              MessageBox.error('Error creating business area code mapping:', oError);
            }
          });
      },

      onDeleteRowReasonCodeMapping: function (oEvent) {
        const oReasonCodeToDelete = oEvent.getParameters().listItem.getBindingContext();
        oReasonCodeToDelete.delete().catch(function (oError) {
          if (!oError.canceled) {
            MessageBox.error('Error deleting reason code mapping:', oError);
          }
        });
      },

      onDeleteRowBusinessAreaCodeMapping: function (oEvent) {
        const oBusinessAreaCodeToDelete = oEvent.getParameters().listItem.getBindingContext();
        oBusinessAreaCodeToDelete.delete().catch(function (oError) {
          if (!oError.canceled) {
            MessageBox.error('Error deleting business area code mapping:', oError);
          }
        });
      },

      _setMappingsTableMode: function (sTableId, sMode) {
        const oTable = this.byId(sTableId);
        if (oTable) {
          return oTable.setMode(sMode);
        }
      },

      setLLMModelSelectionItems: async function () {
        try {
          const aLLMModels = await this._getLLMModels();
          const aLLMObjectList = aLLMModels.map((item) => ({ name: item }));

          const sModelSelectionField = this.getView().byId('sModelSelection');
          sModelSelectionField.destroyItems();

          aLLMObjectList.forEach((item) => {
            sModelSelectionField.addItem(new sap.ui.core.Item({ key: item.name, text: item.name }));
          });
        } catch (oError) {
          MessageBox.error('Error setting the LLM models:', oError);
        }
      },

      _getLLMModels: async function () {
        const oModel = this.getView().getModel();
        const oAction = oModel.bindContext('/getLLMModels(...)');

        await oAction.execute();
        return oAction.getBoundContext().getObject().models;
      }
    });
  }
);
