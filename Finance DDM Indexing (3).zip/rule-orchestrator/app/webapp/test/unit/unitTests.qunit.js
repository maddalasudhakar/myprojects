/* global QUnit */
// https://api.qunitjs.com/config/autostart/
QUnit.config.autostart = false;
sap.ui.require(['ruleorchestratorui/test/unit/AllTests'], function () {
  'use strict';
  QUnit.start();
});
