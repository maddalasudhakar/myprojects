sap.ui.define(['ruleorchestratorui/test/unit/controller/RuleOrchestrator.controller'], function () {
  'use strict';
});
