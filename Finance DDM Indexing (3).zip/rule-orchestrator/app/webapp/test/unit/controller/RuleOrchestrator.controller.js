sap.ui.define(
  [
    'ruleorchestratorui/controller/RuleOrchestrator.controller',
    'sap/ui/model/odata/v4/ODataModel',
    'sap/ui/model/json/JSONModel',
    'sap/m/MessageBox',
    'sap/ui/thirdparty/sinon'
  ],
  function (Controller, ODataModel, JSONModel, MessageBox, sinon) {
    ('use strict');

    QUnit.module('RuleOrchestrator Controller', {
      beforeEach: function () {
        // Instantiate the controller
        this.oController = new Controller();

        // Stub view and its controls
        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub(),
          addDependent: sinon.stub()
        };

        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
        sinon.stub(this.oController, 'getOwnerComponent').returns({ getModel: sinon.stub() });
        this.oController.byId = this.oViewStub.byId;
      },
      afterEach: function () {
        try {
          MessageBox.error.restore();
        } catch (e) {}
        sinon.restore();
      }
    });

    QUnit.test('onInit sets up ODataModel and JSONModel correctly', function (assert) {
      const oODataModelStub = {
        attachDataReceived: sinon.stub()
      };
      this.oController.getOwnerComponent().getModel.returns(oODataModelStub);

      this.oController.onInit();

      assert.ok(this.oViewStub.setModel.calledWith(oODataModelStub), 'ODataModel was set on the view');
      assert.ok(oODataModelStub.attachDataReceived.calledOnce, 'attachDataReceived was called on the ODataModel');
      assert.ok(
        this.oViewStub.setModel.calledWithMatch(sinon.match.instanceOf(JSONModel), 'viewModel'),
        'JSONModel for viewModel was set on the view'
      );
    });

    QUnit.test('onInit shows error when dataReceived event has error', function (assert) {
      // Arrange
      const oODataModelStub = {
        attachDataReceived: sinon.stub()
      };
      this.oController.getOwnerComponent().getModel.returns(oODataModelStub);
      sinon.stub(MessageBox, 'error');

      // Act
      this.oController.onInit();

      // Simulate dataReceived event with error
      const dataReceivedHandler = oODataModelStub.attachDataReceived.getCall(0).args[0];
      // The handler is called with a function, so we need to call it with an event mock
      const oEventMock = {
        getParameters: function () {
          return { error: true };
        }
      };
      dataReceivedHandler(oEventMock);

      // Assert
      assert.ok(MessageBox.error.calledWith('An error occurred while communicating with the service'), 'Error message shown on dataReceived error');
    });

    QUnit.test('onTableDataReceived sets table header text with item count', function (assert) {
      // Arrange
      const i18nStub = {
        getResourceBundle: sinon.stub().returns({
          getText: sinon.stub().withArgs('valueHelpDialog.tableTitle', [5]).returns('Table Title (5)')
        })
      };
      const oTableStub = {
        getBinding: sinon
          .stub()
          .withArgs('items')
          .returns({ getCount: sinon.stub().returns(5) }),
        setHeaderText: sinon.stub()
      };
      this.oViewStub.getModel.withArgs('i18n').returns(i18nStub);
      this.oViewStub.byId.withArgs('idCompanySelectionTable').returns(oTableStub);

      // Act
      this.oController.onTableDataReceived();

      // Assert
      assert.ok(i18nStub.getResourceBundle.calledOnce, 'Resource bundle retrieved');
      assert.ok(oTableStub.getBinding.calledWith('items'), 'Table binding for items retrieved');
      assert.ok(oTableStub.setHeaderText.calledWith('Table Title (5)'), 'Header text set with correct item count');
    });

    QUnit.test('formatHasRuleBook()', function (assert) {
      assert.strictEqual(this.oController.formatHasRuleBook('Yes'), 'Success', 'Success');
      assert.strictEqual(this.oController.formatHasRuleBook('No'), 'Error', 'Error');
    });

    QUnit.test('formatDate()', function (assert) {
      assert.strictEqual(this.oController.formatDate('Apr 17, 2025, 2:46:53 PM'), '17/04/2025 02:46 PM', 'Valid date string is formatted correctly');
      assert.strictEqual(this.oController.formatDate('Invalid Date'), '', 'Invalid date yields empty string');
      assert.strictEqual(this.oController.formatDate(''), '', 'Empty input yields empty string');
    });

    QUnit.test('_validateTextField sets Error state and returns false when empty, None and returns true when filled', function (assert) {
      // Empty field
      const oEmptyField = {
        getValue: sinon.stub().returns(''),
        setValueState: sinon.stub(),
        setValueStateText: sinon.stub()
      };
      this.oViewStub.byId.withArgs('myField').returns(oEmptyField);
      const bEmptyValid = this.oController._validateTextField('myField');
      assert.notOk(bEmptyValid, 'Validation fails when value is empty');
      assert.ok(oEmptyField.setValueState.calledWith('Error'), 'Error state set on empty field');

      // Filled field
      const oFilledField = {
        getValue: sinon.stub().returns('value'),
        setValueState: sinon.stub(),
        setValueStateText: sinon.stub()
      };
      this.oViewStub.byId.withArgs('filledField').returns(oFilledField);
      const bFilledValid = this.oController._validateTextField('filledField');
      assert.ok(bFilledValid, 'Validation passes when value is present');
      assert.ok(oFilledField.setValueState.calledWith('None'), 'None state set on filled field');
    });

    QUnit.test('_validateTableInputMappings sets Error state on missing cell values and returns correct boolean', function (assert) {
      const oCellValid = { getValue: sinon.stub().returns('text'), setValueState: sinon.stub(), setValueStateText: sinon.stub() };
      const oCellInvalid = { getValue: sinon.stub().returns(''), setValueState: sinon.stub(), setValueStateText: sinon.stub() };
      // Two rows: first valid, second invalid
      const oItem1 = { getCells: sinon.stub().returns([oCellValid, oCellValid]) };
      const oItem2 = { getCells: sinon.stub().returns([oCellInvalid, oCellValid]) };
      const oTableStub = { getItems: sinon.stub().returns([oItem1, oItem2]) };
      this.oViewStub.byId.withArgs('idReasonCodeTable').returns({ getItems: oTableStub.getItems });

      const bValid = this.oController._validateTableInputMappings('idReasonCodeTable', ['field1', 'field2']);
      assert.notOk(bValid, 'Validation fails when any cell value is empty');
      assert.ok(oCellInvalid.setValueState.calledWith('Error'), 'Error state set on empty cell');
      assert.ok(oCellValid.setValueState.calledWith('None'), 'None state set on non-empty cell');
    });

    QUnit.test('onValueHelpRequested loads and opens Value Help Dialog', function (assert) {
      const done = assert.async();

      // Arrange
      const oDialogStub = { open: sinon.stub() };
      const oFilterBarStub = { setBasicSearch: sinon.stub() };
      const oSearchFieldStub = { attachSearch: sinon.stub().returns({ search: sinon.stub() }) };
      const oAddDependentStub = sinon.stub();

      // Stub SearchField constructor
      const SearchFieldStub = sinon.stub().returns(oSearchFieldStub);
      this.oController._oBasicSearchField = null; // Ensure clean state

      // Stub loadFragment to resolve with dialog stub
      sinon.stub(this.oController, 'loadFragment').returns(Promise.resolve(oDialogStub));
      // Stub getView and byId
      this.oViewStub.byId.withArgs('fbSelectCompany').returns(oFilterBarStub);
      this.oViewStub.addDependent = oAddDependentStub;

      // Act
      this.oController.onValueHelpRequested();

      // Assert after promise resolves
      setTimeout(() => {
        assert.strictEqual(this.oController._oVHD, oDialogStub, 'Dialog assigned to _oVHD');
        assert.ok(oAddDependentStub.calledWith(oDialogStub), 'Dialog added as dependent');
        assert.ok(oFilterBarStub.setBasicSearch.called, 'Basic search set on filter bar');
        assert.ok(oDialogStub.open.calledOnce, 'Dialog opened');
        done();
      }, 0);
    });

    QUnit.test('onSelectionChange triggers filter bar search', function (assert) {
      const oFilterBarStub = { search: sinon.stub() };
      this.oViewStub.byId.withArgs('fbSelectCompany').returns(oFilterBarStub);

      this.oController.onSelectionChange();

      assert.ok(oFilterBarStub.search.calledOnce, 'Filter bar search triggered');
    });

    QUnit.test('_deleteAllMappings deletes all item contexts and shows error on failure', async function (assert) {
      // Arrange
      const oError = new Error('Delete failed');
      oError.canceled = false;

      // Two items: one deletes successfully, one fails
      const oContextSuccess = { delete: sinon.stub().returns(Promise.resolve()) };
      const oContextFail = { delete: sinon.stub().returns(Promise.reject(oError)) };

      const oItemSuccess = { getBindingContext: sinon.stub().returns(oContextSuccess) };
      const oItemFail = { getBindingContext: sinon.stub().returns(oContextFail) };
      const oTableStub = { getItems: sinon.stub().returns([oItemSuccess, oItemFail]) };

      this.oController.byId = sinon.stub().withArgs('idTestTable').returns(oTableStub);
      sinon.stub(MessageBox, 'error');

      // Act
      this.oController._deleteAllMappings('idTestTable');

      // Await all delete promises
      await Promise.resolve(); // allow microtasks to run

      // Assert
      assert.ok(oContextSuccess.delete.calledOnce, 'Delete called on first context');
      assert.ok(oContextFail.delete.calledOnce, 'Delete called on second context');
      assert.ok(MessageBox.error.calledWith('Error deleting all mappings:', oError), 'Error message shown for failed deletion');
    });

    QUnit.test('onRestoreDefaultRuleBook restores default rule book and sets properties', async function (assert) {
      // Arrange
      const oSetPropertyStub = sinon.stub();
      const oBindingContextStub = {
        setProperty: oSetPropertyStub
      };
      const oObjectPageStub = {
        getBindingContext: sinon.stub().returns(oBindingContextStub)
      };
      this.oController.byId = sinon.stub().withArgs('companySelectionObjectPageLayout').returns(oObjectPageStub);

      // Stub _deleteAllMappings
      sinon.stub(this.oController, '_deleteAllMappings');

      // Stub _getDefaultRuleBook to resolve with a mock rulebook
      const oDefaultRuleBook = {
        getObject: () => ({
          llmName: 'LLM',
          reasonCodeMappingPrompt: 'Prompt1',
          businessAreaCodeMappingPrompt: 'Prompt2',
          additionalInfo: 'Info'
        })
      };
      sinon.stub(this.oController, '_getDefaultRuleBook').returns(Promise.resolve(oDefaultRuleBook));

      // Act
      await this.oController.onRestoreDefaultRuleBook();

      // Assert
      assert.ok(this.oController._deleteAllMappings.calledWith('idReasonCodeTable'), 'Reason code mappings deleted');
      assert.ok(this.oController._deleteAllMappings.calledWith('idBusinessAreaCodeTable'), 'Business area code mappings deleted');
      assert.ok(oSetPropertyStub.calledWith('llmName', 'LLM'), 'llmName property set');
      assert.ok(oSetPropertyStub.calledWith('reasonCodeMappingPrompt', 'Prompt1'), 'reasonCodeMappingPrompt property set');
      assert.ok(oSetPropertyStub.calledWith('businessAreaCodeMappingPrompt', 'Prompt2'), 'businessAreaCodeMappingPrompt property set');
      assert.ok(oSetPropertyStub.calledWith('additionalInfo', 'Info'), 'additionalInfo property set');
    });

    QUnit.test('onRestoreDefaultRuleBook shows error when _getDefaultRuleBook fails', async function (assert) {
      // Arrange
      const oObjectPageStub = {
        getBindingContext: sinon.stub().returns({ setProperty: sinon.stub() })
      };
      this.oController.byId = sinon.stub().withArgs('companySelectionObjectPageLayout').returns(oObjectPageStub);
      sinon.stub(this.oController, '_deleteAllMappings');
      const error = new Error('fail');
      sinon.stub(this.oController, '_getDefaultRuleBook').returns(Promise.reject(error));
      sinon.stub(MessageBox, 'error');

      // Act
      await this.oController.onRestoreDefaultRuleBook();

      // Assert
      assert.ok(MessageBox.error.calledWith('Error restoring the default rule book:', error), 'Error message shown');
    });

    QUnit.test('onImportRuleBook loads and opens Import Rulebook Dialog', function (assert) {
      const done = assert.async();

      // Arrange
      const oDialogStub = { open: sinon.stub() };
      const oAddDependentStub = sinon.stub();
      sinon.stub(this.oController, 'loadFragment').returns(Promise.resolve(oDialogStub));
      this.oViewStub.addDependent = oAddDependentStub;

      // Act
      this.oController.onImportRuleBook();

      setTimeout(() => {
        assert.strictEqual(this.oController._oImportRuleBookDialog, oDialogStub, 'Dialog assigned to _oImportRuleBookDialog');
        assert.ok(oAddDependentStub.calledWith(oDialogStub), 'Dialog added as dependent');
        assert.ok(oDialogStub.open.calledOnce, 'Dialog opened');
        done();
      }, 0);
    });

    QUnit.test('onRuleBookToImportPress shows error if no company selected', async function (assert) {
      // Arrange
      const oObjectPageStub = { getBindingContext: sinon.stub().returns({ setProperty: sinon.stub() }) };
      this.oController.byId = sinon.stub().withArgs('companySelectionObjectPageLayout').returns(oObjectPageStub);
      const cbStub = { getSelectedKey: sinon.stub().returns('') };
      this.oViewStub.byId.withArgs('cbCompanyCodeToImport').returns(cbStub);
      sinon.stub(MessageBox, 'error');

      // Act
      await this.oController.onRuleBookToImportPress();

      // Assert
      assert.ok(MessageBox.error.calledWith('Please select a company to import the rulebook.'), 'Error shown when no company selected');
    });

    QUnit.test('onRuleBookToImportPress imports rulebook and sets properties', async function (assert) {
      // Arrange
      const oSetPropertyStub = sinon.stub();
      const oBindingContextStub = { setProperty: oSetPropertyStub };
      const oObjectPageStub = { getBindingContext: sinon.stub().returns(oBindingContextStub) };
      this.oController.byId = sinon.stub().withArgs('companySelectionObjectPageLayout').returns(oObjectPageStub);

      const cbStub = { getSelectedKey: sinon.stub().returns('C1') };
      this.oViewStub.byId.withArgs('cbCompanyCodeToImport').returns(cbStub);

      const oRuleBookData = {
        llmName: 'LLM',
        reasonCodeMappingPrompt: 'Prompt1',
        businessAreaCodeMappingPrompt: 'Prompt2',
        additionalInfo: 'Info',
        reasonCodeMappings: [{ id: 1 }],
        businessAreaCodeMappings: [{ id: 2 }]
      };
      const oRuleBookStub = [{ getObject: sinon.stub().returns(oRuleBookData) }];
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.resolve(oRuleBookStub));
      sinon.stub(this.oController, '_deleteAllMappings');
      sinon.stub(this.oController, 'onAddRowReasonCodeMapping');
      sinon.stub(this.oController, 'onAddRowBusinessAreaCodeMapping');
      this.oController._oImportRuleBookDialog = { close: sinon.stub() };

      // Act
      await this.oController.onRuleBookToImportPress();

      // Assert
      assert.ok(oSetPropertyStub.calledWith('llmName', 'LLM'), 'llmName property set');
      assert.ok(oSetPropertyStub.calledWith('reasonCodeMappingPrompt', 'Prompt1'), 'reasonCodeMappingPrompt property set');
      assert.ok(oSetPropertyStub.calledWith('businessAreaCodeMappingPrompt', 'Prompt2'), 'businessAreaCodeMappingPrompt property set');
      assert.ok(oSetPropertyStub.calledWith('additionalInfo', 'Info'), 'additionalInfo property set');
      assert.ok(this.oController._deleteAllMappings.calledWith('idReasonCodeTable'), 'Reason code mappings deleted');
      assert.ok(this.oController._deleteAllMappings.calledWith('idBusinessAreaCodeTable'), 'Business area code mappings deleted');
      assert.ok(this.oController.onAddRowReasonCodeMapping.calledWith({ id: 1 }), 'Reason code mapping row added');
      assert.ok(this.oController.onAddRowBusinessAreaCodeMapping.calledWith({ id: 2 }), 'Business area code mapping row added');
      assert.ok(this.oController._oImportRuleBookDialog.close.calledOnce, 'Dialog closed');
    });

    QUnit.test('onRuleBookToImportPress shows error when import fails', async function (assert) {
      // Arrange
      const oObjectPageStub = { getBindingContext: sinon.stub().returns({ setProperty: sinon.stub() }) };
      this.oController.byId = sinon.stub().withArgs('companySelectionObjectPageLayout').returns(oObjectPageStub);
      const cbStub = { getSelectedKey: sinon.stub().returns('C1') };
      this.oViewStub.byId.withArgs('cbCompanyCodeToImport').returns(cbStub);
      const error = new Error('fail');
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.reject(error));
      sinon.stub(MessageBox, 'error');
      this.oController._oImportRuleBookDialog = { close: sinon.stub() };

      // Act
      await this.oController.onRuleBookToImportPress();

      // Assert
      assert.ok(MessageBox.error.calledWith('Error importing rule book:', error), 'Error message shown on import failure');
      assert.ok(this.oController._oImportRuleBookDialog.close.calledOnce, 'Dialog closed');
    });

    QUnit.module('RuleOrchestrator Controller - OData interactions', {
      beforeEach: function () {
        // Instantiate controller and stub view
        this.oController = new Controller();
        this.oViewStub = {
          setModel: sinon.stub(),
          getModel: sinon.stub(),
          byId: sinon.stub(),
          addDependent: sinon.stub()
        };
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);

        // Stub OData model
        this.oModelStub = {
          bindContext: sinon.stub(),
          bindList: sinon.stub()
        };
        this.oController.oModel = this.oModelStub;
      },
      afterEach: function () {
        // Restore all sinon stubs
        try {
          MessageBox.error.restore();
        } catch (e) {}
        try {
          MessageBox.alert.restore();
        } catch (e) {}
        sinon.restore();
      }
    });

    QUnit.test('_getDefaultRuleBook resolves context on successful execute', function (assert) {
      const done = assert.async();
      // Stub action with execute returning a real promise
      const oActionStub = {
        execute: sinon.stub().returns(Promise.resolve()),
        getBoundContext: sinon.stub().returns({
          getObject: function () {
            return { default: true };
          }
        })
      };
      this.oModelStub.bindContext.withArgs('/getDefaultRuleBook(...)').returns(oActionStub);
      // Model retrieval
      this.oViewStub.getModel.returns(this.oModelStub);

      // Invoke
      this.oController._getDefaultRuleBook().then(function (context) {
        assert.equal(context.getObject().default, true, 'Default rule book context returned');
        done();
      });
    });

    QUnit.test('_getDefaultRuleBook shows error on failure', function (assert) {
      const done = assert.async();
      const error = new Error('fail');
      const oActionStub = {
        execute: sinon.stub().returns(Promise.reject(error))
      };
      this.oModelStub.bindContext.returns(oActionStub);
      this.oViewStub.getModel.returns(this.oModelStub);
      sinon.stub(MessageBox, 'error');

      this.oController._getDefaultRuleBook().then(function () {
        assert.ok(MessageBox.error.calledWith('Error fetching default rule book:', error), 'Error shown on default rule book failure');
        done();
      });
    });

    QUnit.test('_getRuleBookByCompanyID resolves contexts on successful requestContexts', function (assert) {
      const done = assert.async();
      const contexts = [{ getObject: () => ({ ID: '123' }) }];
      const oBindingStub = { requestContexts: sinon.stub().returns(Promise.resolve(contexts)) };
      this.oModelStub.bindList.withArgs('/RuleBooks', undefined, [], sinon.match.array, sinon.match.object).returns(oBindingStub);

      this.oController._getRuleBookByCompanyID('123').then(function (result) {
        assert.deepEqual(result, contexts, 'Contexts array returned');
        done();
      });
    });

    QUnit.test('_getRuleBookByCompanyID shows error on requestContexts failure', function (assert) {
      const done = assert.async();
      const error = new Error('rc fail');
      const oBindingStub = {
        requestContexts: sinon.stub().returns(Promise.reject(error))
      };
      this.oModelStub.bindList.returns(oBindingStub);
      try {
        MessageBox.error.restore();
      } catch (e) {}
      sinon.stub(MessageBox, 'error');

      this.oController._getRuleBookByCompanyID('999').then(function () {
        assert.ok(MessageBox.error.calledWith('Error fetching rule book:', error), 'Error shown on rule book failure');
        done();
      });
    });

    QUnit.test('onValueHelpOKPress shows error when no company selected', function (assert) {
      const oTableStub = { getSelectedItems: sinon.stub().returns([]) };
      this.oViewStub.byId.withArgs('idCompanySelectionTable').returns(oTableStub);
      sinon.stub(MessageBox, 'error');

      this.oController.onValueHelpOKPress();
      assert.ok(MessageBox.error.calledWith('Please select one company to proceed.'), 'Error shown when no company selected');
    });

    QUnit.test('onValueHelpOKPress closes dialog after processing', function (assert) {
      const done = assert.async();

      const oItemContext = { getObject: sinon.stub().returns({ ID: '42' }) };
      const oItem = { getBindingContext: sinon.stub().returns(oItemContext) };
      const oTableStub = { getSelectedItems: sinon.stub().returns([oItem]) };
      this.oViewStub.byId.withArgs('idCompanySelectionTable').returns(oTableStub);
      // Stub viewModel
      const oViewModelStub = { setProperty: sinon.stub().returns() };
      this.oController.oViewModel = oViewModelStub;
      // Stub value help dialog
      this.oController._oVHD = { close: sinon.stub() };
      // Force default branch: no existing rulebooks
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.resolve([]));
      sinon.stub(this.oController, '_getDefaultRuleBook').returns(Promise.resolve({ getObject: () => ({ A: 1 }) }));
      // Stub bindList and create
      const createPromise = { created: sinon.stub().returns(Promise.resolve()) };
      const oListBindingStub = { create: sinon.stub().returns(createPromise) };
      this.oController.oModel.bindList.returns(oListBindingStub);
      // Stub object page
      const oPageStub = { setBusy: sinon.stub(), setBindingContext: sinon.stub() };
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(oPageStub);

      this.oController.onValueHelpOKPress().then(
        function () {
          assert.ok(createPromise.created.calledOnce, 'New rulebook creation triggered');
          assert.ok(oPageStub.setBusy.calledTwice, 'Busy set before and after creation');
          assert.ok(oListBindingStub.create.calledOnce, 'BindList.create called');
          assert.ok(oPageStub.setBindingContext.calledOnce, 'Binding context updated after creation');
          assert.ok(oPageStub.setBusy.calledWith(false), 'Busy cleared');
          assert.ok(this.oController._oVHD.close.calledOnce, 'Dialog closed finally');
          done();
        }.bind(this)
      );
    });

    QUnit.test('onClickRestoreDefaultRuleBook invokes confirm and calls onRestoreDefaultRuleBook on OK', function (assert) {
      const originalConfirm = MessageBox.confirm;
      let onCloseCallback;
      // Override confirm directly
      MessageBox.confirm = function (message, options) {
        onCloseCallback = options.onClose;
      };
      sinon.stub(this.oController, 'onRestoreDefaultRuleBook');

      this.oController.onClickRestoreDefaultRuleBook();
      // Simulate user clicking OK
      onCloseCallback(MessageBox.Action.OK);
      assert.ok(this.oController.onRestoreDefaultRuleBook.calledOnce);
      // Restore confirm
      MessageBox.confirm = originalConfirm;
    });

    QUnit.module('RuleOrchestrator Controller - Edit, Save, Cancel flows', {
      beforeEach: function () {
        this.oController = new Controller();
        // Stub view and core methods
        this.oController.createId = function (s) {
          return s;
        };
        this.oViewStub = { byId: sinon.stub() };
        sinon.stub(this.oController, 'getView').returns(this.oViewStub);
      },
      afterEach: function () {
        try {
          MessageBox.alert.restore();
        } catch (e) {}
        try {
          MessageBox.confirm.restore();
        } catch (e) {}
        try {
          MessageBox.error.restore();
        } catch (e) {}
        sinon.restore();
      }
    });

    QUnit.test('onEdit shows alert when draft in process by another user', async function (assert) {
      // Stub object page and binding context with DraftAdministrativeData
      const draftData = { InProcessByUser: 'AdminUser', LastChangeDateTime: '2025-05-01T12:00:00Z' };
      const contextObj = { DraftAdministrativeData: draftData };
      const mockContext = {
        getObject: function () {
          return contextObj;
        }
      };
      const pageStub = { setBindingContext: sinon.stub(), getBindingContext: sinon.stub().returns(mockContext) };
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(pageStub);
      sinon.stub(MessageBox, 'alert');
      sinon.stub(this.oController, 'formatDate').returns('01/05/2025 12:00 PM');
      this.oController.oViewModel = new JSONModel({ selectedCompany: { ID: 'C1' } });
      // Stub _getRuleBookByCompanyID to resolve with our context
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.resolve([mockContext]));

      await this.oController.onEdit();
      assert.ok(MessageBox.alert.calledWithMatch('Draft is progress by another user'), 'Alert shown when draft in process');
      assert.ok(MessageBox.alert.calledWithMatch('01/05/2025 12:00 PM'), 'Last modified date included');
    });

    QUnit.test('onEdit creates draft when no existing draft', async function (assert) {
      // Stub page context without DraftAdministrativeData
      const contextObj = {
        getObject: function () {
          return {};
        }
      };
      const pageStub = {
        setBindingContext: sinon.stub(),
        getBindingContext: sinon.stub().returns(contextObj)
      };
      this.oController.oViewModel = new JSONModel({ selectedCompany: { ID: 'C1' } });
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(pageStub);

      // Stub _getRuleBookByCompanyID to resolve with our context
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.resolve([contextObj]));
      // Stub createDraftEntity
      sinon.stub(this.oController, '_createDraftEntity').returns(Promise.resolve());
      sinon.stub(this.oController, 'setLLMModelSelectionItems').returns(Promise.resolve());
      sinon.stub(this.oController, '_setMappingsTableMode');

      await this.oController.onEdit();
      assert.ok(this.oController._createDraftEntity.called, 'Draft entity creation invoked');
      assert.ok(this.oController.setLLMModelSelectionItems.calledOnce, 'LLM model items refreshed');
      assert.ok(this.oController._setMappingsTableMode.calledWith('idReasonCodeTable', 'Delete'));
      assert.ok(this.oController._setMappingsTableMode.calledWith('idBusinessAreaCodeTable', 'Delete'));
    });

    QUnit.test('onEdit shows error when fetching rulebook fails', async function (assert) {
      // Arrange
      const error = new Error('fetch failed');
      const pageStub = { setBindingContext: sinon.stub(), getBindingContext: sinon.stub().returns({}) };
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(pageStub);
      this.oController.oViewModel = new JSONModel({ selectedCompany: { ID: 'C1' } });
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.reject(error));
      sinon.stub(MessageBox, 'error');

      // Act
      await this.oController.onEdit();

      // Assert
      assert.ok(MessageBox.error.calledWith('Error fetching the latest rulebook data: ' + error.message), 'Error message shown when fetch fails');
    });

    QUnit.test('onSave shows error when validation fails', function (assert) {
      sinon.stub(this.oController, '_validateTextField').returns(false);
      sinon.stub(this.oController, '_validateTableInputMappings').returns(false);
      sinon.stub(MessageBox, 'error');

      this.oController.onSave();
      assert.ok(MessageBox.error.calledWith('Please fill all mandatory fields before saving.'), 'Validation error shown');
    });

    QUnit.test('onSave activates draft on valid input', async function (assert) {
      // Stub validations
      sinon.stub(this.oController, '_validateTextField').returns(true);
      sinon.stub(this.oController, '_validateTableInputMappings').returns(true);

      // Stub page and binding context
      const invokeStub = sinon.stub().returns(Promise.resolve({}));
      const bindStub = sinon.stub().returns({ invoke: invokeStub });
      const modelStub = { bindContext: bindStub };
      const contextStub = {
        getModel: function () {
          return modelStub;
        }
      };
      const pageStub = { getBindingContext: sinon.stub().returns(contextStub) };
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(pageStub);
      sinon.stub(this.oController, '_setMappingsTableMode');

      this.oController.oModel = { submitBatch: sinon.stub().returns(Promise.resolve()) };

      // Act
      await this.oController.onSave();

      // Assert
      assert.ok(bindStub.calledWith('RuleOrchestratorService.draftActivate(...)'), 'Activate action bound');
      assert.ok(invokeStub.called, 'Draft activation invoked');
      assert.ok(this.oController._setMappingsTableMode.calledWith('idReasonCodeTable', 'None'));
      assert.ok(this.oController._setMappingsTableMode.calledWith('idBusinessAreaCodeTable', 'None'));
    });

    QUnit.test('onCancel deletes draft and resets context', function (assert) {
      const done = assert.async();
      // Stub context.delete
      const deleteStub = sinon.stub().returns(Promise.resolve());
      const contextObj = { delete: deleteStub };
      const pageStub = { getBindingContext: sinon.stub().returns(contextObj) };
      this.oViewStub.byId.withArgs('companySelectionObjectPageLayout').returns(pageStub);
      // Stub viewModel selectedCompany
      const viewModel = new JSONModel({ selectedCompany: { ID: 'C1' } });
      this.oController.oViewModel = viewModel;
      // Stub getRuleBookByCompanyID
      const fetchedContexts = [
        {
          getObject: function () {
            return {};
          }
        }
      ];
      sinon.stub(this.oController, '_getRuleBookByCompanyID').returns(Promise.resolve(fetchedContexts));
      sinon.stub(this.oController, '_setMappingsTableMode');

      this.oController.onCancel().then(
        function () {
          assert.ok(deleteStub.called, 'Draft delete invoked');
          assert.ok(pageStub.getBindingContext, 'Binding context retrieved for reset');
          assert.ok(this.oController._setMappingsTableMode.calledWith('idReasonCodeTable', 'None'));
          assert.ok(this.oController._setMappingsTableMode.calledWith('idBusinessAreaCodeTable', 'None'));
          done();
        }.bind(this)
      );
    });

    QUnit.test('onValueHelpCancelPress closes the Value Help Dialog', function (assert) {
      this.oController._oVHD = { close: sinon.stub() };
      this.oController.onValueHelpCancelPress();
      assert.ok(this.oController._oVHD.close.calledOnce, 'Dialog closed');
    });

    QUnit.test('onValueHelpAfterClose destroys the Value Help Dialog', function (assert) {
      this.oController._oVHD = { destroy: sinon.stub() };
      this.oController.onValueHelpAfterClose();
      assert.ok(this.oController._oVHD.destroy.calledOnce, 'Dialog destroyed');
    });

    QUnit.test('onClickRestoreDefaultRuleBook confirms and invokes restore', function (assert) {
      const originalConfirm = MessageBox.confirm;
      let onCloseCallback;
      MessageBox.confirm = function (message, options) {
        onCloseCallback = options.onClose;
      };
      sinon.stub(this.oController, 'onRestoreDefaultRuleBook');

      this.oController.onClickRestoreDefaultRuleBook();
      onCloseCallback(MessageBox.Action.OK);

      assert.ok(this.oController.onRestoreDefaultRuleBook.calledOnce, 'Restore method invoked');
      MessageBox.confirm = originalConfirm;
    });

    QUnit.test('onImportRuleBookCancelPress closes the Import Rulebook Dialog', function (assert) {
      this.oController._oImportRuleBookDialog = { close: sinon.stub() };
      this.oController.onImportRuleBookCancelPress();
      assert.ok(this.oController._oImportRuleBookDialog.close.calledOnce, 'Dialog closed');
    });

    QUnit.test('onImportRuleBookAfterClose destroys the Import Rulebook Dialog', function (assert) {
      this.oController._oImportRuleBookDialog = { destroy: sinon.stub() };
      this.oController.onImportRuleBookAfterClose();
      assert.ok(this.oController._oImportRuleBookDialog.destroy.calledOnce, 'Dialog destroyed');
    });

    QUnit.test('onAddRowReasonCodeMapping adds a new row to the Reason Code table', function (assert) {
      const oBindingStub = { create: sinon.stub().returns({ created: sinon.stub().returns(Promise.resolve()) }) };
      const oTableStub = { getBinding: sinon.stub().returns(oBindingStub) };
      this.oViewStub.byId.withArgs('idReasonCodeTable').returns(oTableStub);

      this.oController.onAddRowReasonCodeMapping();

      assert.ok(oBindingStub.create.calledOnce, 'Row creation triggered');
    });

    QUnit.test('onAddRowBusinessAreaCodeMapping adds a new row to the Business Area Code table', function (assert) {
      const oBindingStub = { create: sinon.stub().returns({ created: sinon.stub().returns(Promise.resolve()) }) };
      const oTableStub = { getBinding: sinon.stub().returns(oBindingStub) };
      this.oViewStub.byId.withArgs('idBusinessAreaCodeTable').returns(oTableStub);

      this.oController.onAddRowBusinessAreaCodeMapping();

      assert.ok(oBindingStub.create.calledOnce, 'Row creation triggered');
    });

    QUnit.test('onDeleteRowReasonCodeMapping deletes a row from the Reason Code table', function (assert) {
      const oContextStub = { delete: sinon.stub().returns(Promise.resolve()) };
      const oEventStub = { getParameters: sinon.stub().returns({ listItem: { getBindingContext: sinon.stub().returns(oContextStub) } }) };

      this.oController.onDeleteRowReasonCodeMapping(oEventStub);

      assert.ok(oContextStub.delete.calledOnce, 'Row deletion triggered');
    });

    QUnit.test('onDeleteRowBusinessAreaCodeMapping deletes a row from the Business Area Code table', function (assert) {
      const oContextStub = { delete: sinon.stub().returns(Promise.resolve()) };
      const oEventStub = { getParameters: sinon.stub().returns({ listItem: { getBindingContext: sinon.stub().returns(oContextStub) } }) };

      this.oController.onDeleteRowBusinessAreaCodeMapping(oEventStub);

      assert.ok(oContextStub.delete.calledOnce, 'Row deletion triggered');
    });

    QUnit.test('setLLMModelSelectionItems populates model selection field', async function (assert) {
      const done = assert.async();
      sinon.stub(this.oController, '_getLLMModels').returns(Promise.resolve(['ModelA', 'ModelB']));
      const sFieldStub = { destroyItems: sinon.stub(), addItem: sinon.stub() };
      this.oViewStub.byId.withArgs('sModelSelection').returns(sFieldStub);

      await this.oController.setLLMModelSelectionItems();

      assert.ok(sFieldStub.destroyItems.calledOnce, 'Existing items destroyed');
      assert.equal(sFieldStub.addItem.callCount, 2, 'New items added');
      done();
    });

    QUnit.test('_getLLMModels fetches LLM models successfully', async function (assert) {
      const done = assert.async();

      // Mock ODataModel and bindContext
      const oActionStub = {
        execute: sinon.stub().returns(Promise.resolve()),
        getBoundContext: sinon.stub().returns({
          getObject: sinon.stub().returns({ models: ['ModelA', 'ModelB'] })
        })
      };
      const oMockODataModel = {
        bindContext: sinon.stub().returns(oActionStub)
      };

      // Stub getModel to return the mock ODataModel
      this.oViewStub.getModel = sinon.stub().returns(oMockODataModel);

      // Call _getLLMModels
      const aLLMModels = await this.oController._getLLMModels();

      // Assertions
      assert.ok(oActionStub.execute.calledOnce, 'Action execute called');
      assert.deepEqual(aLLMModels, ['ModelA', 'ModelB'], 'Correct models fetched');
      done();
    });

    QUnit.test('setLLMModelSelectionItems shows error when fetching LLM models fails', async function (assert) {
      const done = assert.async();
      const error = new Error('Error fetching LLM models');
      sinon.stub(this.oController, '_getLLMModels').returns(Promise.reject(error));
      sinon.stub(MessageBox, 'error');

      await this.oController.setLLMModelSelectionItems();

      assert.ok(this.oController._getLLMModels.calledOnce, '_getLLMModels called');
      assert.ok(MessageBox.error.calledWith('Error setting the LLM models:', error), 'Error message shown');
      done();
    });

    QUnit.test('onFilterBarSearch applies filters to the table', function (assert) {
      const oTableStub = { getBinding: sinon.stub().returns({ filter: sinon.stub() }) };
      this.oViewStub.byId.withArgs('idCompanySelectionTable').returns(oTableStub);
      this.oController._oBasicSearchField = { getValue: sinon.stub().returns('searchQuery') };

      const oEventStub = {
        getParameter: sinon.stub().returns([
          { getValue: sinon.stub().returns('value1'), getName: sinon.stub().returns('field1') },
          { getValue: sinon.stub().returns(''), getName: sinon.stub().returns('field2') }
        ])
      };

      this.oController.onFilterBarSearch(oEventStub);

      assert.ok(oTableStub.getBinding().filter.calledOnce, 'Filters applied to the table');
    });

    QUnit.test('onDeleteRowBusinessAreaCodeMapping shows error when deletion fails', function (assert) {
      const done = assert.async(); // Ensure async handling
      const oError = new Error('Deletion failed');
      const oContextStub = { delete: sinon.stub().returns(Promise.reject(oError)) };
      const oEventStub = { getParameters: sinon.stub().returns({ listItem: { getBindingContext: sinon.stub().returns(oContextStub) } }) };
      sinon.stub(MessageBox, 'error');

      this.oController.onDeleteRowBusinessAreaCodeMapping(oEventStub);

      // Wait for the promise to resolve
      setTimeout(() => {
        assert.ok(oContextStub.delete.calledOnce, 'Delete method called');
        assert.ok(MessageBox.error.calledWith('Error deleting business area code mapping:', oError), 'Error message shown');
        done();
      }, 0);
    });

    QUnit.test('onDeleteRowReasonCodeMapping shows error when deletion fails', function (assert) {
      const done = assert.async(); // Ensure async handling
      const oError = new Error('Deletion failed');
      const oContextStub = { delete: sinon.stub().returns(Promise.reject(oError)) };
      const oEventStub = { getParameters: sinon.stub().returns({ listItem: { getBindingContext: sinon.stub().returns(oContextStub) } }) };
      sinon.stub(MessageBox, 'error');

      this.oController.onDeleteRowReasonCodeMapping(oEventStub);

      // Wait for the promise to resolve
      setTimeout(() => {
        assert.ok(oContextStub.delete.calledOnce, 'Delete method called');
        assert.ok(MessageBox.error.calledWith('Error deleting reason code mapping:', oError), 'Error message shown');
        done();
      }, 0);
    });

    QUnit.test('onAddRowBusinessAreaCodeMapping shows error when creation fails', function (assert) {
      const done = assert.async(); // Ensure async handling
      const oError = new Error('Creation failed');
      const oBindingStub = { create: sinon.stub().returns({ created: sinon.stub().returns(Promise.reject(oError)) }) };
      const oTableStub = { getBinding: sinon.stub().returns(oBindingStub) };
      this.oViewStub.byId.withArgs('idBusinessAreaCodeTable').returns(oTableStub);
      sinon.stub(MessageBox, 'error');

      this.oController.onAddRowBusinessAreaCodeMapping();

      // Wait for the promise to resolve
      setTimeout(() => {
        assert.ok(oBindingStub.create.calledOnce, 'Create method called');
        assert.ok(MessageBox.error.calledWith('Error creating business area code mapping:', oError), 'Error message shown');
        done();
      }, 0);
    });

    QUnit.test('onAddRowReasonCodeMapping shows error when creation fails', function (assert) {
      const done = assert.async(); // Ensure async handling
      const oError = new Error('Creation failed');
      const oBindingStub = { create: sinon.stub().returns({ created: sinon.stub().returns(Promise.reject(oError)) }) };
      const oTableStub = { getBinding: sinon.stub().returns(oBindingStub) };
      this.oViewStub.byId.withArgs('idReasonCodeTable').returns(oTableStub);
      sinon.stub(MessageBox, 'error');

      this.oController.onAddRowReasonCodeMapping();

      // Wait for the promise to resolve
      setTimeout(() => {
        assert.ok(oBindingStub.create.calledOnce, 'Create method called');
        assert.ok(MessageBox.error.calledWith('Error creating reason code mapping:', oError), 'Error message shown');
        done();
      }, 0);
    });
  }
);
