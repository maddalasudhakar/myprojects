# Rule-orchestrator service
It's responsible for creating and updating rule books for different companies from the list of available companies.

## ODATA services exposed

### RuleOrchestratorService (rule-orchestrator)
Service exposing the entities composing the companies and the rule books. The rule book also has reason code mappings and business area code mappings. The service also exposes functions:
- `getDefaultRuleBook` - gets default data for the rule book, data used when creating the default rule book when pressing on a company
- `getLLMModels` - get all the available llm models as defined by user in user provided variables 



**Actions (HTTP POST):**
- `GET https://service_hostname:port/odata/v4/rule-orchestrator/Companies`
- `GET https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks`
- `GET https://service_hostname:port/odata/v4/rule-orchestrator/getDefaultRuleBook`
- `GET https://service_hostname:port/odata/v4/rule-orchestrator/getLLMModels`
- `POST https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks` with body
- `PATCH https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=true)` with body; example: {
    "reasonCodeMappings": [
        { "reasonCode": "AD", "keywords": "key, key, key" }
    ],
    "businessAreaCodeMappings": [
        { "businessAreaCode": "MA", "keywords": "key ba, key ba, key ba" }
    ],
    "reasonCodeMappingPrompt": "New Prompt",
    "businessAreaCodeMappingPrompt": "BA New Prompt"
} - patch on rule book when entity is not in draft mode
- `PATCH https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=false)` with body - patch on rule book when entity is in draft
- `POST https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=true)/RuleOrchestratorService.draftEdit` - enter draft mode
- `DELETE https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=false)` - deletes rule book from draft
- `POST https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=false)/RuleOrchestratorService.draftActivate` - get rule book out of draft mode
- `POST https://service_hostname:port/odata/v4/rule-orchestrator/RuleBooks(ID=id,IsActiveEntity=false)/ReasonCodeMappings` with empty body - creates an empty mapping for patching later with data introduced by user
- `PATCH https://service_hostname:port/odata/v4/rule-orchestrator/ReasonCodeMappings(ID=id,IsActiveEntity=false)` with body; example {
  "reasonCode": "AD"  
} 
- `POST https://service_hostname:port/odata/v4/rule-orchestrator//RuleBooks(ID=id,IsActiveEntity=false)/BusinessAreaCodeMappings` with empty body - creates an empty mapping for patching later with data introduced by user
- `PATCH https://service_hostname:port/odata/v4/rule-orchestrator/BusinessAreaCodeMappings(ID=id,IsActiveEntity=false)` with body; example {
  "businessAreaCode": "AD"  
}

## Processes flow description
User can see all companies in a list and select one of the available ones. When selecting, if a rule book is not already existent then it is created with default data. The mappings can be now added by editing the rule book. The other options are to restore th default rule book, action that deletes everything on the rule book ond overwrites with default data and to import a rule book action that will delete and overwrite data with the specific selected rule book data.

## Additional Resources
-



