import cds from '@sap/cds';
import { defaultAITemplate } from '../lib/utils/ai-prompt-templating.js';

export default async (srv) => {
  srv.on('getLLMModels', async () => {
    const models = cds?.env?.requires?.['LLM_MODELS'];
    return models || [];
  });

  srv.on('getDefaultRuleBook', async () => {
    return defaultAITemplate();
  });
};
