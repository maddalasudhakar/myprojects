using dispute.management as db from '../../../central-db/schema';

@title               : 'Rule Orchestrator Service'
@Core.LongDescription: 'Service to manage companies and their specific rule books'
@Core.Description    : 'Rule orchestrator service'
service RuleOrchestratorService @(requires: ['Administrator']) {
   type LLMModelsData {
      models : many String;
   }

   @readonly
   entity Companies                as
      select from db.Companies as companies {
         *,
         case
            when
               ruleBook.ID is not null
               and exists(
                  select reasonCodeMappings.ID from db.ReasonCodeMappings as reasonCodeMappings
                  where
                     reasonCodeMappings.ruleBook.ID = companies.ruleBook.ID
               )
               and exists(
                  select businessAreaCodeMappings.ID from db.BusinessAreaCodeMappings as businessAreaCodeMappings
                  where
                     businessAreaCodeMappings.ruleBook.ID = companies.ruleBook.ID
               )
            then
               'Yes'
            else
               'No'
         end as hasRuleBook : String @Core.Computed
      };

   entity RuleBooks                as projection on db.RuleBooks;
   entity ReasonCodeMappings       as projection on db.ReasonCodeMappings;
   entity BusinessAreaCodeMappings as projection on db.BusinessAreaCodeMappings;
   function getDefaultRuleBook() returns RuleBooks;
   function getLLMModels()       returns LLMModelsData;

}

annotate RuleOrchestratorService.RuleBooks with  @odata.draft.enabled  @odata.draft.bypass;
annotate RuleOrchestratorService.ReasonCodeMappings with @odata.draft.bypass;
annotate RuleOrchestratorService.BusinessAreaCodeMappings with @odata.draft.bypass;
