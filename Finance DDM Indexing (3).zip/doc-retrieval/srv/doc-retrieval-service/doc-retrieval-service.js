import cds from '@sap/cds';
import {
  getAllDocumentPagesAsText,
} from '../lib/clients/dox-client.js';

import { extractTextFromDocument } from '../lib/utils/extraction-utils.js';

const log = cds.log('dox-retrieval-service');

/**
 * This service is responsible for handling requests related to document retrieval functionalities that can be triggered from an external service (dispute-analyzer OCR scenario).
 */
export default cds.service.impl(async function () {
  /**
   * This event handler retrieves all pages of a document as text.
   * It listens for the 'getDocumentAsText' event and processes the request to return the text content of the document.
   * @param {Object} req - The request object containing the DoX jobId of the document.
   * @returns {Promise<string>} - A promise that resolves to the text content of the document.
   * @throws {Error} - Throws an error if the document retrieval fails.
   */
    this.on('getDocumentAsText', async (req) => {
    try {
      const { jobId } = req.data;
      log.info(`Getting all document pages as text for docId: ${jobId}`);
      const ocrResponse = await getAllDocumentPagesAsText(jobId);
      return extractTextFromDocument(ocrResponse);
    } catch (error) {
      log.error('Getting all document pages as text failed due to error:', error);
      req.error(500, 'An error occurred while getting the document pages as text.');
    }
  });
});
