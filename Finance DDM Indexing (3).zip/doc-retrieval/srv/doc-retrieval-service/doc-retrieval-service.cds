
using dispute.management  as db from '../../../central-db/schema';

@title : 'Document Retrieval Service'
@Core.LongDescription : 'Service to retrieve and manage documents'
@Core.Description : 'Document retrieval service'
service DocRetrievalService  {

@readonly
entity Documents as projection on db.Documents;
@requires: ['authenticated-user']
function getDocumentAsText(jobId : String)           returns String;

}
