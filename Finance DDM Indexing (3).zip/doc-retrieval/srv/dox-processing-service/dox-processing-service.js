import cds from '@sap/cds';
import DocRetrievalJobHandler from '../lib/handlers/doc-retrieval-job-handler.js';
import { handleActionTriggeredByJobScheduler } from '../common-lib/managers/job-scheduler-manager.js';
import Utilities from '../common-lib/utils/utilities.js';

const log = cds.log('dox-processing-service');

 /**
     * This service is responsible for handling requests for document retrieval jobs in regards to data extraction from DoX service
     */
export default async (srv) => {
   /**
    * This event handler is triggered by the job scheduler to send documents for data extraction, process that is running in the background.
    * It sends documents in the UNPROCESSED status to DoX for data extraction.
    * First is changing the processing status of the documents to SENDING_TO_DOX, so that in case something is failing to be resend later.
    * At the end of the process, it updates the processing status of the sent documents to DOX_IN_PROGRESS and the job run log with the execution result.
    * @param {Object} req - The request object containing the job scheduler client and headers required for updating the job with the execution result.
    * @returns {Promise<void>} - A promise that resolves when the documents are sent for data extraction.
    * @throws {Error} - Throws an error if the document retrieval fails.
    */
    srv.on('sendDocumentsForDataExtraction', async (req) => {
        try {
            log.info('Action: sendDocumentsForDataExtraction triggered');
            await handleActionTriggeredByJobScheduler(req, DocRetrievalJobHandler.sendDocumentsForDataExtraction);
        } catch (error) {
            Utilities.handleHttpError(req, error, 'sendDocumentsForDataExtraction');
        }
    });

    /**
     * This event handler is triggered by the job scheduler to get data extraction results for documents sent to DoX, process that is running in the background.
     * It's calling the DoX service to retrieve data extraction for the documents in the DOX_IN_PROGRESS status.
     * At the end of the process, it updates the processing status of the documents successfully extracted to DOX_DONE or DOX_PARTIALLY_DONE (depending on the extraction results)
     * and the documents that failed to be extracted with DOX_FAILED.
     * The failed documents will be available in INVALID page for the user to correct them manually or to reject them.
     * The documents that were successfully extracted will be processed further by the LLM processing service, and in the end will be available in the `PROCESSED documents` page.
     * The job run log will be updated with the execution result.
     * @param {Object} req - The request object containing the job scheduler client and headers required for updating the job with the execution result.
     * @returns {Promise<void>} - A promise that resolves when the data extraction results are retrieved.
     * @throws {Error} - Throws an error if the data extraction results retrieval fails.
     */
    srv.on('getDataExtractionResults', async (req) => {
        try {
            log.info('Action: getDataExtractionResults triggered');
            await handleActionTriggeredByJobScheduler(req, DocRetrievalJobHandler.getDataExtractionResults);
        } catch (error) {
            Utilities.handleHttpError(req, error, 'getDataExtractionResults');
        }
    });

    /**
     * This event handler is triggered by the job scheduler to resend documents for data extraction.
     * This might be the case when the initial sending failed for any reason.
     * It fetches documents that are in the SENDING_TO_DOX status and resend them to DoX for data extraction.
     * At the end of the process, it updates the processing status of the documents to DOX_IN_PROGRESS and the job run log with the execution result.
     * @param {Object} req - The request object containing the job scheduler client and headers required for updating the job with the execution result.
     * @returns {Promise<void>} - A promise that resolves when the documents are resent for data extraction.
     * @throws {Error} - Throws an error if the document resend fails.
     */
    srv.on('resendDocumentsForDataExtraction', async (req) => {
        try {
            log.info('Action: resendDocumentsForDataExtraction triggered');
            await handleActionTriggeredByJobScheduler(req, DocRetrievalJobHandler.resendDocumentsForDataExtraction);
        } catch (error) {
            Utilities.handleHttpError(req, error, 'resendDocumentsForDataExtraction');
        }
    });

    /**
     * This event handler is triggered by the job scheduler to get data extraction results for documents corrected by the user, process that is running in the background.
     * When the user pressed `Make correction in DoX` the processing status of the document was set to 'DOX_CORRECTION_IN_PROGRESS).
     * It's fetching the data extraction results for documents in the DOX_CORRECTION_IN_PROGRESS status.
     * In case that changes are noticed on the document, it will update the processing status of the documents to DOX_CORRECTION_DONE or DOX_PARTIALLY_DONE (depending on the extraction results).
     * If no changes are noticed, it will remain in the DOX_CORRECTION_IN_PROGRESS status a configurable amount of time (default is 15 minutes). After that time, it will be set to back to the original status (e.g., DOX_DONE or DOX_PARTIALLY_DONE).
     * The job run log will be updated with the execution result.
     * @param {Object} req - The request object containing the job scheduler client and headers required for updating the job with the execution result.
     * @returns {Promise<void>} - A promise that resolves when the data extraction results for corrected documents are retrieved.
     * @throws {Error} - Throws an error if the data extraction results retrieval for corrected documents fails.
     */
    srv.on('getDataExtractionResultsForDocumentsCorrectedByUser', async (req) => {
        try {
            log.info('Action: getDataExtractionResultsForDocumentsCorrectedByUser triggered');
            await handleActionTriggeredByJobScheduler(req, DocRetrievalJobHandler.getDataExtractionResultsForDocumentsCorrectedByUser);
        } catch (error) {
            Utilities.handleHttpError(req, error, 'getDataExtractionResultsForDocumentsCorrectedByUser');
        }
    });
};
