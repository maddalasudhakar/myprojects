@title : 'Dox Processing Service'
@Core.LongDescription : 'Service exposing actions for document retrieval jobs in regards to data extraction from DoX service'
@Core.Description : 'Dox Processing Service'
@requires: ['JOBSCHEDULER']
service DoxProcessingService  {
    action sendDocumentsForDataExtraction();
    action getDataExtractionResults();
    action resendDocumentsForDataExtraction();
    action getDataExtractionResultsForDocumentsCorrectedByUser();
}
