import cds from '@sap/cds';
import { getAllDocumentPagesAsText } from '../../../srv/lib/clients/dox-client.js';
import { extractTextFromDocument } from '../../../srv/lib/utils/extraction-utils.js';
import impl from '../../../srv/doc-retrieval-service/doc-retrieval-service.js';

jest.mock('../../../srv/lib/clients/dox-client.js');
jest.mock('../../../srv/lib/utils/extraction-utils.js');

describe('Document Retrieval Service', () => {
  let log;

  beforeEach(() => {
    log = { info: jest.fn(), error: jest.fn() };
    jest.spyOn(cds, 'log').mockReturnValue(log);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  it('should return extracted text when getDocumentAsText is successful', async () => {
    const mockJobId = '12345';
    const mockOcrResponse = { pages: ['Page 1 text', 'Page 2 text'] };
    const mockExtractedText = 'Page 1 text Page 2 text';

    getAllDocumentPagesAsText.mockResolvedValue(mockOcrResponse);
    extractTextFromDocument.mockReturnValue(mockExtractedText);

    const req = { data: { jobId: mockJobId }, error: jest.fn() };
    const service = { on: jest.fn((event, handler) => handler(req)) };

    await impl.call(service);

    expect(req.error).not.toHaveBeenCalled();
    expect(getAllDocumentPagesAsText).toHaveBeenCalledWith(mockJobId);
    expect(extractTextFromDocument).toHaveBeenCalledWith(mockOcrResponse);
  });

  it('should handle errors when getDocumentAsText fails', async () => {
    const mockJobId = '12345';
    const mockError = new Error('OCR service failed');

    getAllDocumentPagesAsText.mockRejectedValue(mockError);

    const req = { data: { jobId: mockJobId }, error: jest.fn() };
    const service = { on: jest.fn((event, handler) => handler(req)) };

    await impl.call(service);

    expect(req.error).toHaveBeenCalledWith(500, 'An error occurred while getting the document pages as text.');
    expect(getAllDocumentPagesAsText).toHaveBeenCalledWith(mockJobId);
  });
});