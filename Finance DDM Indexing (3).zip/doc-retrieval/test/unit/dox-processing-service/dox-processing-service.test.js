import cds from '@sap/cds';
import DocRetrievalJobHandler from '../../../srv/lib/handlers/doc-retrieval-job-handler.js';
import { handleActionTriggeredByJobScheduler } from '../../../srv/common-lib/managers/job-scheduler-manager.js';
import Utilities from '../../../srv/common-lib/utils/utilities.js';

jest.mock('@sap/cds', () => ({
    log: jest.fn(() => ({
        info: jest.fn(),
        error: jest.fn(),
    })),
}));

jest.mock('../../../srv/lib/handlers/doc-retrieval-job-handler.js', () => ({
    sendDocumentsForDataExtraction: jest.fn(),
    getDataExtractionResults: jest.fn(),
    resendDocumentsForDataExtraction: jest.fn(),
    getDataExtractionResultsForDocumentsCorrectedByUser: jest.fn(),
}));

jest.mock('../../../srv/common-lib/managers/job-scheduler-manager.js', () => ({
    handleActionTriggeredByJobScheduler: jest.fn(),
}));

jest.mock('../../../srv/common-lib/utils/utilities.js', () => ({
    handleHttpError: jest.fn(),
}));

describe('dox-processing-service', () => {
    let srv;

    beforeEach(() => {
        srv = {
            on: jest.fn(),
        };
        require('../../../srv/dox-processing-service/dox-processing-service.js').default(srv);
    });

    it('should register sendDocumentsForDataExtraction handler', async () => {
        const req = {};
        const handler = srv.on.mock.calls.find(call => call[0] === 'sendDocumentsForDataExtraction')[1];

        await handler(req);

        expect(handleActionTriggeredByJobScheduler).toHaveBeenCalledWith(req, DocRetrievalJobHandler.sendDocumentsForDataExtraction);
    });

    it('should register getDataExtractionResults handler', async () => {
        const req = {};
        const handler = srv.on.mock.calls.find(call => call[0] === 'getDataExtractionResults')[1];

        await handler(req);

        expect(handleActionTriggeredByJobScheduler).toHaveBeenCalledWith(req, DocRetrievalJobHandler.getDataExtractionResults);
    });

    it('should register resendDocumentsForDataExtraction handler', async () => {
        const req = {};
        const handler = srv.on.mock.calls.find(call => call[0] === 'resendDocumentsForDataExtraction')[1];

        await handler(req);

        expect(handleActionTriggeredByJobScheduler).toHaveBeenCalledWith(req, DocRetrievalJobHandler.resendDocumentsForDataExtraction);
    });

    it('should register getDataExtractionResultsForDocumentsCorrectedByUser handler', async () => {
        const req = {};
        const handler = srv.on.mock.calls.find(call => call[0] === 'getDataExtractionResultsForDocumentsCorrectedByUser')[1];

        await handler(req);

        expect(handleActionTriggeredByJobScheduler).toHaveBeenCalledWith(req, DocRetrievalJobHandler.getDataExtractionResultsForDocumentsCorrectedByUser);
    });

    it('should handle errors in sendDocumentsForDataExtraction', async () => {
        const req = {};
        const error = new Error('Test Error');
        handleActionTriggeredByJobScheduler.mockRejectedValueOnce(error);
        const handler = srv.on.mock.calls.find(call => call[0] === 'sendDocumentsForDataExtraction')[1];

        await handler(req);

        expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'sendDocumentsForDataExtraction');
    });

    it('should handle errors in getDataExtractionResults', async () => {
        const req = {};
        const error = new Error('Test Error');
        handleActionTriggeredByJobScheduler.mockRejectedValueOnce(error);
        const handler = srv.on.mock.calls.find(call => call[0] === 'getDataExtractionResults')[1];

        await handler(req);

        expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'getDataExtractionResults');
    });

    it('should handle errors in resendDocumentsForDataExtraction', async () => {
        const req = {};
        const error = new Error('Test Error');
        handleActionTriggeredByJobScheduler.mockRejectedValueOnce(error);
        const handler = srv.on.mock.calls.find(call => call[0] === 'resendDocumentsForDataExtraction')[1];

        await handler(req);

        expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'resendDocumentsForDataExtraction');
    });

    it('should handle errors in getDataExtractionResultsForDocumentsCorrectedByUser', async () => {
        const req = {};
        const error = new Error('Test Error');
        handleActionTriggeredByJobScheduler.mockRejectedValueOnce(error);
        const handler = srv.on.mock.calls.find(call => call[0] === 'getDataExtractionResultsForDocumentsCorrectedByUser')[1];

        await handler(req);

        expect(Utilities.handleHttpError).toHaveBeenCalledWith(req, error, 'getDataExtractionResultsForDocumentsCorrectedByUser');
    });
});