# Doc-Retrieval service
It's responsible for sending and getting documents to DoX service for information extraction and saving them in the database.

## ODATA services exposed

### DoxProcessingService (dox-processing)
Service exposing actions for document retrieval in regards to DoX service information extraction process.
These actions are triggered periodically by the `JOB Scheduling` service:
- `sendDocumentsForDataExtraction` to send unprocessed documents for data extraction,
- `getDataExtractionResults` to retrieve the information extraction results,
- `resendDocumentsForDataExtraction` to resend documents that failed to be send in a previous attempt,
- `getDataExtractionResultsForDocumentsCorrectedByUser` to get results for documents that were manually corrected by users through DoX UI.

**Actions (HTTP POST):**
- `POST https://service_hostname:port/odata/v4/dox-processing/sendDocumentsForDataExtraction()`
- `POST https://service_hostname:port/odata/v4/dox-processing/getDataExtractionResults()`
- `POST https://service_hostname:port/odata/v4/dox-processing/resendDocumentsForDataExtraction()`
- `POST https://service_hostname:port/odata/v4/dox-processing/getDataExtractionResultsForDocumentsCorrectedByUser()`

## Processes flow description

### sendDocumentsForDataExtraction

![Process Flow: Sending documents for data extraction](readme-resources/sendDocumentsForDataExtraction.png)

1. Action is triggered by job scheduler.
2. The system selects documents with status `UNPROCESSED` and updates their status to `SENDING_TO_DOX`.
   - Uses configuration from `cds.env.DOX_CONFIG` (e.g., `CLIENT_ID`, `SCHEMA_NAME`, `DOCUMENT_TYPE`, `SCHEMA_VERSION`) for DoX service connection and document metadata.
3. For each document, the file content and metadata are submitted to the DoX service for information extraction.
4. The response from DoX (job ID and status) is parsed and stored.
   - If submission is successful, the document's status is updated to `DOX_IN_PROGRESS` and the job ID is stored for tracking.
   - If submission fails, the document status remains as `SENDING_TO_DOX`, allowing for retry in the next job run.
   - If DoX returns an unexpected or error status, the document status is set to `DOX_FAILED` and an error reason is recorded. These documents can be rejected or require manual intervention.
5. This process ensures that only unprocessed documents are sent and that failures are handled for future retries or review.

### getDataExtractionResults

![Process Flow: Getting data extraction results](readme-resources/getDataExtractionResults.png)

1. Action is triggered by job scheduler.
2. The system selects documents with status `DOX_IN_PROGRESS`.
3. For each document, the DoX job ID is used to fetch extraction results from the DoX service.
   - Uses `cds.env.DOX_CONFIG.UI_URL` (if set) to build DoX UI links for extracted documents.
4. The results are parsed and stored, updating the document's processing status and extracted data.
   - If all required fields (such as customer reference, name, and postal code) are present, the document status is set to `DOX_DONE`.
   - If only some required fields are present, the status is set to `DOX_PARTIALLY_DONE`.
   - `DOX_DONE` means all essential information was successfully extracted and the document is ready for further processing.
   - `DOX_PARTIALLY_DONE` means only partial information was extracted; manual review or correction may be needed.
   - If DoX fails to extract data (status is `FAILED`), the document status is set to `DOX_FAILED` and an error reason is recorded. These documents can be rejected or require manual intervention.
5. If fetching fails, the document status is not updated, allowing for retry in the next job run.

### resendDocumentsForDataExtraction

![Process Flow: Resending documents for data extraction](readme-resources/resendDocumentsForDataExtraction.png)

1. Action is triggered by job scheduler.
2. The system selects documents stuck in `SENDING_TO_DOX` status for longer than the configured time interval (`cds.env.MINUTES_SINCE_SENDING_TO_DOX_STATUS_CHANGE`, default: 10 minutes).
3. Each document is resubmitted to the DoX service for information extraction.
   - Uses configuration from `cds.env.DOX_CONFIG` for DoX service connection and document metadata.
4. The response from DoX (job ID and status) is parsed and stored.
   - If submission is successful, the document's status is updated to `DOX_IN_PROGRESS` and the new job ID is stored.
   - If submission fails, the document status remains unchanged, allowing for retry in the next job run.
5. This process helps recover documents that were not processed due to previous submission errors or timeouts.

### getDataExtractionResultsForDocumentsCorrectedByUser

![Process Flow: Getting results for documents corrected by user](readme-resources/getDataExtractionResultsForDocumentsCorrectedByUser.png)

1. Action is triggered by job scheduler.
2. The system selects documents with status `DOX_CORRECTION_IN_PROGRESS`.
3. For each document, the DoX job ID is used to fetch extraction results after user correction from the DoX service.
   - Uses `cds.env.MAX_USER_CORRECTION_WAIT_TIME_IN_MINUTES` (default: 60 minutes) to determine how long to wait for user corrections before reverting status.
4. The results are parsed and stored, updating the document's processing status and extracted data.
   - If the user-corrected extraction results contain all required fields, the document status is set to `DOX_CORRECTION_DONE`.
   - If only some required fields are present, the status is set to `DOX_CORRECTION_PARTIALLY_DONE`.
   - If the maximum wait time for user correction is exceeded without changes, the document will be reverted to its previous status for further handling.
   - If DoX fails to provide corrected data (status is `FAILED`), the document status is set to `DOX_FAILED` and an error reason is recorded. These documents can be rejected or require manual intervention.
5. If fetching fails, the document status is not updated, allowing for retry in the next job run.

## DocRetrievalService (doc-retrieval)
Service exposing `getDocumentAsText` action to retrieve the text of a document from the DoX service.
This action allows the `dispute-analyzer` service to retrieve the full text of a document from the DoX service via the `HENKEL-DOC-RETRIEVAL-SERVICE` destination. It is used when the DoX service is unable to extract all required information, enabling further analysis by the LLM.

### getDocumentAsText

![Process Flow: Getting document as text](readme-resources/getDocumentAsText.png)

1. Action is triggered via the OData endpoint by an external service (e.g., dispute-analyzer).
2. The system receives a request with the DoX job ID for the document.
3. The service calls the DoX API to retrieve the full text content of the document using the job ID.
4. The text content is returned to the requester for further analysis (e.g., by an LLM if required fields were not extracted).
   - Uses `cds.env.DOX_CONFIG` for DoX service connection and job lookup.
5. If fetching fails, an error is returned to the requester.

**Actions (HTTP POST):**
- `POST https://service_hostname:port/odata/v4/doc-retrieval/getDocumentAsText()`

## User-provided Variables Used in the Process

- `cds.env.DOX_CONFIG`: (from `cds.env`) Configuration object for DoX service connection. Contains:
  - `CLIENT_ID` (default: 'henkel-doc-ai-premium-finance-ddm-indexing')
  - `SCHEMA_NAME` (default: 'Henkel_Claims_final')
  - `DOCUMENT_TYPE` (default: 'custom')
  - `SCHEMA_VERSION` (default: '1')
  - `UI_URL` (default: 'https://henkel-qa-ai-foundation.eu20-001.doc.cloud.sap/', used for building DoX UI links)

- `cds.env.MINUTES_SINCE_SENDING_TO_DOX_STATUS_CHANGE`: (from `cds.env`) Number of minutes to wait before resending documents stuck in `SENDING_TO_DOX` status. Default: 5 minutes.

- `cds.env.MAX_USER_CORRECTION_WAIT_TIME_IN_MINUTES`: (from `cds.env`) Maximum time (in minutes) to wait for user correction after a document is sent for correction. Default: 5 minutes.

- `cds.env.MAX_BATCHES_TO_PROCESS`: (from `cds.env`) Maximum number of batches to process in a single job run. Default: 10.

- `cds.env.MAX_ROWS_IN_BATCH`: (from `cds.env`) Maximum number of documents (rows) in a single batch. Default: 50.

- `process.env.MAX_DOCUMENTS_TO_PROCESS`: (from `process.env`) Maximum number of documents to process in a single job run. Default: 500.



