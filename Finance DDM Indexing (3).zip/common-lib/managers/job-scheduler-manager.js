import xsenv from '@sap/xsenv';
import { StatusCodes } from 'http-status-codes';
import JobSchedulerClient from '../clients/job-scheduler-client.js';
import DocumentsProcessingService from '../service/documents-processing-service.js';
import Utilities from '../utils/utilities.js';
const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;
const log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('job-scheduler-manager') : { info: () => {}, error: () => {}, warn: () => {} };
xsenv.loadEnv();

/**
 * Processes documents based on the provided details and function.
 * If the action was triggered by Job Scheduler, updates the job run log with the processing status or error details.
 * For manual triggers (e.g., in hybrid mode testing), processes the documents without updating the job run log.
 *
 * @param {object} processDetails - Details of the documents to be processed.
 * @param {function} processingFunction - Function to process the documents.
 * @param {object} [headers=null] - Headers from the Job Scheduler request (if applicable).
 * @param {object} [jobSchedulerClient=null] - Instance of the Job Scheduler client (if applicable).
 * @returns {Promise<void>} - Resolves when processing is complete.
 * @throws {Error} - Throws an error if processing fails.
 */
async function handleDocumentsProcessingJob(processDetails, processingFunction, headers = null, jobSchedulerClient = null) {
  try {
    const processingDocResponse = await DocumentsProcessingService.processDocuments(processingFunction, processDetails);
    const stringifiedResponse = Utilities.safeStringify(processingDocResponse);
    log.info(`Processing completed successfully. Response: ${stringifiedResponse}`);
    const jobStatus = {
      success: true,
      message: stringifiedResponse
    };
    await updateJobRunLog(jobSchedulerClient, headers, jobStatus);
  } catch (error) {
    const jobStatus = {
      success: false,
      message: Utilities.safeStringify({ errorMessage: error.message, errorStackTrace: error.stack })
    };
    await updateJobRunLog(jobSchedulerClient, headers, jobStatus);
    log.error(`Error during processing:`, error);
    throw error;
  }
}

/**
 * Handles actions triggered by Job Scheduler or manual triggers.
 * For Job Scheduler requests, creates a Job Scheduler client, extracts headers, and invokes the action handler with the headers and client.
 * For non-Job Scheduler requests, invokes the action handler without headers or client.
 * In production, returns a 400 Bad Request status for non-Job Scheduler requests. In non-production, accepts such requests with a 202 status.
 *
 * @param {object} req - The incoming request object.
 * @param {function} actionHandler - Function to handle the action.
 * @returns {Promise<void>} - Resolves when the action is handled.
 */
async function handleActionTriggeredByJobScheduler(req, actionHandler) {
  const jobSchedulerClient = new JobSchedulerClient();

  try {
    if (jobSchedulerClient.isJobSchedulerInvocation(req)) {
      log.info('Job Scheduler headers are present in the request.');
      const headers = jobSchedulerClient.getJobSchedulerRequestHeadersAsObject(req);
      cds.spawn({ user: req.user }, async () => {
        await actionHandler(headers, jobSchedulerClient);
      });
      req.http.res.status(StatusCodes.ACCEPTED).end();
    } else {
      log.error('Job Scheduler headers are missing in the request.');
      if (process.env.NODE_ENV === 'production') {
        req.http.res.status(StatusCodes.BAD_REQUEST).end();
      } else {
        log.info('Non-Job Scheduler invocation accepted in non-production environment.');
        cds.spawn({ user: req.user }, async () => {
          await actionHandler();
        }); // Invoke with no headers and no jobSchedulerClient
        req.http.res.status(StatusCodes.ACCEPTED).end();
      }
    }
  } catch (error) {
    log.error(`Error in ${actionHandler.name}:`, error);
    req.http.res.status(StatusCodes.INTERNAL_SERVER_ERROR).end();
  }
}

/**
 * Handles the update of the job run log.
 *
 * @param {object} jobSchedulerClient - The Job Scheduler client instance.
 * @param {object} headers - The headers from the Job Scheduler request.
 * @param {boolean} success - Indicates whether the operation was successful.
 * @param {object} message - The message to log.
 */
async function handleJobRunLog(jobSchedulerClient, headers, success, message) {
  try {
    log.info('Updating job run log with status:', success);
    const jobStatus = {
      success,
      message: Utilities.safeStringify(message)
    };
    await updateJobRunLog(jobSchedulerClient, headers, jobStatus);
  } catch (error) {
    log.error('Error updating job run log:', error);
    // no need to throw an error here, just log it, since the job is running in the background and
    // updating the triggered job with the execution status is not critical for the job execution
  }
}

/**
 * Update the job run log with the given status and headers.
 * Logs an error if the update fails but does not throw an exception.
 *
 * @param {object} jobSchedulerClient - The Job Scheduler client instance.
 * @param {object} headers - The headers from the Job Scheduler request.
 * @param {object} status - The status to log (success or failure).
 */
async function updateJobRunLog(jobSchedulerClient, headers, status) {
  if (jobSchedulerClient && headers) {
    try {
      await jobSchedulerClient.updateJobRunLog(status, headers);
    } catch (error) {
      log.error('Failed to update job run log:', error);
      // no need to throw an error here, just log it, since the job is running in the background and
      // updating the triggered job with the execution status is not critical for the job execution
    }
  }
}

export { handleDocumentsProcessingJob, handleActionTriggeredByJobScheduler, updateJobRunLog, handleJobRunLog };
