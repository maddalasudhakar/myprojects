const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;
const log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('retry-handler') : { info: () => {}, error: () => {}, warn: () => {} };
export default class RetryHandler {
  /**
   * Executes a method with retry logic.
   * @param {Function} methodToBeRetried - The method to be retried.
   * @param {Object} options - Retry configuration options.
   * @param {number} [options.maxRetries=10] - Maximum number of retries.
   * @param {number} [options.retryDelay=3] - Delay between retries in minutes.
   * @param {Array} args - Arguments to be passed to the method as an array.
   * @returns {Promise<any>} The result of the method if successful.
   * @throws {Error} The last error encountered if retries are exhausted.
   */
  static async executeWithRetry(methodToBeRetried, options = {}) {
    const { maxRetries = 10, retryDelay = 3 } = options;

    let attempt = 1;
    while (attempt <= maxRetries) {
      try {
        return await methodToBeRetried();
      } catch (error) {
        if (attempt >= maxRetries) {
          log.error(`Max retries (${maxRetries}) reached. Throwing error.`);
          throw new Error(`Max retries reached: ${maxRetries}. Last error: ${error.message}`);
        }

        log.warn(`Attempt ${attempt} failed. Retrying in ${retryDelay} minutes...`, error);
        await this.delay(retryDelay);
        attempt++;
      }
    }
  }

  /**
 * Delays execution for a specified number of minutes.
 * @param {number} minutes - The delay duration in minutes.
 * @returns {Promise<void>} A promise that resolves after the delay.
 */
  static async delay(minutes) {
    return new Promise(resolve => setTimeout(resolve, minutes * 60000)); // Convert minutes to milliseconds
  }
}


