import { CDS_ENTITIES } from '../../common-lib/utils/constants.js';
const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;

class CommonCompaniesRepository {
  constructor() {
    this.db = cdsGlobal ? cdsGlobal.db : { run: () => {} };
    this.log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('common-companies-repository') : { info: () => {}, error: () => {}, warn: () => {} };
  }

  async getCompanyByCompanyCode(companyCode, columns = null, tx = null) {
    const companyEntity = this.db.entities[CDS_ENTITIES.DISPUTE_MANAGEMENT_COMPANIES];
    try {
      let query = SELECT.one.from(companyEntity).where({ companyCode: companyCode });
      if(columns){
        query = query.columns(columns);
      }

      const result = tx ? await tx.run(query) : await this.db.run(query);

      return result;
    } catch (error) {
      this.log.error('Error retrieving company by company code:', error);
      throw error;
    }
  }
}

export default CommonCompaniesRepository;
