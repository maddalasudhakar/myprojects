import { Readable } from 'stream';
import { CDS_ENTITIES, ERP_PROCESSING_STATUS } from '../../common-lib/utils/constants.js';
const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;

class DocumentsRepository {
  constructor() {
    this.db = cdsGlobal ? cdsGlobal.db : { run: () => {} };
    this.log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('DocumentsRepository') : { info: () => {}, error: () => {}, warn: () => {} };
  }

  async _runQuery(query, errorMessage, tx = null) {
    try {
      return await (tx || this.db).run(query);
    } catch (error) {
      this.log.error(errorMessage, error);
      throw error;
    }
  }

  async _connectToService(serviceName, errorMessage) {
    try {
      return await cds.connect.to(serviceName);
    } catch (error) {
      this.log.error(errorMessage, error);
      throw error;
    }
  }

  /**
   * Fetches a single document by its ID.
   * @param {string} documentId - The ID of the document to fetch.
   * @returns {Promise<Object|null>} The document object if found, otherwise null.
   */
  async getDocumentById(documentId) {
    const query = SELECT.one.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ ID: documentId });

    return await this._runQuery(query, `Error fetching document with ID ${documentId}:`);
  }

  /**
   * Fetches a draft document by its ID.
   * @param {string} documentId - The ID of the draft document to fetch.
   * @returns {Promise<Object|null>} The draft document object if found, otherwise null.
   */
  async getDraftDocumentById(documentId) {
    const query = SELECT.one.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_DRAFTS).where({ ID: documentId });
    return await this._runQuery(query, `Error fetching draft document with ID ${documentId}:`);
  }

  /**
   * Fetches a configurable number of documents with a specific processing status.
   * Optionally filters by a time condition and orders by lastModifiedAt in ascending order.
   * @param {string} processingStatus - The processing status to filter documents.
   * @param {number} maxRows - The maximum number of documents to fetch.
   * @param {object} filters - Optional filters.
   * @throws Will throw an error if the query fails.
   * @returns {Promise<Array>} The list of documents matching the criteria.
   */
  async getDocuments(processingStatus, maxRows, filters = null) {
    const query = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ processingStatus }).orderBy('lastModifiedAt').limit(maxRows);

    if (filters?.timeFilterMinutes) {
      const timeFilter = new Date(Date.now() - filters.timeFilterMinutes * 60000).toISOString();
      query.where('lastModifiedAt <', timeFilter);
    }

    const documents = await this._runQuery(query, 'Error fetching documents:');

    if (filters?.includeAttachments) {
      await this._addAttachmentToDocuments(documents);
    }

    return documents;
  }

  /**
   * Adds attachments to the provided documents.
   * @param {Array<Object>} documents - The list of documents to which attachments will be added.
   * @throws Will throw an error if the query for attachments fails.
   */
  async _addAttachmentToDocuments(documents) {
    try {
      if (!documents.length) return;

      const attachmentsSrv = await this._connectToService('attachments', 'Error connecting to attachments service:');

      const attachmentQuery = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS)
        .columns('ID', 'up__ID', 'filename', 'url')
        .where({ up__ID: { in: documents.map((doc) => doc.ID) } });

      const docAttachments = await this.db.run(attachmentQuery);
      const attachments = docAttachments.filter((attachment) => attachment.url);
      if (!attachments.length) return;

      const attachmentsContents = await Promise.allSettled(
        attachments.map(async (attachment) => {
          try {
            const attachmentContent = await attachmentsSrv.get(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS, { ID: attachment.ID });

            // Ensure LOB data is fully read and converted to Buffer
            const contentBuffer = await this._convertToBuffer(attachmentContent);

            return {
              documentId: attachment.up__ID,
              content: contentBuffer,
              fileName: attachment.filename
            };
          } catch (error) {
            this.log.error(`Error fetching attachment content for attachment ID ${attachment.ID}:`, error);
            return {
              documentId: attachment.up__ID,
              content: null,
              fileName: attachment.filename
            };
          }
        })
      );

      attachmentsContents.forEach((result) => {
        if (result.status === 'fulfilled') {
          const attachment = result.value;
          const doc = documents.find((doc) => doc.ID === attachment.documentId);
          if (doc) {
            doc.attachment = attachment;
          }
        } else {
          this.log.warn(`Attachment processing failed:`, result.reason);
        }
      });
    } catch (error) {
      this.log.error('Error fetching attachments for documents:', error);
      throw error;
    }
  }

  async getAttachmentByDocumentId(documentId, tx = null) {
    const attachmentsSrv = await this._connectToService('attachments', 'Error connecting to attachments service:');

    const attachmentQuery = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS).where({ up__ID: documentId });

    const attachments = await this._runQuery(attachmentQuery, `Error fetching attachments for document ID ${documentId}:`, tx);

    if (attachments.length === 0) {
      this.log.error(`No attachments found for document ID ${documentId}`);
      return null;
    }

    const attachmentId = attachments[0]?.ID;
    if (!attachmentId) {
      this.log.error(`Attachment ID not found for document ID ${documentId}`);
      return null;
    }

    const attachmentUrl = attachments[0]?.url;
    const attachmentContent = await attachmentsSrv.get(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS, { ID: attachmentId });
    const contentBuffer = await this._convertToBuffer(attachmentContent);

    return { contentBuffer, attachmentUrl };
  }

  async deleteAttachmentForDocumentId(documentId, attachmentUrl, tx = null) {
    this.log.info(`Deleting attachment for document ID ${documentId} with URL ${attachmentUrl}`);

    const attachmentQuery = DELETE.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS).where({ up__ID: documentId });
    await this._runQuery(
      attachmentQuery,
      `Error deleting attachment for document ID ${documentId}:`, tx
    );

    const attachmentsSrv = await this._connectToService(
      'attachments',
      'Error connecting to attachments service:',
    );

    await attachmentsSrv.delete(attachmentUrl);

  }

  /**
   * Converts the given content into a Buffer.
   * Handles Readable streams, Buffer objects, and other content types.
   * @param {Readable|Buffer|string} content - The content to convert.
   * @returns {Promise<Buffer>} - The converted Buffer.
   * @throws {Error} - Throws an error if the content type is unsupported.
   */
  async _convertToBuffer(content) {
    if (content instanceof Readable) {
      const chunks = [];
      try {
        for await (const chunk of content) {
          chunks.push(chunk);
        }
        if (chunks.length === 0) {
          throw new Error('LOB stream is empty.');
        }
        return Buffer.concat(chunks);
      } catch (error) {
        this.log.error('Error reading LOB stream:', error);
        throw new Error('Failed to read LOB stream');
      }
    } else if (Buffer.isBuffer(content)) {
      return content;
    } else if (typeof content === 'string') {
      return Buffer.from(content);
    }
    throw new Error('Unsupported content type for Buffer conversion.');
  }

  /**
   * Updates the processing status of multiple documents in bulk.
   * This operation is performed in a transaction to ensure atomicity.
   * @param {Array<string>} documentIds - The IDs of the documents to update.
   * @param {string} newStatus - The new processing status to set.
   * @param {string|null} errorReason - Optional error reason to set if the status is an error.
   * @throws Will throw an error if the transaction fails.
   */
  async updateDocumentsProcessingStatus(documentIds, newStatus, sendingToERPError = null, tx = null) {
    this.log.info(`Updating processing status for documents with IDs: ${documentIds.join(', ')} to ${newStatus}`);

    const localTx = tx || this.db.tx();

    try {
      const updateData =
        newStatus === ERP_PROCESSING_STATUS.ERP_FAILED
          ? {
              status: newStatus,
              processingStatus: newStatus
            }
          : { processingStatus: newStatus };

      if (sendingToERPError) {
        updateData.sendingToERPError = sendingToERPError;
      }

      await localTx.run(
        UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS)
          .set(updateData)
          .where({ ID: { in: documentIds } })
      );

      if (!tx) await localTx.commit();

      this.log.info(`Successfully updated processing status for documents with IDs: ${documentIds.join(', ')} to ${newStatus}`);
    } catch (error) {
      this.log.error('Error updating document processing status:', error);
      if (!tx) await localTx.rollback();
      throw error;
    }
  }


  async updateDocumentProcessingStatus(documentId, newStatus){
    const query = UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS)
      .set({ processingStatus: newStatus })
      .where({ ID: documentId });
    await this._runQuery(query, `Error updating draft document processing status for ID ${documentId}:`);
  }

  /**
   * Updates multiple documents with specific data in bulk.
   * This operation is performed in a transaction to ensure atomicity.
   * @param {Array<Object>} documentUpdates - The list of updates, each containing an ID and data.
   * @throws Will throw an error if the transaction fails.
   */
  async updateDocumentsData(documentUpdates, tx = null) {
    try {
      const updatePromises = documentUpdates.map((update) => {
        const query = UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).set(update.data).where({ ID: update.id });
        return tx ? tx.run(query) : this.db.run(query);
      });

      const updateResponse = await Promise.all(updatePromises);
      this.log.info(`Successfully updated ${updateResponse.length} documents.`);
      return updateResponse;
    } catch (error) {
      this.log.error('Error updating documents data:', error);
      throw error;
    }
  }

  /**
   * Fetches documents that need to be updated based on their IDs.
   * @param {Array<string>} documentIds - The IDs of the documents to fetch.
   * @returns {Promise<Array>} The list of documents matching the provided IDs.
   * @throws Will throw an error if the query fails.
   */
  async getDocumentsToBeUpdated(documentIds, tx) {
    try {
      const query = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS, (doc) => {
        doc.ID,
          doc.name,
          doc.companyCode,
          doc.processingStatus,
          doc.status,
          doc.businessAreaCode,
          doc.reasonCode,
          doc.customerExternalReference,
          doc.henkelInvoice,
          doc.customerNumber,
          doc.amount,
          doc.debitNoteDate,
          doc.shipTo,
          doc.soldTo,
          doc.netDueDate,
          doc.taxReportingDate;
      })
        .where({
          ID: { in: documentIds },
          status: { '!=': 'PROCESSED' }
        })
        .forUpdate();

      return await this._runQuery(query, 'Error fetching documents to be updated:', tx);
    } catch (error) {
      this.log.error('Error in getDocumentsToBeUpdated:', error);
      throw error;
    }
  }

  /**
   * Creates a new document in the database.
   * @param {Object} document - The document object to create.
   * @throws Will throw an error if the creation fails.
   * @returns {Promise<Object>} The created document object.
   */
  async createDocument(document) {
    // Log debitNoteDate before inserting
    console.log(`Creating document - debitNoteDate: ${document.debitNoteDate}`);

    const query = INSERT.into(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).entries([document]);

    return await this._runQuery(query, 'Error creating document:');
  }

  /**
   * Updates an existing document in the database.
   * @param {Object} document - The document object to update.
   * @throws Will throw an error if the update fails.
   * @returns {Promise<Object>} The updated document object.
   */
  async updateDocument(document) {
    const query = UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).set(document).where({ ID: document.ID });

    return await this._runQuery(query, 'Error updating document:');
  }

  async getFailedDocuments(processingStatusList) {
    try {
      const query = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS)
        .columns((document) => {
          document`.*`, document.message('*');
        })
        .where({ processingStatus: { in: processingStatusList } });
      return await this.db.run(query);
    } catch (error) {
      this.log.error('Error retrieving failed documents:', error);
      throw error;
    }
  }

  async getDocumentByExternalId(externalAttachmentId) {
    try {
      const query = SELECT.one.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS).where({ externalAttachmentId: externalAttachmentId });
      return await this.db.run(query);
    } catch (error) {
      this.log.error('Error retrieving document by external ID:', error);
      throw error;
    }
  }
}

export default DocumentsRepository;
