import { CDS_ENTITIES } from '../../common-lib/utils/constants.js';
const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;

class MessagesRepository {
  constructor() {
    this.db = cdsGlobal ? cdsGlobal.db : { run: () => {} };
    this.log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('MessagesRepository') : { info: () => {}, error: () => {}, warn: () => {} };
  }

  async createMessage(message) {
    try {
      return await this.db.run(INSERT.into(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES).entries([message]));
    } catch (error) {
      this.log.error('Error creating message:', error);
      throw error;
    }
  }

  async updateMessage(message) {
    try {
      return await this.db.run(UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES).set(message).where({ ID: message.ID }));
    } catch (error) {
      this.log.error('Error updating message:', error);
      throw error;
    }
  }

  async getFailedMessages(processingStatusList) {
    try {
      const query = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES).where({ processingStatus: { in: processingStatusList } });
      return await this.db.run(query);
    } catch (error) {
      this.log.error('Error retrieving failed messages:', error);
      throw error;
    }
  }

  async getMessageByExternalId(externalMessageId) {
    try {
      const query = SELECT.one.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_MESSAGES).where({ externalMessageId: externalMessageId });
      return await this.db.run(query);
    } catch (error) {
      this.log.error('Error retrieving message by external ID:', error);
      throw error;
    }
  }

  async createFailedMessageJob(messageJob) {
    try {
      return await this.db.run(INSERT.into(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS).entries([messageJob]));
    } catch (error) {
      this.log.error('Error creating message job:', error);
      throw error;
    }
  }

  async updateFailedMessageJob(messageJob) {
    try {
      return await this.db.run(UPDATE(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS).set(messageJob).where({ ID: messageJob.ID }));
    } catch (error) {
      this.log.error('Error updating message job:', error);
      throw error;
    }
  }

  async getFailedMessageJobs(processingStatusList, maxRetryCount) {
    try {
      const query = SELECT.from(CDS_ENTITIES.DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS).where({ processingStatus: { in: processingStatusList }, retryCount: { '<=': maxRetryCount } });
      return await this.db.run(query);
    } catch (error) {
      this.log.error('Error retrieving failed message jobs:', error);
      throw error;
    }
  }
}

export default MessagesRepository;
