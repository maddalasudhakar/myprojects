import {StatusCodes} from 'http-status-codes';
import {VALID_CONTENT_TYPES} from './constants.js';

const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;
const log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('utilities') : { info: () => {}, error: () => {}, warn: () => {} };
export default class Utilities {
    /**
     * Generates a default response object with a dynamic key and value.
     * @param {string} key - The key for the response object.
     * @param {any} value - The value for the response object (default is 0).
     * @returns {object} - The generated response object.
     */
    static generateDefaultResponse(key, value = 0) {
        return {[key]: value};
    }

    /**
     * Handles errors by logging the error and optionally throwing it.
     * @param {string} message - The error message to log.
     * @param {Error|null} error - The error object to log (optional).
     * @param {object|null} returnObject - An optional object to return instead of throwing the error.
     * @returns {object|null} - The returnObject if provided, otherwise throws an error.
     * @throws {Error} - Throws an error if returnObject is not provided.
     */
    static handleError(message, error = null, returnObject = null) {
        error ? log.error(message, error) : log.error(message);
        if (!returnObject && !error) {
            throw new Error(message);
        } else if (!returnObject && error) {
            throw error;
        }
        return returnObject;
    }

    /**
     * Handles errors for HTTP requests by logging the error and setting the response status.
     * @param {object} req - The HTTP request object.
     * @param {Error} error - The error object to log.
     * @param {string} actionName - The name of the action where the error occurred.
     */
    static handleHttpError(req, error, actionName) {
        log.error(`Error in ${actionName}:`, error);
        req.http.res.status(StatusCodes.INTERNAL_SERVER_ERROR).end();
    }

    /**
     * Logs informational messages with optional data.
     * @param {string} message - The informational message to log.
     * @param {object|null} data - Optional data to include in the log (default is null).
     */
    static logInfo(message, data = null) {
        if (data) {
            log.info(`${message} ${JSON.stringify(data)}`);
        } else {
            log.info(message);
        }
    }

    /**
     * Helper function to safely converts the response object to a JSON string. If conversion fails, returns a fallback message.
     *
     * @param {object} obj - The object to stringify.
     * @returns {string} - The JSON string or a fallback message.
     */
    static safeStringify(obj) {
        try {
            return JSON.stringify(obj);
        } catch (error) {
            log.error('Failed to stringify object:', error);
            return 'Unable to stringify object';
        }
    }

    /**
     * Helper function that validates if a given string is a valid UUID.
     * @param {string} uuid - The UUID string to validate.
     * @returns {boolean} - Returns true if the UUID is valid, false otherwise.
     */
    static isValidUUID(uuid) {
        const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        return uuidRegex.test(uuid);
    }

    /**
     * Checks if the content type of the attachment is valid.
     * @param {Object} attachment - The attachment from the Inbox.
     * @returns {boolean} True if the content type is valid, false otherwise.
     */
    static isValidContentType(attachment) {
        return VALID_CONTENT_TYPES.includes(attachment.contentType);
    }
}