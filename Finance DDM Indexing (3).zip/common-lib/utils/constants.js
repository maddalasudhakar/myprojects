export const CDS_ENTITIES = {
  DISPUTE_MANAGEMENT_COMPANIES: 'dispute.management.Companies',
  DISPUTE_MANAGEMENT_RULEBOOKS: 'dispute.management.RuleBooks',
  DISPUTE_MANAGEMENT_MESSAGES: 'dispute.management.Messages',
  DISPUTE_MANAGEMENT_DOCUMENTS: 'dispute.management.Documents',
  DISPUTE_MANAGEMENT_DOCUMENTS_DRAFTS: 'DisputeAnalyzerService.Documents.drafts',
  DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS: 'dispute.management.Documents.attachments',
  CUSTOMER_MASTER_DATA: 'dispute.masterdata.Customer2',
  CUSTOMER_PARTNER_ROLE_MASTER_DATA: 'dispute.masterdata.Customerpartnerrole',
  CUSTOMER_MASTER_DATA_SNAPSHOT: 'dispute.masterdata.CustomerSnapshot',
  DISPUTE_MANAGEMENT_FAILED_MESSAGE_JOBS: 'dispute.management.FailedMessageJobs'
};

export const MAILBOX_CLIENT_CONFIG = {
  BATCH_SIZE: process.env.BATCH_SIZE || 100,
  MINUTES: process.env.MINUTES || 5
};

export const VALID_CONTENT_TYPES = [
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/txt',
  'application/rtf',
  'application/vnd.oasis.opendocument.text',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'text/csv',
  'application/vnd.oasis.opendocument.spreadsheet',
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/bmp'
];

export const DESTINATIONS = {
  HENKEL_MAILBOX: process.env.HENKEL_MAILBOX || 'HENKEL-MAILBOX'
};

export const DOX_EXTRACTION_STATUS = {
  FAILED: 'FAILED',
  DONE: 'DONE',
  PENDING: 'PENDING',
  CONFIRMED: 'CONFIRMED'
};

export const PROCESSING_STATUS = {
  INVALID_MAIL: 'INVALID_MAIL',
  CONTENT_FETCH_ERROR: 'CONTENT_FETCH_ERROR',
  UNPROCESSED: 'UNPROCESSED',
  SENDING_TO_DOX: 'SENDING_TO_DOX',
  DOX_IN_PROGRESS: 'DOX_IN_PROGRESS',
  DOX_DONE: 'DOX_DONE',
  DOX_FAILED: 'DOX_FAILED',
  DOX_PARTIALLY_DONE: 'DOX_PARTIALLY_DONE',
  DOX_CORRECTION_IN_PROGRESS: 'DOX_CORRECTION_IN_PROGRESS',
  DOX_CORRECTION_DONE: 'DOX_CORRECTION_DONE',
};

export const MESSAGE_PROCESSING_STATUS = {
  DONE: 'DONE',
  PARTIALLY_DONE: 'PARTIALLY_DONE',
  NO_ATTACHMENTS_FOUND: 'NO_ATTACHMENTS_FOUND',
  ATTACHMENTS_FETCH_ERROR: 'ATTACHMENTS_FETCH_ERROR'
};

export const FAILED_MESSAGE_JOB_STATUS = {
  UNPROCESSED: 'UNPROCESSED',
  PROCESSED: 'PROCESSED'
};

export const FAILED_STATUS = 'FAILED';

export const ERROR_REASONS = {
  NO_EXTRACTED_FIELDS: 'Data extraction process failed, DoX service did not extract any fields',
  UNKNOWN_ERROR_FROM_DOX: 'Unknown error from DoX service getting document extraction results',
  UNEXPECTED_EXTRACTION_ERROR: 'Unexpected error getting document extraction results'
};

export const LLM_PROCESSING_STATUS = {
  VALIDATION_FAILED: 'VALIDATION_FAILED',
  SENDING_TO_LLM: 'SENDING_TO_LLM'
};

export const LLM_EXTRACTION_STATUS = {
  FAILED: 'LLM_FAILED',
  DONE: 'LLM_DONE'
};

export const DOCUMENT_STATUS_FOR_USER = {
  NEW: 'NEW',
  PROCESSED: 'PROCESSED',
  REJECTED: 'REJECTED',
  INVALID: 'INVALID',
};

export const ERP_PROCESSING_STATUS = {
  SENDING_TO_ERP: 'SENDING_TO_ERP',
  ERP_DONE: 'ERP_DONE',
  ERP_FAILED: 'ERP_FAILED'
};

export const DEFAULT_MAX_USER_CORRECTION_WAIT_TIME_IN_MINUTES = 30;
export const DEFAULT_MAX_BATCHES_TO_PROCESS = 10;
export const DEFAULT_MAX_ROWS_IN_BATCH = 50;
export const DEFAULT_MAX_DOCUMENTS_TO_PROCESS = 500;
export const DEFAULT_MINUTES_SINCE_SENDING_TO_DOX_STATUS_CHANGE = 30;

export const MAX_DOCUMENTS = parseInt(process.env.MAX_DOCUMENTS_TO_PROCESS);

export const JOB_SCHEDULER = Object.freeze({
  headers: {
    X_SAP_JOB_ID: 'x-sap-job-id',
    X_SAP_JOB_SCHEDULE_ID: 'x-sap-job-schedule-id',
    X_SAP_JOB_RUN_ID: 'x-sap-job-run-id',
    X_SAP_SCHEDULER_HOST: 'x-sap-scheduler-host',
    X_SAP_RUN_AT: 'x-sap-run-at'
  }
});
