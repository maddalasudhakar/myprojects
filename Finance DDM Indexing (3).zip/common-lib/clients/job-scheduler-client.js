import {JOB_SCHEDULER} from '../utils/constants.js';

class JobSchedulerClient {
  constructor() {
    this.log = cds.log('job-scheduler-client');
  }

  /**
   * Checks if the request is a Job Scheduler invocation.
   * @param {object} expressReq - The Express request object.
   * @return {boolean} - Returns true if the request is a Job Scheduler invocation, false otherwise.
   * */
  isJobSchedulerInvocation(expressReq) {
    const headers = expressReq.headers;
    return (
      headers[JOB_SCHEDULER.headers.X_SAP_JOB_ID] &&
      headers[JOB_SCHEDULER.headers.X_SAP_JOB_SCHEDULE_ID] &&
      headers[JOB_SCHEDULER.headers.X_SAP_JOB_RUN_ID] &&
      headers[JOB_SCHEDULER.headers.X_SAP_SCHEDULER_HOST] &&
      headers[JOB_SCHEDULER.headers.X_SAP_RUN_AT]
    );
  }

  /**
   * Extracts Job Scheduler request headers from the Express request object.
   * @param {object} expressReq - The Express request object.
   * @return {object} - An object containing the Job Scheduler request headers.
   * */
  getJobSchedulerRequestHeadersAsObject(expressReq) {
    const headers = {};
    Object.keys(JOB_SCHEDULER.headers).forEach((key) => {
      headers[JOB_SCHEDULER.headers[key]] = expressReq.headers[JOB_SCHEDULER.headers[key]];
    });
    return headers;
  }

  /**
   * Updates the job run log with the given status.
   * @param {object} status - The status to update the job run log with.
   * @param {object} originalRequestHeaders - The original request headers from the Job Scheduler.
   * @return {Promise<object>} - The response data from the API.
   * @throws {Error} - Throws an error if the request fails.
   * */
  async updateJobRunLog(status, originalRequestHeaders) {
    const jobId = originalRequestHeaders[JOB_SCHEDULER.headers.X_SAP_JOB_ID];
    const scheduleId = originalRequestHeaders[JOB_SCHEDULER.headers.X_SAP_JOB_SCHEDULE_ID];
    const runId = originalRequestHeaders[JOB_SCHEDULER.headers.X_SAP_JOB_RUN_ID];
    const url = `/scheduler/jobs/${jobId}/schedules/${scheduleId}/runs/${runId}`;
    return this._makeRequestWithBearerToken('put', url, status)
      .then((response) => response.data)
      .catch((error) => this._handleError('Error updating job run log', error));
  }

  async createJob(jobDetails) {
    const url = `/scheduler/jobs`;
    this.log.info(`Creating job schedule with body: ${JSON.stringify(jobDetails)}`);
    return this._makeRequestWithBearerToken('post', url, jobDetails)
      .then((response) => response.data)
      .catch((error) => this._handleError('Error creating job schedule', error));
  }

  async createJobSchedule(jobId, schedule) {
    const url = `/scheduler/jobs/${jobId}/schedules`;
    this.log.info(`Creating schedule for job ID [${jobId}] with body: ${JSON.stringify(schedule)}`);
    return this._makeRequestWithBearerToken('post', url, schedule)
      .then((response) => response.data)
      .catch((error) => this._handleError(`Error creating schedule for job ID [${jobId}]`, error));
  }

  async updateJobSchedule(jobId, scheduleId, schedule) {
    const url = `/scheduler/jobs/${jobId}/schedules/${scheduleId}`;
    this.log.info(
      `Updating schedule for job ID [${jobId}] and schedule ID [${scheduleId}] with body: ${JSON.stringify(
        schedule,
      )}`,
    );
    return this._makeRequestWithBearerToken('put', url, schedule)
      .then((response) => response.data)
      .catch((error) =>
        this._handleError(
          `Error updating schedule for job ID [${jobId}] and schedule ID [${scheduleId}]`,
          error,
        ),
      );
  }

  async deleteJobSchedule(jobId, scheduleId) {
    const url = `/scheduler/jobs/${jobId}/schedules/${scheduleId}`;
    this.log.info(`Deleting schedule ID [${scheduleId}] for job ID [${jobId}]`);
    return this._makeRequestWithBearerToken('delete', url, {})
      .then((response) => response.data)
      .catch((error) =>
        this._handleError(
          `Error deleting schedule ID [${scheduleId}] for job ID [${jobId}]`,
          error,
        ),
      );
  }

  async getJobDetails(jobId) {
    const url = `/scheduler/jobs/${jobId}?displaySchedules=true`;
    this.log.info(`Getting job details for job ID [${jobId}]`);
    return this._makeRequestWithBearerToken('get', url)
      .then((response) => response.data)
      .catch((error) =>
        this._handleError(`Error getting job details for job ID [${jobId}]`, error),
      );
  }

  /**
   * Helper function to make a request to the Job Scheduler API with a Bearer token for authentication.
   * @param {string} method - The HTTP method (GET, POST, PUT, DELETE).
   * @param {string} url - The URL for the request.
   * @param {object} data - The data to be sent with the request (for POST and PUT).
   * @returns {Promise<object>} - The response data from the API.
   * @throws {Error} - Throws an error if the request fails.
   */
  async _makeRequestWithBearerToken(method, url, data = null) {
    try {
      const jobScheduler = await cds.connect.to('JobScheduler');

      return await jobScheduler.send(method, url, data);
    } catch (error) {
      return Promise.reject(this._handleError('Error making request with bearer token', error));
    }
  }

  /**
   * Helper function to handle errors and log them.
   * @param {string} message - The error message to log.
   * @param {Error} error - The error object.
   * @throws {Error} - Throws the error after logging it.
   */
  _handleError(message, error) {
    this.log.error(`${message}:`, error);
    throw error;
  }
}

export default JobSchedulerClient;
