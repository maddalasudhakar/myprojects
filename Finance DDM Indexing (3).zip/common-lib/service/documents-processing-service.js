import DocumentsRepository from '../repository/documents-repository.js';
import CommonCompaniesRepository from '../repository/companies-repository.js';
import MessagesRepository from '../repository/messages-repository.js';
import Utilities from '../utils/utilities.js';
import mime from 'mime-types';
import {
  CDS_ENTITIES,
  DEFAULT_MAX_BATCHES_TO_PROCESS,
  DEFAULT_MAX_DOCUMENTS_TO_PROCESS,
  DEFAULT_MAX_ROWS_IN_BATCH,
  PROCESSING_STATUS,
  MESSAGE_PROCESSING_STATUS,
  FAILED_MESSAGE_JOB_STATUS,
  MAX_DOCUMENTS,
  DOCUMENT_STATUS_FOR_USER,
} from '../utils/constants.js';
const cdsGlobal = typeof cds !== 'undefined' ? cds : global.cds;
const log = cdsGlobal && cdsGlobal.log ? cdsGlobal.log('documents-processing-service') : { info: () => {}, error: () => {}, warn: () => {} };
const { uuid } = cdsGlobal && cdsGlobal.utils ? cdsGlobal.utils : { uuid: () => 'default-uuid' };

class DocumentsProcessingService {
  constructor() {
    this.documentsRepository = new DocumentsRepository();
    this.companiesRepository = new CommonCompaniesRepository();
    this.messagesRepository = new MessagesRepository();
  }
  /**
   * Fetches documents based on the provided status and optional filters.
   * @param {Array<string>} statusToBeProcessed - The status of documents to be fetched.
   * @param {object} filters - Optional filters.
   * @returns {Promise<Array<Object>>} The list of documents matching the criteria.
   */
  async getDocumentsForProcessing(statusToBeProcessed, filters) {
    let maxDocuments = MAX_DOCUMENTS || DEFAULT_MAX_DOCUMENTS_TO_PROCESS;
    if (isNaN(maxDocuments)) {
      maxDocuments = DEFAULT_MAX_DOCUMENTS_TO_PROCESS;
      log.warn(`MAX_DOCUMENTS_TO_PROCESS is not a valid number, defaulting to ${DEFAULT_MAX_DOCUMENTS_TO_PROCESS}`);
    }
    return await this.documentsRepository.getDocuments(statusToBeProcessed, maxDocuments, filters);
  }

  /**
   * Performs a bulk update to set a specific status for the provided documents.
   * @param {Array<Object>} documents - The list of documents to update.
   * @param {string} newStatus - The status to set for the documents.
   * @returns {Promise<void>}
   */
  async bulkUpdateDocumentsStatus(documents, newStatus) {
    if (!documents.length) {
      log.info('No documents to process.');
      return;
    }
    const documentIds = documents.map((doc) => doc.ID);
    return await this.documentsRepository.updateDocumentsProcessingStatus(documentIds, newStatus);
  }

  /**
   * Fetches documents based on provided filter criteria and processes these documents in batches.
   * Each document is processed by a provided function.
   * The processing status of the documents can be updated before processing.
   * @param {Function} processRow - The function that is called for processing each document row. It should return the data to be updated, in a JSON format containing the columnName and the value.
   * @param {Object} processDetails - Details for processing documents.
   * @param {Array<string>} processDetails.statusOfDocumentsToBeProcessed - The status of documents to be processed.
   * @param {object} filters - Optional filters.
   * @param {string} [processDetails.initialBulkUpdateStatus] - Optional status to be set for all data before processing.
   */
  async processDocuments(processRow, processDetails) {
    log.info('Processing documents with details:', processDetails);
    try {
      this.validateProcessDocumentsParams(processRow, processDetails);

      const { statusOfDocumentsToBeProcessed, initialBulkUpdateStatus, ...filters } = processDetails;

      const documents = await this.getDocumentsForProcessing(statusOfDocumentsToBeProcessed, filters);

      if (!documents.length) {
        log.info('No documents found for processing');
        return Utilities.generateDefaultResponse('documentsToBeSentToDoxForProcessing');
      } else {
        log.info('Number of documents fetched for processing:', documents.length);
      }

      if (initialBulkUpdateStatus) {
        await this.bulkUpdateDocumentsStatus(documents, initialBulkUpdateStatus);
      }

      return await this.splitDocumentsInBatches(documents, processRow);
    } catch (error) {
      log.error('Error processing documents:', error);
      throw error;
    }
  }

  /**
   * Processes received documents in batches.
   * The documents are split into batches and each document is processed by a provided function.
   * @param {Array<Object>} documents - The list of documents to process.
   * @param {Function} processRow - The function to process each document row.
   * @param {Object} batchProcessingDetails - Optional details for batch processing.
   */
  async processDocumentsInBatches(documents, processRow, batchProcessingDetails = null, tx) {
    log.info('Processing documents in batches');
    try {
      this.validateProcessDocumentsInBatchesParams(documents, processRow, batchProcessingDetails);
      return await this.splitDocumentsInBatches(documents, processRow, batchProcessingDetails, tx);
    } catch (error) {
      log.error('Error processing documents in batches:', error);
      throw error;
    }
  }

  /**
   * Splits the fetched documents into batches and processes each batch.
   * The number of batches and rows per batch are configurable.
   * @param {Array<Object>} documents - The list of documents to process.
   * @param {Function} processRow - The function to process each document row.
   * @param {Object} batchProcessingDetails - Optional details for batch processing.

   */
  async splitDocumentsInBatches(documents, processRow, batchProcessingDetails = null, tx = null) {
    log.info('Splitting documents into batches');
    try {
      let maxBatches = parseInt(cds.env.MAX_BATCHES_TO_PROCESS) || DEFAULT_MAX_BATCHES_TO_PROCESS;
      let maxRowsInBatch = parseInt(cds.env.MAX_ROWS_IN_BATCH) || DEFAULT_MAX_ROWS_IN_BATCH;
      if (isNaN(maxBatches)) {
        maxBatches = DEFAULT_MAX_BATCHES_TO_PROCESS;
        log.warn(`MAX_BATCHES_TO_PROCESS is not a valid number, defaulting to ${DEFAULT_MAX_BATCHES_TO_PROCESS}`);
      }
      if (isNaN(maxRowsInBatch)) {
        maxRowsInBatch = DEFAULT_MAX_ROWS_IN_BATCH;
        log.warn(`MAX_ROWS_IN_BATCH is not a valid number, defaulting to ${DEFAULT_MAX_ROWS_IN_BATCH}`);
      }

      const batches = [];
      for (let i = 0; i < documents.length; i += maxRowsInBatch) {
        batches.push(documents.slice(i, i + maxRowsInBatch));
      }

      const processingDocResponse = {
        totalBatchesProcessed: 0,
        batchDetails: []
      };

      for (const batch of batches.slice(0, maxBatches)) {
        const batchResult = await this.processBatch(batch, processRow, batchProcessingDetails, tx );
        processingDocResponse.totalBatchesProcessed++;
        processingDocResponse.batchDetails.push(batchResult);
      }

      return processingDocResponse;
    } catch (error) {
      log.error('Error splitting documents into batches:', error);
      throw error;
    }
  }

  /**
   * Processes a single batch of documents.
   * Each document in the batch is processed in parallel, and the results are used to update the database.
   * If a document fails to process, it will not block the processing of other documents.
   * @param {Array<Object>} batch - The batch of documents to process.
   * @param {Function} processRow - The function to process each document row.
   * @param {Object} processingDetails - Optional details to be used during processing.
   */
  async processBatch(batch, processRow, processingDetails, tx = null) {
    log.info('Processing batch of documents:', batch);
    try {
      const results = await Promise.allSettled(
        batch.map(async (row) => {
          const updateData = await processRow(row, processingDetails, tx);
          if (!updateData) {
            log.info(`No update data returned for document ID: ${row.ID}, skipping update.`); // this is usually the case when the document correction was triggered but there are no changes yet
            return { id: row.ID };
          }
          return { id: row.ID, data: updateData };
        })
      );
      log.info('Batch processing results:', results);

      const successfulProcessedRows = results.filter((result) => result.status === 'fulfilled').map((result) => result.value);
      const successfulUpdates = successfulProcessedRows.filter((row) => row.data); // Filter out rows with no update data
      const skippedRows = successfulProcessedRows.filter((row) => !row.data); // Rows that were skipped

      const failedUpdates = results.filter((result) => result.status === 'rejected').map((result) => result.reason);

      if (successfulUpdates.length) {
        log.info('Updating documents with updates:', successfulUpdates);
        await this.documentsRepository.updateDocumentsData(successfulUpdates, tx);
      }

      if (failedUpdates.length) {
        log.error('Failed to process some rows:', failedUpdates);
      }

      return {
        rowsProcessed: batch.length,
        successfulUpdatesCount: successfulUpdates.length,
        failedUpdatesCount: failedUpdates.length,
        skippedRowsCount: skippedRows.length
      };
    } catch (error) {
      log.error('Error processing batch:', error);
      throw error;
    }
  }

  /**
   * Validates the parameters for the `processDocuments` method.
   * @param {Function} processRow - The function to process each document row.
   * @param {Object} processDetails - Details for processing documents.
   */
  validateProcessDocumentsParams(processRow, processDetails) {
    if (!processRow || typeof processRow !== 'function') {
      throw new Error('processRow must be a function');
    }
    if (!processDetails || typeof processDetails !== 'object') {
      throw new Error('processDetails must be an object');
    }
    if (!processDetails.statusOfDocumentsToBeProcessed) {
      throw new Error('statusOfDocumentsToBeProcessed is required in processDetails');
    }
  }

  /**
   * Validates the parameters for the `processDocumentsInBatches` method.
   * @param {Array<Object>} documents - The list of documents to process.
   * @param {Function} processRow - The function to process each document row.
   * @param {Object} processDetails - Details for processing documents.
   */
  validateProcessDocumentsInBatchesParams(documents, processRow, processDetails) {
    if (processDetails && typeof processDetails !== 'object') {
      throw new Error('processDetails must be an object if it exists');
    }
    if (!Array.isArray(documents) || !documents.length) {
      throw new Error('documents must be a non-empty array');
    }
    if (!processRow || typeof processRow !== 'function') {
      throw new Error('the second argument must be a function');
    }
  }

  /**
   * Creates a new document in the database.
   * @param {Object} document - The document object to create.
   * @param {Object} attachment - The attachment object from the Inbox.
   * @param {Blob} content - The content of the attachment.
   * @returns {Promise<Object>} The created document.
   */
  async createDocumentWithAttachment(document, attachment, content = null) {
    log.info('Creating document with attachment:', document);

    if(attachment.contentType === 'application/octet-stream')
      attachment.contentType = mime.lookup(attachment.name);

    if (!Utilities.isValidContentType(attachment)) {
      return await this._createInvalidDocument(document, `Invalid content type: ${attachment.contentType}`);
    }

    if (!(await this._existsInCompanyDatabase(document.companyCode))) {
      return await this._createInvalidDocument(document, `Extracted company code ${document.companyCode} from email subject is not found`);
    }

    try {
      const attachmentService = await cds.connect.to('attachments');
      const attachmentId = uuid();

      await attachmentService.put(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS, {
        ID: attachmentId,
        up__ID: document.ID,
        content: content,
        filename: attachment.name,
        mimeType: attachment.contentType,
        url: attachmentId
      });

      document.processingStatus = PROCESSING_STATUS.UNPROCESSED;
      await this.documentsRepository.createDocument(document);
      return document;
    } catch (error) {
      log.error('Error creating document with attachment:', error.message);
      log.debug('Error details:', error.stack);
    }
  }

  /**
   * Updates an existing document with an attachment.
   * @param {Object} document - The document object to update.
   * @param {Object} attachment - The attachment object from the Inbox.
   * @param {Blob} content - The content of the attachment.
   * @returns {Promise<void>}
   */
  async updateDocumentWithAttachment(document, attachment, content = null) {
    log.info('Updating document with attachment:', document);
    if (!Utilities.isValidContentType(attachment)) {
      return await this._setDocumentToInvalid(document, `Invalid content type: ${attachment.contentType}`);
    }

    if (!(await this._existsInCompanyDatabase(document.companyCode))) {
      return await this._setDocumentToInvalid(document, `Extracted company code ${document.companyCode} from email subject is not found`);
    }

    try {
      const attachmentService = await cds.connect.to('attachments');
      const attachmentId = uuid();

      await attachmentService.put(CDS_ENTITIES.DISPUTE_MANAGEMENT_DOCUMENTS_ATTACHMENTS, {
        ID: attachmentId,
        up__ID: document.ID,
        content: content,
        filename: attachment.name,
        mimeType: attachment.contentType,
        url: attachmentId
      });

      document.processingStatus = PROCESSING_STATUS.UNPROCESSED;
      await this.documentsRepository.updateDocument(document);
      return document;
    } catch (error) {
      log.error('Error updating document with attachment:', error.message);
      log.debug('Error details:', error.stack);
    }
  }

  /**
   * Creates an invalid document by setting the processing status and error reason.
   * @param {Object} document - The document object to update.
   * @param {string} status - The processing status to set.
   * @param {string} errorReason - The error reason to set.
   * @returns {Promise<void>}
   */
  async _createInvalidDocument(document, errorReason) {
    document.status  = DOCUMENT_STATUS_FOR_USER.INVALID;
    document.processingStatus = PROCESSING_STATUS.INVALID_MAIL;
    document.errorReason = errorReason;
    log.info(`Creating invalid document: ${document.ID}, status: ${document.processingStatus}, error reason: ${document.errorReason}`);
    await this.documentsRepository.createDocument(document);
    return document;
  }

  async _setDocumentToInvalid(document, errorReason) {
    document.status  = DOCUMENT_STATUS_FOR_USER.INVALID;
    document.processingStatus = PROCESSING_STATUS.INVALID_MAIL;
    document.errorReason = errorReason;
    log.info(`Creating invalid document: ${document.ID}, status: ${document.processingStatus}, error reason: ${document.errorReason}`);
    await this.documentsRepository.upsertDocument(document);
    return document;
  }

  /**
   * Creates a document with an error reason.
   * @param {Object} document - The document object to update.
   * @param {string} errorReason - The error reason to set.
   * @returns {Promise<void>}
   */
  async createDocumentWithErrorReason(document, errorReason) {
    document.errorReason = errorReason;
    log.info(`Creating document with error reason: ${document.ID}, status: ${document.processingStatus}, error reason: ${document.errorReason}`);
    await this.documentsRepository.createDocument(document);
  }

  async _existsInCompanyDatabase(companyCode) {
    const company = await this.companiesRepository.getCompanyByCompanyCode(companyCode);
    if (!company) {
      log.warn(`Company code ${companyCode} does not exist in the database.`);
      return false;
    }
    return true;
  }

  /**
   * Creates a new message in the database.
   * @param {Object} message - The message object to create.
   * @returns {Promise<Object>} The created message.
   */
  async createMessage(message) {
    return this.messagesRepository.createMessage(message);
  }

  /**
   * Updates an existing message in the database.
   * @param {Object} message - The message object to update.
   * @returns {Promise<Object>} The updated message.
   */
  async updateMessage(message) {
    return this.messagesRepository.updateMessage(message);
  }

  /**
   * Fetches failed messages from the database based on the provided processing status.
   * @returns {Promise<Array<Object>>} The list of failed messages.
   */
  async getFailedMessages() {
    const processingStatusList = [MESSAGE_PROCESSING_STATUS.ATTACHMENTS_FETCH_ERROR];
    return this.messagesRepository.getFailedMessages(processingStatusList);
  }

  /**
   * Fetches a message by its external ID from the database.
   * @param {string} externalMessageId - The external ID of the message.
   * @returns {Promise<Object>} The message object.
   */
  async getMessageByExternalId(externalMessageId) {
    const message = await this.messagesRepository.getMessageByExternalId(externalMessageId);
    return message;
  }

  /**
   * Fetches a document by its external attachment ID from the database.
   * @param {string} externalAttachmentId - The external attachment ID of the document.
   * @returns {Promise<Object>} The document object.
   */
  async getDocumentByExternalAttachmentId(externalAttachmentId) {
    const document = await this.documentsRepository.getDocumentByExternalId(externalAttachmentId);
    return document;
  }

  /**
   * Fetches failed documents from the database based on the provided processing status.
   * @returns {Promise<Array<Object>>} The list of failed documents.
   */
  async getFailedDocuments() {
    const processingStatusList = [PROCESSING_STATUS.CONTENT_FETCH_ERROR];
    return this.documentsRepository.getFailedDocuments(processingStatusList);
  }

  /**
   * Creates a failed message job in the database.
   * @param {Object} messageJob - The job data to create.
   * @returns {Promise<void>}
   */
  async createFailedMessageJob(messageJob) {
    await this.messagesRepository.createFailedMessageJob(messageJob);
  }

  /**
   * Updates a failed message job in the database.
   * @param {Object} messageJob - The job data to update.
   * @returns {Promise<void>}
   */
  async updateFailedMessageJob(messageJob) {
    await this.messagesRepository.updateFailedMessageJob(messageJob);
  }

  /**
   * Fetches failed message jobs from the database based on the provided processing status.
   * @returns {Promise<Array<Object>>} The list of failed message jobs.
   */
  async getFailedMessageJobs() {
    const processingStatusList = [FAILED_MESSAGE_JOB_STATUS.UNPROCESSED];
    const maxRetryCount =  3;
    return this.messagesRepository.getFailedMessageJobs(processingStatusList, maxRetryCount);
  }
}

export default new DocumentsProcessingService();
