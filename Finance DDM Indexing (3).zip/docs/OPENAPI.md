# Getting Started

OpenAPI defines a standard interface to APIs which leads to discovering and understanding the capabilities of the service without access to the source code.

## Next Steps

- in order to generate the openapi3 representation of the service APIs you will need to run : npm run compile:openapi in one of the services (read below how to test locally vs. how to test in hybrid mode)
- a docs folder will be generated where you can find the openapi json object
- you can test locally or in hybrid mode; in hybrid mode you can use services from cloud in your local environment
  Example for hybrid mode: you can make requests from localhost and use the hana database 


To test locally:
- delete the required roles for authentication from the service (add back when you finish testing locally)
- regenerate the openapi docs file : npm run compile:openapi
- npm install and npm run build
- start your service locally: npm run start 
- go to local host on the port the server is listening to and click on Open API Preview
- you can now test locally any of the available APIs


To test in hybrid mode:
- add annotation in the service {{your_service_name}}-service.cds (remove when you finish testing) :
  Example - for dispute-analyzer-service.cds :  annotate DisputeAnalyzerService with @(
      Authorization: {
         Authorizations: [
            { $Type : 'Authorization.Http', Name : 'JWT',   Scheme : 'bearer', BearerFormat : 'JWT' },
         ],
         SecuritySchemes: [
           { Authorization : 'JWT', RequiredScopes : ['BusinessUser', 'Administrator'] },
         ],
      }
   );
    Example - for rule-orchestrator-service.cds :  annotate RuleOrchestratorService with @(
      Authorization: {
         Authorizations: [
            { $Type : 'Authorization.Http', Name : 'JWT',   Scheme : 'bearer', BearerFormat : 'JWT' },
         ],
         SecuritySchemes: [
           { Authorization : 'JWT', RequiredScopes : [ 'Administrator' ] },
         ],
      }
   );
- regenerate the openapi docs file: npm run compile:openapi
- npm install and npm run build
- npm run setup:hybrid
- npm run start
- go to local host on the port the server is listening to and click on Open API Preview :
  In order to get the authorization code for authentication required for making requests follow these steps:
  Make sure you have the required user roles assigned to you
  Enter this link in the browser: {{auth_url}}/oauth/authorize?&response_type=code&client_id={{client_id}} 
  Take the auth_url and client_id from the key generated in cloud after running npm run setup:hybrid  
  The link will then require for authentication the client id and client secret and generate an error but also a code in the URL that you will have to copy for using it in the next step
  Paste the copied code in this URL in the browser: {{auth_url}}/oauth/token?grant_type=authorization_code&code={{generated_code}}&client_id={{client_id}}
  This will generate an authorization token that you will have to copy and paste into the authorization field in the Open API Preview
  For more information about the authentication follow this link: https://community.sap.com/t5/technology-blogs-by-sap/sap-cloud-platform-backend-service-tutorial-15-security-using-authorization/ba-p/13404903
- you can now test in hybrid mode any of the available APIs (you can check in the .cdsrc-private.json which services are used from the cloud in hybrid mode)